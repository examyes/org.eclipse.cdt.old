/*******************************************************************************
 * Copyright (c) 2000, 2004 QNX Software Systems and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     QNX Software Systems - Initial API and implementation
 *******************************************************************************/

package org.eclipse.cdt.indent;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.cdt.core.formatter.CodeFormatter;
import org.eclipse.cdt.utils.spawner.ProcessFactory;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.text.edits.MultiTextEdit;
import org.eclipse.text.edits.ReplaceEdit;
import org.eclipse.text.edits.TextEdit;

/**
 */
public class IndentFormatter extends CodeFormatter {

	// TODO: This is hardcoded it shoul be in a preference page.
	String commandPath = "indent";
	Map fOptions = new HashMap();

	/* (non-Javadoc)
	 * @see org.eclipse.cdt.core.org.eclipse.cdt.indent.CodeFormatter#format(int, org.eclipse.jface.text.IDocument, int, int, int, java.lang.String)
	 */
	public TextEdit format(int kind, String source, int offset,
			int length, int indentationLevel, String lineSeparator) {
		try {
			File tempFile = File.createTempFile("indent", null); //$NON-NLS-1$
			FileOutputStream ostream = new FileOutputStream(tempFile);
			Writer writer = new OutputStreamWriter(ostream);
			writer.write(source.substring(offset, offset + length).toCharArray());
			writer.close(); // close file, otherwise astyle fails to open it
			transform(tempFile.getCanonicalPath());
			FileInputStream istream = new FileInputStream(tempFile);
			Reader reader = new InputStreamReader(istream);
			BufferedReader br  = new BufferedReader(reader);
			StringBuffer buffer = new StringBuffer();
			String line;
			while ((line = br.readLine()) != null) {
				buffer.append(line).append(lineSeparator);
			}
			int bLen = buffer.length();
			MultiTextEdit textEdit = new MultiTextEdit(offset, length);
			textEdit.addChild(new ReplaceEdit(offset, length, buffer.toString()));
			br.close();
			return textEdit;
		} catch (IOException e) {
			Status status = new Status(IStatus.ERROR, IndentPlugin.PLUGIN_ID, IStatus.ERROR, "Error", e); //$NON-NLS-1$
			IndentPlugin.getDefault().getLog().log(status);
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.cdt.core.org.eclipse.cdt.indent.CodeFormatter#setOptions(java.util.Map)
	 */
	public void setOptions(Map options) {
		fOptions.putAll(options);
	}

	void transform(String tempname) throws IOException {
		String[] cmdArray = new String[] { commandPath, tempname };
		Process p = ProcessFactory.getFactory().exec(cmdArray);
		try {
			p.waitFor();
		} catch (InterruptedException e) {
			Status status = new Status(IStatus.ERROR, IndentPlugin.PLUGIN_ID, IStatus.ERROR, "Error", e); //$NON-NLS-1$
			IndentPlugin.getDefault().getLog().log(status);
		}
	}

	public boolean supportProperty(String propertyID) {
		// TODO Auto-generated method stub
		return false;
	}

	public String[][] getEnumerationProperty(String propertyID) {
		// TODO Auto-generated method stub
		return null;
	}
}
