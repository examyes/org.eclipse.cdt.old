////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */
package com.ibm.debug.daemon;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

import com.ibm.debug.daemon.util.StatusInfo;

/**
 * The action delegate for the daemon listening button on the debug toolbar.
 */



public class ListenActionDelegate implements IViewActionDelegate {
	
	private static IAction thisAction;
	
	public ListenActionDelegate() {
		updateToolTip();		
	}
	
	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		valueChanged(action.isChecked());
		String label= getToolTipText(action.isChecked());
		action.setToolTipText(label);
		action.setText(label);
		if(thisAction == null)
			thisAction = action;		
	}
	
	/**
	 * @see ToggleDelegateAction#getShowText()
	 */
	static protected String getToolTipText(boolean isChecked) {
		if(isChecked)
			return DaemonUtils.getFormattedString("ListenActionDelegate.tooltip2",CoreDaemon.getPortPreference());
		return DaemonUtils.getFormattedString("ListenActionDelegate.tooltip",CoreDaemon.getPortPreference());		
	}
	
	private void valueChanged(boolean isChecked)
	{
		if(isChecked)
		{
			if(!CoreDaemon.startListening())
			{
		//		System.out.println("Start Listening failed");
				StatusInfo status = new StatusInfo();
				status.setError(
					DaemonUtils.getResourceString("DaemonPreferencePage.portInUseError"));
					ErrorDialog.openError(
						DebugDaemonPlugin.getDefault().getShell(),
						DaemonUtils.getResourceString("ErrorDialog.error"),
						null,
						status);
				updateButtonState(false);
			}
			
		}
		else 
			CoreDaemon.stopListening();		
	}
	
	/**
	 * Only intended for use by the daemon.  Button will be updated to appropriate state if daemon
	 * told to start/stop listening programatically (rather than by user pushing button).
	 */
	static public void updateButtonState(boolean isListening)
	{
		if(thisAction == null)
			return;  //nothing we can do if we don't have a button reference yet
		thisAction.setChecked(isListening);
		
		String label= getToolTipText(isListening);
		thisAction.setToolTipText(label);
		thisAction.setText(label);
		
	}
	/**
	 * Intended for use by preference page when daemon port changed (while daemon not listening).
	 * If daemon is listening, preference page will stop and restart the daemon and the tooltip
	 * will update automatically.
	 */
	static public void updateToolTip()
	{
		if(thisAction == null || CoreDaemon.isListening())
			return;  //nothing we can do if we don't have a button reference yet
		String label= getToolTipText(false);
		thisAction.setToolTipText(label);
		thisAction.setText(label);
	}

	/*
	 * @see IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart view) {
	}

	/*
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
		if(thisAction == null)
			thisAction = action;		
	}

}



