package com.ibm.debug.daemon;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.core.ILauncher;
import org.eclipse.debug.core.model.ILauncherDelegate;
import org.eclipse.jface.viewers.StructuredSelection;



public class DaemonLauncherDelegate implements ILauncherDelegate {

	

    /**
     * @see ILauncherDelegate#launch(Object[], String, ILauncher)
     */
    public boolean launch(Object[] elements, String mode, ILauncher launcher) {
        StructuredSelection selection = new StructuredSelection(elements);
    	boolean result = DebugDaemonPlugin.launchDaemon(launcher, selection.getFirstElement());
        return result;

    }

    /**
     * @see ILauncherDelegate#getLaunchMemento(Object)
     */
    public String getLaunchMemento(Object element) {
        return null;
    }

    /**
     * @see ILauncherDelegate#getLaunchObject(String)
     */
    public Object getLaunchObject(String memento) {
        return null;
    }
    /**
	 * Can be used to start launch daemon if another launcher requires the daemon to be running.
	 * Returns the port number it is listening on if successful, else returns -1.
	 * @param elements The array of objects passed to the constructor of the calling launcher.
	 * @see ILauncher
	 * @see CoreDaemon.isListening()
	 */
	static public int launchDaemon(Object[] elements)
	{
		if(!CoreDaemon.isListening())
			new DaemonLauncherDelegate().launch(elements, ILaunchManager.DEBUG_MODE, 
												findLauncher("com.ibm.debug.daemon.DaemonLauncherDelegate"));
		return CoreDaemon.getCurrentPort();
	}
	
	static private ILauncher findLauncher(String id)
  	{
  		ILauncher[] registeredLaunchers = DebugPlugin.getDefault().getLaunchManager().getLaunchers();
    	ILauncher launcher =null;  //the launcher associated with the delegate
    	
    	for(int i=0; i< registeredLaunchers.length; i++)
    	{       		
        		if(registeredLaunchers[i].getIdentifier().equals(id))        			
        			launcher = registeredLaunchers[i];    			   		 
        		      		
    	}
    	
    	return launcher;   
  	}
}
