package com.ibm.debug.daemon;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.IntegerFieldEditor;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.jface.preference.StringFieldEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

public class DebugDaemonPreferencePage
	extends PreferencePage
	implements IWorkbenchPreferencePage
{
	private static final String PAGE_NAME = "DaemonPreferencePage";

	private IntegerFieldEditor fPort;
	private IPreferenceStore fPreferenceStore;
	private String tmpPort;
	private boolean isListening=false;
	
	public DebugDaemonPreferencePage()
	{
		fPreferenceStore = DebugDaemonPlugin.getDefault().getPreferenceStore();
	}

	public void init(IWorkbench workbench)
	{}

	/**
	 * @see PreferencePage#createContents
	 */
	public Control createContents(Composite parent)
	{
		Composite composite = new Composite(parent, SWT.NONE);
		int nColumns = 2;

		/*MGridLayout layout = new MGridLayout();
		layout.marginWidth = 0;
		layout.marginHeight = 0;
		layout.numColumns = nColumns;
		composite.setLayout(layout);

		fPort = new StringDialogField();
		fPort.setLabelText(DaemonUtils.getResourceString(PAGE_NAME + ".portLabel"));
		fPort.doFillIntoGrid(composite, nColumns);
		new Separator().doFillIntoGrid(composite, 1, 1);
					
		restoreSettings();*/
		
		fPort = new IntegerFieldEditor(DebugDaemonPlugin.DAEMON_PORT, 
			DaemonUtils.getResourceString(PAGE_NAME + ".portLabel"), composite);

		fPort.setPreferenceStore(fPreferenceStore);
		fPort.setPreferencePage(this);
		fPort.setErrorMessage(DaemonUtils.getResourceString(PAGE_NAME + ".portMustBeIntError"));
		fPort.setValidateStrategy(StringFieldEditor.VALIDATE_ON_KEY_STROKE);
		fPort.setValidRange(1, Integer.MAX_VALUE);
		fPort.setFocus();
		fPort.load();	
		
		tmpPort = fPreferenceStore.getString(DebugDaemonPlugin.DAEMON_PORT);
		//remember if the daemon was listening when we started. Used to restore daemon to current state.
		isListening = CoreDaemon.isListening();

		return composite;
	}

	/**
	 * @see PreferencePage#performDefaults
	 */
	public void performDefaults()
	{				
		fPort.loadDefault();
	}

	
	/**
	 * @see PreferencePage#performOk
	 */
	public boolean performOk()
	{
		boolean result = false;

		//String port = fPort.getText();
		int portNum=-1;
		try{
			 portNum = fPort.getIntValue();
		}catch(NumberFormatException e){
			fPort.setErrorMessage(DaemonUtils.getResourceString(PAGE_NAME + ".portMustBeIntError"));
			return result;
		}
		result = true;
		fPort.store();
				
		ListenActionDelegate.updateToolTip();		
		//stop and restart the daemon on the new port
		if(isListening && CoreDaemon.getCurrentPort() != portNum)
		{
			CoreDaemon.stopListening();
			result = CoreDaemon.startListening();
			
			if(result == false)
			{
				ListenActionDelegate.updateButtonState(false);  //return to not listening state
				fPort.setErrorMessage(DaemonUtils.getResourceString(PAGE_NAME + ".portInUseError"));
				fPort.showErrorMessage();
				/*StatusInfo status = new StatusInfo();
				status.setError(
					DaemonUtils.getResourceString(PAGE_NAME + ".portInUseError"));
					ErrorDialog.openError(
						getShell(),
						DaemonUtils.getResourceString("ErrorDialog.error"),
						null,
						status);						*/
			}	
					
		}	
		
		//reset error message to int error
		fPort.setErrorMessage(DaemonUtils.getResourceString(PAGE_NAME + ".portMustBeIntError"));
					
		return result;
	}
	
	public void performApply()
	{
		performOk();
	}
	
	public boolean performCancel()
	{
		//reset to old value (valid port number) so daemon can still start
		fPreferenceStore.setValue(DebugDaemonPlugin.DAEMON_PORT, tmpPort);	
		return true;
	}	
	
}