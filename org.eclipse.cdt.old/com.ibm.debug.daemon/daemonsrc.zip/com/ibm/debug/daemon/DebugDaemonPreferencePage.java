package com.ibm.debug.daemon;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.util.Iterator;
import java.util.Vector;

import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILauncher;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import com.ibm.debug.daemon.util.MGridData;
import com.ibm.debug.daemon.util.MGridLayout;
import com.ibm.debug.daemon.util.Separator;
import com.ibm.debug.daemon.util.StatusInfo;
import com.ibm.debug.daemon.util.StringCombo;
import com.ibm.debug.daemon.util.StringDialogField;

public class DebugDaemonPreferencePage
	extends PreferencePage
	implements IWorkbenchPreferencePage
{
	private static final String PAGE_NAME = "DaemonPreferencePage";

	private StringDialogField fPort;
	private StringCombo fDefaultConfig;
	private IPreferenceStore fPreferenceStore;

	public DebugDaemonPreferencePage()
	{
		fPreferenceStore = DebugDaemonPlugin.getDefault().getPreferenceStore();
	}

	public void init(IWorkbench workbench)
	{}

	/**
	 * @see PreferencePage#createContents
	 */
	public Control createContents(Composite parent)
	{
		Composite composite = new Composite(parent, SWT.NONE);
		int nColumns = 2;

		MGridLayout layout = new MGridLayout();
		layout.marginWidth = 0;
		layout.marginHeight = 0;
		layout.numColumns = nColumns;
		composite.setLayout(layout);

		fPort = new StringDialogField();
		fPort.setLabelText(DaemonUtils.getResourceString(PAGE_NAME + ".portLabel"));
		fPort.doFillIntoGrid(composite, nColumns);
		new Separator().doFillIntoGrid(composite, 1, 1);
		
		Label label = new Label(composite, SWT.WRAP | SWT.LEFT);
		label.setText(DaemonUtils.getResourceString(PAGE_NAME + ".portNote"));
		new Separator().doFillIntoGrid(composite, 2, 3);

		fDefaultConfig = new StringCombo();
		fDefaultConfig.setLabelText(DaemonUtils.getResourceString(PAGE_NAME + ".configLabel"));
		fDefaultConfig.doFillIntoGrid(composite, nColumns);

		
		
		
		
		MGridData gridData = new MGridData();
		gridData.horizontalAlignment = gridData.FILL;
		gridData.horizontalSpan = 1;
		label.setLayoutData(gridData);
		fDefaultConfig.setItems(findLaunchers());
		restoreSettings();
		

		return composite;
	}

	/**
	 * @see PreferencePage#performDefaults
	 */
	public void performDefaults()
	{
		String port = fPreferenceStore.getDefaultString(DebugDaemonPlugin.DAEMON_PORT);
		fPort.setText(port);
	}

	protected void restoreSettings()
	{
		String port = fPreferenceStore.getString(DebugDaemonPlugin.DAEMON_PORT);
		fPort.setText(port);
		String defaultConfig = fPreferenceStore.getString(DebugDaemonPlugin.DEFAULT_LAUNCH_CONFIG);
		fDefaultConfig.setText(defaultConfig);
	}

	private String[] findLaunchers()
	{
		ILauncher[] registeredLaunchers =
			DebugPlugin.getDefault().getLaunchManager().getLaunchers();
		Vector launcherChoices = new Vector();
		//launchers that implement IDaemonSupport or IOldDaemonSupport

		for (int i = 0; i < registeredLaunchers.length; i++)
		{
			if (registeredLaunchers[i].getDelegate() instanceof IDaemonSupport
				|| registeredLaunchers[i].getDelegate() instanceof IOldDaemonSupport)
				launcherChoices.add(registeredLaunchers[i].getIdentifier());
		}
		if(launcherChoices.isEmpty())
			return new String[0];
			
		String[] ids=new String[launcherChoices.size()];
		Iterator iterator = launcherChoices.iterator();
		int i=0;
		while(iterator.hasNext())
		{
			ids[i]=(String)iterator.next();
			i++;
		}
		return ids;
	}
	
	/**
	 * Check if launcher ID is valid and that the launcher delegate for the launcher
	 * implements one of the daemon interfaces.
	 */
	private boolean validateLauncher(String id)
	{
		ILauncher[] registeredLaunchers =
			DebugPlugin.getDefault().getLaunchManager().getLaunchers();
		
		for (int i = 0; i < registeredLaunchers.length; i++)
		{
			if (registeredLaunchers[i].getIdentifier().equals(id) &&
				(registeredLaunchers[i].getDelegate() instanceof IDaemonSupport
				|| registeredLaunchers[i].getDelegate() instanceof IOldDaemonSupport))
				return true;
		}
		return false;
	}

	/**
	 * @see PreferencePage#performOk
	 */
	public boolean performOk()
	{
		boolean result = false;

		String port = fPort.getText();
		int portNum=-1;
		String config = fDefaultConfig.getText();
		
		if (!port.equals(""))
		{
			try
			{
				portNum = Integer.parseInt(port);
				fPreferenceStore.setValue(DebugDaemonPlugin.DAEMON_PORT, port);								
			} catch (NumberFormatException e)
			{
				StatusInfo status = new StatusInfo();
				status.setError(
					DaemonUtils.getResourceString(PAGE_NAME + ".portMustBeIntError"));
					ErrorDialog.openError(
					getShell(),
					DaemonUtils.getResourceString("ErrorDialog.error"),
					null,
					status);
				return result;
			}
			if(portNum < 0)
			{
				StatusInfo status = new StatusInfo();
				status.setError(
					DaemonUtils.getResourceString(PAGE_NAME + ".portMustBeIntError"));
					ErrorDialog.openError(
					getShell(),
					DaemonUtils.getResourceString("ErrorDialog.error"),
					null,
					status);
				return result;			
			}
		}		
		
		if(validateLauncher(config))
		{
			fPreferenceStore.setValue(DebugDaemonPlugin.DEFAULT_LAUNCH_CONFIG,config);
			result = true;
		}
		else
		{
			StatusInfo status = new StatusInfo();
			status.setError(
				DaemonUtils.getResourceString(PAGE_NAME + ".badConfigError"));
			ErrorDialog.openError(
				getShell(),
				DaemonUtils.getResourceString("ErrorDialog.error"),
				null,
				status);
		}
		
		return result;
	}
}