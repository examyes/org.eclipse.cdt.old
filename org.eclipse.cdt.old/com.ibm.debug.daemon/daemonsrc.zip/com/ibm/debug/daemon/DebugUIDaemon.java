package com.ibm.debug.daemon;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.core.resources.IMarkerDelta;
import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILauncher;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.IMemoryBlock;
import org.eclipse.debug.core.model.IProcess;
import org.eclipse.debug.core.model.IThread;
import org.eclipse.jface.preference.IPreferenceStore;

/**
 * Represents the UI daemon that will listen for incoming requests to start a debug session
 */

public class DebugUIDaemon implements IDebugTarget{

    private CoreDaemon daemon = null;
    private ILauncher launcher;
    private Object selection;
    private String portNumber;
    private int port;

    /**
     * Constructor for DebugUIDaemon
     */
    public DebugUIDaemon(ILauncher launcher, Object obj) {
        this.launcher = launcher;
        this.selection = obj;

        // get the port number from the preference store
        IPreferenceStore preferenceStore = DebugDaemonPlugin.getDefault().getPreferenceStore();
      	portNumber = preferenceStore.getString(DebugDaemonPlugin.DAEMON_PORT);
		// convert the port number
        try {
            port = Integer.parseInt(portNumber);
        } catch(NumberFormatException e) {
        }

        // start the UI daemon listening
        daemon = new CoreDaemon();   
        daemon.startListening(portNumber);
    }

 /*   String getportNumber() {
        return portNumber;
    }*/

    /**
     * Get the port the daemon is listening on.
     * @returns The port as an int.
     */
   /* public int getPort() {
        return port;
    }*/

    /**
     * @see IAdaptable#getAdapter(java.lang.Class)
     */
    public Object getAdapter(Class arg0) {
        return null;
    }

    /**
     * @see IDisconnect#isDisconnected()
     */
    public boolean isDisconnected() {
        return false;
    }

    /**
     * @see IDisconnect#disconnect()
     */
    public void disconnect() throws DebugException {
    }

    /**
     * @see IDisconnect#canDisconnect()
     */
    public boolean canDisconnect() {
        return false;
    }

    /**
     * @see ISuspendResume#suspend()
     */
    public void suspend() throws DebugException {
    }

    /**
     * @see ISuspendResume#resume()
     */
    public void resume() throws DebugException {
    }

    /**
     * @see ISuspendResume#isSuspended()
     */
    public boolean isSuspended() {
        return false;
    }

    /**
     * @see ISuspendResume#canSuspend()
     */
    public boolean canSuspend() {
        return false;
    }

    /**
     * @see ISuspendResume#canResume()
     */
    public boolean canResume() {
        return false;
    }

    /**
     * @see ITerminate#terminate()
     */
    public void terminate() throws DebugException {
        daemon.stopListening();   
        DebugPlugin.getDefault().getLaunchManager().deregisterLaunch(getLaunch());
    }

    /**
     * @see ITerminate#isTerminated()
     */
    public boolean isTerminated() {
        return !daemon.isListening();
    }

    /**
     * @see ITerminate#canTerminate()
     */
    public boolean canTerminate() {
        return daemon.isListening();
    }

    /**
     * @see IDebugElement#getModelIdentifier()
     */
    public String getModelIdentifier() {
        return null;
    }

    /**
     * @see IDebugElement#getName()
     */
    public String getName() throws DebugException {
        return DaemonUtils.getFormattedString("DebugUIDaemon.targetName", portNumber);
    }

    /**
     * @see IDebugElement#getLaunch()
     */
    public ILaunch getLaunch() {
        return DebugPlugin.getDefault().getLaunchManager().findLaunch(this);
    }

    
    /**
     * @see IDebugElement#getDebugTarget()
     */
    public IDebugTarget getDebugTarget() {
        return this;
    }

    /**
     * @see IDebugTarget#getProcess()
     */
    public IProcess getProcess() {
        return null;
    }

   

	/*
	 * @see IDebugTarget#getThreads()
	 */
	public IThread[] getThreads() throws DebugException {
		return new IThread[0];
	}

	/*
	 * @see IBreakpointListener#breakpointAdded(IBreakpoint)
	 */
	public void breakpointAdded(IBreakpoint breakpoint) {
	}

	/*
	 * @see IBreakpointListener#breakpointRemoved(IBreakpoint, IMarkerDelta)
	 */
	public void breakpointRemoved(IBreakpoint breakpoint, IMarkerDelta delta) {
	}

	/*
	 * @see IBreakpointListener#breakpointChanged(IBreakpoint, IMarkerDelta)
	 */
	public void breakpointChanged(IBreakpoint breakpoint, IMarkerDelta delta) {
	}

	/*
	 * @see IMemoryBlockRetrieval#supportsStorageRetrieval()
	 */
	public boolean supportsStorageRetrieval() {
		return false;
	}

	/*
	 * @see IMemoryBlockRetrieval#getMemoryBlock(long, long)
	 */
	public IMemoryBlock getMemoryBlock(long startAddress, long length)
		throws DebugException {
		return null;
	}

}
