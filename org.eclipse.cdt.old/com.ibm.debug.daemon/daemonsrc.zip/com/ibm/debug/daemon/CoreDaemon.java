package com.ibm.debug.daemon;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Hashtable;
import java.util.Vector;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.core.ILauncher;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.ILauncherDelegate;
import org.eclipse.jface.preference.IPreferenceStore;
/**
 * The class that will create a server socket and listen on that socket for incoming socket 
 * and daemon connections.  
 * The daemon can only listen on one port at a time, but can be simultaneously connected to multiple
 * engines/kickers through that port.  Once a connection is received, the daemon will continue listening
 * for other connections.
 */
public class CoreDaemon
{

	public static final String _defaultPort = "8001";  //the default port that will be used
	private static int port=-1; //the port the daemon is currently listening on (negative if not listening)
	private static volatile boolean isListening = false; 
	private static ServerSocket serverSocket;
	private static volatile Vector socketsToBeClosed = new Vector();
	
	//counter to keep track of current key (need unique values)
	private static int currentKey = 0;
	// a hashtable to store debug targets using the key as the index
	private static Hashtable targetHashtable = new Hashtable();	
	private static ListenerThread listenerThread;
	private static CoreDaemon instance;
	
	/**
	 * Can be used to check if the daemon is listening
	 * @return true if the daemon is currently listening
	 * @see getCurrentPort() to find out which port the daemon is listening on
	 * @see startListening() if you need to start the daemon
	 */
	public static boolean isListening()
	{
		return CoreDaemon.isListening;
	}

	/**
	 * Should be used by launchers that need to tell engine where daemon is listening.
	 * A negative value indicates the daemon is not currently listening.
	 * Host is always "localhost".
	 * @see isListening()
	 */
	public static int getCurrentPort()
	{
		return CoreDaemon.port;
	}
	
	/**
	 * Intended for use with the few non-static methods in this class.
	 * @see startListening()
	 * @return CoreDaemon returns an instance of this class
	 */
	static public CoreDaemon getInstance()
	{		
		if(instance == null)
			instance = new CoreDaemon();
		return instance;
	}
	
		
	/**
	 * Returns the port specified in the preference page.
	 * If entry is not found, will return _defaultPort.
	 * @return the port that daemon will listen on when told to listen
	 */
	static public String getPortPreference()	
	{	
		IPreferenceStore preferenceStore = DebugDaemonPlugin.getDefault().getPreferenceStore();
      	String portNumber = preferenceStore.getString(DebugDaemonPlugin.DAEMON_PORT);
      	if(portNumber == null || (portNumber.trim()).equals(""))
      		return _defaultPort;
      	else return portNumber;
	}
	

	
	
	/**
	 * Starts listening for remote engine requests on port specified in preference page.
	 * Does nothing if daemon is already listening.
	 * @return boolean - true means successful
	 * @see getInstance() Can be called using CoreDaemon.getInstance().startListening()
	 * @see isListening()
	 * @see stopListening()
	 * @see getPortPreference() Returns the port number that the daemon will start listening 
	 * 							on when this method is called
	 */
	static public boolean startListening()
	{
		return getInstance().startListening(CoreDaemon.getPortPreference());
	}
	
	/**
	 * Starts listening for remote engine requests on the port number specified.
	 * Does nothing if daemon is already listening.
	 * Internal use only.  Plugin developers should use startListening()
	 * @param String - the port number the daemon should listen on.
	 * @return boolean - true means successful
	 */
	private boolean startListening(String portNumber)
	{
		// initially supports 1 daemon
		// first check to see if we are already listening
		if (isListening())
			return true;
			
		// check to make sure that the new port number is a valid number
		port = convertPortNumberToInt(portNumber);				
		isListening = true;
		try{
			initServer(port,2,1000);
		} catch (IOException e)
		{				
			DebugDaemonPlugin.logText("Could not start daemon listening:"+e.getMessage(),DebugDaemonPlugin.ERR,e);
			port=-1;
			isListening=false;
			return false;
		}		
		
		DebugDaemonPlugin.logText("Daemon is now listening on port "+port,DebugDaemonPlugin.DBG,null);
		
		listenerThread = new ListenerThread();
		listenerThread.setDaemon(true);
		listenerThread.setName("DbgDaemon");
		listenerThread.start();	
			
		ListenActionDelegate.updateButtonState(true);
		return true;
	}
	
	/**
	 * Converts the string to an integer, checking for proper format and a positive number.
	 */
	static private int convertPortNumberToInt(String port)
	{
		int setPortNumber;
		try
		{
			setPortNumber = Integer.parseInt(port);
		} catch (NumberFormatException ne)
		{
			DebugDaemonPlugin.displayError("BadPortFormat.title", "BadPortFormat.message");
			DebugDaemonPlugin.logText("Port number "+port+" not valid",DebugDaemonPlugin.ERR,ne);
			return -1;
		}

		if (setPortNumber <= 0)
		{
			DebugDaemonPlugin.displayError("BadPortFormat.title", "BadPortFormat.message");
			DebugDaemonPlugin.logText("Port number "+port+" not a positive integer",DebugDaemonPlugin.ERR,null);
			return -1;
		}		
		return setPortNumber;
	}

	/**
	 * Tells the debug daemon to stop listening.  This will change the flag (to cause the listener to fall out
	 * of the ServerSocket.accept() and will eventually lead to the closing of the server socket.
	 * This method is normally not needed by plugin developers.
	 * It is intended for use by the preferences page when changing ports and the daemon listening button
	 * when the daemon is shut off by the user.
	 */
	static public void stopListening()
	{
		if(!isListening)
			return;
		CoreDaemon.isListening = false;  //flag will tell socket to stop
		CoreDaemon.port = -1;
		if(serverSocket != null)
		{
			CoreDaemon.socketsToBeClosed.addElement(serverSocket);
			serverSocket = null;
		}
		
		DebugDaemonPlugin.logText("Daemon has requested to stop listening",DebugDaemonPlugin.DBG,null);
		//make sure button reflects current daemon state
		ListenActionDelegate.updateButtonState(false);
	}
	
	/**
	 * Will be called when the socket times out while listening, and sees that it should 
	 * stop listening.  This method is called as a result of a previous call to stopListening().
	 */
	static private void closeServerSocket()
	{
		//System.out.println("IN CLOSE SERVER SOCKET");
		ServerSocket tmpServerSocket;
		while (!socketsToBeClosed.isEmpty())
		{			
			try{
				tmpServerSocket = (ServerSocket) socketsToBeClosed.firstElement();
				tmpServerSocket.close();	
				socketsToBeClosed.remove(tmpServerSocket);
			}catch(IOException e){}			
		}					
	}
	
	
	
	/**
	 * Creates the server socket and initializes it with appropriate defaults.
	 */
	static private void initServer(int portNumber, int connectAttempts, int sleepInterval) throws IOException
	{
		boolean connected = false;
		int attempts = 0;	
		
		while (!connected)
		{
			try
			{
				serverSocket = new ServerSocket(portNumber);		
				serverSocket.setSoTimeout(5000);  //timeout to check if should be listening, workaround to JDK bug		
				connected = true;
			} catch (IOException excp)
			{
				if (++attempts == connectAttempts)
					throw excp;
				else
					try
					{
						Thread.sleep(sleepInterval, 0);
					} catch (InterruptedException excp2)
					{}
			}
		}

	}	
	
	/**
	 * Listens on the socket, timing out periodically to check if it should continue to listen (workaround to JDK bug)
	 * Will close the server socket if it should not continue.
	 * Creates a new DaemonSocketConnection if a connection request is received.
	 */
	static private DaemonSocketConnection connectToClient() throws IOException
	{
		Socket tmpSocket=null;
				
		while(socketsToBeClosed.isEmpty() && tmpSocket == null)  //check flag to know when to stop
		{
	//		System.out.println("GOING INTO ACCEPT");
			try{
				tmpSocket = serverSocket.accept();		
			}catch(InterruptedIOException e){//ignore timeout exception
			}
		}
	//	System.out.println("Fell out of loop");
		if(!socketsToBeClosed.isEmpty())  //check the flag and close if done listening
			CoreDaemon.closeServerSocket();
						
		if(tmpSocket == null)
			return null;
			
		return new DaemonSocketConnection(tmpSocket);		
	}
	
	
	
	/** This method will listen for and establish a socket connection.
	 *  It will then read in the version number and act accordingly.
	 * If all goes well, it will have found a launcher or a debug target and will pass the input along
	 * to it for interpretation.  If errors occur, for positive versions, it logs the error
	 * and does nothing (the engine/kicker will have already closed the socket).  For negative
	 * versions, it will log the error, write an error to the socket, and close the socket connection.
	 */
	private void readAndProcessRequest(DaemonSocketConnection connection) throws IOException
	{	
		DebugDaemonPlugin.logText("Connection request received!",DebugDaemonPlugin.DBG,null);
		
		int version = connection.beginRead();
		DebugDaemonPlugin.logText("Version: "+version,DebugDaemonPlugin.DBG,null);
		if (version == -1 || version < -2)
		{ //return error - beta only, unsupported version
			DebugDaemonPlugin.displayError("UnsupportedVersion.title", "UnsupportedVersion.message");
			DebugDaemonPlugin.logText("Unsupported version: "+version,DebugDaemonPlugin.ERR,null);
			return;				
		}

		ILauncher launcher=null;
		ILauncherDelegate launcherDelegate = null;
		try
		{
			InputStream inputStream = connection.getInputStream();			

			if (version > -1)
			{
				//use default launcher (if load instead of attach, launcher will switch launchers)
				DebugDaemonPlugin.logText("Using default launcher com.ibm.debug.OldDaemonDefaultLauncher",DebugDaemonPlugin.DBG,null);				
				launcher = findLauncher("com.ibm.debug.OldDaemonDefaultLauncher");
				if(launcher == null)
				{					
					DebugDaemonPlugin.displayError("DefaultLauncherNotFound.title", "DefaultLauncherNotFound.message");
					DebugDaemonPlugin.logText("Launcher com.ibm.debug.OldDaemonDefaultLauncher not found",DebugDaemonPlugin.ERR,null);
					return; 
				}
				launcherDelegate = launcher.getDelegate();

				if (launcherDelegate == null)  //default launcher not found
				{					
					DebugDaemonPlugin.displayError("DefaultLauncherNotFound.title", "DefaultLauncherNotFound.message");
					DebugDaemonPlugin.logText("Launcher com.ibm.debug.OldDaemonDefaultLauncher not found",DebugDaemonPlugin.ERR,null);
					return;  //todo: prompt user for launcher
				}
				else if(!(launcherDelegate instanceof IOldDaemonSupport))
				{
					DebugDaemonPlugin.displayError("LauncherNotIOldDaemonSupport.title", "LauncherNotIOldDaemonSupport.message");
					DebugDaemonPlugin.logText("Specified launch configuration does not support IOldDaemonSupport ",DebugDaemonPlugin.ERR,null);
					//todo: prompt for launch config
					writeErrorToSocket(-1, connection);
					connection.close();
				}
				String[] input = readOldStyleStrings(inputStream, version);
				((IOldDaemonSupport) launcherDelegate).setInputParametersAsStrings(
						input,
						0,  //no key yet
						version);
			} else if(version==-2)//"new" format, read launcher (and other params) off stream and instantiate, passing in socket
			{
				NameValuePair[] pairs = readNameValuePairs(inputStream);
				int key = findKey(pairs);
				if (key > 0) //engine has provided key, therefore lookup debug target and let it take over
				{
					IDaemonDebugTarget debugTarget = (IDaemonDebugTarget) retrieveDebugTarget(key);
					if (debugTarget != null) //key was valid and debug target located
					{
						DebugDaemonPlugin.logText("Target found and notified of connection",DebugDaemonPlugin.DBG,null);
						debugTarget.engineIsWaiting(connection, null); 
						//todo! writeReturnCodeToSocket(1, connection);					
						return;
					}
					else 
					{
						DebugDaemonPlugin.logText("Target not found-invalid key specified",DebugDaemonPlugin.ERR,null);
						DebugDaemonPlugin.displayError("InvalidKey.title", "InvalidKey.message");
						writeErrorToSocket(-3, connection);
						connection.close();
						return;						
					}
				}

				launcher = findLauncher(findLauncherID(pairs));
				launcherDelegate = launcher.getDelegate();

				if (launcherDelegate == null)
				{
					DebugDaemonPlugin.displayError("LauncherNotFound.title", "LauncherNotFound.message");
					DebugDaemonPlugin.logText("Specified launch configuration not found "+findLauncherID(pairs),DebugDaemonPlugin.ERR,null);
					//todo: prompt for launch config
					writeErrorToSocket(-1, connection);
					connection.close();
					return;				
				}
				else if(!(launcherDelegate instanceof IDaemonSupport))
				{
					DebugDaemonPlugin.displayError("LauncherNotIDaemonSupport.title", "LauncherNotIDaemonSupport.message");
					DebugDaemonPlugin.logText("Specified launch configuration not found "+findLauncherID(pairs),DebugDaemonPlugin.ERR,null);
					//todo: prompt for launch config
					writeErrorToSocket(-3, connection);
					connection.close();
				}
				key = generateKey();
				writeKeyToSocket(key, connection);
				((IDaemonSupport) launcherDelegate).setConnectionInfo(
					findXMLValue(pairs),
					key,
					version);

			}
			connection.endRead();
		} catch (IOException e)
		{
			try{
				if (version < 0)  //positive versions do not have an open socket
				{
					writeErrorToSocket(-2, connection);	
					connection.close();			          
				}
			}catch(Exception exception){}
			throw e;
		}
		//pass socket to launcher		
		if (launcherDelegate instanceof IDaemonSupport)			
			 ((IDaemonSupport) launcherDelegate).setSocket(connection);
		else if (launcherDelegate instanceof IOldDaemonSupport)
			 ((IOldDaemonSupport) launcherDelegate).setSocket(connection);

		//find current selection  ---temp fix until project not required for launch	
		Object[] resource = new Object[1];
		resource[0] = ResourcesPlugin.getWorkspace().getRoot();
		IProject projects[] = ((IWorkspaceRoot) resource[0]).getProjects();
		if (projects != null && projects.length > 0 && projects[0] != null)
			resource[0] = projects[0];
		else 
		{
			DebugDaemonPlugin.displayError("ProjectNotSelected.title", "ProjectNotSelected.message");			
			DebugDaemonPlugin.logText("Must be a project in the workspace for launch to succeed",DebugDaemonPlugin.ERR,null);
			return;
		}
		DebugDaemonPlugin.logText("Telling LauncherDelegate to launch",DebugDaemonPlugin.DBG,null);
		launcherDelegate.launch(resource, ILaunchManager.DEBUG_MODE, launcher);
	}
	/**
	 * Generates a unique key to identify this connection.  Should be passed back to the engine if a
	 * launcher wants to store a debug target in the hashtable or an engine wants the daemon to retrieve
	 * the target from the hashtable.
	 * @see storeDebugTarget
	 * @see retrieveDebugTarget
	 */
	public static int generateKey()
	{
		//wrap if max int reached (unlikely)		
		if (currentKey == Integer.MAX_VALUE)
		{
			DebugDaemonPlugin.logText("Key generator wrapped because MAX_VALUE reached",DebugDaemonPlugin.DBG,null);
			currentKey = 1;
		}
		else
			currentKey++;
		return currentKey;
	}

	/**
	 * Used by a launch configuration to store a debug target in the hashtable for future use.
	 * @param key the index into the hashtable (originally generated by the daemon)
	 * @param target the target that should be stored in the hashtable
	 * @see retrieveDebugTarget
	 * @see removeDebugTarget
	 */
	public static void storeDebugTarget(IDebugTarget target, int key)
	{
		targetHashtable.put(new Integer(key), target);
		DebugDaemonPlugin.logText("Target stored in hashtable, key="+key,DebugDaemonPlugin.DBG,null);
	}

	/**
	 * Removes the debug target from the hashtable when a reference to it is no longer needed.
	 * @param key the index into the hashtable (originally generated by the daemon)
	 * @see storeDebugTarget
	 * @see retrieveDebugTarget
	 */
	public static void removeDebugTarget(int key)
	{
		targetHashtable.remove(new Integer(key));
		DebugDaemonPlugin.logText("Target removed from hashtable, key="+key,DebugDaemonPlugin.DBG,null);
	}

	/**
	 * Returns the debug target stored in the hashtable using the key.
	 * Due to timing issue, target may not be stored in hashtable when request comes in -
	 * therefore will try intermittently for 60 seconds before returning if target not found immediately.
	 * @param key the index into the hashtable (originally generated by the daemon)
	 * @see removeDebugTarget
	 * @see storeDebugTarget
	 */
	static public IDebugTarget retrieveDebugTarget(int key)
	{
		IDebugTarget target = (IDebugTarget) (targetHashtable.get(new Integer(key)));
		int repeated = 0;
		while (target == null && repeated < 6) //wait no longer than 60 seconds
		{
			try
			{
				Thread.sleep(10000); //todo: sleep to avoid timing problem;
			} catch (InterruptedException e)
			{}
			repeated++;
			target = (IDebugTarget) (targetHashtable.get(new Integer(key)));			
		}
		if(target !=null)
			DebugDaemonPlugin.logText("Target retrieved from hashtable, key="+key,DebugDaemonPlugin.DBG,null);
		else DebugDaemonPlugin.logText("Target NOT FOUND in hashtable, key="+key,DebugDaemonPlugin.ERR,null);
		
		return target;
	}

	/**
	 * Returns the bytes of XML that were sent over the socket connection.
	 * @param the array of NameValuePairs that were sent over the socket.
	 * @see NameValuePairs
	 */
	static private byte[] findXMLValue(NameValuePair[] pairs)
	{
		for (int i = 0; i < pairs.length; i++)
			if (pairs[i].getName().equalsIgnoreCase("XML"))
				return pairs[i].getValueArray();
		return null;
	}

	/**
	 * Returns the key, if sent to the daemon by the engine. Returns -1 if not found.
	 * @param int the key that was sent over the socket.
	 * @see NameValuePairs
	 */
	static private int findKey(NameValuePair[] pairs)
	{
		for (int i = 0; i < pairs.length; i++)
			if (pairs[i].getName().equalsIgnoreCase("Key"))
				return Integer.parseInt(pairs[i].getValue());
		return -1;
	}
	
	static private boolean isKickerConnection(NameValuePair[] pairs)
	{
		for (int i = 0; i < pairs.length; i++)
			if (pairs[i].getName().equalsIgnoreCase("Kicker")  && pairs[i].getValue().equalsIgnoreCase("true") )
				return true;					
		return false;
	}

	static private ILauncher findLauncher(String id)
	{
		ILauncher[] registeredLaunchers =
			DebugPlugin.getDefault().getLaunchManager().getLaunchers();
		if(registeredLaunchers == null) return null;
		for (int i = 0; i < registeredLaunchers.length; i++)
		{
			if (registeredLaunchers[i].getIdentifier().equals(id))
				return registeredLaunchers[i];
			//the launcher associated with the delegate		   		         		      		
		}

		return null;
	}

	/**
	 * Find the launcher ID pair and returns the ID.
	 * Returns null if not found.
	 */
	static private String findLauncherID(NameValuePair[] pairs)
	{
		for (int i = 0; i < pairs.length; i++)
			if (pairs[i].getName().equalsIgnoreCase("LaunchConfigTypeID"))
				return pairs[i].getValue();
		return null;
	}

	/**
	 * Read in name value pairs from the socket.  Used for all versions -2 and lower.
	 * This is the only style that should be used by new implementations.
	 * @param inputStream the input stream from the incoming socket connection.
	 */
	private NameValuePair[] readNameValuePairs(InputStream inputStream)
	{
		DataInputStream dataStream = new DataInputStream(inputStream);

		int length;
		String name;
		String value;
		byte[] valueArray;
		byte[] nameArray;

		try
		{
			int numPairs = dataStream.readInt();

			NameValuePair[] pairs = new NameValuePair[numPairs];
			for (int i = 0; i < numPairs; i++)
			{
				//read name length (in bytes)
				length = dataStream.readInt(); 
				nameArray = new byte[length];
				//read name
				dataStream.read(nameArray, 0, length);
				name = new String(nameArray, "UTF-8");
				
				//read value length (in bytes)  			
				length = dataStream.readInt();
				valueArray = new byte[length];
				//read value 		
				dataStream.read(valueArray, 0, length);
				value = new String(valueArray, "UTF-8");
				//store name/value pair in array 
				pairs[i] = new NameValuePair(name, value, valueArray);
				DebugDaemonPlugin.logText("Read pair from stream: name="+name+" value="+value,DebugDaemonPlugin.DBG,null);
			}
			return pairs;

		} catch (IOException e)
		{ DebugDaemonPlugin.logText("Exception reading pairs from stream:"+e.getMessage(),DebugDaemonPlugin.DBG,e);}
		return null;
	}
	
	
	static private String[] readOldStyleStrings(InputStream inputStream, int version)
	{
		//older version (positive numbered versions)
		//format is: host, conduit, title, # parms to follow, parms
		//read as strings and let the launcher figure out which is which
		int argCount = 0;
		boolean readNull = false;
		String buffer[] = new String[1];
		String input[] = new String[5]; //array of all strings read in
		try
		{
			for (int i = 0; i <= 3; i++)
			{
				//DT does not always send args, so don't block if they aren't there
				// Args 0 and 1 (host and port) must be there
				readNull = readLineOrNull(inputStream, buffer, i >= 2? true:false);
				input[i] = buffer[0];
			}
		} catch (IOException e)
		{DebugDaemonPlugin.logText("Exception reading input:"+e.getMessage(),DebugDaemonPlugin.ERR,e);}
		//read the parameters into the same buffer    	
		String argCountString = input[3];
		DebugDaemonPlugin.logText("DebugDaemon Argcount =" + argCountString,DebugDaemonPlugin.DBG,null);
		
		//no parameters
		if (argCountString == null || readNull)
			return input;

		if (argCountString.length() > 0)
		{
			try
			{
				argCount = Integer.parseInt(argCountString);
			} catch (NumberFormatException e)
			{
				DebugDaemonPlugin.logText("Invalid format for number of arguments "+e.getMessage(),DebugDaemonPlugin.ERR,e);
				return buffer;
			}
		}
		String arguments = "";
		try
		{
			while (argCount-- > 0)
			{
				arguments += " ";
				readNull = readLineOrNull(inputStream, buffer,false);
				arguments += buffer[0];
				if (readNull)
					break;
			}
		} catch (IOException e)
		{DebugDaemonPlugin.logText("Exception reading arguments:"+e.getMessage(),DebugDaemonPlugin.ERR,e);}
		DebugDaemonPlugin.logText("DebugDaemon Arguments =" + arguments,DebugDaemonPlugin.DBG,null);
		input[4] = arguments;

		return input;

	}

	static private boolean readLineOrNull(InputStream inputStream, String[] answer, boolean blockOnRead)
		throws IOException
	{
		char buffer[] = new char[1024];
		int i = 0;
		char currentByte = 0;
		try
		{	DebugDaemonPlugin.logText("Input stream bytes still available:"+inputStream.available(),DebugDaemonPlugin.DBG,null);
			
			if(blockOnRead && inputStream.available() == 0)  //DT is not giving four args like it should, return null for final two args
			{
				answer[0]=null;
				return true;
			}
			for (i = 0, currentByte = (char) inputStream.read();
					currentByte != '\n' && currentByte != '\r' && currentByte != 0;
					currentByte = (char) inputStream.read(), i++)
			{
				buffer[i] = currentByte;
			}
		} catch (IOException e)
		{DebugDaemonPlugin.logText("Error reading line from stream:"+e.getMessage(),DebugDaemonPlugin.ERR,e);}

		if (i == 0)
		{
			answer[0] = null;
		} else
		{
			answer[0] = new String(buffer, 0, i);
		}
		DebugDaemonPlugin.logText("Line read:"+answer[0],DebugDaemonPlugin.DBG,null);
		if (currentByte == 0)
			return true;
		return false;
	}

	static private void writeKeyToSocket(int key, DaemonSocketConnection connection)
	{

		try
		{
			DebugDaemonPlugin.logText("Writing key to socket: " + key,DebugDaemonPlugin.DBG,null);
			DataOutputStream outputStream =
				new DataOutputStream(connection.getOutputStreamBuffer());
			outputStream.writeInt(key);
			connection.endWrite();
		} catch (Exception e)
		{
			DebugDaemonPlugin.logText("Exception writing key to socket:"+e.getMessage(),DebugDaemonPlugin.ERR,e);
		}
	}
	
	/**
	 * Writes an error to the socket.  Can be used to write any integer to the socket in fact, including
	 * success.  Note that the method does not close the socket when done, though this should be done
	 * in most error cases.
	 * 
	 * @see DaemonSocketConnection.close()
	 *  
	 * @param errorCode-Implementations may use any code they would like.
	 * 		-1 means an invalid launcher or launch configuration was specified.
	 * 		-2 means an IOException occurred.
	 * 		-3 Invalid key was specified
	 * @param connection The daemonSocketConnection over which the code should be written
	 */
	static private void writeErrorToSocket(int errorCode, DaemonSocketConnection connection)
	{

		try
		{
			DebugDaemonPlugin.logText("Writing return code to socket:"+errorCode,DebugDaemonPlugin.DBG,null);
			DataOutputStream outputStream =
				new DataOutputStream(connection.getOutputStreamBuffer());
			outputStream.writeInt(errorCode);
			connection.endWrite();
		} catch (Exception e)
		{
			DebugDaemonPlugin.logText("Exception writing return code "+ errorCode +" to socket: "+e.getMessage(),DebugDaemonPlugin.ERR,e);
		}
	}
	/**
	 * Class used to store the name value pairs (version -1 and newer).
	 * The value is stored as a string as well as the bytes read off the stream.
	 */

	public class NameValuePair
	{
		private String name;
		private String value;
		private byte[] valueArray;

		public NameValuePair(String name, String value, byte[] valueArray)
		{
			this.name = name;
			this.value = value;
			this.valueArray = valueArray;
		}

		public String getName()
		{
			return name;
		}

		public String getValue()
		{
			return value;
		}

		public byte[] getValueArray()
		{
			return valueArray;
		}
	} //end NameValuePair

	protected class ListenerThread extends Thread
	{
		public void run()
		{
			DaemonSocketConnection socket=null;
			while (CoreDaemon.isListening)
			{			
				try
				{
					// wait for a connection  
					Socket tmpSocket=null;
				
					while(socketsToBeClosed.isEmpty() && tmpSocket == null)  //check flag to know when to stop
					{
			//			System.out.println("GOING INTO ACCEPT");
						try{
							tmpSocket = serverSocket.accept();		
						}catch(InterruptedIOException e){//ignore timeout exception
						}catch(NullPointerException e){//serverSocket was null due to timing - will fall out
							break;
						}
					}
		//			System.out.println("Fell out of loop");
					if(!socketsToBeClosed.isEmpty())  //check the flag and close if done listening
						CoreDaemon.closeServerSocket();
						
					if(tmpSocket != null)
						socket= new DaemonSocketConnection(tmpSocket);	
					else continue;
					
								
				}catch (IOException e){
					DebugDaemonPlugin.logText(e.getMessage(),DebugDaemonPlugin.ERR,e);				
				} 
				
				//read input from socket
				try{
					readAndProcessRequest(socket);
				}catch (NullPointerException e){
					DebugDaemonPlugin.logText(e.getMessage(),DebugDaemonPlugin.ERR,e);				
				}catch(IOException e){
					DebugDaemonPlugin.logText(e.getMessage(),DebugDaemonPlugin.ERR,e);
				}
			} //end while	
		//	System.out.println("***********End RUN");
			
		} //end run
		
	}
}