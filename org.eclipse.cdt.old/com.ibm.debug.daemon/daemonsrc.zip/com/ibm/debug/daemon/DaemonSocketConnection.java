package com.ibm.debug.daemon;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */



import java.net.*;
import java.io.*;

/**
 *  Represents an individual socket connection from an engine or kicker to the daemon.
 */

public class DaemonSocketConnection
{
	private Socket socket;
	private OutputStream _outputStream;
	protected InputStream _inputStream;
	protected ByteArrayOutputStream _outputStreamBuffer = new ByteArrayOutputStream();
	//if the connection is from a kicker; if false, connection is from engine
	private boolean isKicker; 	
		
	public DaemonSocketConnection(Socket socket)
	{
		this.socket=socket;
		try{
			setOutputStream(socket.getOutputStream());
			setInputStream(socket.getInputStream());
		}catch(IOException e){}
	}
	
	public DaemonSocketConnection(Socket socket, boolean kicker)
	{
		isKicker=kicker;
		this.socket=socket;
		try{
			setOutputStream(socket.getOutputStream());
			setInputStream(socket.getInputStream());
		}catch(IOException e){}
		
	}
	

	public void close() throws IOException
	{
		flush();
		if (socket != null)
			socket.close();		//disconnect from client			
	}
	
	
	
	/**
	 * Get the buffered output stream used
	 */
	final public ByteArrayOutputStream getOutputStreamBuffer()
	{
		return _outputStreamBuffer;
	}

	final public InputStream getInputStream()
	{
		return _inputStream;
	}

	/** Set the output stream that clients should use when sending data
	 *  via this connection. This method should generally only be called from a
	 *  subclass.
	 */

	protected void setOutputStream(OutputStream outputStream)
	{
		try
		{
			flush();
		} catch (IOException ex)
		{}
		_outputStream = outputStream;
	}

	/** Set the input stream that clients should use when reading data
	 *  from this connection. This method should generally only be called from a
	 *  subclass.
	 */

	protected void setInputStream(InputStream inputStream)
	{
		_inputStream = inputStream;
	}

	/** 
	 * Packet is prefixed by its length.
	 */
	public int beginRead() throws IOException
	{
		DataInputStream dataStream = new DataInputStream(_inputStream);
		return dataStream.readInt();
	}

	/**
	 * Write out the packet size
	 */
	/*public void beginWrite(int packetSize) throws IOException
	{
		new DataOutputStream(_outputStreamBuffer).writeInt(packetSize);
	}*/
		
	/**
	 * Called after the reading of the input stream to allow the appropriate
	 * clean up.
	 */
	public void endRead() throws IOException
	{}

	/**
	 * Called after writing of the output stream to allow the appropriate
	 * clean up.
	 */
	public void endWrite() throws IOException
	{
		flush();
	}
			
	/**
	 *  Flush the output stream buffer to the actual output stream.
	 *  Data in the output stream buffer is not sent until the stream is flushed.
	 */
	public void flush() throws IOException
	{
		// make sure we have an output stream and data to write
		if (_outputStream != null && _outputStreamBuffer.size() > 0)
			_outputStream.write(_outputStreamBuffer.toByteArray());
		_outputStreamBuffer.reset();
	}
}