package com.ibm.debug.daemon;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */



import java.net.*;
import java.io.*;

/** Establish a connection between daemon and the debug engine using a socket.
 */

public class DaemonSocketConnection
{
	private Socket socket;
	private ServerSocket serverSocket;
	private int connectAttempts = 100;
	private int sleepInterval = 500;
	private OutputStream _outputStream;
	protected InputStream _inputStream;
	protected ByteArrayOutputStream _outputStreamBuffer = new ByteArrayOutputStream();
	private static ServerSocket _serverSocket;
	protected static final int TCPIP = 1;

	public DaemonSocketConnection(String host, String portAsString)
		throws IOException
	{
		init(host, portAsString);
	}
	public DaemonSocketConnection(
		String host,
		String portAsString,
		int connectAttempts,
		int sleepInterval)
		throws IOException
	{
		this.connectAttempts = connectAttempts;
		this.sleepInterval = sleepInterval;	
		init(host, portAsString);
	}

	public DaemonSocketConnection(Socket socket) throws IOException
	{
	//	mode = AS_CLIENT;
		this.socket = socket;
		setOutputStream(socket.getOutputStream());
		setInputStream(socket.getInputStream());
	}

	/**
	 * Makes a clone of itself and then clears the current
	 * socket.  If there is no socket it returns null.
	 * Used to break off the current socket connection for
	 * use elsewhere while this connection can continue to
	 * listen for new connections.
	 * @returns A clone of this socket connection or null if
	 *          there is currently no socket.
	 */
	public DaemonSocketConnection cloneConnectionAndClear() throws IOException
	{
		DaemonSocketConnection clone = null;
		
		if (socket != null)
		{
			clone = new DaemonSocketConnection(socket);
			socket = null;
			setOutputStream(null);
			setInputStream(null);
		}

		return clone;
	}

	/** Packet is prefixed by its length.
	 */
	public int beginRead() throws IOException
	{
		DataInputStream dataStream = new DataInputStream(_inputStream);
		return dataStream.readInt();
	}

	/**
	 * Write out the packet size
	 */
	public void beginWrite(int packetSize) throws IOException
	{
		new DataOutputStream(_outputStreamBuffer).writeInt(packetSize);
	}

	public void close() throws IOException
	{
		flush();
		disconnectFromClient();

		/*if (mode == AS_CLIENT)
		{
			if (socket != null)
			{
				socket.close();
				super.setOutputStream(null);
				super.setInputStream(null);				
				socket = null;
			}
		} else
		{*/
			if (serverSocket != null)
			{			
				serverSocket.close();				
				serverSocket = null;
			}			
		//}
	}
	public int communicationType()
	{
		return TCPIP;
	}
	public void connectToClient() throws IOException
	{
		socket = serverSocket.accept();
		setOutputStream(socket.getOutputStream());
		setInputStream(socket.getInputStream());
	//	serverSocket.close();
	//	socket.close();
	//	serverSocket = new ServerSocket(8001);
	//	socket = serverSocket.accept();
	}
	/**
	 * Terminate the socket connection.
	 */
	public void disconnectFromClient() throws IOException
	{
		if (socket != null)
			socket.close();
	}
	private void init(String host, String portAsString) throws IOException
	{
		int port;
		try
		{
			port = Integer.parseInt(portAsString);
		} catch (NumberFormatException e)
		{
			DebugDaemonPlugin.logText(
				"Socket port " + portAsString + " is not an integer: " + e.getMessage(),
				DebugDaemonPlugin.ERR,
				e);
			throw new IOException("Socket port not an integer:" + portAsString);
		}		
		initServer(port);
	}
	
	private void initServer(int portNumber) throws IOException
	{
		boolean connected = false;
		int attempts = 0;

		while (!connected)
		{
			try
			{
				serverSocket = new ServerSocket(portNumber);				
				connected = true;
			} catch (IOException excp)
			{
				if (++attempts == connectAttempts)
					throw excp;
				else
					try
					{
						Thread.sleep(sleepInterval, 0);
					} catch (InterruptedException excp2)
					{}
			}
		}

	}
	/**
	 * Get the buffered output stream used
	 */
	final public ByteArrayOutputStream getOutputStreamBuffer()
	{
		return _outputStreamBuffer;
	}

	final public InputStream getInputStream()
	{
		return _inputStream;
	}

	/** Set the output stream that clients should use when sending data
	 *  via this connection. This method should generally only be called from a
	 *  subclass.
	 */

	protected void setOutputStream(OutputStream outputStream)
	{
		try
		{
			flush();
		} catch (IOException ex)
		{}
		_outputStream = outputStream;
	}

	/** Set the input stream that clients should use when reading data
	 *  from this connection. This method should generally only be called from a
	 *  subclass.
	 */

	protected void setInputStream(InputStream inputStream)
	{
		_inputStream = inputStream;
	}

		
	/**
	 * Called after the reading of the input stream to allow the appropriate
	 * clean up.
	 */
	public void endRead() throws IOException
	{}

	/**
	 * Called after writing of the output stream to allow the appropriate
	 * clean up.
	 */
	public void endWrite() throws IOException
	{
		flush();
	}
			
	/**
	 *  Flush the output stream buffer to the actual output stream.
	 *  Data in the output stream buffer is not sent until the stream is flushed.
	 */
	public void flush() throws IOException
	{
		// make sure we have an output stream and data to write
		if (_outputStream != null && _outputStreamBuffer.size() > 0)
			_outputStream.write(_outputStreamBuffer.toByteArray());
		_outputStreamBuffer.reset();
	}
}