package com.ibm.debug.daemon;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.internal.plugins.PluginDescriptor;


/**
 * This class serves as a location for utility methods for the daemon.
 */
public class DaemonUtils {

	/**
	 * The resource bundle within which all daemon resource Strings are held
	 */
	private static ResourceBundle fgResourceBundle;
	/**
	 * The resource bundle within which all daemon help id Strings are held
	 */
	private static ResourceBundle helpResourceBundle;
	
	private static String modelIdentifier = "com.ibm.debug.daemon";
	

	/**
	 * Retrieve the requested String resource.  Practice lazy retrieval on the resource bundle.
	 */
	public static String getResourceString(String key) {
		if (fgResourceBundle == null) {
			fgResourceBundle= getResourceBundle();
		}
		if (fgResourceBundle != null) {
			return fgResourceBundle.getString(key);
		} else {
			return "!" + key + "!";
		}
	}

	/**
	 * Retrieve the requested help id.  Practice lazy retrieval on the resource bundle.
	 */
	public static String getHelpResourceString(String key) {
		if (helpResourceBundle == null) {
			helpResourceBundle= getHelpResourceBundle();
		}
		if (helpResourceBundle != null) {
			return helpResourceBundle.getString(key);
		} else {
			return "!" + key + "!";
		}
	}

	/**
	 * Plug in the single argument to the resource String for the key to get a formatted resource String
	 */
	public static String getFormattedString(String key, String arg) {
		String string= getResourceString(key);
		return MessageFormat.format(string, new String[] { arg });
	}

	/**
	 * Plug in the arguments to the resource String for the key to get a formatted resource String
	 */
	public static String getFormattedString(String key, String[] args) {
		String string= getResourceString(key);
		return MessageFormat.format(string, args);
	}

	/**
	 * Returns the resource bundle used by all parts of the debug ui package.
	 */
	public static ResourceBundle getResourceBundle() {
		try {
			return ResourceBundle.getBundle("com.ibm.debug.daemon.DaemonResources");
		} catch (MissingResourceException e) {
		}
		return null;
	}

	/**
	 * Returns the resource bundle used by all parts of the debug ui package.
	 */
	public static ResourceBundle getHelpResourceBundle() {
		try {
			return ResourceBundle.getBundle("com.ibm.debug.internal.pdt.ui.util.HelpResources");
		} catch (MissingResourceException e) {
		}
		return null;
	}

	/**
	 * Returns a string that is used to identify this plugin.
	 */

	public static String getModelIdentifier() {
		return modelIdentifier;
	}	

		
	/**
	 * Returns a String that is the current path to the this plugin's directory
	 * This is more accurate that asking the plugin directly since it seems to always give back "plugin"
	 * @return a string that contains the full path to the debugger's plugin directory
	 */
	public static String getPluginPath() {
		return ((PluginDescriptor)DebugDaemonPlugin.getInstance().getDescriptor()).getInstallURLInternal().getPath();
	}
}
