package com.ibm.debug.daemon;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.debug.core.ILauncher;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * Represents the Daemon plugin
 */
public class DebugDaemonPlugin extends AbstractUIPlugin
{

	public final static String DAEMON_PORT = "DaemonPort";
	private final static String PLUGIN = "DebugDaemonPlugin";

	private static DebugDaemonPlugin instance;
	
	private static IPluginDescriptor fPluginDescriptor = null;
	
	private static ILog logFile; 
	private static boolean err = false;
	private static boolean dbg = false;
	//trace level
	public final static int DBG=0;
	public final static int ERR=1;
	

	/**
	 * Constructor for DebugDaemonPlugin
	 */
	public DebugDaemonPlugin(IPluginDescriptor descriptor)
	{
		super(descriptor);
		instance = this;
		
		fPluginDescriptor = getDescriptor();
		if (isDebugging()) {  
			String id = fPluginDescriptor.getUniqueIdentifier();
			String test = Platform.getDebugOption(id + "/debug/err");
			if (test != null)
				err = test.equals("true");				
			test = Platform.getDebugOption(id + "/debug/dbg");
			if (test != null)
				dbg = test.equals("true");
				
		}
		
		logFile = getLog();
		
		logText("Plugin has been initialized",DBG, null);
				
	}

	public static String getPluginID()
	{
		return fPluginDescriptor.getUniqueIdentifier();
	}

	public static DebugDaemonPlugin getInstance()
	{
		return instance;
	}

	public static DebugDaemonPlugin getDefault()
	{
		return instance;
	}

	public void startup() throws CoreException
	{
		super.startup();
	}

	/**
	 * @see Plugin#shutdown()
	 */
	public void shutdown() throws CoreException
	{
		CoreDaemon.getInstance().stopListening();
		super.shutdown();
	}

	public static IWorkbenchWindow getActiveWorkbenchWindow()
	{
		return getDefault().getWorkbench().getActiveWorkbenchWindow();
	}

	/**
	 * Returns the active workbench shell.
	 * Note: This method should only be called from a UI thread.
	 * When running on a non-UI thread, use getShell() method.
	 */
	public static Shell getActiveWorkbenchShell()
	{
		return getActiveWorkbenchWindow().getShell();
	}

	/**
	 * @see AbstractUIPlugin#initializeDefaultPreferences
	 */
	public void initializeDefaultPreferences(IPreferenceStore store)
	{
		store.setDefault(DAEMON_PORT, CoreDaemon._defaultPort);
	}

	/**
	* Terminate the debug engine.  This is used when the engine was
	* started by the user but hit cancel in the startup wizard.
	* @param connectionKey Key for retrieving the engine connection info.
	*		        Must be the same key that was passed to
	*                      either the wizard or launcher.  If connectionKey
	*                      is not valid, terminateEngine does nothing.
	*/
	public static void terminateEngine(int connectionKey)
	{

		/*todo if(connectionKey instanceof ConnectionInfo) {
			DebugUIDaemon.terminateEngine((ConnectionInfo)connectionKey);
		}*/
	}
	
	
	/**
		* Debug ui thread safe access to a shell
		*/
	public Shell getShell()
	{
		IWorkbench workbench = getWorkbench();
		if (workbench != null)
		{
			IWorkbenchWindow[] windows = workbench.getWorkbenchWindows();

			if (windows != null && windows.length > 0)
			{
				Shell shell = windows[0].getShell();
				if (!shell.isDisposed())
				{
					return shell;
				}
			}
		}
		return null;
	}

	/**
	  * Debug ui thread safe access to a display
	  */
	public Display getDisplay()
	{
		Shell shell = getShell();
		if (shell != null)
			return shell.getDisplay();

		return null;
	}

	
	/**To be used when daemon not on UI thread */
	protected static void displayError(String titleCode, String msgCode)
	{
		final String title = DaemonUtils.getResourceString(titleCode);
		final String msg = DaemonUtils.getResourceString(msgCode);
		//Shell shell=DebugDaemonPlugin.getActiveWorkbenchShell();
		//if(shell == null)
		final Shell shell= DebugDaemonPlugin.getInstance().getShell();
		
		shell.getDisplay().syncExec(new Runnable() {
					public void run() {
						MessageDialog.openError(
										shell,
										title,
										msg);
					}
				});
		
		
	}
	
	/**
	 * If tracing is enabled, logs the text to the file and prints to the console.
	 * @param text The text to be logged.
	 * @param level Must be either DebugDaemonPlugin.EVT or DebugDaemonPlugin.DBG.
	 * @param e exception or null if none
	 */
	public static void logText(String text, int level, Exception e) {
			if ((err && level == ERR) || (dbg && level==DBG)) {
				if(text == null) //Assertion will fail if null
				{
					if(e != null)
						text = e.getMessage();
					if(text == null)
						text = "";  
				}
				Status sts = new Status(IStatus.INFO,
								DebugDaemonPlugin.getPluginID(),
								IStatus.OK,
								text,
								e);
				logFile.log(sts);
				System.out.println(text);   
			}
		}

}