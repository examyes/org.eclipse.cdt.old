package com.ibm.debug.daemon;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.core.ILauncher;
import org.eclipse.debug.core.Launch;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * Represents the Daemon plugin
 */
public class DebugDaemonPlugin extends AbstractUIPlugin
{

	public final static String DAEMON_PORT = "DaemonPort";
	public final static String DEFAULT_LAUNCH_CONFIG= "DefaultLaunchConfig";
	private final static String PLUGIN = "DebugDaemonPlugin";

	private static DebugDaemonPlugin instance;

	private static DebugUIDaemon daemon = null;

	private static IPluginDescriptor fPluginDescriptor = null;
	
	private static ILog logFile; 
	private static boolean err = false;
	private static boolean dbg = false;
	//trace level
	public final static int DBG=0;
	public final static int ERR=1;
	

	/**
	 * Constructor for DebugDaemonPlugin
	 */
	public DebugDaemonPlugin(IPluginDescriptor descriptor)
	{
		super(descriptor);
		instance = this;
		
		fPluginDescriptor = getDescriptor();
		if (isDebugging()) {  
			String id = fPluginDescriptor.getUniqueIdentifier();
			String test = Platform.getDebugOption(id + "/debug/err");
			if (test != null)
				err = test.equals("true");				
			test = Platform.getDebugOption(id + "/debug/dbg");
			if (test != null)
				dbg = test.equals("true");
				
		}
		
		logFile = getLog();
		
		logText("Plugin has been initialized",DBG, null);
	}

	public static String getPluginID()
	{
		return fPluginDescriptor.getUniqueIdentifier();
	}

	public static DebugDaemonPlugin getInstance()
	{
		return instance;
	}

	public static DebugDaemonPlugin getDefault()
	{
		return instance;
	}

	public void startup() throws CoreException
	{
		super.startup();
	}

	/**
	 * @see Plugin#shutdown()
	 */
	public void shutdown() throws CoreException
	{
		super.shutdown();
	}

	public static IWorkbenchWindow getActiveWorkbenchWindow()
	{
		return getDefault().getWorkbench().getActiveWorkbenchWindow();
	}

	/**
	 * Returns the active workbench shell.
	 * Note: This method should only be called from a UI thread.
	 * When running on a non-UI thread, use getShell() method.
	 */
	public static Shell getActiveWorkbenchShell()
	{
		return getActiveWorkbenchWindow().getShell();
	}

	/**
	 * @see AbstractUIPlugin#initializeDefaultPreferences
	 */
	public void initializeDefaultPreferences(IPreferenceStore store)
	{
		store.setDefault(DAEMON_PORT, CoreDaemon._defaultPort);
	}

	/**
	* Terminate the debug engine.  This is used when the engine was
	* started by the user but hit cancel in the startup wizard.
	* @param connectionKey Key for retrieving the engine connection info.
	*		        Must be the same key that was passed to
	*                      either the wizard or launcher.  If connectionKey
	*                      is not valid, terminateEngine does nothing.
	*/
	public static void terminateEngine(int connectionKey)
	{

		/*todo if(connectionKey instanceof ConnectionInfo) {
			DebugUIDaemon.terminateEngine((ConnectionInfo)connectionKey);
		}*/
	}

	/**
	 * Launch a PICL UI Daemon.  This is for launching the daemon
	 * independant of an engine launch.  This is for PICL Debug Plugin
	 * internal use only.
	 */
	public static boolean launchDaemon(ILauncher launcher, Object resource)
	{
		if (daemon == null || daemon.isTerminated())
		{
			daemon = new DebugUIDaemon(launcher, resource);
			if (daemon.isTerminated())
			{
				displayError("DaemonFailedToStart.title", "DaemonFailedToStart.message");
				return false;
			}
			if (!(resource instanceof IResource))
			{
				IProject projects[] = ResourcesPlugin.getWorkspace().getRoot().getProjects();
				if (projects.length > 0)
					resource = projects[0];
			}
			ILaunch launch =
				new Launch(launcher, ILaunchManager.DEBUG_MODE, resource, null, null, daemon);
			DebugPlugin.getDefault().getLaunchManager().registerLaunch(launch);
		}
		return true;
	}

	/*protected static synchronized PICLDaemonInfo generateDaemonInfo(PICLStartupInfo startupInfo) {
		int key;
		if(freeInfoKeyList.size() == 0) {
			key = infoList.size();
			infoList.addElement(startupInfo);
		}
		else {
			key = ((Integer)freeInfoKeyList.elementAt(0)).intValue();
			infoList.setElementAt(startupInfo, key);
			freeInfoKeyList.removeElementAt(0);
		}
	
		PICLDaemonInfo daemonInfo = new PICLDaemonInfo(key, daemon.getPort());
		return daemonInfo;
		
		
	}
	*/
	
	/**
	 * Returns whether the given launcher should be visible in the UI.
	 * If a launcher is not visible, it will not appear
	 * in the UI - i.e. not as a default launcher, not in the run/debug
	 * drop downs, and not in the launch history.
	 * Based on the public attribute.
	 */
	public boolean isVisible(ILauncher launcher)
	{
		IConfigurationElement e = launcher.getConfigurationElement();
		String publc = e.getAttribute("public");
		if (publc == null || publc.equals("true"))
		{
			return true;
		}
		return false;
	}

	/**
		* Debug ui thread safe access to a shell
		*/
	public Shell getShell()
	{
		IWorkbench workbench = getWorkbench();
		if (workbench != null)
		{
			IWorkbenchWindow[] windows = workbench.getWorkbenchWindows();

			if (windows != null && windows.length > 0)
			{
				Shell shell = windows[0].getShell();
				if (!shell.isDisposed())
				{
					return shell;
				}
			}
		}
		return null;
	}

	/**
	  * Debug ui thread safe access to a display
	  */
	public Display getDisplay()
	{
		Shell shell = getShell();
		if (shell != null)
			return shell.getDisplay();

		return null;
	}

	/**
	 * Returns whether the given launcher specifies a wizard.
	 */
	public boolean hasWizard(ILauncher launcher)
	{
		IConfigurationElement e = launcher.getConfigurationElement();
		return e.getAttribute("wizard") != null;
	}

	/**To be used when daemon not on UI thread */
	protected static void displayError(String titleCode, String msgCode)
	{
		final String title = DaemonUtils.getResourceString(titleCode);
		final String msg = DaemonUtils.getResourceString(msgCode);
		//Shell shell=DebugDaemonPlugin.getActiveWorkbenchShell();
		//if(shell == null)
		final Shell shell= DebugDaemonPlugin.getInstance().getShell();
		
		shell.getDisplay().syncExec(new Runnable() {
					public void run() {
						MessageDialog.openError(
										shell,
										title,
										msg);
					}
				});
		
		
	}
	
	/**
	 * If tracing is enabled, logs the text to the file and prints to the console.
	 * @param text The text to be logged.
	 * @param level Must be either DebugDaemonPlugin.EVT or DebugDaemonPlugin.DBG.
	 * @param e exception or null if none
	 */
	public static void logText(String text, int level, Exception e) {
			if ((err && level == ERR) || (dbg && level==DBG)) {
				if(text == null) //Assertion will fail if null
				{
					if(e != null)
						text = e.getMessage();
					if(text == null)
						text = "";  
				}
				Status sts = new Status(IStatus.INFO,
								DebugDaemonPlugin.getPluginID(),
								IStatus.OK,
								text,
								e);
				logFile.log(sts);
				System.out.println(text);   
			}
		}

}