package com.ibm.debug.daemon;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.net.InetAddress;

public class DaemonConnectionInfo
{
  private int connectAttempts;
  private boolean hasConnectAttempts = false;
  protected String host;
  protected String port;
  protected DaemonSocketConnection connection;
  protected boolean isClosed;
  
  /**
   * @param ipAddress If this argument is null, the getNewConnection method
   * will use the local host by default.
   * @param port 
   */

  public DaemonConnectionInfo(String ipAddress, String port)
  {	
     host = ipAddress;
     this.port = port;
     connection = null;
  }
  
  /**
   * @param ipAddress If this argument is null, the getNewConnection method
   * will use the local host by default.
   * @param port If this argument is null, the getNewConnection method
   * will use port 8000 by default.
   * @param connectAttempts number of connection attempts before timing out
   */
 /* public DaemonConnectionInfo(String ipAddress, String port,
							  int connectAttempts)
  {
	this(ipAddress, port);
	connectAttempts = connectAttempts;
	hasConnectAttempts = true;
  }*/

 /**
   * If the host contained in this SocketConnectionInfo object is null,
   * the getNewConnection method will use the local host by default.
   * If the port # contained in this SocketConnectionInfo object is null,
   * the getNewConnection method will use a default of 8000.
   * @param connectionMode This arg is ignored in this override of the
   * @param noWait If true and fail to connect the first try do not wait
   *               and try again.
   * getNewConnection method since socket connections can only be clients.
   */

/*  public DaemonSocketConnection getNewConnection(int connectionMode, boolean noWait)
  throws java.io.IOException
  {
	 String port = (this.port == null) ? getDefaultConduit() : this.port;

	 // We will pass "localhost" vs. InetAddress.getLocalHost() because the
	 // latter converts the localhost to an actual valid host and that will
	 // cause a problem if the user does not have a tcpip connection but
	 // still wants to debug his application using "localhost".

	 InetAddress addr = (host == null) ? InetAddress.getByName(getDefaultHost()) :
										  InetAddress.getByName(host);

         if (noWait)
                 return new DaemonSocketConnection(addr, Integer.parseInt(port), 500);
	 else if (!hasConnectAttempts)
		 return new DaemonSocketConnection(addr, Integer.parseInt(port));
	 else
		 // 500 (500ms) is the default sleep interval
		 return new DaemonSocketConnection(addr, Integer.parseInt(port),
									 connectAttempts, 500);
  }*/
  
    /**
   * The default host is "localhost".  Using "localhost" instead of the actual
   * host name avoids a network request to the name server.   This allows the
   * connection to work when there is no network
   */

  public String getDefaultHost()
  {
      return "localhost";
  }

 /* public String getDefaultConduit()
  {
    return defaultPort;
  }*/

 
  
  public void setHost(String host)
  {
    host = host;
  }

  public void setConduit(String conduit)
  {
    conduit = conduit;
  }

  public String getHost()
  {
    return host;
  }

  public String getConduit()
  {
    return port;
  }

    
  public void setConnection(DaemonSocketConnection connection)
  {
    connection = connection;
  }

  public DaemonSocketConnection getConnection()
  {
    return connection;
  }

  public void setClosed(boolean closed)
  {
    isClosed = closed;
  }

  public boolean isClosed()
  {
    return isClosed;
  }

  
}
