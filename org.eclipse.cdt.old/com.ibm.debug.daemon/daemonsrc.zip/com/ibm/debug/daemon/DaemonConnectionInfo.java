package com.ibm.debug.daemon;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

/**
 * Currently only useful to IOldDaemonSupport type startups.  Used to pass the host and port of the engine listener,
 * as well as the socket established with the daemon.
 */
import java.net.InetAddress;

public class DaemonConnectionInfo
{
  protected String host;
  protected String port;
  protected DaemonSocketConnection connection;
  protected boolean isClosed;
  
  /**
   * @param ipAddress If this argument is null, the getNewConnection method
   * will use the local host by default.
   * @param port that the engine is waiting on
   */

  public DaemonConnectionInfo(String ipAddress, String port)
  {	
     host = ipAddress;
     this.port = port;
     connection = null;
  }  
 /**
   * The default host is "localhost".  Using "localhost" instead of the actual
   * host name avoids a network request to the name server.   This allows the
   * connection to work when there is no network
   */
  public String getDefaultHost()
  {
      return "localhost";
  } 

  public String getHost()
  {
  	if(host == null)
  		return getDefaultHost();
    return host;
  }

  public String getConduit()
  {
    return port;
  }
    
  public void setConnection(DaemonSocketConnection connection)
  {
    connection = connection;
  }

  public DaemonSocketConnection getConnection()
  {
    return connection;
  }

  
}
