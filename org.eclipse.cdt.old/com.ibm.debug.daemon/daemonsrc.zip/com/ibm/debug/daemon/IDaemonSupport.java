package com.ibm.debug.daemon;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */
import java.net.Socket;

/**
 * This interface should be implemented by launch configurations delegates that support the new style
 * of engine-daemon connection.  See also IOldDaemonSupport.
 */
public interface IDaemonSupport {
	
	/**
	 * The daemon will pass the parameters received from the engine/kicker over the socket.
	 * @param xml the bytes of xml sent by the engine
	 * @param key the connection key that is used to identify the connection. Will be 0 if not sent by the engine.
	 * @param version the daemon conversation version sent by the engine (not to be confused with EPDC version).
	 */	
	public void setConnectionInfo(byte[] xml, int key, int version);

	/**
	 * May be a kicker socket or engine socket.  The launcher should be able to tell from the
	 * conversation style.
	 */
	public void setSocket(DaemonSocketConnection socket);
	

	
	
}
