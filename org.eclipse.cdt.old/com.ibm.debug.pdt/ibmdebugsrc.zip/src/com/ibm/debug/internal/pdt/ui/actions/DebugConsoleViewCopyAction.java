package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2000, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.ui.views.DebugConsoleView;

/**
 * Copy selected text to clipboard
 */

public class DebugConsoleViewCopyAction extends DebugConsoleViewAction {

	protected static final String PREFIX= "DebugConsoleViewCopyAction.";
	
	/**
	 * DebugConsoleViewCopyAction constructor
	 * @param aView DebugConsoleView
	 * @param name java.lang.String
	 */
	public DebugConsoleViewCopyAction(DebugConsoleView aView) {
		super(aView, PICLUtils.getResourceString(PREFIX+"label"));
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip"));
	}

	public void run() {
		getDebugConsoleView().copySelection();
	}

}
