package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.epdc.*;

/**
 * This class represents the monitored expressions of array type
 */
public class ArrayMonitoredExpressionTreeNode extends
                                           AggregateMonitoredExpressionTreeNode
{
   ArrayMonitoredExpressionTreeNode(EStdTreeNode node,
                                    MonitoredExpression expr)
   {
      super(node, expr);
      int count = ((EStdArrayItem)(node.getTreeNodeData())).getItemCount();
      super.setNumberOfChildren(count);

      // Set the default representation index of this node
      // Set the array of representation indices of this node
      super.setDefRepAndRepsArray(
                     ((EStdArrayItem)(node.getTreeNodeData())).getArrayOfReps(),
                     ((EStdArrayItem)(node.getTreeNodeData())).getDefRep() );
   }

}
