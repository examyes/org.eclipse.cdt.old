package com.ibm.debug.internal.pdt.ui.views;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.Launch;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IVariable;
import org.eclipse.debug.ui.AbstractDebugView;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITreeViewerListener;
import org.eclipse.jface.viewers.TreeExpansionEvent;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PDTModelPresentation;
import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLMonitorParent;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.PICLVariable;
import com.ibm.debug.internal.pdt.model.Representation;
import com.ibm.debug.internal.pdt.ui.actions.ChangeRepresentationAction;
import com.ibm.debug.internal.pdt.ui.actions.CopyTreeViewToClipboardAction;
import com.ibm.debug.internal.pdt.ui.actions.DereferencePointerAction;
import com.ibm.debug.internal.pdt.ui.actions.DisableVariableMonitorAction;
import com.ibm.debug.internal.pdt.ui.actions.EditValueAction;
import com.ibm.debug.internal.pdt.ui.actions.MonitorExpressionAction;
import com.ibm.debug.internal.pdt.ui.actions.PrintTreeViewAction;
import com.ibm.debug.internal.pdt.ui.actions.RemoveVariableFromMonitorAction;
import com.ibm.debug.internal.pdt.ui.actions.ShowTypeInfoAction;


public class MonitorView extends AbstractDebugView implements ISelectionListener, IDoubleClickListener, ITreeViewerListener {
	protected final static String PREFIX= "MonitorView.";
	private TreeViewer fTreeViewer = null;

	protected MonitorContentProvider fContentProvider= null;
	protected EditValueAction fEditVariableValueAction;
	protected MonitorExpressionAction fMonitorExpressionAction;
	protected ShowTypeInfoAction fShowTypeInfoAction;
	protected RemoveVariableFromMonitorAction fRemoveVariableFromMonitorAction;
	protected DisableVariableMonitorAction fDisableVariableMonitorAction;
	protected CopyTreeViewToClipboardAction fCopyTreeViewToClipboardAction;
	protected PrintTreeViewAction fPrintTreeViewAction;


	/**
	 * @see AbstractDebugView#createViewer(Composite)
	 */
	protected Viewer createViewer(Composite parent) {
		addListeners();
		fTreeViewer = new TreeViewer(parent, SWT.MULTI);
		fContentProvider = new MonitorContentProvider();
		fTreeViewer.setContentProvider(fContentProvider);
		fTreeViewer.setLabelProvider(new PDTModelPresentation());
		setInitialContent();
		setTitleToolTip(PICLUtils.getResourceString(PREFIX+"tooltip"));
		return fTreeViewer;
	}

	/**
	 * @see AbstractDebugView#createActions()
	 */
	protected void createActions() {
		fEditVariableValueAction= new EditValueAction(fTreeViewer);
		fEditVariableValueAction.setEnabled(false);

		fMonitorExpressionAction= new MonitorExpressionAction(false);
		fMonitorExpressionAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_MONITOR_EXPRESSION));
		fMonitorExpressionAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_MONITOR_EXPRESSION));
		fMonitorExpressionAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_MONITOR_EXPRESSION));
		fMonitorExpressionAction.setEnabled(false);

		fShowTypeInfoAction= new ShowTypeInfoAction(fTreeViewer);
		fShowTypeInfoAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_SHOW_TYPE_NAMES));
		fShowTypeInfoAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_SHOW_TYPE_NAMES));
		fShowTypeInfoAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_SHOW_TYPE_NAMES));
		fShowTypeInfoAction.setChecked(false);

		fCopyTreeViewToClipboardAction= new CopyTreeViewToClipboardAction(fTreeViewer);
		fCopyTreeViewToClipboardAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_COPY_VIEW_TO_CLIPBOARD));
		fCopyTreeViewToClipboardAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_COPY_VIEW_TO_CLIPBOARD));
		fCopyTreeViewToClipboardAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_COPY_VIEW_TO_CLIPBOARD));
		fCopyTreeViewToClipboardAction.setChecked(false);

		fPrintTreeViewAction= new PrintTreeViewAction(fTreeViewer, PICLUtils.getResourceString(PREFIX+"printjobtitle"));
		fPrintTreeViewAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_PRINT_VIEW));
		fPrintTreeViewAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_PRINT_VIEW));
		fPrintTreeViewAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_PRINT_VIEW));
		fPrintTreeViewAction.setChecked(false);

		fRemoveVariableFromMonitorAction= new RemoveVariableFromMonitorAction(fTreeViewer);
		fRemoveVariableFromMonitorAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_REMOVE_MONITOR));
		fRemoveVariableFromMonitorAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_REMOVE_MONITOR));
		fRemoveVariableFromMonitorAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_REMOVE_MONITOR));
		fRemoveVariableFromMonitorAction.setChecked(false);

		fDisableVariableMonitorAction= new DisableVariableMonitorAction(fTreeViewer);
		fDisableVariableMonitorAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_DISABLE_MONITOR));
		fDisableVariableMonitorAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_DISABLE_MONITOR));
		fDisableVariableMonitorAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_DISABLE_MONITOR));
		fDisableVariableMonitorAction.setChecked(false);
	}

	/**
	 * @see AbstractDebugView#configureToolBar(IToolBarManager)
	 */
	protected void configureToolBar(IToolBarManager tbm) {
		tbm.add(new Separator(this.getClass().getName()));
		tbm.add(fMonitorExpressionAction);
		tbm.add(fRemoveVariableFromMonitorAction);
		tbm.add(fDisableVariableMonitorAction);
		tbm.add(new Separator(this.getClass().getName()));
		tbm.add(fShowTypeInfoAction);
		tbm.add(new Separator(this.getClass().getName()));
		tbm.add(fCopyTreeViewToClipboardAction);
		tbm.add(fPrintTreeViewAction);
	}

	/**
	 * @see AbstractDebugView#getHelpContextId()
	 */
	protected String getHelpContextId() {
		return PICLUtils.getHelpResourceString("MonitorView");
	}

	/**
	 * @see AbstractDebugView#fillContextMenu(IMenuManager)
	 */
	protected void fillContextMenu(IMenuManager menu) {

		menu.add(new Separator(this.getClass().getName()));
		menu.add(fEditVariableValueAction);
		menu.add(fMonitorExpressionAction);
		menu.add(fRemoveVariableFromMonitorAction);
		menu.add(fDisableVariableMonitorAction);
		
		//(single selection only)
		IStructuredSelection selection= (IStructuredSelection) fTreeViewer.getSelection();
		if (selection != null && !selection.isEmpty() && selection.size() == 1) {
			Object var = selection.getFirstElement();
			if (var instanceof PICLVariable) {
				
				//add "dereference pointer" action
				if (((PICLVariable)var).isPointer()) {
					menu.add(new DereferencePointerAction((PICLVariable)var));
				}
				
				//add all "change representation" choices for the selected item
				MenuManager submenu= new MenuManager(PICLUtils.getResourceString("ChangeRepresentationAction.label"), "group.representations");
				Representation reps[] = ((PICLVariable)var).getArrayOfRepresentations();
				if (reps != null) {
					for (int i=0; i<reps.length; i++) {
						submenu.add(new ChangeRepresentationAction((PICLVariable)var, reps[i]));
					}
				}
				menu.add(submenu);
			}
		}

		menu.add(new Separator(this.getClass().getName()));
		menu.add(fShowTypeInfoAction);

		menu.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
	}

	protected void setInitialContent() {
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) { return; }
		IViewPart view= p.findView(IDebugUIConstants.ID_DEBUG_VIEW);
		if (view == null) {
			try {
				IWorkbenchPart activePart= p.getActivePart();
				view= p.showView(IDebugUIConstants.ID_DEBUG_VIEW);
				p.activate(activePart);
			} catch (PartInitException e) {
				PICLUtils.logError(e);
				return;
			}
		}
		if (!(view instanceof IDebugView)) { return; }
		((IDebugView)view).getViewer().setSelection(((IDebugView)view).getViewer().getSelection());
	}


	/**
	 * @see IDoubleClickListener#doubleClick(DoubleClickEvent)
	 */
	public void doubleClick(DoubleClickEvent event) {
    	IStructuredSelection selection = (IStructuredSelection)event.getSelection();
		if (selection.size() != 1) 	//Single selection only
			return;

		//Get the selected monitored variable
		IDebugElement source = (IDebugElement) selection.getFirstElement();
		if(! (source instanceof PICLVariable)) { return; }
		if (((PICLVariable)source).hasChildren()) { //expand/collapse
			if (fTreeViewer.getExpandedState(source))
				fTreeViewer.collapseToLevel(source,1);
			else
				fTreeViewer.expandToLevel(source,1);
		} else { //edit the value
			fEditVariableValueAction.run();
		}
	}

	/**
	 * Handles key events in viewer.  Specifically interested in
	 * the Delete key.
	 */
	protected void handleKeyPressed(KeyEvent event) {
		if (event.character == SWT.DEL && event.stateMask == 0
			&& fRemoveVariableFromMonitorAction.isEnabled()) {
				fRemoveVariableFromMonitorAction.run();
		}
	}


	/**
	 * Remove myself as a selection listener to the <code>LaunchesView</code> in this perspective.
	 *
	 * @see IWorkbenchPart
	 */
	public void dispose() {
		removeListeners();
		//exception occurs sometimes when tree already disposed
		try{
			if (fTreeViewer != null) {
				fTreeViewer.removeTreeListener(this);
				fTreeViewer.removeDoubleClickListener(this);
			}
		}catch(Exception e) {}
		super.dispose();
	}

	public void partClosed(IWorkbenchPart part) {
		if (!(part instanceof MonitorView))
			return;
		//TODO: stop add/update events from the model
		removeListeners();
		try {
			if (fTreeViewer != null) {
				fTreeViewer.removeTreeListener(this);
				fTreeViewer.removeDoubleClickListener(this);
			}
		} catch (Exception e) {}
		super.partClosed(part);
	}


	/**
	 * @see ITreeViewerListener#treeCollapsed(TreeExpansionEvent)
	 */
	public void treeCollapsed(TreeExpansionEvent event) {
	}
	/**
	 * @see ITreeViewerListener#treeExpanded(TreeExpansionEvent)
	 */
	public void treeExpanded(TreeExpansionEvent event) {
	}
	
	
	/**
	 * @see ISelectionListener#selectionChanged(IWorkbenchPart, ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {

		if (fTreeViewer == null || fTreeViewer.getContentProvider() == null) {
			return;
		}

		IStructuredSelection ssel = (IStructuredSelection) selection;

		PICLDebugElement de = null;

		// check if the selection is a PICLDebugElement
		if ((ssel.getFirstElement() instanceof PICLDebugElement))
			de = (PICLDebugElement)ssel.getFirstElement();
		else
			if ((ssel.getFirstElement() instanceof Launch)) {
				Launch l = (Launch)ssel.getFirstElement();
				if (l.getDebugTarget() instanceof PICLDebugElement)
					de = (PICLDebugTarget)l.getDebugTarget();
			}

		if (de == null)  // nothing selected that the monitor view can show
			fTreeViewer.setInput(null);
		else {
			// check to see if a change is required

			PICLMonitorParent monitorParent = ((PICLDebugTarget)de.getDebugTarget()).getMonitorParent();

			if (fTreeViewer.getInput() != null && fTreeViewer.getInput().equals(monitorParent)) { // no change required because it matches
				fTreeViewer.refresh();
				return;
			} else {
				//save the current tree expanded state in the current monitorparent
				Object current = fTreeViewer.getInput();
				if (current !=null && current instanceof PICLMonitorParent)
					((PICLMonitorParent)current).setExpandedElements(fTreeViewer.getExpandedElements());
				//set the input to the new monitorparent
				fTreeViewer.setInput(monitorParent);
				//restore any previously expanded state of the new parent
				if(monitorParent != null && monitorParent.getExpandedElements() != null)
					fTreeViewer.setExpandedElements(monitorParent.getExpandedElements());
			}
		}


	}

	private void addListeners() {
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().addSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
	}
	
	private void removeListeners() {
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().removeSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
	}
}
