package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

abstract class Serialization
{
  Serialization(int flags)
  {
    _flags = flags;
  }

  abstract void saveGraph(Object object) throws java.io.IOException;

  abstract Object getGraph()
  throws java.io.IOException, java.lang.ClassNotFoundException;

  void saveGraph(OutputStream stream, Object object)
  throws java.io.IOException
  {
    // Create a ModelObjectOutputStream and tell it to save the graph:

    ModelObjectOutputStream objectStream =
                            new ModelObjectOutputStream(stream, _flags);

    objectStream.writeObject(object);
  }

  static Object getGraph(InputStream stream)
  throws java.io.IOException,
         java.lang.ClassNotFoundException
  {
    // Create a ModelObjectInputStream and tell it to read the graph:

    ModelObjectInputStream objectStream =
                            new ModelObjectInputStream(stream);

    return objectStream.readObject();
  }

  void setFlags(int flags)
  {
    _flags = flags;
  }

  int getFlags()
  {
    return _flags;
  }

  boolean canBeDeserialized()
  {
    try
    {
      if (getGraph() == null)
         return false;
      else
         return true;
    }
    catch (java.io.IOException excp)
    {
      return false;
    }
    catch (java.lang.ClassNotFoundException excp)
    {
      return false;
    }
  }

  private int _flags;
}
