package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * <code>IStorageSupport</code> defines functionality for
 * debug targets supporting storage. The storage
 * view will only appear if the target returns <code>true</code>
 * from <code>supportsStorage</code>.
 */

import java.util.Vector;

public interface IStorageSupport {

	/**
	 * Returns <code>true</code> if this target supports monitoring
	 * storage, otherwise <code>false</code>. The default value should be false.
	 * This method will control the ability to monitor specific blocks
	 * of storage.
	 */
	boolean supportsStorageMonitors();

	/**
	 * Returns <code>true</code> if this target supports monitoring
	 * storage, otherwise <code>false</code>. The default value should be false.
	 * This method will control the ability to map storage
	 * in the mapping view.
	 */
	boolean supportsStorageMapping();
}
