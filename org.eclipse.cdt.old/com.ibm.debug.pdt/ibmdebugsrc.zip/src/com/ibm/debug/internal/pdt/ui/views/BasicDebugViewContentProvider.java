package com.ibm.debug.internal.pdt.ui.views;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.DebugEvent;
import org.eclipse.debug.core.IDebugEventSetListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.widgets.Control;

public abstract class BasicDebugViewContentProvider implements IStructuredContentProvider, IDebugEventSetListener {

	protected StructuredViewer fViewer;
	protected boolean fDisposed= false;

	/**
	 * @see IContentProvider#dispose
	 */
	public void dispose() {
		fDisposed= true;
	}
	
	/**
	 * Returns whether this content provider has already
	 * been disposed.
	 */
	protected boolean isDisposed() {
		return fDisposed;
	}
	
	/**
	 * @see IContentProvider#inputChanged
	 */
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		fViewer= (StructuredViewer) viewer;
	}

	/**
	 * @see Display.asyncExec(Runnable)
	 */
	protected void asyncExec(Runnable r) {
		if (fViewer != null) {
			Control ctrl= fViewer.getControl();
			if (ctrl != null && !ctrl.isDisposed()) {
				ctrl.getDisplay().asyncExec(r);
			}
		}
	}
	
	/**
	 * @see Display.syncExec(Runnable)
	 */
	protected void syncExec(Runnable r) {
		if (fViewer != null) {
			Control ctrl= fViewer.getControl();
			if (ctrl != null && !ctrl.isDisposed()) {
				ctrl.getDisplay().syncExec(r);
			}
		}
	}
	
	/**
	 * Refreshes the viewer - must be called in UI thread.
	 */
	protected void refresh() {
		if (fViewer != null) {
			fViewer.refresh();
		}
	}
			
	/**
	 * Refresh the given element in the viewer - must be called in UI thread.
	 */
	protected void refresh(Object element) {
		if (fViewer != null) {
			 fViewer.refresh(element);
		}
	}
	
	/**
	 * Handle debug events on the main thread.
	 * @param event
	 */
	public void handleDebugEvent(final DebugEvent event) {
		if (fViewer == null) {
			return;
		}
		Object element= event.getSource();
		if (element == null) {
			return;
		}
		Runnable r= new Runnable() {
			public void run() {
				if (!isDisposed()) {
					doHandleDebugEvent(event);
				}
			}
		};
		
		asyncExec(r);
	}
	
	/**
	 * @see ITreeContentProvider
	 */
	public Object[] getChildren(final Object parent) {
		return doGetChildren(parent);
	}
	
	/**
	 * Performs an update based on the event
	 */
	protected abstract void doHandleDebugEvent(DebugEvent event);
	
	protected abstract Object[] doGetChildren(Object parent);
	
	/**
	 * @see ITreeContentProvider
	 */
	public boolean hasChildren(Object item) {
		return doGetChildren(item).length > 0;
	}	
	/* (non-Javadoc)
	 * @see IDebugEventSetListener#handleDebugEvents(DebugEvent[])
	 */
	public void handleDebugEvents(DebugEvent[] events) {
		for (int i=0; i < events.length; i++)
			handleDebugEvent(events[i]);
	}

}

