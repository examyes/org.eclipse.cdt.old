package com.ibm.debug.internal.pdt.ui.dialogs;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.epdc.EPDC;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.DebugEngine;


/**
 * Presents to the user an input field they can enter a program name to load into debug
 * Primarily used for the 400 platform.
 */
public class AddProgramDialog extends StatusDialog {

	private final static String PREFIX= "AddProgramDialog.";
	private PICLDebugTarget fdt;
	private Text fProgramNamefield;
	
	private Button fProgramButton, fServicePgmButton, fJavaClassButton;

	/**
	 * Constructor for AddProgramDialog.
	 * @param parent
	 */
	public AddProgramDialog(Shell parent, PICLDebugTarget dt) {
		super(parent);
		fdt = dt;		
		setTitle(PICLUtils.getResourceString(PREFIX+"title"));


		WorkbenchHelp.setHelp(parent, PICLUtils.getHelpResourceString("AddProgramDialog"));
	}

	
	/**
	 * @see Dialog#createDialogArea(Composite)
	 */
	protected Control createDialogArea(Composite parent) {
		parent.setLayout(new GridLayout());
		
		// setup program name field
		Label label = new Label(parent,SWT.NONE);
		label.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_FILL));
		label.setText(PICLUtils.getResourceString(PREFIX+"program_name"));
		fProgramNamefield = new Text(parent,SWT.BORDER);
		fProgramNamefield.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_FILL));
		
		// setup program type group
		Group pgmTypeGrp = new Group(parent,SWT.NONE);
		pgmTypeGrp.setLayout(new GridLayout());
		pgmTypeGrp.setText(PICLUtils.getResourceString(PREFIX+"program_type"));
		pgmTypeGrp.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_FILL));
		
		fProgramButton = new Button(pgmTypeGrp, SWT.RADIO);
		fProgramButton.setText(PICLUtils.getResourceString(PREFIX+"program_type.program"));
		fProgramButton.setSelection(true);  // set default
		fServicePgmButton = new Button(pgmTypeGrp, SWT.RADIO);
		fServicePgmButton.setText(PICLUtils.getResourceString(PREFIX+"program_type.service_program"));
		fJavaClassButton = new Button(pgmTypeGrp, SWT.RADIO);
		fJavaClassButton.setText(PICLUtils.getResourceString(PREFIX+"program_type.java_class"));
		
		fProgramNamefield.setFocus();
		return parent;
	}

	/**
	 * @see Dialog#okPressed()
	 */
	protected void okPressed() {
		if (fdt != null) {
			// figure out the program type
			int pgmType = EPDC.ProgType400Default;
			if (fProgramButton.getSelection())
				pgmType = EPDC.ProgType400Default;
			else if (fServicePgmButton.getSelection())
					pgmType = EPDC.ProgType400Service;
				else if (fJavaClassButton.getSelection())
						pgmType = EPDC.ProgType400Java;
					
			try {
				fdt.getDebugEngine().addProgram(fProgramNamefield.getText(),pgmType,DebugEngine.sendReceiveSynchronously);
			} catch(IOException e) {
			}
		}
		super.okPressed();
	}

}
