package com.ibm.debug.internal.pdt;

import com.ibm.debug.daemon.DaemonConnectionInfo;
import com.ibm.debug.internal.pdt.util.DebuggerOptionDescriptor;
import com.ibm.debug.pdt.launch.PICLLoadInfo;

/**
   * This class handles the old style of engine parameter.
   */
  public class OldEngineParameters extends EngineParameters
  {
    protected final String OPTION_A                = "-a";
    protected final String OPTION_HELP             = "-help";
    protected final String OPTION_I                = "-i";
    protected final String OPTION_QADDRESS         = "-qaddress";
    protected final String OPTION_QCONNECT         = "-qconnect";
    protected final String OPTION_QDAEMON          = "-qdaemon";
    protected final String OPTION_QDISPLAY         = "-qdisplay";
    protected final String OPTION_QHOST            = "-qhost";
    protected final String OPTION_QLANG            = "-qlang";
    protected final String OPTION_QPID             = "-qpid";
    protected final String OPTION_QPORT            = "-qport";
    protected final String OPTION_QPROTOCOL        = "-qprotocol";
    protected final String OPTION_QQUIET           = "-qquiet";
    protected final String OPTION_QSESSION         = "-qsession";
    protected final String OPTION_QTITLE           = "-qtitle";
    protected final String OPTION_QUIPORT          = "-quiport";
    protected final String OPTION_S                = "-s";
    //java attach JVM details
    protected final String OPTION_HOST			= "-host";
    protected final String OPTION_PORT			= "-port";    
    protected final String OPTION_PASSWORD		= "-password";
    

    public OldEngineParameters()
    {
      setOptionDescriptors();
    }

    public String getProgramName()
    {
      return debuggeeName();
    }

    public String getProgramParms()
    {
      return debuggeeArgs();
    }

    public int getLoadStartupBehaviour()
    {
      if(valueByName(OPTION_S) != null)
        return PICLLoadInfo.RUN_TO_BREAKPOINT;
      else if(valueByName(OPTION_I) != null)
        return PICLLoadInfo.DEBUG_INITIALIZATION;
      else
        return PICLLoadInfo.RUN_TO_MAIN;
    }

    public int getAttachStartupBehaviour()
    {
      if(valueByName(OPTION_S) != null)
        return RUN;
      else
        return STOP;
    }
    
    public boolean isAttach()
  	{
  		if(valueByName(OPTION_A) == null)
			return false;
		else return true;
  	}

    public String getProcessID()
    {
      return valueByName(OPTION_A);
    }
    
    public boolean isJavaAttach()
    {	
    	String pid = valueByName(OPTION_A);
    	if(pid != null && valueByName(OPTION_A).equals("0"))
    		return true;
    	return false;
    }
    
    
    public void setInfo(String[] inputStrings)
    {
    	//inputStrings will be an array[5] in format: host, conduit, title, # parms, large string of all parms
      // clear out current options
      rebuild(new String[0], false);

      //
      // Read the host and conduit
      //
      
      String host = inputStrings[0];     
      String conduit = inputStrings[1];           
      
      //
      // Read the title
      //
      
      title = inputStrings[2];

      PICLUtils.logText("DebugDaemon Title =" + title);

      //
      // Read the parms
      //
      arguments = "";
      String argCountString = inputStrings[3];

      PICLUtils.logText("DebugDaemon Argcount =" + argCountString);

     if (argCountString != null && !argCountString.equals("") && argCountString.length() != 0) 
          arguments = inputStrings[4];
      PICLUtils.logText( "DebugDaemon Arguments =" + arguments);
	  rebuild(arguments);
      
      if(host == null)
     	host=valueByName(OPTION_HOST);
      PICLUtils.logText("DebugDaemon Host=" + host);
      	if(conduit==null)
      		conduit=valueByName(OPTION_PASSWORD);  //old JDK term also accepted
      	if(conduit==null)
      		conduit=valueByName(OPTION_PORT); //new JDK term 
   	PICLUtils.logText("DebugDaemon Conduit =" + conduit);
      	
	  if(host!=null && conduit!= null && !host.equals("") && !conduit.equals(""))
	  	connectionInfo = new DaemonConnectionInfo(host, conduit);
    }
    
  
    protected void setOptionDescriptors()
    {
      super.setOptionDescriptors();

      // Note that OPTION_A and OPTION_QDAEMON may have optional parameters, and so appear twice.
      // The "with parm" version appears first, to allow options of the form -a 123
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_A,                OPTION_A.length(),                true,  true));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_A,                OPTION_A.length(),                false, false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_HELP,             OPTION_HELP.length(),             false, false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_I,                OPTION_I.length(),                false, false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QADDRESS,         OPTION_QADDRESS.length(),         true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QCONNECT,         OPTION_QCONNECT.length(),         true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QDAEMON,          OPTION_QDAEMON.length(),          true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QDAEMON,          OPTION_QDAEMON.length(),          false, false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QDISPLAY,         OPTION_QDISPLAY.length(),         true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QHOST,            OPTION_QHOST.length(),            true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QLANG,            OPTION_QLANG.length(),            true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QPID,             OPTION_QPID.length(),             true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QPID,             OPTION_QPID.length(),             false, false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QPORT,            OPTION_QPORT.length(),            true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QPROTOCOL,        OPTION_QPROTOCOL.length(),        true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QQUIET,           OPTION_QQUIET.length(),           false, false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QTITLE,           OPTION_QTITLE.length(),           true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_QUIPORT,          OPTION_QUIPORT.length(),          true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_S,                OPTION_S.length(),                false, false));
	  addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_HOST,            OPTION_HOST.length(),              true,  false));
	  addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_PORT,            OPTION_PORT.length(),              true,  false));
	  addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_PASSWORD,        OPTION_PASSWORD.length(),          true,  false));
      
    }
}
