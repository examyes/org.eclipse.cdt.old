package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Vector;

import org.apache.xerces.parsers.DOMParser;
import org.eclipse.core.resources.IMarker;
import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ibm.debug.epdc.EPDC;
import com.ibm.debug.internal.pdt.model.DebugEngine;
import com.ibm.debug.internal.pdt.model.Storage;
import com.ibm.debug.internal.pdt.model.StorageChangedEvent;
import com.ibm.debug.internal.pdt.model.StorageColumn;
import com.ibm.debug.internal.pdt.model.StorageDeletedEvent;
import com.ibm.debug.internal.pdt.model.StorageEventListener;
import com.ibm.debug.internal.pdt.model.StorageLine;
import com.ibm.debug.internal.pdt.model.StorageLineChangedEvent;
import com.ibm.debug.internal.pdt.model.StorageLineEventListener;
import com.ibm.debug.internal.pdt.model.StorageStyle;
import com.ibm.debug.internal.pdt.model.ViewInformation;
import com.ibm.debug.internal.pdt.ui.util.StatusInfo;
import com.ibm.debug.internal.pdt.util.FileSystem;



/**
 * Represents a monitored storage mapping
 */

public class PICLStorageMap
	extends PICLDebugElement
	implements StorageEventListener, StorageLineEventListener {

	protected final static String PREFIX= "picl_storage_map.";
	public static final int RAW = 0;

	//Valid attributes for FIELD entries (nodes of the storage tree map) in the XML 
	//Not to be translated
	public static String HEADER			= "Header";
	public static String TYPE				= "Type";
	public static String LENGTH			= "length";
	public static String LAYOUT			= "layout";


	//Valid types for the storage chunks to be displayed in (depending on engine)
	//Not to be translated
	public static final String TYPE_16_BIT_INT	= "16_BIT_INT";
	public static final String TYPE_16_BIT_UINT	= "16_BIT_UINT";
	public static final String TYPE_16_BIT_HINT	= "16_BIT_HINT";
	public static final String TYPE_32_BIT_INT	= "32_BIT_INT";
	public static final String TYPE_32_BIT_UINT	= "32_BIT_UINT";
	public static final String TYPE_32_BIT_HINT	= "32_BIT_HINT";
	public static final String TYPE_32_BIT_FLOAT= "32_BIT_FLOAT";
	public static final String TYPE_64_BIT_INT	= "64_BIT_INT";
	public static final String TYPE_64_BIT_FLOAT= "64_BIT_FLOAT";
	public static final String TYPE_CHARACTER	= "CHARACTER";
	public static final String TYPE_HEX				= "HEX";
	public static final String TYPE_ASCII			= "ASCII";
	public static final String TYPE_EBCDIC			= "EBCDIC";
	public static final String TYPE_STRUCTURE	= "STRUCTURE";
	public static final String TYPE_PADDING		= "PADDING";
	public static final String TYPE_BIT				= "BIT";
	public static final String TYPE_BITMASK		= "BITMASK";
	public static final String TYPE_MAP				= "MAP";


	private PICLThread fThread;
	private IMarker fMarker;
	private ViewInformation fViewInfo;
	private Node fNode;	//used by parent nodes (structures and maps/layouts) to construct children from the XML definition

	private boolean childrenHaveBeenBuilt = false;

	private String fStorageType = "";
	private Storage fStorage = null;
	private StorageLine fStorageLine = null;
	private String fName = "";
	private String fAddress = null;	//used for parent nodes that do not monitor storage (structures) or that use a different address (maps) to construct children
	private int fNumStorageLines = 0;
	private	int fTotalNumBytesMonitored = 0;
	private	int fLowestOffsetMonitored = 0;
	private int fHighestOffsetMonitored = 0;
	private StringBuffer fStorageBuffer = null;
	private boolean fStorageBufferCurrent = false;
	private String fLayout = "";

	private Vector fMonitoredStorageLines = null;


	/**
	 * Constructor for PICLStorageMap
	 */
	public PICLStorageMap(PICLThread thread, 
									IMarker marker, 
									ViewInformation viewInfo, 
									PICLDebugElement parent, 
									Storage storage, 
									IDebugTarget debugTarget) {
		super(parent, debugTarget);
		fThread = thread;
		fMarker = marker;
		fViewInfo = viewInfo;

		if (storage != null) {	//Structure nodes do not monitor storage
			fStorage = storage;
			fStorage.addEventListener(this);
			calculateStorageValues();
	
			// add ourselves as an event listener on the storage lines
			fMonitoredStorageLines = fStorage.getStorageLines();
			monitorStorageLines();
			
			getStorageLine(0, fStorage.getNumberOfUnitsPerLine());
			fStorageBufferCurrent = true;
		}
	}

	/**
	 * Delete this storage monitor
	 */
	public boolean delete() {

		try {
			if (childrenHaveBeenBuilt) {
				IDebugElement children[]  = getChildren();
				for (int i=0; i<children.length; i++) {
					((PICLStorageMap)children[i]).delete();
				}
			}
		} catch(DebugException e) {
		}

		if (fStorage != null) {
			MonitorStorageMapDeleteRequest request = new MonitorStorageMapDeleteRequest((PICLDebugTarget)getDebugTarget(), this);
			try {
				request.execute();
			} catch(PICLException pe) {
				return false;
			}
		}
		((PICLDebugElement)getParent()).removeChild(this);
		return true;
	}

	/**
	 * Enable this storage monitor
	 */
	public boolean enable() {
		if (fStorage == null)
			return false;
		else
			try {
				return fStorage.enable();
			} catch(IOException ioe) {
				return false;
			}
	}

	/**
	 * Disable this storage monitor
	 */
	public boolean disable() {
		if (fStorage == null)
			return false;
		else
			try {
				return fStorage.disable();
			} catch(IOException ioe) {
				return false;
			}
	}


	/**
	 * Update raw storage contents
	 * @param storage type (see PICLStorage.RAW and PICLStorage.TRANSLATED
	 * @param offset from original storage location. NOTE: this MUST be within the storage requested
	 * @param new storage contents in the same format as the raw storage
	 * @return if successful sending request.   NOTE: a change event will be signalled when the change
	 * occurs.
	 */
	public boolean updateStorage(int offset, String newContents) {

		if (fStorage == null) 
			return false;


		int numBytes = fStorage.getNumberOfUnitsPerLine();
		// in order to update storage the correct storageline/storagecolumn must be obtained.
		int line = offset/numBytes;
		if (offset < 0)  // for -ve offsets subtract 1 to get to the previous storage line
			line--;

		// bump by offset in the storage object to get to get the correct array index
		line -= fStorage.getFirstLineOffset();

		int offsetInLine = 0;
		// now calculate the offset into the initial storage line
		if (offset >= 0)
			offsetInLine = offset - (offset/numBytes * numBytes);
		else
			offsetInLine = numBytes + offset - (offset/numBytes * numBytes);

		int translatedColumn = fStorage.getNumberOfUnitsPerLine();

		boolean done = false;
		int startPosn = offsetInLine;
		int endPosn = 0;

		int leftToChange = newContents.length();
		leftToChange /= 2;

		StringBuffer columnContents = null;

		while (!done) {  // start to process the changes
			if (startPosn + leftToChange > numBytes) {
				leftToChange -= numBytes - startPosn;
				endPosn = numBytes;
			} else {
				done = true;
				endPosn = startPosn + leftToChange;
			}


			StorageLine stgLine = (StorageLine)fMonitoredStorageLines.get(line);

			StorageColumn cols[] = stgLine.getStorageColumns();

			MonitorStorageUpdateRequest req = null;

			for (int i = startPosn, j = 0; i < endPosn; i++,j+=2 ) {
				req = new MonitorStorageUpdateRequest((PICLDebugTarget)getDebugTarget(),
														cols[i],
														newContents.substring(j,j+2));
				try {
					req.execute();
				} catch(PICLException pe) {
					return false;
				}
//						cols[i].update(newContents.substring(j,j+2),DebugEngine.sendReceiveSynchronously);
			}

			if (req !=null && req.isError())
				return false;
			startPosn = 0;
			line++;
		}



		return true;
	}

	/**
	 * @see PICLDebugElement#doCleanupDetails()
	 */
	protected void doCleanupDetails() {
		if (fStorage != null) {
			releaseStorageLines();
			fStorage.removeEventListener(this);
			fStorage = null;
		}
	}


	
	/**
	 * @see PICLDebugElement#getLabel(boolean)
	 */
	public String getLabel(boolean qualified) {

		if ((fStorage != null) && !fStorageBufferCurrent) {
			getStorageLine(0, fStorage.getNumberOfUnitsPerLine());
		}
		
		
		String type = "";
		if (qualified)
			type = getType();
		
		String label = PICLUtils.getResourceString(PREFIX+"label.error");
		if (TYPE_MAP.equals(fStorageType)) {
			label = PICLUtils.getFormattedString(PREFIX+"label.layout", new String[] {type, getName(), getAddress(), getLayout()});
		} else if (TYPE_STRUCTURE.equals(fStorageType)) {
			label = PICLUtils.getFormattedString(PREFIX+"label.structure", new String[] {type, getName(), getAddress()});			
		} else if (TYPE_BITMASK.equals(fStorageType)) {
			label = PICLUtils.getFormattedString(PREFIX+"label", new String[] {type, getName(), fStorageBuffer.toString()});
		} else if (TYPE_BIT.equals(fStorageType)) {
			label = PICLUtils.getFormattedString(PREFIX+"label", new String[] {type, getName(), fStorageBuffer.toString()});
		} else if (fStorageBuffer != null) {
			label = PICLUtils.getFormattedString(PREFIX+"label", new String[] {type, getName(), fStorageBuffer.toString()});
		}
		return label;
	}

	/**
	 * @see StorageEventListener#storageDeleted(StorageDeletedEvent)
	 */
	public void storageDeleted(StorageDeletedEvent event) {
		PICLUtils.logEvent("Storage deleted",this);
	}

	/**
	 * @see StorageEventListener#storageChanged(StorageChangedEvent)
	 */
	public void storageChanged(StorageChangedEvent event) {
		PICLUtils.logEvent("Storage changed",this);
		// make sure that the storage values are up-to-date
		fMonitoredStorageLines = event.getStorage().getStorageLines();
		calculateStorageValues();
		monitorStorageLines();   // monitor the new storage lines
		fStorageBufferCurrent = false;
		fireChangeEvent();
	}

	/**
	 * @see StorageLineEventListener#storageLineChanged(StorageLineChangedEvent)
	 */
	public void storageLineChanged(StorageLineChangedEvent event) {
		PICLUtils.logEvent("StorageLine changed", this);
		fStorageBufferCurrent = false;
		fStorageLine = event.getStorageLine();

		// NOTE: currently this only monitors the base storage line
		fireChangeEvent();
	}

	public String getName() {
		return fName;
	}

	public void setName(String name) {
		fName = name;
	}



	/**
	 * Return the storage contents
	 * @param start offset.  This can be negative if storage before the address is required
	 * @param number of bytes to return.   The buffer returned will contain 2x the number of
	 * bytes requested because each byte is represented by 2 characters
	 * @return array of buffers with contents of storage
	 * Use PICLStorage.RAW and PICLStorage.TRANSLATED to get the correct stringbuffer from the returned
	 * values.
	 */
	public StringBuffer getStorageLine(int offset, int numberOfBytes) {

		// check to make sure that we have enough storage to satisfy the request
		// NOTE: anytime storage is requested an additional storage line before and
		// after is obtained.   The requested offset can therefore be -ve

		int adjustedOffset = offset - fLowestOffsetMonitored;
		int adjustedEndOffset = adjustedOffset + numberOfBytes;

		PICLUtils.logText("(GET)Requested offset= " + offset + " numberOfBytes= " + numberOfBytes);
		PICLUtils.logText("(GET)Adjusted  offset= " + adjustedOffset + " adjusted endoffset= " + adjustedEndOffset);
		PICLUtils.logText("(GET)Storage first line/last line =(" + fStorage.getFirstLineOffset() + "," + fStorage.getLastLineOffset() + ")");
		PICLUtils.logText("(GET)offset + # bytes= " + (offset + numberOfBytes));

		if (adjustedOffset < 0 || (offset + numberOfBytes) > fHighestOffsetMonitored) {
			PICLUtils.logText("Storage requested outside what is available.  Get new storage");

			int newFirstLine = 0;
			int newLastLine = 0;

			try {
				releaseStorageLines();  // remove this object as listener for storage lines
				fStorage.setRange(newFirstLine,newLastLine,DebugEngine.sendReceiveSynchronously);
				calculateStorageValues();
				fStorageBufferCurrent = false;
				adjustedOffset = offset - fLowestOffsetMonitored;
				adjustedEndOffset = adjustedOffset + numberOfBytes;
			} catch(IOException ioe) {
				return null;   // error condition
			}

		}

		if (fStorageBuffer == null)
			fStorageBuffer = new StringBuffer(fTotalNumBytesMonitored * 2);  // there are 2 chars per byte

		if (!fStorageBufferCurrent) {

			fStorageBuffer.setLength(0);    // clear the buffer

			// get the lines from the Storage object
			fMonitoredStorageLines = fStorage.getStorageLines();
			Enumeration enum = fMonitoredStorageLines.elements();

			while (enum.hasMoreElements()) {
				StorageLine contents = (StorageLine)enum.nextElement();
				fStorageBuffer.append((contents.getStorage())[RAW]);
			}
			fStorageBufferCurrent = true;
		}

		PICLUtils.logText("RAW 			buffer is " + fStorageBuffer.length());
		StringBuffer buffer = new StringBuffer(fStorageBuffer.substring(adjustedOffset, adjustedEndOffset));
		return buffer;
	}

	public void setAddress(String address) {
		fAddress = address;
	}
	/**
	 * Return the address expression used to compute the address
	 * @return A string that represents the original expression
	 */
	public String getAddress() {
		
		if (fAddress != null) {
			return fAddress;
		}
		if (fStorage == null )
			return "";
		String storageAddress = fStorage.getAddress();
		if (storageAddress.toUpperCase().startsWith("0X")) {
			storageAddress = storageAddress.substring(2);
		}
		return storageAddress;
	}


	/**
	 * Gets the storage
	 * @return Returns a Storage
	 */
	public Storage getStorage() {
		return fStorage;
	}

	private void calculateStorageValues() {
		fNumStorageLines = Math.abs(fStorage.getFirstLineOffset() - fStorage.getLastLineOffset()) +1;
		fTotalNumBytesMonitored = fNumStorageLines * fStorage.getNumberOfUnitsPerLine();

		fLowestOffsetMonitored = fStorage.getNumberOfUnitsPerLine() * fStorage.getFirstLineOffset();
		fHighestOffsetMonitored = fLowestOffsetMonitored + fTotalNumBytesMonitored - 1; // check to see if the
		// last byte is included in the monitored list.
		PICLUtils.logText("Storage first line/last line =(" + fStorage.getFirstLineOffset() + "," + fStorage.getLastLineOffset() + ")");
		PICLUtils.logText("Calculated values: #lines		= " + fNumStorageLines);
		PICLUtils.logText("Calculated values: #total bytes	= " + fTotalNumBytesMonitored);
		PICLUtils.logText("Calculated values: #lowest offset= " + fLowestOffsetMonitored);
		PICLUtils.logText("Calculated values: #highest offset= " + fHighestOffsetMonitored);

	}

	private void releaseStorageLines() {
		Enumeration enum = fMonitoredStorageLines.elements();

		while (enum.hasMoreElements()) {
			StorageLine sl = (StorageLine)enum.nextElement();
//			if (sl.getLineOffset() == 0)  // this is the base source line
				sl.removeEventListener(this);
		}
	}

	private void monitorStorageLines() {
		Enumeration enum = fMonitoredStorageLines.elements();

		while (enum.hasMoreElements()) {
			StorageLine sl = (StorageLine)enum.nextElement();
//			if (sl.getLineOffset() == 0) // this is the base source line
				sl.addEventListener(this);
		}
	}


	/**
	 * @see PICLDebugElement#getChildren()
	 */
	public IDebugElement[] getChildren() throws DebugException {
		if ((TYPE_MAP.equals(fStorageType) || TYPE_STRUCTURE.equals(fStorageType)) && fChildren == Collections.EMPTY_LIST) {
			try {
				buildChildren();
				setChildrenHaveBeenBuilt(true);
			} catch(PICLException e) {
				StatusInfo status= new StatusInfo();
				status.setError(e.getMessage());
				throw new DebugException(status);
			}
		}
		childrenHaveBeenBuilt = true;
		return super.getChildren();
	}


	/**
	 * @see PICLDebugElement#hasChildren()
	 */
	public boolean hasChildren() {
		if (TYPE_MAP.equals(fStorageType) || TYPE_STRUCTURE.equals(fStorageType)) {
			return true;
		} else {
			return super.hasChildren();
		}
	}

	/**
	 *  convenience method for setting attributes of a parent PICLStorageMap (Structure or Map types)
	 */
	public void configureParentMap(String name, String address, String type, String layout, Node node ) {
		fName = name;
		fAddress = address;
		fStorageType = type;
		fLayout = layout;
		fNode = node;
	}

	/**
	 *  convenience method for setting attributes of a PICLStorageMap (anything but Structure or Map types)
	 */
	public void configureMap(String name, String type) {
		fName = name;
		fStorageType = type;
	}
	
	/**
	 * Gets the Storage Type.
	 * @return Returns a String
	 */
	public String getType() {
		return fStorageType;
	}

	/**
	 * Sets the Storage Type.
	 * @param fStorageType The fStorageType to set
	 */
	public void setType(String fStorageType) {
		this.fStorageType = fStorageType;
	}
	
	/**
	 * Gets the Layout file location.
	 * @return Returns a String
	 */
	public String getLayout() {
		return fLayout;
	}

	/**
	 * Sets the Layout file location.
	 * @param fLayout The Layout to set
	 */
	public void setLayout(String fLayout) {
		this.fLayout = fLayout;
	}

	/**
	 * Gets the childrenHaveBeenBuilt.
	 * @return Returns a boolean
	 */
	public boolean childrenHaveBeenBuilt() {
		return childrenHaveBeenBuilt;
	}

	/**
	 * Sets the childrenHaveBeenBuilt.
	 * @param childrenHaveBeenBuilt The childrenHaveBeenBuilt to set
	 */
	public void setChildrenHaveBeenBuilt(boolean childrenHaveBeenBuilt) {
		this.childrenHaveBeenBuilt = childrenHaveBeenBuilt;
	}

	/**
	 * Sets the XML Node required for delayed building of children
	 * @param fNode The Node to set
	 */
	public void setNode(Node fNode) {
		this.fNode = fNode;
	}

	private static String addDecimalOffsetToHexString(String calculatedAddress, int length) {
		//handle '0x' address strings
		if (calculatedAddress.toUpperCase().startsWith("0X")) {
			calculatedAddress = calculatedAddress.substring(2);
		}

		long longAddress = Long.parseLong(calculatedAddress, 16);
		longAddress += Long.parseLong(Integer.toString(length,16), 16);
		calculatedAddress = Long.toHexString(longAddress);

		if (calculatedAddress.length() < 8) {
			for (int j=0; calculatedAddress.length()<8; j++) {
				calculatedAddress = "0" + calculatedAddress;
			}
		}
		calculatedAddress = calculatedAddress.toUpperCase();
		return calculatedAddress;
	}


	public static PICLStorageMap mapStorage(PICLThread thread,
															IMarker monitorMarker,
															ViewInformation viewInfo,
															PICLDebugElement parent,
															String address, 
															int length, 
															String type) throws PICLException {
		PICLStorageMap map = null;
		StorageStyle style;
		
		if (type == null) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
		} else if (type.equals(PICLStorageMap.TYPE_16_BIT_INT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle16BitIntSigned);
		} else if (type.equals(PICLStorageMap.TYPE_16_BIT_UINT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle16BitIntUnsigned);
		} else if (type.equals(PICLStorageMap.TYPE_16_BIT_HINT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle16BitIntHex);
		} else if (type.equals(PICLStorageMap.TYPE_32_BIT_INT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle32BitIntSigned);
		} else if (type.equals(PICLStorageMap.TYPE_32_BIT_UINT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle32BitIntUnsigned);
		} else if (type.equals(PICLStorageMap.TYPE_32_BIT_HINT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle32BitIntHex);
		} else if (type.equals(PICLStorageMap.TYPE_32_BIT_FLOAT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle32BitFloat);
		} else if (type.equals(PICLStorageMap.TYPE_64_BIT_INT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle64BitIntSigned);
		} else if (type.equals(PICLStorageMap.TYPE_64_BIT_FLOAT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle64IEEE);
		} else if (type.equals(PICLStorageMap.TYPE_CHARACTER)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteCharacter);
		} else if (type.equals(PICLStorageMap.TYPE_HEX)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
		} else if (type.equals(PICLStorageMap.TYPE_ASCII)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteASCII);
		} else if (type.equals(PICLStorageMap.TYPE_EBCDIC)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteEBCDIC);
		} else if (type.equals(PICLStorageMap.TYPE_STRUCTURE)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
		} else if (type.equals(PICLStorageMap.TYPE_PADDING)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
		} else if (type.equals(PICLStorageMap.TYPE_BIT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
		} else if (type.equals(PICLStorageMap.TYPE_BITMASK)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
		} else if (type.equals(PICLStorageMap.TYPE_MAP)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
		} else {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
		}

		if ((style == null) || (length <= 0)) {	//this is a dummy parent object that does not actually monitor storage
//			map = thread.monitorStorageMap(parent, monitorMarker, address, viewInfo, 0, style, false);
			map = thread.monitorStorageMap(parent, monitorMarker, address, viewInfo, 1, style, false);
		} else {
			map = thread.monitorStorageMap(parent, monitorMarker, address, viewInfo, length, style, true);
		}
		return map;
	}


	private void buildBitChildren(String bitmaskContents) throws PICLException {
		String fChildName = null;
		String fChildType = null;
		int fChildLength = 0;
		String fChildLayout = null;

		String nodeName = null;
		String nodeValue = null;
		Node att = null;

		Node childNode = null;
		PICLStorageMap childStorageMap = null;

		String address = getAddress();
		if (address.toUpperCase().startsWith("0X")) {
			address = address.substring(2);
		}

		int offset = 0;
		NodeList childNodeList = fNode.getChildNodes();
		for (int i=0; i<childNodeList.getLength(); i++) {
			childNode = childNodeList.item(i);
			if (childNode instanceof Element) {
				NamedNodeMap cAttributes = childNode.getAttributes();
				for (int j=0; j<cAttributes.getLength(); j++) {
					att = cAttributes.item(j);
					nodeName = att.getNodeName();
					nodeValue = att.getNodeValue();
					if (nodeName.startsWith(HEADER)) {
						fChildName = nodeValue;
					} else if (nodeName.startsWith(TYPE)) {
						fChildType = nodeValue;
					} else if (nodeName.startsWith(LENGTH)) {
						fChildLength = Integer.parseInt(nodeValue);
					} else if (nodeName.startsWith(LAYOUT)) {
						fChildLayout = nodeValue;
					}
				}
				if (fChildName == null || fChildType == null || fChildLength <= 0) {
					throw new PICLException(PICLUtils.getResourceString(PREFIX+"error.malformed_file_parse2"));
				}
				if (fChildType.equals(PICLStorageMap.TYPE_BIT) || fChildType.equals(PICLStorageMap.TYPE_PADDING)) {
					
					childStorageMap = mapStorage(fThread, fMarker, fViewInfo, this, address, 0, fChildType);
					childStorageMap.fStorageBuffer = new StringBuffer(fChildLength+1);
					childStorageMap.fStorageBuffer.setLength(0);
					childStorageMap.fStorageBuffer.append(convertHexStringToBitString(bitmaskContents, offset, fChildLength));
					childStorageMap.fStorageBufferCurrent = true;					
					
					addChild(childStorageMap, false);
				} else { //only BIT objects can be a child of a BITMASK object
					throw new PICLException(PICLUtils.getResourceString(PREFIX+"error.malformed_file_parse2"));
				}
				offset += fChildLength;
			}
		}
	}
	
	private void buildChildren() throws PICLException {

		String fChildName = null;
		String fChildType = null;
		int fChildLength = 0;
		String fChildLayout = null;

		String nodeName = null;
		String nodeValue = null;
		Node att = null;

		Node childNode = null;
		PICLStorageMap childStorageMap = null;

		String address = getAddress();
		if (address.toUpperCase().startsWith("0X")) {
			address = address.substring(2);
		}

		NodeList childNodeList = fNode.getChildNodes();
		for (int i=0; i<childNodeList.getLength(); i++) {
			childNode = childNodeList.item(i);
			if (childNode instanceof Element) {
				NamedNodeMap cAttributes = childNode.getAttributes();
				for (int j=0; j<cAttributes.getLength(); j++) {
					att = cAttributes.item(j);
					nodeName = att.getNodeName();
					nodeValue = att.getNodeValue();
					if (nodeName.startsWith(HEADER)) {
						fChildName = nodeValue;
					} else if (nodeName.startsWith(TYPE)) {
						fChildType = nodeValue;
					} else if (nodeName.startsWith(LENGTH)) {
						fChildLength = Integer.parseInt(nodeValue);
					} else if (nodeName.startsWith(LAYOUT)) {
						fChildLayout = nodeValue;
					}
				}
				if (fChildName == null || fChildType == null || fChildLength <= 0) {
					throw new PICLException(PICLUtils.getResourceString(PREFIX+"error.malformed_file_parse2"));
				}
				if (fChildType.equals(PICLStorageMap.TYPE_MAP)) {
					/* this parent object is a layout.  we use the contents of the storage as the starting address for laying out children */
					//open/check/read the Layout XML file
					Element rootNode= openLayout(fChildLayout);
					
					//create the Layout PICLStorageMap object
					childStorageMap= mapStorage(fThread, fMarker, fViewInfo, this, address, fChildLength, fChildType);
					address = addDecimalOffsetToHexString(address, fChildLength);	//increment the address for the following siblings
					if (childStorageMap != null) {
						childStorageMap.configureParentMap(fChildName, 
																			childStorageMap.getStorageLine(0, fChildLength*2).toString(),
																			fChildType,
																			fChildLayout,
																			rootNode);
						//We do not need to build child nodes at this time.  See PICLStorageMap.getChildren() for delayed child creation
						addChild(childStorageMap, false);
					}
				} else if (fChildType.equals(PICLStorageMap.TYPE_STRUCTURE)) {
					/* this is a parent object that does not actually monitor storage, it just holds a place in the tree - note 0 length*/
					childStorageMap = mapStorage(fThread, fMarker, fViewInfo, this, address, 0, fChildType);
					//address = addDecimalOffsetToHexString(address, fChildLength); //ignore the length of the structure
					if (childStorageMap != null) {
						childStorageMap.configureParentMap(fChildName,
																			address,
																			fChildType,
																			null,
																			childNode);
						//We do not need to build child nodes at this time.  See PICLStorageMap.getChildren() for delayed child creation
						addChild(childStorageMap, false);
					}
				} else if (fChildType.equals(PICLStorageMap.TYPE_BITMASK)) {
					/* this parent object displays storage, but it also has children */
					childStorageMap = mapStorage(fThread, fMarker, fViewInfo, this, address, fChildLength, fChildType);
					//address = addDecimalOffsetToHexString(address, fChildLength); //what do we do here?
					if (childStorageMap != null) {
						childStorageMap.configureParentMap(fChildName,
																			address,
																			fChildType,
																			null,
																			childNode);

						childStorageMap.buildBitChildren(childStorageMap.fStorageBuffer.toString());
						childStorageMap.setChildrenHaveBeenBuilt(true);

						String bitString = convertHexStringToBitString(childStorageMap.fStorageBuffer.toString(), 0, fChildLength*8);
						childStorageMap.fStorageBuffer.setLength(0);
						childStorageMap.fStorageBuffer.append(bitString);

						addChild(childStorageMap, false);
					}
				} else {
					childStorageMap = mapStorage(fThread, fMarker, fViewInfo, this, address, fChildLength, fChildType);
					address = addDecimalOffsetToHexString(address, fChildLength);	//increment the address for the following siblings
					if (childStorageMap != null) {
						childStorageMap.setName(fChildName);
						childStorageMap.setType(fChildType);
						addChild(childStorageMap, false);
					}
				}
			}
		}
	}

	public static Element openLayout(String filename) throws PICLException {
		File file = new File(filename);
		if (!file.exists() || !file.isFile() || !file.canRead()) {
			throw new PICLException(PICLUtils.getFormattedString(PREFIX+"error.file_error", filename));
		}
		
		DOMParser parser = new DOMParser();
		Document fDOMLayout = null;
		try {
			parser.parse(FileSystem.toURL(file));
			fDOMLayout = parser.getDocument();
		} catch (Exception e) {
			throw new PICLException(PICLUtils.getFormattedString(PREFIX+"error.could_not_parse", filename));
		}
		
		if (fDOMLayout == null) {
			throw new PICLException(PICLUtils.getFormattedString(PREFIX+"error.could_not_parse", filename));
		}
		
		Element rootNode = (Element) fDOMLayout.getDocumentElement();
		if (rootNode == null) {
			throw new PICLException(PICLUtils.getFormattedString(PREFIX+"error.could_not_parse", filename));
		}

		NamedNodeMap attributes = rootNode.getAttributes();
		
//		if (!rootNode.getAttribute(TYPE).equals("LAYOUT")) {
			//return null;
			//fail;
//		}
		Node att = null;
		String nodeName = null;
		String nodeValue = null;

		String fLayoutHeader = null;
		int fLayoutLength = 0;
		for (int i=0; i<attributes.getLength(); i++) {
			att = attributes.item(i);
			nodeName = att.getNodeName();
			nodeValue = att.getNodeValue();
			if (nodeName.startsWith(HEADER)) {
				fLayoutHeader = nodeValue;
			} else if (nodeName.startsWith(LENGTH)) {
				fLayoutLength = Integer.parseInt(nodeValue);
			}
		}
		if (fLayoutHeader == null || fLayoutLength <= 0) {
			throw new PICLException(PICLUtils.getFormattedString(PREFIX+"error.malformed_file_parse", filename));
		}
		return rootNode;
	}
	
	
	public static String convertHexStringToBitString(String hexString, int bitOffset, int numOfBits) {
		String sRetVal = "?";

		if (hexString.indexOf("?") >= 0) return sRetVal;

		int size = (bitOffset + numOfBits)%4 == 0 ? (bitOffset + numOfBits)/4 : (bitOffset + numOfBits)/4 + 1;

		if(hexString.length() < size) return sRetVal;

		try {
			sRetVal = "";
			for(int i = 0; i < size; i ++) {
			//pre-pad the string with zeroes to the right size
			String s = Integer.toBinaryString(Character.digit(hexString.charAt(i), 16));
			if(s.length() < 4)
				s = "0000".substring(1, 4 - s.length() + 1) + s;
			sRetVal += s;
			}

		sRetVal = sRetVal.substring(bitOffset, bitOffset + numOfBits);
		} catch(Exception exc) {
			sRetVal = "?";
		}
		return sRetVal;
	}
}
