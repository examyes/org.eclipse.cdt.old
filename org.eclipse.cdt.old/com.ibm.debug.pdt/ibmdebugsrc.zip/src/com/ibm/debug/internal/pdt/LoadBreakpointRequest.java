package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IBreakpoint;

import com.ibm.debug.internal.pdt.model.Breakpoint;
import com.ibm.debug.internal.pdt.model.ModuleLoadBreakpoint;

class LoadBreakpointRequest extends EventBreakpointRequest {

	protected final String msgKey = super.msgKey + "load.";

    /**
     * Constructor for LoadBreakpointRequest
     */
    LoadBreakpointRequest(IBreakpoint breakpoint, PICLDebugTarget debugTarget) throws DebugException {
        super(breakpoint,debugTarget);
    }

    /**
     * @see BreakpointRequest#setBreakpoint()
     */
    public boolean setBreakpoint() throws PICLException {
        boolean rc = false;
        try {
            rc = getDebugTarget().getDebuggeeProcess().setModuleLoadBreakpoint(getEnabled(),
                                                       getModuleName(),
                                                       getEveryValue(),getFromValue(),getToValue(),
                                                       getThreadAsNumber(),
                                                       syncRequest(),
                                                       getMarker());
        } catch(IOException e) {
        	throw new PICLException(PICLUtils.getResourceString(super.msgKey + "senderror"));
       	}
		if (!rc)
	        throw new PICLException(PICLUtils.getResourceString(super.msgKey + "seterror"));

        return true;
    }
	/**
	 * Update the attributes of the marker with the values from the breakpoint
	 * @param The marker that matches the breakpoint
	 * @param The breakpoint from the engine
	 * @return true if successful
	 */

	public static boolean updateAttributes(IMarker marker, Breakpoint breakpoint, PICLDebugTarget debugTarget) {

		ModuleLoadBreakpoint bkp = (ModuleLoadBreakpoint)breakpoint;

		String[] attributeNames = {IPICLDebugConstants.UPDATE_BREAKPOINT,
								   IPICLDebugConstants.MODULE_NAME,
								   IPICLDebugConstants.THREAD,
								   IPICLDebugConstants.EVERY_VALUE,
								   IPICLDebugConstants.TO_VALUE,
								   IPICLDebugConstants.FROM_VALUE};

		Object[] values = {new Boolean(false),
						   bkp.getModuleName(),
						   String.valueOf(bkp.getThreadID()),
						   new Integer(bkp.getEveryVal()),
						   new Integer(bkp.getToVal()),
						   new Integer(bkp.getFromVal())};


		try {
	        marker.setAttributes(attributeNames, values);
		} catch(CoreException ce) {
			return false;
		}

		return true;
	}

}
