package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.model.MonitoredExpressionTreeNode;
import com.ibm.debug.internal.pdt.model.Representation;
import java.io.IOException;


/**
 * Request to change the representation of the expression node
 */

public class MonitorExpressionChangeRep extends MonitorRequest {

	private PICLVariable fPICLVariable = null;
	private Representation fRepresentation = null;

	/**
	 * Constructor for MonitorExpressionChangeRep
	 */
	public MonitorExpressionChangeRep(PICLDebugTarget debugTarget,
									  PICLVariable piclVariable,
									  Representation newRepresentation) {
		super(debugTarget);
		fPICLVariable = piclVariable;
		fRepresentation = newRepresentation;

	}

	/**
	 * @see PICLEngineRequest#execute()
	 */
	public void execute() throws PICLException {

		beginRequest();

		MonitoredExpressionTreeNode treeNode = fPICLVariable.getExpressionTreeNode();

		boolean rc = true;

		try {
			rc = treeNode.changeRepresentation(fRepresentation,syncRequest());

            if (!rc)
 	      		throw new PICLException(PICLUtils.getResourceString(msgKey + "send_error"));
		} catch(IOException ioe) {
			throw(new PICLException(PICLUtils.getResourceString(msgKey + "send_error")));
		} finally {
			endRequest();
		}
	}

}

