package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.epdc.*;
import java.io.*;

/**
 * Class representing format of different types. This class will have the
 * name of the type (of the format) as well as an index into the array
 * of possible formats for a given type.
 */
public class Representation extends DebugModelObject
{
  Representation(String name, short index)
  {
    if (Model.TRACE.EVT && Model.traceInfo())
      Model.TRACE.evt(4, "Creating Representation(name:" + name + ", index:" + index + ")");

    _name = name;
    _index = index;
  }

  /**
   * Return the index of a given representation
   */
  short index()
  {
    return _index;
  }

  /**
   * Return the name of a given representation
   */
  public String name()
  {
    return _name;
  }

  /**
   * Print the representation object information
   */
  public void print(PrintWriter printWriter)
  {
    if (Model.includePrintMethods)
    {
        printWriter.println("  Rep " + _index + ":  " + _name);
    }
  }

  private String _name;
  private short _index;
}
