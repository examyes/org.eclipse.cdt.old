package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

/**
 * Request to halt or suspend the debuggee
 * This is an asynchronous request
 */

public class SuspendProcessRequest extends ProgramControlRequest {

    /**
     * Constructor for SuspendProcessRequest
     */
    public SuspendProcessRequest(PICLDebugTarget debugTarget) {
        super(debugTarget);
    }

	/* (non-Javadoc)
	 * @see PICLEngineRequest#execute()
	 */
    public void execute() throws PICLException {

		// no begin request because another request is pending

    	try {
	    	fDebugTarget.getDebuggeeProcess().halt(syncRequest());
    	} catch(IOException ioe) {
			throw new PICLException(PICLUtils.getResourceString(msgKey + "send_error"));
    	}

    	// NOTE: there is no call to endRequest() because this request is not complete yet...  At some time later the
    	//       model will fire an event that represents the end of this request.

    }

}

