package com.ibm.debug.internal.pdt.connection;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

/** Establish a connection between the UI and the debug engine using a socket.
 */

public class SocketConnection extends Connection {
	private Socket socket;
	private ServerSocket serverSocket;
	private int connectAttempts = 100;
	private int sleepInterval = 500;
	private int mode = AS_CLIENT;

	public SocketConnection(String host, String portAsString, int mode)
		throws IOException {
		this.mode = mode;
		init(host, portAsString);
	}
	public SocketConnection(
		String host,
		String portAsString,
		int mode,
		int connectAttempts,
		int sleepInterval)
		throws IOException {
		this.connectAttempts = connectAttempts;
		this.sleepInterval = sleepInterval;
		this.mode = mode;
		init(host, portAsString);
	}
	public SocketConnection(InetAddress internetAddress, int portNumber)
		throws IOException {
		mode = AS_CLIENT;
		initClient(internetAddress, portNumber);
	}
	public SocketConnection(
		InetAddress internetAddress,
		int portNumber,
		int connectAttempts,
		int sleepInterval)
		throws IOException {
		this.connectAttempts = connectAttempts;
		this.sleepInterval = sleepInterval;
		mode = AS_CLIENT;
		initClient(internetAddress, portNumber);
	}
	public SocketConnection(Socket socket) throws IOException {
		mode = AS_CLIENT;
		this.socket = socket;
		super.setOutputStream(socket.getOutputStream());
		super.setInputStream(socket.getInputStream());
	}

	public void close() throws IOException {
		super.close();

		if (mode == AS_CLIENT) {
			if (socket != null)
				socket.close();
		} else {
			if (serverSocket != null)
				serverSocket.close();
		}
	}
	private void init(String host, String portAsString) throws IOException {
		int port;
		try {
			port = Integer.parseInt(portAsString);
		} catch (NumberFormatException e) {
			throw new IOException("Socket port not a number:" + portAsString);
		}

		if (mode == AS_CLIENT)
			initClient(InetAddress.getByName(host), port);
		else
			initServer(port);
	}
	private void initClient(InetAddress internetAddress, int portNumber)
		throws IOException {
		boolean connected = false;
		int attempts = 0;

		while (!connected) {
			try {
				socket = new Socket(internetAddress, portNumber);

				connected = true;

				super.setOutputStream(socket.getOutputStream());
				super.setInputStream(socket.getInputStream());
				socket.setTcpNoDelay(true); // Send data immediately (defect 16268)

			} catch (ConnectException excp) // Could not connect
				{
				if (++attempts == connectAttempts)
					throw excp;
				else
					try {
						Thread.sleep(sleepInterval, 0);
					} catch (InterruptedException excp2) {
					}
			}
		}

	}
	private void initServer(int portNumber) throws IOException {
		boolean connected = false;
		int attempts = 0;

		while (!connected) {
			try {
				serverSocket = new ServerSocket(portNumber);
				connected = true;
			} catch (IOException excp) {
				if (++attempts == connectAttempts)
					throw excp;
				else
					try {
						Thread.sleep(sleepInterval, 0);
					} catch (InterruptedException excp2) {
					}
			}
		}

	}
}
