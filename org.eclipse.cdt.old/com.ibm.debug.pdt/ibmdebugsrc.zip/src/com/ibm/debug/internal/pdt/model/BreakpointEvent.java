package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * The super class for all breakpoint events.
 */

public abstract class BreakpointEvent extends ModelEvent
{
  BreakpointEvent(Object source, Breakpoint breakpoint, int requestCode)
  {
    super(source, requestCode);
    _breakpoint = breakpoint;
  }

  public Breakpoint getBreakpoint()
  {
    return _breakpoint;
  }

  private Breakpoint _breakpoint;
}
