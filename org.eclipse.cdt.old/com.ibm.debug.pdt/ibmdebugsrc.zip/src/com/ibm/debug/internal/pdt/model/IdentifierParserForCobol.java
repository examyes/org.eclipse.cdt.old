package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1999, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * This class finds identifiers in Cobol strings.
 */
public class IdentifierParserForCobol extends DelimitersBasedIdentifierParser
{
   static final private char [] delims = {' ', '.', '<', '(', '+', '$', '*', ')', ';',
                                          ':', '/', ',', '>', '=', '\"', '\''};

   /**
    * Setup
    */
   public IdentifierParserForCobol() {}

   /**
    * This method must be overriden to return the delimiters for that language.
    */
   public char [] getDelimiters()
   {
      return delims;
   }
} // end class IdentifierParserForCobol




