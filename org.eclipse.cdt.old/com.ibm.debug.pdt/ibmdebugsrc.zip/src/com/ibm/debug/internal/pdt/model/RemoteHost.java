package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.connection.ConnectionInfo;
import java.net.InetAddress;

/** Use this class when the debug engine and SUI are running on
 *  different machines.
 */

public class RemoteHost extends Host
{
  RemoteHost(Object address)
  {
    super(address);
  }

  public boolean loadEngine(EngineInfo engineInfo,
                            ProductInfo productInfo,
                            ConnectionInfo connectionInfo,
                            EngineArgs engineArgs)
  {
    return false;
  }
}
