package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * A class which can be used to save and restore "restorable" Model
 * objects e.g. breakpoints, monitored exprs, etc. When this class is
 * used, the Model objects will be saved persistently i.e. in a file.
 * @see TransientRestorableObjects
 */

public class PersistentRestorableObjects extends RestorableObjects
{
  /**
   * @param process The process into which objects will be restored and
   * from which objects will be saved. This can be changed by calling
   * setProcess.
   * @param flags Flags which control the saving and restoring of objects.
   * Initially, both the save flags and the restore flags are set to the
   * value of the 'flags' parameter and are therefore the same.
   * Both sets of flags can be changed by calling setSaveFlags and setRestoreFlags.
   * @param fileName The name of the file where objects will be saved to and
   * restored from.
   */

  public PersistentRestorableObjects(DebuggeeProcess process, int flags, String fileName)
  {
    super(process,
          new PersistentSerialization(fileName, flags | SaveRestoreFlags.RESTORABLE_OBJECTS),
          flags);
  }

  /**
   * Get the name of the file being used to save and restore objects.
   */

  public String getFileName()
  {
    return ((PersistentSerialization)_serialization).getFileName();
  }
}
