package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.debug.core.Launch;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.plugin.AbstractUIPlugin;

import com.ibm.debug.internal.pdt.ui.actions.DebugViewMenuListener;
import com.ibm.debug.internal.pdt.ui.editor.DebuggerDocumentProvider;

/**
 * Represents the compiled PICL plugin
 */
public class PICLDebugPlugin extends AbstractUIPlugin {

	private static PICLDebugPlugin instance;
	private boolean debugViewMenuListenerAdded = false;
	private static IPluginDescriptor fPluginDescriptor = null;
	private DebuggerDocumentProvider editorDocumentProvider = null;

	// logging settings
	public static boolean logging = false;
	public static boolean events = false;
	public static boolean dumpEPDC = false;
	public static String dumpFile = "epdcdump";
	public static String DBG = null;
	public static String EVT = null;
	public static String ERR = null;
	public static boolean MODEL = false;
	public static ILog logFile = null;
	
	/**
	 * Constructor for PICLDebugPlugin
	 */
	public PICLDebugPlugin(IPluginDescriptor descriptor) {
		super(descriptor);
		instance = this;

		// Code copied from GDBViewPlugin
		fPluginDescriptor = getDescriptor();
		
		// load the logging settings
		// only if the main debug setting is on
		if (isDebugging()) {
			
			logFile = getLog();
			
			String id = fPluginDescriptor.getUniqueIdentifier();
			String test = Platform.getDebugOption(id + "/debug/events");
			if (test != null)
				events = test.equals("true");
			test = Platform.getDebugOption(id + "/debug/logging");
			if (test !=null)
				logging = test.equals("true");
			
			test = Platform.getDebugOption(id + "/debug/dumpepdc");
			if (test != null)
				dumpEPDC = test.equals("true");				
			
			test = Platform.getDebugOption(id + "/debug/dumpfile");
			if (test != null)
				dumpFile = test;
				
			test = Platform.getDebugOption(id + "/debug/jt_dbg");
			if (test != null) 
				DBG = test;

			test = Platform.getDebugOption(id + "/debug/jt_evt");
			if (test != null) 
				EVT = test;
				
			test = Platform.getDebugOption(id + "/debug/jt_err");
			if (test != null)
				ERR = test;

			test = Platform.getDebugOption(id + "/debug/model");
			if (test != null) {
				MODEL = test.equals("true");
				if (MODEL)
					DBG = "3";  // in order for model to work DBG must also be on.
			}
				
		}

		PICLUtils.logText("PICLDebugPlugin loaded");
	}

	public static String getPluginID() {
		return fPluginDescriptor.getUniqueIdentifier();
	}

	public static PICLDebugPlugin getInstance() {
		return instance;
	}

	public static PICLDebugPlugin getDefault() {
		return instance;
	}

	public void startup() throws CoreException {
		PICLUtils.logText("In startup()");
		super.startup();
	}

	/**
	 * @see Plugin#shutdown()
	 */
	public void shutdown() throws CoreException {
		PICLUtils.logText("In shutdown()");
		super.shutdown();
	}

	public static IWorkbenchWindow getActiveWorkbenchWindow() {
		try {
			return getDefault().getWorkbench().getActiveWorkbenchWindow();
		} catch(NullPointerException e) {
			return null;
		}
	}

	/**
	 * Returns the active workbench shell.
	 * Note: This method should only be called from a UI thread.
	 * When running on a non-UI thread, use getShell() method.
	 */
	public static Shell getActiveWorkbenchShell() {
		return getActiveWorkbenchWindow().getShell();
	}

	/**
	 * Returns the currently selected debug target in the Debug View
	 * Returns the first <code>IDebugTarget</code> that has a launch and is associated with a debug target.
	 * If no debug targets, returns null.
	 */
	public static IDebugTarget determineCurrentDebugTarget() {

		IWorkbenchWindow w= PICLDebugPlugin.getActiveWorkbenchWindow();
		if (w == null) return null;

		IWorkbenchPage p= w.getActivePage();
		if (p == null) return null;

		IViewPart view= p.findView(IDebugUIConstants.ID_DEBUG_VIEW);
		if ((view==null) || !(view instanceof IDebugView)) return null;

		try {
			view= p.showView(IDebugUIConstants.ID_DEBUG_VIEW);
		} catch (PartInitException e) {
			PICLUtils.logError(e);
			return null;
		}

		Viewer viewer = ((IDebugView)view).getViewer();
		if (viewer == null) return null;

		ISelection sel = viewer.getSelection();
		if ((sel == null) || !(sel instanceof IStructuredSelection)) return null;
		
		Object elem = ((IStructuredSelection)sel).getFirstElement();
		if (elem == null) return null;
		
		//a Launch is not an IDebugElement, but its debugtarget should be
		if (elem instanceof Launch) {
			elem = ((Launch)elem).getDebugTarget();
		}

		//any IDebugElement can get its debugtarget
		if (! (elem instanceof IDebugElement) ) return null;
		return ((IDebugElement)elem).getDebugTarget();
	}

	/**
	 * @see AbstractUIPlugin#saveDialogSettings()
	 * Allows access to the protected method super.saveDialogSettings().
	 */
	public void saveDialogSettings()
	{
		super.saveDialogSettings();  //protected method
	}

	/**
 	* Debug ui thread safe access to a shell
 	*/
	public Shell getShell() {
		IWorkbench workbench= getWorkbench();
		if (workbench != null) {
			IWorkbenchWindow[] windows= workbench.getWorkbenchWindows();
			if (windows != null && windows.length > 0) {
				Shell shell= windows[0].getShell();
				if (!shell.isDisposed()) {
					return shell;
				}
			}
		}
		return null;
	}

	/**
 	* Debug ui thread safe access to a display
 	*/
	public Display getDisplay() {
		Shell shell = getShell();
		if (shell != null)
			return shell.getDisplay();

		return null;
	}



	
	/**
 	* Creates an extension.  If the extension plugin has not
 	* been loaded a busy cursor will be activated during the duration of
 	* the load.
 	*
 	* @param element the config element defining the extension
 	* @param classAttribute the name of the attribute carrying the class
 	* @returns the extension object
 	*/
	public static Object createExtension(final IConfigurationElement element, final String classAttribute) throws CoreException {
		// If plugin has been loaded create extension.
		// Otherwise, show busy cursor then create extension.
		IPluginDescriptor plugin = element.getDeclaringExtension().getDeclaringPluginDescriptor();
		if (plugin.isPluginActivated()) {
			return element.createExecutableExtension(classAttribute);
		} else {
			final Object [] ret = new Object[1];
			final CoreException [] exc = new CoreException[1];
			BusyIndicator.showWhile(null, new Runnable() {
				public void run() {
					try {
						ret[0] = element.createExecutableExtension(classAttribute);
					} catch (CoreException e) {
						exc[0] = e;
					}
				}
			});
			if (exc[0] != null) {
				throw exc[0];
			}
			else {
				return ret[0];
			}
		}
	}

	protected static void displayError(String titleCode, String msgCode) {
		String title = PICLUtils.getResourceString(titleCode);
		String msg = PICLUtils.getResourceString(msgCode);
		MessageDialog.openError(PICLDebugPlugin.getActiveWorkbenchShell(), title, msg);
	}

	/**
	 * Returns the document provider used for the debugger's editor
	 */
	public DebuggerDocumentProvider getDebuggerEditorDocumentProvider() {
		if (editorDocumentProvider == null)
			editorDocumentProvider = new DebuggerDocumentProvider();
		return editorDocumentProvider;
	}


	

}
