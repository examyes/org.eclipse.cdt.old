package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.epdc.*;
import java.io.*;

public class EngineExceptionCapabilities extends EngineCapabilitiesGroup
{
  EngineExceptionCapabilities(EFunctCustTable FCTBits)
  {
    super(FCTBits);
  }

  /**
   * Compare one set of capabilities with another to see if they are the
   * same. This is typically used to find out if a given set of capabilities
   * has changed when an EngineCapabilitiesChangedEvent is fired. This event
   * contains the old set of engine capabilities as well as the new one.
   * Calling isSameAs to compare the old set of capabilities with the new one
   * allows client code to find out what has changed on
   * less granular basis than comparing individual capabilities. If a set of
   * capabilities has changed then the client may want to compare individual
   * capabilities within that set to see exactly what has changed.
   */

  public boolean isSameAs(EngineExceptionCapabilities capabilities)
  {
    if (capabilities == null)
       return false;
    else
       return getBits() == capabilities.getBits();
  }

  int getBits()
  {
    return getFCTBits().getExceptionCapabilities();
  }

  public boolean exceptionFilterSupported()
  {
    return getFCTBits().exceptionFilterSupported();
  }

  public boolean exceptionExamineSupported()
  {
    return getFCTBits().exceptionExamineSupported();
  }

  public boolean exceptionStepSupported()
  {
    return getFCTBits().exceptionStepSupported();
  }

  public boolean exceptionRunSupported()
  {
    return getFCTBits().exceptionRunSupported();
  }

  public void print(PrintWriter printWriter)
  {
    if (Model.includePrintMethods)
    {
       printWriter.println("Engine Exception Capabilities:");
    }
  }
}
