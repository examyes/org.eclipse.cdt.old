package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * The super class for all part events.
 */

public abstract class PartEvent extends ModelEvent
{
  PartEvent(Object source, Part part, int requestCode)
  {
    super(source, requestCode);
    _part = part;
  }

  public Part getPart()
  {
    return _part;
  }

  private Part _part;
}
