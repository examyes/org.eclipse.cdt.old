package com.ibm.debug.internal.pdt.ui.views;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.DebugEvent;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.IDebugEventSetListener;
import org.eclipse.debug.core.Launch;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.internal.ui.DebugUIPlugin;
import org.eclipse.debug.ui.AbstractDebugView;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;

import com.ibm.debug.epdc.EPDC;
import com.ibm.debug.internal.pdt.EngineSuppliedViewEditorInput;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PDTModelPresentation;
import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLFile;
import com.ibm.debug.internal.pdt.PICLFunction;
import com.ibm.debug.internal.pdt.PICLModule;
import com.ibm.debug.internal.pdt.PICLModuleParent;
import com.ibm.debug.internal.pdt.PICLPart;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.Location;
import com.ibm.debug.internal.pdt.model.ViewFile;
import com.ibm.debug.internal.pdt.ui.actions.AddProgramAction;
import com.ibm.debug.internal.pdt.ui.actions.CopyTreeViewToClipboardAction;
import com.ibm.debug.internal.pdt.ui.actions.ModulesFilterAction;
import com.ibm.debug.internal.pdt.ui.actions.PrintTreeViewAction;
import com.ibm.debug.internal.pdt.ui.actions.RemoveProgramAction;
import com.ibm.debug.internal.pdt.ui.actions.SetFunctionBreakpointAction;
import com.ibm.debug.pdt.WorkspaceSourceLocator;

public class ModulesView extends AbstractDebugView implements ISelectionListener, IDoubleClickListener, IDebugEventSetListener {

	private final static String PREFIX= "ModulesView.";
	private TreeViewer fTreeViewer = null;
	private PICLDebugTarget fCurrentDebugTarget = null;
	private String fMODULES_NOT_AVAILABLE = PICLUtils.getResourceString(PREFIX + "modules_not_available");
	
	// actions
	private ModulesFilterAction fModulesFilterAction;
	private CopyTreeViewToClipboardAction fCopyTreeViewToClipboardAction;
	private PrintTreeViewAction fPrintTreeViewAction;
	private SetFunctionBreakpointAction fSetFunctionBreakpointAction;

	private AddProgramAction fAddProgramAction = null;
	private boolean fAddProgramAdded = false;
	private RemoveProgramAction fRemoveProgramAction = null;

	private IToolBarManager ftbm = null;
	
	/**
	 * @see AbstractDebugView#createViewer(Composite)
	 */
	protected Viewer createViewer(Composite parent) {
		PICLUtils.logText("ModulesView.createViewer()");

		// add this view as a listener of the main debug view selection events
		addListeners();
		fTreeViewer = new TreeViewer(parent, SWT.SINGLE);
		fTreeViewer.setContentProvider(new ModulesContentProvider());
		fTreeViewer.setLabelProvider(new PDTModelPresentation());
		setTitleToolTip(PICLUtils.getResourceString(PREFIX + "tooltip"));
		fTreeViewer.addDoubleClickListener(this);
		getSite().setSelectionProvider(fTreeViewer);

		return fTreeViewer;
	}

	/**
	 * @see AbstractDebugView#createActions()
	 */
	protected void createActions() {
		PICLUtils.logText("ModulesView.createActions()");
		fModulesFilterAction = new ModulesFilterAction(fTreeViewer);
		fSetFunctionBreakpointAction = new SetFunctionBreakpointAction(fTreeViewer);
		fRemoveProgramAction = new RemoveProgramAction(fTreeViewer);

		fCopyTreeViewToClipboardAction= new CopyTreeViewToClipboardAction(fTreeViewer);
		fCopyTreeViewToClipboardAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_COPY_VIEW_TO_CLIPBOARD));
		fCopyTreeViewToClipboardAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_COPY_VIEW_TO_CLIPBOARD));
		fCopyTreeViewToClipboardAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_COPY_VIEW_TO_CLIPBOARD));

		fPrintTreeViewAction= new PrintTreeViewAction(fTreeViewer, PICLUtils.getResourceString(PREFIX+"printjobtitle"));
		fPrintTreeViewAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_PRINT_VIEW));
		fPrintTreeViewAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_PRINT_VIEW));
		fPrintTreeViewAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_PRINT_VIEW));
	
	}

	/**
	 * @see AbstractDebugView#configureToolBar(IToolBarManager)
	 */
	protected void configureToolBar(IToolBarManager tbm) {
		PICLUtils.logText("ModulesView.configureToolBar()");
		ftbm = tbm;
		
		tbm.add(fModulesFilterAction);
		tbm.add(new Separator(this.getClass().getName()));
		tbm.add(fCopyTreeViewToClipboardAction);
		tbm.add(fPrintTreeViewAction);
	}

	/**
	 * @see AbstractDebugView#createActions()
	 */
	protected String getHelpContextId() {
		PICLUtils.logText("ModulesView.getHelpContextId()");
		return PICLUtils.getHelpResourceString("ModulesView");
	}

	/**
	 * @see AbstractDebugView#fillContextMenu(IMenuManager)
	 */
	protected void fillContextMenu(IMenuManager mm) {
		PICLUtils.logText("ModulesView.fillContextMenu()");
		StructuredSelection sel = (StructuredSelection)fTreeViewer.getSelection();
		if (sel.EMPTY == StructuredSelection.EMPTY && sel.size() == 1) {   // for now support a single selection
			
			// process PICLfunction menu items
			if (sel.getFirstElement() instanceof PICLFunction) {
				// check if target supports function breakpoints
				if (fCurrentDebugTarget.supportsBrkptType(IPICLDebugConstants.PICL_ENTRY_BREAKPOINT))
					mm.add(fSetFunctionBreakpointAction);
			}
			
			// determine PICLPart menu items
			if (sel.getFirstElement() instanceof PICLPart) {
				// check if remove program supported
				if (supportsRemoveProgram(fCurrentDebugTarget))
					mm.add(fRemoveProgramAction);					
			}
		}
		mm.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
	}

	public void partClosed(IWorkbenchPart part )
	{
		if(!(part instanceof ModulesView))
			return;
		//TODO: stop add/update events from model
		removeListeners();
		try{
			if(fTreeViewer != null)
				((TreeViewer)fTreeViewer).removeDoubleClickListener(this);
		}catch(Exception e) {}

		super.partClosed(part);
	}

	
    /**
     * @see IDoubleClickListener#doubleClick(DoubleClickEvent)
     */
    public void doubleClick(DoubleClickEvent event) {
		PICLUtils.logText("Modulesview double click event");
    	IStructuredSelection structuredSelection = (IStructuredSelection)event.getSelection();

    	if (structuredSelection.size() != 1)   // only expand/collapse if 1 selected
    		return;

    	Object selection = structuredSelection.getFirstElement();

		// Only types PICLFile and PICLFunction support going to the file

		if (selection instanceof PICLFile ||
			selection instanceof PICLFunction ) {
	
			WorkspaceSourceLocator wsl = (WorkspaceSourceLocator)((PICLDebugElement)selection).getLaunch().getSourceLocator();
			IEditorInput editorInput = ((PICLDebugElement)selection).getEditorInput();
			IMarker locationMarker = null;
	
			PICLFile piclFile = null;
			PICLFunction piclFunction = null;
			
			String fileName;
			if (selection instanceof PICLFile) {
				piclFile = (PICLFile)selection;
				fileName = piclFile.getFileName();
			} else {
				piclFunction = (PICLFunction)selection;
				fileName = piclFunction.getFileName();
				try {
					locationMarker = wsl.getHomeProject().createMarker(IPICLDebugConstants.PICL_LOCATION_MARKER);
					locationMarker.setAttribute(IMarker.LINE_NUMBER, piclFunction.getLineNumber());
				} catch(CoreException e) {}
			}
				
			// show in the editor
			IFile file = wsl.findFile(fileName);
			IWorkbenchWindow dwindow= DebugUIPlugin.getActiveWorkbenchWindow();
			if (dwindow == null)
				return;
			IWorkbenchPage page= dwindow.getActivePage();
			if (page == null)
				return;
			
			if (file != null) {   // file found in workspace
				try {
					IEditorPart ep = page.openEditor(file);
					if (locationMarker != null) {
						ep.gotoMarker(locationMarker);
						locationMarker.delete();
						locationMarker = null;
					}
				} catch(PartInitException e) {}
				  catch(CoreException ce) {}
				return;
			} else {  // file is not in the workspace so use engine supplied view
				PDTModelPresentation mp = new PDTModelPresentation();
				if (editorInput == null) {
					PICLDebugTarget dt = (PICLDebugTarget)((PICLDebugElement)selection).getDebugTarget();
					Location loc = null;

					if (piclFunction != null) { // PICLFunction
						try {
							loc = piclFunction.getFunction().getLocation();
							loc.file().verify();  // make sure it is verified
							if (!loc.file().isVerified())
								return;
						} catch(IOException e) {
							return;
						}
						try {
							locationMarker = wsl.getHomeProject().createMarker(IPICLDebugConstants.PICL_LOCATION_MARKER);
							locationMarker.setAttribute(IMarker.LINE_NUMBER, piclFunction.getLineNumber());
						} catch(CoreException e) {}
					} else { // PICLFile
						ViewFile vf = piclFile.getViewFile();
						if (vf == null)
							return;
						try {
							vf.verify();
						} catch(IOException e) {  // any failure then return
							return;
						} // force it to be verified
						if (!vf.isVerified())   // a valid view file couldn't be found
							return;
						else
							loc = new Location(vf,1);
					}
					editorInput = new EngineSuppliedViewEditorInput(loc,dt);
					if (editorInput == null)
						return;
					((EngineSuppliedViewEditorInput)editorInput).setResource(wsl.getHomeProject());
					((PICLDebugElement)selection).setEditorInput(editorInput);
				}
				String eid = mp.getEditorId(editorInput, null);
				if (eid == null || eid.equals(""))
					return;
				try {
					IEditorPart ep = page.openEditor(editorInput,eid);
					if (locationMarker != null) {
						ep.gotoMarker(locationMarker);
						locationMarker.delete();
						locationMarker = null;
					}
				} catch(PartInitException e) {}
				  catch(CoreException ce) {}
				return;
			}
			
				
				
		} else {
	    	if (fTreeViewer.getExpandedState(selection))
	   			fTreeViewer.collapseToLevel(selection,1);
	   		else
	   			fTreeViewer.expandToLevel(selection,1);
		}


    }

	/**
	 * @see ISelectionListener#selectionChanged(IWorkbenchPart, ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		PICLUtils.logText("ModulesView.selectionChanged()");
		
		fCurrentDebugTarget = null; 

		if(fTreeViewer == null  || fTreeViewer.getContentProvider() == null) {
			showMessage(fMODULES_NOT_AVAILABLE);
			return;
		}

		IStructuredSelection ssel = (IStructuredSelection) selection;

		PICLDebugTarget dt = null;

		// check if the selection is an active PICLDebugElement
		if ((ssel.getFirstElement() instanceof PICLDebugElement)) {
			IDebugTarget debugTarget = ((PICLDebugElement)ssel.getFirstElement()).getDebugTarget();
			if (debugTarget instanceof PICLDebugTarget)
				dt = (PICLDebugTarget)debugTarget;
		} else
			if ((ssel.getFirstElement() instanceof Launch)) {
				Launch l = (Launch)ssel.getFirstElement();
				if (l.getDebugTarget() instanceof PICLDebugElement)
					dt = (PICLDebugTarget)l.getDebugTarget();
			}

		if (dt == null)
			fTreeViewer.setInput(null);
		else if (dt.isTerminated() || !dt.supportsModulesView())
			showMessage(fMODULES_NOT_AVAILABLE);
		else {  // valid debug target ... make sure modules view shows correct info
			fCurrentDebugTarget = dt;
			// check to see if a change is required
			showViewer();

			// check if Add program toolbar icon should be added
			if (supportsAddProgram(dt) && !fAddProgramAdded) {
				if (fAddProgramAction == null)
					fAddProgramAction = new AddProgramAction(dt);
				ftbm.insertBefore(fModulesFilterAction.getId(),fAddProgramAction);
				ftbm.update(false);
				fAddProgramAdded = true;
			} else if (!supportsAddProgram(dt) && fAddProgramAdded) {
				ftbm.remove(fAddProgramAction.getId());
				ftbm.update(false);
				fAddProgramAdded = false;
			}

			// set the title of this view based on the connected engine
			if (iSeriesEngine(dt))
				setTitle(PICLUtils.getResourceString(PREFIX + "printjobtitle.400"));
			else
				setTitle(PICLUtils.getResourceString(PREFIX + "printjobtitle"));


			// set the debug target so that if required the add program dialog will have the current
			// debug target.
			if (fAddProgramAction != null)
				fAddProgramAction.setDebugTarget(dt);

			PICLModuleParent moduleParent = dt.getModuleParent();

			if (fTreeViewer.getInput() != null && fTreeViewer.getInput().equals(moduleParent)) { // no change required because it matches
				fTreeViewer.refresh();
				return;
			} else {
				// first store off the expanded setting of the current tree
				if (fTreeViewer.getInput() != null)
					((PICLModuleParent)fTreeViewer.getInput()).saveExpandedElements(fTreeViewer.getExpandedElements());
				// set it to the new module parent
				fTreeViewer.setInput(moduleParent);
				// restore expanded setting
				if (moduleParent != null && moduleParent.getExpandedElements() != null)
					fTreeViewer.setExpandedElements(moduleParent.getExpandedElements());
			}
		}
	}

	private void addListeners() {
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().addSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
		DebugPlugin.getDefault().addDebugEventListener(this);
	}
	
	private void removeListeners() {
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().removeSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
		DebugPlugin.getDefault().removeDebugEventListener(this);
	}

	private boolean supportsAddProgram(PICLDebugTarget dt) {
		return dt.getDebugEngine().getCapabilities().getFileCapabilities().moduleAddSupported();
	}

	private boolean supportsRemoveProgram(PICLDebugTarget dt) {
		return dt.getDebugEngine().getCapabilities().getFileCapabilities().moduleRemoveSupported();
	}
	
	private boolean iSeriesEngine(PICLDebugTarget dt) {
		return dt.getDebugEngine().host().getPlatformID() == EPDC.PLATFORM_ID_AS400;
	}
	
	/* (non-Javadoc)
	 * @see IDebugEventSetListener#handleDebugEvents(DebugEvent[])
	 */
	public void handleDebugEvents(DebugEvent[] events) {
		for (int i=0; i<events.length; i++) {
			IDebugElement element = (IDebugElement)events[i].getSource();
			// need to update this view if a debugevent involves a PICLModule
			// --or-- a debug target terminates (this will clean up the view contents)
			if (element instanceof PICLModule) {
				PICLDebugPlugin.getInstance().getShell().getDisplay().asyncExec(new Runnable() {
					public void run() {
						fTreeViewer.refresh();
					}
				});
			}				
			if (element instanceof PICLDebugTarget && events[i].getKind() == DebugEvent.TERMINATE) {
				PICLDebugPlugin.getInstance().getShell().getDisplay().asyncExec(new Runnable() {
					public void run() {
						fTreeViewer.refresh();
						showMessage(fMODULES_NOT_AVAILABLE);
					}
				});
			}				
		}
	}

}
