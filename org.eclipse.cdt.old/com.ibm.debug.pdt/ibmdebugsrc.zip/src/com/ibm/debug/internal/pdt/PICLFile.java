package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.PropertyDescriptor;

import com.ibm.debug.internal.pdt.model.Function;
import com.ibm.debug.internal.pdt.model.ViewFile;

public class PICLFile extends PICLDebugElement 
						implements IPropertySource {

	private ViewFile fViewFile = null;
	private boolean fFunctionsRetrieved = false;
	// list of attributes for display
	private static final String PREFIX = "picl_file.";
	private static final String FILE_NAME = PREFIX + "file_name";
	private static final String NUM_LINES = PREFIX + "num_lines";
	private static final String QUAL_NAME = PREFIX + "qualified_name";
	private static final String RECORDLENGTH = PREFIX + "recordlength";
	private static final String VERIFIED = PREFIX + "verified";
	private static final String LOCAL_SOURCE = PREFIX + "local_source";

	/**
	 * Constructor for PICLFile
	 */
	public PICLFile(IDebugElement parent, ViewFile viewFile, IDebugTarget debugTarget) {
		super(parent, debugTarget);

		fViewFile = viewFile;
	}

	/**
	 * @see PICLDebugElement#doCleanupDetails()
	 */
	protected void doCleanupDetails() {
		fViewFile = null;
	}

	/**
	 * Removes this child from the collection of children for this element.
	 * Fires a termination event for the child.
	 * Cleanup depends on the order of operations in this method.
	 */
	public final void removeChild(IDebugElement child) {

		// first call the child to clean itself up and then remove it
		((PICLDebugElement)child).doCleanup();

		fChildren.remove(child);
	}

	/**
	 * @see PICLDebugElement#getLabel(boolean)
	 */
	public String getLabel(boolean qualified) {
		String label = null;
		try {
			if (!fViewFile.view().isSourceView())
				label = PICLUtils.getResourceString("picl_file.no_source");
			else
				label = fViewFile.name();
		} catch(IOException ioe) {
			label = PICLUtils.getResourceString("picl_file.source_error");
		}
		if (label == null)
			label = PICLUtils.getResourceString("picl_file.no_source");
		return label;
	}

	


	/**
	 * @see PICLDebugElement#hasChildren()
	 */
	public boolean hasChildren() {
		return true;
	}

	/**
	 * @see PICLDebugElement#getChildren()
	 */
	public IDebugElement[] getChildren() throws DebugException {
		if (!fFunctionsRetrieved) {
			Vector functions = null;
			try {
				functions = fViewFile.getFunctions();
			} catch(IOException ioe) {}
			if (functions != null) {
				Iterator iter = functions.iterator();
				while (iter.hasNext()) {
					Function f = (Function)iter.next();
					if (f != null)
						addChild(new PICLFunction(this, f, getDebugTarget()), false);
				}
			}
			fFunctionsRetrieved = true;

		}
		return super.getChildren();

	}

	/**
	 * @see PICLDebugElement#getChildrenNoExpand()
	 */
	public IDebugElement[] getChildrenNoExpand() throws DebugException {
		return super.getChildren();
	}

	public boolean hasSource() {
		return fViewFile.view().isSourceView();
	}

	/**
	 * return the file name
	 * @return file name
	 */
	public String getFileName() {
		try {
			return fViewFile.baseFileName();
		} catch(IOException ioe) {}

		return null;
	}
	/**
	 * returns the line number in the view file
	 * @return line number, returns 0 if no line number
	 */
	public int getLineNumber() {
		return 1;
	}

	/**
	 * Gets the ViewFile and attempts to verify it if required.
	 * @return Returns a ViewFile
	 */
	public ViewFile getViewFile() {
		
		// make sure the view file is verified
		try {
			fViewFile.verify();
		} catch(IOException e) {}
		return fViewFile;
	}

	
	/**
	 * @see IPropertySource#getEditableValue()
	 */
	public Object getEditableValue() {
		return null;
	}

	/**
	 * @see IPropertySource#getPropertyDescriptors()
	 */
	public IPropertyDescriptor[] getPropertyDescriptors() {
		
		IPropertyDescriptor[] pdlist = new IPropertyDescriptor[6];
		pdlist[0] = new PropertyDescriptor(FILE_NAME,PICLUtils.getResourceString(FILE_NAME));
		pdlist[1] = new PropertyDescriptor(NUM_LINES,PICLUtils.getResourceString(NUM_LINES));
		pdlist[2] = new PropertyDescriptor(QUAL_NAME,PICLUtils.getResourceString(QUAL_NAME));
		pdlist[3] = new PropertyDescriptor(RECORDLENGTH,PICLUtils.getResourceString(RECORDLENGTH));
		pdlist[4] = new PropertyDescriptor(LOCAL_SOURCE,PICLUtils.getResourceString(LOCAL_SOURCE));
		pdlist[5] = new PropertyDescriptor(VERIFIED,PICLUtils.getResourceString(VERIFIED));
		return pdlist;		
	}

	/**
	 * @see IPropertySource#getPropertyValue(Object)
	 */
	public Object getPropertyValue(Object id) {
		try {
			if (id.equals(FILE_NAME))
				return fViewFile.baseFileName();
			else
				if (id.equals(NUM_LINES))
					return new Integer(fViewFile.getNumberOfLines());
				else
					if (id.equals(QUAL_NAME))
						return fViewFile.name();
					else
						if (id.equals(RECORDLENGTH))
							return new Integer(fViewFile.recordLength());
						else
							if (id.equals(VERIFIED))
								return new Boolean(fViewFile.isVerified());
							else
								if (id.equals(LOCAL_SOURCE))
									return new Boolean(fViewFile.isLocalSource());
								else
									return "*unknown*";
		} catch(IOException e) {
			return "*error*";
		}
	}

	/**
	 * @see IPropertySource#isPropertySet(Object)
	 */
	public boolean isPropertySet(Object id) {
		return false;
	}

	/**
	 * @see IPropertySource#resetPropertyValue(Object)
	 */
	public void resetPropertyValue(Object id) {
	}

	/**
	 * @see IPropertySource#setPropertyValue(Object, Object)
	 */
	public void setPropertyValue(Object id, Object value) {
	}

}
