package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLThread;
import com.ibm.debug.internal.pdt.PICLUtils;


public class ShowStoppingThreadAction implements IViewActionDelegate {
	private IViewPart view;

	/**
	 * Constructor for ShowStoppingThreadAction
	 */
	public ShowStoppingThreadAction() {
		super();
	}

	/**
	 * @see IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart arg0) {
		view = arg0;
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction arg0) {
		IDebugTarget target = PICLDebugPlugin.determineCurrentDebugTarget();
		if(target instanceof PICLDebugTarget)
		{
	   		PICLDebugTarget PICLTarget = (PICLDebugTarget)target;
			PICLThread thread = PICLTarget.getStoppingThread();

			if( view instanceof IDebugView)
			{
				// Want to select top stack frame of stopping thread
				Object[] myArray= new Object[]{thread.getTopStackFrame()};
				StructuredSelection newSelection = new StructuredSelection(myArray);
				((IDebugView) view).getViewer().setSelection(newSelection);
			}
		}
  	   	else
			PICLUtils.logText("ShowStoppingThreadAction - bad target?? ");
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection arg1) {
		Object element = null;
		boolean show = false;
		if (arg1 instanceof IStructuredSelection)
		{
			IStructuredSelection selection = (IStructuredSelection) arg1;
			element = selection.getFirstElement();
		} else
		  element = arg1;

		if (element instanceof PICLDebugElement)
		{
		 	// enable menu item
			show = true;
		}
		else if (element instanceof ILaunch)
		{
		 	IDebugTarget dt =((ILaunch) element).getDebugTarget();
			if (dt instanceof PICLDebugTarget)
				show = true;
		}


		if (show == true)
		{
		 	// enable menu item
			action.setEnabled(true);
		} else
		{
		 	// disable menu item
			action.setEnabled(false);
		}
	}

}

