package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.model.ErrorOccurredEvent;

/**
 * This interface must be implemented by all requests to the model.
 * It allows for error feedback on a request to the debug engine
 */
public interface IPICLEngineRequestError {

	/**
	 * Updates the request with any errors that occured as a result of the request
	 * @param The error event that the model returns from the debug engine
	 */
	public abstract void setError(ErrorOccurredEvent errorEvent);

}

