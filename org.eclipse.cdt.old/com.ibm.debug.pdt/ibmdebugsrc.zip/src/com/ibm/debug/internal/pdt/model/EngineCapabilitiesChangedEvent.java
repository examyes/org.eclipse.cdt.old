package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * This kind of event is fired whenever the capabilities of a debug engine
 * change.
 * @see DebugEngineEventListener#engineCapabilitiesChanged
 * @see DebugEngine#getCapabilities
 * @see EngineCapabilities
 */

public class EngineCapabilitiesChangedEvent extends DebugEngineEvent
{
  EngineCapabilitiesChangedEvent(Object source,
                        DebugEngine debugEngine,
                        EngineCapabilities oldCapabilities,
                        EngineCapabilities newCapabilities,
                        int requestCode
                       )
  {
    super(source, debugEngine, requestCode);

    _oldCapabilities = oldCapabilities;
    _newCapabilities = newCapabilities;
  }

  public EngineCapabilities getOldCapabilities()
  {
    return _oldCapabilities;
  }

  public EngineCapabilities getNewCapabilities()
  {
    return _newCapabilities;
  }

  void fire(ModelEventListener listener)
  {
    ((DebugEngineEventListener)listener).engineCapabilitiesChanged(this);
  }

  private EngineCapabilities _oldCapabilities;
  private EngineCapabilities _newCapabilities;
}
