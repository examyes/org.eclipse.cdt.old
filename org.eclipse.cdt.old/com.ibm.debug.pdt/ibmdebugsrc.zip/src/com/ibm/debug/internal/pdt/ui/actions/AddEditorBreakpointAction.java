package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.IBreakpointManager;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.IUpdate;
import org.eclipse.ui.texteditor.MarkerUtilities;

import com.ibm.debug.common.GenericLineBreakpoint;
import com.ibm.debug.epdc.EPDC;
import com.ibm.debug.internal.pdt.EngineSuppliedViewEditorInput;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.Host;
import com.ibm.debug.internal.pdt.model.ViewInformation;
import com.ibm.debug.pdt.breakpoints.PICLAddressBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLLineBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLLocationBreakpoint;
import com.ibm.lpex.alef.LpexAbstractTextEditor;
import com.ibm.lpex.core.LpexView;


public class AddEditorBreakpointAction extends Action implements IUpdate {
	protected final static String PREFIX= "AddEditorBreakpointAction.";
	private ITextEditor editor;
	boolean doAddressBreakpoint = false;
	IResource resource = null;
	IBreakpointManager breakpointManager= DebugPlugin.getDefault().getBreakpointManager();
	String address = null;
	int line = 0;
	EngineSuppliedViewEditorInput engineViewEI = null;
	IFile file = null;


	/**
 	* Creates a new AddEditorBreakpointAction.
 	*/
	public AddEditorBreakpointAction(ITextEditor textEditor) {
		super(PICLUtils.getResourceString(PREFIX+"label"));
		editor = textEditor;
	}

	/**
	 * See IAction
	 */
	public void run() {

		if (editor == null) {
			PICLUtils.logText("AddEditorBreakpointAction.run(): editor is null");
			return;
		}

		IEditorInput input = editor.getEditorInput();

		LpexView lpexView = null;
		line = 0;

		// Determine line number
		if (editor instanceof LpexAbstractTextEditor) {
			lpexView = ((LpexAbstractTextEditor)editor).getLpexView();
			line = lpexView.currentElement();
		} else {
			IDocumentProvider docProvider= editor.getDocumentProvider();
			ISelectionProvider selProvider= editor.getSelectionProvider();
			ITextSelection selection= (ITextSelection) selProvider.getSelection();
			line = selection.getStartLine() + 1;
		}

		if (input instanceof IFileEditorInput) {
			IFile file = ((IFileEditorInput)input).getFile();

			if (file != null) {
				resource= (IResource) file;
				// Check if there is already a breakpoint on this line.  If so,
				// then we should remove it.  If not, then add one.
				IBreakpoint curBreakpoint = getBreakpoint(resource, line, null);
				if (curBreakpoint != null) {
					// Removing breakpoint
					try {
						breakpointManager.removeBreakpoint(curBreakpoint, true);
					} catch (CoreException ce) {
					}
					return;
				}

				new GenericLineBreakpoint(resource, line);

			}
		} else if (input instanceof EngineSuppliedViewEditorInput) {
			engineViewEI = (EngineSuppliedViewEditorInput) input;

			ViewInformation viewInfo = engineViewEI.getViewInformation();
			short kind = viewInfo.kind();

			// Address breakpoint used for mixed and real disassembly (i.e. not AS400 statement) views.
			// Line breakpoint used for source, listing and statement views.
			doAddressBreakpoint = false;
			if (kind == EPDC.View_Class_Mixed ||
					(kind == EPDC.View_Class_Disasm && engineViewEI.getEngineHost() != EPDC.PLATFORM_ID_AS400))
				doAddressBreakpoint = true;

			String lineText = lpexView.elementText(line);
			address = lineText.substring(0, engineViewEI.getPrefixLength());

			resource= engineViewEI.getResource();
			if (resource != null) {
				// Check if there is already a breakpoint on this line.  If so,
				// then we should remove it.  If not, then add one.
				IBreakpoint curBreakpoint = getBreakpoint(resource, line, engineViewEI.getName());
				if (curBreakpoint != null) {
					// Removing breakpoint
					try {
						breakpointManager.removeBreakpoint(curBreakpoint, true);
					} catch (CoreException ce) {
					}
					return;
				}

				String filename = engineViewEI.getName();
				
				if (doAddressBreakpoint)
					new PICLAddressBreakpoint(resource,filename,line,address);
				else
					new PICLLineBreakpoint(resource, filename, line);

			}
		}
	}

	/*
	 * @see IUpdate#update()
	 */
	public void update() {
		// Check if add breakpoint action should be enabled or not for
		// this editor.  This can only be done if the editor input
		// came from a debug engine.
		if (editor == null) {
			PICLUtils.logText("AddEditorBreakpointAction.update(): editor is null");
			return;
		} 
		IEditorInput input = editor.getEditorInput();
		if (input instanceof EngineSuppliedViewEditorInput) {
			engineViewEI = (EngineSuppliedViewEditorInput) input;
			String bkptType = IPICLDebugConstants.PICL_LINE_BREAKPOINT;

			ViewInformation viewInfo = engineViewEI.getViewInformation();
			short kind = viewInfo.kind();

			// Address breakpoint used for mixed and real disassembly (i.e. not AS400 statement) views.
			// Line breakpoint used for source, listing and statement views.
			if (kind == EPDC.View_Class_Mixed ||
					(kind == EPDC.View_Class_Disasm &&
						engineViewEI.getEngineHost() != EPDC.PLATFORM_ID_AS400))
				bkptType = IPICLDebugConstants.PICL_ADDRESS_BREAKPOINT;

			PICLDebugTarget target = engineViewEI.getPICLDebugTarget();
			boolean supported = target.supportsBrkptType(bkptType);
			setEnabled(supported);
		}
	}


	/**
	 * Check if there is already a corresponding PICLLocationBreakpoint on the specified line.
	 * If sourceFile is null then it will not be checked.
	 */

	private IBreakpoint getBreakpoint(IResource resource, int line, String sourceFile) {
		if (resource == null)
			return null;
		try {
			IMarker markers[] =
				resource.findMarkers(IPICLDebugConstants.BASE_BREAKPOINT,
									true,
									IResource.DEPTH_INFINITE);
			if (markers.length == 0)
				return null;

			// check if marker is the one we are looking for
			for (int i = 0; i < markers.length; i++) {
				if (markers[i] == null)
					continue;
				if (MarkerUtilities.getLineNumber(markers[i]) != line)
					continue;
				if (sourceFile != null) {
					String markerName = (String) markers[i].getAttribute("sourceFileName");
					if (!sourceFile.equals(markerName))
						continue;
				}
				//Must be what we are looking for
				IBreakpoint breakpoint = breakpointManager.getBreakpoint(markers[i]);
				return breakpoint;
			}

		} catch (CoreException e) {
		}

		return null;
	}

}
