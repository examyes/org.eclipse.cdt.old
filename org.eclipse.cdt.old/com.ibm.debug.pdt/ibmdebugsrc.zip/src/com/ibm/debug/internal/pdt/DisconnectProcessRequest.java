package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import com.ibm.debug.epdc.EPDC;

/**
 * Request to disconnect from the debuggee's process
 * This is an asynchronous request
 */

public class DisconnectProcessRequest extends ProgramControlRequest {

	private int fDetachType = EPDC.ProcessRelease;

	/**
	 * Constructor for DisconnectProcessRequest.
	 * @param debugTarget
	 * @param detachType
	 */
    /**
     * Constructor for DisconnectProcessRequest
     */
    public DisconnectProcessRequest(PICLDebugTarget debugTarget, int detachType) {
        super(debugTarget);
        fDetachType = detachType;
    }
    
	/**
	 * Default constructor for DisconnectProcessRequest.
	 * This will attempt to disconnect from the process without killing it
	 * @param debugTarget
	 */
    public DisconnectProcessRequest(PICLDebugTarget debugTarget) {
    	super(debugTarget);
    }

	/* (non-Javadoc)
	 * @see PICLEngineRequest#execute()
	 */
    public void execute() throws PICLException {

    	beginRequest();

    	try {
	    	fDebugTarget.getDebuggeeProcess().detach(fDetachType,asyncRequest());
    	} catch(IOException ioe) {
			throw new PICLException(PICLUtils.getResourceString(msgKey + "send_error"));
    	}

    	// NOTE: there is no call to endRequest() because this request is not complete yet...  At some time later the
    	//       model will fire an event that represents the end of this request.

    }

}

