package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * The super class for all StorageLine events.
 */

public abstract class StorageLineEvent extends ModelEvent
{
  StorageLineEvent(Object source, StorageLine storageLine, int requestCode)
  {
    super(source, requestCode);
    _storageLine = storageLine;
  }

  public StorageLine getStorageLine()
  {
    return _storageLine;
  }

  private StorageLine _storageLine;
}
