package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;

import com.ibm.debug.internal.pdt.model.Storage;

/**
 * Represents the parent of all monitored storage
 */

public class PICLStorageParent extends PICLDebugElement {

	private Object[] fExpandedElements = null;

	/**
	 * Constructor for PICLStorageParent
	 */
	public PICLStorageParent(IDebugElement parent, IDebugTarget debugTarget) {
		super(parent, debugTarget);
	}

	/**
	 * @see PICLDebugElement#doCleanupDetails()
	 */
	protected void doCleanupDetails() {
		fExpandedElements = null;
	}

	/**
	 * This label is not displayed.
	 * @see PICLDebugElement#getLabel(boolean)
	 */
	public String getLabel(boolean qualified) {
		return "PICLStorageParent label";
	}

	
	/**
	 * Used to add storage to this parent.
	 * @param The module that is to be added
	 */
	public void addStorage(Storage storage) {
        addChild(new PICLStorage(this,storage, getDebugTarget()), true);

	}


	/**
	 * Saves tree expanded elements
	 * @param expanded elements
	 */
	public void saveExpandedElements(Object[] elements) {
		fExpandedElements = elements;
	}

	/**
	 * Returns tree expanded elements
	 * @return expanded elements
	 */
	public Object[] getExpandedElements() {
		return fExpandedElements;
	}

}

