package com.ibm.debug.internal.pdt.ui.dialogs;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;

import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLUtils;

/**
 * Superclass for the breakpoint wizards
 **/

public abstract class BreakpointWizard extends Wizard {

	//The currently selected debug target. May be null.
	protected PICLDebugTarget target;

	protected PICLDebugTarget getSelectedTarget()
	{
		return target;
	}

	protected void findSelectedDebugTarget()
	{
		IWorkbenchPage page = PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if(page ==null) return;
		IViewPart view= page.findView(IDebugUIConstants.ID_DEBUG_VIEW);
		if ((view==null) || !(view instanceof IDebugView)) return;

		ISelection sel = ((IDebugView)view).getViewer().getSelection();

		Object element = null;
		if (sel instanceof IStructuredSelection)
		{

			IStructuredSelection selection = (IStructuredSelection) sel;
			if(!selection.isEmpty() && selection.size() == 1)
				element = selection.getFirstElement();
			else
				return;

		}
		else
		  element = sel;

		//check item is a stack frame, process, or thread for live debug target	that supports address breakpoints
		if (element instanceof PICLDebugElement && !((IDebugElement)element).getDebugTarget().isTerminated() )
			target = (PICLDebugTarget)((IDebugElement)element).getDebugTarget();

		else if (element instanceof ILaunch) //launcher
		{
		 	IDebugTarget dt =((ILaunch) element).getDebugTarget();
			if (dt instanceof PICLDebugTarget && !((PICLDebugTarget)dt).isTerminated())
				target = (PICLDebugTarget)dt;
		}
	}

	//Checks if any of the 3 conditional FCT bits are on
	protected boolean conditionalBPSupported()
	{
		if (target == null)
			return false;
		return (expressionsSupported() || frequencySupported() || threadsSupported());

	}
	//Checks frequency FCT bit
	protected boolean frequencySupported()
	{
		if (target == null)
			return false;
		return target.getBreakpointCapabilities().breakpointFrequencySupported();
	}
	//Checks threads FCT bit
	protected boolean threadsSupported()
	{
		if (target == null)
			return false;
		return target.getBreakpointCapabilities().breakpointThreadsSupported();
	}

	//Checks expression FCT bit
	protected boolean expressionsSupported()
	{
		if (target == null)
			return false;
		return target.getBreakpointCapabilities().conditionalBreakpointsSupported();
	}

	protected boolean deferredSupported()
	{
		if (target == null)
			return false;
		return target.getBreakpointCapabilities().deferredBreakpointsSupported();
	}

	//Checks bytes supported FCT bit
	protected boolean monitor0_128BytesSupported()
	{
		if (target == null)
			return false;
		return target.getBreakpointCapabilities().monitor0_128BytesSupported();
	}
	//Checks bytes supported FCT bit
	protected boolean monitor1ByteSupported()
	{
		if (target == null)
			return false;
		return target.getBreakpointCapabilities().monitor1ByteSupported();
	}
	//Checks bytes supported FCT bit
	protected boolean monitor2BytesSupported()
	{
		if (target == null)
			return false;
		return target.getBreakpointCapabilities().monitor2BytesSupported();
	}
	//Checks bytes supported FCT bit
	protected boolean monitor4BytesSupported()
	{
		if (target == null)
			return false;
		return target.getBreakpointCapabilities().monitor4BytesSupported();
	}
	//Checks bytes supported FCT bit
	protected boolean monitor8BytesSupported()
	{
		if (target == null)
			return false;
		return target.getBreakpointCapabilities().monitor8BytesSupported();
	}

	public boolean canFinish()
	{
		//Only first of two pages are mandatory, so if page 1 complete, can finish
		if (getStartingPage().isPageComplete())
			return true;
		return false;
	}

	public static String getPluginIdentifier()
	{
		return PICLUtils.getModelIdentifier();
	}

	/**
	 * @see Wizard#performFinish()
	 * Subclasses must override method.
	 */
	public abstract boolean performFinish();


}

