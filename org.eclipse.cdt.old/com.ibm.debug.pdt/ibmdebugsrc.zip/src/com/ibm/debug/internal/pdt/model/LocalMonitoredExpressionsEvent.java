package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * The super class for local monitor events.
 * The Events include monitoredExpressionAdded for adding a monitored
 * expression to the local monitor, and localExpressionsEnded for removing
 * a local monitor.
 */

public abstract class LocalMonitoredExpressionsEvent extends ModelEvent
{
  LocalMonitoredExpressionsEvent(Object source, LocalMonitoredExpressions monitor, int requestCode)
  {
    super(source, requestCode);
    _monitor = monitor;
  }

  /**
   * Return the local monitor
   */
  public LocalMonitoredExpressions getLocalExpressionsMonitor()
  {
    return _monitor;
  }

  private LocalMonitoredExpressions _monitor;
}
