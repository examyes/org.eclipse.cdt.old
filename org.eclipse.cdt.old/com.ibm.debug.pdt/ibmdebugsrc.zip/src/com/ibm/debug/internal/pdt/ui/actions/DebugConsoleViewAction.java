package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.ui.views.DebugConsoleView;

import org.eclipse.jface.action.Action;
import org.eclipse.swt.widgets.*;

/**
 * This is the base class of all the local actions used in the view.
 */
public abstract class DebugConsoleViewAction extends Action {
	private String id;
	DebugConsoleView myView;

	/**
	 * DebugConsoleViewAction constructor.
	 */
	protected DebugConsoleViewAction(DebugConsoleView aView, String name) {
		super(name);
		myView = aView;
		setID(name);
	}

	/**
	 * Returns the unique action ID that will be
	 * used in contribution managers.
	 */
	public String getID() {
		return id;
	}

	/**
	 * Returns the my view.
	 */
	protected DebugConsoleView getDebugConsoleView() {
		return myView;
	}

	/**
	 * Sets the unique ID that should be used
	 * in the contribution managers.
	 */
	public void setID(String newId) {
		id = newId;
	}

}
