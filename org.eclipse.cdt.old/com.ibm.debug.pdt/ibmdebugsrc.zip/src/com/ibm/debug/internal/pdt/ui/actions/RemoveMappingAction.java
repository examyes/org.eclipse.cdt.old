package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.util.Iterator;

import org.eclipse.debug.core.DebugException;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.actions.SelectionProviderAction;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLStorageMap;
import com.ibm.debug.internal.pdt.PICLStorageMapParent;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.ui.views.StorageMapView;


public class RemoveMappingAction extends SelectionProviderAction {
	protected static final String PREFIX= "RemoveMappingAction.";

	/**
	 * Constructor for RemoveMappingAction
	 */
	public RemoveMappingAction(ISelectionProvider provider) {
		super(provider, PICLUtils.getResourceString(PREFIX+"label"));
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip"));
		setEnabled(!getStructuredSelection().isEmpty());

		WorkbenchHelp.setHelp(this, PICLUtils.getHelpResourceString("RemoveMappingAction"));
		}

	protected void doAction() throws DebugException {
		IStructuredSelection selection= getStructuredSelection();
		Iterator vars= selection.iterator();
		while (vars.hasNext()) {
			Object item= vars.next();
			if (item instanceof PICLStorageMap) {
				((PICLStorageMap)item).delete();
			}
		}
	}

	/**
	 * @see Action#run()
	 */
	public void run() {
		// get the MappingView
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) {
			return;
		}
		IViewPart view= p.findView(IPICLDebugConstants.MAPPING_VIEW);
		if (view == null) {
			// open a new view
			try {
				view= p.showView(IPICLDebugConstants.MAPPING_VIEW);
			} catch (PartInitException e) {
				//DebugUIUtils.logError(e);
				return;
			}
		}

		try {
			if (!(view instanceof StorageMapView)) { return; }
			doAction();
		} catch (DebugException de) {
			PICLUtils.logError(de);
		}
	}


	/**
	 * @see SelectionProviderAction
	 */
	public void selectionChanged(IStructuredSelection sel) {
		setChecked(false);
		setEnabled(!sel.isEmpty());
		Iterator iter = sel.iterator();
		Object object = null;
		while (iter.hasNext()) {
			object = iter.next();
			if (object instanceof PICLStorageMap) {
				PICLStorageMap map= (PICLStorageMap)object;
				//can only delete root items
				if (! (map.getParent() instanceof PICLStorageMapParent)) {
					setEnabled(false);
					return;
				}
			} else {
				setEnabled(false);
				return;
			}
		}
	}

}
