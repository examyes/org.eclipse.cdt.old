package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/** The methods in this interface correspond to events that can occur
 *  within a debuggee at the process level. Client code should implement
 *  this interface if it wants to be informed when these events occur.
 *  An object of this type can be registered as an interested listener
 *  by calling the <b>DebuggeeProcess.add(DebuggeeProcessEventListener)</b>
 *  method. Whenever an event occurs which corresponds to one of the methods
 *  in the interface, the DebuggeeProcess object will call the appropriate
 *  method for every registered event listener.
 *  @see DebuggeeProcess
 *  @see DebuggeeThread
 *  @see Module
 */

public interface DebuggeeProcessEventListener extends ModelEventListener {
	/**
	 * This method will be called whenever a module is added to the process.
	 * @param event The event
	 */

	public void moduleAdded(ModuleAddedEvent event);

	/**
	 * This method will be called whenever a thread is added to the process.
	 * @param event The event
	 */

	public void threadAdded(ThreadAddedEvent event);

	/**
	 * This method will be called whenever a monitored expression is added to
	 * the process.
	 * @param event The event
	 */

	public void monitoredExpressionAdded(MonitoredExpressionAddedEvent event);

	/**
	 * This method will be called whenever a breakpoint is added to the process.
	 * @param event The event
	 */

	public void breakpointAdded(BreakpointAddedEvent event);

	/**
	 * This method will be called whenever monitored storage is added to the process.
	 * @param event The event
	 */

	public void storageAdded(StorageAddedEvent event);

	/**
	 *  This method will be called whenever the process stops.
	 *  @param event The event
	 */

	public void processStopped(ProcessStoppedEvent event);

	public void processEnded(ProcessEndedEvent event);

	/**
	 *  This method will be called whenever an exception occurs.
	 *  @param event The event
	 */

	public void exceptionRaised(ExceptionRaisedEvent event);

	/**
	 * Called when there are 1 or more lines of program output
	 * represented by this process
	 * @param event contains the lines of program output text
	 */
	public void programOutput(ProcessPgmOutput event);

	/**
	 * Called when there are 1 or more lines of error output from the program
	 * represented by this process
	 * @param event contains the lines of error text
	 */
	public void programError(ProcessPgmError event);
}
