package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.epdc.*;
import java.io.*;

public abstract class EventBreakpoint extends Breakpoint
{
  EventBreakpoint(DebuggeeProcess owningProcess, ERepGetNextBkp epdcBkp)
  {
    super(owningProcess, epdcBkp);
  }

  void change(ERepGetNextBkp epdcBkp, boolean isNew)
  {
    super.change(epdcBkp, isNew);
  }

  public void print(PrintWriter printWriter)
  {
    if (Model.includePrintMethods)
    {
      printWriter.println("State: " + (isEnabled() ? "Enabled" : "Disabled"));
      printWriter.println("Thread ID: " + getThreadID());
      printWriter.println("Breakpoint Every: " + getEveryVal());
      printWriter.println("           To: " + getToVal());
      printWriter.println("           From: " + getFromVal());
    }
  }
}
