package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.model.MonitoredExpressionTreeNode;
import com.ibm.debug.internal.pdt.model.Representation;
import java.io.IOException;


/**
 * Request to change the value of the expression node
 */

public class MonitorExpressionChangeValue extends MonitorRequest {

	private PICLVariable fPICLVariable = null;
	private Representation fRepresentation = null;
	private String fNewValue = null;

	/**
	 * Constructor for MonitorExpressionChangeValue
	 */
	public MonitorExpressionChangeValue(PICLDebugTarget debugTarget,
									  PICLVariable piclVariable,
									  String newValue) {
		super(debugTarget);
		fPICLVariable = piclVariable;
		fNewValue = newValue;

	}

	/**
	 * @see PICLEngineRequest#execute()
	 */
	public void execute() throws PICLException {

		beginRequest();

		MonitoredExpressionTreeNode treeNode = fPICLVariable.getExpressionTreeNode();

		boolean rc = true;

		try {
			rc = treeNode.modifyValue(fNewValue,syncRequest());
            if (!rc)
 	      		throw new PICLException(PICLUtils.getResourceString(msgKey + "send_error"));
    	} catch(IOException ioe) {
			throw(new PICLException(PICLUtils.getResourceString(msgKey + "send_error")));
    	} finally {
	    	endRequest();
    	}
	}

}

