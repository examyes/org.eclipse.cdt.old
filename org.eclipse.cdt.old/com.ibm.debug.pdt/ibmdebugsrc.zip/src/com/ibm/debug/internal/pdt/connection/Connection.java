package com.ibm.debug.internal.pdt.connection;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract class Connection {
	// connection types matched with the C++ connection classes
	static public int AS_CLIENT = 0;
	static public int AS_SERVER = 1;

	/**
	 * Get the connection's output stream
	 * @return OutputStream
	 */
	final public OutputStream getOutputStream() {
		return _outputStream;
	}

	/**
	 * Get the connection's input stream
	 * @return InputStream
	 */
	final public InputStream getInputStream() {
		return _inputStream;
	}

	/** Set the output stream that clients should use when sending data
	 *  via this connection. This method should generally only be called from a
	 *  subclass.
	 */

	protected void setOutputStream(OutputStream outputStream) {
		try {
			flush();
		} catch (IOException ex) {
		}
		_outputStream = outputStream;
	}

	/** Set the input stream that clients should use when reading data
	 *  from this connection. This method should generally only be called from a
	 *  subclass.
	 */

	protected void setInputStream(InputStream inputStream) {
		_inputStream = inputStream;
	}

	public void close() throws IOException {
		flush();
	}

	/**
	 *  Flush the output stream 
	 */
	public void flush() throws IOException {
		if (_outputStream != null)
			_outputStream.flush();
	}

	private OutputStream _outputStream;
	private InputStream _inputStream;
}
