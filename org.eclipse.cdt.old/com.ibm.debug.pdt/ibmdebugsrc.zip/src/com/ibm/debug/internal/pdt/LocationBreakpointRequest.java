package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.resources.IMarker;
import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.ui.texteditor.MarkerUtilities;

public abstract class LocationBreakpointRequest extends BreakpointCreateRequest {

    private String fConditionalExpression = null;
	private boolean fDeferred = false;


    /**
     * Constructor for LocationBreakpointRequest
     */
    LocationBreakpointRequest(IBreakpoint breakpoint, PICLDebugTarget debugTarget) throws DebugException {
        super(breakpoint,debugTarget);

        // Get the line number from the marker
        setLineNumber(MarkerUtilities.getLineNumber(fMarker));


        if (fAttributes != null) {
            if (fAttributes.containsKey(IPICLDebugConstants.CONDITIONAL_EXPRESSION))
                fConditionalExpression = (String)fAttributes.get(IPICLDebugConstants.CONDITIONAL_EXPRESSION);

            if (fAttributes.containsKey(IPICLDebugConstants.DEFERRED))
                fDeferred = ((Boolean)fAttributes.get(IPICLDebugConstants.DEFERRED)).booleanValue();

        }

    }

    /**
     * Gets the deferred
     * @return Returns a boolean
     */
    protected boolean getDeferred() {
        return fDeferred;
    }
    /**
     * Gets the conditionalExpression
     * @return Returns a String
     */
    protected String getConditionalExpression() {
        return fConditionalExpression;
    }

	/**
	 * Sets the deferred
	 * @param deferred The deferred to set
	 */
	protected void setDeferred(boolean deferred) {
		fDeferred = deferred;
	}

}
