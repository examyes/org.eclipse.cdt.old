package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import org.eclipse.core.resources.IMarker;
import org.eclipse.debug.core.model.IBreakpoint;

import com.ibm.debug.internal.pdt.model.Breakpoint;

public class BreakpointEnableRequest extends BreakpointRequest {

	protected final String msgKey = super.msgKey + "enable.";
	private Breakpoint fBreakpoint = null;
    private IMarker fMarker = null;

	public BreakpointEnableRequest(PICLDebugTarget debugTarget, Breakpoint breakpoint, IMarker marker) {
		super(debugTarget);

		fBreakpoint = breakpoint;
        fMarker = marker;
	}

	/**
	 * @see PICLEngineRequest#execute()
	 */
	public void execute() throws PICLException {

		beginRequest();

    	boolean rc = true;

    	try {
    		if (fMarker.getAttribute(IBreakpoint.ENABLED, true))
    			rc = fBreakpoint.enable(syncRequest(), fMarker);
    		else
    			rc = fBreakpoint.disable(syncRequest(), fMarker);
			if (!rc)
 	      		throw new PICLException(PICLUtils.getResourceString(msgKey + "enable_error"));
    	} catch(IOException ioe) {
			throw(new PICLException(PICLUtils.getResourceString(msgKey + "sendError")));
    	} finally {
    		endRequest();
    	}
	}

}
