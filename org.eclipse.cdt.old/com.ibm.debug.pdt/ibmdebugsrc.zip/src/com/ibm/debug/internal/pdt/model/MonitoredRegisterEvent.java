package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * The super class for all monitored register events.
 */

public abstract class MonitoredRegisterEvent extends ModelEvent
{
  MonitoredRegisterEvent(Object source, MonitoredRegister monRegister, int requestCode)
  {
    super(source, requestCode);
    _monRegister = monRegister;
  }

  public MonitoredRegister getMonitoredRegister()
  {
    return _monRegister;
  }

  private MonitoredRegister _monRegister;
}
