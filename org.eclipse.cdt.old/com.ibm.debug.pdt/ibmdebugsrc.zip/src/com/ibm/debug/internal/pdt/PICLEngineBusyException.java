package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.model.ErrorOccurredEvent;

public class PICLEngineBusyException extends PICLException {

	/**
     * Constructor for PICLEngineBusyException
     */
    public PICLEngineBusyException() {
        super();
    }

    /**
     * Constructor for PICLEngineBusyException
     */
    public PICLEngineBusyException(String arg0) {
        super(arg0);
    }

    /**
     * Constructor for PICLEngineBusyException
     */
    private PICLEngineBusyException(ErrorOccurredEvent errorEvent) {
        super(errorEvent);
    }



}

