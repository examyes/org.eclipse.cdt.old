package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.PICLVariable;
import com.ibm.debug.internal.pdt.model.DebugEngine;
import com.ibm.debug.internal.pdt.model.MonitoredExpressionTreeNode;
import com.ibm.debug.internal.pdt.model.PointerMonitoredExpressionTreeNode;

public class DereferencePointerAction extends Action {
	protected static final String PREFIX= "DereferencePointerAction.";
	private PICLVariable fVar;

	public DereferencePointerAction(PICLVariable var) {
		super(PICLUtils.getResourceString(PREFIX+"label"));
		fVar = var;
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip"));
		WorkbenchHelp.setHelp(this, PICLUtils.getHelpResourceString("DereferencePointerAction"));
	}


	/**
	 * @see Action#run()
	 */
	public void run() {
		if (fVar.isPointer())
			fVar.dereference();
	}

}
