package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

import org.eclipse.jface.action.Action;
import org.eclipse.swt.widgets.Shell;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.ui.dialogs.AddProgramDialog;


public class AddProgramAction extends Action {

	private static final String PREFIX= "AddProgramAction.";
	private PICLDebugTarget fdt;

	/**
	 * Constructor for AddProgramAction.
	 */
	public AddProgramAction(PICLDebugTarget dt) {
		super(PICLUtils.getResourceString(PREFIX + "label"));
		setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_EXPAND_ALL));
		setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_EXPAND_ALL));
		setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_EXPAND_ALL));
		setToolTipText(PICLUtils.getResourceString(PREFIX + "tooltip"));
		setId(PREFIX);
		fdt = dt;
	}

	/**
	 * @see IAction#run()
	 */
	public void run() {
		Shell shell= PICLDebugPlugin.getActiveWorkbenchShell();

		AddProgramDialog dialog= new AddProgramDialog(shell,fdt);
			dialog.open();
	}

	/**
	 * Gets the debug target.
	 * @return Returns a PICLDebugTarget
	 */
	public PICLDebugTarget getDebugTarget() {
		return fdt;
	}

	/**
	 * Sets the debug target.
	 * @param dt The debug target to set
	 */
	public void setDebugTarget(PICLDebugTarget dt) {
		fdt = dt;
	}

}
