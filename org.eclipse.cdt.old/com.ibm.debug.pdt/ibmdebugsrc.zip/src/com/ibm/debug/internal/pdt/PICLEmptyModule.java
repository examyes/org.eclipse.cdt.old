package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;

public class PICLEmptyModule extends PICLModule {

	/**
	 * Constructor for PICLEmptyModule
	 */
	public PICLEmptyModule(IDebugElement parent, IDebugTarget debugTarget) {
		super(parent, null, debugTarget);
	}

	/**
	 * @see PICLModule#getLabel(boolean)
	 */
	public String getLabel(boolean qualified) {
		return PICLUtils.getResourceString("picl_module.no_modules");
	}

}

