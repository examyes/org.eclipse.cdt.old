package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.epdc.*;
import java.io.*;

/**
 * This class represents a group of debug engine capabilities. It is subclassed
 * by several classes representing specific kinds of engine capability groups.
 * @see    EngineStartupCapabilities
 * @see    EngineGeneralCapabilities
 * @see    EngineFileCapabilities
 * @see    EngineStorageCapabilities
 * @see    EngineBreakpointCapabilities
 * @see    EngineMonitorCapabilities
 * @see    EngineWindowCapabilities
 * @see    EngineRunCapabilities
 * @see    EngineExceptionCapabilities
 * @see    EngineStackCapabilities
 */

abstract public class EngineCapabilitiesGroup
{
  EngineCapabilitiesGroup(EFunctCustTable FCTBits)
  {
    _FCTBits = FCTBits;
  }

  protected EFunctCustTable getFCTBits()
  {
    return _FCTBits;
  }

  abstract int getBits();

  abstract public void print(PrintWriter printStream);

  private EFunctCustTable _FCTBits;
}
