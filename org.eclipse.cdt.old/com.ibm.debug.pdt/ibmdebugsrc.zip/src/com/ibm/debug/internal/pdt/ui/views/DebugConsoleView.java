package com.ibm.debug.internal.pdt.ui.views;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2000, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.runtime.ILog;
import org.eclipse.debug.core.DebugEvent;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.IDebugEventListener;
import org.eclipse.debug.core.IDebugEventSetListener;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchListener;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.TextViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.ui.part.ViewPart;

import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLStackFrame;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.PICLVariable;
import com.ibm.debug.internal.pdt.model.DebugEngine;
import com.ibm.debug.internal.pdt.model.DebugEngineCommandLogResponseEvent;
import com.ibm.debug.internal.pdt.model.DebugEngineEventListener;
import com.ibm.debug.internal.pdt.model.DebugEngineTerminatedEvent;
import com.ibm.debug.internal.pdt.model.EngineCapabilities;
import com.ibm.debug.internal.pdt.model.EngineCapabilitiesChangedEvent;
import com.ibm.debug.internal.pdt.model.ErrorOccurredEvent;
import com.ibm.debug.internal.pdt.model.MessageReceivedEvent;
import com.ibm.debug.internal.pdt.model.ModelStateChangedEvent;
import com.ibm.debug.internal.pdt.model.ProcessAddedEvent;
import com.ibm.debug.internal.pdt.ui.actions.*;

/**
 * View for Debug Engine commands
 */
public class DebugConsoleView
	extends ViewPart
	implements IMenuListener, IDebugEventSetListener, ILaunchListener {

	protected final static String PREFIX= "DebugConsoleView.";
	private ResourceBundle _messagesBundle;
	private ILog log;
	private TextViewer responses;
	private StyledText commands;
	private Label label;
	private String lastLabel = "";
	private Composite parent;
	private Control ctrl = null;
	private Display display = null;
	private DebugConsoleViewCopyAction copyAction;
	private DebugConsoleViewDeleteAction deleteAction;
	private final static int MAX_TEXT = 5000;
	private final static int AUTOCUT_TEXT = MAX_TEXT / 5;
	private String lastCommand = "";

	protected DebugEngine debugEngine = null;
	protected IDebugTarget iDebugTarget = null;
	protected String debuggeeName = "";

	/**
	 * DebugConsoleView constructor
	 */
	public DebugConsoleView() {
		super();
	}

	/**
	 * Creates the DebugConsoleView
	 */
	public void createPartControl(Composite _parent) {

		//   init_Initialization();

		PICLUtils.logEvent("DebugConsoleView created",this);

		initializeMessagesOnce();

		parent = _parent;

		GridLayout parentLayout = new GridLayout();
		parentLayout.numColumns = 2;
		parent.setLayout(parentLayout);

		// ################ command responses ########################
		responses = new TextViewer(parent, SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
		responses.getTextWidget().setLayoutData(new GridData(GridData.FILL_BOTH));
		GridData responsesGrid = new GridData(GridData.FILL_BOTH);
		responsesGrid.horizontalSpan = 2;
		responses.getTextWidget().setLayoutData(responsesGrid);
		responses.setDocument(new Document(""));
		responses.setEditable(false);
		responses.getTextWidget().setTextLimit(MAX_TEXT);

		ctrl = responses.getControl();
		if (ctrl != null)
			display = ctrl.getDisplay();
		responses.getTextWidget().setFont(new Font(display, "Courier", 10, SWT.NORMAL));

		// ################ command label ########################
		label = new Label(parent, SWT.SINGLE);
		GridData labelGrid =
			new GridData(GridData.VERTICAL_ALIGN_END | GridData.HORIZONTAL_ALIGN_BEGINNING);
		label.setLayoutData(labelGrid);
		label.setText("");

		// ################ command entry-field ########################
		commands = new StyledText(parent, SWT.SINGLE | SWT.BORDER);
		GridData commandsGrid =
			new GridData(GridData.VERTICAL_ALIGN_END | GridData.HORIZONTAL_ALIGN_FILL);
		commandsGrid.grabExcessHorizontalSpace = true;
		commands.setLayoutData(commandsGrid);
		commands.setText("");

		commands.addListener(SWT.KeyUp, new Listener() {
			public void handleEvent(Event e) {
				if (e.character == '\r') // "enter" key
					{
					lastCommand = commands.getText();
					performCommand(commands.getText());
					commands.setText("");
				} else if (e.keyCode == 16777217) // "up" arrow
					{
					commands.setText(lastCommand);
					commands.setCaretOffset(commands.getCharCount());
				} else if (e.keyCode == 16777218) // "down" arrow
					{
					commands.setText("");
				}
			}
		});
		commands.setFont(new Font(display, "Courier", 10, SWT.NORMAL));

		// ################ menus ########################
		MenuManager menuMgr = new MenuManager("#BaseActionPopUp");
		Menu menu = menuMgr.createContextMenu(responses.getControl());
		menuMgr.addMenuListener(this);
		menuMgr.setRemoveAllWhenShown(true);
		responses.getControl().setMenu(menu);
		makeActions();

		fillLocalToolBar();

		// ################ ADD DebugEvent+Launch Listeners ########################
		boolean initialized = false;
		
		DebugPlugin debugPlugin = DebugPlugin.getDefault();
		if (debugPlugin != null) {
			PICLUtils.logText("DebugPlugin ADDING_I_DEBUG_EVENT_LISTENER");
			debugPlugin.addDebugEventListener(this);

			ILaunchManager launchManager = debugPlugin.getLaunchManager();
			
			if (launchManager != null) {
				PICLUtils.logText("ILaunchManager ADDING_LAUNCH_LISTENER");
				launchManager.addLaunchListener((ILaunchListener) this);

				// This is a hack until a better way is found.
				// Search for a picldebug target
				IDebugTarget[] targets = launchManager.getDebugTargets();
				PICLDebugTarget pt = null;
				for (int i=0; i < targets.length; i++) {
					if (targets[i] instanceof PICLDebugTarget) {
						pt = (PICLDebugTarget)targets[i];
						if (!pt.isTerminated()) {
							initialize(pt);
							initialized = true;
							break;
						}
					}
				}
				
				
						
			}
		}

		if (initialized) {
			addItem(GDBPICL_ACTIVE);
			setLabel(GDBPICL_ACTIVE);
		} else {
			addItem(GDBPICL_INACTIVE);
			setLabel(GDBPICL_INACTIVE);
		}
		debuggeeName = "";
	}

	public void dispose() {
		super.dispose();
		PICLUtils.logEvent("DebugConsoleView disposed",this);
		debugEngine = null;
		iDebugTarget = null;

		// ################ REMOVED DebugEvent+Launch Listeners ########################
		DebugPlugin debugPlugin = DebugPlugin.getDefault();
		if (debugPlugin != null) {
			debugPlugin.removeDebugEventListener(this);
			ILaunchManager launchManager = debugPlugin.getLaunchManager();
			if (launchManager != null)
				launchManager.removeLaunchListener((ILaunchListener) this);
		}

		label.dispose();
		label = null;
		commands.dispose();
		commands = null;
		if (responses.getControl() != null)
			responses.getControl().dispose();
		responses = null;
	}
	public void fillContextMenu(IMenuManager menu) {
		menu.add(copyAction);
		menu.add(deleteAction);
		//	menu.add(new Separator());
		//	menu.add(showAllAction);
	}
	public void fillLocalToolBar() {
		IToolBarManager toolBarManager =
			getViewSite().getActionBars().getToolBarManager();
		//	showAllAction.setEnabled(true);
		//	showAllAction.setChecked(true); //start out showing all
		//	showAllAction.setImageDescriptor(GdbViewPlugin.getDefault().getImageDescriptor("newreadme_wiz.gif"));
		//	showAllAction.setText("Show All");
		//	showAllAction.setToolTipText("Show All Items");
		//	toolBarManager.add(showAllAction);
	}
	private void makeActions() {
		// add item
		copyAction = new DebugConsoleViewCopyAction(this);
		// delete item
		deleteAction = new DebugConsoleViewDeleteAction(this);
	}
	/**
	 * The context menu is about to appear.  Populate it.
	 */
	public void menuAboutToShow(IMenuManager mgr) {
		fillContextMenu(mgr);
	}
	public void setFocus() {
		commands.setFocus();
	}

	
	/* (non-Javadoc)
	 * @see IDebugEventSetListener#handleDebugEvents(DebugEvent[])
	 */
	public void handleDebugEvents(DebugEvent[] events) {

		for (int i=0; i < events.length; i++) {
			Object source = events[i].getSource();

			initialize(source);
		
			doHandleDebugEvent(events[i]);
		}
		return;
	}


	/**
	 * Initialize
	 */
	
	private void initialize(Object source) {
		
		if (debugEngine == null && source instanceof PICLDebugTarget) {
			PICLDebugTarget tgt = (PICLDebugTarget)source;
			DebugEngine newDebugEngine = tgt.getDebugEngine();
			if (debugEngine == null && newDebugEngine != null) {
				if (!tgt.isTerminated()) {
					boolean cmdLog = false;
					try {
						EngineCapabilities capabilities = newDebugEngine.getCapabilities();
						if (capabilities == null)
							return;
						cmdLog = capabilities.getWindowCapabilities().commandLogSupported();
					} catch(NullPointerException npe) {
						return;
					}
					if (cmdLog) {
						if (debugEngine != null) {
							PICLUtils.logText(GDBPICL_IS_OVERWRITING_EXISTING_DEBUGENGINE);
						}
						debugEngine = newDebugEngine;
						debugEngine.addEventListener(new GdbEngineEventListener());
						debuggeeName = "";
						String targetLabel = tgt.getLabel(false);
						int quote = targetLabel.indexOf("\"");
						if (quote > 0)
							debuggeeName = targetLabel.substring(quote);

					} else {
						;
					} // non-GdbPicl
				}
			} else if (
				debugEngine != null
					&& debugEngine == newDebugEngine
					&& (tgt.isTerminated()
						|| tgt.isDisconnected())) {
				PICLUtils.logText(GDBPICL_IS_TERMINATED_OR_DISCONNECTED);
			}
		}
	}

	/**
	 * @see BasicContentProvider#doHandleDebug(Event)
	 */
	public void doHandleDebugEvent(DebugEvent event) {
		Object element = event.getSource();
		if (element instanceof PICLStackFrame) {
			return; // the DebugConsoleView does not care about StackFrames
		}
		if (element instanceof PICLVariable) {
			return; // the DebugConsoleView does not care about variables
		}
		switch (event.getKind()) {
			case DebugEvent.CREATE :
				if (element instanceof IDebugTarget) {
					if (iDebugTarget == null && debugEngine != null) {
						iDebugTarget = (IDebugTarget) element;
						addItem(GDBPICL_ACTIVE + " (" + debuggeeName + ")");
						setLabel(GDBPICL_COMMAND);
					}
				}
				break;
			case DebugEvent.TERMINATE :
				if (element instanceof IDebugTarget) {
					if (iDebugTarget != null && (iDebugTarget == (IDebugTarget) element));
					{
						debugEngine = null;
						iDebugTarget = null;
						addItem("\r" + GDBPICL_INACTIVE);
						setLabel(GDBPICL_INACTIVE);
						debuggeeName = "";
					}
				}
				break;
			default :
				break;
				
		}
	}

	/**
	 * @see ILaunchListener
	 */
	public void launchRegistered(final ILaunch launch) {
		IDebugTarget debugTarget = launch.getDebugTarget();
	}
	/**
	 * @see ILaunchListener
	 */
	public void launchDeregistered(final ILaunch launch) {
		IDebugTarget debugTarget = launch.getDebugTarget();
		if (iDebugTarget != null && iDebugTarget == debugTarget) {
			if (debugEngine != null) {
				performCommand("quit");
			}
		}
	}

	/**
	 * @see DebugEngineEventListener
	 */
	public class GdbEngineEventListener implements DebugEngineEventListener {
		public GdbEngineEventListener() {
		}
		public void commandLogResponse(DebugEngineCommandLogResponseEvent event) {
			String[] responseLines = event.getResponseLines();
			if (responseLines == null || responseLines.length == 0) {
				//addItem("");
			} else {
				for (int i = 0; i < responseLines.length; i++) {
					if (responseLines.length == 1 && responseLines[0].equals(""))
						break;
					addItem(responseLines[i]);
				}
			}
		}
		public void debugEngineTerminated(DebugEngineTerminatedEvent event) {
			debugEngine = null;
			iDebugTarget = null;
			addItem("\r" + GDBPICL_INACTIVE);
			setLabel(GDBPICL_INACTIVE);
			debuggeeName = "";
		}
		public void errorOccurred(ErrorOccurredEvent event) {
			addItem("\r" + GDBPICL_SENT_ERROR + event.getMessage());
		}
		public void messageReceived(MessageReceivedEvent event) {
			addItem("\r" + GDBPICL_SENT_MESSAGE + event.getMessage());
		}
		public void engineCapabilitiesChanged(EngineCapabilitiesChangedEvent event) {
			;
		}
		public void modelStateChanged(ModelStateChangedEvent event) {
			;
		}
		public void processAdded(ProcessAddedEvent event) {
			//      System.out.println("#### DebugConsoleView.GdbEngineEventListener.processAdded" );
			//      DebuggeeProcess process = event.getProcess();
			//      process.addEventListener(new GdbProcessEventListener());
		}
	}

	private void performCommand(String cmd) {
		if (debugEngine == null) {
			addItem(GDBPICL_INACTIVE_REJECTED_COMMAND + " " + cmd);
			return;
		}
		try {
			addItem("\r" + COMMAND + " " + cmd);
			debugEngine.commandLog(cmd, DebugEngine.sendReceiveSynchronously);
		} catch (java.io.IOException exc) {
			debugEngine = null;
			iDebugTarget = null;
			addItem("\r" + GDBPICL_INACTIVE);
			setLabel(GDBPICL_INACTIVE);
			debuggeeName = "";
		}
	}
	private void addItem(final String str) {
		display.asyncExec(new Runnable() {
			public void run() {
				if (responses == null || responses.getTextWidget() == null) {
					return;
				}
				StyledText textArea = responses.getTextWidget();
				int newChars = str.length() + 2;
				int max = textArea.getTextLimit();
				int current = textArea.getCharCount();
				if ((current + newChars) >= max) {
					int endChar = AUTOCUT_TEXT + 200;
					if (endChar >= current)
						endChar = current - 1;
					String s = textArea.getText(AUTOCUT_TEXT, endChar);
					int endLine = AUTOCUT_TEXT;
					int length = s.length();
					for (int i = 0; i < length; i++) {
						if (s.charAt(i) == '\r') {
							endLine = endLine + i + 1;
							break;
						}
					}

					textArea.setSelection(0, endLine);
					deleteSelection();
				}

				textArea.append("\r" + str);
				textArea.setSelection(textArea.getCharCount());
				textArea.setHorizontalIndex(0);
				String msg = str;
				if (msg.startsWith("\r"))
					msg = msg.substring(1);
				if (msg.startsWith(GDBPICL_COMMAND))
					return;
				if (msg.endsWith(lastLabel))
					return;
			}
		});
	}
	private void setLabel(final String str) {
		lastLabel = str;
		display.asyncExec(new Runnable() {
			public void run() {
				if (label != null && !label.isDisposed())
					label.setText(str);
				if (parent != null && !parent.isDisposed())
					parent.layout();
			}
		});
	}

	public void deleteSelection() {
		StyledText textArea = responses.getTextWidget();
		textArea.setEditable(true);
		responses.doOperation(org.eclipse.jface.text.ITextOperationTarget.DELETE);
		//    textArea.cut();   // cut also copies to clipboard
		textArea.setEditable(false);
	}
	public void copySelection() {
		StyledText textArea = responses.getTextWidget();
		textArea.setEditable(true);
		textArea.copy();
		textArea.setEditable(false);
	}

	// ***************************************************************************
	// Internationalization Initialization
	// ***************************************************************************
	private void init_Initialization() {

		try {
			_messagesBundle =
				ResourceBundle.getBundle("com.ibm.debug.internal.gdb.GdbViewMessages");
		} catch (MissingResourceException e) {}

	}


	/**
	 * Get a resource string from the Messages ResourceBundle object
	 */
	public String getResourceString(String key) {
		if (_messagesBundle == null) {
			return key;
		}
		try {
			return _messagesBundle.getString(key);
		} catch (MissingResourceException e) {
			return "!" + key + "!";
		}
	}

	private void initializeMessagesOnce() {
		GDBPICL_INACTIVE = PICLUtils.getResourceString(GDBPICL_INACTIVE);
		GDBPICL_ACTIVE = PICLUtils.getResourceString(GDBPICL_ACTIVE);
		GDBPICL_COMMAND = PICLUtils.getResourceString(GDBPICL_COMMAND);
		COMMAND = PICLUtils.getResourceString(COMMAND);
		GDBPICL_INACTIVE_REJECTED_COMMAND = PICLUtils.getResourceString(GDBPICL_INACTIVE_REJECTED_COMMAND);
		GDBPICL_COMMAND_IO_EXCEPTION = PICLUtils.getResourceString(GDBPICL_COMMAND_IO_EXCEPTION);
		GDBPICL_SENT_ERROR = PICLUtils.getResourceString(GDBPICL_SENT_ERROR);
		GDBPICL_SENT_MESSAGE = PICLUtils.getResourceString(GDBPICL_SENT_MESSAGE);
		GDBPICL_IS_TERMINATED_OR_DISCONNECTED = PICLUtils.getResourceString(GDBPICL_IS_TERMINATED_OR_DISCONNECTED);
		GDBPICL_IS_OVERWRITING_EXISTING_DEBUGENGINE =  PICLUtils.getResourceString(GDBPICL_IS_OVERWRITING_EXISTING_DEBUGENGINE);
	}
	String GDBPICL_INACTIVE = PREFIX + "inactive";
	String GDBPICL_ACTIVE = PREFIX + "active";
	String GDBPICL_COMMAND = PREFIX + "piclCommand";
	String COMMAND = PREFIX + "command";
	String GDBPICL_INACTIVE_REJECTED_COMMAND = PREFIX + "inactiveRejected";
	String GDBPICL_COMMAND_IO_EXCEPTION = PREFIX + "commandIOException";
	String GDBPICL_SENT_ERROR = PREFIX + "sentError";
	String GDBPICL_SENT_MESSAGE = PREFIX + "sentMessage";
	String GDBPICL_IS_TERMINATED_OR_DISCONNECTED = PREFIX + "terminatedOrDisconnected";
	String GDBPICL_IS_OVERWRITING_EXISTING_DEBUGENGINE = PREFIX + "overwritingExistingEngine";

	/*
	 * @see ILaunchListener#launchRemoved(ILaunch)
	 */
	public void launchRemoved(ILaunch launch) {
	}

	/*
	 * @see ILaunchListener#launchAdded(ILaunch)
	 */
	public void launchAdded(ILaunch launch) {
	}

	/*
	 * @see ILaunchListener#launchChanged(ILaunch)
	 */
	public void launchChanged(ILaunch launch) {
	}


}
