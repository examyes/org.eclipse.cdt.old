package com.ibm.debug.internal.pdt.ui.editor;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.lpex.alef.LpexContextContributor;

/**
 * This class provides editor actions like print and cut & paste,
 * all of which is inherited from LpexContextContributor.
 */

public class DebuggerEditorContextContributor extends LpexContextContributor {

	/**
	 * Constructor for DebuggerEditorContextContributor
	 */
	public DebuggerEditorContextContributor() {
		super();
	}
}
