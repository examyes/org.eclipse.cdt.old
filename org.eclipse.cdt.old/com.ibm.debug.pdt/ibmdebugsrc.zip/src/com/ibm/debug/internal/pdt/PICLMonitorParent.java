package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;

import com.ibm.debug.internal.pdt.model.MonitoredExpression;


public class PICLMonitorParent extends PICLDebugElement {
	Object[] fExpandedElements = null;


	/**
	 * Constructor for PICLMonitorParent
	 */
	public PICLMonitorParent(IDebugElement parent, IDebugTarget debugTarget) {
		super(parent, debugTarget);
	}


	/**
	 * Add a monitored expression to this parent
	 * @param The monitored expression
	 */
	public void addMonitoredExpression(MonitoredExpression expression) {
		addChild(new PICLVariable(this,expression, getDebugTarget()), true);
	}


	/**
	 * @see PICLDebugElement#doCleanupDetails()
	 */
	protected void doCleanupDetails() {
	}


	/**
	 * This label is not displayed.
	 * @see PICLDebugElement#getLabel(boolean)
	 */
	public String getLabel(boolean qualified) {
		return "PICLMonitorParent label";
	}


	

    /**
     * Stores the current expanded state of its child tree.
     * Used to restore tree to current state next time selection returns
     * to current selected thread in debug view.
     *
     * @see getExpandedElements()
     */
    public void setExpandedElements(Object[] state){
    	fExpandedElements = state;
    }

    /**
     * Returns the current expanded state of its child tree.
     * Used to restore tree to current state when selection returns
     * to current selected thread in debug view.
     *
     * @see setExpandedElements()
     */
    public Object[] getExpandedElements(){
		return fExpandedElements;
	}

	/**
	 * Reset all of the monitors owned by this parent
	 */
	public void resetChanged() {
		// loop through all of the monitors and reset the changed flags

		if (!hasChildren())
			return;

		IDebugElement monitors[] = null;

		try {
			monitors = getChildrenNoExpand();
		} catch(DebugException de) {
			return;
		}
		for (int i = 0;i < monitors.length; i++)
			((PICLVariable)monitors[i]).resetChanged();

	}

}
