package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.model.ViewInformation;
import java.io.IOException;

/**
 * Represents a request to step return
 */

public class StepReturnRequest extends StepRequest {

    /**
     * Constructor for StepReturnRequest
     */
    public StepReturnRequest(PICLDebugTarget debugTarget, PICLThread threadContext, ViewInformation viewInformation) {
        super(debugTarget, threadContext, viewInformation);
    }

    /**
     * @see PICLEngineRequest#execute()
     */
    public void execute() throws PICLException {
    	beginRequest();

    	try {
	    	fThreadContext.fDebuggeeThread.stepReturn(fViewInformation,asyncRequest(), this);
    	} catch(IOException ioe) {
			throw new PICLException(PICLUtils.getResourceString(msgKey + "send_error"));
    	}

    	// NOTE: there is no call to endRequest() because this request is not complete yet...  At some time later the
    	//       model will fire an event that represents the end of this request.

    }

}

