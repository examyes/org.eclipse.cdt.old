package com.ibm.debug.internal.pdt.ui.views;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.util.ArrayList;

import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

import com.ibm.debug.internal.pdt.PICLFile;
import com.ibm.debug.internal.pdt.PICLFunction;
import com.ibm.debug.internal.pdt.PICLModule;
import com.ibm.debug.internal.pdt.PICLPart;


public class ModulesFilterDebuggable extends ViewerFilter {

	/**
	 * @see ViewerFilter#select(Viewer, Object, Object)
	 */
	public boolean select(Viewer viewer, Object parentElement, Object element) {
		return hasDebugInfo(element);
	}

	/**
	 * @see ViewerFilter#filter(Viewer, Object, Object[])
	 */
	public Object[] filter(Viewer viewer, Object parent, Object[] elements) {
		ArrayList arrayList = new ArrayList();
		for (int i=0; i < elements.length; i++) {
			if (hasDebugInfo(elements[i]))
				arrayList.add(elements[i]);
		}
		return arrayList.toArray();
	}

	/**
	 * Determines if the passed element should be considered to have debug info
	 * @return boolean 
	 */
	private boolean hasDebugInfo(Object obj) {
		if (obj instanceof PICLModule)
			return ((PICLModule)obj).getModule().hasDebugInfo();
		else
			if (obj instanceof PICLPart)
				return ((PICLPart)obj).getPart().hasDebugInfo();
			else
				if (obj instanceof PICLFile)
					return ((PICLFile)obj).hasSource();
				else
					if (obj instanceof PICLFunction)
						return true;
					else
						return false;
	}
}
