package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


public class StorageChangedEvent extends StorageEvent
{
  StorageChangedEvent(Object source, Storage storage, int requestCode)
  {
    super(source, storage, requestCode);
  }

  /**
   * @see ModelEvent#fire(ModelEventListener)
   */

  void fire(ModelEventListener listener)
  {
    ((StorageEventListener)listener).storageChanged(this);
  }

  /**
   * Will return true if the Storage object has been fundamentally rebuilt.
   * In this case the listener should throw away its representation of
   * the storage and rebuild as well using the new contents of the Storage object.
   */

  public boolean rebuild()
  {
    return _rebuild;
  }

  private boolean _rebuild = true;
}
