package com.ibm.debug.internal.pdt.ui.dialogs;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.debug.core.model.ISourceLocator;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLException;
import com.ibm.debug.internal.pdt.PICLThread;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.Location;
import com.ibm.debug.internal.pdt.model.ViewInformation;
import com.ibm.debug.internal.pdt.ui.views.MonitorView;
import com.ibm.debug.internal.pdt.ui.views.StorageView;
import com.ibm.debug.pdt.WorkspaceSourceLocator;


/**
 * Dialog to monitor expressions (program monitors show up in Monitors View, storage monitors show up in Storage View)
 */
public class MonitorExpressionDialog extends StatusDialog {
	protected final static String PREFIX= "MonitorExpressionDialog.";

	private PICLThread thread;
	private boolean defaultIsStorageMonitor;

	private Text expressionInput;
	private Button monitorTypeIsProgramButton;
	private Button monitorTypeIsStorageButton;
	private Group monitorTypeGroup;
	private Label fileNameLabel;
	private Label lineNumberLabel;
	private Label viewInfoLabel;
	private Label threadNameLabel;

	/**
	 * Constructor for MonitorExpressionDialog
	 */
	public MonitorExpressionDialog(Shell parentShell, PICLThread thread, boolean defaultIsStorageMonitor) {
		super(parentShell);
		setTitle(PICLUtils.getResourceString(PREFIX+"label.title"));
		this.thread = thread;
		this.defaultIsStorageMonitor = defaultIsStorageMonitor;

		WorkbenchHelp.setHelp(parentShell, PICLUtils.getHelpResourceString("MonitorExpressionDialog"));
	}

	protected Control createDialogArea(Composite ancestor) {
		Composite parent = new Composite(ancestor, SWT.NULL);
		//FillLayout fill = new FillLayout();
		//fill.type = SWT.VERTICAL;
		//parent.setLayout(fill);
		//parent.setLayout(new RowLayout());
		parent.setLayout(new GridLayout());
		GridData spec2= new GridData();
		spec2.grabExcessVerticalSpace= true;
		spec2.grabExcessHorizontalSpace= true;
		spec2.horizontalAlignment= spec2.FILL;
		spec2.verticalAlignment= spec2.CENTER;
		parent.setLayoutData(spec2);


		expressionInput = new Text(parent, SWT.BORDER);
		GridData spec= new GridData();
		spec.grabExcessVerticalSpace= false;
		spec.grabExcessHorizontalSpace= true;
		spec.horizontalAlignment= spec.FILL;
		spec.verticalAlignment= spec.BEGINNING;
		expressionInput.setLayoutData(spec);

		monitorTypeGroup = new Group (parent, SWT.NONE);
		monitorTypeGroup.setLayout (new GridLayout());
		monitorTypeGroup.setLayoutData (new GridData (GridData.HORIZONTAL_ALIGN_FILL | GridData.VERTICAL_ALIGN_FILL));
		monitorTypeGroup.setText(PICLUtils.getResourceString(PREFIX+"label.group"));

		monitorTypeIsProgramButton = new Button(monitorTypeGroup, SWT.RADIO);
		monitorTypeIsProgramButton.setText(PICLUtils.getResourceString(PREFIX+"label.programmonitor"));
		monitorTypeIsStorageButton = new Button(monitorTypeGroup, SWT.RADIO);
		monitorTypeIsStorageButton.setText(PICLUtils.getResourceString(PREFIX+"label.storagemonitor"));

		Group evaluationGroup = new Group(parent, SWT.SHADOW_NONE);
		evaluationGroup.setLayout(new GridLayout());
		evaluationGroup.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_FILL | GridData.VERTICAL_ALIGN_FILL));
		evaluationGroup.setText(PICLUtils.getResourceString(PREFIX+"label.context"));

		fileNameLabel = new Label(evaluationGroup, SWT.NULL);
		lineNumberLabel = new Label(evaluationGroup, SWT.NULL);
		viewInfoLabel = new Label(evaluationGroup, SWT.NULL);
		threadNameLabel = new Label(evaluationGroup, SWT.NULL);

		initStatusInfo();

		expressionInput.setFocus();
		return parent;
	}


	private void initStatusInfo() {
		try {
			ViewInformation viewInfo = thread.getViewInformation();
			Location location = thread.getLocation(viewInfo);

			if (defaultIsStorageMonitor) {
				monitorTypeIsStorageButton.setSelection(true);
			} else {
				monitorTypeIsProgramButton.setSelection(true);
			}
			fileNameLabel.setText(PICLUtils.getResourceString(PREFIX+"label.filename") + " " + location.file().name());
			lineNumberLabel.setText(PICLUtils.getResourceString(PREFIX+"label.linenumber") +  " " + Integer.toString(location.lineNumber()));
			viewInfoLabel.setText(PICLUtils.getResourceString(PREFIX+"label.viewtype") + " " + viewInfo.name());
			threadNameLabel.setText(PICLUtils.getResourceString(PREFIX+"label.threadname") + " " + thread.getName());
		} catch (Exception e) {
		}
	}


	protected void okPressed() {
		String expression = expressionInput.getText().trim();

		if (thread == null || !(thread instanceof PICLThread) || thread.isTerminated()) {
			PICLUtils.logText(PREFIX + ": invalid thread");
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.invalid_thread"));
			return;
		}

		int lineNum = ((PICLThread)thread).getLocation(((PICLThread)thread).getViewInformation()).lineNumber();

		//get the resource (project) and viewinformation associated with the thread
		IResource inputResource = null;
		ViewInformation viewInfo = null;

		ISourceLocator sourceLocator = thread.getLaunch().getSourceLocator();
		if (sourceLocator instanceof WorkspaceSourceLocator) {
			WorkspaceSourceLocator wslocator = (WorkspaceSourceLocator) sourceLocator;
			inputResource  = wslocator.getHomeProject();
		}
		if (inputResource == null) {
			PICLUtils.logText(PREFIX + ": invalid resource");
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.invalid_resource"));
			return;
		}

		// create a marker on the resource and set the line number and file name where the expression is to be evaluated
		IMarker monitorMarker = null;
		try {
			monitorMarker = inputResource.createMarker(IPICLDebugConstants.PICL_MONITORED_EXPRESSION);
			monitorMarker.setAttribute(IMarker.LINE_NUMBER, lineNum);
			monitorMarker.setAttribute(IPICLDebugConstants.SOURCE_FILE_NAME, thread.getLocation(thread.getViewInformation()).file().name());
		} catch (Exception e) {
			PICLUtils.logError(e);
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.marker"));
			return;
		}

		//open a new view if necessary
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) {
			PICLUtils.logText(PREFIX + ": error getting ActivePage()");
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.no_activepage"));
			return;
		}
		IViewPart view = null;
		if (monitorTypeIsStorageButton.getSelection()) {
			view= p.findView(IPICLDebugConstants.STORAGE_VIEW);
		} else {
			view= p.findView(IPICLDebugConstants.MONITOR_VIEW);
		}
		if (view == null) {
			try {
				IWorkbenchPart activePart= p.getActivePart();
				if (monitorTypeIsStorageButton.getSelection()) {
					view= (StorageView) p.showView(IPICLDebugConstants.STORAGE_VIEW);
				} else {
					view= (MonitorView) p.showView(IPICLDebugConstants.MONITOR_VIEW);
				}
				p.activate(activePart);
			} catch (PartInitException e) {
				PICLUtils.logError(e);
				if (monitorTypeIsStorageButton.getSelection()) {
					MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.could_not_open_storage_view"));
				} else {
					MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.could_not_open_monitors_view"));
				}
				return;
			}
		}


		try {
			if (monitorTypeIsStorageButton.getSelection()) {
				((PICLThread)thread).monitorStorage(monitorMarker, expression, viewInfo);
			} else {
				((PICLThread)thread).monitorExpression(monitorMarker, expression, viewInfo);
			}
		} catch (PICLException pe) {
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getFormattedString(PREFIX+"error.could_not_be_evaluated", new String[] {"\"" + PICLUtils.getNonMnemonicString(expression) +"\"", "\"" + ((PICLThread)thread).getLabel(true) + "\""}));
			return;
		}

		if (view instanceof IDebugView) {
			p.bringToTop(view);
			if (((IDebugView)view).getViewer() != null)
				((IDebugView)view).getViewer().refresh();
		}

		super.okPressed();
	}


	private SelectionListener fListListener= new SelectionAdapter() {
		public void widgetSelected(SelectionEvent event) {
		}

		public void widgetDefaultSelected(SelectionEvent event) {
				okPressed();
		}
	};
}
