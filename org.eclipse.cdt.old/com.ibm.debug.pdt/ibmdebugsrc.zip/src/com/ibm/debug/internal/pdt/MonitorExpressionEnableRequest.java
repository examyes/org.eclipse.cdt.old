package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.model.MonitoredExpression;
import java.io.IOException;


public class MonitorExpressionEnableRequest extends MonitorRequest {

	private PICLVariable fPICLVariable = null;

	/**
	 * Constructor for MonitorExpressionEnableRequest
	 */
	public MonitorExpressionEnableRequest(PICLDebugTarget debugTarget,
										  PICLVariable piclVariable) {
		super(debugTarget);
		fPICLVariable = piclVariable;
	}

	/**
	 * @see PICLEngineRequest#execute()
	 */
	public void execute() throws PICLException {

		beginRequest();

		MonitoredExpression mon = fPICLVariable.getMonitoredExpression();

		boolean rc = true;

		try {
			rc = mon.enable(syncRequest());
            if (!rc)
 	      		throw new PICLException(PICLUtils.getResourceString(msgKey + "send_error"));
    	} catch(IOException ioe) {
			throw(new PICLException(PICLUtils.getResourceString(msgKey + "send_error")));
    	} finally {
	    	endRequest();
    	}
	}

}

