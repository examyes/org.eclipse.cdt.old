package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * The super class for all process events.
 */

public abstract class ProcessEvent extends ModelEvent
{
  ProcessEvent(Object source, DebuggeeProcess process, int requestCode)
  {
    super(source, requestCode);
    _process = process;
  }

  public DebuggeeProcess getProcess()
  {
    return _process;
  }

  private DebuggeeProcess _process;
}
