package com.ibm.debug.internal.pdt.ui.views;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.Launch;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.ui.AbstractDebugView;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITreeViewerListener;
import org.eclipse.jface.viewers.TreeExpansionEvent;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PDTModelPresentation;
import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLStorageMapParent;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.ui.actions.CopyTreeViewToClipboardAction;
import com.ibm.debug.internal.pdt.ui.actions.MapStorageAction;
import com.ibm.debug.internal.pdt.ui.actions.PrintTreeViewAction;
import com.ibm.debug.internal.pdt.ui.actions.RemoveMappingAction;
import com.ibm.debug.internal.pdt.ui.actions.ShowTypeInfoAction;


public class StorageMapView extends AbstractDebugView implements ISelectionListener, IDoubleClickListener, ITreeViewerListener {
	protected final static String PREFIX= "StorageMapView.";
	private TreeViewer fTreeViewer = null;

	protected StorageMapContentProvider fContentProvider= null;

	protected MapStorageAction fMapStorageAction;
	protected RemoveMappingAction fRemoveMappingAction;
	protected ShowTypeInfoAction fShowTypeInfoAction;
	protected CopyTreeViewToClipboardAction fCopyTreeViewToClipboardAction;
	protected PrintTreeViewAction fPrintTreeViewAction;


	/**
	 * @see AbstractDebugView#createViewer(Composite)
	 */
	protected Viewer createViewer(Composite parent) {
		addListeners();
		fTreeViewer = new TreeViewer(parent, SWT.MULTI);
		fContentProvider = new StorageMapContentProvider();
		fTreeViewer.setContentProvider(fContentProvider);
		fTreeViewer.setLabelProvider(new PDTModelPresentation());
		setInitialContent();
		setTitleToolTip(PICLUtils.getResourceString(PREFIX+"tooltip"));
		return fTreeViewer;
	}

	/**
	 * @see AbstractDebugView#createActions()
	 */
	protected void createActions() {
		fMapStorageAction= new MapStorageAction();
		fMapStorageAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_MONITOR_EXPRESSION));
		fMapStorageAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_MONITOR_EXPRESSION));
		fMapStorageAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_MONITOR_EXPRESSION));
		fMapStorageAction.setEnabled(false);

		fRemoveMappingAction= new RemoveMappingAction(fTreeViewer);
		fRemoveMappingAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_REMOVE_MONITOR));
		fRemoveMappingAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_REMOVE_MONITOR));
		fRemoveMappingAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_REMOVE_MONITOR));
		fRemoveMappingAction.setChecked(false);

		fShowTypeInfoAction= new ShowTypeInfoAction(fTreeViewer);
		fShowTypeInfoAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_SHOW_TYPE_NAMES));
		fShowTypeInfoAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_SHOW_TYPE_NAMES));
		fShowTypeInfoAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_SHOW_TYPE_NAMES));
		fShowTypeInfoAction.setChecked(false);

		fCopyTreeViewToClipboardAction= new CopyTreeViewToClipboardAction(fTreeViewer);
		fCopyTreeViewToClipboardAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_COPY_VIEW_TO_CLIPBOARD));
		fCopyTreeViewToClipboardAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_COPY_VIEW_TO_CLIPBOARD));
		fCopyTreeViewToClipboardAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_COPY_VIEW_TO_CLIPBOARD));
		fCopyTreeViewToClipboardAction.setChecked(false);

		fPrintTreeViewAction= new PrintTreeViewAction(fTreeViewer, PICLUtils.getResourceString(PREFIX+"printjobtitle"));
		fPrintTreeViewAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_PRINT_VIEW));
		fPrintTreeViewAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_PRINT_VIEW));
		fPrintTreeViewAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_PRINT_VIEW));
		fPrintTreeViewAction.setChecked(false);

	}

	/**
	 * @see AbstractDebugView#configureToolBar(IToolBarManager)
	 */
	protected void configureToolBar(IToolBarManager tbm) {
		tbm.add(new Separator(this.getClass().getName()));
		tbm.add(fMapStorageAction);
		tbm.add(fRemoveMappingAction);
		tbm.add(new Separator(this.getClass().getName()));
		tbm.add(fShowTypeInfoAction);
		tbm.add(new Separator(this.getClass().getName()));
		tbm.add(fCopyTreeViewToClipboardAction);
		tbm.add(fPrintTreeViewAction);
	}

	/**
	 * @see AbstractDebugView#getHelpContextId()
	 */
	protected String getHelpContextId() {
		return PICLUtils.getHelpResourceString("StorageMapView");
	}

	/**
	 * @see AbstractDebugView#fillContextMenu(IMenuManager)
	 */
	protected void fillContextMenu(IMenuManager menu) {

		menu.add(new Separator(this.getClass().getName()));
		menu.add(fMapStorageAction);
		menu.add(fRemoveMappingAction);
		menu.add(new Separator(this.getClass().getName()));
		menu.add(fShowTypeInfoAction);

		menu.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
	}

	protected void setInitialContent() {
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) { return; }
		IViewPart view= p.findView(IDebugUIConstants.ID_DEBUG_VIEW);
		if (view == null) {
			try {
				IWorkbenchPart activePart= p.getActivePart();
				view= p.showView(IDebugUIConstants.ID_DEBUG_VIEW);
				p.activate(activePart);
			} catch (PartInitException e) {
				PICLUtils.logError(e);
				return;
			}
		}
		if (!(view instanceof IDebugView)) { return; }
		((IDebugView)view).getViewer().setSelection(((IDebugView)view).getViewer().getSelection());
	}


	/**
	 * @see IDoubleClickListener#doubleClick(DoubleClickEvent)
	 */
	public void doubleClick(DoubleClickEvent event) {
    	IStructuredSelection selection = (IStructuredSelection)event.getSelection();
		if (selection.size() != 1) 	//Single selection only
			return;

		//Get the selected monitored variable
		IDebugElement source = (IDebugElement) selection.getFirstElement();
//		if(! (source instanceof IVariable)) { return; }
//		try {
//			if (((IVariable)source).getValue().getVariables() != null) { //expand/collapse
				if (fTreeViewer.getExpandedState(source))
					fTreeViewer.collapseToLevel(source,1);
				else
					fTreeViewer.expandToLevel(source,1);
//			} else { //edit the value
//				fEditVariableValueAction.run();
//			}
//		} catch (DebugException de) {}
	}

	/**
	 * Handles key events in viewer.  Specifically interested in
	 * the Delete key.
	 */
	protected void handleKeyPressed(KeyEvent event) {
//		if (event.character == SWT.DEL && event.stateMask == 0
//			&& fRemoveVariableFromMonitorAction.isEnabled()) {
//				fRemoveVariableFromMonitorAction.run();
//		}
	}


	/**
	 * Remove myself as a selection listener to the <code>LaunchesView</code> in this perspective.
	 *
	 * @see IWorkbenchPart
	 */
	public void dispose() {
		removeListeners();
		//exception occurs sometimes when tree already disposed
		try{
			if (fTreeViewer != null) {
				fTreeViewer.removeTreeListener(this);
				fTreeViewer.removeDoubleClickListener(this);
			}
		}catch(Exception e) {}
		super.dispose();
	}

	public void partClosed(IWorkbenchPart part) {
		if (!(part instanceof MonitorView))
			return;
		//TODO: stop add/update events from the model
		removeListeners();
		try {
			if (fTreeViewer != null) {
				fTreeViewer.removeTreeListener(this);
				fTreeViewer.removeDoubleClickListener(this);
			}
		} catch (Exception e) {}
		super.partClosed(part);
	}


	/**
	 * @see ITreeViewerListener#treeCollapsed(TreeExpansionEvent)
	 */
	public void treeCollapsed(TreeExpansionEvent event) {
	}
	/**
	 * @see ITreeViewerListener#treeExpanded(TreeExpansionEvent)
	 */
	public void treeExpanded(TreeExpansionEvent event) {
	}
	
	
	/**
	 * @see ISelectionListener#selectionChanged(IWorkbenchPart, ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {

		if (fTreeViewer == null || fTreeViewer.getContentProvider() == null) {
			return;
		}

		IStructuredSelection ssel = (IStructuredSelection) selection;

		PICLDebugElement de = null;

		// check if the selection is a PICLDebugElement
		if ((ssel.getFirstElement() instanceof PICLDebugElement))
			de = (PICLDebugElement)ssel.getFirstElement();
		else
			if ((ssel.getFirstElement() instanceof Launch)) {
				Launch l = (Launch)ssel.getFirstElement();
				if (l.getDebugTarget() instanceof PICLDebugElement)
					de = (PICLDebugTarget)l.getDebugTarget();
			}

		if (de == null)  // nothing selected that the storage mapping view can show
			fTreeViewer.setInput(null);
		else {
			// check to see if a change is required

			PICLStorageMapParent mapParent = ((PICLDebugTarget)de.getDebugTarget()).getStorageMapParent();

			if (fTreeViewer.getInput() != null && fTreeViewer.getInput().equals(mapParent)) { // no change required because it matches
				fTreeViewer.refresh();
				return;
			} else {
				//save the current tree expanded state in the current parent
				Object current = fTreeViewer.getInput();
				if (current !=null && current instanceof PICLStorageMapParent)
					((PICLStorageMapParent)current).setExpandedElements(fTreeViewer.getExpandedElements());
				//set the input to the new parent
				fTreeViewer.setInput(mapParent);
				//restore any previously expanded state of the new parent
				if(mapParent != null && mapParent.getExpandedElements() != null)
					fTreeViewer.setExpandedElements(mapParent.getExpandedElements());
			}
		}


	}

	private void addListeners() {
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().addSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
	}
	
	private void removeListeners() {
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().removeSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
	}
}
