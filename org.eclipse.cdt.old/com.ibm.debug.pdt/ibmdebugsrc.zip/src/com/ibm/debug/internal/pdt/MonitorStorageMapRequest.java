package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;

import com.ibm.debug.epdc.EPDC;
import com.ibm.debug.internal.pdt.model.DebuggeeProcessEventListener;
import com.ibm.debug.internal.pdt.model.Location;
import com.ibm.debug.internal.pdt.model.Storage;
import com.ibm.debug.internal.pdt.model.StorageStyle;
import com.ibm.debug.internal.pdt.model.ViewFile;
import com.ibm.debug.internal.pdt.model.ViewInformation;



/**
 * Request to start monitoring storage
 */

public class MonitorStorageMapRequest extends MonitorRequest {
	
	private PICLDebugElement fParent = null;
	private PICLThread fEvaluationThread = null;
	private IMarker fMarker = null;
	private ViewInformation fViewInformation = null;
	private String fAddressExpression = null;
	private int fNumberOfBytes = PICLStorage.NUM_BYTES;
	private Storage fStorage = null;
	private PICLStorageMap fMonitorResult = null;
	private StorageStyle fStorageStyle = null;
	private boolean fEnableStorage = true;
	private DebuggeeProcessEventListener fPrivilegedListener;

	/**
	 * Constructor for MonitorStorageRequest
	 */
	public MonitorStorageMapRequest(PICLDebugElement parent,
									PICLDebugTarget debugTarget,
									PICLThread evaluationThread,
									IMarker marker,
									ViewInformation viewInformation,
									String addressExpression) {
		super(debugTarget);

		fParent = parent;
		fEvaluationThread = evaluationThread;
		fMarker = marker;
		fViewInformation = viewInformation;
		fAddressExpression = addressExpression;
		fStorageStyle = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
	}

	/**
	 * Constructor for MonitorStorageRequest
	 */
	public MonitorStorageMapRequest(PICLDebugElement parent, 
									PICLDebugTarget debugTarget,
									PICLThread evaluationThread,
									IMarker marker,
									ViewInformation viewInformation,
									String addressExpression,
									int numberOfBytes,
									StorageStyle style,
									DebuggeeProcessEventListener privilegedListener, 
									boolean enableStorage) {

		this(parent, debugTarget, evaluationThread, marker, viewInformation, addressExpression);

		fNumberOfBytes = numberOfBytes;
		fStorageStyle = style;
		fPrivilegedListener = privilegedListener;
		fEnableStorage = enableStorage;
	}

	/**
	 * @see PICLEngineRequest#execute()
	 */
	public void execute() throws PICLException {

		beginRequest();

		Location loc = null;

		ViewFile viewFile = fDebugTarget.getViewFile(fMarker, fViewInformation);

		if (viewFile == null) {   // file not found using marker
			// check to see if this is a project marker.  If it is then use the current location in the thread.
			if (fMarker.getResource() instanceof IProject || fMarker.getResource() instanceof IWorkspaceRoot) {
				try {
					ViewInformation vi = ((PICLStackFrame)fEvaluationThread.getTopStackFrame()).findSupportedViewInformation();
					loc = fEvaluationThread.getDebuggeeThread().currentLocationWithinView(vi);
				} catch(IOException ioe) {}
			}
		} else {
			loc = new Location(viewFile, fMarker.getAttribute(IMarker.LINE_NUMBER, -1));
		}

		if (loc == null) {
            endRequest();
			throw new PICLException(PICLUtils.getResourceString(msgKey + "file_not_found"));
        }

		boolean rc = true;

		int firstOffset = 0;	//Unlike PICLStorage, we do not need or want to monitor lines before/after the offset
		int lastOffset = 0;

		try {
			rc = fDebugTarget.getDebuggeeProcess().monitorStorage(fAddressExpression,
																  loc,
																  fEvaluationThread.getDebuggeeThread(),
																  firstOffset,   // offset from address is zero
																  lastOffset,  // get # lines
																  fStorageStyle,
																  fNumberOfBytes,
																  fEnableStorage,
																  true,
																  null,
																  null,
																  syncRequest());
			if (rc && !isError())
				fMonitorResult = new PICLStorageMap(fEvaluationThread, fMarker, fViewInformation, fParent, fStorage, getDebugTarget());
			else
 	      		throw new PICLException(PICLUtils.getResourceString(msgKey + "monitor_storage_error"));
    	} catch(IOException ioe) {
			throw(new PICLException(PICLUtils.getResourceString(msgKey + "send_error")));
    	} finally {
	    	endRequest();
    	}
	}

	/**
	 * Gets the monitorResult
	 * @return Returns a PICLStorageMap
	 */
	public PICLStorageMap getMonitorResult() {
		return fMonitorResult;
	}

	/**
	 * Sets the Storage.
	 * @param fStorage The fStorage to set
	 */
	public void setStorage(Storage storage) {
		this.fStorage = storage;
	}

}

