package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.epdc.*;

public class ScalarMonitoredExpressionTreeNode extends MonitoredExpressionTreeNode
{

   ScalarMonitoredExpressionTreeNode(EStdTreeNode node,
                                     MonitoredExpression expr)
   {
      super(node, expr);

      _value = ((EStdScalarItem)(node.getTreeNodeData())).getValue();

      // Set the default representation index of this node
      // Set the array of representation indices of this node
      super.setDefRepAndRepsArray(
                    ((EStdScalarItem)(node.getTreeNodeData())).getArrayOfReps(),
                    ((EStdScalarItem)(node.getTreeNodeData())).getDefRep() );
   }

   /**
    * Return the contents of the variable as a string
    */
   public String getValue()
   {
      return _value;
   }

   private String _value;
}
