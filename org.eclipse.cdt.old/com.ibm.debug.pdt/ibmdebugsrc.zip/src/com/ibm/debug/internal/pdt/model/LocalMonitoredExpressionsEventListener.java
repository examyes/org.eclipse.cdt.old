package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


public interface LocalMonitoredExpressionsEventListener extends ModelEventListener
{
   /**
    * This method will be called when a new monitored expression has just
    * been added to the local monitor.
    * @param event The event for adding a monitored expression
    */
   public void monitoredExpressionAdded(MonitoredExpressionAddedEvent event);

   /**
    * This method will be called when the monitor for local monitored
    * expressions has been removed.
    * @param event The event for removing the local monitor
    */
   public void localExpressionsMonitorEnded(LocalMonitoredExpressionsEndedEvent event);
}
