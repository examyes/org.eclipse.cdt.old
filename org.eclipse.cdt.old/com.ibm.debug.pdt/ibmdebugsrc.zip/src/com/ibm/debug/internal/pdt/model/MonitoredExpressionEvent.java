package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * The super class for all Monitored Expression events.
 */

public abstract class MonitoredExpressionEvent extends ModelEvent
{
  MonitoredExpressionEvent(Object source, MonitoredExpression monitor,
                           int requestCode)
  {
    super(source, requestCode);
    _monitor = monitor;
  }

  /**
   * Return a monitored expression
   */
  public MonitoredExpression getMonitoredExpression()
  {
    return _monitor;
  }

  private MonitoredExpression _monitor;
}
