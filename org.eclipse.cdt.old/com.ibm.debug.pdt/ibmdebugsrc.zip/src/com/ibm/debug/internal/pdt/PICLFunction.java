package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;
import java.util.ArrayList;

import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.PropertyDescriptor;

import com.ibm.debug.internal.pdt.model.Function;
import com.ibm.debug.internal.pdt.model.Location;
import com.ibm.debug.internal.pdt.model.ViewFile;

public class PICLFunction extends PICLDebugElement
							implements IPropertySource {

	private Function fFunction = null;
	// list of attributes for display
	private static final String PREFIX = "picl_function.";
	private static final String FUNCTION_NAME = PREFIX + "function_name";
	private static final String DEMANGLED_NAME = PREFIX + "demangled_name";
	private static final String RETURN_TYPE = PREFIX + "return_type";
	private static final String LOCATION = PREFIX + "location";

	/**
	 * Constructor for PICLFunction
	 */
	public PICLFunction(IDebugElement parent, Function function, IDebugTarget debugTarget) {
		super(parent, debugTarget);

		fFunction = function;
	}

	/**
	 * @see PICLDebugElement#doCleanupDetails()
	 */
	protected void doCleanupDetails() {
		fFunction = null;
	}

	/**
	 * @see PICLDebugElement#getLabel(boolean)
	 */
	public String getLabel(boolean qualified) {
		String returnType = fFunction.getReturnType();
		String functionName = fFunction.name();

		if (returnType == null || returnType.length() == 0)
			return fFunction.name();
		else
			return "(" + returnType + ") " + functionName;
	}

	
	/**
	 * return the file name that contains this function
	 * @return file name
	 */
	public String getFileName() {

		Location loc = null;
		try {
			loc = fFunction.getLocation();
			if (loc != null) {
				ViewFile vf = loc.file();
				if (vf != null)
					return vf.baseFileName();
			}
		} catch(IOException ioe) {}

		return null;
	}

	/**
	 * returns the line number in the view file that this function is located
	 * @return line number, returns 0 if no line number
	 */
	public int getLineNumber() {
		Location loc = null;
		try {
			loc = fFunction.getLocation();
			if (loc != null)
				return loc.lineNumber();
		} catch(IOException ioe) {}

		return 0;
	}


	/**
	 * Gets the function.
	 * @return Returns a Function
	 */
	public Function getFunction() {
		return fFunction;
	}

	
	/**
	 * @see IPropertySource#getEditableValue()
	 */
	public Object getEditableValue() {
		return null;
	}

	/**
	 * @see IPropertySource#getPropertyDescriptors()
	 */
	public IPropertyDescriptor[] getPropertyDescriptors() {
		ArrayList list = new ArrayList();
		list.add(new PropertyDescriptor(FUNCTION_NAME,PICLUtils.getResourceString(FUNCTION_NAME)));
		list.add(new PropertyDescriptor(DEMANGLED_NAME,PICLUtils.getResourceString(DEMANGLED_NAME)));
		if (fFunction.getReturnType() != null)
			list.add(new PropertyDescriptor(RETURN_TYPE,PICLUtils.getResourceString(RETURN_TYPE)));
		list.add(new PropertyDescriptor(LOCATION,PICLUtils.getResourceString(LOCATION)));
		
		
		IPropertyDescriptor[] pdlist = (IPropertyDescriptor[])list.toArray(new IPropertyDescriptor[list.size()]);
		return pdlist;
	}

	/**
	 * @see IPropertySource#getPropertyValue(Object)
	 */
	public Object getPropertyValue(Object id) {
		try {
			if (id.equals(FUNCTION_NAME))
				return fFunction.name();
			else 
				if (id.equals(DEMANGLED_NAME))
					return fFunction.getDemangledName();
				else
					if (id.equals(RETURN_TYPE)) {
						return fFunction.getReturnType();
					} else 
						if (id.equals(LOCATION))
							return fFunction.getFile().name() + ":" + fFunction.getLocation().lineNumber();
						else
							return "*unknown*";
		} catch(IOException e) {
			return "*error*";
		}
	}

	/**
	 * @see IPropertySource#isPropertySet(Object)
	 */
	public boolean isPropertySet(Object id) {
		return false;
	}

	/**
	 * @see IPropertySource#resetPropertyValue(Object)
	 */
	public void resetPropertyValue(Object id) {
	}

	/**
	 * @see IPropertySource#setPropertyValue(Object, Object)
	 */
	public void setPropertyValue(Object id, Object value) {
	}

	/**
	 * @see PICLDebugElement#setEditorInput(IEditorInput)
	 * The editor input is actually shared in the parent (PICLFile)
	 */
	public void setEditorInput(IEditorInput editorInput) {
		((PICLDebugElement)getParent()).setEditorInput(editorInput);
	}

	/**
	 * @see PICLDebugElement#getEditorInput()
	 * The editor input is actually shared in the parent (PICLFile)
	 */
	public IEditorInput getEditorInput() {
		return ((PICLDebugElement)getParent()).getEditorInput();
	}

}

