package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


public abstract class DebuggeeStartupOptions
{
  public DebuggeeStartupOptions(String debuggeeName,
                                int saveRestoreFlags,
                                String saveRestoreDirectory,
                                boolean restoreSavedObjects,
                                boolean executeAfterStartup)
  {
    _debuggeeName = debuggeeName;
    _saveRestoreFlags = saveRestoreFlags;
    _saveRestoreDirectory = saveRestoreDirectory;
    _restoreSavedObjects= restoreSavedObjects;
    _executeAfterStartup = executeAfterStartup;
  }

  public String getDebuggeeName()
  {
    return _debuggeeName;
  }

  public int getSaveRestoreFlags()
  {
    return _saveRestoreFlags;
  }

  public String getSaveRestoreDirectory()
  {
    return _saveRestoreDirectory;
  }

  public boolean restoreSavedObjects()
  {
    return _restoreSavedObjects;
  }

  public boolean executeAfterStartup()
  {
    return _executeAfterStartup;
  }

  private String _debuggeeName;
  private int _saveRestoreFlags;
  private String _saveRestoreDirectory;
  private boolean _restoreSavedObjects;
  private boolean _executeAfterStartup;
}
