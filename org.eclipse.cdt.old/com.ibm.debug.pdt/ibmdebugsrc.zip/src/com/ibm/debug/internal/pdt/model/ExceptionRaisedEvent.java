package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


public class ExceptionRaisedEvent extends ProcessStoppedEvent
{
  ExceptionRaisedEvent(Object source,
                      ProcessStopInfo stopInfo,
                      String exceptionMsg,
                      int requestCode)
  {
    super(source, stopInfo, requestCode);

    _exceptionMsg = exceptionMsg;
  }

  /**
   * Returns the exception message.
   */

  public String exceptionMsg()
  {
    return _exceptionMsg;
  }


  void fire(ModelEventListener listener)
  {
    ((DebuggeeProcessEventListener)listener).exceptionRaised(this);
  }

  private String _exceptionMsg;
}
