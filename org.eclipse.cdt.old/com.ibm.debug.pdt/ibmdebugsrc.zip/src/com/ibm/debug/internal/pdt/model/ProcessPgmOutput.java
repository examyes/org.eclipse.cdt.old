package com.ibm.debug.internal.pdt.model;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////



/**
 * Represents the output of the program under debug control
 */

public class ProcessPgmOutput extends ProcessEvent {

	private String[] _lines;

	/**
	 * Constructor for ProcessPgmOutput.
	 * @param source
	 * @param process
	 * @param requestCode
	 */
	ProcessPgmOutput(Object source, DebuggeeProcess process, int requestCode, String[] lines) {
		super(source, process, requestCode);
		_lines = lines;
	}

	/*
	 * @see ModelEvent#fire(ModelEventListener)
	 */
	void fire(ModelEventListener listener) {
		((DebuggeeProcessEventListener)listener).programOutput(this);
	}

	/**
	 * Gets the program output lines.
	 * @return Returns a String[]
	 */
	public String[] getLines() {
		return _lines;
	}

	
}
