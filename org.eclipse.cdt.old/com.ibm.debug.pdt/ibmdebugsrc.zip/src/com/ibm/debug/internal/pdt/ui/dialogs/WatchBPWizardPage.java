package com.ibm.debug.internal.pdt.ui.dialogs;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.util.Vector;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.help.DialogPageContextComputer;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.model.EngineBreakpointCapabilities;
import com.ibm.debug.internal.pdt.ui.util.DialogField;
import com.ibm.debug.internal.pdt.ui.util.IDialogFieldListener;
import com.ibm.debug.internal.pdt.ui.util.StringButtonDialogField;
import com.ibm.debug.internal.pdt.ui.util.StringCombo;
import com.ibm.debug.internal.pdt.ui.util.StringDialogField;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLUtils;


/**
 * Subclasses may override these methods if required:
 * <ul>
 *  <li><code>performHelp</code> - may be reimplemented to display help for the page</li>
 *  <li><code>dispose</code> - may be extended to dispose additional allocated SWT resources</li>
 * </ul>
 * </p>
 */

/** The first page in the add watch breakpoint wizard.*/
public class WatchBPWizardPage extends BreakpointWizardPage implements IDialogFieldListener, ISettingsWriter {

	private StringDialogField addressField;
//	private StringDialogField byteField;
	private StringCombo byteList;
	private boolean monitor0_128Bytes = false;
	private boolean monitor1Byte = false;
	private boolean monitor2Bytes = false;
	private boolean monitor4Bytes = false;
	private boolean monitor8Bytes = false;

	private static IDialogSettings section;
	private static final String ADDRESS ="Address"; //profile key
	private static final String PROJECT ="Project";
	private static final String BYTES ="Bytes";

	private static final String PAGE_NAME= "WatchBPWizard.page1";

	/**
	 * Constructor for WatchBPWizardPage
	 */
	protected WatchBPWizardPage(String pageName, 
												String title, 
												ImageDescriptor titleImage, 
												boolean supports0_128Bytes, 
												boolean supports1Byte,
												boolean supports2Bytes,
												boolean supports4Bytes,
												boolean supports8Bytes) {
		super(pageName, title, titleImage);
		monitor0_128Bytes = supports0_128Bytes;
		monitor1Byte = supports1Byte;
		monitor2Bytes = supports2Bytes;
		monitor4Bytes = supports4Bytes;
		monitor8Bytes = supports8Bytes;
		setDescription(PICLUtils.getResourceString(PAGE_NAME+".description"));
	}

	/**
	 * Constructor for WatchBPWizardPage when editing
	 */
	protected WatchBPWizardPage(String pageName, 
												String title, 
												ImageDescriptor titleImage, 
												boolean supports0_128Bytes, 
												boolean supports1Byte,
												boolean supports2Bytes,
												boolean supports4Bytes,
												boolean supports8Bytes,
												IMarker breakpoint) {
		super(pageName, title, titleImage, breakpoint);
		monitor0_128Bytes = supports0_128Bytes;
		monitor1Byte = supports1Byte;
		monitor2Bytes = supports2Bytes;
		monitor4Bytes = supports4Bytes;
		monitor8Bytes = supports8Bytes;
		setDescription(PICLUtils.getResourceString(PAGE_NAME+".description"));
	}


	protected void createRequiredFields()
	{
		projectField = new StringButtonDialogField(this);
		projectField.setLabelText(PICLUtils.getResourceString(PAGE_NAME+".projectLabel"));
		projectField.setDialogFieldListener(this);
		projectField.setButtonLabel(PICLUtils.getResourceString(PAGE_NAME+".browseLabel"));

		addressField = new StringDialogField();
		addressField.setLabelText(PICLUtils.getResourceString(PAGE_NAME+".addressLabel"));
		addressField.setDialogFieldListener(this);

		byteList = new StringCombo(true);
		byteList.setLabelText(PICLUtils.getResourceString(PAGE_NAME+".byteLabel"));
		byteList.setDialogFieldListener(this);
	}


	/**
	 * @see WizardPage#createControl
	 */
	public void createControl(Composite parent) {
		super.createControl(parent);

		int nColumns= 3;

		projectField.doFillIntoGrid(composite, nColumns);
		addressField.doFillIntoGrid(composite, nColumns);
		byteList.doFillIntoGrid(composite, nColumns);
		String [] bytesToMonitor = getStorageBytesToMonitor();
		byteList.setItems(bytesToMonitor);
		byteList.setText(bytesToMonitor[0]);

		WorkbenchHelp.setHelp(composite, PICLUtils.getHelpResourceString("WatchBPWizardPage"));
		//String pageHelpID = PICLUtils.getHelpResourceString("WatchBPWizardPage");
		//sets the help for any helpless widget on the page
		//WorkbenchHelp.setHelp(getShell(), new DialogPageContextComputer(this, pageHelpID));
		//set widget specific help, with page help as backup
		//WorkbenchHelp.setHelp(projectField.getTextControl(composite), new Object[] {PICLUtils.getHelpResourceString("WatchBPWizardPage.projectField") , pageHelpID });
		//WorkbenchHelp.setHelp(projectField.getChangeControl(composite), new Object[] {PICLUtils.getHelpResourceString("WatchBPWizardPage.projectBrowse") , pageHelpID });
		//WorkbenchHelp.setHelp(addressField.getTextControl(composite), new Object[] {PICLUtils.getHelpResourceString("WatchBPWizardPage.addressField") , pageHelpID});
		//WorkbenchHelp.setHelp(byteField.getTextControl(composite), new Object[] {PICLUtils.getHelpResourceString("WatchBPWizardPage.numBytesField") , pageHelpID});


		restoreSettings();
	}

	public void dialogFieldChanged(DialogField field)
	{
		if(addressField.getText().equals("")  || projectField.getText().equals("") )
			setPageComplete(false);
		else setPageComplete(true);
	}

	/**
	 * Returns the Address or expression specified in the text field.
	 * For use by Wizard to set marker attributes.
	 */
	public String getStartAddress()
	{
		return addressField.getText();
	}

	/** Returns the value currently in the every field.
	 * For use by Wizard to set marker attributes.
	 */
	public Integer getNumBytes()
	{
		try{
			return Integer.valueOf(byteList.getText());
		}
		catch(NumberFormatException e){
			// todo: display error
			return new Integer(1);
		}
	}

	/**
	 * This method initializes the dialog fields with the values of the existing
	 * breakpoint that the user is editing.
	 */
	private void initUsingOldBreakpoint()
	{

		try{		//todo: handle null responses
			addressField.setText((String)existingBP.getAttribute(IPICLDebugConstants.ADDRESS_EXPRESSION) );
			projectField.setText(existingBP.getResource().getProject().getName()); //TODO
		 	projectField.setEnabled(false);
		 	byteList.setText( ((Integer)existingBP.getAttribute(IPICLDebugConstants.NUM_BYTES_MONITORED)).toString() );
	  	}catch(CoreException e){}
	}

	private void restoreSettings()
	{
		if(section == null)
		{
			IDialogSettings dialogSettings = getDialogSettings();
			if((section=dialogSettings.getSection(PAGE_NAME)) == null)
			{
				section=dialogSettings.addNewSection(PAGE_NAME);
			}
		}

		if(editing)
		{
			initUsingOldBreakpoint();
			return;
		}

  		String text = section.get(ADDRESS);
  		if( text != null)
	  		addressField.setText(text);

	  	text = section.get(PROJECT);
	  	if( text != null)
	  		projectField.setText(text);
	  	else   //use name of current selected debug target's project
	  		projectField.setText(getNameOfCurrentSelectedProject());

	}


	private String[] getStorageBytesToMonitor() {
		if (monitor0_128Bytes) {
			String[] elements = new String[129];
			for(int i=0; i<129; i++)
				elements[i] = "" + i;
			return elements;
		}

		Vector bytes = new Vector(4);
		if (monitor1Byte)
			bytes.add("1");
		if (monitor2Bytes)
			bytes.add("2");
		if (monitor4Bytes)
			bytes.add("4");
		if (monitor8Bytes)
			bytes.add("8");
		
		String [] stringBytes = new String[bytes.size()];
		for (int i=0; i<bytes.size(); i++) 
			stringBytes[i] = (String)bytes.elementAt(i);
		return stringBytes;

	}
	
  	/**
	 * @see ISettingsWriter#writeSettings
	 */
	public void writeSettings()
	{
		section.put(ADDRESS, addressField.getText());
		section.put(PROJECT, projectField.getText());
	}


}

