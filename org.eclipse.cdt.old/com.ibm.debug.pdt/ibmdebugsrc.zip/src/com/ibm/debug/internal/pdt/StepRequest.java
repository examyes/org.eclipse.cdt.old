package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.model.ViewInformation;

/**
 * All requests to step the debuggee inherit from this class
 */

public abstract class StepRequest extends ProgramControlRequest {

	protected PICLThread fThreadContext = null;
	protected ViewInformation fViewInformation = null;

    /**
     * Constructor for StepRequest
     */
    public StepRequest(PICLDebugTarget debugTarget, PICLThread threadContext, ViewInformation viewInformation) {
        super(debugTarget);
        fThreadContext = threadContext;
        fViewInformation = viewInformation;
    }

}

