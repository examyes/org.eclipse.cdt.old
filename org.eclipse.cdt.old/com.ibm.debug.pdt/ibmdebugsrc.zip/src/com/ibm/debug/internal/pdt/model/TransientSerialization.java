package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * This class allows us to serialize Model objects into a buffer (byte
 * array) and reconstruct those objects from the buffer.
 */

class TransientSerialization extends Serialization
{
  TransientSerialization(int flags)
  {
    super(flags);
  }

  /**
   * Serialize an object graph starting with the object 'object'. The graph
   * can later be deserialized using getGraph.
   */

  synchronized void saveGraph(Object object)
  throws java.io.IOException
  {
    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

    // Serialize the graph to the stream:

    super.saveGraph(outputStream, object);

    // Save the byte array containing the serialized graph so that it can
    // be used to deserialize in getGraph:

    _buffer = outputStream.toByteArray();
  }

  /**
   * Deserialize the object graph that was saved using saveGraph. If saveGraph
   * has not yet been called, returns null.
   */

  synchronized Object getGraph()
  throws java.io.IOException,
         java.lang.ClassNotFoundException
  {
    if (_buffer == null)
       return null;

    ByteArrayInputStream inputStream = new ByteArrayInputStream(_buffer);

    return super.getGraph(inputStream);
  }

  private byte[] _buffer;
}
