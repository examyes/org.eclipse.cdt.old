package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.PICLVariable;
import com.ibm.debug.internal.pdt.model.Representation;
import org.eclipse.jface.action.Action;
import org.eclipse.ui.help.WorkbenchHelp;

public class ChangeRepresentationAction extends Action {
	protected static final String PREFIX= "ChangeRepresentationAction.";
	private PICLVariable fVar;
	private Representation fRep;

	public ChangeRepresentationAction(PICLVariable var, Representation rep) {
		super(rep.name());
		fVar = var;
		fRep = rep;
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip"));
		WorkbenchHelp.setHelp(this, PICLUtils.getHelpResourceString("ChangeRepresentationAction"));
	}


	/**
	 * @see Action#run()
	 */
	public void run() {
		fVar.changeRepresentation(fRep);
	}

}
