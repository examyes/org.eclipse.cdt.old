package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.model.ErrorOccurredEvent;


/**
 * This class represents errors that have resulted from a request sent to a debug engine
 * The error text that can be obtained from this class is the error string that the engine returned
 */


public class PICLException extends Throwable {

	private int fReturnCode = 0;
	private int fRequestCode = 0;

    /**
     * Constructor for PICLException
     */
    public PICLException() {
        super();
    }

    /**
     * Constructor for PICLException
     */
    public PICLException(String arg0) {
        super(arg0);

    }

	public PICLException(ErrorOccurredEvent errorEvent) {
		super(errorEvent.getMessage());
		fReturnCode = errorEvent.getReturnCode();
		fRequestCode = errorEvent.getRequestCode();
	}


}

