package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.resources.IMarker;
import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IBreakpoint;
public abstract class EventBreakpointRequest extends BreakpointCreateRequest {

    /**
     * Constructor for EventBreakpointRequest
     */
    EventBreakpointRequest(IBreakpoint breakpoint, PICLDebugTarget debugTarget)
        throws DebugException {
        super(breakpoint, debugTarget);

    }

}
