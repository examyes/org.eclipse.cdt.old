package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


public class DebugEngineCommandLogResponseEvent extends DebugEngineEvent
{
   String[] _responseLines = null;
   
   DebugEngineCommandLogResponseEvent(Object source,
                      DebugEngine engine,
                      int requestCode,
                      String[] responseLines)
   {
     super(source, engine, requestCode);
     _responseLines = responseLines;
   }

   public String[] getResponseLines()
   {
       return _responseLines;
   }

  /**
   * @see ModelEvent#fire(ModelEventListener)
   */

  void fire(ModelEventListener listener)
  {
    ((DebugEngineEventListener)listener).commandLogResponse(this);
  }
}
