package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


public class MonitoredExpressionAddedEvent extends MonitoredExpressionEvent
{
  MonitoredExpressionAddedEvent(Object source,
                                MonitoredExpression monitor, int requestCode)
  {
    super(source, monitor, requestCode);
  }

  /**
   * Fire the event for monitored expressions of local or program monitor
   */
  void fire(ModelEventListener listener)
  {
    if (listener instanceof DebuggeeProcessEventListener)
        ((DebuggeeProcessEventListener)listener).monitoredExpressionAdded(this);
    else
    if (listener instanceof LocalMonitoredExpressionsEventListener)
        ((LocalMonitoredExpressionsEventListener)listener).monitoredExpressionAdded(this);

  }
}
