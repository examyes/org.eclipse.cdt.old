package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

import java.util.Enumeration;
import java.util.Vector;

import org.eclipse.debug.core.IStreamListener;
import org.eclipse.debug.core.model.IStreamMonitor;

public class PICLStreamMonitor implements IStreamMonitor {
	
	private PICLStreamsProxy fStreamsProxy = null;
	private Vector fListeners = new Vector();
	private String fText = null;

	/**
	 * Constructor for PICLStreamMonitor.
	 */
	public PICLStreamMonitor(PICLStreamsProxy streamsProxy) {
		super();
		fStreamsProxy = streamsProxy;
	}

	/**
	 * @see IStreamMonitor#addListener(IStreamListener)
	 */
	public void addListener(IStreamListener listener) {
		if (fListeners.contains(listener))
			return;
		else
			fListeners.add(listener);
	}

	/**
	 * @see IStreamMonitor#getContents()
	 */
	public String getContents() {
		String tmpText = fText;
		fText = null;
		if (tmpText == null)
			return "";
		else
			return tmpText;
	}

	/**
	 * @see IStreamMonitor#removeListener(IStreamListener)
	 */
	public void removeListener(IStreamListener listener) {
		fListeners.remove(listener);
	}

	protected void writeText(String text) {
		fText = text;
		for (Enumeration enum = fListeners.elements(); enum.hasMoreElements();)
			((IStreamListener)enum.nextElement()).streamAppended(fText,this);
	}
}
