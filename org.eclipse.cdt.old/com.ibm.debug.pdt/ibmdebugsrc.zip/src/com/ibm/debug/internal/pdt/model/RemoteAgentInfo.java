package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


public class RemoteAgentInfo
{
  public RemoteAgentInfo(String host, String password)
  {
    _host = host;
    _password = password;
  }

  public String getHost()
  {
    return _host;
  }

  public String getPassword()
  {
    return _password;
  }

  private String _host;
  private String _password;
}
