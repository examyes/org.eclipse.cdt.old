package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.model.Storage;
import java.io.IOException;

public class MonitorStorageMapDeleteRequest extends MonitorRequest {

	private PICLStorageMap fPICLStorageMap = null;

	/**
	 * Constructor for MonitorStorageDeleteRequest
	 */
	public MonitorStorageMapDeleteRequest(PICLDebugTarget debugTarget, PICLStorageMap storage) {
		super(debugTarget);

		fPICLStorageMap = storage;
	}

	/**
	 * @see PICLEngineRequest#execute()
	 */
	public void execute() throws PICLException {

		beginRequest();

		Storage storage = fPICLStorageMap.getStorage();

		boolean rc = true;

		try {
			rc = storage.remove(syncRequest());
            if (!rc)
 	      		throw new PICLException(PICLUtils.getResourceString(msgKey + "send_error"));
    	} catch(IOException ioe) {
			throw(new PICLException(PICLUtils.getResourceString(msgKey + "send_error")));
    	} finally {
	    	endRequest();
    	}

	}

}

