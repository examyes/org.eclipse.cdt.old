package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;

import com.ibm.debug.epdc.EPDC;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLStackFrame;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.Host;
import com.ibm.debug.internal.pdt.model.View;
import com.ibm.debug.internal.pdt.model.ViewInformation;

public class DebugViewMenuListener implements IMenuListener {
	protected final static String PREFIX= "DebugViewMenuListener";
	IDebugView debugView = null;

	/**
	 * Constructor for DebugViewMenuListener
	 */
	public DebugViewMenuListener(IDebugView dv) {
		super();
		debugView = dv;
	}

	/**
	 * @see IMenuListener#menuAboutToShow(IMenuManager)
	 */
	public void menuAboutToShow(IMenuManager mm) {
		if (debugView == null)
			return;
		ISelection sel = debugView.getViewer().getSelection();
		Object element = null;
		boolean show = false;

		if (sel instanceof IStructuredSelection)
			element = ((IStructuredSelection)sel).getFirstElement();
		else
			element = sel;

		//remove all items (actioncontributions) except for the "set preferred view" action and menu separators
		IContributionItem actions[] = mm.getItems();
		for (int i=0; i<actions.length; i++)
			if (!("com.ibm.debug.pdt.ui.actions.SetPreferredView".equals(actions[i].getId())) &&
				!("PreferredView".equals(actions[i].getId())) &&
				!("ViewSwitching".equals(actions[i].getId())))
					mm.remove(actions[i]);

		if (element instanceof PICLStackFrame)
		{
			PICLStackFrame stackFrame = (PICLStackFrame) element;

			//Add all the engine-supported views to the menu.  The actions themselves will determine 
			//if the selected stackframe supports their type and enable/disable themselves accordingly
		 	PICLDebugTarget pdt = (PICLDebugTarget) stackFrame.getDebugTarget();
		 	ViewInformation engineViews[] = pdt.getDebugEngine().supportedViews();

			int viewCount = (engineViews == null ? 0 : engineViews.length);
			short kind = 0;
			for (int i = 0; i < viewCount; i++)	{
				if (engineViews[i] == null) continue;
				ViewInformation vi = engineViews[i];
				if (vi == null) continue;
				kind = vi.kind();
				mm.appendToGroup("ViewSwitching", new SwitchViewAction(kind, stackFrame));
			}
		}
	}
}

