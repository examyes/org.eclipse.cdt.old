package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

import java.io.PrintWriter;

import com.ibm.debug.epdc.EFunctCustTable;

public class EngineMonitorCapabilities extends EngineCapabilitiesGroup {
	EngineMonitorCapabilities(EFunctCustTable FCTBits) {
		super(FCTBits);
	}

	/**
	 * Compare one set of capabilities with another to see if they are the
	 * same. This is typically used to find out if a given set of capabilities
	 * has changed when an EngineCapabilitiesChangedEvent is fired. This event
	 * contains the old set of engine capabilities as well as the new one.
	 * Calling isSameAs to compare the old set of capabilities with the new one
	 * allows client code to find out what has changed on
	 * less granular basis than comparing individual capabilities. If a set of
	 * capabilities has changed then the client may want to compare individual
	 * capabilities within that set to see exactly what has changed.
	 */

	public boolean isSameAs(EngineMonitorCapabilities capabilities) {
		if (capabilities == null)
			return false;
		else
			return getBits() == capabilities.getBits();
	}

	public boolean monitorEnableDisableSupported() {
		return getFCTBits().monitorEnableDisableSupported();
	}

	/**
	 * Support for locals on any stackframe
	 * @return boolean
	 */
	public boolean monitorAnyLocalsSupported() {
		return getFCTBits().monitorAnyLocalsSupported();
	}

	int getBits() {
		return getFCTBits().getMonitorCapabilities();
	}

	public void print(PrintWriter printWriter) {
		if (Model.includePrintMethods) {
			printWriter.println("Engine Monitor Capabilities:");

			printWriter.println(
				"  Monitor Enable/Disable Supported="
					+ (monitorEnableDisableSupported() ? "true" : "false"));
		}
	}
}