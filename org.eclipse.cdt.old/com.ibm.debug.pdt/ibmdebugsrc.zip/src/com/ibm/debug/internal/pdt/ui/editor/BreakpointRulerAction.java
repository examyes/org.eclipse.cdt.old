package com.ibm.debug.internal.pdt.ui.editor;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.IBreakpointManager;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.jface.text.source.IVerticalRuler;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.IUpdate;

import com.ibm.debug.common.GenericLineBreakpoint;
import com.ibm.debug.epdc.EPDC;
import com.ibm.debug.internal.pdt.EngineSuppliedViewEditorInput;
import com.ibm.debug.internal.pdt.model.Host;
import com.ibm.debug.internal.pdt.model.ViewInformation;
import com.ibm.debug.pdt.breakpoints.PICLAddressBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLLineBreakpoint;
import com.ibm.lpex.alef.LpexAbstractTextEditor;
import com.ibm.lpex.alef.LpexMarkerRulerAction;
import com.ibm.lpex.core.LpexView;

// This action is used for adding / removing breakpoints (line and address) from
// the vertical ruler of the Debugger Editor.

public class BreakpointRulerAction extends LpexMarkerRulerAction implements IUpdate {

	boolean doAddressBreakpoint = false;
	IResource resource = null;
	IBreakpointManager breakpointManager= DebugPlugin.getDefault().getBreakpointManager();
	String address = null;
	int line = 0;
	EngineSuppliedViewEditorInput engineViewEI = null;
	IFile file = null;
	/**
	 * Constructor for BreakpointRulerAction
	 */
	public BreakpointRulerAction(ResourceBundle bundle,
								String prefix,
								IVerticalRuler ruler,
								ITextEditor editor,
								String markerType) {

		super(bundle, prefix, ruler, editor, markerType, false);
	}

	/**
	 * @see MarkerRulerAction#addMarker()
	 */
	protected void addMarker() {
		IEditorInput input = getTextEditor().getEditorInput();

		line = getVerticalRuler().getLineOfLastMouseButtonActivity() + 1;

		if (input instanceof IFileEditorInput) {
			IFile file = ((IFileEditorInput) input).getFile();

			if (file != null) {
				new GenericLineBreakpoint((IResource) file, line);
			}
		} else if (input instanceof EngineSuppliedViewEditorInput) {
			engineViewEI = (EngineSuppliedViewEditorInput) input;

			ViewInformation viewInfo = engineViewEI.getViewInformation();
			short kind = viewInfo.kind();

			// Address breakpoint used for mixed and real disassembly (i.e. not AS400 statement)
			// views. Line breakpoint used for source, listing and statement views.
			doAddressBreakpoint = false;
			if (kind == EPDC.View_Class_Mixed
				|| (kind == EPDC.View_Class_Disasm && engineViewEI.getEngineHost() != EPDC.PLATFORM_ID_AS400))
				doAddressBreakpoint = true;

			// EngineSuppliedViews should only be displayed in the Debugger Editor, so we
			// can safely assume the editor is a LpexAbstractTextEditor
			LpexView lpexView = ((LpexAbstractTextEditor) getTextEditor()).getLpexView();

			// The address is determined from the "prefix" area of the source view
			String lineText = lpexView.elementText(line);
			address = lineText.substring(0, engineViewEI.getPrefixLength());

			resource = engineViewEI.getResource();
			if (resource != null) {
				String filename = engineViewEI.getName();
				if (doAddressBreakpoint) {
					PICLAddressBreakpoint breakpoint =
						new PICLAddressBreakpoint(resource, filename, line, address);
				} else {
					PICLLineBreakpoint bkp = new PICLLineBreakpoint(resource, filename, line);
				}
			}
		}
	}
	/**
	 * @see MarkerRulerAction#removeMarkers(List)
	 */
	protected void removeMarkers(List markers) {
		IBreakpointManager breakpointManager= DebugPlugin.getDefault().getBreakpointManager();
		try {

			Iterator e= markers.iterator();
			IBreakpoint breakpoint = null;
			while (e.hasNext()) {
				breakpoint = breakpointManager.getBreakpoint((IMarker)e.next());
				if (breakpoint != null)
					breakpointManager.removeBreakpoint(breakpoint, true);
			}

		} catch (CoreException e) {
		}
	}
	
}

