package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;

import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLStackFrame;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.View;
import com.ibm.debug.internal.pdt.model.ViewInformation;

public class SwitchViewAction extends Action {
	protected PICLStackFrame stackFrame = null;
	protected ViewInformation viewInfo;

	/**
	 * Constructor for SwitchViewAction
	 */
	public SwitchViewAction(short kind, PICLStackFrame stackFrame) {
		super();
		this.stackFrame = stackFrame;
		viewInfo = ((PICLDebugTarget)stackFrame.getDebugTarget()).getDebugEngine().getViewInformationByType(kind);
		setText(PICLUtils.getFormattedString("DebugViewMenuListener.showView2", viewInfo.name()));
		
		boolean isSupported = false;
		View views[] = stackFrame.getSupportedViews();
		for (int i=0; i<views.length; i++) {
			if ((views[i] != null) && (views[i].kind() == kind)) {
				isSupported = true;
				break;
			}
		}
		setEnabled(isSupported);
	}
	
	
	/**
	 * @see Action#run()
	 */
	public void run() {
		if ((stackFrame != null) && (viewInfo != null)) { 
			stackFrame.setViewInformation(viewInfo);

			// tell the view we want the file redisplayed
			Object[] myArray= new Object[]{stackFrame};
			final StructuredSelection newSelection = new StructuredSelection(myArray);
			Display.getCurrent().asyncExec(new Runnable() {
				public void run () {
					IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
					if (p == null) 	return;
					IViewPart view= p.findView(IDebugUIConstants.ID_DEBUG_VIEW);
					if ((view==null) || !(view instanceof IDebugView)) return;

					((IDebugView)view).getViewer().setSelection(newSelection);
				}
			});
		}
	}
}

