package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

public class ProcessPgmError extends ProcessEvent {

	private String[] _lines;


	/**
	 * Constructor for ProcessPgmError.
	 * @param source
	 * @param process
	 * @param requestCode
	 */
	ProcessPgmError(Object source, DebuggeeProcess process, int requestCode, String[] lines) {
		super(source, process, requestCode);
		_lines = lines;
	}

	/*
	 * @see ModelEvent#fire(ModelEventListener)
	 */
	void fire(ModelEventListener listener) {
		((DebuggeeProcessEventListener)listener).programError(this);
	}

	/**
	 * Gets the program's error lines.
	 * @return Returns a String[]
	 */
	public String[] getLines() {
		return _lines;
	}

	
}
