package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * The super class for all Storage events.
 */

public abstract class StorageEvent extends ModelEvent
{
  StorageEvent(Object source,
               Storage storage,
               int requestCode)
  {
    this(source, storage, requestCode, null, null);
  }

  StorageEvent(Object source,
               Storage storage,
               int requestCode,
               Client client, // The client that caused this event to be generated
               ModelEventListener privilegedListener
              )
  {
    super(source, requestCode, client, privilegedListener);
    _storage = storage;
  }

  public Storage getStorage()
  {
    return _storage;
  }

  private Storage _storage;
}
