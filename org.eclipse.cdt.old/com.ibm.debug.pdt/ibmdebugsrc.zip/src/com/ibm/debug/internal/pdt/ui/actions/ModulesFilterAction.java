package com.ibm.debug.internal.pdt.ui.actions;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.ViewerFilter;

import com.ibm.debug.internal.pdt.ui.views.ModulesFilterDebuggable;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLUtils;

public class ModulesFilterAction extends Action {

	private static final String PREFIX= "ModulesFilterAction.";
	private TreeViewer fTreeViewer;
	private ViewerFilter fModulesFilterDebuggable = new ModulesFilterDebuggable();

	/**
	 * Constructor for ModulesFilterAction.
	 */
	public ModulesFilterAction(TreeViewer treeViewer) {
		super(PICLUtils.getResourceString(PREFIX + "label"));
		setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_FILTER_MODULES));
		setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_FILTER_MODULES));
		setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_FILTER_MODULES));
		setToolTipText(PICLUtils.getResourceString(PREFIX + "tooltip"));
		setChecked(false);
		setId(PREFIX);
		fTreeViewer = treeViewer;
	}

	/**
	 * @see IAction#run()
	 */
	public void run() {
		if (isChecked())
			fTreeViewer.addFilter(fModulesFilterDebuggable);
		else
			fTreeViewer.removeFilter(fModulesFilterDebuggable);
	}

	/**
	 * @see IAction#getId()
	 */
	public String getId() {
		return super.getId();
	}

}
