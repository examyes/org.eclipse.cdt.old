package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1999, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


// emun CHARACTERTYPE

public class CHARACTERTYPE
{
   static public final CHARACTERTYPE INVALIDCHAR = new CHARACTERTYPE();
   static public final CHARACTERTYPE ALPHA       = new CHARACTERTYPE();
   static public final CHARACTERTYPE NUMERIC     = new CHARACTERTYPE();
   static public final CHARACTERTYPE DASH        = new CHARACTERTYPE();
   static public final CHARACTERTYPE AMPERSAND   = new CHARACTERTYPE();
   static public final CHARACTERTYPE UNDERSCORE  = new CHARACTERTYPE();
} // end calss CHARACTERTYPE


