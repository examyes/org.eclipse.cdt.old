package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2000, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.ui.views.DebugConsoleView;


public class DebugConsoleViewDeleteAction extends DebugConsoleViewAction {
	
	protected static final String PREFIX= "DebugConsoleViewDeleteAction.";
	
	/**
	 * DebugConsoleViewDeleteAction constructor.
	 * @param aView DebugConsoleView
	 * @param name java.lang.String
	 */
	public DebugConsoleViewDeleteAction(DebugConsoleView aView) {
		super(aView, PICLUtils.getResourceString(PREFIX+"label"));
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip"));
	}

	/**
	 * Removes an item
	 */
	public void run() {
		getDebugConsoleView().deleteSelection();
	}

}
