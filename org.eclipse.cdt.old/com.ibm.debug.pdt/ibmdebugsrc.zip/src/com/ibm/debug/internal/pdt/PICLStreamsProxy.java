package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import org.eclipse.debug.core.model.IStreamMonitor;
import org.eclipse.debug.core.model.IStreamsProxy;

import com.ibm.debug.internal.pdt.model.BreakpointAddedEvent;
import com.ibm.debug.internal.pdt.model.DebuggeeProcessEventListener;
import com.ibm.debug.internal.pdt.model.ExceptionRaisedEvent;
import com.ibm.debug.internal.pdt.model.ModuleAddedEvent;
import com.ibm.debug.internal.pdt.model.MonitoredExpressionAddedEvent;
import com.ibm.debug.internal.pdt.model.ProcessEndedEvent;
import com.ibm.debug.internal.pdt.model.ProcessPgmError;
import com.ibm.debug.internal.pdt.model.ProcessPgmOutput;
import com.ibm.debug.internal.pdt.model.ProcessStoppedEvent;
import com.ibm.debug.internal.pdt.model.StorageAddedEvent;
import com.ibm.debug.internal.pdt.model.ThreadAddedEvent;

/**
 * Streams proxy for I/O to debuggee
 */
public class PICLStreamsProxy implements IStreamsProxy, DebuggeeProcessEventListener {

	private PICLProcess fProcess = null;
	private PICLDebugTarget fDebugTarget = null;
	private PICLStreamMonitor fOutputStreamMonitor = new PICLStreamMonitor(this);
	private PICLStreamMonitor fErrorStreamMonitor = new PICLStreamMonitor(this);
	
	private boolean fSupported = false;

	/**
	 * Constructor for PICLStreamsProxy.
	 */
	public PICLStreamsProxy(PICLProcess process, PICLDebugTarget debugTarget) {
		super();
		
		fProcess = process;
		fDebugTarget = debugTarget;
		
		try {
			if (fDebugTarget.getDebugEngine().getCapabilities().getWindowCapabilities().programIOSupported())
				fSupported = true;
		} catch(NullPointerException npe) {}
		
	}

	/**
	 * @see IStreamsProxy#getErrorStreamMonitor()
	 */
	public IStreamMonitor getErrorStreamMonitor() {
		return fErrorStreamMonitor;
	}

	/**
	 * @see IStreamsProxy#getOutputStreamMonitor()
	 */
	public IStreamMonitor getOutputStreamMonitor() {
		return fOutputStreamMonitor;
	}

	/**
	 * @see IStreamsProxy#write(String)
	 */
	public void write(String input) throws IOException {
		
		// first check if this is supported.
		if (!fSupported)
			return;
					
		ProgramInputRequest request = new ProgramInputRequest(fDebugTarget, input);
		
		try {
			request.execute();
		} catch(PICLException e) {
		}
		// send to inputStream of DebuggeeProcess
		System.out.println("Input received: " + input);
	}

	/**
	 * @see DebuggeeProcessEventListener#breakpointAdded(BreakpointAddedEvent)
	 */
	public void breakpointAdded(BreakpointAddedEvent event) {
	}

	/**
	 * @see DebuggeeProcessEventListener#exceptionRaised(ExceptionRaisedEvent)
	 */
	public void exceptionRaised(ExceptionRaisedEvent event) {
	}

	/**
	 * @see DebuggeeProcessEventListener#moduleAdded(ModuleAddedEvent)
	 */
	public void moduleAdded(ModuleAddedEvent event) {
	}

	/**
	 * @see DebuggeeProcessEventListener#monitoredExpressionAdded(MonitoredExpressionAddedEvent)
	 */
	public void monitoredExpressionAdded(MonitoredExpressionAddedEvent event) {
	}

	/**
	 * @see DebuggeeProcessEventListener#processEnded(ProcessEndedEvent)
	 */
	public void processEnded(ProcessEndedEvent event) {
	}

	/**
	 * @see DebuggeeProcessEventListener#processStopped(ProcessStoppedEvent)
	 */
	public void processStopped(ProcessStoppedEvent event) {
	}

	/**
	 * @see DebuggeeProcessEventListener#programError(ProcessPgmError)
	 */
	public void programError(ProcessPgmError event) {
		String lines[] = event.getLines();
		if (lines == null)
			return;

		for (int i=0; i < lines.length; i++) {
			if (lines[i] != null)
				fErrorStreamMonitor.writeText(lines[i] + '\n');
		}
		
	}

	/**
	 * @see DebuggeeProcessEventListener#programOutput(ProcessPgmOutput)
	 */
	public void programOutput(ProcessPgmOutput event) {
		String lines[] = event.getLines();
		if (lines == null)
			return;
			
		for (int i=0; i < lines.length; i++) {
			if (lines[i] != null)
				fOutputStreamMonitor.writeText(lines[i] + '\n');
		}
	}

	/**
	 * @see DebuggeeProcessEventListener#storageAdded(StorageAddedEvent)
	 */
	public void storageAdded(StorageAddedEvent event) {
	}

	/**
	 * @see DebuggeeProcessEventListener#threadAdded(ThreadAddedEvent)
	 */
	public void threadAdded(ThreadAddedEvent event) {
	}

}
