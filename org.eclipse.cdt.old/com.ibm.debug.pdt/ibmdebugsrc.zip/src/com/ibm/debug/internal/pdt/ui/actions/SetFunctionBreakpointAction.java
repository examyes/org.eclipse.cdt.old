package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLFunction;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.Function;
import com.ibm.debug.pdt.WorkspaceSourceLocator;
import com.ibm.debug.pdt.breakpoints.PICLEntryBreakpoint;

public class SetFunctionBreakpointAction extends Action {

	private static final String PREFIX= "SetFunctionBreakpointAction.";
	private TreeViewer fTreeViewer;

	/**
	 * Constructor for SetFunctionBreakpointAction.
	 */
	public SetFunctionBreakpointAction(TreeViewer treeViewer) {
		super(PICLUtils.getResourceString(PREFIX + "label"));
		fTreeViewer = treeViewer;
		setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ACTIVE_BREAKPOINT));
		
		WorkbenchHelp.setHelp(this,PICLUtils.getHelpResourceString("SetFunctionBreakpointAction"));
	}

	
	
	/**
	 * @see IAction#run()
	 */
	public void run() {
		StructuredSelection sel = (StructuredSelection)fTreeViewer.getSelection();
		if (sel != StructuredSelection.EMPTY && sel.size() == 1) {   // for now support a single selection
			if (sel.getFirstElement() instanceof PICLFunction) {
				PICLFunction function = (PICLFunction)sel.getFirstElement();
				setEntryBreakpoint(function);
				// find the resource from the function
				Function fnc = function.getFunction();
				String fileName;
				try {
					fileName = fnc.getFile().baseFileName();
					WorkspaceSourceLocator locator = new WorkspaceSourceLocator();
					IResource resource = locator.findFile(fileName);
					System.out.println(fileName);
				} catch(IOException e) {
				}
				
			}
		}
		
		
	}

	private void setEntryBreakpoint(PICLFunction pFunc) {
		Function fnc = pFunc.getFunction();
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		String module = fnc.getFile().view().part().module().name();
		String part = fnc.getFile().view().part().name();
		String sourceFile = "";
		try {
			sourceFile = fnc.getFile().name();
		} catch (IOException e) {
		}
		String entryPoint = fnc.name();
		int lineNumber = 1;
		try {
			lineNumber = fnc.getLocation().lineNumber();
		} catch (IOException e) {
		}

		new PICLEntryBreakpoint(
			root,
			module,
			part,
			sourceFile,
			true,
			true,
			entryPoint,
			lineNumber);

	}

}
