package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import com.ibm.debug.internal.pdt.model.DebuggeeThread;
import com.ibm.debug.internal.pdt.model.MonitoredRegisterGroup;
import java.io.IOException;

/**
 * Request to monitor a register group.   The groups are defined by the engine.  The result
 * is that all the registers in the group are monitored
 */

public class MonitorRegisterGroupRequest extends MonitorRequest {

	PICLRegisterGroup fRegisterGroup = null;
	PICLThread fThread = null;
	MonitoredRegisterGroup fMonitoredRegisterGroup = null;


    /**
     * Constructor for MonitorRegisterGroupRequest
     */
    public MonitorRegisterGroupRequest(PICLDebugTarget debugTarget,
    									PICLThread debuggeeThread,
    									PICLRegisterGroup registerGroup) {
        super(debugTarget);
		fThread = debuggeeThread;
        fRegisterGroup = registerGroup;
    }

    /**
     * @see PICLEngineRequest#execute()
     */
    public void execute() throws PICLException {

		DebuggeeThread threadToMonitor = fThread.getDebuggeeThread();

		beginRequest();

		boolean rc = true;

		try {
			rc = threadToMonitor.monitorRegisterGroup(fRegisterGroup.getRegisterGroup(), syncRequest());
            if (!rc)
 	      		throw new PICLException(PICLUtils.getResourceString(msgKey + "send_error"));
    	} catch(IOException ioe) {
			throw(new PICLException(PICLUtils.getResourceString(msgKey + "send_error")));
    	} finally {
	    	endRequest();
    	}

    }

	/**
	 * Gets the monitoredRegisterGroup
	 * @return Returns a MonitoredRegisterGroup
	 */
	public MonitoredRegisterGroup getMonitoredRegisterGroup() {
		return fMonitoredRegisterGroup;
	}
    /**
     * Sets the monitoredRegisterGroup
     * @param monitoredRegisterGroup The monitoredRegisterGroup to set
     */
    public void setMonitoredRegisterGroup(MonitoredRegisterGroup monitoredRegisterGroup) {
        fMonitoredRegisterGroup = monitoredRegisterGroup;
    }

}

