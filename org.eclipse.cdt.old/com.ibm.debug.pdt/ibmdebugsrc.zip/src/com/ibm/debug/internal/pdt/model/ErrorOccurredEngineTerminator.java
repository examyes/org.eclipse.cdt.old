package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


class ErrorOccurredEngineTerminator extends DebugEngineEventAdapter
{
   public void errorOccurred(ErrorOccurredEvent event)
   {
     DebugEngine engine;

     try
     {
       engine = (DebugEngine)event.getSource();
     }
     catch (ClassCastException excp)
     {
       return;
     }

     // This shouldn't be necessary but we'll remove this object as an
     // event listener so that we don't end up with infinite recursion:

     engine.removeEventListener(this);

     try
     {
       engine.terminate(DebugEngine.sendReceiveSynchronously);
     }
     catch (java.io.IOException excp)
     {
     }
   }
}
