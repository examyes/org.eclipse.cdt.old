package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * The super class for all thread events.
 */


public abstract class ThreadEvent extends ModelEvent
{
  ThreadEvent(Object source, DebuggeeThread thread, int requestCode)
  {
    super(source, requestCode);
    _thread = thread;
  }

  public DebuggeeThread getThread()
  {
    return _thread;
  }

  private DebuggeeThread _thread;
}
