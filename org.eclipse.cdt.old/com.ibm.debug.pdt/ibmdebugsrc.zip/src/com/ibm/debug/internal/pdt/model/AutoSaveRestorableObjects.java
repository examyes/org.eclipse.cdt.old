package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


class AutoSaveRestorableObjects extends AutoSave
{
  AutoSaveRestorableObjects(RestorableObjects restorableObjects)
  {
    super(restorableObjects.getSerialization(),
          restorableObjects.getProcess(),
          restorableObjects.getProcess().debugEngine());

    _restorableObjects = restorableObjects;
  }

  // TODO: This event is fired EVERY time the Model updates are complete which
  // is a bit too often for our purposes. An optimization would be to create
  // a new event called 'restorableObjectsChanged' and listen for that
  // event instead. It would only be fired when restorable objects really
  // have been changed.


  public void modelStateChanged(ModelStateChangedEvent event)
  {
    DebuggeeProcess process = _restorableObjects.getProcess();
    DebugEngine engine = process.debugEngine();
    int saveFlags = _restorableObjects.getSaveFlags();

    // Compare what we are saving with what has changed and only save if what
    // we are saving has changed:

    if (SaveRestoreFlags.breakpointsFlagIsSet(saveFlags) &&
        process.breakpointsHaveChanged() ||
        SaveRestoreFlags.programMonitorsFlagIsSet(saveFlags) &&
        process.monitoredExpressionsHaveChanged() ||
        SaveRestoreFlags.storageFlagIsSet(saveFlags) &&
        process.storageMonitorsHaveChanged() ||
        SaveRestoreFlags.defaultDataRepresentationsFlagIsSet(saveFlags) &&
        engine.defaultDataRepresentationsHaveChanged() ||
        SaveRestoreFlags.exceptionFiltersFlagIsSet(saveFlags) &&
        engine.exceptionFiltersHaveChanged())
       super.modelStateChanged(event); // super.model - get it?
  }

  private RestorableObjects _restorableObjects;
}
