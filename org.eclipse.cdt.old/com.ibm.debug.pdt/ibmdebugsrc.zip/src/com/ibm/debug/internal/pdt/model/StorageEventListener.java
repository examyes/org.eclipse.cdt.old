package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/** The methods in this interface correspond to events that can occur
 *  within a debuggee at the storage level. Client code should implement
 *  this interface if it wants to be informed when these events occur.
 *  An object of this type can be registered as an interested listener
 *  by calling the <b>Storage.addEventListener(StorageEventListener)</b>
 *  method. Whenever an event occurs which corresponds to one of the methods
 *  in the interface, the Storage object will call the appropriate
 *  method for every registered event listener.
 *  @see Storage
 */

public interface StorageEventListener extends ModelEventListener
{
   /**
    * This method will be called when a Storage object has been deleted and is just about
    * to be removed from its owning process object.
    * @param event The event
    */

   public void storageDeleted(StorageDeletedEvent event);

   public void storageChanged(StorageChangedEvent event);
}
