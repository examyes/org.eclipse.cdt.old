package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * The super class for all module events.
 */

public abstract class ModuleEvent extends ModelEvent
{
  ModuleEvent(Object source, Module module, int requestCode)
  {
    super(source, requestCode);
    _module = module;
  }

  public Module getModule()
  {
    return _module;
  }

  private Module _module;
}
