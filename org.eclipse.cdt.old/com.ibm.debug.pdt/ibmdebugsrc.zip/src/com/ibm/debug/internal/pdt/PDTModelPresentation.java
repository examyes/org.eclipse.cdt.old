package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.IValue;
import org.eclipse.debug.ui.DebugUITools;
import org.eclipse.debug.ui.IDebugModelPresentation;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.debug.ui.IValueDetailListener;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorRegistry;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.FileEditorInput;

import com.ibm.debug.internal.pdt.model.AddressBreakpoint;
import com.ibm.debug.internal.pdt.model.Breakpoint;
import com.ibm.debug.internal.pdt.model.DebuggeeException;
import com.ibm.debug.internal.pdt.model.EntryBreakpoint;
import com.ibm.debug.internal.pdt.model.LineBreakpoint;
import com.ibm.debug.internal.pdt.model.Location;
import com.ibm.debug.internal.pdt.model.LocationBreakpoint;
import com.ibm.debug.internal.pdt.model.ViewInformation;
import com.ibm.debug.pdt.breakpoints.PICLAddressBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLEntryBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLLineBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLLoadBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLWatchBreakpoint;


/**
 * @see IDebugModelPresentation
 */
public class PDTModelPresentation
	extends LabelProvider
	implements IDebugModelPresentation {
	protected boolean fShowQualified = false;
	protected boolean fShowTypes = false;

	private static final String PREFIX = "picl_label_provider.";
	private static final String TERMINATED = "terminated";
	private static final String DISCONNECTED = "disconnected";
	private static final String LINE = "line";
	private static final String ENTRY = "entry";
	private static final String LOAD = "load";
	private static final String WATCH = "watch";
	private static final String ADDRESS = "address";
	private static final String ERRORVALUE = "errorvalue";
	private static final String STR_UNKNOWN = "unknown";

	/**
	 * Returns a label for the item
	 */
	public String getText(Object item) {
		
		if (item instanceof PICLVariable) {
			PICLVariable var = (PICLVariable) item;
			PICLValue val = (PICLValue) var.getValue();
			String value = "";
			if (!var.hasChildren()) {
				try {
					value = " = " + val.getValueString();
				} catch (Exception e) {
					value = " = " + PICLUtils.getResourceString(PREFIX + ERRORVALUE);
				}
			}

			return var.getLabel(fShowQualified, fShowTypes) + value;

		}
		if (item instanceof PICLStorageMap) {
			PICLStorageMap map = (PICLStorageMap) item;
			String value = "";
			try {
				value = map.getLabel(fShowTypes);
			} catch (Exception e) {
				value = map.getName() + " = " + PICLUtils.getResourceString(PREFIX + ERRORVALUE);
			}
			return value;
		
		}

		if (item instanceof PICLDebugElement) {
			String label = ((PICLDebugElement) item).getLabel(fShowQualified);
			return label;
		}

		if (item instanceof IBreakpoint) {
			IBreakpoint breakpoint = (IBreakpoint) item;

			// Check if it is one of ours			
			if (!(breakpoint instanceof PICLBreakpoint))
				return null;

			try {
				StringBuffer label = new StringBuffer();

				String fileName = null;

				if (breakpoint instanceof PICLLineBreakpoint) {
					label.append(PICLUtils.getResourceString(PREFIX + LINE));
					label.append(" [");
					fileName = ((PICLLineBreakpoint)breakpoint).getFileName();
					if (fileName != null)
						label.append(fileName + ':');
					label.append(((PICLLineBreakpoint)breakpoint).getLineNumber());
					label.append(']');
				} else if (breakpoint instanceof PICLEntryBreakpoint) {
					label.append(PICLUtils.getResourceString(PREFIX + ENTRY));
					label.append(" [");
					label.append(((PICLEntryBreakpoint)breakpoint).getFunctionName());
					label.append(']');
				} else if (breakpoint instanceof PICLAddressBreakpoint) {
					label.append(PICLUtils.getResourceString(PREFIX + ADDRESS));
					label.append(" [");
					label.append(((PICLAddressBreakpoint)breakpoint).getAddress());
					label.append(']');
				} else if (breakpoint instanceof PICLLoadBreakpoint) {
					label.append(PICLUtils.getResourceString(PREFIX + LOAD));
					label.append(" [");
					label.append(((PICLLoadBreakpoint)breakpoint).getModuleName());
					label.append(']');
				} else if (breakpoint instanceof PICLWatchBreakpoint) {
					label.append(PICLUtils.getResourceString(PREFIX + WATCH));
					label.append(" [");
					label.append(((PICLWatchBreakpoint)breakpoint).getAddress());
					label.append(']');
				}

				return label.toString();
			} catch (CoreException e) {
				PICLUtils.logError(e);
			}

		}

		if (item instanceof DebuggeeException) {
			return ((DebuggeeException) item).name();
		}

		if (item instanceof String) {
			return (String) item;
		}
		return PICLUtils.getResourceString(PREFIX + STR_UNKNOWN);
	}

	/**
	 * Maps a Java element to an appropriate image.
	 */
	public Image getImage(Object item) {
		if (item instanceof IBreakpoint) {
			IBreakpoint breakpoint = (IBreakpoint) item;
			if (!breakpoint.getMarker().getAttribute(IBreakpoint.ENABLED, true)) {
				return DebugUITools.getImage(IDebugUIConstants.IMG_OBJS_BREAKPOINT_DISABLED);
			}
			return DebugUITools.getImage(IDebugUIConstants.IMG_OBJS_BREAKPOINT);
		}
		if (item instanceof IMarker) {
			//needed for breakpoint markers to show up in debugger editor annotation model
			IMarker marker = (IMarker) item;
			if (!marker.getAttribute(IBreakpoint.ENABLED, true)) {
				return DebugUITools.getImage(IDebugUIConstants.IMG_OBJS_BREAKPOINT_DISABLED);
			} 
			return DebugUITools.getImage(IDebugUIConstants.IMG_OBJS_BREAKPOINT);
		}

		if (item instanceof PICLVariable) {
			if (!((PICLVariable) item).isEnabled()) {
				return PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_VARIABLE_DISABLED);
			} else if (((PICLVariable) item).hasChanged(false)) {
				return PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_VARIABLE_CHANGED);
			}
			return PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_VARIABLE);
		}

		if (item instanceof PICLRegister) {
			if (((PICLRegister) item).hasChanged(false)) {
				return PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_REGISTER_CHANGED);
			}
			return PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_REGISTER);
		}

		if (item instanceof PICLRegisterGroup) {
			return PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_REGISTER_GROUP);
		}

		if (item instanceof PICLModule) {
			return PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_MODULE);
		}

		if (item instanceof PICLPart) {
			return PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_PART);
		}

		if (item instanceof PICLFile) {
			if (((PICLFile) item).hasSource())
				return PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_FILE);
			else
				return PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_NO_FILE);
		}

		if (item instanceof PICLFunction) {
			return PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_FUNCTION);
		}

		return null;
	}

	/**
	 * @see IDebugModelPresentation
	 */
	public IEditorInput getEditorInput(Object item) {
		/*IJavaElement je= null; */
		if (item instanceof IMarker) {
			IMarker marker = (IMarker) item;
			IResource resource = marker.getResource();
			if (resource instanceof IFile)
				return new FileEditorInput((IFile) resource);
			if (resource instanceof IProject || resource instanceof IWorkspaceRoot) {
				// Marker on an IProject/IWorkspaceRoot probably means a marker in an EngineSuppliedView.                      
				// Need engine to supply the view content to us.                                                

				// Find the PICLDebugTarget to build the view                                                   
				// If the ViewFile is not available from the current debug target then give up                  
				IDebugTarget target = PICLDebugPlugin.determineCurrentDebugTarget();
				if (target instanceof PICLDebugTarget) {
					PICLDebugTarget PICLTarget = (PICLDebugTarget) target;
					Breakpoint bp = PICLTarget.getBreakpoint(marker);
					if (bp != null && bp instanceof LocationBreakpoint) {
						LocationBreakpoint locBp = (LocationBreakpoint) bp;
						ViewInformation viewInfo = null;
						if (locBp instanceof AddressBreakpoint)
							viewInfo = PICLTarget.getDebugEngine().getDisassemblyViewInformation();
						else if (locBp instanceof LineBreakpoint)
							viewInfo = PICLTarget.getDebugEngine().getSourceViewInformation();
						else if (locBp instanceof EntryBreakpoint)
							// Not sure what to pick here                                                       
							viewInfo = PICLTarget.getDebugEngine().getSourceViewInformation();
						if (viewInfo == null)
							return null;
						Location loc = null;
						try {
							loc = locBp.getLocationWithinView(viewInfo);
						} catch (IOException e) {
							return null;
						}

						if (loc != null) {
							EngineSuppliedViewEditorInput engineEI =
								new EngineSuppliedViewEditorInput(loc, PICLTarget);
							if (resource instanceof IWorkspaceRoot) {
								engineEI.setResource(resource);
							} else {
								engineEI.setResource(resource.getProject());
							}
							// Update the line number in the marker to match the generated view                 
							try {
								marker.setAttribute(IMarker.LINE_NUMBER, loc.lineNumber());
							} catch (CoreException e) {
							}
							return engineEI;
						}
					}
				}
				return null;
			}
		}
		if (item instanceof IBreakpoint) {
			IMarker marker = ((IBreakpoint) item).getMarker();
			IResource resource = marker.getResource();
			if (resource instanceof IFile)
				return new FileEditorInput((IFile) resource);
			if (resource instanceof IProject || resource instanceof IWorkspaceRoot) {
				// Marker on an IProject/IWorkspaceRoot probably means a marker in an EngineSuppliedView.                      
				// Need engine to supply the view content to us.                                                

				// Find the PICLDebugTarget to build the view                                                   
				// If the ViewFile is not available from the current debug target then give up                  
				IDebugTarget target = PICLDebugPlugin.determineCurrentDebugTarget();
				if (target instanceof PICLDebugTarget) {
					PICLDebugTarget PICLTarget = (PICLDebugTarget) target;
					Breakpoint bp = PICLTarget.getBreakpoint(marker);
					if (bp != null && bp instanceof LocationBreakpoint) {
						LocationBreakpoint locBp = (LocationBreakpoint) bp;
						ViewInformation viewInfo = null;
						if (locBp instanceof AddressBreakpoint)
							viewInfo = PICLTarget.getDebugEngine().getDisassemblyViewInformation();
						else if (locBp instanceof LineBreakpoint)
							viewInfo = PICLTarget.getDebugEngine().getSourceViewInformation();
						else if (locBp instanceof EntryBreakpoint)
							// Not sure what to pick here                                                       
							viewInfo = PICLTarget.getDebugEngine().getSourceViewInformation();
						if (viewInfo == null)
							return null;
						Location loc = null;
						try {
							loc = locBp.getLocationWithinView(viewInfo);
						} catch (IOException e) {
							return null;
						}

						if (loc != null) {
							EngineSuppliedViewEditorInput engineEI =
								new EngineSuppliedViewEditorInput(loc, PICLTarget);
							if (resource instanceof IWorkspaceRoot) {
								engineEI.setResource(resource);
							} else {
								engineEI.setResource(resource.getProject());
							}
							// Update the line number in the marker to match the generated view                 
							try {
								marker.setAttribute(IMarker.LINE_NUMBER, loc.lineNumber());
							} catch (CoreException e) {
							}
							return engineEI;
						}
					}
				}
				return null;
			}
		}
		if (item instanceof IFile)
			return new FileEditorInput((IFile) item);

		if (item instanceof EngineSuppliedViewEditorInput)
			return (EngineSuppliedViewEditorInput) item;

		return null;
	}
	/**
	* @see IDebugModelPresentaion
	*/
	public String getEditorId(IEditorInput input, Object inputObject) {
		String editorId = null;
		IEditorDescriptor desc = null;
		IEditorRegistry reg = PlatformUI.getWorkbench().getEditorRegistry();

		if (input instanceof IFileEditorInput) {
			if (inputObject instanceof IFile) {
				IFile file = (IFile) inputObject;
				desc = reg.getDefaultEditor(file);
				if (desc != null)
					return desc.getId();
			} else if (inputObject instanceof IMarker) {
				IResource resource = ((IMarker) inputObject).getResource();
				if (resource instanceof IFile) {
					IFile file = (IFile) resource;
					desc = reg.getDefaultEditor(file);
					if (desc != null)
						return desc.getId();
				}
			} else if (inputObject instanceof IBreakpoint) {
				IResource resource = ((IBreakpoint) inputObject).getMarker().getResource();
				if (resource instanceof IFile) {
					IFile file = (IFile) resource;
					desc = reg.getDefaultEditor(file);
					if (desc != null)
						return desc.getId();
				}
			}
		} else if (input instanceof EngineSuppliedViewEditorInput) {
			editorId = IPICLDebugConstants.DEBUGGER_EDITOR;;
			desc = (IEditorDescriptor) reg.findEditor(editorId);
		}
		if (desc == null) {
			/* Don't know which editor to use so fall back to default text editor */
			editorId = "org.eclipse.ui.DefaultTextEditor";
		}

		return editorId;
	}
	/**
	 * @see IDebugModelPresentation
	 */
	public void setAttribute(String id, Object value) {
		if (value == null) {
			return;
		}
		if (id.equals(IDebugModelPresentation.DISPLAY_VARIABLE_TYPE_NAMES))
			fShowTypes = ((Boolean) value).booleanValue();

		return;
	}

	/*
	 * @see IDebugModelPresentation#computeDetail(IValue, IValueDetailListener)
	 */
	public void computeDetail(IValue value, IValueDetailListener listener) {
	}

}
