package com.ibm.debug.internal.pdt.ui.dialogs;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.debug.core.model.ISourceLocator;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.help.WorkbenchHelp;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLException;
import com.ibm.debug.internal.pdt.PICLStorageMap;
import com.ibm.debug.internal.pdt.PICLThread;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.Location;
import com.ibm.debug.internal.pdt.model.ViewInformation;
import com.ibm.debug.internal.pdt.ui.views.StorageView;
import com.ibm.debug.pdt.WorkspaceSourceLocator;


/**
 * Dialog to map storage addresses to tree structures as defined by user XML
 */
public class MapStorageDialog extends StatusDialog implements ISettingsWriter {
	protected final static String PREFIX= "MapStorageDialog.";
    private static final String PAGE_NAME= "MapStorageDialog";
    private static final String PARAMETERS1 = "Parameters1";
    private static final String PARAMETERS2 = "Parameters2";

	private PICLThread fThread;
	private IResource fInputResource;
	private IMarker fMonitorMarker;
	private ViewInformation fViewInfo;

	private Text expressionInput;
	private Text mappingFileInput;
	private Button mappingFileBrowseButton;
	private Label fileNameLabel;
	private Label lineNumberLabel;
	private Label viewInfoLabel;
	private Label threadNameLabel;

	private Document fDOMLayout;
	/**
	 * Constructor for MapStorageDialog
	 */
	public MapStorageDialog(Shell parentShell, PICLThread thread) {
		super(parentShell);
		setTitle(PICLUtils.getResourceString(PREFIX+"label.title"));
		this.fThread = thread;

		WorkbenchHelp.setHelp(parentShell, PICLUtils.getHelpResourceString("MapStorageDialog"));
	}

	protected Control createDialogArea(Composite ancestor) {
		Composite parent = new Composite(ancestor, SWT.NULL);

		GridLayout parentLayout = new GridLayout();
		parentLayout.numColumns = 8;
		parent.setLayout(parentLayout);

		Label expressionLabel = new Label(parent, SWT.NULL);
		expressionLabel.setText(PICLUtils.getResourceString(PREFIX+"label.address"));
		Label filler11 = new Label(parent, SWT.NONE);
		Label filler12 = new Label(parent, SWT.NONE);
		Label filler13 = new Label(parent, SWT.NONE);
		
		expressionInput = new Text(parent, SWT.BORDER);
		GridData specExpressionInput= new GridData();
		specExpressionInput.grabExcessVerticalSpace= false;
		specExpressionInput.grabExcessHorizontalSpace= true;
		specExpressionInput.horizontalAlignment= GridData.FILL;
		specExpressionInput.verticalAlignment= GridData.BEGINNING;
		specExpressionInput.horizontalSpan = 8;
		expressionInput.setLayoutData(specExpressionInput);

		Label mappingFileLabel =new Label(parent, SWT.NULL);
		mappingFileLabel.setText(PICLUtils.getResourceString(PREFIX+"label.mappingfile"));
		Label filler21 = new Label(parent, SWT.NONE);
		Label filler22 = new Label(parent, SWT.NONE);
		Label filler23 = new Label(parent, SWT.NONE);

		mappingFileInput = new Text(parent, SWT.BORDER);
		GridData specMappingFileInput= new GridData();
		specMappingFileInput.grabExcessVerticalSpace= false;
		specMappingFileInput.grabExcessHorizontalSpace= true;
		specMappingFileInput.horizontalAlignment= GridData.FILL;
		specMappingFileInput.verticalAlignment= GridData.BEGINNING;
		specMappingFileInput.horizontalSpan = 7;
		mappingFileInput.setLayoutData(specMappingFileInput);
		mappingFileBrowseButton = new Button(parent, SWT.PUSH);
		mappingFileBrowseButton.setText(PICLUtils.getResourceString(PREFIX+"label.browse"));
		mappingFileBrowseButton.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				String fileName = chooseMappingFile();
				if (fileName != null)
					mappingFileInput.setText(fileName);
			}
			public void widgetSelected(SelectionEvent e) {
				String fileName = chooseMappingFile();
				if (fileName != null)
					mappingFileInput.setText(fileName);
			}
		});
		
		Group evaluationGroup = new Group(parent, SWT.SHADOW_NONE);
		evaluationGroup.setLayout(new GridLayout());
		fileNameLabel = new Label(evaluationGroup, SWT.NULL);
		lineNumberLabel = new Label(evaluationGroup, SWT.NULL);
		viewInfoLabel = new Label(evaluationGroup, SWT.NULL);
		threadNameLabel = new Label(evaluationGroup, SWT.NULL);

		GridData specEvaluationGroup= new GridData();
		specEvaluationGroup.grabExcessVerticalSpace= false;
		specEvaluationGroup.grabExcessHorizontalSpace= true;
		specEvaluationGroup.horizontalAlignment= GridData.FILL;
		specEvaluationGroup.verticalAlignment= GridData.BEGINNING;
		specEvaluationGroup.horizontalSpan = 8;
		evaluationGroup.setLayoutData(specEvaluationGroup);
		evaluationGroup.setText(PICLUtils.getResourceString(PREFIX+"label.context"));

		initStatusInfo();

		expressionInput.setFocus();
		restoreSettings();
		return parent;
	}


	protected IDialogSettings getDialogSettings() {
		IDialogSettings workbenchSettings = PICLDebugPlugin.getDefault().getDialogSettings();
		IDialogSettings section = workbenchSettings.getSection(PAGE_NAME);//$NON-NLS-1$
		if(section == null)
			section = workbenchSettings.addNewSection(PAGE_NAME);//$NON-NLS-1$
		return section;
	}

	/**
	 * @see ISettingsWriter#restoreSettings
	 */
    public void restoreSettings() {
		IDialogSettings dialogSettings = getDialogSettings();
		IDialogSettings section = null;
		if(dialogSettings != null)
			section = dialogSettings.getSection(PAGE_NAME);

		if(section == null) {
			expressionInput.setText("");
			mappingFileInput.setText("");
		} else {
			String parameters1 = section.get(PARAMETERS1);
			String parameters2 = section.get(PARAMETERS2);
			if(parameters1 == null) {
				expressionInput.setText("");
			} else {
				expressionInput.setText(parameters1);
			}
			if(parameters2 == null) {
				mappingFileInput.setText("");
			} else {
				mappingFileInput.setText(parameters2);
			}

		}
	}

	/**
	 * @see ISettingsWriter#writeSettings
	 */
	public void writeSettings() {
		IDialogSettings dialogSettings = getDialogSettings();
		IDialogSettings section = null;
		if(dialogSettings == null)
			return;
		section = dialogSettings.getSection(PAGE_NAME);
		if(section == null)
			section = dialogSettings.addNewSection(PAGE_NAME);
		section.put(PARAMETERS1, expressionInput.getText());
		section.put(PARAMETERS2, mappingFileInput.getText());
	}


	private String chooseMappingFile() {
		FileDialog dialog = new FileDialog(getShell(), SWT.MULTI);
		if (!mappingFileInput.getText().trim().equals("")) {
			dialog.setFilterPath(mappingFileInput.getText());
		} else if (fThread != null) {
			ISourceLocator locator = fThread.getSourceLocator();
			if (locator instanceof WorkspaceSourceLocator) {
				IResource resource = ((WorkspaceSourceLocator)locator).getHomeProject();
				if ((resource != null) && (resource.getLocation() != null)) 
					dialog.setFilterPath(resource.getLocation().toOSString());
			}
		}
		dialog.setFilterExtensions(new String[] {"*.xml"});
		return dialog.open();
	}


	private void initStatusInfo() {
		try {
			fViewInfo = fThread.getViewInformation();
			Location location = fThread.getLocation(fViewInfo);

			fileNameLabel.setText(PICLUtils.getResourceString(PREFIX+"label.filename") + " " + location.file().name());
			lineNumberLabel.setText(PICLUtils.getResourceString(PREFIX+"label.linenumber") +  " " + Integer.toString(location.lineNumber()));
			viewInfoLabel.setText(PICLUtils.getResourceString(PREFIX+"label.viewtype") + " " + fViewInfo.name());
			threadNameLabel.setText(PICLUtils.getResourceString(PREFIX+"label.threadname") + " " + fThread.getName());
		} catch (Exception e) {
		}
	}
	


	protected void okPressed() {

		String fBaseExpression = expressionInput.getText().trim();
		try {
			long longAddress = Long.parseLong(fBaseExpression, 16);
		} catch(NumberFormatException e) {
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.invalid_address_format"));
			return;
		}


		if (fThread == null || !(fThread instanceof PICLThread) || fThread.isTerminated()) {
			PICLUtils.logText(PREFIX + ": invalid thread");
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.invalid_thread"));
			return;
		}

		int lineNum = fThread.getLocation(fViewInfo).lineNumber();

		//get the resource (project) and viewinformation associated with the thread
		ISourceLocator sourceLocator = fThread.getLaunch().getSourceLocator();
		if (sourceLocator instanceof WorkspaceSourceLocator) {
			WorkspaceSourceLocator wslocator = (WorkspaceSourceLocator) sourceLocator;
			fInputResource  = wslocator.getHomeProject();
		}
		if (fInputResource == null) {
			PICLUtils.logText(PREFIX + ": invalid resource");
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.invalid_resource"));
			return;
		}

		// create a marker on the resource and set the line number and file name where the expression is to be evaluated
		try {
			fMonitorMarker = fInputResource.createMarker(IPICLDebugConstants.PICL_MONITORED_EXPRESSION);
			fMonitorMarker.setAttribute(IMarker.LINE_NUMBER, lineNum);
			fMonitorMarker.setAttribute(IPICLDebugConstants.SOURCE_FILE_NAME, fThread.getLocation(fViewInfo).file().name());
		} catch (Exception e) {
			PICLUtils.logError(e);
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.marker"));
			return;
		}


		//open/check/read the Layout XML file
		Element rootNode =null;
		try {
			rootNode = PICLStorageMap.openLayout(mappingFileInput.getText().trim());
		} catch(PICLException e) {
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), e.getMessage());
			return;
		}

		//create the root Layout PICLStorageMap object
		try {
			PICLDebugElement parentPICLObject = ((PICLDebugTarget)fThread.getDebugTarget()).getStorageMapParent();
			PICLStorageMap rootStorageMap = PICLStorageMap.mapStorage(fThread, 
																								fMonitorMarker, 
																								fViewInfo, 
																								parentPICLObject, 
																								fBaseExpression, 
																								0, 
																								PICLStorageMap.TYPE_MAP);
			if (rootStorageMap == null) {
				MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getFormattedString(PREFIX+"error.could_not_be_evaluated", new String[] {"\"" + PICLUtils.getNonMnemonicString(fBaseExpression) +"\"", "\"" + ((PICLThread)fThread).getLabel(true) + "\""}));
				return;
			}
			rootStorageMap.configureParentMap(rootNode.getAttribute(PICLStorageMap.HEADER),
														fBaseExpression,
														PICLStorageMap.TYPE_MAP,
														mappingFileInput.getText().trim(),
														(Node)rootNode);
			//We do not need to build child nodes at this time.  See PICLStorageMap.getChildren() for delayed child creation
			//add the root Layout PICLStorageMap to the PICLStorageMapParent so the view can display it
			((PICLDebugTarget)fThread.getDebugTarget()).getStorageMapParent().addChild(rootStorageMap, false);
			
		} catch(PICLException e) {
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getFormattedString(PREFIX+"error.could_not_be_evaluated", new String[] {"\"" + PICLUtils.getNonMnemonicString(fBaseExpression) +"\"", "\"" + ((PICLThread)fThread).getLabel(true) + "\""}));
			return;
		}


		//open a new view if necessary
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) {
			PICLUtils.logText(PREFIX + ": error getting ActivePage()");
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.no_activepage"));
			return;
		}
		IViewPart view = null;
		view= p.findView(IPICLDebugConstants.MAPPING_VIEW);
		if (view == null) {
			try {
				IWorkbenchPart activePart= p.getActivePart();
				view= (StorageView) p.showView(IPICLDebugConstants.MAPPING_VIEW);
				p.activate(activePart);
			} catch (PartInitException e) {
				PICLUtils.logError(e);
				MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"error.title"), PICLUtils.getResourceString(PREFIX+"error.could_not_open_view"));
				return;
			}
		}

		if (view instanceof IDebugView) {
			p.bringToTop(view);
			((IDebugView)view).getViewer().refresh();
		}


		fMonitorMarker = null;
		fInputResource = null;
		fViewInfo = null;
		writeSettings();
		
		super.okPressed();
	}


	private SelectionListener fListListener= new SelectionAdapter() {
		public void widgetSelected(SelectionEvent event) {
		}

		public void widgetDefaultSelected(SelectionEvent event) {
				okPressed();
		}
	};
}
