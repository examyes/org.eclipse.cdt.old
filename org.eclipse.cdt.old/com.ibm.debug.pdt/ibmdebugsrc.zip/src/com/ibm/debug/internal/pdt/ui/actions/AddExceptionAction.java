package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;

import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.ui.dialogs.AddExceptionDialog;


public class AddExceptionAction implements IViewActionDelegate, ISelectionListener {

	IAction myAction;
	//static int instantiationCounter=0;

	public AddExceptionAction()
	{
	//	instantiationCounter+=1;
		//System.out.println("%%%%%%%%%%%%%%%%%%%%%Exception action created. "+instantiationCounter);
	}

	/**
	 * @see IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart view) {
		//want to be notified when picl stack frame selected so action can be enabled.
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().addSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);

		//find debug view and ask for current selection
		//add selection listener to plugin for getting current
	}

	public void run(IAction action) {

		Shell shell= PICLDebugPlugin.getActiveWorkbenchShell();
		AddExceptionDialog dialog= new AddExceptionDialog(shell);
		if (dialog.checkEngineSupport())
			dialog.open();
		else
			dialog = null;
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 * Processes selection changed events from breakpoint view only.
	 */
	public void selectionChanged(IAction action, ISelection sel) {
		if(myAction == null)
			myAction=action;

		//send selection changed event in case action wasn't created when stack selection event sent
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) 	return;
		IViewPart view= p.findView(IDebugUIConstants.ID_DEBUG_VIEW);
		if ((view==null) || !(view instanceof IDebugView)) return;

		((IDebugView)view).getViewer().setSelection(((IDebugView)view).getViewer().getSelection());
	}


	
	/**
	 * @see ISelectionListener#selectionChanged(IWorkbenchPart, ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {

		Object element = null;
		if (selection instanceof IStructuredSelection)
		{
			IStructuredSelection strSelection = (IStructuredSelection) selection;
			element = strSelection.getFirstElement();
		} else
		  element = selection;

		//check if stack frame, process, or thread for live debug target
		if (element instanceof PICLDebugElement && !((IDebugElement)element).getDebugTarget().isTerminated()
			&& ((PICLDebugTarget)((IDebugElement)element).getDebugTarget()).supportsExceptionFiltering())
			myAction.setEnabled(true);
		else if (element instanceof ILaunch) //launcher
		{
		 	IDebugTarget dt =((ILaunch) element).getDebugTarget();
			if (dt instanceof PICLDebugTarget && !((PICLDebugTarget)dt).isTerminated()
				&& ((PICLDebugTarget)dt).supportsExceptionFiltering())
				myAction.setEnabled(true);
			else myAction.setEnabled(false);
		}
		else myAction.setEnabled(false);
	}

}
