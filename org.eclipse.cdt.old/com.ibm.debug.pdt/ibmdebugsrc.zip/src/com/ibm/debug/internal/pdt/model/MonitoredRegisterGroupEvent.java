package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * The super class for all monitored register group events.
 */

public abstract class MonitoredRegisterGroupEvent extends ModelEvent
{
  MonitoredRegisterGroupEvent(Object source, MonitoredRegisterGroup monRegGroup, int requestCode)
  {
    super(source, requestCode);
    _monRegGroup = monRegGroup;
  }

  public MonitoredRegisterGroup getMonitoredRegisterGroup()
  {
    return _monRegGroup;
  }

  private MonitoredRegisterGroup _monRegGroup;
}
