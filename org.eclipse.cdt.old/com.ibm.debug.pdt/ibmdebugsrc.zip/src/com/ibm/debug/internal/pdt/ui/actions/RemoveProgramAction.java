package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLPart;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.DebugEngine;
import com.ibm.debug.internal.pdt.model.DebugEngineAddedEvent;
import com.ibm.debug.internal.pdt.model.Part;

public class RemoveProgramAction extends Action {

	private static final String PREFIX= "RemoveProgramAction.";
	private TreeViewer fTreeViewer;

	/**
	 * Constructor for RemoveProgramAction.
	 */
	public RemoveProgramAction(TreeViewer treeViewer) {
		super(PICLUtils.getResourceString(PREFIX + "label"));
		fTreeViewer = treeViewer;
		setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_EXPAND_ALL));
		
		WorkbenchHelp.setHelp(this,PICLUtils.getHelpResourceString("RemoveProgramAction"));
	}

	
	
	/**
	 * @see IAction#run()
	 */
	public void run() {
		StructuredSelection sel = (StructuredSelection)fTreeViewer.getSelection();
		if (sel != StructuredSelection.EMPTY && sel.size() == 1) {   // for now support a single selection
			if (sel.getFirstElement() instanceof PICLPart) {
				PICLPart part = (PICLPart)sel.getFirstElement();
				try {
					((PICLDebugTarget)part.getDebugTarget()).getDebugEngine().removeProgram(part.getPart().name(),DebugEngine.sendReceiveSynchronously);
				} catch(IOException e) {
				}
				
			}
		}
		
		
	}


}
