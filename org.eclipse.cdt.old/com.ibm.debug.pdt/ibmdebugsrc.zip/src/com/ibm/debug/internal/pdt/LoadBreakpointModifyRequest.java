package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.IOException;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IMarkerDelta;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.debug.core.DebugException;
import com.ibm.debug.internal.pdt.model.AddressBreakpoint;
import com.ibm.debug.internal.pdt.model.Breakpoint;
import com.ibm.debug.internal.pdt.model.LineBreakpoint;
import com.ibm.debug.internal.pdt.model.Location;
import com.ibm.debug.internal.pdt.model.ModuleLoadBreakpoint;

public class LoadBreakpointModifyRequest extends BreakpointModifyRequest {

	private IMarker fMarker = null;
	private IMarkerDelta fDelta = null;

	/**
	 * Constructor for LoadBreakpointModifyRequest
	 */

	public LoadBreakpointModifyRequest(PICLDebugTarget debugTarget,
										IMarker marker,
										IMarkerDelta delta,
										Breakpoint breakpoint) {

		super(debugTarget, breakpoint);
		fDelta = delta;
		fMarker = marker;
	}


	/**
	 * @see PICLEngineRequest#execute()
	 */
	public void execute() throws PICLException {

		beginRequest();

    	boolean rc = true;

    	// first get all of the attributes from the breakpoint


    	try {
    		String[] attributes = {	IPICLDebugConstants.MODULE_NAME,
    								IPICLDebugConstants.EVERY_VALUE,
   									IPICLDebugConstants.FROM_VALUE,
   									IPICLDebugConstants.TO_VALUE,
   									IPICLDebugConstants.THREAD };

    		Object[] values = fMarker.getAttributes(attributes);

    		// check the thread value, if "Every" then make it 0
    		if (((String)values[4]).equalsIgnoreCase("every"))
    			values[4] = "0";

    		int threadID = Integer.parseInt((String)values[4]);


    		rc = ((ModuleLoadBreakpoint)fBreakpoint).modify((String)values[0],
															((Integer)values[1]).intValue(),
															((Integer)values[2]).intValue(),
															((Integer)values[3]).intValue(),
    												  		threadID,
    												  		syncRequest(),
															fMarker);

            if (!rc)
 	      		throw new PICLException(PICLUtils.getResourceString(msgKey + "load_error"));

    	} catch(IOException ioe) {
			throw(new PICLException(PICLUtils.getResourceString(msgKey + "send_error")));
    	} catch(CoreException ce) {
			throw(new PICLException(PICLUtils.getResourceString(msgKey + "modify_error")));
    	} finally {
    		endRequest();
    	}


	}

}

