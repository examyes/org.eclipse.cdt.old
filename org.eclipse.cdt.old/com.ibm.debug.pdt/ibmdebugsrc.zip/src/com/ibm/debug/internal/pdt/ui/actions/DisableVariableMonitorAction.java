package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.util.Iterator;

import org.eclipse.debug.core.DebugException;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.actions.SelectionProviderAction;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLMonitorParent;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.PICLVariable;
import com.ibm.debug.internal.pdt.ui.views.MonitorView;

public class DisableVariableMonitorAction extends SelectionProviderAction {
	protected static final String PREFIX= "DisableVariableMonitorAction.";

	/**
	 * Constructor for DisableVariableMonitorAction
	 */
	public DisableVariableMonitorAction(ISelectionProvider provider) {
		super(provider, PICLUtils.getResourceString(PREFIX+"label.disable"));
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip.disable"));
		setEnabled(!getStructuredSelection().isEmpty());

		WorkbenchHelp.setHelp(this, PICLUtils.getHelpResourceString("DisableVariableMonitorAction"));
	}

	protected void doAction(MonitorView view) throws DebugException {
		IStructuredSelection s = getStructuredSelection();
		Iterator vars = s.iterator();
		while (vars.hasNext()) {
			Object var = vars.next();
			if (var instanceof PICLVariable && isChecked()) {
				((PICLVariable)var).disable();
			} else {
				((PICLVariable)var).enable();
			}
			view.getViewer().refresh();
		}
	}

	/**
	 * @see Action#run()
	 */
	public void run() {
		// get the view
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) {
			return;
		}
		IViewPart view= p.findView(IPICLDebugConstants.MONITOR_VIEW);
		if (view == null) {
			// open a new view
			try {
				view= p.showView(IPICLDebugConstants.MONITOR_VIEW);
			} catch (PartInitException e) {
				PICLUtils.logError(e);
				return;
			}
		}

		try {
			if (!(view instanceof MonitorView)) { return; }
			doAction((MonitorView)view);
		} catch (DebugException de) {
			PICLUtils.logError(de);
		}
	}


	/**
	 * @see Action
	 */
	public void setChecked(boolean value) {
		super.setChecked(value);
//		setText(value ? PICLUtils.getResourceString(PREFIX+"label.enable") : PICLUtils.getResourceString(PREFIX+"label.disable"));
		setToolTipText(value ? PICLUtils.getResourceString(PREFIX+"tooltip.enable") : PICLUtils.getResourceString(PREFIX+"tooltip.disable"));
	}


	/**
	 * @see SelectionProviderAction
	 */
	public void selectionChanged(IStructuredSelection sel) {
		if (sel.isEmpty()) {
			setEnabled(false);
			setChecked(false);
			return;
		}

		boolean atLeastOneIsEnabled = false;
		Iterator vars= sel.iterator();
		while (vars.hasNext()) {
			Object item= vars.next();
			if (item instanceof PICLVariable) {
				// only root items can be disabled. if any item is a child, disable the action
				if (! (((PICLVariable)item).getParent() instanceof PICLMonitorParent)) {
					setChecked(false);
					setEnabled(false);
					return;
				} else if (((PICLVariable)item).isEnabled()) {
					atLeastOneIsEnabled = true;
				}
			}
		}

		// for multiple selections - if any monitor is enabled, set the action to "disable monitor" mode
		if (atLeastOneIsEnabled) {
			setChecked(false);
			setEnabled(true);
		} else {	// if we've gotten this far, then every selected item is a parent and is disabled
			setEnabled(true);
			setChecked(true);
		}
	}

}
