package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.ui.dialogs.PreferredSourceViewDialog;


public class SetPreferredViewAction implements IViewActionDelegate {
	private PICLDebugTarget debugTarget = null;
	/**
	 * Constructor for SetPreferredViewAction
	 */
	public SetPreferredViewAction() {
		super();
	}

	/**
	 * @see IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart debugView) {
		//This action is added through XML to the Debug View and is instantiated/initialized 
		//every time the view is opened.  We piggyback off this to add our DebugViewMenuListener
		//which dynamically adds our 'Switch to...' view actions to the drop-down menu on the toolbar
		if (debugView instanceof IDebugView) {
			DebugViewMenuListener dmListener = new DebugViewMenuListener((IDebugView)debugView);
			IMenuManager mm = debugView.getViewSite().getActionBars().getMenuManager();
			mm.addMenuListener(dmListener);
			
			// Look for the PreferredView group that was added in our plugin.xml for the DebugView
			IContributionItem preferred = mm.find("PreferredView");
			if (preferred != null)
				mm.insertBefore(preferred.getId(), new Separator("ViewSwitching"));
			else 
				mm.add(new Separator("ViewSwitching"));
		}
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction arg0) {
		Shell shell= PICLDebugPlugin.getActiveWorkbenchShell();
		PreferredSourceViewDialog dialog = new PreferredSourceViewDialog(shell, debugTarget);
		dialog.open();
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection sel) {
		Object element = null;
		boolean show = false;
		debugTarget = null;

		if (sel instanceof IStructuredSelection)
		{
			IStructuredSelection selection = (IStructuredSelection) sel;
			element = selection.getFirstElement();
		} else
		  element = sel;

		if (element instanceof PICLDebugElement)
		{
		 	// enable menu item
			show = true;
			debugTarget = (PICLDebugTarget) ((PICLDebugElement)element).getDebugTarget();
		}
		else if (element instanceof ILaunch)
		{
		 	IDebugTarget dt =((ILaunch) element).getDebugTarget();
			if (dt instanceof PICLDebugTarget) {
				show = true;
				debugTarget = (PICLDebugTarget) dt;
			}
		}

		if (show == true)
		{
		 	// enable menu item
			action.setEnabled(true);
		} else
		{
		 	// disable menu item
			action.setEnabled(false);
		}
	}


}

