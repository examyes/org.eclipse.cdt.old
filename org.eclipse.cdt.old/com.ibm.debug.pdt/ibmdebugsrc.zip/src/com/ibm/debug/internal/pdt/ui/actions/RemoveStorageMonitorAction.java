package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.jface.action.Action;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.ui.views.StorageView;
import com.ibm.debug.internal.pdt.ui.views.StorageViewTab;

public class RemoveStorageMonitorAction extends Action {
	protected static final String PREFIX= "RemoveStorageMonitorAction.";
	private StorageViewTab storageTab = null;

	/**
	 * Constructor for RemoveStorageMonitorAction
	 */
	//intended for use with the StorageView
	public RemoveStorageMonitorAction() {
		super(PICLUtils.getResourceString(PREFIX+"label"));
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip"));

		WorkbenchHelp.setHelp(this, PICLUtils.getHelpResourceString("RemoveStorageMonitorAction"));
	}

	/**
	 * Constructor for RemoveStorageMonitorAction
	 */
	//intended for use with the StorageViewTab
	public RemoveStorageMonitorAction(StorageViewTab sTab) {
		super(PICLUtils.getResourceString(PREFIX+"label"));
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip"));
		storageTab = sTab;

		WorkbenchHelp.setHelp(this, PICLUtils.getHelpResourceString("RemoveStorageMonitorAction"));
	}

	/**
	 * @see Action#run()
	 */
	public void run() {
		if (storageTab == null) {
			// get the StorageView
			IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
			if (p == null) { return; }
			IViewPart view= p.findView(IPICLDebugConstants.STORAGE_VIEW);
			if (view == null) {
				try {
					view= p.showView(IPICLDebugConstants.STORAGE_VIEW);
				} catch (PartInitException e) {
					PICLUtils.logError(e);
					return;
				}
			}
			p.bringToTop(view);
			if (!(view instanceof StorageView)) { return; }
			storageTab = ((StorageView)view).getTopStorageTab();
			if (storageTab != null) {
				storageTab.getStorage().delete();
			}
			storageTab = null;
		} else {
			storageTab.getStorage().delete();
		}
	}
}
