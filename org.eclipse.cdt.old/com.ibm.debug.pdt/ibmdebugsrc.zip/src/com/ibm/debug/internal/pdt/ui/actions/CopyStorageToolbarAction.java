package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugPlugin;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.ui.views.StorageView;
import com.ibm.debug.internal.pdt.ui.views.StorageViewTab;

public class CopyStorageToolbarAction extends Action {
	protected static final String PREFIX= "CopyViewToClipboardAction.";

	/**
	 * Constructor for CopyStorageToolbarAction
	 */
	public CopyStorageToolbarAction() {
		super(PICLUtils.getResourceString(PREFIX+"label"));
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip"));
	}


	/**
	 * @see Action#run()
	 */
	public void run() {
		// get the StorageView
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) { return; }
		IViewPart view= p.findView(IPICLDebugConstants.STORAGE_VIEW);
		if (view == null) {
			try {
				view= p.showView(IPICLDebugConstants.STORAGE_VIEW);
			} catch (PartInitException e) {
				PICLUtils.logError(e);
				return;
			}
		}
		p.bringToTop(view);
		if (!(view instanceof StorageView)) { return; }
		StorageViewTab storageTab = ((StorageView)view).getTopStorageTab();
		if (storageTab != null) {
			TableViewer tableViewer = (TableViewer)storageTab.getViewer();
			if (tableViewer != null) {
				CopyTableViewToClipboardAction fCopyTableViewToClipboardAction = new CopyTableViewToClipboardAction(tableViewer);
				fCopyTableViewToClipboardAction.run();
			}
		}
	}

}
