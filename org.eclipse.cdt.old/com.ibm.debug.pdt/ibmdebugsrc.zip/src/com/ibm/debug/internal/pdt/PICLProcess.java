package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

import com.ibm.debug.internal.pdt.model.DebuggeeProcess;

import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.IProcess;
import org.eclipse.debug.core.model.IStreamsProxy;


/**
 * Represents the process that is under debug control
 *
 */
public class PICLProcess implements IProcess {

	private static final String PREFIX = "picl_process.";

	private DebuggeeProcess fProcess = null;
	private PICLDebugTarget fDebugTarget = null;
	private PICLStreamsProxy fStreamsProxy = null;
	/**
	 * Constructor for PICLProcess.
	 */
	public PICLProcess(DebuggeeProcess process, PICLDebugTarget debugTarget) {
		super();
		fProcess = process;
		fDebugTarget = debugTarget;
		fStreamsProxy = new PICLStreamsProxy(this, fDebugTarget);
		fProcess.addEventListener(fStreamsProxy);
		
	}

	/**
	 * @see IProcess#getAttribute(String)
	 */
	public String getAttribute(String key) {
		return null;
	}

	/**
	 * @see IProcess#getLabel()
	 */
	public String getLabel() {
	
		String pgmName = fProcess.qualifiedName();

		String PID = String.valueOf(fProcess.processID());
		
		String[] substitutionText = { PID, pgmName };
		String label = PICLUtils.getFormattedString(PREFIX + "label", substitutionText);
		
		return label;
	}

	/**
	 * @see IProcess#getLaunch()
	 */
	public ILaunch getLaunch() {
		return fDebugTarget.getLaunch();
	}

	/**
	 * @see IProcess#getStreamsProxy()
	 */
	public IStreamsProxy getStreamsProxy() {
		return fStreamsProxy;
	}

	/**
	 * @see IProcess#setAttribute(String, String)
	 */
	public void setAttribute(String key, String value) {
	}

	/**
	 * @see IAdaptable#getAdapter(Class)
	 */
	public Object getAdapter(Class adapter) {
		return null;
	}

	/**
	 * @see ITerminate#canTerminate()
	 */
	public boolean canTerminate() {
		return fDebugTarget.canTerminate();
	}

	/**
	 * @see ITerminate#isTerminated()
	 */
	public boolean isTerminated() {
		return fDebugTarget.isTerminated();
	}

	/**
	 * @see ITerminate#terminate()
	 */
	public void terminate() throws DebugException {
		fProcess.removeEventListener(fStreamsProxy);
		fDebugTarget.terminate();
	}

	/**
	 * Gets the process.
	 * @return Returns a DebuggeeProcess
	 */
	public DebuggeeProcess getProcess() {
		return fProcess;
	}

	
}
