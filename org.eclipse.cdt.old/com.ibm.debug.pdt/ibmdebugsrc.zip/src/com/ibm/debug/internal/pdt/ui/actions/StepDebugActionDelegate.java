package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.pdt.IStepExtended;

public class StepDebugActionDelegate implements IViewActionDelegate {

	IDebugElement fCurrentElement = null;
	boolean fInitialized = false;

	/**
	 * @see IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart view) {
		PICLUtils.logText("StepDebugActionDelegate.init()");
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		PICLUtils.logText("StepDebugActionDelegate.run()");
		try {
			((IStepExtended)fCurrentElement).stepDebug();
		} catch(DebugException e) {
			PICLUtils.logError(e);
		}
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
		PICLUtils.logText("StepDebugActionDelegate.selectionChanged");
		
		if (!fInitialized)
			fInitialized = initialize(action);
		
		
		action.setEnabled(false);
		
		IStructuredSelection sel = (IStructuredSelection)selection;
		if (sel.size() == 1 && sel.getFirstElement() instanceof IDebugElement) {
			IDebugElement de = (IDebugElement)sel.getFirstElement();
			if (de instanceof IStepExtended && ((IStepExtended)de).canStepDebug()) {
				action.setEnabled(true);
				fCurrentElement = de;
			}
		} 
		
	}

	private boolean initialize(IAction action) {
		if (action == null)
			return false;
		else {
			return true;
		}
	}
		
}
