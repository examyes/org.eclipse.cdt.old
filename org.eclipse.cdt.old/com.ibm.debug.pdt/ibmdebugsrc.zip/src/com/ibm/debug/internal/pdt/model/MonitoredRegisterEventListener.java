package com.ibm.debug.internal.pdt.model;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/** The methods in this interface correspond to events that can occur
 *  after a register is monitored. Client code should implement
 *  this interface if it wants to be informed when these events occur.
 *  An object of this type can be registered as an interested listener
 *  by calling the <b>MonitoredRegister.addEventListener
 *  (MonitoredRegisterEventListener)</b> method.
 *  Whenever an event occurs which corresponds to one of the methods
 *  in the interface, the MonitoredRegister object will call the appropriate
 *  method for every registered event listener.
 *  @see MonitoredRegister
 */

public interface MonitoredRegisterEventListener extends ModelEventListener
{
   /**
    * This method will be called when a register is no longer required to
    * be monitored and is to be removed from its owning register group object.
    * @param event The event
    */

   public void monitoredRegisterEnded(MonitoredRegisterEndedEvent event);

   /**
    * This method will be called whenever a register's attributes have changed.
    * @param event The event
    */

   public void monitoredRegisterChanged (MonitoredRegisterChangedEvent event);
}
