package com.ibm.debug.pdt.launchconfig;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.ui.AbstractLaunchConfigurationTab;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;

import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.ui.util.MGridLayout;
import com.ibm.debug.internal.pdt.ui.util.SelectionButtonDialogField;
import com.ibm.debug.internal.pdt.ui.util.Separator;
import com.ibm.debug.internal.pdt.ui.util.StringDialogField;
import com.ibm.debug.pdt.launch.PICLLoadInfo;


public class PICLLoadAdvancedTab extends AbstractLaunchConfigurationTab implements IConfigurationConstants {
	
	private static final String PAGE_NAME = "PICLLoadLaunchConfigTab2";        
    
    private PICLLoadInfo fLoadInfo;

    private StringDialogField fSourceSearchField;
    private SelectionButtonDialogField fDebugInitializationButton;
 //   private SelectionButtonDialogFieldGroup fEnvironmentGroup;     
    
    /**
	 * @see ILaunchConfigurationTab#getName()
	 */
	public String getName() {
		return PICLUtils.getResourceString(PAGE_NAME + ".name");
	}
    
	/*
	 * @see ILaunchConfigurationTab#okToLeave()
	 * Always returns true as settings are optional/have defaults.
	 */
	public boolean okToLeave() {
		return true;
	}

	/*
	 * @see ILaunchConfigurationTab#createControl(Composite)
	 */
	public void createControl(Composite parent) {
		
		createFields();

        Composite fComposite = new Composite(parent, SWT.NONE);
        setControl(fComposite);
        int nColumns= 3;

        MGridLayout layout = new MGridLayout();
        layout.marginWidth = 0;
        layout.marginHeight = 20;
        layout.minimumWidth = 400;
        layout.minimumHeight = 200;
        layout.numColumns = nColumns;

        fComposite.setLayout(layout);
                    
        fSourceSearchField.doFillIntoGrid(fComposite, nColumns);                
        new Separator().doFillIntoGrid(fComposite, nColumns, 10);
        fDebugInitializationButton.doFillIntoGrid(fComposite, nColumns);                
       // new Separator().doFillIntoGrid(fComposite, nColumns, 10);
      //  fEnvironmentGroup.doFillIntoGrid(fComposite, 3);       
	}

	
	/*
	 * @see ILaunchConfigurationTab#setDefaults(ILaunchConfigurationWorkingCopy)
	 */
	public void setDefaults(ILaunchConfigurationWorkingCopy config) {
		config.setAttribute(SOURCE_PATH,"");
		config.setAttribute(DEBUG_INITIALIZATION, false);	
		config.setAttribute(ENVIRONMENT, PICLLoadInfo.ENV_COMMAND_WINDOW);	
		
	}

	/*
	 * @see ILaunchConfigurationTab#initializeFrom(ILaunchConfiguration)
	 */
	public void initializeFrom(ILaunchConfiguration config) {
		try{
			fSourceSearchField.setText(config.getAttribute(SOURCE_PATH, ""));
			fDebugInitializationButton.setSelection(config.getAttribute(DEBUG_INITIALIZATION, false));
//			fEnvironmentGroup.setSelection(PICLLoadInfo.ENV_COMMAND_WINDOW,
//				config.getAttribute(ENVIRONMENT, PICLLoadInfo.ENV_COMMAND_WINDOW)==PICLLoadInfo.ENV_COMMAND_WINDOW);
//			fEnvironmentGroup.setSelection(PICLLoadInfo.ENV_DEBUGGER_STARTUP, 
//				config.getAttribute(ENVIRONMENT, PICLLoadInfo.ENV_COMMAND_WINDOW)==PICLLoadInfo.ENV_DEBUGGER_STARTUP);
//			fEnvironmentGroup.setSelection(PICLLoadInfo.ENV_PREVIOUS_SESSION, 
//				config.getAttribute(ENVIRONMENT, PICLLoadInfo.ENV_COMMAND_WINDOW)==PICLLoadInfo.ENV_PREVIOUS_SESSION);
		}catch(CoreException e){PICLUtils.logError(e);}
	}

	/*
	 * @see ILaunchConfigurationTab#dispose()
	 */
	public void dispose() {
	}

	/*
	 * @see ILaunchConfigurationTab#performApply(ILaunchConfigurationWorkingCopy)
	 */
	public void performApply(ILaunchConfigurationWorkingCopy config) {
		config.setAttribute(SOURCE_PATH, fSourceSearchField.getText().trim());	
		config.setAttribute(DEBUG_INITIALIZATION, fDebugInitializationButton.isSelected() );
		//radio buttons - only one must be selected, one has to be selected
//		for(int i=0; i < ENVIRONMENTS.length; i++)	
//			if(fEnvironmentGroup.isSelected(ENVIRONMENTS[i]))
//			{
//				config.setAttribute(ENVIRONMENT, ENVIRONMENTS[i]);	
//				break;
//			}
	}

	/*
	 * @see ILaunchConfigurationTab#getErrorMessage()
	 */
	public String getErrorMessage() {
		return null;
	}

	/*
	 * @see ILaunchConfigurationTab#getMessage()
	 */
	public String getMessage() {
		return null;
	}

	/*
	 * @see ILaunchConfigurationTab#isValid()
	 */
	public boolean isValid() {
		return true;
	}

	
	/*
	 * @see ILaunchConfigurationTab#launched(ILaunch)
	 */
	public void launched(ILaunch launch) {
	}
	
	protected void createFields() {
        fSourceSearchField = new StringDialogField(false);                
        fSourceSearchField.setLabelText(PICLUtils.getResourceString(PAGE_NAME + ".sourceSearchLabel"));

        fDebugInitializationButton = new SelectionButtonDialogField(SWT.CHECK|SWT.LEFT);
        fDebugInitializationButton.setLabelText(PICLUtils.getResourceString(PAGE_NAME + ".debugInitButtonLabel"));

//        String[] buttonTitles = {
//            PICLUtils.getResourceString(PAGE_NAME + ".envCommandWindowButtonLabel"),
//            PICLUtils.getResourceString(PAGE_NAME + ".envPreviousSessionButtonLabel"),
//            PICLUtils.getResourceString(PAGE_NAME + ".envDebuggerStartupButtonLabel")
//        };
//
//        fEnvironmentGroup = new SelectionButtonDialogFieldGroup(SWT.RADIO, buttonTitles, 1, SWT.SHADOW_IN);
//        fEnvironmentGroup.setLabelText(PICLUtils.getResourceString(PAGE_NAME + ".environmentGroupLabel"));
    }    

}
