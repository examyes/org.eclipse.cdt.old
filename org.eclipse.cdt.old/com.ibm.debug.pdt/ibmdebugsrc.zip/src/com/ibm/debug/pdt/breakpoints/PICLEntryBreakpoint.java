package com.ibm.debug.pdt.breakpoints;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.debug.core.model.IBreakpoint;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLUtils;

public class PICLEntryBreakpoint extends PICLLocationBreakpoint {

	/**
	 * Constructor for PICLEntryBreakpoint.
	 */
	public PICLEntryBreakpoint() {
		super();
	}

	public PICLEntryBreakpoint(
		final IResource resource,
		final String moduleName,
		final String objectName,
		final String sourceFileName,
		final boolean deferred,
		final boolean caseSensitive,
		final String entryName,
		final int lineNumber) {

		IWorkspaceRunnable body = new IWorkspaceRunnable() {
			public void run(IProgressMonitor monitor) throws CoreException {
				try {
					IMarker breakpointmarker =
						resource.createMarker(IPICLDebugConstants.PICL_ENTRY_BREAKPOINT);
					breakpointmarker.setAttributes(
						new String[] {
							IBreakpoint.ID,
							IBreakpoint.ENABLED,
							IPICLDebugConstants.MODULE_NAME,
							IPICLDebugConstants.OBJECT_NAME,
							IPICLDebugConstants.SOURCE_FILE_NAME,
							IPICLDebugConstants.DEFERRED,
							IPICLDebugConstants.CASESENSITIVE,
							IPICLDebugConstants.FUNCTION_NAME,
							IMarker.LINE_NUMBER },
						new Object[] {
							PICLUtils.getModelIdentifier(),
							new Boolean(true),
							moduleName,
							objectName,
							sourceFileName,
							new Boolean(deferred),
							new Boolean(caseSensitive),
							entryName,
							new Integer(lineNumber) });

					setMarker(breakpointmarker);
					registerBreakpoint();
				} catch (CoreException ce) {
				}
			}
		};
		try {
			ResourcesPlugin.getWorkspace().run(body, null);
		} catch (CoreException ce) {
		}

	}
	
	/**
	 * Get the function/method/entry name associated with this breakpoint
	 * @return String function name
	 * @throws CoreException
	 */
	public String getFunctionName() throws CoreException {
		String functionName = getMarker().getAttribute(IPICLDebugConstants.FUNCTION_NAME, "N/A");
		return functionName;
	}
	

}
