package com.ibm.debug.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.ui.texteditor.MarkerAnnotation;
import org.eclipse.ui.texteditor.ResourceMarkerAnnotationModel;

public class DebuggerMarkerAnnotationModel
	extends ResourceMarkerAnnotationModel {
	private String filename = null;

	/**
	 * Constructor for DebuggerMarkerAnnotationModel
	 */
	public DebuggerMarkerAnnotationModel(IResource resource) {
		super(resource);

	}

	/**
	 * Constructor for DebuggerMarkerAnnotationModel
	 */
	public DebuggerMarkerAnnotationModel(IResource resource, String name) {
		super(resource);

		filename = name;
	}
	/**
	 * @see AbstractMarkerAnnotationModel#createMarkerAnnotation(IMarker)
	 */
	protected MarkerAnnotation createMarkerAnnotation(IMarker marker) {

			return new DebuggerMarkerAnnotation(marker, filename);

	}

}

