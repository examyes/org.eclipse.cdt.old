////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

package com.ibm.debug.pdt.launchconfig;

import com.ibm.debug.internal.pdt.model.ProcessListColumnDetails;
import java.util.Vector;

public interface IProcessListSupplier {
	
    /*
     * Get the list of processes
     * @return the list of processes (a Vector of SystemProcess objects)
     * @see com.ibm.debug.model.SystemProcess
     */
    Vector getProcessList();

    /*
     * Get the process list column details
     * @return the process list column details
     * @see com.ibm.debug.model.ProcessListColumnDetails
     */
    ProcessListColumnDetails[] getProcessListColumnDetails();

}
