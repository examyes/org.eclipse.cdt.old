////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

package com.ibm.debug.pdt.launch;

import com.ibm.debug.internal.pdt.OldEngineParameters;

/**
 * @version 	1.0
 * @author
 */
public interface IOldEngineParameters
{
	public void setOldEngineParameters(OldEngineParameters parameters);
}
