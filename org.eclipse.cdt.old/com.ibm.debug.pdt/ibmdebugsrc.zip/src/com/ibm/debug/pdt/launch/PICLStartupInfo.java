package com.ibm.debug.pdt.launch;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.net.URL;

import org.eclipse.core.resources.IProject;
import org.eclipse.debug.core.ILaunchConfiguration;

import com.ibm.debug.epdc.EPDC;
import com.ibm.debug.pdt.WorkspaceSourceLocator;

/**
 * This class is used to provide launch or startup information for a debug
 * session.  This class is abstract and cannot be instantiated.  One of its
 * subclasses (e.g. PICLAttachInfo, PICLLoadInfo) should be instantiated
 * instead.  This class is not intended to be subclassed outside of this
 * plugin.
 */

public abstract class PICLStartupInfo {

    private IProject fProject;   
    private ILaunchConfiguration fLaunchConfig;
    private WorkspaceSourceLocator fWorkspaceSourceLocator;
    private String fTitle;
    private byte fLanguage = EPDC.LANG_CPP; // default to C++ for now.
    private URL fProfilePath = null;  // path where profile files should be saved.

    /**
     * Sets the resource to associate with the launch.  This must be
     * an instance of an IProject.
     * The project does not need to be set for a launch to be successful.
     * @param project The project to set
     * @see org.eclipse.core.resources.IResource
     * @see org.eclipse.core.resources.IProject
     */
    public void setProject(IProject project) {
        fProject = project;
    }

    /**
     * Gets the project
     * @return The project which is an instance of 
     * 			IProject, or null if it has not been set.
     * @see org.eclipse.core.resources.IResource
     * @see org.eclipse.core.resources.IProject
     */
    public IProject getProject() {
        return fProject;
    }    
   
   	public void setLaunchConfig(ILaunchConfiguration config){
   		fLaunchConfig = config;   		
   	}
   	
   	public ILaunchConfiguration getLaunchConfig(){
   		return fLaunchConfig;
   	}
    
   /**
     * Sets the workspace source locator to associate with the launch.  The
     * workspace source locator must be set for a launch to be successful.
     * @param workspaceSourceLocator The workspace source locator to set
     * @see WorkspaceSourceLocator
     */
    public void setWorkspaceSourceLocator(WorkspaceSourceLocator workspaceSourceLocator) {
        fWorkspaceSourceLocator = workspaceSourceLocator;
    }

    /**
     * Gets the workspace source locator
     * @return The workspace source locator
     * @see WorkspaceSourceLocator
     */
    public WorkspaceSourceLocator getWorkspaceSourceLocator() {
        return fWorkspaceSourceLocator;
    }

    /**
     * Sets the title.  The title does not need to be set for a successful
     * launch and may be left as null.
     * @param title The title to set. This string is displayed to the user
     *              as part of the launch info in the debug view.
     */
    public void setTitle(String title) {
        fTitle = title;
    }

    /**
     * Gets the title
     * @return The title
     */
    public String getTitle() {
        return fTitle;
    }
	/**
	 * Gets the language.
	 * @return Returns a byte
	 */
	public byte getLanguage() {
		return fLanguage;
	}

	/**
	 * Sets the language.
	 * @param language The language to set @see the EPDC interface for lauguage constants.
	 */
	public void setLanguage(byte language) {
		fLanguage = language;
	}

	/**
	 * Gets the profilePath.
	 * @return Returns a URL
	 */
	public URL getProfilePath() {
		return fProfilePath;
	}

	/**
	 * Sets the profilePath.
	 * @param profilePath The profilePath to set
	 */
	public void setProfilePath(URL profilePath) {
		fProfilePath = profilePath;
	}

}
