package com.ibm.debug.pdt.breakpoints;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.runtime.CoreException;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;


public class PICLWatchBreakpoint extends PICLEventBreakpoint {

	/**
	 * Constructor for PICLWatchBreakpoint.
	 */
	public PICLWatchBreakpoint() {
		super();
	}

	/**
	 * Returns the address associated with this breakpoint
	 * @return String address
	 * @throws CoreException
	 */
	public String getAddress() throws CoreException {
		String address = getMarker().getAttribute(IPICLDebugConstants.ADDRESS_EXPRESSION, "N/A");
		return address;
	}

}

