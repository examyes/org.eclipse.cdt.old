/////////////////////////////////////////////////////////////////////////
//                     IBM Confidential
//  xxxx-xxx (C) Copyright IBM Corp. ????, 2001 All rights reserved.
//             OCO Source Materials-Property of IBM.
//
// The source code for this program is not published or otherwise
// divested of its trade secrets, irrespective of what has been
// deposited with the U.S. Copyright Office.
//
// Version %I% of %H% (last modified %G% %U%)
/////////////////////////////////////////////////////////////////////////
package com.ibm.debug.pdt.launchconfig;

import java.util.Vector;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import com.ibm.debug.epdc.EPDC;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.ProcessListColumnDetails;
import com.ibm.debug.internal.pdt.model.SystemProcess;


/**
 * Dialog for selecting a process from a list.  Contains a table of
 * processes and OK, Refresh and Cancel buttons.
 */ 
public class ProcessSelectionDialog extends Dialog {

    private static String DIALOG = "ProcessSelectionDialog";
    
    private Table fTable;
    private Button fRefreshButton;
    private IProcessListSupplier fProcessListSupplier;
    private Vector fProcessList;
    private ProcessListColumnDetails[] fColumnDetails;
    private int fSelectionIndex = -1;

    /**
     * Constructor for ProcessListSelectionDialog
     * @param parent The parent shell.
     * @param processListSupplier The class that will supply the process list information.
     */
    public ProcessSelectionDialog(Shell parent, IProcessListSupplier processListSupplier) {
        super(parent);
/*
        int style = getShellStyle();
        setShellStyle(style | SWT.RESIZE);
*/
        fProcessListSupplier = processListSupplier;
    }

    /**
     * @see Window#open
     */
    public int open() {
        BusyIndicator.showWhile(null, new Runnable() {
            public void run() {
                access$superOpen();
            }
        });

        return getReturnCode();
    }

    private void access$superOpen() {
        super.open();
    }

    /**
     * @see Window#configureShell
     */
    protected void configureShell(Shell shell) {
        super.configureShell(shell);
        shell.setText(PICLUtils.getResourceString(DIALOG+".title"));
    }

    /**
     * @see Dialog#createButtonsForButtonBar
     */
    protected void createButtonsForButtonBar(Composite parent) {
        createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
        fRefreshButton = createButton(parent, PICLUtils.getResourceString(DIALOG+".refreshButton"));
        createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
    }

    /**
     * Create a button.
     * @param parent The parent composite.
     * @param label The label for the button.
     */
    private Button createButton(Composite parent, String label) {

        //increment the number of columns in the button bar
        ((GridLayout)parent.getLayout()).numColumns++;

        Button button= new Button(parent, SWT.PUSH);
        button.setText(label);
        button.addSelectionListener(new SelectionAdapter() {
            public void widgetSelected(SelectionEvent event) {
                buttonPressed(event.getSource());
            }
            public void widgetDefaultSelected(SelectionEvent event) {
                buttonPressed(event.getSource());
            }
        });

        GridData gridData= new GridData();
        gridData.horizontalAlignment= gridData.FILL;
        gridData.heightHint = convertVerticalDLUsToPixels(IDialogConstants.BUTTON_HEIGHT);
        int widthHint = convertHorizontalDLUsToPixels(IDialogConstants.BUTTON_WIDTH);
        gridData.widthHint = Math.max(widthHint, button.computeSize(SWT.DEFAULT, SWT.DEFAULT, true).x);
        button.setLayoutData(gridData);

        return button;
    }

    /**
     * Handles a button pressed event.
     * @param source The button that was pressed.
     */
    private void buttonPressed(Object source) {
        if(source == fRefreshButton) {
            fTable.setRedraw(false);
            fTable.removeAll();
            fProcessList = fProcessListSupplier.getProcessList();
            createTableEntries();
            fSelectionIndex = -1;
            fTable.setRedraw(true);
        }
    }

    /**
     * @see Dialog#createDialogArea
     */
    protected Control createDialogArea(Composite parent) {
        Composite composite = (Composite)super.createDialogArea(parent);
        ((GridLayout)composite.getLayout()).numColumns = 1;

        createTable(composite);

        GridData gridData = new GridData();
        gridData.horizontalAlignment = gridData.FILL;
        gridData.grabExcessHorizontalSpace = true;
        gridData.verticalAlignment = gridData.FILL;
        gridData.grabExcessVerticalSpace = true;
        gridData.horizontalSpan = 1;
        gridData.heightHint = 250;
        fTable.setLayoutData(gridData);

        return composite;
    }

    private void createTable(Composite parent) {
        fTable = new Table(parent, SWT.BORDER | SWT.SINGLE | SWT.V_SCROLL | SWT.V_SCROLL | SWT.FULL_SELECTION);
        fTable.setHeaderVisible(true);
        
        TableLayout tableLayout = new TableLayout();
        fProcessList = fProcessListSupplier.getProcessList();
        fColumnDetails = fProcessListSupplier.getProcessListColumnDetails();
        // TODO: handle case where cannot get process list
        for (int i = 0; i < fColumnDetails.length; i++) {
            tableLayout.addColumnData(new ColumnWeightData(10));
            int style = getStyle(fColumnDetails[i].getColumnTextAlignment());
            TableColumn column = new TableColumn(fTable, style);
            column.setText(fColumnDetails[i].getColumnName());
        }
        fTable.setLayout(tableLayout);
        fTable.setEnabled(true);
        fTable.addSelectionListener(new SelectionListener() {
            public void widgetSelected(SelectionEvent e) {
                fSelectionIndex = fTable.getSelectionIndex();
            }
            public void widgetDefaultSelected(SelectionEvent e) {
                fSelectionIndex = fTable.getSelectionIndex();
            }
        }); 

        createTableEntries();
    }

    private void createTableEntries() {
        for(int i = 0; i < fProcessList.size(); i++) {
            SystemProcess process = (SystemProcess)fProcessList.elementAt(i);
            String[] details = process.getProcessDetails();
            TableItem item = new TableItem(fTable, SWT.NONE);
            item.setText(details);
        }
    }

    private int getStyle(int alignment) {
        int style = SWT.NONE;
        switch(alignment) {
            case EPDC.Centered:
                style = SWT.CENTER;
                break;
            case EPDC.LeftJustified:
                style = SWT.LEFT;
                break;
            case EPDC.RightJustified:
                style = SWT.RIGHT;
                break;
        }
        return style;
    }

    /**
     * Get the selected SystemProcess.
     * @return The selected SystemProcess or null if none.
     */
    public SystemProcess getSelectedProcess() {
        if (fSelectionIndex == -1)
            return null;

        return (SystemProcess)fProcessList.elementAt(fSelectionIndex);
    }

    /**
     * Get the process list column details.
     * @return The process list column details.
     */
    public ProcessListColumnDetails[] getProcessListColumnDetails() {
        return fColumnDetails;
    }
}
