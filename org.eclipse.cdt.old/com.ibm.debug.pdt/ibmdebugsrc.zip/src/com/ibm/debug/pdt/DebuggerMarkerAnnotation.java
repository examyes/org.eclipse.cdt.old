package com.ibm.debug.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.debug.ui.DebugUITools;
import org.eclipse.debug.ui.IDebugModelPresentation;
import org.eclipse.ui.texteditor.MarkerAnnotation;
import org.eclipse.ui.texteditor.MarkerUtilities;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;

public class DebuggerMarkerAnnotation extends MarkerAnnotation {

	private String filename = null;
	private boolean mySetupDone = false;
	private IDebugModelPresentation fPresentation = null;
	/**
	 * Constructor for DebuggerMarkerAnnotation
	 */
	public DebuggerMarkerAnnotation(IMarker marker, String name) {
		super(marker);
		filename = name;
		// super(marker) calls initialize() before I have a chance to
		// save the filename, so I need to skip running initialize() until
		// I can save the filename.  This is the purpose of the mySetupDone
		// flag and the check of it in initialize().
		mySetupDone = true;
		initialize();
	}


	/**
	 * @see MarkerAnnotation#initialize()
	 */
	protected void initialize() {
		if (!mySetupDone)
			return;
		IMarker breakpoint = getMarker();

		if (MarkerUtilities.isMarkerType(breakpoint, IBreakpoint.BREAKPOINT_MARKER)) {

			try {
				if (filename != null) {
					// Need to make sure this marker should be shown for this editor input
					// Because engine supplied views store breakpoints (markers) against the workspace
					// root, only the markers that have a filename that matches the engine supplied view
					// should be shown.
					String sourceFilename =
						(String) breakpoint.getAttribute(IPICLDebugConstants.SOURCE_FILE_NAME);
					if (!filename.equals(sourceFilename))
						return;
				}
			} catch(CoreException e) {
			}

			if (fPresentation == null)
				fPresentation = DebugUITools.newDebugModelPresentation();

			setLayer(2);
			setImage(fPresentation.getImage(breakpoint));
			return;
		}

		super.initialize();
	}}

