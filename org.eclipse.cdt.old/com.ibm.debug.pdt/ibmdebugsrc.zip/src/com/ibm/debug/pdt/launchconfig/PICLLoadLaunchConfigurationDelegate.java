package com.ibm.debug.pdt.launchconfig;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.core.Launch;
import org.eclipse.debug.core.model.ILaunchConfigurationDelegate;

import com.ibm.debug.daemon.CoreDaemon;
import com.ibm.debug.daemon.IDaemonDebugTarget;
import com.ibm.debug.daemon.CoreDaemon.OldDaemonInput;
import com.ibm.debug.internal.pdt.OldEngineParameters;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.pdt.WorkspaceSourceLocator;
import com.ibm.debug.pdt.launch.PICLLoadInfo;

/**
 * @version 	1.0
 * @author
 */
public class PICLLoadLaunchConfigurationDelegate
	implements ILaunchConfigurationDelegate, IConfigurationConstants{

	public PICLLoadInfo createLoadInfo(ILaunchConfiguration config)
	{
		PICLLoadInfo loadInfo = new PICLLoadInfo();
		try{
			loadInfo.setLaunchConfig(config); //needed?
			loadInfo.setProgramName(config.getAttribute(PROGRAM_NAME,""));
			loadInfo.setProgramParms(config.getAttribute(PARAMETERS,""));
			loadInfo.setProject(getProjectResource(config.getAttribute(PROJECT,"")));			
			
			if(config.getAttribute(DEBUG_INITIALIZATION, false))
				loadInfo.setStartupBehaviour(PICLLoadInfo.DEBUG_INITIALIZATION);
			else
				loadInfo.setStartupBehaviour(PICLLoadInfo.RUN_TO_MAIN);
			//todo do something with the environment command window...
			
			loadInfo.setWorkspaceSourceLocator( createSourceLocator(getProjectResource(config.getAttribute(PROJECT,"")), config.getAttribute(SOURCE_PATH, "")) );
			
		}catch(CoreException e){PICLUtils.logError(e);}
        return loadInfo;
	}
	
	 protected WorkspaceSourceLocator createSourceLocator(IProject project, String searchPath) {
        WorkspaceSourceLocator sourceLocator = new WorkspaceSourceLocator();
                
        sourceLocator.setHomeProject(project);
        sourceLocator.setSearchPath(searchPath);

        return sourceLocator;
    }
    
       
    
    
    /**
	 * Returns the WorkspaceRoot
	 */
	public IWorkspaceRoot getWorkspaceRoot() {
		return ResourcesPlugin.getWorkspace().getRoot();
	}

	private IProject getProjectResource(String projectName)
	{
		IProject projects[] = getWorkspaceRoot().getProjects();
		for (int i = 0; i < projects.length; i++) {
			if(projects[i].getName().equals(projectName))
				return projects[i];
		}
		return null;
	}
 	
	/**
	 * @see ILaunchConfigurationDelegate#launch(ILaunchConfiguration, String, ILaunch, IProgressMonitor)
	 */
	public void launch(
		ILaunchConfiguration config,
		String mode,
		ILaunch launch,
		IProgressMonitor monitor)
		throws CoreException {
			
			PICLUtils.logText("Got to the PICL Load launch config delegate");
		if(!(config.getType().supportsMode(mode))) //needed ?
			return;		
		if(config.getAttribute(DAEMON, false)) //daemon, not dialog
		{ //no target available already, start fresh
			int key = config.getAttribute(KEY,-99999);
			if(key == -99999)
				return;  //something went wrong, todo error message
			OldDaemonInput input = CoreDaemon.retrieveOldDaemonInput(key);
			if(input == null)
				return;//something went wrong, todo error message
			OldEngineParameters engineParameters = new OldEngineParameters();
			//get StringArray from Daemon storage		
    		engineParameters.setInfo(input.getInputArray());   			   
    		//todo - decide if we want socket info inside connection info 		    		
    		engineParameters.getConnectionInfo().setConnection(input.getSocket());
    		
			PICLLoadInfo loadInfo = null;
   		 	
        	loadInfo = new PICLLoadInfo();
			loadInfo.setLaunchConfig(config);   
        	
        	if(engineParameters.debuggeeName() != null)
        		loadInfo.setProgramName(engineParameters.debuggeeName());
        	if(engineParameters.debuggeeArgs() != null)
        			loadInfo.setProgramParms(engineParameters.debuggeeArgs()); 
        		
			if( engineParameters.getConnectionInfo() !=null)
        	{
        		loadInfo.setEngineConnectionInfo(engineParameters.getConnectionInfo());        
        		loadInfo.setEngineWaiting(true);
        	}
        	else loadInfo.setEngineWaiting(false);
        	loadInfo.setWorkspaceSourceLocator(new WorkspaceSourceLocator());
        	loadInfo.setStartupBehaviour(engineParameters.getLoadStartupBehaviour());     
        	//todo getSourceSearchPath if any        
        	PICLDebugTarget target = new PICLDebugTarget(launch, loadInfo,loadInfo.getEngineConnectionInfo()); //connection info can't be null	     	   	
        	if(target != null)
			{
				launch.addDebugTarget(target);			
				launch.setSourceLocator(loadInfo.getWorkspaceSourceLocator());
				PICLUtils.logText("calling debug target.engineIsWaiting()");
				((IDaemonDebugTarget)target).engineIsWaiting(loadInfo.getEngineConnectionInfo());
			}	        	
        	 	
		}
		else
		{
			PICLLoadInfo loadInfo =  createLoadInfo(config);
			if(loadInfo == null)
			{
				PICLUtils.logText("Startup info is null - error occurred");
				return;
			}
	    	PICLDebugTarget target = new PICLDebugTarget(launch, loadInfo,loadInfo.getEngineConnectionInfo()); //connection info can't be null
	    	
    		int key=CoreDaemon.generateKey();
    		CoreDaemon.storeDebugTarget(target, key);  		
			launch.addDebugTarget(target);
			launch.setSourceLocator(loadInfo.getWorkspaceSourceLocator());
    		target.launchEngine(key);    	
		}
		
		return;
	}

}
