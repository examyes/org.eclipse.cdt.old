package com.ibm.debug.pdt.productsupport;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

import java.util.*;
import java.io.*;
import com.ibm.debug.epdc.*;

public class IdealMsgDecoder implements IFormattedString
{
  public String decodeString(byte[] packetBuffer) 
  {
  	String messageContent = null;
  	
    try
    {    
      DataInputStream wholeBufferInputStream = new DataInputStream(new ByteArrayInputStream(packetBuffer));
   
      //Get the length of the upper case English message content.
      short msgContentUELength = wholeBufferInputStream.readShort();
      //System.out.println("upper case English message length is " + msgContentUELength);
      //Get the content into a byte array.
      byte[] msgContentByteArray = new byte[msgContentUELength];
      wholeBufferInputStream.read(msgContentByteArray);
      String msgContentUE = new String(msgContentByteArray, "UTF-8");
      //System.out.println("upper case English message constent is: " +  msgContentUE);
      
      //Get the length of the message ID string                                                                     
      short messageIDStringLength = wholeBufferInputStream.readShort();
      //System.out.println("message ID string length is " + messageIDStringLength);
      //Get the content into a byte array.
      byte[] msgIDStringByteArray = new byte[messageIDStringLength];
      wholeBufferInputStream.read(msgIDStringByteArray);
      
      String messageIDString = new String(msgIDStringByteArray, "UTF-8");
      //System.out.println("message ID string is : " + messageIDString);

      
      try
      {
        //Get the resouce bundles
        ResourceBundle messagesBundle;
        //Use the default locale of the JVM.
        messagesBundle = ResourceBundle.getBundle("com.ibm.debug.pdt.productsupport.IdealMessages", Locale.getDefault());
    
        messageContent = messagesBundle.getString(messageIDString);
      }//end try

      catch (Exception e)
      {
        //Something wrong with retrieving resource.  Use upper case English
        //text.
        messageContent = msgContentUE;
      }
      
      //Get number of substitution strings.
      short numberOfSubstitutionStrings = wholeBufferInputStream.readShort();
      System.out.println("numberOfSubstitutionStrings is : " + numberOfSubstitutionStrings);
      if (numberOfSubstitutionStrings > 0)
      {
        String[] substitutionStringArray = new String[numberOfSubstitutionStrings];
        //Go through the loop
        
        for (int i=0; i<numberOfSubstitutionStrings; ++i)
        {
          short substitutionStringLength = wholeBufferInputStream.readShort(); 
          byte[] substitutionStringByteArray = new byte[substitutionStringLength];
          wholeBufferInputStream.read(substitutionStringByteArray);
  
          //Store it into the array.
          substitutionStringArray[i] = new String(substitutionStringByteArray, "UTF-8");
          //System.out.println(i + ": " + substitutionStringArray[i]);
        }//end for

        messageContent = addReplacementText(messageContent, substitutionStringArray);
        
        
      }//end if

      //System.out.println("Message content is  : " + messageContent);
    
    }//end try  
  
   catch(java.io.IOException e)
   {
     System.out.println("Error ...");
   }

   return messageContent;
  }
  



  
  //Get a message string from the messages ResourceBundle object with replacement text
  static public String addReplacementText(String messageText, String [] replacementText)
  {
     for (int i = 0; i < replacementText.length; i++)
     {
        //
        // Find %i
        //
        int index = messageText.indexOf("%" + (i+1));
        if (index == -1)
        {
           return messageText;
        }
        else
        {
           messageText = messageText.substring(0, index) + replacementText[i] + messageText.substring(index+2, messageText.length());
        }
     }
     return messageText;
  }
  

}
