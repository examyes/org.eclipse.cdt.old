package com.ibm.debug.pdt.launchconfig;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////



import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.ui.AbstractLaunchConfigurationTab;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.ui.model.WorkbenchLabelProvider;

import com.ibm.debug.daemon.CoreDaemon;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.ui.dialogs.ElementTreeSelectionDialog;
import com.ibm.debug.internal.pdt.ui.util.DialogField;
import com.ibm.debug.internal.pdt.ui.util.IDialogFieldListener;
import com.ibm.debug.internal.pdt.ui.util.IStringButtonAdapter;
import com.ibm.debug.internal.pdt.ui.util.MGridLayout;
import com.ibm.debug.internal.pdt.ui.util.StringButtonDialogField;
import com.ibm.debug.internal.pdt.ui.util.StringComboButton;
import com.ibm.debug.internal.pdt.ui.util.StringDialogField;
import com.ibm.debug.internal.pdt.ui.views.BasicContainerContentProvider;
import com.ibm.debug.pdt.launch.PICLLoadInfo;


public class PICLLoadMainTab extends AbstractLaunchConfigurationTab
	implements IDialogFieldListener, IStringButtonAdapter,IConfigurationConstants {
	
	private static final String PAGE_NAME= "PICLLoadLaunchConfigTab1";        

    private IProject fProject;
    private String[] fProgramNames;
   // private IProgramNameListener fProgramNameListener;
    private PICLLoadInfo fLoadInfo;
    private StringComboButton fProgramNameField;
    private StringDialogField fProgramParmsField;
    private StringButtonDialogField fProjectField;
    private String fErrorMessage;
        
/*
    private SelectionButtonDialogField fUseProfileButton;
*/

	/**
	 * @see ILaunchConfigurationTab#getName()
	 */
	public String getName() {
		return PICLUtils.getResourceString(PAGE_NAME + ".name");
	}
	
   	/*
	 * @see ILaunchConfigurationTab#okToLeave()
	 */
	public boolean okToLeave() {
		return isValid();
	}

	/*
	 * @see ILaunchConfigurationTab#createControl(Composite)
	 */
	public void createControl(Composite parent) {
		
		createFields();
		
		Composite fComposite = new Composite(parent, SWT.NONE);
		setControl(fComposite);
        int nColumns= 2;

        MGridLayout layout = new MGridLayout();
        layout.marginWidth = 0;
        layout.marginHeight = 20;
        layout.minimumWidth = 400;
        layout.minimumHeight = 200;
        layout.numColumns = nColumns;
        fComposite.setLayout(layout);
        
        fProjectField.doFillIntoGrid(fComposite, nColumns);                 
        fProgramNameField.doFillIntoGrid(fComposite, nColumns);                
        fProgramParmsField.doFillIntoGrid(fComposite, nColumns);   
                  
/*
        new Separator().doFillIntoGrid(composite, nColumns, 8);
        fUseProfileButton.doFillIntoGrid(composite, nColumns);
*/

        if(fProgramNames != null) {
            fProgramNameField.setItems(fProgramNames);
            fProgramNameField.setText(fProgramNames[0]);
            fProgramNameField.setDialogFieldListener(this);
        }               
	}

	
	/*
	 * @see ILaunchConfigurationTab#setDefaults(ILaunchConfigurationWorkingCopy)
	 */
	public void setDefaults(ILaunchConfigurationWorkingCopy config) {				 
			config.setAttribute(PROGRAM_NAME,""); 
			config.setAttribute(PARAMETERS,"");	
	}

	/*
	 * @see ILaunchConfigurationTab#initializeFrom(ILaunchConfiguration)
	 */
	public void initializeFrom(ILaunchConfiguration config) {
		try{
			fProgramParmsField.setText(config.getAttribute(PARAMETERS,""));
			fProgramNameField.setText(config.getAttribute(PROGRAM_NAME,"")); 
			fProjectField.setText(config.getAttribute(PROJECT,""));
		}catch(CoreException e){ PICLUtils.logError(e);}
	}

	/*
	 * @see ILaunchConfigurationTab#dispose()
	 */
	public void dispose() {
	}

	/*
	 * @see ILaunchConfigurationTab#performApply(ILaunchConfigurationWorkingCopy)
	 */
	public void performApply(ILaunchConfigurationWorkingCopy config) {	
			config.setAttribute(PARAMETERS,fProgramParmsField.getText());
			config.setAttribute(PROGRAM_NAME,fProgramNameField.getText());
			config.setAttribute(PROJECT, fProjectField.getText());
		
			//make sure daemon is running 
			//todo - better place for this???
			if(CoreDaemon.startListening() == false)
			{
				fErrorMessage = PICLUtils.getResourceString(PAGE_NAME+".daemonFailedToStartError") ;  //todo error message				
			} 				
	}

	/*
	 * @see ILaunchConfigurationTab#getErrorMessage()
	 */
	public String getErrorMessage() {
		return fErrorMessage;
	}

	/*
	 * @see ILaunchConfigurationTab#getMessage()
	 */
	public String getMessage() {
		return null;
	}

	/*
	 * @see ILaunchConfigurationTab#isValid()
	 */
	public boolean isValid() {
		 // Minimum to start debugging is a program name
        if(!fProgramNameField.getText().equals(""))
        {
        	if( !getProject().equals("")) 
			{
		 		if(!projectExists(getProject()) )
				{
					fErrorMessage = PICLUtils.getResourceString(PAGE_NAME +".projectDoesNotExistError");
					return false;
				}
				else fErrorMessage=null;
			}
			fErrorMessage = null;
            return true;
        }
        fErrorMessage = PICLUtils.getResourceString(PAGE_NAME +".programNameNeededError");
        return false;
	}

	

	/*
	 * @see ILaunchConfigurationTab#launched(ILaunch)
	 */
	public void launched(ILaunch launch) {
	}
	
	protected void createFields() {
        fProgramNameField = new StringComboButton(this, false);                
        fProgramNameField.setLabelText(PICLUtils.getResourceString(PAGE_NAME+".programNameLabel"));
        fProgramNameField.setButtonLabel(PICLUtils.getResourceString(PAGE_NAME+".browseLabel"));

        // Set the listener after the text is set - so no event.
        fProgramNameField.setDialogFieldListener(this);                
            
        fProgramParmsField = new StringDialogField(false);                
        fProgramParmsField.setLabelText(PICLUtils.getResourceString(PAGE_NAME+".programParmsLabel"));
  		
  		fProjectField = new StringButtonDialogField(this, false);
		fProjectField.setLabelText(PICLUtils.getResourceString(PAGE_NAME+".projectLabel"));
		fProjectField.setDialogFieldListener(this);
		fProjectField.setButtonLabel(PICLUtils.getResourceString(PAGE_NAME+".browseLabel"));  
/*
        fUseProfileButton = new SelectionButtonDialogField(SWT.CHECK|SWT.LEFT);
        fUseProfileButton.setLabelText(PICLUtils.getResourceString(PAGE_NAME+".profileButtonLabel"));
*/
    }
    
    /**
     * One of the dialog fields was changed
     * @see IDialogFieldListener
     */
    public void dialogFieldChanged(DialogField field) {                
        if(field == fProgramNameField || field == fProjectField) {                  
            updateLaunchConfigurationDialog();
        }        
    }

    /**
     * One of the browse buttons was pressed.
     * @see IStringButtonAdapter
     */
    public void changeControlPressed(DialogField field) {
        if (field == fProgramNameField) {
            String programName = chooseProgramName();
            if (programName != null)
                fProgramNameField.setText(programName);
        }else if (field == fProjectField)
		{
			IProject fSelectedProject = chooseProject();
			if (fSelectedProject!=null && fSelectedProject.getName()!=null)
				fProjectField.setText(fSelectedProject.getName());
		}
    }

	private IProject chooseProject() {
		ILabelProvider labelProvider = new WorkbenchLabelProvider();
		BasicContainerContentProvider contentProvider =
			new BasicContainerContentProvider();
		ElementTreeSelectionDialog dialog =
			new ElementTreeSelectionDialog(
				getShell(),
				PICLUtils.getResourceString("ElementTreeSelectionDialog.title"),
				labelProvider,
				contentProvider,
				false,
				true);

		dialog.setMessage(
			PICLUtils.getResourceString("ElementTreeSelectionDialog.description"));

		if (dialog.open(getWorkspaceRoot()) == dialog.OK) {
			Object element = dialog.getPrimaryResult();
			if (element instanceof IProject) {
				return (IProject) element;
			}
		}
		return null;
	}      
    private String chooseProgramName() {
        FileDialog dialog = new FileDialog(getShell(), SWT.MULTI);
        if(fProject != null && fProject.getLocation() != null)
            dialog.setFilterPath(fProject.getLocation().toOSString());
        return dialog.open();
    }

    /**
     * Get the program name as entered in the wizard by the user.
     * @return Returns the program name.
     */
    public String getProgramName() {
        return fProgramNameField.getText().trim();
    }

    /**
     * Get the program parameters as entered in the wizard by the user.
     * @return Returns the program parameters.
     */
    public String getProgramParms() {
        return fProgramParmsField.getText().trim();
    }
    /**
     * Get the program parameters as entered in the wizard by the user.
     * @return Returns the program parameters.
     */
    public String getProject() {
        return fProjectField.getText().trim();
    }

    /**
     * Get the use profile setting as entered in the wizard by the user.
     * @return Returns the use profile setting.
     */
/*
    public boolean useProfile() {
        return fUseProfileButton.isSelected();
    }
*/
	/**
	 * Returns the WorkspaceRoot
	 */
	public IWorkspaceRoot getWorkspaceRoot() {
		return ResourcesPlugin.getWorkspace().getRoot();		
	}

	public IProject getProjectResource()
	{
		String projectName = fProjectField.getText();
		IProject projects[] = getWorkspaceRoot().getProjects();
		for (int i = 0; i < projects.length; i++) {
			if(projects[i].getName().equals(projectName))
				return projects[i];
		}
		return null;
	}
	
	private boolean projectExists(String projectName)
	{
		IProject projects[] = ResourcesPlugin.getWorkspace().getRoot().getProjects();
		for (int i = 0; i < projects.length; i++) {
			if(projects[i].getName().equals(projectName))
				return true;
		}
		return false;
	}
}
