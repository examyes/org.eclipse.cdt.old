package com.ibm.debug.pdt.launchconfig;

import org.eclipse.debug.ui.AbstractLaunchConfigurationTabGroup;
import org.eclipse.debug.ui.CommonTab;
import org.eclipse.debug.ui.ILaunchConfigurationDialog;
import org.eclipse.debug.ui.ILaunchConfigurationTab;

/**
 * The tab group for the Attach tabs.
 */
public class PICLAttachLaunchConfigurationTabGroup
	extends AbstractLaunchConfigurationTabGroup{

	/**
	 * @see ILaunchConfigurationTabGroup#createTabs(ILaunchConfigurationDialog, String)
	 */
	public void createTabs(ILaunchConfigurationDialog dialog, String mode) {
		ILaunchConfigurationTab[] tabs = new ILaunchConfigurationTab[3];
		tabs[0] = new PICLAttachMainTab();
		tabs[1]	= new PICLAttachAdvancedTab();
        tabs[2] = new CommonTab();
		setTabs(tabs);
		
	}

}
