
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////
package com.ibm.debug.pdt.launchconfig;

import com.ibm.debug.pdt.launch.PICLLoadInfo;

public interface IConfigurationConstants {
	
	public static final String SOURCE_PATH = "SourcePath";
    public static final String DEBUG_INITIALIZATION = "DebugInitialization";
    public static final String ENVIRONMENT = "Environment";
    public static final String PROCESS_PATH="ProcessPath";
    public static final String USE_PROCESS_LIST = "UseProcessList";
    public static final String USE_PROFILE = "UseProfile";
    public static final String PID = "PID";
    public static final String PROJECT = "Project";
    
    public static final int[] ENVIRONMENTS = {
        PICLLoadInfo.ENV_COMMAND_WINDOW,
        PICLLoadInfo.ENV_PREVIOUS_SESSION,
        PICLLoadInfo.ENV_DEBUGGER_STARTUP
    };
    
    public static final String PARAMETERS = "Parameters";
    public static final String PROGRAM_NAME="ProgramName";
    
    /*
    public static final String USE_PROFILE = "UseProfile";
	*/
	
	public static final String VERSION="Version";
	public static final String KEY="Key";
	//Used to indicate that the launch call came from the daemon, not directly from the automatic
	//call made on behalf of the dialog
	public static final String DAEMON = "Daemon"; 

}
