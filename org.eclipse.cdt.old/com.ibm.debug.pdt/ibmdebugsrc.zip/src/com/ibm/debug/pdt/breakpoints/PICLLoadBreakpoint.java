package com.ibm.debug.pdt.breakpoints;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.runtime.CoreException;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;

public class PICLLoadBreakpoint extends PICLEventBreakpoint {

	/**
	 * Constructor for PICLLoadBreakpoint.
	 */
	public PICLLoadBreakpoint() {
		super();
	}


	/**
	 * Returns module name associated with this breakpoint
	 * @return String module name
	 * @throws CoreException
	 */
	public String getModuleName() throws CoreException {
		String moduleName = getMarker().getAttribute(IPICLDebugConstants.MODULE_NAME, "N/A");
		return moduleName;
	}

}

