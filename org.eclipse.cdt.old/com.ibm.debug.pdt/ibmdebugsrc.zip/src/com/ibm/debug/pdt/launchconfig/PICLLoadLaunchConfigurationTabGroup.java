package com.ibm.debug.pdt.launchconfig;

import org.eclipse.debug.ui.AbstractLaunchConfigurationTabGroup;
import org.eclipse.debug.ui.CommonTab;
import org.eclipse.debug.ui.ILaunchConfigurationDialog;
import org.eclipse.debug.ui.ILaunchConfigurationTab;

/**
 * The tab group for the Load tabs.
 */
public class PICLLoadLaunchConfigurationTabGroup
	extends AbstractLaunchConfigurationTabGroup{

	/**
	 * @see ILaunchConfigurationTabGroup#createTabs(ILaunchConfigurationDialog, String)
	 */
	public void createTabs(ILaunchConfigurationDialog dialog, String mode) {
		ILaunchConfigurationTab[] tabs = new ILaunchConfigurationTab[3];
		tabs[0] = new PICLLoadMainTab();
		tabs[1]	= new PICLLoadAdvancedTab();
        tabs[2] = new CommonTab();
		setTabs(tabs);
		
	}
	

}
