package com.ibm.debug.pdt.launchconfig;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////



import java.util.Vector;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.ui.AbstractLaunchConfigurationTab;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.model.WorkbenchLabelProvider;

import com.ibm.debug.daemon.CoreDaemon;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.ProcessListColumnDetails;
import com.ibm.debug.internal.pdt.model.SystemProcess;
import com.ibm.debug.internal.pdt.ui.dialogs.ElementTreeSelectionDialog;
import com.ibm.debug.internal.pdt.ui.util.DialogField;
import com.ibm.debug.internal.pdt.ui.util.IDialogFieldListener;
import com.ibm.debug.internal.pdt.ui.util.IStringButtonAdapter;
import com.ibm.debug.internal.pdt.ui.util.MGridData;
import com.ibm.debug.internal.pdt.ui.util.MGridLayout;
import com.ibm.debug.internal.pdt.ui.util.SelectionButtonDialogField;
import com.ibm.debug.internal.pdt.ui.util.Separator;
import com.ibm.debug.internal.pdt.ui.util.StringButtonDialogField;
import com.ibm.debug.internal.pdt.ui.views.BasicContainerContentProvider;

/**
 * @version 	1.0
 * @author
 */
public class PICLAttachMainTab extends  AbstractLaunchConfigurationTab
				 implements IDialogFieldListener, ModifyListener, IConfigurationConstants,
				  IProcessListSupplier,IStringButtonAdapter {

	private static final String TAB_NAME= "PICLAttachLaunchConfigTab1";  
		
	private SelectionButtonDialogField fUseProcessListButton;
    private Button fGetProcessListButton;
    private Group fSelectionGroup;
    private Label fSelectionGroupLabel;
    private SelectionButtonDialogField fEnterPIDButton;
    private Text fPIDText;
    private SelectionButtonDialogField fUseProfileButton;
    private StringButtonDialogField fProjectField;	
	private String fErrorMessage;

    private SystemProcess fProcess = null;
    private ProcessListColumnDetails[] fColumnDetails;
	private PICLDebugTarget fDebugTarget;
	
   

	/*
	 * @see ILaunchConfigurationTab#okToLeave()
	 */
	public boolean okToLeave() {
		return isValid();		
	}
	
	/**
	 * @see ILaunchConfigurationTab#getName()
	 */
	public String getName() {
		return PICLUtils.getResourceString(TAB_NAME + ".name");
	}

	/*
	 * @see ILaunchConfigurationTab#createControl(Composite)
	 */
	public void createControl(Composite parent) {
		
		Composite fComposite = new Composite(parent, SWT.NONE);
		setControl(fComposite);
        int nColumns= 3;

        MGridLayout layout = new MGridLayout();
        layout.marginWidth = 0;
        layout.marginHeight = 20;
        layout.minimumWidth = 400;
        layout.minimumHeight = 200;
        layout.numColumns = nColumns;
        fComposite.setLayout(layout);
                    
        createUseProcessListButton();
        fUseProcessListButton.doFillIntoGrid(fComposite, 1);                    
		
        createGetProcessListButton(fComposite);
        MGridData gridData = new MGridData();
        gridData.horizontalAlignment = gridData.BEGINNING;
        gridData.grabExcessHorizontalSpace = false;
        gridData.horizontalSpan = 1;            
        fGetProcessListButton.setLayoutData(gridData);

        new Separator().doFillIntoGrid(fComposite, 1, 1);
	//	new Separator().doFillIntoGrid(fComposite, 1, 1);
		
        createSelectionGroup(fComposite);
        gridData = new MGridData();
        gridData.horizontalAlignment = gridData.FILL;
        gridData.grabExcessHorizontalSpace = true;
        gridData.horizontalSpan = nColumns;            
        fSelectionGroup.setLayoutData(gridData);


		createEnterPIDButton();
        fEnterPIDButton.doFillIntoGrid(fComposite, 1);        
      //  new Separator().doFillIntoGrid(fComposite, 2, 1);
        createPIDText(fComposite);
        gridData = new MGridData();
        gridData.horizontalAlignment = gridData.FILL;
        gridData.grabExcessHorizontalSpace = true;
        gridData.horizontalSpan = 1;            
        fPIDText.setLayoutData(gridData);     
		new Separator().doFillIntoGrid(fComposite, 1, 1);
		
		new Separator().doFillIntoGrid(fComposite, 3, 30);
		
		fProjectField = new StringButtonDialogField(this, false);
		fProjectField.setLabelText(PICLUtils.getResourceString(TAB_NAME+".projectLabel"));
		fProjectField.setDialogFieldListener(this);
		fProjectField.setButtonLabel(PICLUtils.getResourceString(TAB_NAME+".browseLabel")); 		
		fProjectField.doFillIntoGrid(fComposite, nColumns); 		

      //  createUseProfileButton();
       // fUseProfileButton.doFillIntoGrid(fComposite, nColumns);      
	}

	/*
	 * @see ILaunchConfigurationTab#setDefaults(ILaunchConfigurationWorkingCopy)
	 */
	public void setDefaults(ILaunchConfigurationWorkingCopy config) {	
		config.setAttribute(USE_PROCESS_LIST,true);
		config.setAttribute(USE_PROFILE, true);	
		config.setAttribute(KEY, -1); //make sure previous key is removed	
	}

	/*
	 * @see ILaunchConfigurationTab#initializeFrom(ILaunchConfiguration)
	 */
	public void initializeFrom(ILaunchConfiguration config) {
		try{
			if(config.getAttribute(USE_PROCESS_LIST, true))
			{
				fUseProcessListButton.setSelection(true);
				fEnterPIDButton.setSelection(false);
			}
			else 
			{	
				fEnterPIDButton.setSelection(true);
				fUseProcessListButton.setSelection(false);
			}		
			fProjectField.setText(config.getAttribute(PROJECT,""));
			//fUseProfileButton.setSelection(config.getAttribute(USE_PROFILE, true));
		}catch(CoreException e){
			PICLUtils.logError(e);
		}
		
		//If the user clicks between process tabs, the "details" need to be cleaned up		
		
        fPIDText.setText("");
        fColumnDetails=null;
        fProcess=null;
        fSelectionGroupLabel.setText(PICLUtils.getResourceString(TAB_NAME+".noSelection")+"\n\n\n"); 
        
	}

	/*
	 * @see ILaunchConfigurationTab#dispose()
	 */
	public void dispose() {
		 //we must close it if not in use
		try{
			if(fDebugTarget != null
				&& !fDebugTarget.getDebugEngine().hasBeenInitialized()
				&& fDebugTarget.canTerminate())
					fDebugTarget.terminate();
		}catch(DebugException e) {}
	}

	/*
	 * @see ILaunchConfigurationTab#performApply(ILaunchConfigurationWorkingCopy)
	 */
	public void performApply(ILaunchConfigurationWorkingCopy config) {
		int key = -1;
		try{
			//note: performApply may be called more than once, so be careful to not repeat
			//key generation, target storage, etc.
			if((key=config.getAttribute(KEY, -1)) == -1)
			{
				key = CoreDaemon.generateKey();
				config.setAttribute(KEY, key);
			}
			config.setAttribute(USE_PROCESS_LIST, fUseProcessListButton.isSelected());
			//if we have a debug target and it hasn't been stored yet, then store it
			if(fDebugTarget != null)//&& CoreDaemon.retrieveDebugTarget(key) == null)
				CoreDaemon.storeDebugTarget(fDebugTarget, key);
			if(fUseProcessListButton.isSelected())	
			{
				ObjectStorageForConfigurations.storeProcess(key, getSystemProcess());			
				config.setAttribute(PID, ""); //remove old PID,if any
			}
			else	
				config.setAttribute(PID, fPIDText.getText().trim());
				
			//config.setAttribute(USE_PROFILE, fUseProfileButton.isSelected());
			config.setAttribute(PROJECT, fProjectField.getText());
			if(CoreDaemon.startListening() == false)  //daemon failed to start
			{
				fErrorMessage=PICLUtils.getResourceString(TAB_NAME+".daemonFailedToStartError");			
			}			
			
		}catch(CoreException e){PICLUtils.logError(e);}
	}
	
	/*
	 * @see ILaunchConfigurationTab#getErrorMessage()
	 */
	public String getErrorMessage() {
		return fErrorMessage;
	}

	
	/*
	 * @see ILaunchConfigurationTab#isValid()
	 */
	public boolean isValid() {
		
		if(fUseProcessListButton.isSelected())
        {
        	if(fProcess != null)
        		fErrorMessage=null;        		
        	else
        	{
        		fErrorMessage =  PICLUtils.getResourceString(TAB_NAME +".processNotSelectedError");
        		return false;	
        	}
        }
        else
        {  //PID selected 
        	if(fPIDText.getText().equals(""))
        	{
        		fErrorMessage = PICLUtils.getResourceString(TAB_NAME +".pidFormatError");
        		return false;
        	}else  //PID non-null
        	{	try{
        			if(!(Integer.parseInt(fPIDText.getText().trim()) > 0))
	        		{		
    	    			fErrorMessage = PICLUtils.getResourceString(TAB_NAME +".pidFormatError");
        				return false;
        			}
	        	}catch(Exception e){ 
    	    		fErrorMessage = PICLUtils.getResourceString(TAB_NAME +".pidFormatError");        		
        			return false;
	        	}
    	    	fErrorMessage=null;        	         
        	}
        }
        
        if( !getProject().equals("")) 
		{
		 	if(!projectExists(getProject()) )
			{
				fErrorMessage = PICLUtils.getResourceString(TAB_NAME +".projectDoesNotExistError");
				return false;
			}
			else fErrorMessage=null;
		}else fErrorMessage = null;
       
       return true;
       
	}

	/*
	 * @see ILaunchConfigurationTab#launched(ILaunch)
	 */
	public void launched(ILaunch launch) {
		
	}
	
	protected void createUseProcessListButton() {
        fUseProcessListButton = new SelectionButtonDialogField(SWT.RADIO|SWT.LEFT);                
        fUseProcessListButton.setLabelText(PICLUtils.getResourceString(TAB_NAME+".useProcessListLabel"));
        fUseProcessListButton.setDialogFieldListener(this);                
    }

    protected void createGetProcessListButton(Composite parent) {
        fGetProcessListButton = new Button(parent, SWT.PUSH);
        fGetProcessListButton.setText(PICLUtils.getResourceString(TAB_NAME+".getProcessListLabel"));
        fGetProcessListButton.addSelectionListener(new SelectionListener() {
            public void widgetDefaultSelected(SelectionEvent e) {
                changeControlPressed(e.getSource());
            }
            public void widgetSelected(SelectionEvent e) {
                changeControlPressed(e.getSource());
            }
        });
    }

    protected void createSelectionGroup(Composite parent) {
    	
        MGridLayout layout = new MGridLayout();
        layout.numColumns = 2;

        fSelectionGroup = new Group(parent, SWT.SHADOW_IN);
        fSelectionGroup.setText(PICLUtils.getResourceString(TAB_NAME+".selectionGroupLabel"));
        fSelectionGroup.setLayout(layout);

        fSelectionGroupLabel = new Label(fSelectionGroup, SWT.WRAP | SWT.LEFT);
        fSelectionGroupLabel.setText(PICLUtils.getResourceString(TAB_NAME+".noSelection")+"\n\n\n");        
        MGridData gridData = new MGridData();
        gridData.horizontalAlignment = gridData.FILL;
        gridData.grabExcessHorizontalSpace = true;
        gridData.horizontalSpan = 2;            
        fSelectionGroupLabel.setLayoutData(gridData);
    }
   

    protected void updateSelectionGroup() {
        getControl().setRedraw(false);

        String[] processDetails = fProcess.getProcessDetails();
        String text = "";
        int i;
        for(i = 0; i < (fColumnDetails.length - 1); i++) {
            text = text + fColumnDetails[i].getColumnName() + ": " + processDetails[i] + "\n";
        }
        text = text + fColumnDetails[i].getColumnName() + ": " + processDetails[i];
        fSelectionGroupLabel.setText(text);

        fSelectionGroup.layout();
        fSelectionGroup.redraw();
        getControl().redraw();
        getControl().update();
        //fComposite.layout();
        getControl().setRedraw(true);
    }

    protected void createEnterPIDButton() {
        fEnterPIDButton = new SelectionButtonDialogField(SWT.RADIO|SWT.LEFT);
        fEnterPIDButton.setLabelText(PICLUtils.getResourceString(TAB_NAME+".enterPIDLabel"));
        fEnterPIDButton.setDialogFieldListener(this);
    }

    protected void createPIDText(Composite parent) {
        fPIDText = new Text(parent, SWT.SINGLE | SWT.BORDER);
        fPIDText.setText("");
        fPIDText.addModifyListener(this);
    }

/*    protected void createUseProfileButton() {
      //  fUseProfileButton = new SelectionButtonDialogField(SWT.CHECK | SWT.LEFT);
       // fUseProfileButton.setLabelText(PICLUtils.getResourceString(TAB_NAME + ".profileButtonLabel"));
    }*/
    
    public void dialogFieldChanged(DialogField field) {
        if(field == fUseProcessListButton) {
            if(fUseProcessListButton.isSelected()) {
                fPIDText.setEnabled(false);
                fSelectionGroup.setEnabled(true);
                fSelectionGroupLabel.setEnabled(true);
                fGetProcessListButton.setEnabled(true);
                fGetProcessListButton.setFocus();  
                updateLaunchConfigurationDialog();  //update error msg         
            }
        } else if(field == fEnterPIDButton) {
            if(fEnterPIDButton.isSelected()) {
                fGetProcessListButton.setEnabled(false);
                fSelectionGroup.setEnabled(false);
                fSelectionGroupLabel.setEnabled(false);
                fPIDText.setEnabled(true);
                fPIDText.setFocus();       
                updateLaunchConfigurationDialog(); //update error msg        
            }
        }else if(field == fProjectField){
        	updateLaunchConfigurationDialog(); //update error msg
        }
    }
    
    /**
     * @see ModifyListener#modifyText
     */
    public void modifyText(ModifyEvent e) {
        if (e.getSource() == fPIDText)
        	updateLaunchConfigurationDialog();
    }    

    
    /** 
     *  The get process list button was pressed.
     */
    public void changeControlPressed(Object source) {
        if(source == fGetProcessListButton) {
            ProcessSelectionDialog dialog = new ProcessSelectionDialog(getShell(), this);
            int res = dialog.open();
            if(res == dialog.OK) {
                SystemProcess process = dialog.getSelectedProcess();
                if(process != null) {
                    fProcess = process;
                    fColumnDetails = dialog.getProcessListColumnDetails();
                    updateSelectionGroup();
                    updateLaunchConfigurationDialog();
                }
            }
        }
    }

    /**
     * Check which type of process information is available, a process id
     * or a SystemProcess object.
     * @return true if process id, false if SystemProcess object
     */
    public boolean haveProcessID() {
        return(fEnterPIDButton.isSelected());
    }

    /**
     * Get the process id.
     * @return The process id.
     */
    public String getProcessID() {
        return fPIDText.getText();
    }

    /**
     * Get the SystemProcess object.
     * @return The system process object.
     */
    public SystemProcess getSystemProcess() {
        return fProcess;
    }

    /**
     * Get the use profile setting.
     * @return Returns the use profile setting.
     */
    /*public boolean useProfile() {
        return fUseProfileButton.isSelected();
    }*/
   
	/**
	 * @see IProcessListSupplier#getProcessList()
	 */
	public Vector getProcessList() {
		return getDebugTarget().getProcessList();
    }
    
    private PICLDebugTarget getDebugTarget() {
        if(fDebugTarget == null)
            fDebugTarget = new PICLDebugTarget();

        return fDebugTarget;
    }

	/**
     * @see IProcessListSupplier#getProcessListColumnDetails
     */
    public ProcessListColumnDetails[] getProcessListColumnDetails() {
        return getDebugTarget().getProcessListColumnDetails();
    }

   /**
     * Get the program parameters as entered in the wizard by the user.
     * @return Returns the program parameters.
     */
    public String getProject() {
        return fProjectField.getText().trim();
    }
    
    /**
	 * Returns the WorkspaceRoot
	 */
	public IWorkspaceRoot getWorkspaceRoot() {
		return ResourcesPlugin.getWorkspace().getRoot();		
	}

	
	/**
     * Browse button was pressed.
     * @see IStringButtonAdapter
     */
    public void changeControlPressed(DialogField field) {
       if (field == fProjectField)
		{
			IProject fSelectedProject = chooseProject();
			if (fSelectedProject!=null && fSelectedProject.getName()!=null)
				fProjectField.setText(fSelectedProject.getName());
		}
    }

	private IProject chooseProject() {
		ILabelProvider labelProvider = new WorkbenchLabelProvider();
		BasicContainerContentProvider contentProvider =
			new BasicContainerContentProvider();
		ElementTreeSelectionDialog dialog =
			new ElementTreeSelectionDialog(
				getShell(),
				PICLUtils.getResourceString("ElementTreeSelectionDialog.title"),
				labelProvider,
				contentProvider,
				false,
				true);

		dialog.setMessage(
			PICLUtils.getResourceString("ElementTreeSelectionDialog.description"));

		if (dialog.open(getWorkspaceRoot()) == dialog.OK) {
			Object element = dialog.getPrimaryResult();
			if (element instanceof IProject) {
				return (IProject) element;
			}
		}
		return null;
	}    
    private boolean projectExists(String projectName)
	{
		IProject projects[] = ResourcesPlugin.getWorkspace().getRoot().getProjects();
		for (int i = 0; i < projects.length; i++) {
			if(projects[i].getName().equals(projectName))
				return true;
		}
		return false;
	}
    
       

}
