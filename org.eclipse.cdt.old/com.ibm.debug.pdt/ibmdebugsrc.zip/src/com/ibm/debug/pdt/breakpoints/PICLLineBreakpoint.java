package com.ibm.debug.pdt.breakpoints;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.debug.core.model.ILineBreakpoint;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLUtils;

public class PICLLineBreakpoint extends PICLLocationBreakpoint implements ILineBreakpoint {

    /**
     * Constructor for PICLLineBreakpoint.
     */
    public PICLLineBreakpoint() {
        super();
    }



	/**
	 * Construct a PICL line breakpoint 
	 * @param resource to add the breakpoint to
	 * @param lineNumber in the resource 
	 */
	public PICLLineBreakpoint(IResource resource, int lineNumber) {
		this(resource, null, lineNumber, -1, -1);
	}

	/**
	 * Construct a PICL line Breakpoint
	 * @param resource to add the breakpoint to
	 * @param fileName of the source file 
	 * @param lineNumber in the source file
	 */
	public PICLLineBreakpoint(IResource resource, String fileName, int lineNumber) {
		this(resource, fileName, lineNumber, -1, -1);
	}

	/**
	 * Construct a PICL line breakpoint
	 * @param resource to add the breakpoint to
	 * @param lineNumber in the resource
	 * @param charStart in the line
	 * @param charEnd in the line
	 */
	public PICLLineBreakpoint(final IResource resource,
								final String fileName,
								final int lineNumber,
								final int charStart,
								final int charEnd) {
		IWorkspaceRunnable body = new IWorkspaceRunnable() {
			public void run(IProgressMonitor monitor) throws CoreException {
				try {
					IMarker breakpointmarker =
						resource.createMarker(IPICLDebugConstants.PICL_LINE_BREAKPOINT);
					breakpointmarker.setAttributes(
						new String[] {
							IBreakpoint.ID,
							IBreakpoint.ENABLED,
							IMarker.LINE_NUMBER,
							IMarker.CHAR_START,
							IMarker.CHAR_END },
						new Object[] {
							PICLUtils.getModelIdentifier(),
							new Boolean(true),
							new Integer(lineNumber),
							new Integer(charStart),
							new Integer(charEnd)});

					if (fileName != null)
						breakpointmarker.setAttribute(IPICLDebugConstants.SOURCE_FILE_NAME,
													  fileName);
													  
					setMarker(breakpointmarker);
					registerBreakpoint();
				} catch (CoreException ce) {
				}
			}
		};
		try {
			ResourcesPlugin.getWorkspace().run(body, null);
		} catch (CoreException ce) {
		}
	}


	/*
	 * @see ILineBreakpoint#getCharEnd()
	 */
	public int getCharEnd() throws CoreException {
		return -1;
	}

	/*
	 * @see ILineBreakpoint#getCharStart()
	 */
	public int getCharStart() throws CoreException {
		return -1;
	}

	/*
	 * @see ILineBreakpoint#getLineNumber()
	 */
	public int getLineNumber() throws CoreException {
		return ((Integer)getMarker().getAttribute(IMarker.LINE_NUMBER)).intValue();
	}

	/**
	 * Get the file name associated with this line breakpoint
	 * @return String file name.
	 * @throws CoreException
	 */
	public String getFileName() throws CoreException {
		IResource resource = getMarker().getResource();
		String fileName = "N/A";
		if (resource instanceof IFile) {
			fileName = resource.getLocation().lastSegment();
		} else {	
			fileName = getMarker().getAttribute(IPICLDebugConstants.SOURCE_FILE_NAME, "N/A");
		}
		return fileName;
	}

}

