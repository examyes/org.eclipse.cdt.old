package com.ibm.debug.pdt.launchconfig;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

import java.util.Hashtable;

import org.eclipse.core.resources.IProject;

import com.ibm.debug.internal.pdt.model.DebugEngine;
import com.ibm.debug.internal.pdt.model.SystemProcess;

public class ObjectStorageForConfigurations {
	private static Hashtable processHashtable = new Hashtable();	
	
	/**
  	 * Can be used to retrieve a system process.
  	 * Process will be removed from the hashtable after it is retrieved.
  	 * @param key The key used to identify this connection.
  	 * @see CoreDaemon.generateKey()
  	 */
  	public static SystemProcess getProcess(int key)
  	{
  		if(processHashtable == null)
  			processHashtable = new Hashtable();
  		SystemProcess process = (SystemProcess) processHashtable.get(new Integer(key));
  		processHashtable.remove(new Integer(key));
  		return process;
  	}
  	/**
  	 * Can be used to store system process for picking up later.
  	 * Used when a user has picked a process from the list using the attach launch
  	 * configuration.
  	 * @param key The key used to identify this connection.
  	 * @see CoreDaemon.generateKey()
  	 */
  	public static void storeProcess(int key, SystemProcess process)
  	{	
  		if(processHashtable == null)
  			processHashtable = new Hashtable();
  		try{
			processHashtable.put(new Integer(key), process );
  		}catch(Exception e){}
  	}
  	
  	public static void clearProcessHashtable()
  	{
  		if(processHashtable == null)
  			processHashtable = new Hashtable();
  		processHashtable.clear();
  	}
  	
  	
  	
  	
}
