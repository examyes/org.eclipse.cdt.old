package com.ibm.debug.pdt.launchconfig;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////



import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.core.model.ILaunchConfigurationDelegate;

import com.ibm.debug.daemon.CoreDaemon;
import com.ibm.debug.daemon.CoreDaemon.OldDaemonInput;
import com.ibm.debug.internal.pdt.OldEngineParameters;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.SystemProcess;
import com.ibm.debug.internal.pdt.ui.util.StatusInfo;
import com.ibm.debug.pdt.WorkspaceSourceLocator;
import com.ibm.debug.pdt.launch.PICLAttachInfo;

/**
 * @version 	1.0
 * @author
 */
public class PICLAttachLaunchConfigurationDelegate
	implements ILaunchConfigurationDelegate, IConfigurationConstants {
		
	protected static final String DIALOG = "PICLAttachWizard";  //todo - rename
	
	
	
	//key will be used to store project and system process
	private PICLAttachInfo createAttachInfo(ILaunchConfiguration config)
	{
		PICLAttachInfo attachInfo = new PICLAttachInfo();

        
        attachInfo.setLaunchConfig(config);
        try{
        	attachInfo.setProject(getProjectResource(config.getAttribute(PROJECT,"")));
      		if(!config.getAttribute(USE_PROCESS_LIST, false)) 
	        {  //use PID instead
    	        String processIDText = config.getAttribute(PID, (String)null);
        	    if(processIDText == null)
            		return null;  //todo - error message - PID not set
	            int processID = -1;
    	        try {
        	        processID = Integer.parseInt(processIDText);
	            } catch(NumberFormatException e) {
    	            StatusInfo status = new StatusInfo();
        	        status.setError(PICLUtils.getResourceString(DIALOG+".pidMustBeIntError"));	             
        	        return null;
	            }
    	        attachInfo.setProcessID(processIDText);
        	} else {	          
    	       int key=config.getAttribute(IConfigurationConstants.KEY, -1);
        	   if(key > 0)
        	   {
        	   	   SystemProcess process;
				   if( (process = ObjectStorageForConfigurations.getProcess(key)) !=null)
		        	   	attachInfo.setProcess(process);
		           else //probable cause - relaunching an old configuration
		           		PICLUtils.logText("Process is null - error occurred"); //todo error dialog!	           		           
        	   }
		       //todo else error!
        	}

	        attachInfo.setProcessPath(config.getAttribute(PROCESS_PATH,""));
    	           
        	WorkspaceSourceLocator sourceLocator = new WorkspaceSourceLocator();
        	if(attachInfo.getProject()!= null && !attachInfo.getProject().equals(""))
	        	sourceLocator.setHomeProject(attachInfo.getProject());
			attachInfo.setWorkspaceSourceLocator(sourceLocator);                  	    
        	sourceLocator.setSearchPath(config.getAttribute(SOURCE_PATH,""));
        
        }catch(CoreException e){PICLUtils.logError(e);}
        attachInfo.setStartupBehaviour(attachInfo.STOP);       
        
        return attachInfo;
	}
	
	/**
	 * Convenience method to get the launch manager.
	 * 
	 * @return the launch manager
	 */
	private ILaunchManager getLaunchManager() {
		return DebugPlugin.getDefault().getLaunchManager();
	}
	
	/**
	 * Returns the WorkspaceRoot
	 */
	public IWorkspaceRoot getWorkspaceRoot() {
		return ResourcesPlugin.getWorkspace().getRoot();
	}

	private IProject getProjectResource(String projectName)
	{
		IProject projects[] = getWorkspaceRoot().getProjects();
		for (int i = 0; i < projects.length; i++) {
			if(projects[i].getName().equals(projectName))
				return projects[i];
		}
		return null;
	}
	

	/**
	 * @see ILaunchConfigurationDelegate#launch(ILaunchConfiguration, String, ILaunch, IProgressMonitor)
	 */
	public void launch(
		ILaunchConfiguration config,
		String mode,
		ILaunch launch,
		IProgressMonitor monitor)
		throws CoreException {
			
			PICLUtils.logText("Got to the PICL attach launch configuration delegate");
		if(!(config.getType().supportsMode(mode)))
			return;
		
		if(config.getAttribute(DAEMON, false)) //daemon, not dialog
		{
			int key = config.getAttribute(KEY,-99999);
			if(key == -99999)
				return;  //something went wrong, todo error message
			OldDaemonInput input = CoreDaemon.retrieveOldDaemonInput(key);
			if(input == null)
				return;//something went wrong, todo error message
			OldEngineParameters engineParameters = new OldEngineParameters();
			//get StringArray from Daemon storage		
    		engineParameters.setInfo(input.getInputArray());   			   
    		//todo - decide if we want socket info inside connection info 		    		
    		engineParameters.getConnectionInfo().setConnection(input.getSocket());
    		
			PICLAttachInfo attachInfo = null;
   		 	
        	attachInfo = new PICLAttachInfo();
			attachInfo.setLaunchConfig(config);   
        	attachInfo.setWorkspaceSourceLocator(new WorkspaceSourceLocator());  
        	if(engineParameters.getProcessID() != null)
        		attachInfo.setProcessID(engineParameters.getProcessID());        		
        		
			if( engineParameters.getConnectionInfo() !=null)
        	{
        		attachInfo.setEngineConnectionInfo(engineParameters.getConnectionInfo());        
        		attachInfo.setEngineWaiting(true);
        	}
        	else attachInfo.setEngineWaiting(false);
        	
        	attachInfo.setStartupBehaviour(engineParameters.getAttachStartupBehaviour());     
			//todo source search path        	        	     	   	
        	     	
        	 PICLDebugTarget target = new PICLDebugTarget(launch, attachInfo, attachInfo.getEngineConnectionInfo());
        	 launch.addDebugTarget(target);
        	 launch.setSourceLocator(attachInfo.getWorkspaceSourceLocator());
        	 target.attachToProcess(attachInfo);       
		}else //dialog was used
		{
			int key;
			boolean keyFound = false;  //is there an engine waiting??
			PICLAttachInfo attachInfo = createAttachInfo(config);			
			//use key if configuration has one, else generate one
			if( (key = config.getAttribute(KEY, -1)) == -1)
			{   
				keyFound = true;
				key = CoreDaemon.generateKey();
			}
			else //remove key so it doesn't get reused next 
			{
				try{
					ILaunchConfigurationWorkingCopy configCopy = config.getWorkingCopy();
					configCopy.setAttribute(KEY, -1);  
					configCopy.doSave();
				}catch(CoreException e){}
			}
			
			if(attachInfo == null)
			{
				PICLUtils.logText("Startup info is null - error occurred");
				return;
			}
			PICLUtils.logText("Startup Info created OK");
			attachInfo.setKey(key);
						
			PICLDebugTarget target;
			if(!keyFound || (target = (PICLDebugTarget)CoreDaemon.retrieveDebugTarget(key)) == null)
			{
				target = new PICLDebugTarget(launch, attachInfo,attachInfo.getEngineConnectionInfo()); //connection info can't be null
    			CoreDaemon.storeDebugTarget(target, key);      			
			}
			else //reuse engine that provided the process list
				target.setStartupInfo(attachInfo);  //apply new startup info
			launch.addDebugTarget(target);
			launch.setSourceLocator(attachInfo.getWorkspaceSourceLocator());
    		target.launchEngine(key);    	
			
		}		
	}

}
