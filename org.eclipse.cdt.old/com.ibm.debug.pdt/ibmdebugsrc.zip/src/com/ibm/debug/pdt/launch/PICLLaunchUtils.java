package com.ibm.debug.pdt.launch;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

 
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.IDebugTarget;

import com.ibm.debug.internal.pdt.PICLDebugTarget;

/**
 * This will create a PICLDebugTarget
 */
public class PICLLaunchUtils {
	
	/**
	 * Create a PICL debug target
	 * @param launch associated with this debug target
	 * @param startUpInfo
	 * @return IDebugTarget
	 */
	public static IDebugTarget getDebugTarget(ILaunch launch, PICLStartupInfo startUpInfo) {
		return new PICLDebugTarget(launch, startUpInfo, null);
	}

}
