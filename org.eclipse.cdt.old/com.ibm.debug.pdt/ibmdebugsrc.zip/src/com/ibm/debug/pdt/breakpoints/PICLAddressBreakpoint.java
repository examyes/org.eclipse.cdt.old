package com.ibm.debug.pdt.breakpoints;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.model.IBreakpoint;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLUtils;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


public class PICLAddressBreakpoint extends PICLLocationBreakpoint {


    /**
     * Constructor for PICLAddressBreakpoint.
     */
	public PICLAddressBreakpoint () {
		super();
	}

	/**
	 * Construct a PICL address breakpoint
	 * @param resource to add the breakpoint to
	 * @param fileName source file name
	 * @param lineNumber in the resource
	 * @param address to add the breakpoint
	 */
	public PICLAddressBreakpoint(final IResource resource,
								final String fileName,
								final int lineNumber,
								final String address) {
		
		// the following code is required to make the operations atomic
		// i.e. all of the below will occur as a unit 
		IWorkspaceRunnable body = new IWorkspaceRunnable() {
			public void run(IProgressMonitor monitor) throws CoreException {
				try {
					IMarker breakpointmarker =
						resource.createMarker(IPICLDebugConstants.PICL_ADDRESS_BREAKPOINT);
					breakpointmarker.setAttributes(
						new String[] {
							IBreakpoint.ID,
							IBreakpoint.ENABLED,
							IMarker.LINE_NUMBER,
							IPICLDebugConstants.EDITABLE,
							IPICLDebugConstants.ADDRESS_EXPRESSION,
							IPICLDebugConstants.SOURCE_FILE_NAME },
						new Object[] {
							PICLUtils.getModelIdentifier(),
							new Boolean(true),
							new Integer(lineNumber),
							new Boolean(true),
							address,
							fileName});

													  
					setMarker(breakpointmarker);
					registerBreakpoint();
				} catch (CoreException ce) {
				}
			}
		};
		try {
			ResourcesPlugin.getWorkspace().run(body, null);
		} catch (CoreException ce) {
		}
	}

	/**
	 * Returns the address associated with this breakpoint
	 * @return String address
	 * @throws CoreException
	 */
	public String getAddress() throws CoreException {
		String address = getMarker().getAttribute(IPICLDebugConstants.ADDRESS_EXPRESSION, "N/A");
		return address;
	}


}

