package com.ibm.debug.pdt.launchconfig;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////



import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.ui.AbstractLaunchConfigurationTab;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;

import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.ui.util.MGridLayout;
import com.ibm.debug.internal.pdt.ui.util.Separator;
import com.ibm.debug.internal.pdt.ui.util.StringDialogField;

/**
 * @version 	1.0
 * @author
 */
public class PICLAttachAdvancedTab extends AbstractLaunchConfigurationTab implements IConfigurationConstants {

private static final String PAGE_NAME = "PICLAttachLaunchConfigTab2";        

    private StringDialogField fSourceSearchField;
    private StringDialogField fProcessPathField;
    
    /**
	 * @see ILaunchConfigurationTab#getName()
	 */
	public String getName() {
		return PICLUtils.getResourceString(PAGE_NAME + ".name");
	}

	/*
	 * @see ILaunchConfigurationTab#okToLeave()
	 * Always return true - all fields are optional or have defaults
	 */
	public boolean okToLeave() {
		return true;
	}

	/*
	 * @see ILaunchConfigurationTab#createControl(Composite)
	 */
	public void createControl(Composite parent) {
		createFields();

        Composite fComposite = new Composite(parent, SWT.NONE);
        setControl(fComposite);
        int nColumns= 1;

        MGridLayout layout = new MGridLayout();
        layout.marginWidth = 0;
        layout.marginHeight = 20;
        layout.minimumWidth = 400;
        layout.minimumHeight = 200;
        layout.numColumns = nColumns;

        fComposite.setLayout(layout);
                    
        fSourceSearchField.doFillIntoGrid(fComposite, nColumns);                
        new Separator().doFillIntoGrid(fComposite, nColumns, 8);
        fProcessPathField.doFillIntoGrid(fComposite, nColumns);                     
	}

	/*
	 * @see ILaunchConfigurationTab#setDefaults(ILaunchConfigurationWorkingCopy)
	 */
	public void setDefaults(ILaunchConfigurationWorkingCopy config) {
		config.setAttribute(SOURCE_PATH,"");
		config.setAttribute(PROCESS_PATH,"");
	}

	/*
	 * @see ILaunchConfigurationTab#initializeFrom(ILaunchConfiguration)
	 */
	public void initializeFrom(ILaunchConfiguration config) {
		try{
			fSourceSearchField.setText(config.getAttribute(SOURCE_PATH,""));
			fProcessPathField.setText(config.getAttribute(PROCESS_PATH,""));
		}catch(Exception e){PICLUtils.logError(e);}
	}

	/*
	 * @see ILaunchConfigurationTab#dispose()
	 */
	public void dispose() {		
	}

	/*
	 * @see ILaunchConfigurationTab#performApply(ILaunchConfigurationWorkingCopy)
	 */
	public void performApply(ILaunchConfigurationWorkingCopy config) {
		config.setAttribute(SOURCE_PATH, fSourceSearchField.getText().trim());
		config.setAttribute(PROCESS_PATH, fProcessPathField.getText().trim());
		
	}

	/*
	 * @see ILaunchConfigurationTab#getErrorMessage()
	 */
	public String getErrorMessage() {
		return null;
	}

	/*
	 * @see ILaunchConfigurationTab#getMessage()
	 */
	public String getMessage() {
		return null;
	}

	/*
	 * @see ILaunchConfigurationTab#isValid()
	 */
	public boolean isValid() {
		return true;
	}

	/*
	 * @see ILaunchConfigurationTab#launched(ILaunch)
	 */
	public void launched(ILaunch launch) {
	}
	
	public String getSourceSearchPath() {
        return fSourceSearchField.getText();
    }

    public String getProcessPath() {
        return fProcessPathField.getText();
    }  
    
    protected void createFields() {
        fSourceSearchField = new StringDialogField(false);                
        fSourceSearchField.setLabelText(PICLUtils.getResourceString(PAGE_NAME + ".sourceSearchLabel"));

        fProcessPathField = new StringDialogField(false);                
        fProcessPathField.setLabelText(PICLUtils.getResourceString(PAGE_NAME + ".processPathLabel"));
    }
    
     

}
