package com.ibm.debug.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import org.eclipse.debug.core.DebugException;

/**
 * Interface for extended debug stepping actions
 * This covers stepping function that is not included in the core
 */

public interface IStepExtended {
	
	
	/**
	 * Returns whether or not step debug is supported.
	 * @return boolean
	 */
	public boolean canStepDebug();
	
	/**
	 * Step into if the entered function has debug information otherwise step
	 * over known as "shallow" step debug.
	 * Some engines support "deep" step debug which means they will continue to 
	 * step into until a function is found that has debug information.
	 * @exception DebugException on failure. 
	 */
	public void stepDebug() throws DebugException;
		
}
