package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.debug.ui.IDebugModelPresentation;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.PICLUtils;

/**
 * An action that toggles the state of a viewer to
 * show/hide type names of variables.
 * Only viewers that use a <code>VariableLabelProvider</code> to render its
 * elements are effected.
 */
public class ShowTypeInfoAction extends Action {
	protected static final String PREFIX= "ShowTypeInfoAction.";
	protected StructuredViewer fViewer;

	public ShowTypeInfoAction(StructuredViewer viewer) {
		super(PICLUtils.getResourceString(PREFIX+"label"));
		fViewer= viewer;
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip.show"));
//		WorkbenchHelp.setHelp(this, new Object[] { PICLUtils.getHelpResourceString("ShowTypeInfoAction") });
	}

	/**
	 * @see Action#run()
	 */
	public void run() {
		valueChanged(isChecked());
	}

	private void valueChanged(boolean on) {
		if (fViewer.getControl().isDisposed()) {
			return;
		}
		ILabelProvider labelProvider= (ILabelProvider)fViewer.getLabelProvider();
		if (labelProvider instanceof IDebugModelPresentation) {
			IDebugModelPresentation debugLabelProvider= (IDebugModelPresentation)labelProvider;
			debugLabelProvider.setAttribute(IDebugModelPresentation.DISPLAY_VARIABLE_TYPE_NAMES, (on ? Boolean.TRUE : Boolean.FALSE));			
			BusyIndicator.showWhile(fViewer.getControl().getDisplay(), new Runnable() {
				public void run() {
					fViewer.refresh();					
				}
			});
		}
//		setText(on ? PICLUtils.getResourceString(PREFIX+"label.enable") : PICLUtils.getResourceString(PREFIX+"label.disable"));
		setToolTipText(on ? PICLUtils.getResourceString(PREFIX+"tooltip.hide") : PICLUtils.getResourceString(PREFIX+"tooltip.show"));
	}

	/**
	 * @see Action#setChecked(boolean)
	 */
	public void setChecked(boolean value) {
		super.setChecked(value);
		valueChanged(value);
	}
}


