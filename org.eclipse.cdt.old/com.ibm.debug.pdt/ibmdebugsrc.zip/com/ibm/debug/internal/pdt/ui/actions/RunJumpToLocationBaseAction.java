package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.source.IVerticalRuler;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.texteditor.ITextEditor;

import com.ibm.debug.internal.pdt.EngineSuppliedViewEditorInput;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLThread;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.pdt.PICLDebugPlugin;

// This editor actions handles RunToLocationAction, RunToLocationRulerAction,
// JumpToLocationAction and JumpToLocationRulerAction functions, since they are 
// all very similar.  Behaviour is dictated by the constructor parameters

public class RunJumpToLocationBaseAction extends Action implements ISelectionListener {
			
	protected final static String PREFIX= "RunJumpToLocationBaseAction.";
	private ITextEditor editor = null;
	private IVerticalRuler ruler = null;

	// isRulerAction : true = vertical ruler menu action; false = context menu action
	protected boolean isRulerAction = false;
	// isJumpAction : true = Jump To Location action; false = Run To Location action
	protected boolean isJumpAction = false;

	/**
	 * Constructor for RunToLocationAction
	 *  setAsRulerAction : true = vertical ruler menu action; false = context menu action
	 *  setAsJumpAction : true = Jump To Location action; false = Run To Location action
	 */
	public RunJumpToLocationBaseAction(ITextEditor textEditor, IVerticalRuler verticalRuler, boolean setAsRulerAction, boolean setAsJumpAction) {
		super();
		editor = textEditor;
		ruler = verticalRuler;
		isJumpAction = setAsJumpAction;
		isRulerAction = setAsRulerAction;
		
		if (isJumpAction) {
			setText(PICLUtils.getResourceString(PREFIX+"jumpaction"));
		} else { 
			setText(PICLUtils.getResourceString(PREFIX+"runaction"));
		}
		
		// Get hooked into DebugView
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().addSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
	}


	/*
	 * @see IAction#run()
	 */
	public void run() {
		int line = 0;
		IResource resource = null;
		IMarker locationMarker = null;
		String filename = null;

		if (editor == null) {
			PICLUtils.logText("RunJumpToLocationBaseAction: editor is null, failing");
			return;
		}

		if (isRulerAction) {
			if (ruler == null) {
				PICLUtils.logText("RunJumpToLocationBaseAction: ruler is null, failing");
				return;
			} 
			line = ruler.getLineOfLastMouseButtonActivity() + 1;
		} else { // Must be context menu action
			ITextSelection textSelection = (ITextSelection) editor.getSelectionProvider().getSelection();
			line = textSelection.getStartLine() + 1;
		}

		IEditorInput input = editor.getEditorInput();
		if (input instanceof IFileEditorInput)
			resource = ((IFileEditorInput)input).getFile();
		else if (input instanceof EngineSuppliedViewEditorInput) {
			EngineSuppliedViewEditorInput viewEI = (EngineSuppliedViewEditorInput) input;
			resource = viewEI.getResource();
			filename = viewEI.getName();	// Store source file name in breakpoint so we don't lose it
		}
		if (resource == null) {
			PICLUtils.logText("no resource for run/jump - not good.");
			return;
		}
		try {
			locationMarker = resource.createMarker(IPICLDebugConstants.PICL_LOCATION_MARKER);
			locationMarker.setAttribute(IMarker.LINE_NUMBER, line);
			if (filename != null) {
				String[] attributeNames = {IPICLDebugConstants.SOURCE_FILE_NAME};
				Object[] values = {filename};
				locationMarker.setAttributes(attributeNames, values);
			}
		} catch(CoreException ce) {
			return;
		}

		IDebugTarget target = PICLDebugPlugin.determineCurrentDebugTarget();
		if(target instanceof PICLDebugTarget)
		{
    		PICLDebugTarget PICLTarget = (PICLDebugTarget)target;
			PICLThread thread = PICLTarget.getStoppingThread();
		  	if (isJumpAction)
				thread.jumpToLocation(locationMarker);
			else
		  		thread.runToLocation(locationMarker);
	 	}
		else
			PICLUtils.logText("RunJumpToLocationBaseAction - bad target?? ");
	}

		/**
	 * @see ISelectionListener#selectionChanged(IWorkbenchPart, ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {

		Object element = null;
		boolean show = false;

		if (selection instanceof IStructuredSelection) {
			IStructuredSelection strSelection = (IStructuredSelection) selection;
			element = strSelection.getFirstElement();
		} else
		  element = selection;

		if (element instanceof PICLDebugElement) {
		 	// enable menu item
			show = true;
		} else if (element instanceof ILaunch) {
		 	IDebugTarget dt =((ILaunch) element).getDebugTarget();
			if (dt instanceof PICLDebugTarget)
				show = true;
		}
		setEnabled(show);
	}

}
