package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.util.*;

/** loads a named dll for subsequent invocation.
 * Usually, subclass with specific invocation methods (see ui\DllDrives)
 */
public class Dll extends Object
{
  private String  _name     = null;
  private boolean _isLoaded = false;

  public Dll()
  {
  }

  public boolean isLoaded()
  {
     return _isLoaded;
  }

  /** user application can clear if dll is not useable (method invocation failed, etc) */
  public void clearIsLoaded()
  {
     _isLoaded=false;
  }

  /** sets dll name and loads it */
  public boolean load(String prefix, String name)
  {
     setName(prefix, name);
     return load();
  }
  synchronized private boolean load()
  {
     _isLoaded = false;
     if(_name==null)
     {
        //System.out.println("Dll WARNING: Dll load failed since dll name is null");
        return false;
     }
     try
     {
        System.loadLibrary(_name);
        _isLoaded = true;
     }
     catch (UnsatisfiedLinkError e)
     {
        //System.out.println( "LoadLibraryError" +" - " +_name );
        TraceLogger tl = new TraceLogger("Util/Dll");
        if(tl.DBG)tl.dbg(2,
           "Dll " +_name +" loadLibrary UnsatisfiedLinkException" );
     }
     catch (SecurityException e)
     {
        //System.out.println( "SecurityError" +" - " +_name );
        TraceLogger tl = new TraceLogger("Util/Dll");
        if(tl.DBG)tl.dbg(2,
           "Dll " +_name +" loadLibrary SecurityException" );

     }
     return _isLoaded;
  }

  /** returns active name=prefix+filename+[.dll] */
  public String getName()
  {
     return _name;
  }
  private void setName(String prefix, String name)
  {
     //if( !prefix.toLowerCase().equals("der") )
     //   debugOutput( "Dll WARNING: Dll prefix notEqual 'der', is = " +prefix );
     _name = prefix + name;

     boolean _isWindows = System.getProperties().getProperty("os.name").startsWith("Windows"); // NT, 95 or 98
     if( !_isWindows )
        _name += ".dll";        // Windows wont find XXXX.dll

  }

}
