package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.PropertyDescriptor;

import com.ibm.debug.internal.pdt.model.Language;
import com.ibm.debug.internal.pdt.model.Part;
import com.ibm.debug.internal.pdt.model.View;
import com.ibm.debug.internal.pdt.model.ViewFile;

public class PICLPart extends PICLDebugElement 
						implements IPropertySource {

	private Part fPart = null;
	private boolean fFilesRetrieved = false;
	// list of attributes for display
	private static final String PREFIX = "picl_part.";
	private static final String PART_NAME = PREFIX + "part_name";
	private static final String DEBUG_INFO = PREFIX + "debug_info";
	private static final String LANGUAGE = PREFIX + "language";

	/**
	 * Constructor for PICLPart
	 */
	public PICLPart(IDebugElement parent, Part part, IDebugTarget debugTarget) {
		super(parent, debugTarget);
		fPart = part;
	}

	/**
	 * @see PICLDebugElement#doCleanupDetails()
	 */
	protected void doCleanupDetails() {
		fPart = null;
	}

	/**
	 * Removes this child from the collection of children for this element.
	 * Fires a termination event for the child.
	 * Cleanup depends on the order of operations in this method.
	 */
	public final void removeChild(IDebugElement child) {

		// first call the child to clean itself up and then remove it
		((PICLDebugElement)child).doCleanup();

		fChildren.remove(child);
	}

	/**
	 * @see PICLDebugElement#getLabel(boolean)
	 */
	public String getLabel(boolean qualified) {
		return fPart.name();
	}

	/**
	 * @see IDebugElement#getName()
	 */
	public String getName() throws DebugException {
		return fPart.name();
	}

	/**
	 * @see PICLDebugElement#hasChildren()
	 */
	public boolean hasChildren() {
		return true;
	}

	/**
	 * @see PICLDebugElement#getChildren()
	 */
	public IDebugElement[] getChildren() throws DebugException {
		if (fFilesRetrieved)
			return super.getChildren();
		else {
			// get the list of files
			// loop through all of the views and add the files as children
			View[] views = fPart.views();

			// determine if a source view exists.  If it doesn't then default to
			// the last view found.

			View defaultView = null;
			for (int i=0; i < views.length; i++) {
				if (views[i] == null)
					continue;
				defaultView = views[i];
				if (defaultView.isSourceView())
					break;
			}


			Vector viewFiles = null;
			try {
				viewFiles = defaultView.getFiles();
			} catch(IOException ioe) {}

			if (viewFiles != null) {
				Iterator iter = viewFiles.iterator();
				while (iter.hasNext()) {
					ViewFile vf = (ViewFile)iter.next();
					if (vf == null)
						continue;
					addChild(new PICLFile(this,vf,getDebugTarget()), false);
				}
			}
			fFilesRetrieved = true;
			return super.getChildren();
		}
	}

	/**
	 * @see PICLDebugElement#getChildrenNoExpand()
	 */
	public IDebugElement[] getChildrenNoExpand() throws DebugException {
		return super.getChildren();
	}

	
	
	/**
	 * Gets the part.
	 * @return Returns a Part
	 */
	public Part getPart() {
		return fPart;
	}

	
	/**
	 * @see IPropertySource#getEditableValue()
	 */
	public Object getEditableValue() {
		return null;
	}

	/**
	 * @see IPropertySource#getPropertyDescriptors()
	 */
	public IPropertyDescriptor[] getPropertyDescriptors() {
		IPropertyDescriptor[] pdlist = new IPropertyDescriptor[3];
		pdlist[0] = new PropertyDescriptor(PART_NAME,PICLUtils.getResourceString(PART_NAME));
		pdlist[1] = new PropertyDescriptor(DEBUG_INFO,PICLUtils.getResourceString(DEBUG_INFO));
		pdlist[2] = new PropertyDescriptor(LANGUAGE,PICLUtils.getResourceString(LANGUAGE));
		
		return pdlist;
	}

	/**
	 * @see IPropertySource#getPropertyValue(Object)
	 */
	public Object getPropertyValue(Object id) {
		if (id.equals(PART_NAME))
			return fPart.name();
		else 
			if (id.equals(DEBUG_INFO))
				return new Boolean(fPart.hasDebugInfo());
			else
				if (id.equals(LANGUAGE)) {
					Language l = fPart.getLanguage();
					if (l == null)
						return null;
					else
						return fPart.getLanguage().name();
				} else 
					return "*unknown*";
	}

	/**
	 * @see IPropertySource#isPropertySet(Object)
	 */
	public boolean isPropertySet(Object id) {
		return false;
	}

	/**
	 * @see IPropertySource#resetPropertyValue(Object)
	 */
	public void resetPropertyValue(Object id) {
	}

	/**
	 * @see IPropertySource#setPropertyValue(Object, Object)
	 */
	public void setPropertyValue(Object id, Object value) {
	}

}

