package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;

import com.ibm.debug.internal.pdt.model.Module;
import com.ibm.debug.internal.pdt.model.ModuleEventListener;
import com.ibm.debug.internal.pdt.model.ModuleUnloadedEvent;
import com.ibm.debug.internal.pdt.model.PartAddedEvent;

public class PICLModuleParent extends PICLDebugElement implements ModuleEventListener {

	private Object[] fExpandedElements = null;

	/**
	 * Constructor for PICLModuleParent
	 */
	public PICLModuleParent(IDebugElement parent, IDebugTarget debugTarget) {
		super(parent, debugTarget);
	}

	/**
	 * @see PICLDebugElement#doCleanupDetails()
	 */
	protected void doCleanupDetails() {
		// loop through the children and remove this object as a listener
		IDebugElement[] modules = null;
		try {
			modules = getChildren();
		} catch(DebugException de) {
			return;
		}
		for (int i=0; i < modules.length; i++)
			((PICLModule)modules[i]).getModule().removeEventListener(this);

	}

	/**
	 * This label is not displayed.
	 * @see PICLDebugElement#getLabel(boolean)
	 */
	public String getLabel(boolean qualified) {
		return "PICLModuleParent label";
	}

	/**
	 * @see IDebugElement#getName()
	 */
	public String getName() throws DebugException {
		return "PICLModuleParent name";
	}

	/**
	 * Used to add modules to this parent.
	 * @param The module that is to be added
	 */
	public void addModule(Module module) {
		// only add modules if the engine supports it.
		if (getDebugEngine().getCapabilities().getWindowCapabilities().modulesViewSupported()) {
			module.addEventListener(this);   // listen for module unload events
    	    addChild(new PICLModule(this,module,getDebugTarget()), false);
		}
	}

	/**
	 * Removes this child from the collection of children for this element.
	 * Fires a termination event for the child.
	 * Cleanup depends on the order of operations in this method.
	 */
	public final void removeChild(IDebugElement child) {

		// first call the child to clean itself up and then remove it
		((PICLDebugElement)child).doCleanup();

		fChildren.remove(child);
	}

	/**
	 * @see ModuleEventListener#partAdded(PartAddedEvent)
	 */
	public void partAdded(PartAddedEvent event) {
		// ignore... handled by the PICLModule
	}

	/**
	 * @see ModuleEventListener#moduleUnloaded(ModuleUnloadedEvent)
	 */
	public void moduleUnloaded(ModuleUnloadedEvent event) {
		PICLUtils.logEvent("module unloaded",this);

		// Don't do anything if the engine doesn't support the modules view
		if (!getDebugEngine().getCapabilities().getWindowCapabilities().modulesViewSupported())
			return;

		// find the PICLModule that must be removed
		Module module = event.getModule();

		IDebugElement[] modules = null;
		try {
			modules = getChildren();
		} catch(DebugException de) {
			return;
		}
		for (int i=0; i < modules.length; i++) {
			if (((PICLModule)modules[i]).getModule().equals(module)) {
				removeChild(modules[i]);
			}
		}
	}

	/**
	 * Saves tree expanded elements
	 * @param expanded elements
	 */
	public void saveExpandedElements(Object[] elements) {
		fExpandedElements = elements;
	}

	/**
	 * Returns tree expanded elements
	 * @return expanded elements
	 */
	public Object[] getExpandedElements() {
		return fExpandedElements;
	}

}

