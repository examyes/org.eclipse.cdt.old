package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.Launch;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.IThread;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.texteditor.ITextEditor;

import com.ibm.debug.internal.pdt.EngineSuppliedViewEditorInput;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLException;
import com.ibm.debug.internal.pdt.PICLStackFrame;
import com.ibm.debug.internal.pdt.PICLThread;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.PICLVariable;
import com.ibm.debug.internal.pdt.model.ViewInformation;
import com.ibm.debug.pdt.PICLDebugPlugin;


public class AddSnippetToMonitorAction extends Action implements ISelectionListener {
	protected final static String PREFIX= "AddSnippetToMonitorAction.";
	private ITextEditor editor;
	private ISelection currentSelection = null;

	public AddSnippetToMonitorAction(ITextEditor textEditor) {
		super(PICLUtils.getResourceString(PREFIX+"label"));
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().addSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
		editor = textEditor;
	}


	/** *@see IAction#run() */
	public void run() {
		if (editor != null) {
			//get the selected text
			ITextSelection textSelection = (ITextSelection) editor.getSelectionProvider().getSelection();
			String snippet = textSelection.getText().trim();
			if (snippet.length() == 0) { return; }
			int lineNum = textSelection.getStartLine();
			if (lineNum < 0) { return; }

			// the current selection in the debug view was saved in selectionChanged()
			if (currentSelection == null || currentSelection.isEmpty() || ((IStructuredSelection)currentSelection).size() > 1) {
				return;
			}

			Object elem = ((IStructuredSelection)currentSelection).getFirstElement();

			//if a launch or debugtarget is selected, use the currently stopped thread from the debugtarget
			if (elem instanceof Launch) {
				elem = ((Launch)elem).getDebugTarget();
			}
			if (elem instanceof PICLDebugTarget) {
				elem = ((PICLDebugTarget)elem).getStoppingThread();
			}
			//if the selected item isn't a PICLDebugElement we can't do anything with it
			if (! (elem instanceof PICLDebugElement) ) {
				return;
			}

			IThread thread = null;
			if (elem instanceof PICLThread) {
				thread = (PICLThread)elem;
			}
			if (elem instanceof PICLStackFrame) {
				thread = ((PICLStackFrame)elem).getThread();
			}
			
			if (thread == null || !(thread instanceof PICLThread) || thread.isTerminated()) {
				PICLUtils.logText(PREFIX + ": invalid thread");
				MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), PICLUtils.getResourceString(PREFIX+"unknown"));
				return;
			}

			//get the resource and viewinformation associated with the editorInput
			IEditorInput editorInput = editor.getEditorInput();
			IResource inputResource = null;
			ViewInformation viewInfo = null;
			if (editorInput instanceof IFileEditorInput) {
				//the resource is simply the file
				inputResource = ((IFileEditorInput)editorInput).getFile();

				//since this is an IFileEditorInput, the viewinformation must be sourceview
				IDebugTarget target = thread.getDebugTarget();
				if (!(target instanceof PICLDebugTarget)) { return; }
				viewInfo = ((PICLDebugTarget)target).getDebugEngine().getSourceViewInformation();

			} else if (editorInput instanceof EngineSuppliedViewEditorInput) {
				//enginesuppliedviews do not correspond to actual files, so we hang the marker off the project/workspaceroot
				inputResource = ((EngineSuppliedViewEditorInput)editorInput).getResource();

				//since this is an EngineSuppliedView, we can ask for the viewinformation directly
				viewInfo = ((EngineSuppliedViewEditorInput)editorInput).getViewInformation();

				//the enginesuppliedvieweditorinput only displays a partial buffer, so do some math to find the real line number
				lineNum += ((EngineSuppliedViewEditorInput)editorInput).getBufferStartLine() -
								((EngineSuppliedViewEditorInput)editorInput).getFileStartLine();
			} else {
				PICLUtils.logText(PREFIX + ": unknown editorInput");
				MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), PICLUtils.getResourceString(PREFIX+"unknown"));
				return;
			}

			// create a marker on the resource and set the line number where the expression is to be evaluated
			IMarker monitorMarker = null;
			try {
				monitorMarker = inputResource.createMarker(IPICLDebugConstants.PICL_MONITORED_EXPRESSION);
				monitorMarker.setAttribute(IMarker.LINE_NUMBER, lineNum);

				if (editorInput instanceof EngineSuppliedViewEditorInput) {
					//since in this case the marker is hung off the project, store the real part name in the marker
					monitorMarker.setAttribute(IPICLDebugConstants.SOURCE_FILE_NAME, ((EngineSuppliedViewEditorInput)editorInput).getName());
				}
			} catch (CoreException ce) {
				PICLUtils.logError(ce);
				MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), PICLUtils.getResourceString(PREFIX+"unknown"));
				return;
			}


			PICLVariable monitoredVar = null;
			try {
				//thread.monitorExpression(...) returns the PICLVariable, but nothing need be done with it except check for null
				monitoredVar = ((PICLThread)thread).monitorExpression(monitorMarker, snippet, viewInfo);
			} catch (PICLException pe) {
				MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), "\"" + snippet + "\": " + PICLUtils.getResourceString(PREFIX+"couldnotbeevaluated") + ": \"" + ((PICLThread)thread).getLabel(true) + "\"");
				return;
			}

			if (monitoredVar == null) {	//the expression could not be monitored
				MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), "\"" + snippet + "\": " + PICLUtils.getResourceString(PREFIX+"couldnotbeevaluated") + ": \"" + ((PICLThread)thread).getLabel(true) + "\"");
				return;
			}

			//open a new view if necessary
			IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
			if (p == null) {
				PICLUtils.logText(PREFIX + ": error getting ActivePage()");
				MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), PICLUtils.getResourceString(PREFIX+"unknown"));
				return;
			}
			IViewPart view= p.findView(IPICLDebugConstants.MONITOR_VIEW);
			if (view == null) {
				try {
					IWorkbenchPart activePart= p.getActivePart();
					view= p.showView(IPICLDebugConstants.MONITOR_VIEW);
					p.activate(activePart);
				} catch (PartInitException e) {
					PICLUtils.logError(e);
					MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), PICLUtils.getResourceString(PREFIX+"unknown"));
					return;
				}
			}
			p.bringToTop(view);
		} else {
			PICLUtils.logText("AddSnippetToMonitorAction: editor is null");
		}

  	}


	/**
	 * @see ISelectionListener#selectionChanged(IWorkbenchPart, ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {

		currentSelection = selection;  //save the current selection for when the action is run

		//only single selection of PICLDebugElements is allowed for this action
		if (selection == null || selection.isEmpty() || ((IStructuredSelection)selection).size() > 1)
		{
			setEnabled(false);
			return;
		}

		Object elem = ((IStructuredSelection)selection).getFirstElement();

		//Launches are not PICLDebugElements, but their debugtarget may be
		if (elem instanceof Launch) {
			elem = ((Launch)elem).getDebugTarget();
		}

		//this action is only valid for PICLDebugElements
		if (! (elem instanceof PICLDebugElement) ) {
			setEnabled(false);
			return;
		}

		//any PICLDebugElement can get its debugtarget
		IDebugTarget dbgtarget = ((PICLDebugElement)elem).getDebugTarget();

		if (dbgtarget == null || !(dbgtarget instanceof PICLDebugTarget) || dbgtarget.isTerminated()) {
			setEnabled(false);
			return;
		}

		setEnabled(true);
	}
	
}
