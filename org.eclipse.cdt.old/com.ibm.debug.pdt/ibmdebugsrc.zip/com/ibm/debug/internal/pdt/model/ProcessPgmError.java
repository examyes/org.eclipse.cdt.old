/*
 * (c) Copyright 2001 MyCorporation.
 * All Rights Reserved.
 */
package com.ibm.debug.internal.pdt.model;
/**
 * @version 	1.0
 * @author
 */
public class ProcessPgmError extends ProcessEvent {

	private String[] _lines;


	/**
	 * Constructor for ProcessPgmError.
	 * @param source
	 * @param process
	 * @param requestCode
	 */
	ProcessPgmError(Object source, DebuggeeProcess process, int requestCode, String[] lines) {
		super(source, process, requestCode);
		_lines = lines;
	}

	/*
	 * @see ModelEvent#fire(ModelEventListener)
	 */
	void fire(ModelEventListener listener) {
		((DebuggeeProcessEventListener)listener).programError(this);
	}

	/**
	 * Gets the program's error lines.
	 * @return Returns a String[]
	 */
	public String[] getLines() {
		return _lines;
	}

	
}
