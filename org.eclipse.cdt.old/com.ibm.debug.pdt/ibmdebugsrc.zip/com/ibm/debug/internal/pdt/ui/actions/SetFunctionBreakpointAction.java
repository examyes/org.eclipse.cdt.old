package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.io.IOException;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;

import com.ibm.debug.pdt.breakpoints.PICLEntryBreakpoint;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLFunction;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.Function;
import com.ibm.debug.pdt.WorkspaceSourceLocator;

public class SetFunctionBreakpointAction extends Action {

	private static final String PREFIX= "SetFunctionBreakpointAction.";
	private TreeViewer fTreeViewer;

	/**
	 * Constructor for SetFunctionBreakpointAction.
	 */
	public SetFunctionBreakpointAction(TreeViewer treeViewer) {
		super(PICLUtils.getResourceString(PREFIX + "label"));
		fTreeViewer = treeViewer;
		setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ACTIVE_BREAKPOINT));
	}

	
	
	/**
	 * @see IAction#run()
	 */
	public void run() {
		StructuredSelection sel = (StructuredSelection)fTreeViewer.getSelection();
		if (sel != StructuredSelection.EMPTY && sel.size() == 1) {   // for now support a single selection
			if (sel.getFirstElement() instanceof PICLFunction) {
				PICLFunction function = (PICLFunction)sel.getFirstElement();
				setEntryBreakpoint(function);
				// find the resource from the function
				Function fnc = function.getFunction();
				String fileName;
				try {
					fileName = fnc.getFile().baseFileName();
					WorkspaceSourceLocator locator = new WorkspaceSourceLocator();
					IResource resource = locator.findFile(fileName);
					System.out.println(fileName);
				} catch(IOException e) {
				}
				
			}
		}
		
		
	}

	private void setEntryBreakpoint(PICLFunction pFunc) {
		Function fnc = pFunc.getFunction();
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		try {
			// create a marker using the workspace root because entry breakpoints are not
			// explicitly related to a source file
			IMarker marker = root.createMarker(IPICLDebugConstants.PICL_ENTRY_BREAKPOINT);
			// now set up the attributes of the marker to complete the request to set
			// the entry breakpoint
			String module = fnc.getFile().view().part().module().name();
			String part = fnc.getFile().view().part().name();
			String sourceFile = "";
			try {
				sourceFile = fnc.getFile().name();
			} catch(IOException e) {}
			String entryPoint = fnc.name();
			
			String[] attributeNames = {IPICLDebugConstants.MODULE_NAME,
									   IPICLDebugConstants.OBJECT_NAME,
									   IPICLDebugConstants.SOURCE_FILE_NAME,
									   IPICLDebugConstants.DEFERRED,
									   IPICLDebugConstants.CASESENSITIVE,
									   IPICLDebugConstants.FUNCTION_NAME};
	
			Object[] values = {module,
							   part,
							   sourceFile,
							   new Boolean(true),
							   new Boolean(true),
							   entryPoint};
			
			marker.setAttributes(attributeNames,values);
			IBreakpoint bkpt = new PICLEntryBreakpoint();
			bkpt.setMarker(marker);
			DebugPlugin.getDefault().getBreakpointManager().addBreakpoint(bkpt);
		} catch(CoreException e) {
			return;
		}
	}


}
