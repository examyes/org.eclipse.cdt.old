package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;

import com.ibm.debug.internal.pdt.ui.dialogs.AddressBPWizard;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.pdt.PICLDebugPlugin;


public class AddAddressBreakpointAction  extends AbstractOpenWizardWorkbenchAction 
											implements IViewActionDelegate, ISelectionListener  {

	IAction myAction;

	/**
	 * Constructor for AddAddressBreakpointAction
	 */
	public AddAddressBreakpointAction(){
		super();
		init(PICLDebugPlugin.getActiveWorkbenchWindow());
	}

	/**
	 * Constructor for AddAddressBreakpointAction
	 */
	public AddAddressBreakpointAction(IWorkbench workbench, String label, Class[] acceptedTypes) {
		super(workbench, label, acceptedTypes, true);
	}

	/**
	 * @see AbstractOpenWizardAction#createWizard()
	 */
	protected Wizard createWizard() {
		return new AddressBPWizard();
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 * Processes selection changed events from breakpoint view only.
	 */
	public void selectionChanged(IAction action, ISelection sel) {
		if(myAction == null)
			myAction=action;

		//send selection changed event in case action wasn't created when stack selection event sent
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) 	return;
		IViewPart view= p.findView(IDebugUIConstants.ID_DEBUG_VIEW);
		if ((view==null) || !(view instanceof IDebugView)) return;

		((IDebugView)view).getViewer().setSelection(((IDebugView)view).getViewer().getSelection());
	}
	

	/**
	 * @see IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart view) {
		//want to be notified when picl stack frame selected so action can be enabled.
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().addSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
	}

	/**
	 * @see ISelectionListener#selectionChanged(IWorkbenchPart, ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {

		Object element = null;
		if (selection instanceof IStructuredSelection)
		{
			IStructuredSelection strSelection = (IStructuredSelection) selection;
			if(!strSelection.isEmpty() && strSelection.size() == 1)
				element = strSelection.getFirstElement();
			else
			{
				myAction.setEnabled(false);
				return;
			}

		} else
		  element = selection;

		//check item is a stack frame, process, or thread for live debug target	that supports address breakpoints
		if (element instanceof PICLDebugElement && !((IDebugElement)element).getDebugTarget().isTerminated()
			&& ((PICLDebugTarget)((IDebugElement)element).getDebugTarget()).supportsBrkptType(IPICLDebugConstants.PICL_ADDRESS_BREAKPOINT))
			myAction.setEnabled(true);
		else if (element instanceof ILaunch) //launcher
		{
		 	IDebugTarget dt =((ILaunch) element).getDebugTarget();
			if (dt instanceof PICLDebugTarget && !((PICLDebugTarget)dt).isTerminated()
				&& ((PICLDebugTarget)dt).supportsBrkptType(IPICLDebugConstants.PICL_ADDRESS_BREAKPOINT))
				myAction.setEnabled(true);
			else myAction.setEnabled(false);
		}
		else myAction.setEnabled(false);
	}

}

