package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.util.ArrayList;

import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.PropertyDescriptor;

import com.ibm.debug.internal.pdt.model.Module;
import com.ibm.debug.internal.pdt.model.ModuleEventListener;
import com.ibm.debug.internal.pdt.model.ModuleUnloadedEvent;
import com.ibm.debug.internal.pdt.model.PartAddedEvent;

public class PICLModule 
			extends PICLDebugElement 
			implements ModuleEventListener,
						IPropertySource {

	private Module fModule = null;
	// list of attributes for display
	private static final String PREFIX = "picl_module.";
	private static final String MODULE_NAME = PREFIX + "module_name";
	private static final String DEBUG_INFO = PREFIX + "debug_info";
	private static final String QUAL_NAME = PREFIX + "qualified_name";

	/**
	 * Constructor for PICLModule
	 */
	public PICLModule(IDebugElement parent, Module module, IDebugTarget debugTarget) {
		super(parent, debugTarget);
		fModule = module;
		if (fModule != null)
			fModule.addEventListener(this);
	}

	/**
	 * @see PICLDebugElement#doCleanupDetails()
	 */
	protected void doCleanupDetails() {
		if (fModule != null)
			fModule.removeEventListener(this);
	}

	/**
	 * Removes this child from the collection of children for this element.
	 * Fires a termination event for the child.
	 * Cleanup depends on the order of operations in this method.
	 */
	public final void removeChild(IDebugElement child) {

		// first call the child to clean itself up and then remove it
		((PICLDebugElement)child).doCleanup();

		fChildren.remove(child);
	}

	/**
	 * @see PICLDebugElement#getLabel(boolean)
	 */
	public String getLabel(boolean qualified) {
		return fModule.getQualifiedName();
	}

	/**
	 * @see IDebugElement#getName()
	 */
	public String getName() throws DebugException {
		return fModule.getQualifiedName();
	}

	/**
	 * @see ModuleEventListener#partAdded(PartAddedEvent)
	 */
	public void partAdded(PartAddedEvent event) {
		PICLUtils.logEvent("part added",this);
		addChild(new PICLPart(this, event.getPart(), getDebugTarget()), false);
	}

	/**
	 * @see ModuleEventListener#moduleUnloaded(ModuleUnloadedEvent)
	 */
	public void moduleUnloaded(ModuleUnloadedEvent event) {
		PICLUtils.logEvent("module unloaded (ignored)",this);
		// ignore because this is handled by the PICLModuleParent
	}

	/**
	 * Gets the module
	 * @return Returns a Module
	 */
	public Module getModule() {
		return fModule;
	}
	/**
	 * @see IPropertySource#getEditableValue()
	 */
	public Object getEditableValue() {
		return null;
	}

	/**
	 * @see IPropertySource#getPropertyDescriptors()
	 */
	public IPropertyDescriptor[] getPropertyDescriptors() {
		IPropertyDescriptor[] pdlist = new IPropertyDescriptor[3];
		pdlist[0] = new PropertyDescriptor(MODULE_NAME,PICLUtils.getResourceString(MODULE_NAME));
		pdlist[1] = new PropertyDescriptor(DEBUG_INFO,PICLUtils.getResourceString(DEBUG_INFO));
		pdlist[2] = new PropertyDescriptor(QUAL_NAME,PICLUtils.getResourceString(QUAL_NAME));
		
		return pdlist;
	}

	/**
	 * @see IPropertySource#getPropertyValue(Object)
	 */
	public Object getPropertyValue(Object id) {
		if (id.equals(MODULE_NAME))
			return fModule.name();
		else 
			if (id.equals(DEBUG_INFO))
				return new Boolean(fModule.hasDebugInfo());
			else
				if (id.equals(QUAL_NAME))
					return fModule.getQualifiedName();
				else 
					return "*unknown*";
	}

	/**
	 * @see IPropertySource#isPropertySet(Object)
	 */
	public boolean isPropertySet(Object id) {
		return false;
	}

	/**
	 * @see IPropertySource#resetPropertyValue(Object)
	 */
	public void resetPropertyValue(Object id) {
	}

	/**
	 * @see IPropertySource#setPropertyValue(Object, Object)
	 */
	public void setPropertyValue(Object id, Object value) {
	}

}

