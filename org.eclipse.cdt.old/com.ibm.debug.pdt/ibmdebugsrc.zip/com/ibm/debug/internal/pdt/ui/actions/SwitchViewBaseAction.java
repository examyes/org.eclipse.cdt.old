package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;

import com.ibm.debug.internal.pdt.PICLStackFrame;

public abstract class SwitchViewBaseAction extends Action {
	protected PICLStackFrame stackFrame = null;
	protected IDebugView view = null;

	/**
	 * Constructor for SwitchToDisViewA3
	 */
	protected SwitchViewBaseAction() {
		super();
	}

	/**
	 * Constructor for SwitchToDisViewA3
	 */
	protected SwitchViewBaseAction(String arg0) {
		super(arg0);
	}

	/**
	 * Constructor for SwitchToDisViewA3
	 */
	protected SwitchViewBaseAction(String arg0, ImageDescriptor arg1) {
		super(arg0, arg1);
	}

	/**
	 * Gets the stackFrame
	 * @return Returns a PICLStackFrame
	 */
	public PICLStackFrame getStackFrame() {
		return stackFrame;
	}

	/**
	 * Sets the stackFrame
	 * @param stackFrame The stackFrame to set
	 */
	public void setStackFrame(PICLStackFrame stackFrame) {
		this.stackFrame = stackFrame;
	}

	/**
	 * Gets the view
	 * @return Returns a DebugView
	 */
	public IDebugView getView() {
		return view;
	}
	/**
	 * Sets the view
	 * @param view The view to set
	 */
	public void setView(IDebugView view) {
		this.view = view;
	}

}

