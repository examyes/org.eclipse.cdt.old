package com.ibm.debug.internal.pdt.ui.dialogs;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.io.File;

import org.apache.xerces.parsers.DOMParser;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.debug.core.model.ISourceLocator;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.help.WorkbenchHelp;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.ibm.debug.epdc.EPDC;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLException;
import com.ibm.debug.internal.pdt.PICLStorageMap;
import com.ibm.debug.internal.pdt.PICLThread;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.Location;
import com.ibm.debug.internal.pdt.model.StorageStyle;
import com.ibm.debug.internal.pdt.model.ViewInformation;
import com.ibm.debug.internal.pdt.ui.views.StorageView;
import com.ibm.debug.internal.pdt.util.FileSystem;
import com.ibm.debug.pdt.PICLDebugPlugin;
import com.ibm.debug.pdt.WorkspaceSourceLocator;


/**
 * Dialog to map storage addresses to tree structures as defined by user XML
 */
public class MapStorageDialog extends StatusDialog {
	protected final static String PREFIX= "MapStorageDialog.";

	//Valid attributes for FIELD entries (nodes of the storage tree map) in the XML
	public static String HEADER			= "Header";
	public static String VIEW				= "View";
	public static String TYPE				= "Type";
	public static String LENGTH			= "length";
	public static String NUMOFCELLS	= "numOfCells";
	public static String FONTSIZE		= "fontsize";
	public static String LAYOUT			= "layout";


	//Valid types for the storage chunks to be displayed in (depending on engine)
	public static String TYPE_16_BIT_INT	= "16_BIT_INT";
	public static String TYPE_16_BIT_UINT	= "16_BIT_UINT";
	public static String TYPE_16_BIT_HINT	= "16_BIT_HINT";
	public static String TYPE_32_BIT_INT	= "32_BIT_INT";
	public static String TYPE_32_BIT_UINT	= "32_BIT_UINT";
	public static String TYPE_32_BIT_HINT	= "32_BIT_HINT";
	public static String TYPE_32_BIT_FLOAT= "32_BIT_FLOAT";
	public static String TYPE_64_BIT_INT	= "64_BIT_INT";
	public static String TYPE_64_BIT_FLOAT= "64_BIT_FLOAT";
	public static String TYPE_CHARACTER	= "CHARACTER";
	public static String TYPE_HEX				= "HEX";
	public static String TYPE_ASCII			= "ASCII";
	public static String TYPE_EBCDIC			= "EBCDIC";
	public static String TYPE_STRUCTURE	= "STRUCTURE";
	public static String TYPE_PADDING		= "PADDING";
	public static String TYPE_BIT				= "BIT";
	public static String TYPE_BITMASK		= "BITMASK";
	public static String TYPE_MAP				= "MAP";
	

	private PICLThread fThread;
	private String fExpression;
	private IResource fInputResource;
	private IMarker fMonitorMarker;
	private ViewInformation fViewInfo;

	private Text expressionInput;
	private Text mappingFileInput;
	private Button mappingFileBrowseButton;
	private Label fileNameLabel;
	private Label lineNumberLabel;
	private Label viewInfoLabel;
	private Label threadNameLabel;

	private Document fDOMLayout;
	/**
	 * Constructor for MapStorageDialog
	 */
	public MapStorageDialog(Shell parentShell, PICLThread thread) {
		super(parentShell);
		setTitle(PICLUtils.getResourceString(PREFIX+"title"));
		setDefaultImage(PICLUtils.getImage(IPICLDebugConstants.PICL_ICON_CLCL_MONITOR_EXPRESSION));
		this.fThread = thread;

		WorkbenchHelp.setHelp(parentShell, PICLUtils.getHelpResourceString("MonitorExpressionDialog"));
	}

	protected Control createDialogArea(Composite ancestor) {
		Composite parent = new Composite(ancestor, SWT.NULL);


		parent.setLayout(new GridLayout());
		GridData specParent= new GridData();
		specParent.grabExcessVerticalSpace= true;
		specParent.grabExcessHorizontalSpace= true;
		specParent.horizontalAlignment= GridData.FILL;
		specParent.verticalAlignment= GridData.CENTER;
		parent.setLayoutData(specParent);



		expressionInput = new Text(parent, SWT.BORDER);
		GridData specExpressionInput= new GridData();
		specExpressionInput.grabExcessVerticalSpace= false;
		specExpressionInput.grabExcessHorizontalSpace= true;
		specExpressionInput.horizontalAlignment= GridData.FILL;
		specExpressionInput.verticalAlignment= GridData.BEGINNING;
		expressionInput.setLayoutData(specExpressionInput);

		mappingFileInput = new Text(parent, SWT.BORDER);
		GridData specMappingFileInput= new GridData();
		specMappingFileInput.grabExcessVerticalSpace= false;
		specMappingFileInput.grabExcessHorizontalSpace= true;
		specMappingFileInput.horizontalAlignment= GridData.FILL;
		specMappingFileInput.verticalAlignment= GridData.BEGINNING;
		mappingFileInput.setLayoutData(specMappingFileInput);
		
		mappingFileBrowseButton = new Button(parent, SWT.PUSH);
		GridData specMappingFileBrowseButton= new GridData();
		specMappingFileBrowseButton.grabExcessVerticalSpace= false;
		specMappingFileBrowseButton.grabExcessHorizontalSpace= true;
		specMappingFileBrowseButton.horizontalAlignment= GridData.FILL;
		specMappingFileBrowseButton.verticalAlignment= GridData.BEGINNING;
		mappingFileBrowseButton.setLayoutData(specMappingFileBrowseButton);
		mappingFileBrowseButton.setText("Browse...");
		mappingFileBrowseButton.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent e) {
				String fileName = chooseMappingFile();
				if (fileName != null)
					mappingFileInput.setText(fileName);
			}
			public void widgetSelected(SelectionEvent e) {
				String fileName = chooseMappingFile();
				if (fileName != null)
					mappingFileInput.setText(fileName);
			}
		});
		
		fileNameLabel = new Label(parent, SWT.NULL);
		fileNameLabel.setLayoutData(new GridData());

		lineNumberLabel = new Label(parent, SWT.NULL);
		lineNumberLabel.setLayoutData(new GridData());

		viewInfoLabel = new Label(parent, SWT.NULL);
		viewInfoLabel.setLayoutData(new GridData());

		threadNameLabel = new Label(parent, SWT.NULL);
		threadNameLabel.setLayoutData(new GridData());

		initStatusInfo();

		expressionInput.setFocus();
		return parent;
	}

//	/**
//	 * The browse button was pressed.
//	 * @see IStringButtonAdapter
//	 */
//    public void changeControlPressed(DialogField field) {
//		String programName = chooseMappingFile();
//		if (programName != null)
//			mappingFileInput.setText(programName);
//	}
    
	private String chooseMappingFile() {
		FileDialog dialog = new FileDialog(getShell(), SWT.MULTI);
//		if(fProject != null && fProject.getLocation() != null)
//			dialog.setFilterPath(fProject.getLocation().toOSString());
		dialog.setFilterExtensions(new String[] {"*.xml"});
		return dialog.open();
	}


	private void initStatusInfo() {
		try {
			fViewInfo = fThread.getViewInformation();
			Location location = fThread.getLocation(fViewInfo);

			fileNameLabel.setText(PICLUtils.getResourceString(PREFIX+"filename") + " " + location.file().name());
			lineNumberLabel.setText(PICLUtils.getResourceString(PREFIX+"linenumber") +  " " + Integer.toString(location.lineNumber()));
			viewInfoLabel.setText(PICLUtils.getResourceString(PREFIX+"viewtype") + " " + fViewInfo.name());
			threadNameLabel.setText(PICLUtils.getResourceString(PREFIX+"threadname") + " " + fThread.getName());
		} catch (Exception e) {
		}
	}
	

	private Element getRootNodeFromFile(String filename) {
		File file = new File(filename);
		if (!file.exists()) {
			//throw some error dialog
		}
		if (!file.isFile() || !file.canRead()) {
			//throw some error dialog
		}
		
		DOMParser parser = new DOMParser();
		try {
			parser.parse(FileSystem.toURL(file));
			fDOMLayout = parser.getDocument();
		} catch (Exception e) {
			//log it, fail, throw up error dialog?
		}
		
		if (fDOMLayout == null) {
			//fail
		}
		
		Element rootNode = (Element) fDOMLayout.getDocumentElement();
		if (rootNode == null) {
			//fail
		}
		return rootNode;
	}

	private void buildChildNodes(Node nodeParent, PICLDebugElement piclParent) {
		String fChildName = null;
		String fChildType = null;
		int fChildLength = 0;
		String fChildLayout = null;

		String nodeName = null;
		String nodeValue = null;
		Node att = null;

		Node childNode = null;
		PICLStorageMap childStorageMap = null;

		NodeList childNodeList = nodeParent.getChildNodes();
		for (int i=0; i<childNodeList.getLength(); i++) {
			childNode = childNodeList.item(i);
			if (childNode instanceof Element) {
				NamedNodeMap cAttributes = childNode.getAttributes();
				for (int j=0; j<cAttributes.getLength(); j++) {
					att = cAttributes.item(j);
					nodeName = att.getNodeName();
					nodeValue = att.getNodeValue();
					if (nodeName.startsWith(HEADER)) {
						fChildName = nodeValue;
					} else if (nodeName.startsWith(TYPE)) {
						fChildType = nodeValue;
					} else if (nodeName.startsWith(LENGTH)) {
						fChildLength = Integer.parseInt(nodeValue);
					} else if (nodeName.startsWith(LAYOUT)) {
						fChildLayout = nodeValue;
					}
				}
				if (fChildType.equals(TYPE_STRUCTURE) || fChildType.equals(TYPE_BITMASK)) {
					/* we don't really want to monitor actual storage, but we need a node in the tree */
					childStorageMap = mapStorage(piclParent, fExpression /*+ offset*/, 0, null);
					childStorageMap.setName(fChildName);
					buildChildNodes(childNode, childStorageMap); //we need to calculate address offset from length
					piclParent.addChild(childStorageMap, false);

				} else {
					childStorageMap = mapStorage(piclParent, fExpression /* + offset*/, fChildLength, fChildType);
					childStorageMap.setName(fChildName);
					piclParent.addChild(childStorageMap, false);
				}
			}
		}
	}



	private PICLStorageMap mapStorage(PICLDebugElement parent, String address, int length, String type) {
		PICLStorageMap map = null;
		StorageStyle style;
		
		if (type == null) {
			style =null;
		} else if (type.equals(TYPE_16_BIT_INT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle16BitIntSigned);
		} else if (type.equals(TYPE_16_BIT_UINT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle16BitIntUnsigned);
		} else if (type.equals(TYPE_16_BIT_HINT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle16BitIntHex);
		} else if (type.equals(TYPE_32_BIT_INT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle32BitIntSigned);
		} else if (type.equals(TYPE_32_BIT_UINT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle32BitIntUnsigned);
		} else if (type.equals(TYPE_32_BIT_HINT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle32BitIntHex);
		} else if (type.equals(TYPE_32_BIT_FLOAT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle32BitFloat);
		} else if (type.equals(TYPE_64_BIT_INT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle64BitIntSigned);
		} else if (type.equals(TYPE_64_BIT_FLOAT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyle64IEEE);
		} else if (type.equals(TYPE_CHARACTER)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteCharacter);
		} else if (type.equals(TYPE_HEX)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
		} else if (type.equals(TYPE_ASCII)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteASCII);
		} else if (type.equals(TYPE_EBCDIC)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteEBCDIC);
		} else if (type.equals(TYPE_STRUCTURE)) {
			//style = StorageStyle.getStorageStyle(EPDC.);
			style = null;
		} else if (type.equals(TYPE_PADDING)) {
			//style = StorageStyle.getStorageStyle(EPDC.);
			style = null;
		} else if (type.equals(TYPE_BIT)) {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
		} else if (type.equals(TYPE_BITMASK)) {
			//style = StorageStyle.getStorageStyle(EPDC.);
			style = null;
		} else if (type.equals(TYPE_MAP)) {
			//style = StorageStyle.getStorageStyle(EPDC.);
			style = null;
		} else {
			style = StorageStyle.getStorageStyle(EPDC.StorageStyleByteHexCharacter);
		}
				
//   public final static short StorageStyleUnknown           = (short) 0;  /* unknown                          */
//   public final static short StorageStyleByteHexCharacter  = (short)1;  /* bytes in hex and character       */
//   public final static short StorageStyleByteCharacter     = (short) 2;  /* bytes in character               */
//   public final static short StorageStyle16BitIntSigned    = (short) 3;  /* 16 bit integer signed            */
//   public final static short StorageStyle16BitIntUnsigned  = (short)4;  /* 16 bit integer unsigned          */
//   public final static short StorageStyle16BitIntHex       = (short) 5;  /* 16 bit integer hex               */
//   public final static short StorageStyle32BitIntSigned    = (short) 6;  /* 32 bit integer signed            */
//   public final static short StorageStyle32BitIntUnsigned  = (short) 7;  /* 32 bit integer unsigned          */
//   public final static short StorageStyle32BitIntHex       = (short) 8;  /* 32 bit integer hex               */
//   public final static short StorageStyle32BitFloat        = (short) 9;  /* 32 bit float                     */
//   public final static short StorageStyle64BitFloat        = (short) 10; /* 64 bit float                     */
//   public final static short StorageStyle80BitFloat        = (short) 11; /* 80 bit float                     */
//   public final static short StorageStyle16BitNear         = (short) 12; /* 16 bit near                      */
//   public final static short StorageStyle16BitFar          = (short) 13; /* 16 bit far                       */
//   public final static short StorageStyle32BitFlat         = (short) 14; /* 32 bit flat                      */
//
//   public final static short StorageStyleByteHexEBCDIC     = (short) 15; /* bytes in hex and EBCDIC          */
//   public final static short StorageStyleByteEBCDIC        = (short) 16; /* bytes in EBCDIC                  */
//
//   public final static short StorageStyleByteHexDisasm     = (short) 17; /* bytes in hex and disassembly     */
//
//   public final static short StorageStyleByteHexASCII      = (short) 18; /* bytes in hex and ASCII           */
//   public final static short StorageStyleByteASCII         = (short) 19; /* bytes in ASCII                   */
//   public final static short StorageStyle32IEEE            = (short) 20; /* IEEE 32-bit float */
//   public final static short StorageStyle64IEEE            = (short) 21; /* IEEE 64-bit float */
//
//   public final static short StorageStyle64BitIntSigned    = (short) 22; /* 64 bit integer signed            */
//   public final static short StorageStyle64BitIntUnsigned  = (short) 23; /* 64 bit integer unsigned          */
//   public final static short StorageStyle64BitIntHex       = (short) 24; /* 64 bit integer hex               */
//   public final static short StorageStyle64BitFlat         = (short) 25; /* 64 bit integer hex               */

		try {
			if ((style == null) || (length <= 0)) {	//this is a dummy object that does not actually monitor storage.  it is a parent of real PICLStorageMap objects
				map = new PICLStorageMap(parent, parent.getDebugTarget(), address);
			} else {
				map = ((PICLThread)fThread).monitorStorageMap(parent, fMonitorMarker, fExpression, fViewInfo, 4, style);
			}
		} catch (PICLException pe) {
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), "\"" + PICLUtils.getNonMnemonicString(fExpression) + "\": " + PICLUtils.getResourceString(PREFIX+"couldnotbeevaluated") + ": \"" + ((PICLThread)fThread).getLabel(true) + "\"");
			return null;
		}
		if (map == null) {
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), "\"" + PICLUtils.getNonMnemonicString(fExpression) + "\": " + PICLUtils.getResourceString(PREFIX+"couldnotbeevaluated") + ": \"" + ((PICLThread)fThread).getLabel(true) + "\"");
			return null;
		}
		return map;
	}



	protected void okPressed() {

		fExpression = expressionInput.getText().trim();

		if (fThread == null || !(fThread instanceof PICLThread) || fThread.isTerminated()) {
			PICLUtils.logText(PREFIX + ": invalid thread");
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), PICLUtils.getResourceString(PREFIX+"unknown"));
			return;
		}

		int lineNum = fThread.getLocation(fViewInfo).lineNumber();

		//get the resource (project) and viewinformation associated with the thread
		ISourceLocator sourceLocator = fThread.getLaunch().getSourceLocator();
		if (sourceLocator instanceof WorkspaceSourceLocator) {
			WorkspaceSourceLocator wslocator = (WorkspaceSourceLocator) sourceLocator;
			fInputResource  = wslocator.getHomeProject();
		}
		if (fInputResource == null) {
			PICLUtils.logText(PREFIX + ": invalid resource");
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), PICLUtils.getResourceString(PREFIX+"unknown"));
			return;
		}

		// create a marker on the resource and set the line number and file name where the expression is to be evaluated
		try {
			fMonitorMarker = fInputResource.createMarker(IPICLDebugConstants.PICL_MONITORED_EXPRESSION);
			fMonitorMarker.setAttribute(IMarker.LINE_NUMBER, lineNum);
			fMonitorMarker.setAttribute(IPICLDebugConstants.SOURCE_FILE_NAME, fThread.getLocation(fViewInfo).file().name());
		} catch (Exception e) {
			PICLUtils.logError(e);
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), PICLUtils.getResourceString(PREFIX+"unknown"));
			return;
		}



		//open/check/read XML file
		Element rootNode = getRootNodeFromFile(mappingFileInput.getText().trim());
		NamedNodeMap attributes = rootNode.getAttributes();
		
		if (!rootNode.getAttribute(TYPE).equals("LAYOUT")) {
			//fail;
		}
		Node att = null;
		String nodeName = null;
		String nodeValue = null;

		String fLayoutHeader = null;
		String fLayoutView = null;
		int fLayoutLength = 0;
		int fLayoutNumOfCells = 0;
		int fLayoutFontSize = 0;
		for (int i=0; i<attributes.getLength(); i++) {
			att = attributes.item(i);
			nodeName = att.getNodeName();
			nodeValue = att.getNodeValue();
			if (nodeName.startsWith(HEADER)) {
				fLayoutHeader = nodeValue;
			} else if (nodeName.startsWith(VIEW)) {
				fLayoutView = nodeValue;
			} else if (nodeName.startsWith(LENGTH)) {
				fLayoutLength = Integer.parseInt(nodeValue);
			} else if (nodeName.startsWith(NUMOFCELLS)) {
				fLayoutNumOfCells = Integer.parseInt(nodeValue);
			} else if (nodeName.startsWith(FONTSIZE)) {
				fLayoutFontSize = Integer.parseInt(nodeValue);
			}
		}

		PICLDebugElement parentPICLObject = ((PICLDebugTarget)fThread.getDebugTarget()).getStorageMapParent();
		PICLStorageMap rootStorageMap = mapStorage(parentPICLObject, fExpression, 0, TYPE_MAP);
		rootStorageMap.setName(fLayoutHeader);


		
		parentPICLObject = rootStorageMap;
		buildChildNodes(rootNode, parentPICLObject);
		((PICLDebugTarget)fThread.getDebugTarget()).getStorageMapParent().addChild(rootStorageMap, false);


		//open a new view if necessary
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) {
			PICLUtils.logText(PREFIX + ": error getting ActivePage()");
			MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), PICLUtils.getResourceString(PREFIX+"unknown"));
			return;
		}
		IViewPart view = null;
		view= p.findView("com.ibm.debug.pdt.ui.StorageMapView");
		if (view == null) {
			try {
				IWorkbenchPart activePart= p.getActivePart();
				view= (StorageView) p.showView("com.ibm.debug.pdt.ui.StorageMapView");
				p.activate(activePart);
			} catch (PartInitException e) {
				PICLUtils.logError(e);
				MessageDialog.openError(null, PICLUtils.getResourceString(PREFIX+"evaluationfailed"), PICLUtils.getResourceString(PREFIX+"unknown"));
				return;
			}
		}

		if (view instanceof IDebugView) {
			p.bringToTop(view);
			((IDebugView)view).getViewer().refresh();
		}


		fMonitorMarker = null;
		fExpression = null;
		fInputResource = null;
		fViewInfo = null;
		
		super.okPressed();
	}


	private SelectionListener fListListener= new SelectionAdapter() {
		public void widgetSelected(SelectionEvent event) {
		}

		public void widgetDefaultSelected(SelectionEvent event) {
				okPressed();
		}
	};
}
