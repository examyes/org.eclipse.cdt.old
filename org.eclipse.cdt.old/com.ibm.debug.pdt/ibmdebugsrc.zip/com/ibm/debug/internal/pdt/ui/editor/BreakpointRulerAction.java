package com.ibm.debug.internal.pdt.ui.editor;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.debug.core.DebugException;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.IBreakpointManager;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.jface.text.source.IVerticalRuler;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.IUpdate;

import com.ibm.debug.pdt.breakpoints.PICLAddressBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLLineBreakpoint;
import com.ibm.debug.epdc.EPDC;
import com.ibm.debug.internal.pdt.EngineSuppliedViewEditorInput;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.Host;
import com.ibm.debug.internal.pdt.model.ViewInformation;
import com.ibm.lpex.alef.LpexAbstractTextEditor;
import com.ibm.lpex.alef.LpexMarkerRulerAction;
import com.ibm.lpex.core.LpexView;

// This action is used for adding / removing breakpoints (line and address) from
// the vertical ruler of the Debugger Editor.

public class BreakpointRulerAction extends LpexMarkerRulerAction implements IUpdate {

	boolean doAddressBreakpoint = false;
	IResource resource = null;
	IBreakpointManager breakpointManager= DebugPlugin.getDefault().getBreakpointManager();
	String address = null;
	int line = 0;
	EngineSuppliedViewEditorInput engineViewEI = null;
	IFile file = null;
	/**
	 * Constructor for BreakpointRulerAction
	 */
	public BreakpointRulerAction(ResourceBundle bundle,
								String prefix,
								IVerticalRuler ruler,
								ITextEditor editor,
								String markerType) {

		super(bundle, prefix, ruler, editor, markerType, false);
	}

	/**
	 * @see MarkerRulerAction#addMarker()
	 */
	protected void addMarker() {
		IEditorInput input = getTextEditor().getEditorInput();

		line = getVerticalRuler().getLineOfLastMouseButtonActivity() + 1;

		if (input instanceof IFileEditorInput) {
			IFile file = ((IFileEditorInput)input).getFile();

			if (file != null) {
				resource= (IResource) file;
				IWorkspaceRunnable body = new IWorkspaceRunnable()
				{
					public void run(IProgressMonitor monitor) throws CoreException
					{
						try {
							PICLLineBreakpoint breakpoint = new PICLLineBreakpoint();
							IMarker breakpointmarker = resource.createMarker(IPICLDebugConstants.PICL_LINE_BREAKPOINT);
//							breakpointManager.configureLineBreakpoint(breakpoint, PICLUtils.getModelIdentifier(), true, line, -1, -1);
							breakpointmarker.setAttributes(new String[] {IBreakpoint.ID, IBreakpoint.ENABLED, IMarker.LINE_NUMBER, IMarker.CHAR_START, IMarker.CHAR_END},
																		new Object[] {new String(PICLUtils.getModelIdentifier()), new Boolean(true), new Integer(line), new Integer(-1), new Integer(-1)});
							breakpoint.setMarker(breakpointmarker);


			   				try {
								breakpointManager.addBreakpoint(breakpoint);
							}
							catch (DebugException de) {
							}
						}
						catch (CoreException ce) {
						}
					}
				};
				try {
					ResourcesPlugin.getWorkspace().run(body, null);
				}
				catch (CoreException ce) {
				}
			}
		} else 	if (input instanceof EngineSuppliedViewEditorInput) {
			engineViewEI = (EngineSuppliedViewEditorInput) input;

			ViewInformation viewInfo = engineViewEI.getViewInformation();
			short kind = viewInfo.kind();

			// Address breakpoint used for mixed and real disassembly (i.e. not AS400 statement)
			// views. Line breakpoint used for source, listing and statement views.
			doAddressBreakpoint = false;
			if (kind == EPDC.View_Class_Mixed ||
					(kind == EPDC.View_Class_Disasm && engineViewEI.getEngineHost() != Host.OS400))
				doAddressBreakpoint = true;

			// EngineSuppliedViews should only be displayed in the Debugger Editor, so we
			// can safely assume the editor is a LpexAbstractTextEditor
			LpexView lpexView = ((LpexAbstractTextEditor)getTextEditor()).getLpexView();

			// The address is determined from the "prefix" area of the source view
			String lineText = lpexView.elementText(line);
			address = lineText.substring(0, engineViewEI.getPrefixLength());

			resource= engineViewEI.getResource();
			if (resource != null) {
				IWorkspaceRunnable body = new IWorkspaceRunnable()
				{
					public void run(IProgressMonitor monitor) throws CoreException
					{
						String filename = engineViewEI.getName();
						try {
							if (doAddressBreakpoint) {
								PICLAddressBreakpoint breakpoint = new PICLAddressBreakpoint();
								IMarker breakpointmarker = resource.createMarker(IPICLDebugConstants.PICL_ADDRESS_BREAKPOINT);
								////breakpointManager.configureBreakpoint(breakpoint, PICLUtils.getModelIdentifier(), true);
								//breakpointManager.configureLineBreakpoint(breakpoint, PICLUtils.getModelIdentifier(), true, line, -1, -1);
								breakpointmarker.setAttributes(new String[] {IBreakpoint.ID, IBreakpoint.ENABLED, IMarker.LINE_NUMBER, IMarker.CHAR_START, IMarker.CHAR_END},
																		new Object[] {new String(PICLUtils.getModelIdentifier()), new Boolean(true), new Integer(line), new Integer(-1), new Integer(-1)});

								String[] attributeNames = {IPICLDebugConstants.EDITABLE,
															IPICLDebugConstants.ADDRESS_EXPRESSION,
															IPICLDebugConstants.SOURCE_FILE_NAME};

								Object[] values = {new Boolean(true), address, filename};

								breakpointmarker.setAttributes(attributeNames, values);
								breakpoint.setMarker(breakpointmarker);
								breakpointManager.addBreakpoint(breakpoint);
							}
							else {
								PICLLineBreakpoint breakpoint = new PICLLineBreakpoint();
								IMarker breakpointmarker = resource.createMarker(IPICLDebugConstants.PICL_LINE_BREAKPOINT);
//								breakpointManager.configureLineBreakpoint(breakpoint, PICLUtils.getModelIdentifier(), true, line, -1, -1);
								breakpointmarker.setAttributes(new String[] {IBreakpoint.ID, IBreakpoint.ENABLED, IMarker.LINE_NUMBER, IMarker.CHAR_START, IMarker.CHAR_END},
																		new Object[] {new String(PICLUtils.getModelIdentifier()), new Boolean(true), new Integer(line), new Integer(-1), new Integer(-1)});

								// Store source file name in breakpoint so we don't lose it
								if (filename != null) {
									String[] attributeNames = {IPICLDebugConstants.SOURCE_FILE_NAME};
									Object[] values = {filename};
									breakpointmarker.setAttributes(attributeNames, values);
								}
								breakpoint.setMarker(breakpointmarker);
								breakpointManager.addBreakpoint(breakpoint);
							}
						}
						catch (CoreException ce) {
						}
					}
				};
				try	{
					ResourcesPlugin.getWorkspace().run(body, null);
				}
				catch (CoreException ce) {
				}
			}
		}
	}

	/**
	 * @see MarkerRulerAction#removeMarkers(List)
	 */
	protected void removeMarkers(List markers) {
		IBreakpointManager breakpointManager= DebugPlugin.getDefault().getBreakpointManager();
		try {

			Iterator e= markers.iterator();
			PICLBreakpoint breakpoint = new PICLBreakpoint();
			while (e.hasNext()) {
				breakpoint.setMarker((IMarker)e.next());
				breakpointManager.removeBreakpoint(breakpoint, true);
			}

		} catch (CoreException e) {
		}
	}
	
}

