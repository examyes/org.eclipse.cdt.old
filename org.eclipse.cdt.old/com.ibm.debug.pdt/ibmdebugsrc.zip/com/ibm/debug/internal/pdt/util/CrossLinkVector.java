package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

/**
 * The <code>CrossLinkVector</code> class implements a growable array of
 * objects. It is similar to the <code>Vector</code> class, but the objects
 * contained in the vector must be of type <code>CrossLink</code>, rather
 * than generic objects.  The class ensures that it is referenced by all
 * <code>CrossLink</code> objects that are in its vector, and vice versa.
 * This facilitates the building of many-to-many relationships between vectors.
 * <p>
 * The class implements most of the interfaces of the <code>Vector</code> class,
 * and the behaviour is, in general, similar.  The major differences occur when
 * adding and deleting elements.  The <code>CrossLinkVector</code> class does
 * not allow duplicate elements, and the addition/deletion procedures are somewhat
 * more complex, as the <code>CrossLink</code> objects must be kept
 * symchronized.
 *
 */

import java.util.Vector;
import com.ibm.debug.internal.pdt.util.*;

public class CrossLinkVector extends CrossLink
{
  /**
   * Constructs an empty vector with an initial capacity of 5.
   *
   * @param   node              the object at the node that is "owns" this vector.
   */
  public CrossLinkVector(DestroyableObject node)
  {
    super(node);
    _links = new Vector(5);
  }

  /**
   * Constructs an empty vector with the specified initial capacity.
   *
   * @param   node              the object at the node that is "owns" this vector.
   * @param   initialCapacity   the initial capacity of the vector.
   */
  public CrossLinkVector(DestroyableObject node, int initialCapacity)
  {
    super(node);
    _links = new Vector(initialCapacity);
  }

  /**
   * Constructs an empty vector with the specified initial capacity and
   * capacity increment, as for the <code>Vector</code> class.
   *
   * @param   node              the object at the node that is "owns" this vector.
   * @param   initialCapacity   the initial capacity of the vector.
   * @param   capacityIncrement the amount by which the capacity is
   *                            increased when the vector overflows.
   */
  public CrossLinkVector(DestroyableObject node, int initialCapacity, int capacityIncrement)
  {
    super(node);
    _links = new Vector(initialCapacity, capacityIncrement);
  }

  /**
   * Destroy the object, removing all internal references
   */
  public void destroy()
  {
    _links.removeAllElements();
    _links = null;
    super.destroy();
  }

  /**
   * Destroy the nodes linked to by this object. This may be called as part of
   * destroying the node attached to this object to clean up the references so
   * that garbage collection can release the storage.
   */
  public void destroyLinkedNodes()
  {
    while (!_links.isEmpty())
      lastNode().destroy();
  }

  /**
   * Adds the specified component to the end of this vector,
   * increasing its size by one. The capacity of this vector is
   * increased if its size becomes greater than its capacity.
   *
   * @param   obj   the component to be added.
   * @exception  IllegalArgumentException  if the object currently exists in the vector
   */
  public void addElement(CrossLink obj)
  {
    if (_links.contains(obj))
      throw new IllegalArgumentException();

    if (obj.contains(this))
      throw new IllegalArgumentException();

    _links.addElement(obj);
    obj.addElementNoCheck(this);
  }

  /**
   * Adds the specified component to the end of this vector,
   * increasing its size by one. The capacity of this vector is
   * increased if its size becomes greater than its capacity.
   * <p>
   * No error checking is performed, and the back chain is not maintained.
   *
   * @param   obj   the component to be added.
   */
  protected void addElementNoCheck(CrossLink obj)
  {
    _links.addElement(obj);
  }

  /**
   * Inserts the specified object as a component in this vector at the
   * specified <code>index</code>. Each component in this vector with
   * an index greater or equal to the specified <code>index</code> is
   * shifted upward to have an index one greater than the value it had
   * previously.
   * <p>
   * The index must be a value greater than or equal to <code>0</code>
   * and less than or equal to the current size of the vector.
   *
   * @param      obj     the component to insert.
   * @param      index   where to insert the new component.
   * @exception  ArrayIndexOutOfBoundsException  if the index was invalid.
   * @exception  IllegalArgumentException  if the object currently exists in the vector
   */
  public void insertElementAt(CrossLink obj, int index)
  {
    // prevent a duplicate
    if (_links.contains(obj))
      throw new IllegalArgumentException();

    if (obj.contains(this))
      throw new IllegalArgumentException();

    _links.insertElementAt(obj, index);
    obj.addElementNoCheck(this);
  }

  /**
   * Removes the argument from this vector. If
   * the object is found in this vector, each component in the vector
   * with an index greater or equal to the object's index is shifted
   * downward to have an index one smaller than the value it had previously.
   *
   * @param   obj   the component to be removed.
   * @return  <code>true</code> if the argument was a component of this
   *          vector; <code>false</code> otherwise.
   */
  public boolean removeElement(CrossLink obj)
  {
    if (!_links.contains(obj))
      return false;

    _links.removeElement(obj);
    obj.removeElementNoCheck(this);
    return true;
  }

  /**
   * Removes the argument from this vector. If
   * the object is found in this vector, each component in the vector
   * with an index greater or equal to the object's index is shifted
   * downward to have an index one smaller than the value it had previously.
   *
   * @param   obj   the component to be removed.
   * @return  <code>true</code> if the argument was a component of this
   *          vector; <code>false</code> otherwise.
   */
  public void removeElementNoCheck(CrossLink obj)
  {
    _links.removeElement(obj);
  }

  /**
   * Removes all components from this vector and sets its size to zero.
   */
  public void removeAllElements()
  {
    Vector crosslinks = (Vector)_links.clone();
    _links.removeAllElements();
    for (int i = crosslinks.size(); 0 != i--; )
    {
      CrossLink p = (CrossLink)crosslinks.elementAt(0);
      p.removeElement(this);
      p = null;
    }
  }

  /**
   * Deletes the component at the specified index. Each component in
   * this vector with an index greater or equal to the specified
   * <code>index</code> is shifted downward to have an index one
   * smaller than the value it had previously.
   * <p>
   * The index must be a value greater than or equal to <code>0</code>
   * and less than the current size of the vector.
   *
   * @param      index   the index of the object to remove.
   * @exception  ArrayIndexOutOfBoundsException  if the index was invalid.
   */
  public void removeElementAt(int index)
  {
    CrossLink p = (CrossLink)_links.elementAt(index);
    _links.removeElementAt(index);
    p.removeElement(this);
  }

  /**
   * Trims the capacity of this vector to be the vector's current
   * size. An application can use this operation to minimize the
   * storage of a vector.
   */
  public void trimToSize()
  {
    _links.trimToSize();
  }

  /**
   * Sets the size of this vector. If the new size is greater than the
   * current size, new <code>null</code> items are added to the end of
   * the vector. If the new size is less than the current size, all
   * components at index <code>newSize</code> and greater are discarded.
   *
   * @param   newSize   the new size of this vector.
   */
  public void setSize(int newSize)
  {
    _links.setSize(newSize);
  }

  /**
   * Increases the capacity of this vector, if necessary, to ensure
   * that it can hold at least the number of components specified by
   * the minimum capacity argument.
   *
   * @param   minCapacity   the desired minimum capacity.
   */
  public void ensureCapacity(int minCapacity) {
    _links.ensureCapacity(minCapacity);
  }

  /**
   * Returns the current capacity of this vector.
   *
   * @return  the current capacity of this vector.
   */
  public int capacity() {
    return _links.capacity();
  }

  /**
   * Returns the number of components in this vector.
   *
   * @return  the number of components in this vector.
   */
  public int size()
  {
    return _links.size();
  }

  /**
   * Tests if the specified object is a component in this vector.
   *
   * @param   elem   an object.
   * @return  <code>true</code> if the specified object is a component in
   *          this vector; <code>false</code> otherwise.
   */
  public boolean contains(CrossLink elem)
  {
    return _links.contains(elem);
  }

  /**
   * Searches for the of the given argument, testing
   * for equality using the <code>equals</code> method.
   *
   * @param   elem   an object.
   * @return  the index of the first occurrence of the argument in this
   *          vector; returns <code>-1</code> if the object is not found.
   * @see     java.lang.Object#equals(java.lang.Object)
   */
  public int indexOf(CrossLinkVector elem) {
    return _links.indexOf(elem, 0);
  }

  /**
   * Searches for the first occurence of the given argument, beginning
   * the search at <code>index</code>, and testing for equality using
   * the <code>equals</code> method.
   *
   * @param   elem    an object.
   * @param   index   the index to start searching from.
   * @return  the index of the first occurrence of the object argument in
   *          this vector at position <code>index</code> or later in the
   *          vector; returns <code>-1</code> if the object is not found.
   * @see     java.lang.Object#equals(java.lang.Object)
   */
  public int indexOf(CrossLinkVector elem, int index) {
    return _links.indexOf(elem, index);
  }

  /**
   * Returns the index of the last occurrence of the specified object in
   * this vector.  Since no duplicates are allowed, this is equivalent
   * to the method <code>indexOf</code>.
   *
   * @param   elem   the desired component.
   * @return  the index of the last occurrence of the specified object in
   *          this vector; returns <code>-1</code> if the object is not found.
   */
  public int lastIndexOf(CrossLinkVector elem) {
    return _links.lastIndexOf(elem);
  }

  /**
   * Searches backwards for the specified object, starting from the
   * specified index, and returns an index to it.
   *
   * @param   elem    the desired component.
   * @param   index   the index to start searching from.
   * @return  the index of the last occurrence of the specified object in this
   *          vector at position less than <code>index</code> in the vector;
   *          <code>-1</code> if the object is not found.
   */
  public int lastIndexOf(CrossLinkVector elem, int index) {
    return _links.lastIndexOf(elem, index);
  }

  /**
   * Returns the element at the specified index.
   *
   * @param      index   an index into this vector.
   * @return     the element at the specified index
   * @exception  ArrayIndexOutOfBoundsException  If an invalid index was
   *               given.
   */
  public CrossLink elementAt(int index) {
    return (CrossLink)_links.elementAt(index);
  }

  /**
   * Returns the node at the specified index.
   *
   * @param      index   an index into this vector.
   * @return     The node at the specified index
   * @exception  ArrayIndexOutOfBoundsException  If an invalid index was
   *               given.
   */
  public DestroyableObject nodeAt(int index) {
    return elementAt(index)._node;
  }

  /**
   * Returns the crosslink that is the first component of this vector.
   *
   * @return     The crosslink that is the first component of this vector.
   * @exception  NoSuchElementException  If this vector has no components.
   */
  public CrossLink firstElement() {
    return (CrossLink)_links.firstElement();
  }

  /**
   * Returns the node that that is at the first component of this vector.
   *
   * @return     The node that is at the first component of this vector.
   * @exception  NoSuchElementException  If this vector has no components.
   */
  public DestroyableObject firstNode() {
    return firstElement()._node;
  }

  /**
   * Returns the cross-link that is the last component of the vector.
   *
   * @return  The cross-link that is the last component of the vector. i.e., the
   *          component at index <code>size()&nbsp;-&nbsp;1</code>.
   * @exception  NoSuchElementException  If this vector is empty.
   */
  public CrossLink lastElement() {
    return (CrossLink)_links.lastElement();
  }

  /**
   * Returns the node that is at the last component of the vector.
   *
   * @return  The node that is the at last component of the vector.
   * @exception  NoSuchElementException  If this vector is empty.
   */
  public DestroyableObject lastNode() {
    return lastElement()._node;
  }

  /**
   * Tests if this vector has no components.
   *
   * @return  <code>true</code> if this vector has no components;
   *          <code>false</code> otherwise.
   */
  public boolean isEmpty()
  {
    return _links.isEmpty();
  }

  /**
   * Generate a vector of the linked nodes.  This vector can be
   * independently manipulated without affecting the state of the
   * CrossLinkVector object.  The resulting vector will be in
   * the same order as in the <code>_links</code> member of the class.
   *
   * @return  a vector of the linked-to nodes.
   */
  public Vector nodeVector()
  {
    Vector links = new Vector(_links.size());
    int sz = _links.size();
    for (int j = 0; j < sz; j++)
      links.addElement(((CrossLink)_links.elementAt(j))._node);
    return links;
  }

  /**
   * The actual <code>Vector</code> object that maintains the list.  It
   * is protected so that all access to it must be through the
   * <code>CrossLinkVector</code> interface.  This prevents inadvertant
   * illegal modification of the list.
   */
  private Vector _links;
}

