package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.debug.core.DebugException;
import org.eclipse.jface.action.Action;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLStorage;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.internal.pdt.model.Storage;
import com.ibm.debug.internal.pdt.ui.views.StorageView;
import com.ibm.debug.internal.pdt.ui.views.StorageViewTab;
import com.ibm.debug.pdt.PICLDebugPlugin;


public class DisableStorageMonitorAction extends Action implements SelectionListener, DisposeListener {
	protected static final String PREFIX= "DisableStorageMonitorAction.";
	private TabFolder tabFolder;


	/**
	 * Constructor for DisableStorageMonitorAction
	 */
	public DisableStorageMonitorAction(TabFolder tabFolder) {
		super(PICLUtils.getResourceString(PREFIX+"label.disable"));
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip.disable"));
		setEnabled(tabFolder.getItems().length > 0);
		setChecked(false);
		this.tabFolder = tabFolder;
		tabFolder.addSelectionListener(this);

		WorkbenchHelp.setHelp(this, PICLUtils.getHelpResourceString("DisableStorageMonitorAction"));
	}

	/**
	 * @see Action
	 */
	public void setChecked(boolean value) {
		super.setChecked(value);
		setText(value ? PICLUtils.getResourceString(PREFIX+"label.enable") : PICLUtils.getResourceString(PREFIX+"label.disable"));
		setToolTipText(value ? PICLUtils.getResourceString(PREFIX+"tooltip.enable") : PICLUtils.getResourceString(PREFIX+"tooltip.disable"));
	}

	protected void doAction(StorageView view) throws DebugException {
		int index = tabFolder.getSelectionIndex();
		TabItem tab = tabFolder.getItem(index);
		if (isChecked()) {
			((StorageViewTab)tab.getData()).getStorage().disable();
			setChecked(true);
		} else {
			((StorageViewTab)tab.getData()).getStorage().enable();
			setChecked(false);
		}
	}

	/**
	 * @see Action#run()
	 */
	public void run() {
		// get the StorageView
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) { return; }
		IViewPart view= p.findView(IPICLDebugConstants.STORAGE_VIEW);
		if (view == null) {
			try {
				view= p.showView(IPICLDebugConstants.STORAGE_VIEW);
			} catch (PartInitException e) {
				PICLUtils.logError(e);
				return;
			}
		}

		try {
			if (!(view instanceof StorageView)) { return; }
			doAction((StorageView)view);
		} catch (DebugException de) {
			PICLUtils.logError(de);
		}
		p.bringToTop(view);
	}


	/**
	 * @see SelectionListener#widgetDefaultSelected(SelectionEvent)
	 */
	public void widgetDefaultSelected(SelectionEvent event) {
		//not used
	}


	/**
	 * @see SelectionListener#widgetSelected(SelectionEvent)
	 */
	public void widgetSelected(SelectionEvent event) {
		//event.item - tabitem
		//event.source - tabfolder
		if (event.item.getData() != null) {
		 	PICLStorage pStorage =  ((StorageViewTab)event.item.getData()).getStorage();
		 	if (pStorage.getStorage() != null) {
				setEnabled(true);
		 		if (pStorage.getStorage().isEnabled()) {
					setChecked(false);
		 		} else {
					setChecked(true);
		 		}
		 		return;
		 	}
		 }
		setEnabled(false);
	}


	/**
	 * @see DisposeListener#widgetDisposed(DisposeEvent)
	 */
	public void widgetDisposed(DisposeEvent event) {
		if (tabFolder.getItems().length > 0) {
			int index = tabFolder.getSelectionIndex();
			if (index >= 0) {
				TabItem tab = tabFolder.getItem(index);
				if ((tab != null) && !(tab.isDisposed())) {
					StorageViewTab storageTab = (StorageViewTab)tab.getData();
					if (storageTab != null) {
						PICLStorage pStorage = storageTab.getStorage();
						if (pStorage != null) {
							Storage storage = pStorage.getStorage();
							if (storage != null) {
								setEnabled(true);
								if (storage.isEnabled()) {
									setChecked(false);
								} else {
									setChecked(true);
								}
								return;
							}
						}
					}
				}
			}
		}
		setEnabled(false);
	}
}
