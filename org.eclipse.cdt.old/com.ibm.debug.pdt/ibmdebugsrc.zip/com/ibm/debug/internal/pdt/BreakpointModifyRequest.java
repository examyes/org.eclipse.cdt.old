package com.ibm.debug.internal.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.core.resources.IMarker;
import org.eclipse.debug.core.model.IBreakpoint;

import com.ibm.debug.internal.pdt.model.Breakpoint;

public abstract class BreakpointModifyRequest extends BreakpointRequest {

	protected final String msgKey = super.msgKey + "modify.";

	protected Breakpoint fBreakpoint = null;
	public BreakpointModifyRequest(
		PICLDebugTarget debugTarget,
		Breakpoint breakpoint) {
		super(debugTarget);

		fBreakpoint = breakpoint;
	}

	protected boolean updateEnableSetting(IMarker marker) {

		try {
			boolean enableSetting = marker.getAttribute(IBreakpoint.ENABLED, true);
			if (enableSetting != fBreakpoint.isEnabled())
				if (enableSetting)
					fBreakpoint.enable(syncRequest());
				else
					fBreakpoint.disable(syncRequest());
		} catch (Exception e) {
			return false;
		}
		return true;
	}
}