package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */


import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.model.IBreakpoint;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IViewActionDelegate;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;

import com.ibm.debug.pdt.breakpoints.PICLAddressBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLEntryBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLLineBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLLoadBreakpoint;
import com.ibm.debug.pdt.breakpoints.PICLWatchBreakpoint;
import com.ibm.debug.internal.pdt.ui.dialogs.AddressBPWizard;
import com.ibm.debug.internal.pdt.ui.dialogs.EntryBPWizard;
import com.ibm.debug.internal.pdt.ui.dialogs.LineBPWizard;
import com.ibm.debug.internal.pdt.ui.dialogs.LoadBPWizard;
import com.ibm.debug.internal.pdt.ui.dialogs.WatchBPWizard;
import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.pdt.PICLDebugPlugin;

public class EditBreakpointAction
	extends AbstractOpenWizardWorkbenchAction
	implements IViewActionDelegate, ISelectionListener {	
	
	IAction myAction;
	IWorkbenchPage p;
	//keep track of last selection so that we can check for termination before running the action
	PICLDebugTarget lastSelectedTarget;   
	
	/**
	 * Constructor for AddEntryBreakpointAction
	 */
	public EditBreakpointAction(IWorkbench workbench, String label, Class[] acceptedTypes) {
		super(workbench, label, acceptedTypes, false);
	}
	
	/**
	 * Constructor for AddEntryBreakpointAction
	 */
	public EditBreakpointAction(){
		super();		
		init(PICLDebugPlugin.getActiveWorkbenchWindow());	
	}
		
	/**
	 * @see AbstractOpenWizardAction#createWizard()
	 */
	protected Wizard createWizard() {
		//Need to double check that target has not terminated. A selectionChanged event is not
		//generated in this case, so it's possible the action should have been disabled.
		if(lastSelectedTarget == null || lastSelectedTarget.isTerminated())
		{
			//send selection changed event so the other breakpoint actions will change their states as well
			IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
			if (p == null) 	return null;
			IViewPart view= p.findView(IDebugUIConstants.ID_BREAKPOINT_VIEW);
			if ((view==null) || !(view instanceof IDebugView)) return null;	
			
			((IDebugView)view).getViewer().setSelection(((IDebugView)view).getViewer().getSelection());
			return null;
		}
			
		if (p == null) 	
			p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p==null)
			return null;
		IViewPart view= p.findView(IDebugUIConstants.ID_BREAKPOINT_VIEW);
		if ((view != null) && (view instanceof IDebugView))
		{
			ISelection currentSelection =  ((IDebugView)view).getViewer().getSelection();
			if(currentSelection == null)
				return null;
			if (currentSelection instanceof IStructuredSelection)
			{ //multiple items selected	
				Object[] selections = ((IStructuredSelection)currentSelection).toArray();			
				for (int i = 0; i < selections.length; i++)	
				{
					if(selections[i] == null)
						continue;
					if(selections[i] instanceof IBreakpoint)
						return openWizard((IBreakpoint) selections[i]);
				}
			}
			else if (currentSelection instanceof IBreakpoint)
				return openWizard((IBreakpoint) currentSelection);

		}
		return null;
	}
	

	private Wizard openWizard(IBreakpoint breakpoint)
	{
        // Determine breakpoint type and bring up corresponding dialog for editing
          if (breakpoint instanceof PICLLineBreakpoint)
            return new LineBPWizard(breakpoint.getMarker());
          else if (breakpoint instanceof PICLEntryBreakpoint)
	       	return new EntryBPWizard(breakpoint.getMarker());
          else if (breakpoint instanceof PICLWatchBreakpoint)
		    return new WatchBPWizard(breakpoint.getMarker());
          else if (breakpoint instanceof PICLLoadBreakpoint)
			return new LoadBPWizard(breakpoint.getMarker());
          else if (breakpoint instanceof PICLAddressBreakpoint)
			return new AddressBPWizard(breakpoint.getMarker());
				        
		// bad breakpoint type
		return null;
	}
	
	
	/**
	 * @see IViewActionDelegate#init(IViewPart)
	 */
	public void init(IViewPart arg0) {
		//want to be notified when picl stack frame selected so action can be enabled.
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().addSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
	}
	
	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 * Processes selection changed events from breakpoint view only.
	 */
	public void selectionChanged(IAction action, ISelection currentSelection) {
		if(myAction == null)
			myAction=action;		
		
		if(currentSelection == null || currentSelection.isEmpty())
		{
			myAction.setEnabled(false);	
			return;
		}
		if(!debugTargetSupportsEditing())
		{
			myAction.setEnabled(false);
			return;
		}
		
		if (currentSelection instanceof IStructuredSelection)
			{ //multiple items selected	
				Object[] selections = ((IStructuredSelection)currentSelection).toArray();			
								
				int found = 0;				
				for (int i = 0; i < selections.length; i++)	
				{
					if(selections[i] == null)
						continue;
					if(selections[i] instanceof IBreakpoint)
					{
						if( selections[i] instanceof PICLLineBreakpoint ||
							selections[i] instanceof PICLEntryBreakpoint ||
							selections[i] instanceof PICLWatchBreakpoint ||
							selections[i] instanceof PICLLoadBreakpoint ||
							selections[i] instanceof PICLAddressBreakpoint)
								found++;
					}
				}
				if(found != 0 && found == selections.length)  //supported by all selected items
					myAction.setEnabled(true);
			}
			else if(currentSelection instanceof IBreakpoint)
			{
				if( currentSelection instanceof PICLLineBreakpoint ||
					currentSelection instanceof PICLEntryBreakpoint ||
					currentSelection instanceof PICLWatchBreakpoint ||
					currentSelection instanceof PICLLoadBreakpoint ||
					currentSelection instanceof PICLAddressBreakpoint)
						myAction.setEnabled(true);
			}
	}
	
	private boolean debugTargetSupportsEditing()
	{
		//try to save a lot of processing by using last selected debug target
		if(lastSelectedTarget != null)
		{ 
			if(!lastSelectedTarget.isTerminated())
				return true;
			else
				return false;
		}	
		p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p==null) return false;
		IViewPart view= p.findView(IDebugUIConstants.ID_DEBUG_VIEW);
		if ((view==null) || !(view instanceof IDebugView)) return false;
	
		ISelection sel = ((IDebugView)view).getViewer().getSelection();
					
		Object element = null;		
		if (sel instanceof IStructuredSelection)
		{
			
			IStructuredSelection selection = (IStructuredSelection) sel;
			if(!selection.isEmpty() && selection.size() == 1)
			{
				element = selection.getFirstElement();
				if (element == null)
					return false;
			}
			else 			
				return false;
				
		} else
		  element = sel;
		
		//check item is a stack frame, process, or thread for live debug target	that supports editing breakpoints	  	
		if (element instanceof PICLDebugElement 
			&& ((PICLDebugTarget)((IDebugElement)element).getDebugTarget())!=null 
			&& !((IDebugElement)element).getDebugTarget().isTerminated() 
			&& ((IDebugElement)element).getDebugTarget().isSuspended()
			&& ((PICLDebugTarget)((IDebugElement)element).getDebugTarget()).getBreakpointCapabilities()!=null
			&& ((PICLDebugTarget)((IDebugElement)element).getDebugTarget()).getBreakpointCapabilities().breakpointModifySupported()) 
		{				
				lastSelectedTarget = (PICLDebugTarget)((IDebugElement)element).getDebugTarget();
				return true;
		}
		else if (element instanceof ILaunch) //launcher
		{
		 	IDebugTarget dt =((ILaunch) element).getDebugTarget();
			if (dt!=null && dt instanceof PICLDebugTarget 
				&& !dt.isTerminated() && dt.isSuspended()
				&& ((PICLDebugTarget)dt).getBreakpointCapabilities()!=null
				&& ((PICLDebugTarget)dt).getBreakpointCapabilities().breakpointModifySupported())
			{
					lastSelectedTarget = (PICLDebugTarget)dt;
					return true;					
			}
			else return false;
		}	
		else return false;
	}

	
	/**
	 * @see ISelectionListener#selectionChanged(IWorkbenchPart, ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {

		lastSelectedTarget = null;		
		boolean flag = false;
		
		Object element = null;	
		
		if(selection == null)
		{
			myAction.setEnabled(false);
			return;	
		}
		
		if (selection instanceof IStructuredSelection)
		{			
			IStructuredSelection strSelection = (IStructuredSelection) selection;
			if(!strSelection.isEmpty() && strSelection.size() == 1)
			{
				element = strSelection.getFirstElement();
				if (element == null)
				{
					myAction.setEnabled(false);
					return;
				}
			}
			else 			
			{
				myAction.setEnabled(false);
				return;
			}
				
		} else
		  element = selection;
		
		//check item is a stack frame, process, or thread for live debug target	that supports editing breakpoints	  	
		if (element instanceof PICLDebugElement && !((IDebugElement)element).getDebugTarget().isTerminated() 
			&& ((IDebugElement)element).getDebugTarget().isSuspended()
			&& ((PICLDebugTarget)((IDebugElement)element).getDebugTarget())!=null 
			&& ((PICLDebugTarget)((IDebugElement)element).getDebugTarget()).getBreakpointCapabilities()!=null
			&& ((PICLDebugTarget)((IDebugElement)element).getDebugTarget()).getBreakpointCapabilities().breakpointModifySupported()) 
		{
			flag = true;
			lastSelectedTarget = (PICLDebugTarget)((IDebugElement)element).getDebugTarget();	
		}
		else if (element instanceof ILaunch) //launcher
		{
		 	IDebugTarget dt =((ILaunch) element).getDebugTarget();
		 	
		 		 		
			if ((dt instanceof PICLDebugTarget) && !dt.isTerminated() && dt.isSuspended()
				&& ((PICLDebugTarget)dt).getBreakpointCapabilities()!=null
				&& ((PICLDebugTarget)dt).getBreakpointCapabilities().breakpointModifySupported())
			{
				 	flag = true;
				 	lastSelectedTarget = (PICLDebugTarget) dt;		
			}
			else myAction.setEnabled(false);
		}	
		else myAction.setEnabled(false);
		
		//acceptable selection in debug view. Now lets make sure breakpoint view has "good" selection.
		if (flag)
		{
			if (p == null) 	
				p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
			
			if (p==null)
			{
				myAction.setEnabled(false);
				return;				
			}
			//findView() will throw null pointer if perspective still null when perspective opened
			IViewPart view;
			try{
				view= p.findView(IDebugUIConstants.ID_BREAKPOINT_VIEW);			
			}catch(Exception e){
				myAction.setEnabled(false);
				return;			
			}
			if ((view != null) && (view instanceof IDebugView))
			{
				ISelection currentSelection =  ((IDebugView)view).getViewer().getSelection();
				if(currentSelection == null)
				{
					myAction.setEnabled(false);		
					return;
				}
				if (currentSelection instanceof IStructuredSelection)
				{ //multiple items selected	
					Object[] selections = ((IStructuredSelection)currentSelection).toArray();			
					int found = 0;				
					for (int i = 0; i < selections.length; i++)	
					{
						if(selections[i] == null)
							continue;
						if(selections[i] instanceof IBreakpoint)
						{
							if( selections[i] instanceof PICLLineBreakpoint ||
								selections[i] instanceof PICLEntryBreakpoint ||
								selections[i] instanceof PICLWatchBreakpoint ||
								selections[i] instanceof PICLLoadBreakpoint ||
								selections[i] instanceof PICLAddressBreakpoint)
									found++;
						}
					}
					if(found == selections.length)  //supported by all selected items
						myAction.setEnabled(true);
				}
				else if(currentSelection instanceof IBreakpoint)
				{
					if( currentSelection instanceof PICLLineBreakpoint ||
						currentSelection instanceof PICLEntryBreakpoint ||
						currentSelection instanceof PICLWatchBreakpoint ||
						currentSelection instanceof PICLLoadBreakpoint ||
						currentSelection instanceof PICLAddressBreakpoint)
							myAction.setEnabled(true);
				}
			}
		}
		else myAction.setEnabled(false);
			
	}

}

