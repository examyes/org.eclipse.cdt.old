package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.lang.Object;

/**
 * Range represents a range of integers between the lower and upper bound
 * inclusively.
 */
public class Range extends Object
{
  private int lower;
  private int upper;

  public Range(int lower, int upper) {
    if (Assertion.ON)
      Assertion.check(lower <= upper);

    this.lower = lower;
    this.upper = upper;
  }

  public void setBounds(int lower, int upper) {
    if (Assertion.ON)
      Assertion.check(lower <= upper);

    this.lower = lower;
    this.upper = upper;
  }

  public void setLowerBound(int lower) {
    if (Assertion.ON)
      Assertion.check(lower <= upper);

    this.lower = lower;
  }

  public void setUpperBound(int upper) {
    if (Assertion.ON)
      Assertion.check(lower <= upper);

    this.upper = upper;
  }

  public int lowerBound() { return lower; }
  public int upperBound() { return upper; }
  public int size() { return upper - lower + 1; }

  public boolean equals(Object obj) {
    Range range = (Range) obj;
    return (lower == range.lowerBound() && upper == range.upperBound());
  }

  public String toString() {
    return new String("Range(" + lower + " to " + upper + ")" );
  }

}

