package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.debug.core.Launch;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.ui.dialogs.MapStorageDialog;
import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLStackFrame;
import com.ibm.debug.internal.pdt.PICLThread;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.pdt.PICLDebugPlugin;


public class MapStorageAction
	extends Action
	implements ISelectionListener {	
		
	protected static final String PREFIX= "MapStorageAction.";
	private PICLThread thread = null;

	public MapStorageAction()
	{
		super(PICLUtils.getResourceString(PREFIX+"label"));
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip"));
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().addSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);

		WorkbenchHelp.setHelp(this, PICLUtils.getHelpResourceString("MonitorExpressionAction"));
	}

	/**
	 * @see Action#run()
	 */
	public void run() {
		Shell shell= PICLDebugPlugin.getActiveWorkbenchShell();

		// the current thread was saved in selectionChanged()
		if (thread == null || !(thread instanceof PICLThread) || thread.isTerminated()) {
			return;
		}

		MapStorageDialog dialog= new MapStorageDialog(shell, thread);
//		if (dialog.checkEngineSupport())
			dialog.open();
//		else
//			dialog = null;
	}

	
	/**
	 * @see ISelectionListener#selectionChanged(IWorkbenchPart, ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {

		thread = null;

		//only single selection of PICLDebugElements is allowed for this action
		if (selection == null || selection.isEmpty() || ((IStructuredSelection)selection).size() > 1)
		{
			setEnabled(false);
			return;
		}

		Object elem = ((IStructuredSelection)selection).getFirstElement();

		//Launches are not PICLDebugElements, but their debugtarget may be
		if (elem instanceof Launch) {
			elem = ((Launch)elem).getDebugTarget();
		}

		//this action is only valid for PICLDebugElements
		if (! (elem instanceof PICLDebugElement) ) {
			setEnabled(false);
			return;
		}

		if (elem instanceof PICLDebugTarget) {
			thread = ((PICLDebugTarget)elem).getStoppingThread();
		} else if (elem instanceof PICLThread) {
			thread = (PICLThread)elem;
		} else if (elem instanceof PICLStackFrame) {
			thread = (PICLThread)((PICLStackFrame)elem).getThread();
		}

		if (thread == null || !(thread instanceof PICLThread) || thread.isTerminated()) {
			setEnabled(false);
			return;
		}

		//check to see if engine supports storage monitors
		PICLDebugTarget target = (PICLDebugTarget)thread.getDebugTarget();
		if (target == null || target.isTerminated() || !target.supportsStorageMapping()) {
			setEnabled(false);
			return;
		}

		setEnabled(true);
	}

}
