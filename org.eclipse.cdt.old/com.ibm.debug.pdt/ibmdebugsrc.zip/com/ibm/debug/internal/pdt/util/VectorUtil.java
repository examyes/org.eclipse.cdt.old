package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.util.*;

public class VectorUtil
{
  /**
   * Puts 'object' into 'vector' at index 'index'. If 'index' is greater than
   * the last available index in the vector, will grow the vector to be size
   * index + 1.
   */

  public static void setVectorElementToObject(Object object, Vector vector, int index)
  {
    if (index > vector.size() - 1)
       vector.setSize(index + 1);

    try
    {
      vector.setElementAt(object, index);
    }
    catch (ArrayIndexOutOfBoundsException excp)
    {
    }
  }

  /**
   * Destroys the objects that a vector points to, and empties the vector.
   * If the vector contains objects that do not implement the
   * <code>DestroyableObject</code> interface, the error will be logged, but
   * otherwise ignored.
   *
   * @param vector    A vector of objects that implement the
   *                  <code>DestroyableObject</code> interface.
   */

  public static void destroyVector(Vector vector)
  {
    // iterate through the vector, destroying the elements
    for (int i = vector.size(); 0 < i--; )
    {
      // Since we may not have a destroyable object, we need to catch
      // the failure of the cast operation
      DestroyableObject obj;
      try
      {
        obj = (DestroyableObject)vector.elementAt(i);
      }
      catch(ClassCastException excp)
      {
        // Oops! - build an error message, and log this...
        String msg = new String(new VectorUtil().getClass().getName());
        msg = msg.concat(".destroyVector(Vector):- Class ");
        msg = msg.concat(vector.elementAt(i).getClass().getName());
        msg = msg.concat(" does not implement the DestroyObject interface.");
        TraceLogger.TRACE.err(2, msg);
        continue;
      }

      // Do not catch exceptions here - they result from what should
      // be a valid destroy() call....
      obj.destroy();
      obj = null;
    }

    // empty the vector
    vector.removeAllElements();
  }

  /**
   * Creates an array of Objects large enough to contain all of the elements
   * in the given Vector, copies the Vector elements into the array, and then
   * returns the array. If 'vector' is null, returns an empty array.
   */

  public static Object[] copyVectorIntoArray(Vector vector)
  {
    if (vector == null)
       return new Object[0];
    else
    {
       Object[] result = new Object[vector.size()];
       vector.copyInto(result);
       return result;
    }
  }
}
