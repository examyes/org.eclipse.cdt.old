package com.ibm.debug.internal.pdt.ui.views;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import org.eclipse.debug.core.DebugEvent;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.IDebugEventListener;
import org.eclipse.debug.core.Launch;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.ui.IDebugModelPresentation;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.help.ViewContextComputer;
import org.eclipse.ui.help.WorkbenchHelp;
import org.eclipse.ui.part.IPage;
import org.eclipse.ui.part.Page;
import org.eclipse.ui.part.PageBook;
import org.eclipse.ui.part.PageBookView;

import com.ibm.debug.internal.pdt.ui.actions.CopyStorageToolbarAction;
import com.ibm.debug.internal.pdt.ui.actions.MonitorExpressionAction;
import com.ibm.debug.internal.pdt.ui.actions.PrintStorageToolbarAction;
import com.ibm.debug.internal.pdt.ui.actions.RemoveStorageMonitorAction;
import com.ibm.debug.internal.pdt.ui.actions.ResetStorageMonitorAction;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLDebugElement;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLStorage;
import com.ibm.debug.internal.pdt.PICLThread;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.pdt.PICLDebugPlugin;

public class StorageView extends PageBookView implements IDebugView, ISelectionListener, IDebugEventListener {

	protected final static String PREFIX= "StorageView.";
	private TabFolder emptyTabFolder;
	private Hashtable tabFolderHashtable;
	private Composite parent;
	private StackLayout stackLayout;
	private MonitorExpressionAction fMonitorExpressionAction;
	private RemoveStorageMonitorAction fRemoveStorageMonitorAction;
//	private DisableStorageMonitorAction fDisableStorageMonitorAction;
	private ResetStorageMonitorAction fResetStorageMonitorAction;

	private CopyStorageToolbarAction fCopyStorageToolbarAction;
	private PrintStorageToolbarAction fPrintStorageToolbarAction;

	/**
	 * A page in this view's page book that contains this view's viewer.
	 */
	class ViewerPage extends Page {
		/** @see IPage#createControl(Composite) */
		public void createControl(Composite parent) { }

		/** @see IPage#getControl() */
		public Control getControl() { return null; }

		/** @see IPage#setFocus() */
		public void setFocus() {
			Viewer viewer= getViewer();
			if (viewer != null) {
				Control c = viewer.getControl();
				if (!c.isFocusControl()) {
					c.setFocus();
				}
			}
		}
	}

	/**
	 * Constructor for StorageView.
	 */
	public StorageView() {
		super();
	}

	/**
	 * The default page for a debug view is its viewer.
	 *
	 * @see PageBookView#createDefaultPage(PageBook)
	 */
	protected final IPage createDefaultPage(PageBook book) {
		ViewerPage page = new ViewerPage();
		page.createControl(book);
		initPage(page);
		return page;
	}

	/**
	 * @see PageBookView#createPartControl(Composite)
	 */
	public void createPartControl(Composite parent) {
		super.createPartControl(parent);
		this.parent = parent;
		stackLayout = new StackLayout();
		parent.setLayout(stackLayout);
		addListeners();
		createActions();
		final IToolBarManager tbm= getViewSite().getActionBars().getToolBarManager();
		configureToolBar(tbm);
		getViewSite().getActionBars().updateActionBars();
		
		emptyTabFolder = new TabFolder(parent, SWT.NULL);
		stackLayout.topControl = emptyTabFolder;

		tabFolderHashtable = new Hashtable(3);

                WorkbenchHelp.setHelp(parent, PICLUtils.getHelpResourceString("StorageView"));

	}

	/**
	 * @see AbstractDebugView#createActions()
	 */
	protected void createActions() {
		fMonitorExpressionAction = new MonitorExpressionAction(true);
		fMonitorExpressionAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_MONITOR_EXPRESSION));
		fMonitorExpressionAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_MONITOR_EXPRESSION));
		fMonitorExpressionAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_MONITOR_EXPRESSION));
		fMonitorExpressionAction.setEnabled(false);

		fRemoveStorageMonitorAction = new RemoveStorageMonitorAction();
		fRemoveStorageMonitorAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_REMOVE_STORAGE));
		fRemoveStorageMonitorAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_REMOVE_STORAGE));
		fRemoveStorageMonitorAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_REMOVE_STORAGE));
		fRemoveStorageMonitorAction.setEnabled(false);

//		fDisableStorageMonitorAction = new DisableStorageMonitorAction();
//		fDisableStorageMonitorAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_DISABLE_STORAGE));
//		fDisableStorageMonitorAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_DISABLE_STORAGE));
//		fDisableStorageMonitorAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_DISABLE_STORAGE));
//		fDisableStorageMonitorAction.setEnabled(false);

		fResetStorageMonitorAction = new ResetStorageMonitorAction();
		fResetStorageMonitorAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_STORAGE_RESET));
		fResetStorageMonitorAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_STORAGE_RESET));
		fResetStorageMonitorAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_STORAGE_RESET));
		fResetStorageMonitorAction.setEnabled(false);
		
		fCopyStorageToolbarAction = new CopyStorageToolbarAction();
		fCopyStorageToolbarAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_COPY_VIEW_TO_CLIPBOARD));
		fCopyStorageToolbarAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_COPY_VIEW_TO_CLIPBOARD));
		fCopyStorageToolbarAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_COPY_VIEW_TO_CLIPBOARD));
		fCopyStorageToolbarAction.setEnabled(false);

		fPrintStorageToolbarAction = new PrintStorageToolbarAction(PICLUtils.getResourceString(PREFIX+"printjobtitle"));
		fPrintStorageToolbarAction.setHoverImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_CLCL_PRINT_VIEW));
		fPrintStorageToolbarAction.setDisabledImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_DLCL_PRINT_VIEW));
		fPrintStorageToolbarAction.setImageDescriptor(PICLUtils.getImageDescriptor(IPICLDebugConstants.PICL_ICON_ELCL_PRINT_VIEW));
		fPrintStorageToolbarAction.setEnabled(false);
	}

	/**
	 * @see AbstractDebugView#configureToolBar(IToolBarManager)
	 */
	protected void configureToolBar(IToolBarManager tbm) {
		tbm.add(new Separator(this.getClass().getName()));
		tbm.add(fMonitorExpressionAction);
		tbm.add(fRemoveStorageMonitorAction);
//		tbm.add(fDisableStorageMonitorAction);
		tbm.add(fResetStorageMonitorAction);
		tbm.add(new Separator(this.getClass().getName()));
		tbm.add(fCopyStorageToolbarAction);
		tbm.add(fPrintStorageToolbarAction);
//		tbm.add(new Separator(IWorkbenchActionConstants.MB_ADDITIONS));
	}


	private void createStorageViewTab(PICLStorage storage) {
		TabFolder tabFolder = (TabFolder)stackLayout.topControl;
		if (tabFolder == emptyTabFolder) {
			//force selectionChanged() so the tab doesn't get added to the emptyTabFolder
			IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
			if (p == null) { return; }
			IViewPart view= p.findView(IDebugUIConstants.ID_DEBUG_VIEW);
			if (view == null) {
				try {
					IWorkbenchPart activePart= p.getActivePart();
					view= p.showView(IDebugUIConstants.ID_DEBUG_VIEW);
					p.activate(activePart);
				} catch (PartInitException e) {
					PICLUtils.logError(e);
					return;
				}
			}
			if (!(view instanceof IDebugView)) { return; }
			((IDebugView)view).getViewer().setSelection(((IDebugView)view).getViewer().getSelection());
			tabFolder = (TabFolder)stackLayout.topControl;
		}

		TabItem tab = new TabItem(tabFolder, SWT.NULL);
		StorageViewTab storageTab = new StorageViewTab(storage, tab);
		tab.setControl(storageTab.createFolderPage(tabFolder));
		((Table)tab.getControl()).setTopIndex(storageTab.TABLE_PREBUFFER);
		storageTab.resizeTable();
		String expression = storage.getStorage().getExpression();
		int indexOfAmpersand = expression.indexOf("&", 0);
		while (indexOfAmpersand >= 0) {
			expression = expression.substring(0, indexOfAmpersand) + "&" + expression.substring(indexOfAmpersand, expression.length());
			indexOfAmpersand += 2;
			indexOfAmpersand = expression.indexOf("&", indexOfAmpersand);
		}
		PICLDebugTarget dbgtarget = (PICLDebugTarget)storage.getDebugTarget();
		PICLThread pThread = dbgtarget.getPICLThread(storage.getStorage().getExpressionThread());
		if (pThread != null) {
			tab.setText(expression + " - " + PICLUtils.getResourceString(PREFIX+"thread") + ": " + pThread.getName());
		} else {
			tab.setText(expression);
		}

//		fDisableStorageMonitorAction.setEnabled(true);
//		fDisableStorageMonitorAction.setChecked(false);
		fRemoveStorageMonitorAction.setEnabled(true);
		fResetStorageMonitorAction.setEnabled(true);
		fCopyStorageToolbarAction.setEnabled(true);
		fPrintStorageToolbarAction.setEnabled(true);

		tabFolder.setSelection(tabFolder.indexOf(tab));
	}

	
	public StorageViewTab getTopStorageTab() {
		TabFolder folder = (TabFolder)stackLayout.topControl;
		int index = folder.getSelectionIndex();
		if (index >= 0) {
			TabItem tab = folder.getItem(index);
			return (StorageViewTab)tab.getData();
		}
		return null;
	}

	public void setFocus() {
		stackLayout.topControl.setFocus();
	}

	/**
	 * Debug views implement the debug view adapter which
	 * provides access to a view's underlying viewer and
	 * debug model presentation for a specific debug model.
	 *
	 * @see IAdaptable#getAdapter(java.lang.Class)
	 * @see IDebugView
	 */
	public Object getAdapter(Class adapter) {
		if (adapter == IDebugView.class) {
			return this;
		}
		return super.getAdapter(adapter);
	}

	/**
	 * @see PageBookView#isImportant(IWorkbenchPart)
	 */
	protected boolean isImportant(IWorkbenchPart part) {
		return false;
	}

	/**
	 * @see PageBookView#doCreatePage(IWorkbenchPart)
	 */
	protected PageRec doCreatePage(IWorkbenchPart part) {
		return null;
	}

	/**
	 * @see PageBookView#doDestroyPage(IWorkbenchPart, PageRec)
	 */
	protected void doDestroyPage(IWorkbenchPart part, PageRec pageRecord) {
	}

	/**
	 * @see PageBookView#getBootstrapPart()
	 */
	protected IWorkbenchPart getBootstrapPart() {
		return null;
	}

	public void dispose() {
		removeListeners();
		
		Enumeration allDbgTargets = tabFolderHashtable.keys();
		List piclStorageMonitors;
		PICLStorage pStorage;
		while (allDbgTargets.hasMoreElements()) {
			PICLDebugTarget dbgtarget = (PICLDebugTarget)allDbgTargets.nextElement();
			if (!dbgtarget.isTerminated()) {
				piclStorageMonitors = ((PICLDebugTarget)dbgtarget).getStorageParent().getChildrenAsList();
				Object iter[] = piclStorageMonitors.toArray();
				for (int i = 0; i < iter.length; i++) {
					pStorage = (PICLStorage)iter[i];
					pStorage.delete();
				}
			}
		}
		super.dispose();
	}

	public void partClosed(IWorkbenchPart part) {
		if (!(part instanceof StorageView))
			return;
		//TODO: stop add/update events from the model
		removeListeners();
		
		Enumeration allDbgTargets = tabFolderHashtable.keys();
		List piclStorageMonitors;
		PICLStorage pStorage;
		while (allDbgTargets.hasMoreElements()) {
			PICLDebugTarget dbgtarget = (PICLDebugTarget)allDbgTargets.nextElement();
			if (!dbgtarget.isTerminated()) {
				piclStorageMonitors = ((PICLDebugTarget)dbgtarget).getStorageParent().getChildrenAsList();
				Object iter[] = piclStorageMonitors.toArray();
				for (int i = 0; i < iter.length; i++) {
					pStorage = (PICLStorage)iter[i];
					pStorage.delete();
				}
			}
		}
		super.partClosed(part);
	}

	public void handleDebugEvent(DebugEvent event) {
		if (! (event.getSource() instanceof PICLStorage)) { return; }
		switch (event.getKind()) {
			case DebugEvent.CREATE:
				final PICLStorage stor = (PICLStorage)event.getSource();
				PICLDebugPlugin.getDefault().getShell().getDisplay().asyncExec(new Runnable() {
					public void run() {
						createStorageViewTab(stor);
					}
				});
				break;
			case DebugEvent.TERMINATE:
				if ((event.getSource() instanceof PICLDebugTarget) && (tabFolderHashtable.containsKey(event.getSource()))) {
					tabFolderHashtable.remove(event.getSource());
				}
				break;
			default:
				break;
		}
	}

	
	private void emptyFolderAndDisableActions() {
		fResetStorageMonitorAction.setEnabled(false);
		fRemoveStorageMonitorAction.setEnabled(false);
		fCopyStorageToolbarAction.setEnabled(false);
		fPrintStorageToolbarAction.setEnabled(false);
		stackLayout.topControl = emptyTabFolder;
		if (!parent.isDisposed()) {
			parent.layout();
		}
	}
	
	/**
	 * @see ISelectionListener#selectionChanged(IWorkbenchPart, ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
			
		//only single selection of PICLDebugElements is allowed for this action
		if (selection == null || selection.isEmpty() || ((IStructuredSelection)selection).size() > 1)
		{
			emptyFolderAndDisableActions();
			return;
		}

		Object elem = ((IStructuredSelection)selection).getFirstElement();

		//Launches are not PICLDebugElements, but their debugtarget may be
		if (elem instanceof Launch) {
			elem = ((Launch)elem).getDebugTarget();
		}

		//this action is only valid for PICLDebugElements
		if (! (elem instanceof PICLDebugElement) ) {
			emptyFolderAndDisableActions();
			return;
		}

		//any PICLDebugElement can get its debugtarget
		IDebugTarget dbgtarget = ((PICLDebugElement)elem).getDebugTarget();

		if (dbgtarget == null || !(dbgtarget instanceof PICLDebugTarget) || dbgtarget.isTerminated()) {
			emptyFolderAndDisableActions();
			return;
		}

		//if we've got a tabfolder to go with the debugtarget, display it
		if (tabFolderHashtable.containsKey(dbgtarget)) {
			if (stackLayout.topControl != (TabFolder)tabFolderHashtable.get(dbgtarget)) {
				stackLayout.topControl = (TabFolder)tabFolderHashtable.get(dbgtarget);
				parent.layout();
			}
		} else {	//otherwise, add a new one
			tabFolderHashtable.put(dbgtarget, new TabFolder(parent, SWT.NULL));
			stackLayout.topControl = (TabFolder)tabFolderHashtable.get(dbgtarget);
			parent.layout();
		}

		//set toolbar actions enabled/disabled
		TabFolder folder = (TabFolder)stackLayout.topControl;
		int index = folder.getSelectionIndex();
		if (index >= 0) {
			fResetStorageMonitorAction.setEnabled(true);
			fRemoveStorageMonitorAction.setEnabled(true);
			fCopyStorageToolbarAction.setEnabled(true);
			fPrintStorageToolbarAction.setEnabled(true);
		} else {
			fResetStorageMonitorAction.setEnabled(false);
			fRemoveStorageMonitorAction.setEnabled(false);
			fCopyStorageToolbarAction.setEnabled(false);
			fPrintStorageToolbarAction.setEnabled(false);
		}
	}

	private void addListeners() {
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().addSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
		DebugPlugin.getDefault().addDebugEventListener(this);
	}
	
	private void removeListeners() {
		PICLDebugPlugin.getActiveWorkbenchWindow().getSelectionService().removeSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
		DebugPlugin.getDefault().removeDebugEventListener(this);
	}
	
	/**
	 * Installs the given action under the given action id.
	 *
	 * @param actionId the action id
	 * @param action the action, or <code>null</code> to clear it
	 * @see IDebugView#getAction
	 */
	public void setAction(String actionID, IAction action) {
//		if (action == null)
//			fActionMap.remove(actionID);
//		else
//			fActionMap.put(actionID, action);
	}	
	
	/**
	 * Returns the action installed under the given action id.
	 *
	 * @param actionId the action id
	 * @return the action, or <code>null</code> if none
	 * @see IDebugView#setAction
	 */
	public IAction getAction(String actionID) {
//		return (IAction) fActionMap.get(actionID);
		return null;
	}

	/**
	 * @see IDebugView#getPresentation(String)
	 */
	public IDebugModelPresentation getPresentation(String id) {
		return null;
	}

	/**
	 * @see IDebugView#getViewer()
	 */
	public Viewer getViewer() {
		if (getTopStorageTab() != null)
			return getTopStorageTab().getViewer();
		return null;
	}
	/**
	 * @see IDebugView#getContextMenuManager()
	 */
	public IMenuManager getContextMenuManager() {
		return null;
	}

}


