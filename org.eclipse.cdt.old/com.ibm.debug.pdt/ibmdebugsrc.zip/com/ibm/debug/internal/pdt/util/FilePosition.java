package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

/**
 * FilePosition represents a position within a record oriented file.
 */

public class FilePosition
{

   public int line = 0;
   public int pos  = 0;

   public FilePosition(int pos, int line)
   {
      this.pos = pos;
      this.line = line;
   }

   public FilePosition(FilePosition fp)
   {
      pos = fp.pos;
      line = fp.line;
   }

   public boolean equals(Object object)
   {
      if (object == null || !(object instanceof FilePosition))
      {
         return false;
      }

      FilePosition position = (FilePosition)object;
      if (position.line == line && position.pos == pos)
      {
         return true;
      }
      return false;
   }

   public boolean isGreaterThan(FilePosition fp)
   {
      if (fp == null)
      {
         return false;
      }
      if (line > fp.line)
      {
         return true;
      }
      else if (line == fp.line && pos > fp.pos)
      {
         return true;
      }
      return false;
   }

   public boolean isGreaterThanOrEqualTo(FilePosition fp)
   {
      if (fp == null)
      {
         return false;
      }
      if (line > fp.line)
      {
         return true;
      }
      else if (line == fp.line && pos >= fp.pos)
      {
         return true;
      }
      return false;
   }

   public boolean isLessThan(FilePosition fp)
   {
      if (fp == null)
      {
         return false;
      }
      if (line < fp.line)
      {
         return true;
      }
      else if (line == fp.line && pos < fp.pos)
      {
         return true;
      }
      return false;
   }

   public boolean isLessThanOrEqualTo(FilePosition fp)
   {
      if (fp == null)
      {
         return false;
      }
      if (line < fp.line)
      {
         return true;
      }
      else if (line == fp.line && pos <= fp.pos)
      {
         return true;
      }
      return false;
   }

   public String toString()
   {
      return "FilePosition(" + pos + "," + line + ")";
   }

}

