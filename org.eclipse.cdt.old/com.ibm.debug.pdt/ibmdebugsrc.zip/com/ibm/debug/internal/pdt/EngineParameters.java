package com.ibm.debug.internal.pdt;

import java.util.Hashtable;

import com.ibm.debug.daemon.DaemonConnectionInfo;
import com.ibm.debug.internal.pdt.util.DebuggerOptionDescriptor;
import com.ibm.debug.internal.pdt.util.DebuggerOptions;

/**
   * EngineParameters collects and saves the engine parameters sent
   * by the debug engine.
   */
  public abstract class EngineParameters extends DebuggerOptions
  {
    protected DaemonConnectionInfo connectionInfo;
    protected String title;
    protected String arguments;
    public final static int STOP = 0;
    public final static int RUN = 1;
    
    protected String host; 
    protected String port;

    protected final String OPTION_LAUNCHER         = "-launcher";
    protected final String OPTION_PROJECT          = "-project";
    protected final String OPTION_SOCKETSTYLE      = "-socketStyle";
    protected final String OPTION_STARTUPKEY       = "-startupKey";

    /**
     * The caller should clone the returned ConnectionInfo object
     * if it is to be saved for later use
     */
    public DaemonConnectionInfo getConnectionInfo()
    {
      return connectionInfo;
    }

    public String getTitle()
    {
      return title;
    }
    
    public String getHost()
    {
    	return host;
    }
    
    public String getPort()
    {
    	return port;
    }

    public String getArguments()
    {
      return arguments;
    }

    public abstract String getProgramName();
    public abstract String getProgramParms();
    public abstract int getLoadStartupBehaviour();
    public abstract int getAttachStartupBehaviour();
    public abstract String getProcessID();

    public String getProject()
    {
      return valueByName(OPTION_PROJECT);
    }

    public String getLauncher()
    {
      return valueByName(OPTION_LAUNCHER);
    }

    public String getSocketStyle()
    {
      return valueByName(OPTION_SOCKETSTYLE);
    }

    public String getStartupKey()
    {
      return valueByName(OPTION_STARTUPKEY);
    }

    public String getValue(String property)
    {
      return valueByName(property);
    }

    public Hashtable getPairs()
    {
      return null;
    }

   protected void setOptionDescriptors()
    {
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_LAUNCHER,         OPTION_LAUNCHER.length(),         true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_PROJECT,          OPTION_PROJECT.length(),          true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_SOCKETSTYLE,      OPTION_SOCKETSTYLE.length(),      true,  false));
      addOptionDescriptor(new DebuggerOptionDescriptor(OPTION_STARTUPKEY,       OPTION_STARTUPKEY.length(),       true,  false));
    }
  
 
  
}