package com.ibm.debug.internal.pdt.ui.actions;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.jface.action.Action;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.help.WorkbenchHelp;

import com.ibm.debug.internal.pdt.ui.views.StorageView;
import com.ibm.debug.internal.pdt.ui.views.StorageViewTab;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.pdt.PICLDebugPlugin;

public class ResetStorageMonitorAction extends Action {
	protected static final String PREFIX= "ResetStorageMonitorAction.";
	private StorageViewTab storageTab = null;

	/**
	 * Constructor for ResetStorageMonitorAction
	 */
	//intended for use with the StorageView
	public ResetStorageMonitorAction() {
		super(PICLUtils.getResourceString(PREFIX+"label"));
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip"));

		WorkbenchHelp.setHelp(this, PICLUtils.getHelpResourceString("ResetStorageMonitorAction"));
	}

	/**
	 * Constructor for ResetStorageMonitorAction
	 */
	//intended for use with the StorageViewTab
	public ResetStorageMonitorAction(StorageViewTab sTab) {
		super(PICLUtils.getResourceString(PREFIX+"label"));
		setToolTipText(PICLUtils.getResourceString(PREFIX+"tooltip"));
		storageTab = sTab;

		WorkbenchHelp.setHelp(this, PICLUtils.getHelpResourceString("ResetStorageMonitorAction"));
	}


	/**
	 * @see Action#run()
	 */
	public void run() {
		if (storageTab == null) {
			// get the StorageView
			IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
			if (p == null) { return; }
			IViewPart view= p.findView(IPICLDebugConstants.STORAGE_VIEW);
			if (view == null) {
				try {
					view= p.showView(IPICLDebugConstants.STORAGE_VIEW);
				} catch (PartInitException e) {
					PICLUtils.logError(e);
					return;
				}
			}
			p.bringToTop(view);
			if (!(view instanceof StorageView)) { return; }
			storageTab = ((StorageView)view).getTopStorageTab();
			if (storageTab != null) {
				storageTab.reloadTable(storageTab.getStorage().getAddress(), true);
			}
			storageTab = null;
		} else {
			storageTab.reloadTable(storageTab.getStorage().getAddress(), true);
		}
	}

}
