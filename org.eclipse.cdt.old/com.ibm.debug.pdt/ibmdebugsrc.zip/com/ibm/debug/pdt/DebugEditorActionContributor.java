package com.ibm.debug.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.text.source.IVerticalRuler;
import org.eclipse.ui.texteditor.ITextEditor;

import com.ibm.debug.internal.pdt.ui.actions.AddEditorBreakpointAction;
import com.ibm.debug.internal.pdt.ui.actions.AddSnippetToMonitorAction;
import com.ibm.debug.internal.pdt.ui.actions.AddSnippetToStorageMonitorAction;
import com.ibm.debug.internal.pdt.ui.actions.RunJumpToLocationBaseAction;
import com.ibm.debug.internal.pdt.ui.editor.BreakpointRulerAction;
import com.ibm.debug.internal.pdt.IPICLDebugConstants;
import com.ibm.debug.internal.pdt.PICLUtils;


/**
 * This class allows ITextEditors to add debug-specific actions to their main context menu and/or 
 * ruler context menu.
 */
public class DebugEditorActionContributor {


	//editor ruler menu action constants.
	// actions that the editor wants displayed should be bitwise OR'd together and passed to 
	// addDebugRulerActions(IMenuManager, int) after createDebugRulerActions(ITextEditor, IVerticalRuler) has been called
	/** Address Breakpoint Ruler Action constant specifier - see addDebugEditorRulerActions(IMenumanager, int) */
	public static final int ADDRESS_BKPT_RULER_ACTION	= 1 << 1;  //most editors should use the BREAKPOINT_RULER_ACTION (line breakpoints)
	
	/** Line Breakpoint Ruler Action constant specifier - see addDebugEditorRulerActions(IMenumanager, int) */
	public static final int BREAKPOINT_RULER_ACTION 		= 1 << 2;
	
	/** Jump To Location Ruler Action constant specifier - see addDebugEditorRulerActions(IMenumanager, int) */
	public static final int JUMP_RULER_ACTION					= 1 << 3;
	
	/** Run To Location Ruler Action constant specifier - see addDebugEditorRulerActions(IMenumanager, int) */
	public static final int RUN_RULER_ACTION					= 1 << 4;


	//editor context menu action constants.
	// actions that the editor wants displayed should be bitwise OR'd together and passed to 
	// addDebugMenuActions(IMenuManager, int) after createDebugMenuActions(ITextEditor) has been called
	/** Line Breakpoint Menu Action constant specifier - see addDebugEditorMenuActions(IMenumanager, int) */
	public static final int BREAKPOINT_MENU_ACTION		= 1 << 2;
	
	/** Jump To Location Menu Action constant specifier - see addDebugEditorMenuActions(IMenumanager, int) */
	public static final int JUMP_MENU_ACTION					= 1 << 3;
	
	/** Run To Location Menu Action constant specifier - see addDebugEditorMenuActions(IMenumanager, int) */
	public static final int RUN_MENU_ACTION					= 1 << 4;
	
	/** Monitor Expression Menu Action constant specifier - see addDebugEditorMenuActions(IMenumanager, int) */
	public static final int MONITOR_MENU_ACTION			= 1 << 5;
	
	/** Monitor Storage Menu Action constant specifier - see addDebugEditorMenuActions(IMenumanager, int) */
	public static final int STORAGE_MENU_ACTION			= 1 << 6;
	


	//ruler action names - these can be used to retrieve the action with getAction(String) from 
	//within the editor after createDebugRulerActions(ITextEditor, IVerticalRuler) has been called
	/**  Address Breakpoint Ruler Action name (id) used in setAction() and getAction() */
	public static final String ADDRESS_BKPT_RULER_ACTION_ID = "AddressBkptRulerAction";
	
	/**  Line Breakpoint Ruler Action name (id) used in setAction() and getAction() */
	public static final String BREAKPOINT_RULER_ACTION_ID	= "BreakpointRulerAction";
	
	/**  Jump To Location Ruler Action name (id) used in setAction() and getAction() */
	public static final String JUMP_RULER_ACTION_ID			= "JumpToLocationRulerAction";
	
	/**  Run To Location Ruler Action name (id) used in setAction() and getAction() */
	public static final String RUN_RULER_ACTION_ID				= "RunToLocationRulerAction";


	//context action names - these can be used to retrieve the action with getAction(String) 
	//from within the editor after createDebugMenuActions(ITextEditor) has been called
	/**  Line Breakpoint Menu Action name (id) used in setAction() and getAction() */
	public static final String BREAKPOINT_MENU_ACTION_ID	= "BreakpointMenuAction";
	
	/**  Jump To Location Menu Action name (id) used in setAction() and getAction() */
	public static final String JUMP_MENU_ACTION_ID				= "JumpToLocationMenuAction";
	
	/**  Run To Location Menu Action name (id) used in setAction() and getAction() */
	public static final String RUN_MENU_ACTION_ID				= "RunToLocationMenuAction";
	
	/**  Monitor Expression Menu Action name (id) used in setAction() and getAction() */
	public static final String MONITOR_MENU_ACTION_ID		= "AddSnippetToMonitorMenuAction";
	
	/**  Monitor Storage Menu Action name (id) used in setAction() and getAction() */
	public static final String STORAGE_MENU_ACTION_ID		= "AddSnippetToStorageMenuAction";


	//ruler actions
	private BreakpointRulerAction fAddressBreakpointRulerAction = null;
	private BreakpointRulerAction fLineBreakpointRulerAction = null;
	private RunJumpToLocationBaseAction fJumpToLocationRulerAction = null;
	private RunJumpToLocationBaseAction fRunToLocationRulerAction = null;

	//context menu actions
	private AddEditorBreakpointAction fAddBreakpointMenuAction = null;
	private RunJumpToLocationBaseAction fJumpToLocationMenuAction = null;
	private RunJumpToLocationBaseAction fRunToLocationMenuAction = null;
	private AddSnippetToMonitorAction fAddSnippetToMonitorMenuAction = null;
	private AddSnippetToStorageMonitorAction fAddSnippetToStorageMenuAction = null;


	
	public DebugEditorActionContributor() { }


	/**
	 * initialize the debug ruler actions
	 */
	public void createDebugRulerActions(ITextEditor editor, IVerticalRuler ruler) {

		fAddressBreakpointRulerAction = new BreakpointRulerAction(PICLUtils.getResourceBundle(),
																					"EditorAddBreakpoint.",
																					ruler,
																					editor,
																					IPICLDebugConstants.PICL_ADDRESS_BREAKPOINT);
		editor.setAction(ADDRESS_BKPT_RULER_ACTION_ID, fAddressBreakpointRulerAction);

		fLineBreakpointRulerAction = new BreakpointRulerAction(PICLUtils.getResourceBundle(),
																					"EditorAddBreakpoint.",
																					ruler,
																					editor,
																					IPICLDebugConstants.PICL_LINE_BREAKPOINT);
		editor.setAction(BREAKPOINT_RULER_ACTION_ID, fLineBreakpointRulerAction);

		fJumpToLocationRulerAction = new RunJumpToLocationBaseAction(editor, ruler, true, true);
		editor.setAction(JUMP_RULER_ACTION_ID, fJumpToLocationRulerAction);

		fRunToLocationRulerAction = new RunJumpToLocationBaseAction(editor, ruler, true, false);
		editor.setAction(RUN_RULER_ACTION_ID, fRunToLocationRulerAction);
	}


	/**
	 * initialize the debug context menu actions
	 */
	public void createDebugMenuActions(ITextEditor editor) {
		
		fAddBreakpointMenuAction = new AddEditorBreakpointAction(editor);
		editor.setAction(BREAKPOINT_MENU_ACTION_ID, fAddBreakpointMenuAction);

		fJumpToLocationMenuAction = new RunJumpToLocationBaseAction(editor, null, false, true);
		editor.setAction(JUMP_MENU_ACTION_ID, fJumpToLocationMenuAction);

		fRunToLocationMenuAction = new RunJumpToLocationBaseAction(editor, null, false, false);
		editor.setAction(RUN_MENU_ACTION_ID, fRunToLocationMenuAction);

		fAddSnippetToMonitorMenuAction = new AddSnippetToMonitorAction(editor);
		editor.setAction(MONITOR_MENU_ACTION_ID, fAddSnippetToMonitorMenuAction);

		fAddSnippetToStorageMenuAction = new AddSnippetToStorageMonitorAction(editor);
		editor.setAction(STORAGE_MENU_ACTION_ID, fAddSnippetToStorageMenuAction);
	}
	

	/** 
	 * add the ruler actions to the menu
	 * createDebugRulerActions(ITextEditor editor, IVerticalRuler ruler) must have been called before this method is used
	 * 
	 * Note: this will not affect the "double-click on vertical ruler" action.  If editors also wish to associate the vertical 
	 * ruler double-click action with the standard "Add Breakpoint" action they should do it themselves with this call :
	 * 	setAction(ITextEditorActionConstants.RULER_DOUBLE_CLICK,  getAction(DebugEditorActionContributor.BREAKPOINT_RULER_ACTION_ID));
	 */
	public void addDebugEditorRulerActions(IMenuManager menu, int flags) {
		//either fLineBreakpointRulerAction or fAddressBreakpointRulerAction is allowed, not both
		if ((flags & BREAKPOINT_RULER_ACTION) != 0) { //default to LineBreakPointAction
			fLineBreakpointRulerAction.update();
			menu.add(fLineBreakpointRulerAction);
		} else if ((flags & ADDRESS_BKPT_RULER_ACTION) != 0) {
			fAddressBreakpointRulerAction.update();
			menu.add(fAddressBreakpointRulerAction);
		}
		if ((flags & JUMP_RULER_ACTION) != 0) {
			menu.add(fJumpToLocationRulerAction);
		}
		if ((flags & RUN_RULER_ACTION) != 0) {
			menu.add(fRunToLocationRulerAction);
		}
	}

	/** 
	 * add the context actions to the menu
	 * createDebugMenuActions(ITextEditor editor) must have been called before this method is used
	 */
	public void addDebugEditorMenuActions(IMenuManager menu, int flags) {

		if ((flags & BREAKPOINT_MENU_ACTION) != 0) {		
			fAddBreakpointMenuAction.update();
			menu.add(fAddBreakpointMenuAction);
		}
		if ((flags & JUMP_MENU_ACTION) != 0) {
			menu.add(fJumpToLocationMenuAction);
		}
		if ((flags & RUN_MENU_ACTION) != 0) {
			menu.add(fRunToLocationMenuAction);
		}
		if ((flags & MONITOR_MENU_ACTION) != 0) {
			menu.add(fAddSnippetToMonitorMenuAction);
		}
		if ((flags & STORAGE_MENU_ACTION) != 0) {		
			menu.add(fAddSnippetToStorageMenuAction);
		}
	}

}
