////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */
package com.ibm.debug.pdt.launch;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.core.ILaunchConfigurationType;
import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.core.model.ILaunchConfigurationDelegate;
import org.eclipse.debug.ui.IDebugUIConstants;

import com.ibm.debug.daemon.CoreDaemon;
import com.ibm.debug.daemon.DaemonConnectionInfo;
import com.ibm.debug.daemon.IDaemonDebugTarget;
import com.ibm.debug.daemon.IOldDaemonDefaultSupport;
import com.ibm.debug.internal.pdt.OldEngineParameters;
import com.ibm.debug.internal.pdt.PICLUtils;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////
/**
 * @version 	1.0
 * @author
 */
public class OldDaemonDefaultLaunchConfigurationDelegate
	implements IOldDaemonDefaultSupport, ILaunchConfigurationDelegate//, ILauncherDelegate
{
	private static final String LAUNCHER = "OldDaemonDefaultLaunchConfigurationDelegate";
	
	
	/*
	 * @see ILauncherDelegate#launch(Object[], String, ILauncher)
	 */
	//public boolean launch(Object[] elements, String mode, ILauncher launcher)
//	{
//		if(version > 0)
//		{
//			PICLUtils.logText("In default Launcher");			
//			engineParameters = new OldEngineParameters();			
//			engineParameters.setInfo(stringArray);
//			
//			//GDB should go through here
//			if(engineParameters.getStartupKey()!=null)
//			{
//				PICLUtils.logText("Startup key found");
//				PICLUtils.logText("Host/Port="+engineParameters.getConnectionInfo().getHost()+engineParameters.getConnectionInfo().getConduit());
//				DaemonConnectionInfo connectionInfo = new DaemonConnectionInfo(engineParameters.getConnectionInfo().getHost(),
//																				engineParameters.getConnectionInfo().getConduit());
//				
//				IDebugTarget debugTarget = CoreDaemon.retrieveDebugTarget(Integer.parseInt(engineParameters.getStartupKey()) );
//				
//				if(debugTarget != null)
//				{
//					PICLUtils.logText("calling debug target.engineIsWaiting()");
//					((IDaemonDebugTarget)debugTarget).engineIsWaiting(socket, connectionInfo);
//				}				
//				return true;
//			}
//				
//			
//			engineParameters.getConnectionInfo().setConnection(socket);
//			
//			//daemon does not parse info, so it may have defaulted to wrong launcher
//			if(engineParameters.isJavaAttach())
//			{
//				PICLUtils.logText("Should be using java attach launcher instead");
//				ILauncher loadLauncher = findLauncher("org.eclipse.jdt.debug.ui.launcher.JDIAttachLauncher");
//				ILauncherDelegate loadLauncherDelegate = loadLauncher.getDelegate(); 
//				if(loadLauncherDelegate == null)
//		    		return false;//bail
//	    		//((IOldDaemonDefaultSupport)loadLauncherDelegate).setInputParametersAsStrings(stringArray, key, version);
//	        	String xml = "<?xml version='1.0' encoding='UTF-8'?> <kicker host='"+engineParameters.getConnectionInfo().getHost()+"' port='"+engineParameters.getConnectionInfo().getConduit()+"'	allowTerminate='true'></kicker>";			
//	        	try{
//		    		((IDaemonSupport)loadLauncherDelegate).setConnectionInfo(xml.getBytes("UTF-8"),key, version);
//	        	}catch(UnsupportedEncodingException e){((IDaemonSupport)loadLauncherDelegate).setConnectionInfo(xml.getBytes(),key, version);}
//	    		((IDaemonSupport)loadLauncherDelegate).setSocket(socket);
//	    		// reuse??((PICLLoadLauncher)	loadLauncherDelegate).setEngineParameters(engineParameters);  		
//	    		//return ((PICLLoadLauncher)loadLauncherDelegate).launch(elements, ILaunchManager.DEBUG_MODE,loadLauncher);
//	    		return loadLauncherDelegate.launch(elements, ILaunchManager.DEBUG_MODE,loadLauncher);
//			}
//			if(!engineParameters.isAttach())  
//			{
//				PICLUtils.logText("Should be using load launcher instead");
//				//start load launcher instead
//				ILauncher loadLauncher = findLauncher("com.ibm.debug.launchers.PICLLoadLauncher");
//				ILauncherDelegate loadLauncherDelegate = loadLauncher.getDelegate(); 
//				if(loadLauncherDelegate == null || !(loadLauncherDelegate instanceof IOldDaemonDefaultSupport))					
//		    		return false;//bail
//	    		((IOldDaemonDefaultSupport)loadLauncherDelegate).setInputParametersAsStrings(stringArray, key, version);
//	    		((IOldDaemonDefaultSupport)loadLauncherDelegate).setSocket(socket);
//	    		if(loadLauncherDelegate instanceof IOldEngineParameters)
//		    		((IOldEngineParameters)	loadLauncherDelegate).setOldEngineParameters(engineParameters);  		
//	    		return loadLauncherDelegate.launch(elements, ILaunchManager.DEBUG_MODE,loadLauncher);	    		
//			} else
//			{
//				PICLUtils.logText("Should be using attach launcher");
//				//start load launcher instead
//				ILauncher loadLauncher = findLauncher("com.ibm.debug.launchers.PICLAttachLauncher");
//				ILauncherDelegate loadLauncherDelegate = loadLauncher.getDelegate(); 
//				if(loadLauncherDelegate == null || !(loadLauncherDelegate instanceof IOldDaemonDefaultSupport)
//					|| !(loadLauncherDelegate instanceof IOldEngineParameters))
//		    		return false;//bail
//	    		((IOldDaemonDefaultSupport)loadLauncherDelegate).setInputParametersAsStrings(stringArray, key, version);
//	    		((IOldDaemonDefaultSupport)loadLauncherDelegate).setSocket(socket);
//	    		if(loadLauncherDelegate instanceof IOldEngineParameters)
//	    			((IOldEngineParameters)loadLauncherDelegate).setOldEngineParameters(engineParameters);  		
//	    		return loadLauncherDelegate.launch(elements, ILaunchManager.DEBUG_MODE,loadLauncher);	    		
//			}
//		}//end if version >0
//		else if( version == -1)
//		{
//			PICLUtils.logText("Unsupported version");  //todo error message				
//			return false;
//		}
//		
//		return true;
//	}
	
	public boolean figureOutWhatToDo(CoreDaemon.OldDaemonInput input)
	{
		PICLUtils.logText("In default Launcher");
					
		OldEngineParameters engineParameters = new OldEngineParameters();			
		engineParameters.setInfo(input.getInputArray());
		engineParameters.getConnectionInfo().setConnection(input.getSocket());
		
		//CASE 1: CHECK IF ALL WE NEED TO DO IS TELL TARGET THAT ENGINE IS HERE
		if(engineParameters.getStartupKey()!=null)
		{
			PICLUtils.logText("Startup key found");
			PICLUtils.logText("Host/Port="+engineParameters.getConnectionInfo().getHost()+engineParameters.getConnectionInfo().getConduit());
			DaemonConnectionInfo connectionInfo = new DaemonConnectionInfo(engineParameters.getConnectionInfo().getHost(),
																				engineParameters.getConnectionInfo().getConduit());
				
			IDebugTarget debugTarget = CoreDaemon.retrieveDebugTarget(Integer.parseInt(engineParameters.getStartupKey()) );
			
			if(debugTarget != null)
			{
				PICLUtils.logText("calling debug target.engineIsWaiting()");
				((IDaemonDebugTarget)debugTarget).engineIsWaiting(connectionInfo);
			}				
			return true;
		}
		//CASE 2: TELL SOMEONE ELSE TO TAKE CARE OF IT
		if(!engineParameters.isAttach())  
		{
				PICLUtils.logText("Should be using load launcher instead");
				//start load launch config
				ILaunchConfiguration loadLaunchConfig = createLaunchConfig("com.ibm.debug.loadPICLApplication", input);
				boolean result;
				try{
					if(loadLaunchConfig == null)
						return false; //else return error
					loadLaunchConfig.launch(ILaunchManager.DEBUG_MODE, null);  //todo progress monitor
					
					loadLaunchConfig.delete();  //remove launch config
					return true;
				}catch(CoreException e){}
				
		} else 
		{
				PICLUtils.logText("Should be using attach launcher");
				//start attach launch config
				ILaunchConfiguration attachLaunchConfig = createLaunchConfig("com.ibm.debug.attachPICLApplication", input);
				boolean result;
				try{
					if(attachLaunchConfig == null)
						return false; //else return error
					attachLaunchConfig.launch(ILaunchManager.DEBUG_MODE, null);  //todo progress monitor
					
					attachLaunchConfig.delete();  //remove launch config
					return true;
				}catch(CoreException e){}
				    		
		}
		return false;	
	}

	/*
	 * @see ILauncherDelegate#getLaunchMemento(Object)
	 */
	public String getLaunchMemento(Object element)
	{
		return null;
	}

	/*
	 * @see ILauncherDelegate#getLaunchObject(String)
	 */
	public Object getLaunchObject(String memento)
	{
		return null;
	}
	
//	private ILauncher findLauncher(String id)
//  	{
//  		ILauncher[] registeredLaunchers = DebugPlugin.getDefault().getLaunchManager().getLaunchers();
//    	ILauncher launcher =null;  //the launcher associated with the delegate
//    	
//    	for(int i=0; i< registeredLaunchers.length; i++)
//    	{        		
//        		if(registeredLaunchers[i].getIdentifier().equals(id))        			
//        			launcher = registeredLaunchers[i];    			   		 
//        		      		
//    	}
//    	
//    	return launcher;   
//  	}
  	
  	private static ILaunchConfigurationWorkingCopy createLaunchConfig(String configID, CoreDaemon.OldDaemonInput input)
  	{
  		ILaunchConfiguration config = null;
  		ILaunchConfigurationWorkingCopy workingConfig = null;
  		int key = -1;
  		ILaunchConfigurationType configType = 
  					DebugPlugin.getDefault().getLaunchManager().getLaunchConfigurationType(configID);
  		if(configType == null)
  			return null;
  		try{//leave container null. 
	  		config = configType.newInstance(null, "com.ibm.debug.defaultAttach");
	  		workingConfig = config.getWorkingCopy();
	  		//make launch private so it can't be relaunched
	  		workingConfig.setAttribute(IDebugUIConstants.ATTR_PRIVATE, true);
	  		//todo - check if key needs to be used from startup
	  		workingConfig.setAttribute("Key", key=CoreDaemon.generateKey());
	  		workingConfig.setAttribute("Daemon", true);
	  		workingConfig.doSave();
	  		CoreDaemon.storeOldDaemonInput(key, input);
  		}catch(CoreException e){}
  		return workingConfig;
  	}  	
  	
  	
	/**
	 * @see ILaunchConfigurationDelegate#launch(ILaunchConfiguration, String, ILaunch, IProgressMonitor)
	 */
	public void launch(
		ILaunchConfiguration configuration,
		String mode,
		ILaunch launch,
		IProgressMonitor monitor)
		throws CoreException {
	}

}
