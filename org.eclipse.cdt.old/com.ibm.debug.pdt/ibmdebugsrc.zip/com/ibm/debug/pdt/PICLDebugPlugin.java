package com.ibm.debug.pdt;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.debug.core.DebugPlugin;
import org.eclipse.debug.core.ILaunch;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.debug.core.ILauncher;
import org.eclipse.debug.core.Launch;
import org.eclipse.debug.core.model.IDebugElement;
import org.eclipse.debug.core.model.IDebugTarget;
import org.eclipse.debug.ui.IDebugUIConstants;
import org.eclipse.debug.ui.IDebugView;
import org.eclipse.jface.action.IContributionItem;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.ISelectionListener;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.plugin.AbstractUIPlugin;

import com.ibm.debug.daemon.CoreDaemon;
import com.ibm.debug.internal.pdt.ui.actions.DebugViewMenuListener;
import com.ibm.debug.internal.pdt.ui.editor.DebuggerDocumentProvider;
import com.ibm.debug.internal.pdt.PICLDebugTarget;
import com.ibm.debug.internal.pdt.PICLUtils;
import com.ibm.debug.pdt.launch.PICLStartupInfo;
import com.ibm.debug.internal.pdt.util.EclipseLogger;

/**
 * Represents the compiled PICL plugin
 */
public class PICLDebugPlugin extends AbstractUIPlugin implements ISelectionListener {


	private final static String PLUGIN = "PICLDebugPlugin";

	private static PICLDebugPlugin instance;
	private boolean breakpointActionsForced = false;
	private boolean debugViewMenuListenerAdded = false;
	private DebuggerDocumentProvider editorDocumentProvider = null;
	public static EclipseLogger LOG;
	private static IPluginDescriptor fPluginDescriptor = null;

	// logging settings
	public static boolean logging = false;
	public static boolean events = false;
	public static boolean dumpEPDC = false;
	public static String dumpFile = "epdcdump";
	public static String DBG = null;
	public static String EVT = null;
	public static String ERR = null;
	public static boolean MODEL = false;
	public static ILog logFile = null;
	
	/**
	 * Constructor for PICLDebugPlugin
	 */
	public PICLDebugPlugin(IPluginDescriptor descriptor) {
		super(descriptor);
		instance = this;
		try {
			getActiveWorkbenchWindow().getSelectionService().addSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
		} catch(Exception e) {
			return;
		}

		// Code copied from GDBViewPlugin
		fPluginDescriptor = getDescriptor();
		
		// load the logging settings
		// only if the main debug setting is on
		if (isDebugging()) {
			
			logFile = getLog();
			
			String id = fPluginDescriptor.getUniqueIdentifier();
			String test = Platform.getDebugOption(id + "/debug/events");
			if (test != null)
				events = test.equals("true");
			test = Platform.getDebugOption(id + "/debug/logging");
			if (test !=null)
				logging = test.equals("true");
			
			test = Platform.getDebugOption(id + "/debug/dumpepdc");
			if (test != null)
				dumpEPDC = test.equals("true");				
			
			test = Platform.getDebugOption(id + "/debug/dumpfile");
			if (test != null)
				dumpFile = test;
				
			test = Platform.getDebugOption(id + "/debug/jt_dbg");
			if (test != null) 
				DBG = test;

			test = Platform.getDebugOption(id + "/debug/jt_evt");
			if (test != null) 
				EVT = test;
				
			test = Platform.getDebugOption(id + "/debug/jt_err");
			if (test != null)
				ERR = test;

			test = Platform.getDebugOption(id + "/debug/model");
			if (test != null) {
				MODEL = test.equals("true");
				if (MODEL)
					DBG = "3";  // in order for model to work DBG must also be on.
			}
				
		}

		String componentName = fPluginDescriptor.getResourceString("%GdbViewLoggerName");
		LOG = new EclipseLogger(this,componentName);

		PICLUtils.logText("PICLDebugPlugin loaded");
	}

	public static String getPluginID() {
		return fPluginDescriptor.getUniqueIdentifier();
	}

	public static PICLDebugPlugin getInstance() {
		return instance;
	}

	public static PICLDebugPlugin getDefault() {
		return instance;
	}

	public void startup() throws CoreException {
		PICLUtils.logText("In startup()");
		super.startup();
	}

	/**
	 * @see Plugin#shutdown()
	 */
	public void shutdown() throws CoreException {
		PICLUtils.logText("In shutdown()");
		try {
			getActiveWorkbenchWindow().getSelectionService().removeSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
		} catch(Exception e) {}
		super.shutdown();
	}

	public static IWorkbenchWindow getActiveWorkbenchWindow() {
		try {
			return getDefault().getWorkbench().getActiveWorkbenchWindow();
		} catch(NullPointerException e) {
			return null;
		}
	}

	/**
	 * Returns the active workbench shell.
	 * Note: This method should only be called from a UI thread.
	 * When running on a non-UI thread, use getShell() method.
	 */
	public static Shell getActiveWorkbenchShell() {
		return getActiveWorkbenchWindow().getShell();
	}

	/**
	 * Returns the currently selected debug target in the Debug View
	 * Returns the first <code>IDebugTarget</code> that has a launch and is associated with a debug target.
	 * If no debug targets, returns null.
	 */
	public static IDebugTarget determineCurrentDebugTarget() {

		IWorkbenchWindow w= PICLDebugPlugin.getActiveWorkbenchWindow();
		if (w == null) return null;

		IWorkbenchPage p= w.getActivePage();
		if (p == null) return null;

		IViewPart view= p.findView(IDebugUIConstants.ID_DEBUG_VIEW);
		if ((view==null) || !(view instanceof IDebugView)) return null;

		try {
			view= p.showView(IDebugUIConstants.ID_DEBUG_VIEW);
		} catch (PartInitException e) {
			PICLUtils.logError(e);
			return null;
		}

		Viewer viewer = ((IDebugView)view).getViewer();
		if (viewer == null) return null;

		ISelection sel = viewer.getSelection();
		if ((sel == null) || !(sel instanceof IStructuredSelection)) return null;
		
		Object elem = ((IStructuredSelection)sel).getFirstElement();
		if (elem == null) return null;
		
		//a Launch is not an IDebugElement, but its debugtarget should be
		if (elem instanceof Launch) {
			elem = ((Launch)elem).getDebugTarget();
		}

		//any IDebugElement can get its debugtarget
		if (! (elem instanceof IDebugElement) ) return null;
		return ((IDebugElement)elem).getDebugTarget();
	}

	/**
	 * Allows access to the protected method super.saveDialogSettings().
	 */
	public void saveDialogSettings()
	{
		super.saveDialogSettings();  //protected method
	}

	/**
	 * Sends a selection event to the breakpoints view to force creation of
	 * Exception/Breakpoint actions. This is necessary to ensure correct enablement of
	 * the actions when a picl debug element is selected in the stack frame.
	 * This will not disrupt the current selection, if any.
	 * This may fail if the breakpoint view is not showing in the debug perspective.
	 */
	private boolean activateBPViewActions()
	{
		IWorkbenchPage p= getActiveWorkbenchWindow().getActivePage();
		if (p == null) 	return false;
		IViewPart view= p.findView(IDebugUIConstants.ID_BREAKPOINT_VIEW);
		if ((view != null) && (view instanceof IDebugView)) 
		{
			((IDebugView)view).getViewer().setSelection(((IDebugView)view).getViewer().getSelection());
			return true;
		}
		return false;

	}
	
	
	/**
	 * Launch a debug session using the given startup info and the
	 * connection key.
	 * @param startupInfo The info used to start debugging.  May be
	 *                    null to indicate that the launch was cancelled
	 *	              and the debug engine should be released.
	 * @param connectionKey Key for retrieving the engine connection info.
	 *		        Must be the same key that was passed to
	 *                      either the wizard or launcher.  If connectionKey
         *                      is not valid, launchDebugSession does nothing.
	 */
	/*public static void launchDebugSession(PICLStartupInfo startupInfo, int connectionKey) {
		
		if(connectionKey <= 0)
		{
			PICLUtils.logText("Missing or invalid connection key");
			return;
		}
		PICLDebugTarget target = (PICLDebugTarget) CoreDaemon.retrieveDebugTarget(connectionKey);
		
		if(target == null)
		{
			PICLUtils.logText("Error - target not found by daemon using key");
			return;
		}
		launchDebugSession(startupInfo, target); 
		
	}*/
	
	
	/**
	 * Launch a debug session.
	 * @param startupInfo The startup info to use to launch.  If null then
	 *                    the session will be terminated immediately.
	 * @param connectionInfo The info for connecting to the engine.
	 */
/*	public static void launchDebugSession(PICLStartupInfo startupInfo,
											 PICLDebugTarget target) {
		if (startupInfo != null) {
			ILaunch launch =
				new Launch(startupInfo.getLauncher(),
							ILaunchManager.DEBUG_MODE,
							startupInfo.getProject(),
							startupInfo.getWorkspaceSourceLocator(),
							null,
							target);
			DebugPlugin.getDefault().getLaunchManager().registerLaunch(launch);
		}

		target.engineIsReadyToConnect(startupInfo, target.getConnectionInfo());
	}*/
  /* PICLDebugUIDaemon public static void terminateEngine(ConnectionInfo connectionInfo) {
        if(!connectionInfo.isClosed()) {
            PICLDebugTarget target = new PICLDebugTarget();
            target.engineIsReadyToConnect(null, connectionInfo);
            connectionInfo.setClosed(true);
        }
    }*/

	

        /**
         * Terminate the debug engine.  This is used when the engine was
         * started by the user but hit cancel in the startup wizard.
         * @param connectionKey Key for retrieving the engine connection info.
	 *		        Must be the same key that was passed to
	 *                      either the wizard or launcher.  If connectionKey
         *                      is not valid, terminateEngine does nothing.
	 */
	/*public static void terminateEngine(Object connectionKey) {
		if(connectionKey instanceof ConnectionInfo) {
			PICLDebugUIDaemon.terminateEngine((ConnectionInfo)connectionKey);
		}
	}*/

	
	/**
	 * Returns whether the given launcher should be visible in the UI.
	 * If a launcher is not visible, it will not appear
	 * in the UI - i.e. not as a default launcher, not in the run/debug
	 * drop downs, and not in the launch history.
	 * Based on the public attribute.
	 */
	public boolean isVisible(ILauncher launcher) {
		IConfigurationElement e = launcher.getConfigurationElement();
		String publc=  e.getAttribute("public");
		if (publc == null || publc.equals("true")) {
			return true;
		}
		return false;
	}


	/**
 	* Debug ui thread safe access to a shell
 	*/
	public Shell getShell() {
		IWorkbench workbench= getWorkbench();
		if (workbench != null) {
			IWorkbenchWindow[] windows= workbench.getWorkbenchWindows();
			Display display= null;
			if (windows != null && windows.length > 0) {
				Shell shell= windows[0].getShell();
				if (!shell.isDisposed()) {
					return shell;
				}
			}
		}
		return null;
	}

	/**
 	* Debug ui thread safe access to a display
 	*/
	public Display getDisplay() {
		Shell shell = getShell();
		if (shell != null)
			return shell.getDisplay();

		return null;
	}



	/**
	 * Returns whether the given launcher specifies a wizard.
	 */
	public boolean hasWizard(ILauncher launcher) {
		IConfigurationElement e = launcher.getConfigurationElement();
		return e.getAttribute("wizard") != null;
	}

	/**
 	* Creates an extension.  If the extension plugin has not
 	* been loaded a busy cursor will be activated during the duration of
 	* the load.
 	*
 	* @param element the config element defining the extension
 	* @param classAttribute the name of the attribute carrying the class
 	* @returns the extension object
 	*/
	public static Object createExtension(final IConfigurationElement element, final String classAttribute) throws CoreException {
		// If plugin has been loaded create extension.
		// Otherwise, show busy cursor then create extension.
		IPluginDescriptor plugin = element.getDeclaringExtension().getDeclaringPluginDescriptor();
		if (plugin.isPluginActivated()) {
			return element.createExecutableExtension(classAttribute);
		} else {
			final Object [] ret = new Object[1];
			final CoreException [] exc = new CoreException[1];
			BusyIndicator.showWhile(null, new Runnable() {
				public void run() {
					try {
						ret[0] = element.createExecutableExtension(classAttribute);
					} catch (CoreException e) {
						exc[0] = e;
					}
				}
			});
			if (exc[0] != null) {
				throw exc[0];
			}
			else {
				return ret[0];
			}
		}
	}

	protected static void displayError(String titleCode, String msgCode) {
		String title = PICLUtils.getResourceString(titleCode);
		String msg = PICLUtils.getResourceString(msgCode);
		MessageDialog.openError(PICLDebugPlugin.getActiveWorkbenchShell(), title, msg);
	}

	/**
	 * Returns the document provider used for the debugger's editor
	 */
	public DebuggerDocumentProvider getDebuggerEditorDocumentProvider() {
		if (editorDocumentProvider == null)
			editorDocumentProvider = new DebuggerDocumentProvider();
		return editorDocumentProvider;
	}

//	/**
//	 * @see ISelectionChangedListener#selectionChanged(SelectionChangedEvent)
//	 */
//	public void selectionChanged(SelectionChangedEvent event) {
	/**
	 * @see ISelectionListener#selectionChanged(IWorkbenchPart, ISelection)
	 */
	public void selectionChanged(IWorkbenchPart part, ISelection selection) {
		

//		if(!breakpointActionsForced) {
//			breakpointActionsForced=activateBPViewActions();					
//		}
		
		IWorkbenchPage p= PICLDebugPlugin.getActiveWorkbenchWindow().getActivePage();
		if (p == null) { return; }
		IViewPart view= p.findView(IDebugUIConstants.ID_DEBUG_VIEW);
		if (view == null) {
			try {
				IWorkbenchPart activePart= p.getActivePart();
				view= p.showView(IDebugUIConstants.ID_DEBUG_VIEW);
				p.activate(activePart);
			} catch (PartInitException e) {
				PICLUtils.logError(e);
				return;
			}
		}
		if ((view != null) && (!debugViewMenuListenerAdded)) {
			IDebugView dv = (IDebugView) view;
			DebugViewMenuListener dmListener = new DebugViewMenuListener(dv);
			IMenuManager mm = dv.getViewSite().getActionBars().getMenuManager();
			mm.addMenuListener(dmListener);
			
			// Look for the PreferredView group that was added in our plugin.xml for the DebugView
			IContributionItem preferred = mm.find("PreferredView");
			if (preferred != null)
				mm.insertBefore(preferred.getId(), new Separator("ViewSwitching"));
			else 
				mm.add(new Separator("ViewSwitching"));
							
			debugViewMenuListenerAdded = true;
			getActiveWorkbenchWindow().getSelectionService().removeSelectionListener(IDebugUIConstants.ID_DEBUG_VIEW, this);
		}
	}

}
