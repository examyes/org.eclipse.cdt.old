package com.ibm.debug.pdt;

/**
 * Constants for use with the PDT plugin
 */
public interface IPDTDebugConstants {
	
	

}
