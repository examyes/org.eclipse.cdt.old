package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Enable Breakpoint reply
 */
public class ERepBreakpointEnable extends EPDC_BasicReply {

   public ERepBreakpointEnable() {
      super(EPDC.Remote_BreakpointEnable);
   }



}
