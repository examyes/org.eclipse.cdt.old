package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;
import java.util.*;

public class ERepStringFind extends EPDC_Reply
{

   public ERepStringFind(int line, int column)
   {
      super(EPDC.Remote_StringFind);
      _line   = line;
      _column = column;
   }

   ERepStringFind( byte[] packetBuffer, DataInputStream dataInputStream, EPDC_EngineSession engineSession)
   throws IOException
   {
      super( packetBuffer, dataInputStream, engineSession);

      _line   = dataInputStream.readInt();
      _column = dataInputStream.readInt();
   }

   public int getLineNumber()
   {
     return _line;
   }

   public int getColumnNumber()
   {
     return _column;
   }

   protected int fixedLen()
   {
      return super.fixedLen() + _fixed_length;
   }

   protected int varLen()
   {
      return super.varLen();
   }

   /** Output class to data streams according to EPDC protocol.
     * @exception IOException if an I/O error occurs
    *  @exception BadEPDCCommandException if the EPDC command
    *    is structured incorrectly
    */
   protected int toDataStreams(DataOutputStream fixedData,
         DataOutputStream varData, int baseOffset)
         throws IOException, BadEPDCCommandException
   {
      super.toDataStreams(fixedData, varData, baseOffset);

      writeInt(fixedData, _line);
      writeInt(fixedData, _column);

      return fixedLen() + varLen();
   }

   // Data fields
   private int _line;
   private int _column;

   private static final int _fixed_length = 8;

}
