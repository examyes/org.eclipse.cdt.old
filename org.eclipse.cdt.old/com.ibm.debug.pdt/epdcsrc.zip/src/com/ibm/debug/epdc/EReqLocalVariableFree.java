package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Local variable free request packet
 */
public class EReqLocalVariableFree extends EPDC_Request {

   /**
    * Decodes request from an input buffer
    * @exception IOException if an I/O error occurs
    */
   protected EReqLocalVariableFree (byte[] inBuffer) throws IOException {
      super(inBuffer);

      _localVarDU = readInt();
      readShort();   // reserved
   }

   public EReqLocalVariableFree(int threadID)
   {
     super(EPDC.Remote_LocalVariableFree);

     _localVarDU = threadID;
  }

   /**
    * Return disptachible unit
    */
   public int getDU() {
      return _localVarDU;
   }

   
   /**
    * Return the length of the fixed component
    */
   protected int fixedLen()
   {
      return _fixed_length + super.fixedLen();
   }

   void output(DataOutputStream dataOutputStream)
   throws IOException
   {
     super.output(dataOutputStream);

     dataOutputStream.writeInt(_localVarDU);
     dataOutputStream.writeShort(0);  // reserved
   }

   // data fields
   private int _localVarDU;

   private static final int _fixed_length = 6;


}
