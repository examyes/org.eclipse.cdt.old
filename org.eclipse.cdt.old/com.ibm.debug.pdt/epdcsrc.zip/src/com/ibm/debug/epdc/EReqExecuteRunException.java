package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


public class EReqExecuteRunException extends EReqExecute
{
  public EReqExecuteRunException(int DU, short viewID)
  {
    super(DU, EPDC.Exec_GoExceptionRun, new EStdView((short)0, viewID, 0, 0));
  }


}
