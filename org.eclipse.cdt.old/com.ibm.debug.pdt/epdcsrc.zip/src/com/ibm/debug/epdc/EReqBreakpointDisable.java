package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Disable breakpoint request
 */
public class EReqBreakpointDisable extends EPDC_Request {

   /**
    * Decodes request from an input buffer
    * @exception IOException if an I/O error occurs
    */
   EReqBreakpointDisable(byte[] inBuffer) throws IOException {
      super(inBuffer);

      _bkpID = readInt();
   }

   public EReqBreakpointDisable(int id)
   {
      super(EPDC.Remote_BreakpointDisable);

      _bkpID = id;
   }

   /**
    * Return breakpoint ID
    */
   public int bkpID() {
      return _bkpID;
   }

   protected int fixedLen()
   {
      return _fixed_length + super.fixedLen();
   }

   void output(DataOutputStream dataOutputStream)
   throws IOException
   {
      super.output(dataOutputStream);

      dataOutputStream.writeInt(_bkpID);
   }

   // Data fields
   private int _bkpID;

   private static final int _fixed_length = 4;


}

