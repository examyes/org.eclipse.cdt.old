package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Request to execute a debug engine command
 * New in EPDC level 308
 */
public class EReqCommandLog extends EReqLog {


	
	/**
	 * Constructor for EReqCommandLog.
	 * @param inBuffer
	 * @throws IOException
	 */
	protected EReqCommandLog(byte[] inBuffer) throws IOException {
		super(inBuffer);
	}

	/**
	 * Constructor to create the initial request
	 * Follow this with a call to output() to send the request
	 * @param The command string
	 */

	public EReqCommandLog(String cmd) {
		super(EPDC.Remote_CommandLog,cmd);
	}

}
