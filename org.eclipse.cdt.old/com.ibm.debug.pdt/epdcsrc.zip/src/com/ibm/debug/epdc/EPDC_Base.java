package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

/**
* The base class that all EPDC classes extend
*
*/
abstract class EPDC_Base implements java.io.Serializable {
	/**
	* Used to decode an input reply/request
	* @exception IOException if an I/O error occurs
	*/
	protected EPDC_Base(byte[] inBuffer) throws IOException {
		_in_command = new DataInputStream(new ByteArrayInputStream(inBuffer));
		_length = _in_command.available();
		_offset = 0;
	}

	/**
	* Used to decode an input reply/request, starting at a specific offset
	* @exception IOException if an I/O error occurs
	*/
	protected EPDC_Base(byte[] inBuffer, int offset) throws IOException {
		_in_command = new DataInputStream(new ByteArrayInputStream(inBuffer));
		_length = _in_command.available();
		_offset = 0;

		// Position the buffer at the specified offset and mark it
		posBuffer(offset);
		markOffset();
	}

	/**
	* Used to create a reply/request for output
	*/
	protected EPDC_Base() {
		_length = 0;
		_offset = 0;
	}

	/**
	 * Output the EPDC outgoing request/reply
	 * Implementations of request/reply must overide this method to provide a way 
	 * to output the request or reply
	 */
	abstract void output(DataOutputStream dataOutputStream)
		throws IOException;

	/** 
	 * Return the length of the fixed component 
	 * Each reply/request must implement this to return the "fixed" portion of their
	 * protocol
	 */
	protected abstract int fixedLen();

	/**
	 * Return the length of the variable component 
	 * Each reply/request must implement this to return the length of 
	 * the variable portion of its protocol
	 */
	protected abstract int varLen();

	

	/**
	* Skips bytes... can be used to skip reserved fields
	* @exception IOException if an I/O error occurs
	*
	*/
	protected final void skipBytes(int num) throws IOException {
		_in_command.skipBytes(num);
	}

	/**
	* Reads in a character (1 byte)
	* @exception IOException if an I/O error occurs
	*
	*/
	protected final byte readChar() throws IOException {
		_offset += 1;
		return (_in_command.readByte());
	}

	/**
	 * Writes a EPDC Character to the output stream
	 * @exception IOException if an I/O error occur
	 */
	protected final void writeChar(DataOutputStream os, byte b)
		throws IOException {
		os.writeByte(b);
	}

	/**
	* Reads in a short (2 bytes)
	* @exception IOException if an I/O error occurs
	*
	*/
	protected final short readShort() throws IOException {
		_offset += 2;
		return (_in_command.readShort());
	}

	/**
	* Writes a short (2 bytes) to an output stream
	* @exception IOException if an I/O error occurs
	*
	*/
	protected final void writeShort(DataOutputStream os, short s)
		throws IOException {
		os.writeShort(s);
	}

	/**
	* Reads in an integer (4 bytes)
	* @exception IOException if an I/O error occurs
	*
	*/
	protected final int readInt() throws IOException {
		_offset += 4;
		return (_in_command.readInt());
	}

	/**
	* Writes an int (4 bytes) to an output stream
	* @exception IOException if an I/O error occurs
	*
	*/
	protected final void writeInt(DataOutputStream os, int d) throws IOException {
		os.writeInt(d);
	}

	/**
	* Reads in a offset (4 bytes)
	* @exception IOException if an I/O error occurs
	*
	*/
	protected final int readOffset() throws IOException {
		return (readInt());
	}

	/**
	 * Writes an offset (4 bytes) to an output stream
	 * @exception IOException if an I/O error occurs
	 */
	protected final void writeOffset(DataOutputStream os, int offset)
		throws IOException {
		os.writeInt(offset);
	}

	/**
	 * Reads an EStdString from the current offset.
	 * @exception IOException if an I/O error occurs
	 */
	protected final EStdString readStdString() throws IOException {
		EStdString stdString = new EStdString(_in_command);
		_offset += stdString.actual_read();
		return stdString;
	}

	/**
	 * Reads an EExtString from the current offset.
	 * The difference between EExtString and EStdString is in their size,
	 * the former is 4 bytes and the latter is only 2 bytes.
	 * @exception IOException if an I/O error occurs
	 */
	protected final EExtString readExtString() throws IOException {
		EExtString extString = new EExtString(_in_command);
		_offset += extString.actual_read();

		return extString;
	}

	protected final static int writeOffsetOrZero(
		DataOutputStream os,
		int offset,
		EPDC_Base object)
		throws IOException {
		if (object == null) {
			os.writeInt(0);
			return 0;
		} else {
			int total = object.totalBytes();
			if (total == 0)
				os.writeInt(0);
			else
				os.writeInt(offset);
			return total;
		}
	}

	/**
	* Returns the current offset in the buffer
	*
	*/
	protected final int getOffset() {
		return _offset;
	}

	/**
	* Marks the current position in the buffer
	* This must be used after the fixed portion of the EPDC request/reply
	*   has been read in.  This allows offsets to be processed properly
	* @exception IOException if an I/O error occurs
	*/
	protected final void markOffset() throws IOException {
		_markedOffset = _offset;
		_in_command.mark(_in_command.available());
	}

	/**
	* Positions the buffer at the offset passed
	* @exception IOException if an I/O error occurs
	*
	*/
	protected final void posBuffer(int offset) throws IOException {
		if (offset == _offset)
			return;
		if (offset > _offset) {
			_in_command.skipBytes(offset - _offset);
			_offset = offset;
			return;
		}
		// we have gone past the required offset
		// go back and reposition
		_in_command.reset();
		_offset = _markedOffset; // reset the read offset
		_in_command.skipBytes(offset - _offset);
		_offset = offset;
		return;
	}

	protected int totalBytes() {
		return fixedLen() + varLen();
	}

	protected static int totalBytes(EPDC_Base object) {
		return (object == null) ? 0 : object.totalBytes();
	}

	protected final static short getPlatformIdentifier() {
		// TODO: Detect other platforms e.g. 390, 400, etc.

		// NOTE: As of 06/24/98, System.getProperty("os.name") was returning the
		// following platform strings:

		// "Windows 95"
		// "Windows NT"
		// "Windows 2000"
		// "AIX"
		// "HP-UX"
		// "Solaris"
		// "SunOS"

		String osName = System.getProperty("os.name");

		if (osName != null) {
			if (osName.indexOf("Win") != -1)
				return EPDC.PLATFORM_ID_NT;
			else if (osName.indexOf("AIX") != -1)
				return EPDC.PLATFORM_ID_AIX;
			else if (osName.indexOf("HP") != -1)
				return EPDC.PLATFORM_ID_HPUX;
			else if (osName.equals("Solaris") || osName.equals("SunOS"))
				return EPDC.PLATFORM_ID_SUN;
			else if (osName.equals("Linux"))
				return EPDC.PLATFORM_ID_LINUX;

		}
		return 0; // unknown
	}

	/**
	 * Need to set the EPDC version before each request is written out. This
	 * is due to some requests having a different set of parameters based on
	 * the EPDC version.
	 */
	public final void setEPDCEngineSession(EPDC_EngineSession engineSession) {
		_engineSession = engineSession;
	}

	/**
	 * Check the EPDC version. This is used for a number of requests that have
	 * different set of parameters based on the version of EPDC.
	 */
	protected final int getEPDCVersion() {
		return (_engineSession == null) ? 0 : _engineSession._negotiatedEPDCVersion;
	}

	protected final EPDC_EngineSession getEPDCEngineSession() {
		return _engineSession;
	}

	//------------------------------------------------------
	// The following are used to dump out the contents of EPDC
	//------------------------------------------------------

	/**
	 * Tell this EPDC object to write a formatted representation of itself
	 * out to the specified PrintWriter.
	 */

	void write(PrintWriter printWriter) {
		printWriter.println(getName());
	}

	/**
	 * Write out a packet to 'printWriter' in hex representation.
	 */

	protected static void write(PrintWriter printWriter, byte[] packet) {
		final int bytesPerLine = 16;
		final int hexLength = bytesPerLine * 3 + (bytesPerLine / 4 - 1);
		StringBuffer lineInHex = new StringBuffer(hexLength);
		StringBuffer lineInChar = new StringBuffer(bytesPerLine);
		int offset = 0;

		for (int i = 0; i < packet.length; i++) {
			lineInHex.append(getHexDigit((packet[i] & 0x00F0) >> 4)); // Hi-order nibble
			lineInHex.append(getHexDigit(packet[i] & 0x0F)); // Low-order nibble

			lineInHex.append(' ');

			if (packet[i] >= 0x20 && packet[i] <= 0x7E)
				lineInChar.append((char) packet[i]);
			else
				lineInChar.append('.');

			if ((i + 1) % bytesPerLine == 0 || i == packet.length - 1) {
				while (lineInHex.length() < hexLength)
					lineInHex.append(' ');

				printWriter.print(getHexDigits(offset) + " :  ");
				printWriter.print(lineInHex.toString());
				printWriter.println("    " + lineInChar.toString());

				lineInHex.setLength(0);
				lineInChar.setLength(0);
				offset += bytesPerLine;
			} else if ((i + 1) % 4 == 0)
				lineInHex.append(' ');
		}
	}

	protected static String getHexDigits(int offset) {
		StringBuffer hexDigits = new StringBuffer(8);
		final int mask = 0x0000000F;

		for (int i = 0; i < 8; i++) {
			// Mask off succesive nibbles and get the hex digit for each one:

			hexDigits.append(getHexDigit((offset >>> ((7 - i) * 4)) & mask));
		}

		return "0x" + hexDigits.toString();
	}

	private static char getHexDigit(int input) {
		return _hexDigits[input];
	}

	public abstract String getName();

	protected String getName(int code) {
		switch (code) {
			case EPDC.Remote_BreakpointLocation :
				return "Remote_BreakpointLocation";
			case EPDC.Remote_Execute :
				return "Remote_Execute";
			case EPDC.Remote_Expression :
				return "Remote_Expression";
			case EPDC.Remote_ExpressionDisable :
				return "Remote_ExpressionDisable";
			case EPDC.Remote_ExpressionEnable :
				return "Remote_ExpressionEnable";
			case EPDC.Remote_ExpressionFree :
				return "Remote_ExpressionFree";
			case EPDC.Remote_ExpressionValueModify :
				return "Remote_ExpressionValueModify";
			case EPDC.Remote_PartGet :
				return "Remote_PartGet";
			case EPDC.Remote_PointerDeref :
				return "Remote_PointerDeref";
			case EPDC.Remote_EntrySearch :
				return "Remote_EntrySearch";
			case EPDC.Remote_Stack :
				return "Remote_Stack";
			case EPDC.Remote_StackFree :
				return "Remote_StackFree";
			case EPDC.Remote_StackBuildView :
				return "Remote_StackBuildView";
			case EPDC.Remote_FilePathVerify :
				return "Remote_FilePathVerify";
			case EPDC.Remote_PartOpen :
				return "Remote_PartOpen";
			case EPDC.Remote_Storage2 :
				return "Remote_Storage2";
			case EPDC.Remote_StorageEnablementSet :
				return "Remote_StorageEnablementSet";
			case EPDC.Remote_StorageFree :
				return "Remote_StorageFree";
			case EPDC.Remote_StorageRangeSet2 :
				return "Remote_StorageRangeSet2";
			case EPDC.Remote_StorageStyleSet :
				return "Remote_StorageStyleSet";
			case EPDC.Remote_StorageUpdate :
				return "Remote_StorageUpdate";
			case EPDC.Remote_StringFind :
				return "Remote_StringFindh";
			case EPDC.Remote_TerminatePgm :
				return "Remote_TerminatePgm";
			case EPDC.Remote_ThreadFreeze :
				return "Remote_ThreadFreeze";
			case EPDC.Remote_ThreadThaw :
				return "Remote_ThreadThaw";
			case EPDC.Remote_ViewsVerify :
				return "Remote_ViewsVerify";
			case EPDC.Remote_Initialize_Debug_Engine :
				return "Remote_Initialize_Debug_Engine";
			case EPDC.Remote_PreparePgm :
				return "Remote_PreparePgm";
			case EPDC.Remote_StartPgm :
				return "Remote_StartPgm";
			case EPDC.Remote_BreakpointClear :
				return "Remote_BreakpointClear";
			case EPDC.Remote_BreakpointDisable :
				return "Remote_BreakpointDisable";
			case EPDC.Remote_BreakpointEnable :
				return "Remote_BreakpointEnable";
			case EPDC.Remote_BreakpointEvent :
				return "Remote_BreakpointEvent";
			case EPDC.Remote_PartSet :
				return "Remote_PartSet";
			case EPDC.Remote_ExpressionSubTree :
				return "Remote_ExpressionSubTree";
			case EPDC.Remote_ExpressionSubTreeDelete :
				return "Remote_ExpressionSubTreeDelete";
			case EPDC.Remote_ExpressionRepTypeSet :
				return "Remote_ExpressionRepTypeSet";
			case EPDC.Remote_LocalVariable :
				return "Remote_LocalVariable";
			case EPDC.Remote_LocalVariableFree :
				return "Remote_LocalVariableFree";
			case EPDC.Remote_Terminate_Debug_Engine :
				return "Remote_Terminate_Debug_Engine";
			case EPDC.Remote_EntryWhere :
				return "Remote_EntryWhere";
			case EPDC.Remote_CommandLog :
				return "Remote_CommandLog";
			case EPDC.Remote_ProcessAttach :
				return "Remote_ProcessAttach";
			case EPDC.Remote_ProcessDetach :
				return "Remote_ProcessDetach";
			case EPDC.Remote_ProcessListGet :
				return "Remote_ProcessListGet";
			case EPDC.Remote_ProcessAttach2 :
				return "Remote_ProcessAttach2";
			case EPDC.Remote_ContextConvert :
				return "Remote_ContextConvert";
			case EPDC.Remote_BreakpointEntryAutoSet2 :
				return "Remote_BreakpointEntryAutoSet2";
			case EPDC.Remote_ModuleAdd :
				return "Remote_ModuleAdd";
			case EPDC.Remote_ModuleRemove :
				return "Remote_ModuleRemove";
			case EPDC.Remote_Registers2 :
				return "Remote_Registers2";
			case EPDC.Remote_RegistersEnablementSet :
				return "Remote_RegistersEnablementSet";
			case EPDC.Remote_RegistersFree2 :
				return "Remote_RegistersFree2";
			case EPDC.Remote_RegistersValueSet :
				return "Remote_RegistersValueSet";
			case EPDC.Remote_StackEnablementSet :
				return "Remote_StackEnablementSet";
			case EPDC.Remote_StackOpenStorage :
				return "Remote_StackOpenStorage";
			case EPDC.Remote_StackSetBreakpoint :
				return "Remote_StackSetBreakpoint";
			case EPDC.Remote_PassThru :
				return "Remote_PassThru";
			case EPDC.Remote_PassThruEnablementSet :
				return "Remote_PassThruEnablementSet";
			case EPDC.Remote_PassThruFree :
				return "Remote_PassThruFree";
			case EPDC.Remote_PassThruSendCommand :
				return "Remote_PassThruSendCommand";
			case EPDC.Remote_ThreadInfoGet :
				return "Remote_ThreadInfoGet";
			case EPDC.Remote_Version :
				return "Remote_Version";

			case EPDC.Remote_DBD_Calls :
				return "Remote_DBD_Calls";
			case EPDC.Remote_ClassDetailsGet :
				return "Remote_ClassDetailsGet";
			case EPDC.Remote_ClassDetailsFree :
				return "Remote_ClassDetailsFree";
			case EPDC.Remote_ClassPartGet :
				return "Remote_ClassPartGet";
			case EPDC.Remote_Halt :
				return "Remote_Halt";
			case EPDC.Remote_TypesNumGet :
				return "Remote_TypesNumGet";
			case EPDC.Remote_RepForTypeSet :
				return "Remote_RepForTypeSet";
			case EPDC.Remote_ContextQualGet :
				return "Remote_ContextQualGet";
			case EPDC.Remote_ContextFromAddrGet :
				return "Remote_ContextFromAddrGet";
			case EPDC.Remote_ExceptionStatusChange :
				return "Remote_ExceptionStatusChange";
			case EPDC.Remote_StorageUsageCheckSet :
				return "Remote_StorageUsageCheckSet";
			case EPDC.Remote_JobsListGet :
				return "Remote_JobsListGet";
			case EPDC.Remote_RegistersDetailsGet :
				return "Remote_RegistersDetailsGet";
			case EPDC.Remote_StackDetailsGet :
				return "Remote_StackDetailsGet";
			case EPDC.Remote_ProcessDetailsGet :
				return "Remote_ProcessDetailsGet";
			case EPDC.Remote_PassThruDetailsGet :
				return "Remote_PassThruDetailsGet";
			case EPDC.Remote_BreakpointEntryAutoSet :
				return "Remote_BreakpointEntryAutoSet";
			case EPDC.Remote_EnvironmentDetailsGet :
				return "Remote_EnvironmentDetailsGet";
			case EPDC.Remote_EnvironmentSet :
				return "Remote_EnvironmentSet";
			case EPDC.Remote_FilePathSet :
				return "Remote_FilePathSet";
			case EPDC.Remote_ProcessActiveListGet :
				return "Remote_ProcessActiveListGet";
			case EPDC.Remote_ViewFileInfoSet :
				return "Remote_ViewFileInfoSet";
			case EPDC.Remote_ViewSearchPath :
				return "Remote_ViewSearchPath";
			case EPDC.Remote_GetStatusInfo :
				return "Remote_GetStatusInfo";
			case EPDC.Remote_GetEngineSettings :
				return "Remote_GetEngineSettings";
			case EPDC.Remote_PutEngineSettings :
				return "Remote_PutEngineSettings";
			default :
				return "Unknown";
		}
	}

	void setDetailLevel(byte detailLevel) {
		_detailLevel = detailLevel;
	}

	protected byte getDetailLevel() {
		return _detailLevel;
	}

	protected void setIndentLevel(int indentLevel) {
		_indentLevel = indentLevel;
	}

	protected int getIndentLevel() {
		return _indentLevel;
	}

	protected void increaseIndentLevel() {
		_indentLevel++;
	}

	protected void decreaseIndentLevel() {
		_indentLevel--;
	}

	protected void indent(PrintWriter printWriter) {
		for (int i = 0; i < _indentLevel; i++)
			printWriter.print("  ");
	}

	protected String getIndentString(int additionalLevels) {
		StringBuffer indentSpaces = new StringBuffer();
		int numOfIndentLevels = additionalLevels + getIndentLevel();
		for (int i = 0; i < numOfIndentLevels; i++) {
			indentSpaces.append("  ");
		}
		return indentSpaces.toString();

	}
	/**
	 * Return the input stream
	 */
	protected DataInputStream getDataInputStream() {
		return _in_command;
	}


	

	static void dumpEPDC(ByteArrayOutputStream byteArrayOutputStream, 
							EPDC_EngineSession engineSession,
							int packetType) {
		final byte timerFlag = 0x01;

		if (packetType == NOT_PACKET)
			return;

		int bufferSize = byteArrayOutputStream.size();

		if (bufferSize > 0) {
			try {
				// If the dump stream is closed we don't want to fail - just
				// ignore the exception:
				DataOutputStream dataOutputStream = new DataOutputStream(engineSession.getDumpOutputStream());
				// write 2 bytes of 0
				dataOutputStream.writeByte(0);
				dataOutputStream.writeByte(0);
				// write the timer flag
				dataOutputStream.writeByte(timerFlag);
				dataOutputStream.writeByte((byte) packetType); // packet type
				dataOutputStream.writeInt(bufferSize); // packet size
				long timeStamp = System.currentTimeMillis();
				if (engineSession.getDumpLastTimeStamp() == 0) {
					engineSession.setDumpLastTimeStamp(timeStamp);  // use this as the base value
					dataOutputStream.writeInt(0);
				} else {
					int difference = (int)(timeStamp - engineSession.getDumpLastTimeStamp());
					dataOutputStream.writeInt(difference);
				}
					
				byteArrayOutputStream.writeTo(engineSession.getDumpOutputStream());
			} catch (IOException excp) {
			}

		}

	}

	protected transient int _prtOffset; // current print offset from left margin
	protected transient final int PRTINDENT = 3;

	// internal data members

	private transient int _offset; // offset for the next read
	private transient int _markedOffset;
	private transient DataInputStream _in_command; // the input stream
	private transient int _length;

	private transient EPDC_EngineSession _engineSession;

	static final byte DETAIL_LEVEL_LOW = 10;
	static final byte DETAIL_LEVEL_MEDIUM = 20;
	static final byte DETAIL_LEVEL_HIGH = 30;

	private static byte _detailLevel = DETAIL_LEVEL_HIGH;
	private static int _indentLevel;
	static final byte INDENT_INCREASE_FOR_LISTS = 3;
	/*represents number of levels
	                            to increase indent when lists are outputted in EPDC viewer*/

	static char[] _hexDigits =
		{
			'0',
			'1',
			'2',
			'3',
			'4',
			'5',
			'6',
			'7',
			'8',
			'9',
			'A',
			'B',
			'C',
			'D',
			'E',
			'F' };

	static final byte REQUEST_PACKET = 0;
	static final byte REPLY_PACKET = 1;
	static final byte CHANGE_PACKET = 2;
	static final byte NOT_PACKET = 3;

}
