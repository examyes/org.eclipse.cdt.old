package com.ibm.debug.epdc;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.OutputStream;

/**
 * This class is a structure of EPDC information that contains information
 * about the current EPDC session
 */
public class EPDC_EngineSession {

	public short _debugEngineID;
	public short _debugEnginePlatformID;
	public int _defaultSettings;
	public int _processDetachAction;

	public ERepGetViews[] _viewInfo;
	public ERepGetLanguages[] _languageInfo;
	public ERepGetExceptions[] _exceptionsInfo;
	public EFunctCustTable _functCustomTable;

	public ERepTypesNumGet _repInfo;

	public int _negotiatedEPDCVersion;

	private boolean _formattingChecked = false;
	private String _formattingJavaClassName;
	private IFormattedString _FormatStringClass = null;

	// dump support
	private static final int BINARY = 0;
	private OutputStream _dumpOutputStream = null;
	private boolean _dumpEPDC = false;
	private int _DumpType = BINARY;
	private long _DumpLastTimeStamp = 0;

		
	/**
	 * Gets the formatting Java Class name
	 * @return Returns a String
	 */
	public String getFormattingJavaClassName() {
		return _formattingJavaClassName;
	}

	/**
	 * Sets the Java formatting Class Name.
	 * @param javaClassName The name of the Java class used to format Strings
	 */
	public void setFormattingJavaClassName(String javaClassName) {
		_formattingJavaClassName = javaClassName;
	}

	/**
	 * Return the string formatting class
	 * If this if the first time called then it will attempt to get the class loaded
	 * @return the formatting class or null 
	 */

	public IFormattedString getFormattingClass() {
		if (_formattingChecked)
			return _FormatStringClass;
		else {
			_formattingChecked = true;
			if (_formattingJavaClassName == null)
				return null;
			try {
				Class c = Class.forName(_formattingJavaClassName);
				IFormattedString obj = (IFormattedString)c.newInstance();
				if (IFormattedString.class.isInstance(obj)) {
					_FormatStringClass = obj;
				}
			} catch(Exception e) {
			}
			return _FormatStringClass;
		}
	}
	
	
	/**
	 * Gets the dumpEPDC.
	 * @return Returns a boolean
	 */
	public boolean getDumpEPDC() {
		if (_dumpOutputStream != null)
			return _dumpEPDC;
		else 
			return false;
	}

	/**
	 * Sets the dumpEPDC.
	 * @param dumpEPDC The dumpEPDC to set
	 */
	public void setDumpEPDC(boolean dumpEPDC) {
		_dumpEPDC = dumpEPDC;
	}

	/**
	 * Gets the dumpOutputStream.
	 * @return Returns a OutputStream
	 */
	public OutputStream getDumpOutputStream() {
		return _dumpOutputStream;
	}

	/**
	 * Sets the dumpOutputStream.
	 * @param dumpOutputStream The dumpOutputStream to set
	 */
	public void setDumpOutputStream(OutputStream dumpOutputStream) {
		_dumpOutputStream = dumpOutputStream;
	}

	/**
	 * Gets the dumpLastTimeStamp.
	 * @return Returns a int
	 */
	long getDumpLastTimeStamp() {
		return _DumpLastTimeStamp;
	}

	/**
	 * Sets the dumpLastTimeStamp.
	 * @param dumpLastTimeStamp The dumpLastTimeStamp to set
	 */
	void setDumpLastTimeStamp(long dumpLastTimeStamp) {
		_DumpLastTimeStamp = dumpLastTimeStamp;
	}

}
