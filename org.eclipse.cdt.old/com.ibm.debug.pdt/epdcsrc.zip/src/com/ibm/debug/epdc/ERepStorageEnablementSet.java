package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Monitor storageStyleSet reply -- only contains reply header
 */
public class ERepStorageEnablementSet extends EPDC_BasicReply {

	
	
   public ERepStorageEnablementSet() {
      super(EPDC.Remote_StorageStyleSet);
   }


}

