package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * This class represents a basic reply that contains no extra fields.
 * This can be used for all replies that consist of a basic reply only.
 */
public class EPDC_BasicReply extends EPDC_Reply {

	/**
	 * Constructor for EPDC_BasicReply.
	 * @param packetBuffer
	 * @param dataInputStream
	 * @throws IOException
	 */
	protected EPDC_BasicReply(byte[] packetBuffer, DataInputStream dataInputStream, EPDC_EngineSession engineSession)
		throws IOException {
		super(packetBuffer, dataInputStream, engineSession);
	}

	/**
	 * 
	 * Constructor for EPDC_BasicReply.
	 * @param reply_code
	 */
	protected EPDC_BasicReply(int reply_code) {
		super(reply_code);
	}

	/**
	 * Basic reply has no length. Pass back the length of the base reply
	 * @see EPDC_Base#fixedLen()
	 */
	protected int fixedLen() {
		return super.fixedLen();
	}

	/**
	 * Send the underly reply only
	 * @see EPDC_Base#output(DataOutputStream)
	 */
	void output(DataOutputStream dataOutputStream) throws IOException {
		super.output(dataOutputStream);
	}

	/**
	 * Send the underlying reply only
	 * @see EPDC_Reply#toDataStreams(DataOutputStream, DataOutputStream, int)
	 */
	protected int toDataStreams(
		DataOutputStream fixedData,
		DataOutputStream varData,
		int baseOffset)
		throws IOException, BadEPDCCommandException {
		return super.toDataStreams(fixedData, varData, baseOffset);
	}

	/**
	 * Basic reply has no length. Pass back the length of the base reply
	 * @see EPDC_Base#varLen()
	 */
	protected int varLen() {
		return super.varLen();
	}

}
