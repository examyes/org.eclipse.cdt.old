package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;
import java.util.*;

/**
 * Part open reply packet
 */
public class ERepPartOpen extends EPDC_Reply {

   public ERepPartOpen() {
      super(EPDC.Remote_PartOpen);
      _partIDs = new Vector();
   }

   public ERepPartOpen(byte[] packetBuffer, DataInputStream dataInputStream, EPDC_EngineSession engineSession)
   throws IOException
   {
     super(packetBuffer, dataInputStream, engineSession);

     short numberOfParts = dataInputStream.readShort();

     _partIDs = new Vector(numberOfParts);

     for (int i=0; i < numberOfParts; i++)
          _partIDs.addElement(new Short(dataInputStream.readShort()));
   }

   /**
    * Add a part ID to this reply packet
    */
   public void addPartID(int partID) {
      _partIDs.addElement(new Integer(partID));
   }

   /**
    * Add a vector of part IDs to this reply packet
    */
   public void addPartIDs(Vector partIDs)
   {
      for (int i=0; i<partIDs.size(); i++)
      {
         Integer num = (Integer) partIDs.elementAt(i);
         addPartID(num.intValue());
      }
   }

   /**
    * Add an array of part IDs to this reply packet
    */
   public void addPartIDs(int[] partIDs) {
      for (int i=0; i<partIDs.length; i++)
         addPartID(partIDs[i]);
   }

   /**
    * Return number of part IDs added to reply packet
    */
   public int numPartIDs() {
      return _partIDs.size();
   }

   public Vector getPartIDs()
   {
     return _partIDs;
   }

   /** Output class to data streams according to EPDC protocol.
     * @exception IOException if an I/O error occurs
    *  @exception BadEPDCCommandException if the EPDC command
    *    is structured incorrectly
    */
   protected int toDataStreams(DataOutputStream fixedData,
         DataOutputStream varData, int baseOffset)
         throws IOException, BadEPDCCommandException {

      super.toDataStreams(fixedData, varData, baseOffset);

      writeShort(fixedData, (short) _partIDs.size());
      for (int i=0; i<_partIDs.size(); i++)
         writeShort(fixedData, ((Integer) _partIDs.elementAt(i)).shortValue());

      return fixedLen() + varLen();
   }

   protected int fixedLen() {
      return super.fixedLen() + _fixed_length + 2 * _partIDs.size();
   }

   protected int varLen() {
      return super.varLen();
   }

   // data fields
   private Vector _partIDs;

   private static final int _fixed_length = 2;


}

