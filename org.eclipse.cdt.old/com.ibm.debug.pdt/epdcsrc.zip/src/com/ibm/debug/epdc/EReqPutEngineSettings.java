package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 *  Remote_PutEngineSettings request
 */
public class EReqPutEngineSettings extends EPDC_Request
{
   public EReqPutEngineSettings(byte[] XMLStream)
   {
     super(EPDC.Remote_PutEngineSettings);

     _XMLStream = new EExtString(XMLStream);
   }

   /**
    * Return the size of the XML stream
    */
   public int streamLength() {
      return _XMLStream.streamLength();
   }

   /**
    * Return a handle to the XML stream
    * @exception IOException if an I/O error occurs
    */
   public String XMLStream() throws IOException {
      if ((_XMLStream == null) && (_XMLStreamOffset != 0)) {
         posBuffer(_XMLStreamOffset);
         _XMLStream = readExtString();
      }

      if (_XMLStream == null)
          return null;

      return _XMLStream.string();
   }

   void output(DataOutputStream dataOutputStream)
   throws IOException
   {
     super.output(dataOutputStream);

     int offset = fixedLen() + super.varLen();

     writeOffsetOrZero(dataOutputStream, offset, _XMLStream);

     if (_XMLStream != null)
         _XMLStream.output(dataOutputStream);
   }

   /**
    * Return the length of the fixed component
    */
   protected int fixedLen()
   {
     return _fixed_length + super.fixedLen();
   }

   /**
    * Return the length of the variable component
    */
   protected int varLen()
   {
     return super.varLen() + totalBytes(_XMLStream);
   }

   // data fields
   private int _XMLStreamOffset;
   private EExtString _XMLStream;

   private static final int _fixed_length = 4;

}
