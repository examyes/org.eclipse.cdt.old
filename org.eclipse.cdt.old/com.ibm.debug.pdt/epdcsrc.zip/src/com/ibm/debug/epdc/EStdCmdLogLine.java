package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.DataInputStream;

/**
 * Represents a line out output from the debug engine that should be 
 * shown as output from a command sent to the debug engine
 */

public class EStdCmdLogLine extends EStdLogLine {

	
	/**
	 * Constructor for EStdCmdLogLine.
	 * @param dataInputStream
	 */
	protected EStdCmdLogLine(DataInputStream dataInputStream) {
		super(dataInputStream);
	}

	/**
	 * Constructor for EStdCmdLogLine.
	 * @param String a line for the log
	 */
	public EStdCmdLogLine(String logLine) {
		super(EPDC.LogCommandLine, logLine);
	}

	

}
