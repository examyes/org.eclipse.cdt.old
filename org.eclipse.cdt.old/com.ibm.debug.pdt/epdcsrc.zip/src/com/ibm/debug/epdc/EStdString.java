package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;
import java.io.UnsupportedEncodingException;

/**
 * All text transported via EPDC must be in the form of an EStdString.
 * There is also the extended format EExtString that is used for long 
 * strings.
 * The EStdString class is used to convert Java String objects into
 * EPDC EStdStrings and vice versa.  EStdStrings are encoded
 * using UTF-8
 */

// NOTE: Please ensure that all conversion and sizing decisions are handled
// inside this class for maintainability.

class EStdString extends EPDC_Structures {
	/**
	 * Construct a new EStdString object from the specified String
	 */
	protected EStdString(String string) {
		if (string != null) {
			try {
				_buffer = string.getBytes(ENCODING);
			} catch(UnsupportedEncodingException e) {
			}
		}
	}

	/**
	 * Constructs an EPDC StdString that is a length prefixed string
	 * from the specified DataInputStream
	 * <p> *note* this assumes that the current position in the buffer is
	 *        at the StdString
	 * @exception IOException if an I/O error occurs
	 */
	protected EStdString(byte[] packetBuffer, DataInputStream dataInputStream)
		throws IOException {
		this(dataInputStream);
	}


	/**
	 * Likely the fastest ctor.
	 */

	protected EStdString(byte[] packetBuffer, int offset) throws IOException {
		// We need to make sure that this ctor can handle strings longer than
		// 128 characters. Therefore, we cannot calculate the length of the
		// of the string by left shifting of the high order bit and adding the
		// low order bit as was done before:
		// _len = (packetBuffer[offset] << 8) + packetBuffer[offset + 1];
		// However, we might run into problems if the string is longer than
		// 32000 (and a bit more) which is the maximum size of a short.

		DataInputStream dataInputStream =
			new OffsetDataInputStream(packetBuffer, offset);
		_len = dataInputStream.readShort();
		_buffer = new byte[_len];
		dataInputStream.read(_buffer,0,_len);
		
//		System.arraycopy(packetBuffer, 	// copy from this array
//						offset + 2,		// starting at this position
//						_buffer, 		// copy into this array
//						0, 				// starting at this position
//						_len); 			// copy this many bytes
	}

	/**
	 * Constructs an EPDC StdString that is a length prefixed string
	 * from the specified DataInputStream.
	 * <p> *note* this assumes that the current position in the buffer is
	 *        at the StdString
	 * @exception IOException if an I/O error occurs
	 */
	protected EStdString(DataInputStream dataInputStream) throws IOException {
		_len = dataInputStream.readShort();
		if (_len < 0) {  // -ve length means special formatting inside
			_specialFormat = true;
			_len = Math.abs(_len);
		}
		_buffer = new byte[_len];
		dataInputStream.read((byte[]) _buffer);
	}

	/**
	 * Constructs an EPDC StdString that is a length prefixed string
	 * from the specified DataInputStream.
	 * <p> *note* this assumes that the current position in the buffer is
	 *        at the StdString
	 * @exception IOException if an I/O error occurs
	 */
	protected EStdString(DataInputStream dataInputStream, EPDC_EngineSession engineSession) throws IOException {
		this(dataInputStream);		
		setEPDCEngineSession(engineSession);
	}


	/**
	 * Returns the number of bytes we actually read from the data input stream
	 * after constructing a new EStdString.  DO NOT use this method to
	 * determine the size of an EStdString.  Use fixedLen() and varLen()
	 * instead.  This method should only be used to increment the offset
	 * within the dataInputStream after a construction of a new EStdString.
	 */
	protected int actual_read() {
		return fixedLen() + _len;
	}

	
	/**
	 * Write a String to an output stream as an EStdString
	 * @exception IOException if an I/O error occurs
	 */
	void output(DataOutputStream dataOutputStream) throws IOException {
		if (stringIsEmpty())
			return;

		dataOutputStream.writeShort(_buffer.length);
		dataOutputStream.write(_buffer);
	}

	private boolean stringIsEmpty() {
		return _buffer == null || _buffer.length == 0;
	}

	/**
	 * Returns the String object this EStdString contains
	 * @return a string or null
	 */
	protected String string() {
		// the internal format is a byte array

		// first check if there is a string to return
		if (stringIsEmpty())
			return null;

		if (!_specialFormat) {
			try {
				return new String(_buffer, ENCODING);
			} catch (UnsupportedEncodingException e) {
				return null;
			}
		} else {

			// for special formatting support there must be the following:
			// 1) a valid engineSession
			// 2) valid formatting class

			if (getEPDCEngineSession() == null
				|| getEPDCEngineSession().getFormattingClass() == null) {
				return null; 
			} else { // use the formatting class 
				IFormattedString fmtCls = getEPDCEngineSession().getFormattingClass();
				try {
					String formattedString = fmtCls.decodeString(_buffer);
					return formattedString;
				} catch(Exception e) {
					return null;
				}
			}
		}
	}
	/**
	 * Returns the fixed length of this EStdString
	 */
	protected int fixedLen() {
		return 2;
	}

	/**
	 * Returns the number of bytes (_not_ the number of _characters) the
	 * specified string would occupy if it were written to a byte stream as an
	 * EStdString in the current encoding scheme.  The current encoding scheme
	 * may be queried via getEncoding().
	 */
	protected int varLen() {
		if (stringIsEmpty())
			return 0;

		return _buffer.length;
	}

	/**
	 * Check if string is in a specialFormat.
	 * @return Returns a boolean
	 */
	protected boolean isSpecialFormat() {
		return _specialFormat;
	}
	
	/**
	 * Returns the total number of bytes this EStdstring will occupy
	 */
	protected int totalBytes() {
		// NOTE:  We _MUST_ override EPDC_Base totalBytes because we need to
		// detect if our string is empty or not.  We don't output offsets for
		// empty strings.
		if (stringIsEmpty())
			return 0;

		return super.totalBytes();
	}

	void write(java.io.PrintWriter printWriter) {
		if (!stringIsEmpty())
			printWriter.print(string());
	}

	private int _len = 0;
	private byte[] _buffer = null;
	private boolean _specialFormat = false;
	private final static String ENCODING = "UTF-8";


	
}
