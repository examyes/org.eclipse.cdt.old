package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Expand expression subtree request
 */
public class EReqExpressionSubTree extends EPDC_Request {

   /**
    * Read in request packet from a buffer
    * @exeception IOException if an I/O error occurs
    */
   protected EReqExpressionSubTree(byte[] inBuffer) throws IOException {
      super(inBuffer);
      _exprID = readShort();
      _exprTreeNodeID = readInt();
      _exprTreeStartChild = readInt();
      _exprTreeEndChild = readInt();
   }

   public EReqExpressionSubTree(short exprID, int exprTreeNodeID,
                                int startChild, int endChild)
   {
     super(EPDC.Remote_ExpressionSubTree);

     _exprID = exprID;
     _exprTreeNodeID = exprTreeNodeID;
     _exprTreeStartChild = startChild;
     _exprTreeEndChild = endChild;
   }

   /**
    * Return monitor expression id
    */
   public short exprID() {
      return _exprID;
   }

   /**
    * Return root node id of expression tree
    */
   public int exprTreeNodeID() {
      return _exprTreeNodeID;
   }

   /**
    * Return start node of subtree to retrieve
    */
   public int exprTreeStartChild() {
      return _exprTreeStartChild;
   }

   /**
    * Return end node of subtree to retrieve
    */
   public int exprTreeEndChild() {
      return _exprTreeEndChild;
   }

   /**
    * Return the length of the fixed component
    */
   protected int fixedLen()
   {
      return _fixed_length + super.fixedLen();
   }

   void output(DataOutputStream dataOutputStream)
   throws IOException
   {
     super.output(dataOutputStream);

     dataOutputStream.writeShort(_exprID);
     dataOutputStream.writeInt(_exprTreeNodeID);
     dataOutputStream.writeInt(_exprTreeStartChild);
     dataOutputStream.writeInt(_exprTreeEndChild);
   }

   // data fields
   private short _exprID;           // monitor expression id
   private int _exprTreeNodeID;     // root node id of expression tree
   private int _exprTreeStartChild; // start node of subtree to retrieve
   private int _exprTreeEndChild;   // end node of subtree to retrieve

   private static final int _fixed_length = 14;


}

