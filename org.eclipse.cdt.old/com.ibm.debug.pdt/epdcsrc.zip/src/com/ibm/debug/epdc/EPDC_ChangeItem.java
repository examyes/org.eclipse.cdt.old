package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;
import java.util.*;

/** Class from which all change item classes are descended */
abstract class EPDC_ChangeItem extends EPDC_Base {

	protected EPDC_ChangeItem() {
		super();
	}

	/**
	 * called to decode a change packet
	 */

	protected EPDC_ChangeItem(
		byte[] packetBuffer,
		DataInputStream dataInputStream,
		EPDC_EngineSession engineSession)
		throws IOException {
		super();
	};
			

	/** This function must be defined by all subclasses.  It outputs
	 *  the class into two byte streams for fixed and variable data,
	 *  corresponding to the EPDC protocol.
	 *
	 *  @param fixedData output stream for the fixed data
	 *  @param varData output stream for the variable data
	 *  @param baseOffset the base offset to add to all offsets
	 *
	 *  @return total size of written data
	 *  @exception IOException if an I/O error occurs
	 *  @exception BadEPDCCommandException if the EPDC command
	 *    is structured incorrectly
	 */
	protected abstract int toDataStreams(
		DataOutputStream fixedData,
		DataOutputStream varData,
		int baseOffset) throws IOException, BadEPDCCommandException;

	/*
	 * @see EPDC_Base#output(DataOutputStream)
	 */
	void output(DataOutputStream dataOutputStream) throws IOException {
		// to be implemented in the derived classes
		// remove this copy when implementing in the derived classes
	}



	/*
	 * @see EPDC_Base#getName()
	 */
	public String getName() {
		String name = getClass().getName();

		int indexOfLastDot = name.lastIndexOf('.');

		if (indexOfLastDot != -1)
			name = name.substring(indexOfLastDot + 1);
		return name;
	}

	
}
