package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class EReqStringFind extends EPDC_Request {
	public EReqStringFind(
		EStdView startingLocation,
		String string,
		int numLinesToSearch,
		int startingColumn,
		boolean caseSensitive) {
		super(EPDC.Remote_StringFind);
		_findContext = startingLocation;
		_searchString = new EStdString(string);
		_numLinesToSearch = numLinesToSearch;
		_startColumnNum = startingColumn;
		if (caseSensitive)
			_searchFlags = CaseSensitive;
	}
	/**
	 * Decodes request
	 */
	EReqStringFind(byte[] packetBuffer)
		throws IOException {
		super(packetBuffer);
		
		DataInputStream dataInputStream = 
			new DataInputStream(new ByteArrayInputStream(packetBuffer));
		
		_findContext = new EStdView(packetBuffer, dataInputStream);
		if ((_searchStringOffset = dataInputStream.readInt()) != 0)
			_searchString =
				new EStdString(packetBuffer,
							new OffsetDataInputStream(packetBuffer, _searchStringOffset));
		_numLinesToSearch = dataInputStream.readInt();
		_startColumnNum = dataInputStream.readInt();
		_searchFlags = dataInputStream.readInt();
	}
	public String getSearchString() {
		return _searchString.string();
	}
	public int getNumLinesToSearch() {
		return _numLinesToSearch;
	}
	public int getStartLine() {
		return _findContext.getLineNum();
	}
	public int getStartColumn() {
		return _startColumnNum;
	}
	public short getViewNumber() {
		return _findContext.getViewNo();
	}
	public short getPartID() {
		return _findContext.getPPID();
	}
	public int getSrcFileIndex() {
		return _findContext.getSrcFileIndex();
	}
	public int getSearchFlags() {
		return _searchFlags;
	}
	void output(DataOutputStream dataOutputStream) throws IOException {
		super.output(dataOutputStream);
		_findContext.output(dataOutputStream);
		writeOffsetOrZero(dataOutputStream, fixedLen() + super.varLen(), _searchString);
		dataOutputStream.writeInt(_numLinesToSearch);
		dataOutputStream.writeInt(_startColumnNum);
		dataOutputStream.writeInt(_searchFlags);
		// Now write out the variable length data:
		if (_searchString != null)
			_searchString.output(dataOutputStream);
	}
	protected int fixedLen() {
		return _fixed_length + super.fixedLen();
	}
	protected int varLen() {
		return super.varLen() + totalBytes(_searchString);
	}
	private EStdView _findContext;
	private int _searchStringOffset;
	private EStdString _searchString;
	private int _numLinesToSearch;
	private int _startColumnNum;
	private int _searchFlags;
	private static final int CaseSensitive = 0x80000000;
	private static final int _fixed_length = 28;
}
