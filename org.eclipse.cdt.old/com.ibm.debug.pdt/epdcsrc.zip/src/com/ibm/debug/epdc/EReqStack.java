package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Monitor stack request
 */
public class EReqStack extends EPDC_Request {

  public EReqStack(int stackDU)
  {
    super(EPDC.Remote_Stack);

    _stackDU = stackDU;
  }

   /**
    * Decodes request from an input buffer
    * @exception IOException if an I/O error occurs
    */
   EReqStack (byte[] inBuffer) throws IOException {
      super(inBuffer);

      _stackDU = readInt();
   }

  void output(DataOutputStream dataOutputStream)
  throws IOException
  {
    super.output(dataOutputStream);

    dataOutputStream.writeInt(_stackDU);
  }

   /**
    * Get the dispatchable unit for stack
    */
   public int stackDU() {
      return _stackDU;
   }

   /**
    * Return size of "fixed" portion
    */
   protected int fixedLen()
   {
      int total = _fixed_length + super.fixedLen();

      return total;
   }

   // data fields
   private int _stackDU;

   private static final int _fixed_length = 4;
}

