package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.IOException;

public class EEveryClause extends EPDC_Structures
{
   public EEveryClause(int every, int to, int from)
   {
     _every = every;
     _to = to;
     _from = from;
   }

   EEveryClause(byte[] packetBuffer, DataInputStream dataInputStream)
   throws IOException
   {
     _every = dataInputStream.readInt();
     _to = dataInputStream.readInt();
     _from = dataInputStream.readInt();
   }

   public int everyVal()
   {
     return _every;
   }

   public int toVal()
   {
     return _to;
   }

   public int fromVal()
   {
     return _from;
   }

   void output(DataOutputStream dataOutputStream)
   throws IOException
   {
     dataOutputStream.writeInt(_every);
     dataOutputStream.writeInt(_to);
     dataOutputStream.writeInt(_from);
   }

   protected int fixedLen()
   {
     return _fixed_length;
   }

	/*
	 * @see EPDC_Base#varLen()
	 */
	protected int varLen() {
		return 0;
	}

   private int _every;
   private int _to;
   private int _from;
   private static final int _fixed_length = 12;


}
