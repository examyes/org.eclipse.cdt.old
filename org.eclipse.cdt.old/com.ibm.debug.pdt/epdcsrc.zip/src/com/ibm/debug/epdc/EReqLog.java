package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Base class for all logging related requests
 * New in EPDC level 308
 */
abstract class EReqLog extends EPDC_Request {


	/**
	 * Constructor to create the initial request
	 * Follow this with a call to output() to send the request
	 * @param type	the type of logging request
	 * @param cmd 	the command string
	 */

	protected EReqLog(int type, String cmd) {
		super(type);
		// EExtString is used to handle potentially long strings
		_logString = new EExtString(cmd);
	}


	/**
	 * Constructor to create the request from a buffer.
	 * Normally this is used on the receiving end of the request to reconstruct it 
	 * from the communication buffer
	 * @param inbuffer contains the request to be decoded
	 * @throws IOException if there are any communication errors getting the buffer
	 * contents.
	 */

	protected EReqLog(byte[] inBuffer) throws IOException {
		super(inBuffer);
		readInt();   		// reserved
		_offsetLogString = readOffset();
		markOffset();
	}

	/**
	 * Write out the request to the output buffer
	 */

	void output(DataOutputStream dataOutputStream) throws IOException {
		super.output(dataOutputStream);
		
		int offset = fixedLen() + super.varLen();  // get the starting offset

		// write out the fixed portion of the request

		dataOutputStream.writeInt(0);   // reserved

		// write out the offset of the command string
		offset += writeOffsetOrZero(dataOutputStream, offset, _logString);

		// now write out the variable portion
		
		if (_logString != null)
			_logString.output(dataOutputStream);
	}



	/**
	 * get the command string from the request
	 * @return Requested command string
	 */

	public String getString() {
		if (_logString != null)
			return _logString.string();
		else {
			if (_offsetLogString > 0) {
				try {
					posBuffer(_offsetLogString);
					_logString = readExtString();
				} catch(IOException e) {
					return null;
				}
				return _logString.string();
			} else
				return null;

		}
	}
	
	protected int fixedLen() {
		return super.fixedLen() + _fixed_length;
	}

	protected int varLen() {
		return super.varLen() + totalBytes(_logString);
	}

	// data fields
	private int _offsetLogString;
	private EExtString _logString;
	private static final int _fixed_length = 8;
}
