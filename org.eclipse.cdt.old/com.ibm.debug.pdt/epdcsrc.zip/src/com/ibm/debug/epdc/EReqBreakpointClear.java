package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Clear breakpoint request
 */
public class EReqBreakpointClear extends EPDC_Request {

   public EReqBreakpointClear(int bkpID)
   {
     super(EPDC.Remote_BreakpointClear);
     _bkpID = bkpID;
   }

   /**
    * Decodes request from an input buffer
    * @exception IOException if an I/O error occurs
    */
   EReqBreakpointClear(byte[] inBuffer) throws IOException {
      super(inBuffer);

      _bkpID = readInt();
   }

   /**
    * Return breakpoint ID
    */
   public int bkpID() {
      return _bkpID;
   }

   protected int fixedLen()
   {
     return _fixed_length + super.fixedLen();
   }

   void output(DataOutputStream dataOutputStream)
   throws IOException
   {
      super.output(dataOutputStream);

      dataOutputStream.writeInt(_bkpID);
   }

   // Data fields
   private int _bkpID;
   private static final int _fixed_length = 4;


}

