package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////



/**
 * The class to construct a watchpoint breakpoint (either adding a new
 * address change breakpoint or replacing one).
 */
public class EReqBreakpointWatchpoint extends EReqBreakpointEvent
{
  /**
   * Constuctor to set an address change breakpoint
   */
  public EReqBreakpointWatchpoint(short attr,
                                  EEveryClause clause,
                                  String addrOrExpr,
                                  String moduleName,
                                  String partName,
                                  String fileName,
                                  EStdExpression2 condition,
                                  int byteCount,
                                  EStdView context,
                                  int threadID,  // 0 for all threads
                                  String computedAddress)
  {
    super(EPDC.SetBkp,
          (short)EPDC.ChangeAddrBkpType,
          attr,
          clause,
          addrOrExpr,
          moduleName,
          partName,
          fileName,
          condition,
          byteCount,
          context,
          threadID,
          0,          // bkp ID
          computedAddress);
  }

  /**
   * Constructor to replace an address change breakpoint
   */

  public EReqBreakpointWatchpoint(short attr,
                                  EEveryClause clause,
                                  String addrOrExpr,
                                  String moduleName,
                                  String partName,
                                  String fileName,
                                  EStdExpression2 condition,
                                  int byteCount,
                                  EStdView context,
                                  int threadID,  // 0 for all threads
                                  int bkpID,     // ID of bkp being replaced
                                  String computedAddress)
  {
    super(EPDC.ReplaceBkp,
          (short)EPDC.ChangeAddrBkpType,
          attr,
          clause,
          addrOrExpr,  // Addr bkps only
          moduleName,
          partName,
          fileName,
          condition,
          byteCount,
          context,
          threadID,
          bkpID,
          computedAddress);
  }
}
