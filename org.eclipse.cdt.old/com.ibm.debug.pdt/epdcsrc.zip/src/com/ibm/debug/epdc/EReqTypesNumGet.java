package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * TypesNumGet Request
 */
public class EReqTypesNumGet extends EPDC_Request {

   EReqTypesNumGet(byte[] inBuffer) throws IOException {
      super(inBuffer);
      _languageId = readInt();
   }

   public EReqTypesNumGet(int languageId)
   {
     super(EPDC.Remote_TypesNumGet);
     _languageId = languageId;
   }

   protected int fixedLen() {
      return _fixed_length + super.fixedLen();
   }

   protected int varLen() {
      return super.varLen();
   }

   /**
    * return the part id
    */
   public int languageId() {
      return _languageId;
   }

   void output(DataOutputStream dataOutputStream)
      throws IOException
   {
      super.output(dataOutputStream);
      dataOutputStream.writeInt(_languageId);
   }

   // Datafields
   private int _languageId;

   private static final int _fixed_length = 4;
}

