package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Free stack request
 */
public class EReqStackFree extends EPDC_Request {

  public EReqStackFree(int stackDU)
  {
    super(EPDC.Remote_StackFree);

    _stackDU = stackDU;
  }

  void output(DataOutputStream dataOutputStream)
  throws IOException
  {
    super.output(dataOutputStream);

    dataOutputStream.writeInt(_stackDU);
  }

  /**
   * Return size of "fixed" portion
   */
  protected int fixedLen()
  {
    int total = _fixed_length + super.fixedLen();

    return total;
  }

   /**
    * Decodes request from an input buffer
    * @exception IOException if an I/O error occurs
    */
   EReqStackFree (byte[] inBuffer) throws IOException {
      super(inBuffer);

      _stackDU = readInt();
   }

   /**
    * Get the dispatchable unit for stack
    */
   public int stackDU() {
      return _stackDU;
   }

   // data fields
   private int _stackDU;

   private static final int _fixed_length = 4;
}

