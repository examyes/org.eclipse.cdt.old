package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * RepForTypeSet Request
 */
public class EReqRepForTypeSet extends EPDC_Request {

   EReqRepForTypeSet(byte[] inBuffer) throws IOException {
      super(inBuffer);
      _languageId = readInt();
      _typeIndex = readInt();
      _rep = readInt();
   }

   public EReqRepForTypeSet(int languageId,int typeIndex,int rep)
   {
     super(EPDC.Remote_RepForTypeSet);
     _languageId = languageId;
      _typeIndex = typeIndex;
      _rep = rep;
   }

   protected int fixedLen() {
      return _fixed_length + super.fixedLen();
   }

   protected int varLen() {
      return super.varLen();
   }

   /**
    * return the part id
    */
   public int languageId() {
      return _languageId;
   }

   public int typeIndex() {
      return _typeIndex;
   }

   public int rep() {
      return _rep;
   }

   void output(DataOutputStream dataOutputStream)
      throws IOException
   {
      super.output(dataOutputStream);
      dataOutputStream.writeInt(_languageId);
      dataOutputStream.writeInt(_typeIndex);
      dataOutputStream.writeInt(_rep);
   }

   // Datafields
   private int _languageId;
   private int _typeIndex;
   private int _rep;

   private static final int _fixed_length = 12;
}

