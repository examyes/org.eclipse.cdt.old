package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


/**
 * Interface for formatting messages in EPDC
 * EPDC allows the engine to pass back a message in a special format.
 * The contents of the buffer are passed to the class that implements
 * this method and a String is expected in return.
 * The name of the class that implements this interface is passed in the
 * reply to initialize Debug Engine.
 */

public interface IFormattedString {

	/**
	 * Called to decode a message string 
	 * @param buffer that contains the message to be decoded.
	 * @return String that will be displayed on the UI.
	 * @throws any exception will be considered an error and the string will not be used
	 */
	public String decodeString(final byte[] buffer) throws Exception;

}
