package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1998, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

public class EReqContextQualGet extends EPDC_Request
{
  // Debug Engine Functions and Data

  EReqContextQualGet(byte[] inBuffer) throws IOException {
    super(inBuffer);

    // Read in EStdView
    _context = new EStdView(inBuffer, getOffset());
  }

  public EStdView context() {
    return _context;
  }

  private EStdView _context;

   // Debug Front End Functions and Data

   public EReqContextQualGet(EStdView context)
   {
     super(EPDC.Remote_ContextQualGet);
     _context = context;
   }

   protected int fixedLen() {
      return totalBytes(_context) + super.fixedLen();
   }

  void output(DataOutputStream dataOutputStream)
    throws IOException
  {
      super.output(dataOutputStream);
      _context.output(dataOutputStream);
  }
}

