package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * ProcessAttach Request
 */
public class EReqProcessAttach extends EPDC_Request {

	/**
	 * Given an array of bytes this constructor will decode the request
	 */
	EReqProcessAttach(byte[] inBuffer) throws IOException {
		super(inBuffer);
		_ReqProcessId = readInt();
		_ReqProcessPathOffset = readOffset();
		readInt(); // reserved
		_ReqEventHandlerId = readInt();

		markOffset(); // save current position as the end of fixed part
		
		// the following is after the mark because the fixed len was not bumped to 
		// include this field.
		// see comment at end of this file
		
		if (getEPDCVersion() > 305)
			_dominantLanguage = readChar();

	}

	public EReqProcessAttach(int processId, String processPath, int eventHandlerID, // For Debug-On-Demand
	byte dominantLanguage) {
		super(EPDC.Remote_ProcessAttach);
		_ReqProcessId = processId;

		if (processPath != null)
			_ReqProcessPath = new EStdString(processPath);

		_ReqEventHandlerId = eventHandlerID;

		_dominantLanguage = dominantLanguage;
	}

	/**
	 * Returns the process id we are to attach to
	 */
	public int processId() {
		return _ReqProcessId;
	}

	/**
	 * Returns the process path for this request
	 */
	public String processPath() throws IOException {
		if (_ReqProcessPath == null)
			if (_ReqProcessPathOffset != 0) {
				posBuffer(_ReqProcessPathOffset);
				_ReqProcessPath = readStdString();
			} else
				return null;

		return _ReqProcessPath.string();
	}




	public byte dominantLanguage() {
		return _dominantLanguage;
	}

	/** Return the length of the fixed component */
	protected int fixedLen() {
		if (getEPDCVersion() > 305)
			return _fixed_length + super.fixedLen() + 1;

		return _fixed_length + super.fixedLen();
	}

	/** Return the length of the variable component */
	protected int varLen() {
		return super.varLen() + totalBytes(_ReqProcessPath);
	}

	void output(DataOutputStream dataOutputStream) throws IOException {
		super.output(dataOutputStream);

		int offset = fixedLen() + super.varLen(); // Our starting offset for writing
		// out variable length data

		// Write out the offsets of the variable length data:

		dataOutputStream.writeInt(_ReqProcessId);
		offset += writeOffsetOrZero(dataOutputStream, offset, _ReqProcessPath);
		dataOutputStream.writeInt(0);  // reserved
		dataOutputStream.writeInt(_ReqEventHandlerId);

		if (getEPDCVersion() > 305)
			dataOutputStream.writeByte(_dominantLanguage);

		// Now write out the variable length data:

		if (_ReqProcessPath != null)
			_ReqProcessPath.output(dataOutputStream);

	}

	private int _ReqProcessId;

	private int _ReqProcessPathOffset;
	private EStdString _ReqProcessPath;

	private int _ReqEventHandlerId;

	// Even though the dominant language is added to the fixed part we will not
	// change the _fixed_length so that we will not break compatibility will
	// EPDC versions that are less than 306. The extra byte is added to the
	// fixedLen method
	private byte _dominantLanguage;

	private static final int _fixed_length = 16;
}
