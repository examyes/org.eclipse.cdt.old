package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Remove a module
 */
public class EReqModuleRemove extends EPDC_Request
{
  public EReqModuleRemove(int moduleId)
  {
    super(EPDC.Remote_ModuleRemove);

    _moduleId = moduleId;
  }

  void output(DataOutputStream dataOutputStream)
  throws IOException
  {
    super.output(dataOutputStream);

    dataOutputStream.writeInt(_moduleId);
  }

  /**
   * Return module type
   */
  public int moduleId()
  {
    return _moduleId;
  }

  protected int fixedLen()
  {
    return _fixed_length + super.fixedLen();
  }

  // data fields
  private int _moduleId;


  private static final int  _fixed_length = 4;
}
