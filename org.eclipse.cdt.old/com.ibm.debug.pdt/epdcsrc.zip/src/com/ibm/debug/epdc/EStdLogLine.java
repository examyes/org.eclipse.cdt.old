package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * All logging types must subclass this
 * Represents a single line of text that the debug engine has generated
 * This includes program output/error and command logging
 */

abstract public class EStdLogLine extends EPDC_Structures {

	private EExtString _logLine;
	private int _logLineType;

	/**
	 * Create a log line from a string
	 * @param logLine is a string that represents a single log line
	 */

	protected EStdLogLine(int logType, String logLine) {
		_logLineType = logType;
		_logLine = new EExtString(logLine);
	}

	protected EStdLogLine(DataInputStream dataInputStream) {
		
		try {
			_logLine = new EExtString(dataInputStream);
		} catch(IOException e) {
			_logLine = null;
		}
	}

	protected static EStdLogLine createLogLine(DataInputStream dis) {

		int type;
		
		try {
			dis.skipBytes(4); 		// reserved
			type = dis.readInt();	// read the type of log line
		} catch(IOException e) {
			return null;
		}
		
		switch (type) {
			case EPDC.LogCommandLine :
				return new EStdCmdLogLine(dis);

			case EPDC.LogProgramOutput:
				return new EStdPgmOutputLine(dis);
			
			case EPDC.LogProgramError:
				return new EStdPgmErrorLine(dis);
			
			default :
				return null;
		}
	}



	/**
	 * Get the log line as a String
	 * @return String or null
	 */
	public String getLogLineString() {
		EExtString es = getLogLine();
		if (es != null)
			return es.string();
		else
			return null;		
	}


	/**
	 * Gets the logLine.
	 * @return Returns a EExtString
	 */
	protected EExtString getLogLine() {
		return _logLine;
	}

	/*
	 * @see EPDC_Base#fixedLen()
	 */
	protected int fixedLen() {
		return 8;
	}

	
	/*
	 * @see EPDC_Base#varLen()
	 */
	protected int varLen() {
		return totalBytes(_logLine);
	}

	/*
	 * @see EPDC_Base#output(DataOutputStream)
	 */
	void output(DataOutputStream dataOutputStream) throws IOException {
		
		dataOutputStream.writeInt(0);  // reserved
		dataOutputStream.writeInt(_logLineType);
		_logLine.output(dataOutputStream);
	}

	
	
}
