package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

public class ModuleChangeInfo extends EPDC_ChangeInfo {
	
	protected ModuleChangeInfo() {
		super(EPDC.MODULE_ENTRY_INFO);
	}
	
	protected ModuleChangeInfo(byte[] packetBuffer, DataInputStream dataInputStream)
		throws IOException {
		super(packetBuffer, dataInputStream); // Construct packet header

		// Get all the changed items and add them to the vector of changed items:

		if (changeItemsInThisPacket() == 1)
			addChangedItem(new ERepNextModuleEntry(packetBuffer, dataInputStream), false);
		else
			for (int i = 0; i < changeItemsInThisPacket(); i++) {
				int offset = dataInputStream.readInt();

				addChangedItem(
					new ERepNextModuleEntry(
						packetBuffer,
						new OffsetDataInputStream(packetBuffer, offset)),
					false);
			}
	}
}
