package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * ProcessDetach Request
 */
public class EReqProcessDetach extends EPDC_Request {

  /**
   * Given an array of bytes this constructor will decode the request
   *
   */
   EReqProcessDetach( byte[] inBuffer ) throws IOException {
      super( inBuffer );
      _ReqProcessId = readInt();
      _ReqProcessDetachAction = readInt();

      markOffset();   // save current position as the end of fixed part
   }

   public EReqProcessDetach(int processId, int processDetachAction)
   {
     super(EPDC.Remote_ProcessDetach);
     _ReqProcessId = processId;
     _ReqProcessDetachAction = processDetachAction;
   }

   public int processId() {
      return _ReqProcessId;
   }

   public int processDetachAction() {
      return _ReqProcessDetachAction;
   }

   /** Return the length of the fixed component */
   protected int fixedLen() {
      return _fixed_length + super.fixedLen();
   }

  void output(DataOutputStream dataOutputStream)
    throws IOException
  {
      super.output(dataOutputStream);

      writeInt(dataOutputStream, _ReqProcessId);
      writeInt(dataOutputStream, _ReqProcessDetachAction);
   }

   private int _ReqProcessId;
   private int _ReqProcessDetachAction;

   private static final int _fixed_length = 8;
}
