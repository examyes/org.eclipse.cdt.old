package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Deference pointer reply
 */
public class ERepPointerDeref extends EPDC_BasicReply {

   public ERepPointerDeref() {
      super(EPDC.Remote_PointerDeref);
   }



}
