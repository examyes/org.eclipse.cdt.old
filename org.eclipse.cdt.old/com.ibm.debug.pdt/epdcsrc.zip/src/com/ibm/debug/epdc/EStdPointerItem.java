package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Class corresponding to an EStdPointerItem structure.
 */
public class EStdPointerItem extends EStdGenericNode {

	/**
	 * Create a new EStdPointerItem class
	 * @param exprID expression id that is used to dereference this pointer
	 * @param pointerName the name of the pointer variable
	 * @param pointerType the type of the pointer variable
	 * @param pointerRefType the type the pointer variable points to
	 * @param pointerValue string that represents the value of the pointer
	 * @param defPointerRepIndex the index into <code> pointerReps </code> of the default representation.
	 * @param pointerReps list of possible representations
	 */

	public EStdPointerItem(
		short exprID,
		String pointerName,
		String pointerType,
		String pointerRefType,
		String pointerValue,
		short defPointerRepIndex,
		short[] pointerReps) {

		super(EPDC.StdPointerNode);

		_exprID = exprID;
		_pointerName = new EStdString(pointerName);
		_pointerType = new EStdString(pointerType);
		_pointerRefType = new EStdString(pointerRefType);
		_pointerValue = new EStdString(pointerValue);
		_defPointerRepIndex = defPointerRepIndex;
		_pointerReps = pointerReps;
	}

	public EStdPointerItem(
		byte[] packetBuffer,
		DataInputStream dataInputStream,
		short nodeType)
		throws IOException {
		super(nodeType);

		dataInputStream.readShort(); //reserved

		_exprID = dataInputStream.readShort();

		int offset;

		if ((offset = dataInputStream.readInt()) != 0) {
			_pointerName =
				(new EStdString(packetBuffer, new OffsetDataInputStream(packetBuffer, offset)));
		}

		if ((offset = dataInputStream.readInt()) != 0) {
			_pointerType =
				(new EStdString(packetBuffer, new OffsetDataInputStream(packetBuffer, offset)));
		}

		if ((offset = dataInputStream.readInt()) != 0) {
			_pointerRefType =
				(new EStdString(packetBuffer, new OffsetDataInputStream(packetBuffer, offset)));
		}

		if ((offset = dataInputStream.readInt()) != 0) {
			_pointerValue =
				(new EStdString(packetBuffer, new OffsetDataInputStream(packetBuffer, offset)));
		}

		_defPointerRepIndex = dataInputStream.readShort();
		_numValueReps = dataInputStream.readShort();

		_pointerReps = new short[_numValueReps];
		for (int i = 0; i < _numValueReps; i++) {
			_pointerReps[i] = dataInputStream.readShort();
		}
	}

	/**
	 * Return "fixed" length
	 */
	protected int fixedLen() {
		return _fixed_length + _pointerReps.length * 2;
	}

	/**
	 * Get the name of the pointer variable
	 */
	public String getName() {
		if (_pointerName != null)
			return _pointerName.string();
		else
			return null;
	}

	/**
	 * Get the type of the pointer variable
	 */
	public String getType() {
		if (_pointerType != null)
			return _pointerType.string();
		else
			return null;
	}

	/**
	 * Get the reference type of the pointer variable
	 */
	public String getRefType() {
		if (_pointerRefType != null)
			return _pointerRefType.string();
		else
			return null;
	}

	/**
	 * Get the contents of the variable
	 */
	public String getValue() {
		if (_pointerValue != null)
			return _pointerValue.string();
		else
			return null;
	}
	/**
	 * Return the current representation index
	 */
	public short getDefRep() {
		return _defPointerRepIndex;
	}

	/**
	 * Return the array of all possible representation indices
	 * of this type
	 */
	public short[] getArrayOfReps() {
		return _pointerReps;
	}

	/* (non-Javadoc)
	 * @see EStdGenericNode#toDataStreams(DataOutputStream, DataOutputStream, int)
	 */
	protected int toDataStreams(
		DataOutputStream fixedData,
		DataOutputStream varData,
		int baseOffset)
		throws IOException, BadEPDCCommandException {

		int totalSize = _fixed_length;

		writeShort(fixedData, EPDC.StdPointerNode);
		writeShort(fixedData, (short)0); // reserved

		writeShort(fixedData, _exprID);

		int offset = baseOffset;

		offset += writeOffsetOrZero(fixedData, offset, _pointerName);
		if (_pointerName != null) {
			_pointerName.output(varData);
			totalSize += _pointerName.totalBytes();
		}

		offset += writeOffsetOrZero(fixedData, offset, _pointerType);
		if (_pointerType != null) {
			_pointerType.output(varData);
			totalSize += _pointerType.totalBytes();
		}

		offset += writeOffsetOrZero(fixedData, offset, _pointerRefType);
		if (_pointerRefType != null) {
			_pointerRefType.output(varData);
			totalSize += _pointerRefType.totalBytes();
		}
			
		offset += writeOffsetOrZero(fixedData, offset, _pointerValue);
		if (_pointerValue != null) {
			_pointerValue.output(varData);
			totalSize += _pointerValue.totalBytes();
		}			

		writeShort(fixedData, _defPointerRepIndex); // default representation

		short numReps = (short) _pointerReps.length;
		writeShort(fixedData, numReps); // number of representations

		totalSize += numReps * 2;
		for (int i = 0; i < numReps; i++)
			writeShort(fixedData, _pointerReps[i]);

		return totalSize;
	}

	/* (non-Javadoc)
	 * @see EPDC_Base#varLen()
	 */
	protected int varLen() {
		return super.varLen() 
					+ totalBytes(_pointerName)
					+ totalBytes(_pointerType)
					+ totalBytes(_pointerRefType)
					+ totalBytes(_pointerValue);
	}


	// data fields
	private short _exprID;
	private EStdString _pointerName;
	private EStdString _pointerType;
	private EStdString _pointerRefType;
	private EStdString _pointerValue;
	private short _defPointerRepIndex;
	private short _numValueReps;
	private short[] _pointerReps;

	private static final int _fixed_length = 26;


}