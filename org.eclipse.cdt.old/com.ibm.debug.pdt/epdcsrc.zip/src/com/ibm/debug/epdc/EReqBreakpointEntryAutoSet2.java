package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

public class EReqBreakpointEntryAutoSet2 extends EPDC_Request
{
  public EReqBreakpointEntryAutoSet2(boolean enableAutoSetEntryBreakpoints,
                                     boolean enableDateBreakpoints)
  {
    super(EPDC.Remote_BreakpointEntryAutoSet2);

    if (enableAutoSetEntryBreakpoints)
       _enablementFlags = EPDC.AutoSetEntryBkpEnable;

    if (enableDateBreakpoints)
       _enablementFlags |= EPDC.DateBkpEnable;
  }

  void output(DataOutputStream dataOutputStream)
  throws IOException
  {
    super.output(dataOutputStream);

    dataOutputStream.writeInt(_enablementFlags);
  }

  protected int fixedLen()
  {
     return _fixed_length + super.fixedLen();
  }

  private int _enablementFlags;

  private static final int _fixed_length = 4;
}
