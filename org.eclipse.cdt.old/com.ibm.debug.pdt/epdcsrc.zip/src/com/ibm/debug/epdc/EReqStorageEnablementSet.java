package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

public class EReqStorageEnablementSet extends EPDC_Request
{
  public EReqStorageEnablementSet(short storageID,
                                  boolean enableStorage,
                                  boolean enableExpression)
  {
    super(EPDC.Remote_StorageEnablementSet);

    _storageID = storageID;

    if (enableStorage)
       _enablementFlags = EPDC.StorageEnabled;

    if (enableExpression)
       _enablementFlags |= EPDC.StorageExprEnabled;
  }

   /**
    * Decodes request from an input buffer
    * @exception IOException if an I/O error occurs
    */
   EReqStorageEnablementSet (byte[] inBuffer) throws IOException {
      super(inBuffer);

      _storageID = readShort();
      _enablementFlags = readInt();
   }

  void output(DataOutputStream dataOutputStream)
  throws IOException
  {
    super.output(dataOutputStream);

    dataOutputStream.writeShort(_storageID);
    dataOutputStream.writeInt(_enablementFlags);
  }

  protected int fixedLen()
  {
     return _fixed_length + super.fixedLen();
  }

  private short _storageID;
  public  short getID() { return _storageID; }
  private int _enablementFlags;
  public  int getEnablementFlags() { return _enablementFlags; }

  private static final int _fixed_length = 6;
}
