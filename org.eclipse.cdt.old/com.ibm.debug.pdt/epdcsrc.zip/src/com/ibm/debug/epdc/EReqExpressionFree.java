package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Free expression monitor request
 */
public class EReqExpressionFree extends EPDC_Request {

   /**
    * Decodes request from an input buffer
    * @exception IOException if an I/O error occurs
    */
   EReqExpressionFree(byte[] inBuffer) throws IOException {
      super(inBuffer);

      _exprID = readShort();
   }

   public EReqExpressionFree(short id)
   {
      super(EPDC.Remote_ExpressionFree);

      _exprID = id;
   }

   /**
    * Return expression ID
    */
   public short exprID() {
      return _exprID;
   }

   protected int fixedLen()
   {
     return _fixed_length + super.fixedLen();
   }

   void output(DataOutputStream dataOutputStream)
   throws IOException
   {
      super.output(dataOutputStream);

      dataOutputStream.writeShort(_exprID);
   }

   // data fields
   private short _exprID;
   private static final int _fixed_length = 2;


}
