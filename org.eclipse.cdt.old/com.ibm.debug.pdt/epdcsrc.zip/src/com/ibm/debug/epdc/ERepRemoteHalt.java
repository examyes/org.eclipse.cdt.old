package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Monitor stack reply -- only contains reply header
 */
public class ERepRemoteHalt extends EPDC_BasicReply {

   public ERepRemoteHalt() {
      super(EPDC.Remote_Halt);
   }

}

