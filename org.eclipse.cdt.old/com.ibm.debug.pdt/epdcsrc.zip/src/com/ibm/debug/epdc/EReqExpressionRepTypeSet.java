package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Set expression representation type request
 */
public class EReqExpressionRepTypeSet extends EPDC_Request {

   /**
    * Decodes request from an input buffer
    * @exception IOException if an I/O error occurs
    */
   EReqExpressionRepTypeSet (byte[] inBuffer) throws IOException {
      super(inBuffer);

      _exprID = readShort();
      _nodeID = readInt();
      _newRepType = readShort();
   }

   public EReqExpressionRepTypeSet(short exprID, int nodeID, short nodeIndex)
   {
      super(EPDC.Remote_ExpressionRepTypeSet);

      _exprID = exprID;
      _nodeID = nodeID;
      _newRepType = nodeIndex;
   }

   /**
    * Return expression ID
    */
   public short exprID() {
      return _exprID;
   }

   /**
    * Return tree node ID
    */
   public int nodeID() {
      return _nodeID;
   }

   /**
    * Return new representation type
    */
   public short newRepType() {
      return _newRepType;
   }

  /**
    * Return the length of the fixed component
    */

   protected int fixedLen()
   {
     return _fixed_length + super.fixedLen();
   }

   void output(DataOutputStream dataOutputStream)
   throws IOException
   {
     super.output(dataOutputStream);

     dataOutputStream.writeShort(_exprID);
     dataOutputStream.writeInt(_nodeID);
     dataOutputStream.writeShort(_newRepType);
   }

   // data fields
   private short _exprID;
   private int _nodeID;
   private short _newRepType;

   private static final int _fixed_length = 8;


}
