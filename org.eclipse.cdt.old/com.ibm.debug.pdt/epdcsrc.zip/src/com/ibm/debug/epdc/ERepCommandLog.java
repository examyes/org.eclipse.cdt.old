package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.DataInputStream;
import java.io.IOException;

/**
 * Reply to CommandLog request
 * This is a standard reply
 */
public class ERepCommandLog extends EPDC_BasicReply {
	
	/**
	 * Command log basic reply
	 */
	public ERepCommandLog() {
		super(EPDC.Remote_CommandLog);
	}

}
