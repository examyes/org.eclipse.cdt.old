package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Termiante Debug Engine Request.  This contains no fixed or variable components,
 * only the request header.
 */
public class EReqTerminateDE extends EPDC_Request {

   public EReqTerminateDE()
   {
      super(EPDC.Remote_Terminate_Debug_Engine);
   }

   EReqTerminateDE(byte[] inBuffer) throws IOException {
      super (inBuffer);
   }
}
