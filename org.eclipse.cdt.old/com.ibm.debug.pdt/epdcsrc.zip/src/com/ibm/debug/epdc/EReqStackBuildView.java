package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Request to get stack view information
 */

public class EReqStackBuildView extends EPDC_Request {

  public EReqStackBuildView(int stackDU, int stackEntryID)
  {
    super (EPDC.Remote_StackBuildView);

    _stackDU = stackDU;
    _stackEntryID = stackEntryID;
  }

  void output(DataOutputStream dataOutputStream)
  throws IOException
  {
    super.output(dataOutputStream);

    dataOutputStream.writeInt(_stackDU);
    dataOutputStream.writeInt(_stackEntryID);
  }

   EReqStackBuildView(byte[] inBuffer) throws IOException {
      super(inBuffer);

      _stackDU = readInt();
      _stackEntryID = readInt();
   }

   public int stackDU() {
      return _stackDU;
   }

   public int stackEntryID() {
      return _stackEntryID;
   }

   /**
    * Return size of "fixed" portion
    */
   protected int fixedLen()
   {
      int total = _fixed_length + super.fixedLen();

      return total;
   }

   void write(PrintWriter printWriter)
   {
     super.write(printWriter);

     indent(printWriter);

     printWriter.print("Thread: " + _stackDU);
     printWriter.println("    Stack frame ID: " + _stackEntryID);
   }

   // data fields
   private int _stackDU;
   private int _stackEntryID;

   private static final int _fixed_length = 8;
}
