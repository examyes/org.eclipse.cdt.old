package com.ibm.debug.epdc;
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.DataInputStream;

/**
 * Represents a single line of text that has come from the program under 
 * debug control.   Typlically stderr output
 */

public class EStdPgmErrorLine extends EStdLogLine {

	
	/**
	 * Constructor for EStdPgmInputLine.
	 * @param dataInputStream
	 */
	protected EStdPgmErrorLine(DataInputStream dataInputStream) {
		super(dataInputStream);
	}
	/**
	 * Constructor for EStdPgmOutputLine.
	 * @param logLine
	 */
	public EStdPgmErrorLine(String logLine) {
		super(EPDC.LogProgramError,logLine);
	}

	


}
