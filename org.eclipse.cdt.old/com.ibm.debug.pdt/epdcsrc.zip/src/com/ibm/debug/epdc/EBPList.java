package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

/**
 * Breakpoint information returned by an EPDC Execute reply packet
 */
public class EBPList extends EPDC_Structures {

   EBPList(int BPId, byte BPKind) {
      _StdBPId = BPId;
      _StdBPKind = BPKind;
   }

   EBPList( byte[] packetBuffer, DataInputStream dataInputStream)
   throws IOException
   {
      _StdBPId = dataInputStream.readInt();
      _StdBPKind = dataInputStream.readByte();

      for (int i=0; i<3; i++)
          dataInputStream.readByte();         // reserved
   }

   /** Output class to data streams according to EPDC protocol.
    * @exception IOException if an I/O error occurs
    * @exception BadEPDCCommandException if the EPDC command
    *    is structured incorrectly
    */
   protected int toDataStreams(DataOutputStream fixedData,
         DataOutputStream varData, int baseOffset)
         throws IOException, BadEPDCCommandException {

      writeInt(fixedData, _StdBPId);
      writeChar(fixedData, _StdBPKind);

      for (int i=0; i<3; i++)
         writeChar(fixedData, (byte) 0);         // reserved

      return fixedLen();
   }

   protected int fixedLen() {
      return _fixed_length;
   }

   /**
    * Static function that returns the fixed length.  Used by ERepExecute so that it
    * does not have to call the instance method fixedLen()
    * @see ERepExecute
    */
   protected static int statfixedLen() {
      return _fixed_length;
   }

   protected int varLen() {
      return 0;
   }

   public int getBreakid() {
      return _StdBPId;
   }

   // data fields
   private int _StdBPId;         // breakpoint id
   private byte _StdBPKind;       // breakpoint kind

   private static final int _fixed_length = 8;


	/*
	 * @see EPDC_Base#output(DataOutputStream)
	 */
	void output(DataOutputStream dataOutputStream) throws IOException {
		// to be implemented
	}

}

