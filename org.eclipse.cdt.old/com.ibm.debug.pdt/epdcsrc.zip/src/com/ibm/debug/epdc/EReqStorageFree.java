package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
////////////////////////////////////////////////////////////////////////////////


import java.io.*;

public class EReqStorageFree extends EPDC_Request
{
  public EReqStorageFree(short id)
  {
    super(EPDC.Remote_StorageFree);

    _id = id;
  }

  protected int fixedLen()
  {
    return _fixed_length + super.fixedLen();
  }

   /**
    * Decodes request from an input buffer
    * @exception IOException if an I/O error occurs
    */
   EReqStorageFree (byte[] inBuffer) throws IOException {
      super(inBuffer);

      _id = readShort();
   }

  void output(DataOutputStream dataOutputStream)
  throws IOException
  {
     super.output(dataOutputStream);

     dataOutputStream.writeShort(_id);
  }

  private short _id;
  public short  getID()
  { return _id;  }

  private final static int _fixed_length = 2;
}
