package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */


import java.io.DataInputStream;

/**
 * Represents a single line of text that has come from the program under debug control
 */

public class EStdPgmOutputLine extends EStdLogLine {

	
	/**
	 * Constructor for EStdPgmOutputLine.
	 * @param dataInputStream
	 */
	protected EStdPgmOutputLine(DataInputStream dataInputStream) {
		super(dataInputStream);
	}

	/**
	 * Constructor for EStdPgmOutputLine.
	 * @param logLine
	 */
	public EStdPgmOutputLine(String logLine) {
		super(EPDC.LogProgramOutput,logLine);
	}

	
}
