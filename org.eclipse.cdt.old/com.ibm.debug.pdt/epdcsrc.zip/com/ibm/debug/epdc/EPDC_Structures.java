package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.io.DataOutputStream;
import java.io.IOException;

/**
 * Represents structures used in replies
 */
abstract class EPDC_Structures extends EPDC_Base {

	/*
	 * @see EPDC_Base#output(DataOutputStream)
	 */
	/**
	 * Constructor for EPDC_Structures.
	 * @param inBuffer
	 * @throws IOException
	 */
	protected EPDC_Structures(byte[] inBuffer) throws IOException {
		super(inBuffer);
	}

	/**
	 * Constructor for EPDC_Structures.
	 * @param inBuffer
	 * @param offset
	 * @throws IOException
	 */
	protected EPDC_Structures(byte[] inBuffer, int offset) throws IOException {
		super(inBuffer, offset);
	}

	/**
	 * Constructor for EPDC_Structures.
	 */
	protected EPDC_Structures() {
		super();
	}

	protected void output(DataOutputStream dataOutputStream) throws IOException {
		// to be implemented in derived classes
		// remove this once implemented in derived classes
	}

	/*
	 * @see EPDC_Base#varLen()
	 */
	protected int varLen() {
		return 0;
	}

	/*
	 * @see EPDC_Base#getName()
	 */
	public String getName() {
		String name = getClass().getName();

		int indexOfLastDot = name.lastIndexOf('.');

		if (indexOfLastDot != -1)
			name = name.substring(indexOfLastDot + 1);
		
		return name;
	}

}
