package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

/**
 * All text transported via EPDC must be in the form of an EExtString.
 * The EExtString class is used to convert Java String objects into
 * EPDC EExtStrings and vice versa.  EExtStrings are encoded
 * using the current encoding scheme as defined by the
 * method getEncoding().
 * <P>
 * Please note: Modifying the default encoding scheme via setEncoding()
 * will modify encoding/decoding for ALL EExtStrings.
 */

// NOTE: Please ensure that all conversion and sizing decisions are handled
// inside this class for maintainability.

class EExtString extends EPDC_Structures {
	
	/**
	 * Create an EExtString from a string.
	 * Use this for strings that can be > 32K
	 * @param s String
	 */
	protected EExtString(String string) {
		if (string != null) {
			try {
				_buffer = string.getBytes(ENCODING);
			} catch(UnsupportedEncodingException e) {
			}
		}
	}

	/**
	 * Create an EExtString from a byte array
	 * @param byteArray array of bytes.
	 */
	protected EExtString(byte[] byteArray) {
		_buffer = byteArray;
	}

	/**
	 * Create an EExtString from an Input Stream
	 * When special formatting is required then the engine session must be passed too
	 * @param dataInputStream input stream
	 * @throws IOException
	 */
	protected EExtString(DataInputStream dataInputStream, EPDC_EngineSession engineSession) throws IOException {
		this(dataInputStream);
		setEPDCEngineSession(engineSession);
	}
	
	/**
	 * Create an EExtString from an input datastream
	 * @param dataInputStream input datastream
	 * @throws IOException
	 */
	protected EExtString(DataInputStream dataInputStream) throws IOException {
		int arrayLen = dataInputStream.readInt();
		if (arrayLen < 0) {  // -ve length means special formatting inside
			_specialFormat = true;
			arrayLen = Math.abs(arrayLen);
		}
		_buffer = new byte[arrayLen];
		dataInputStream.read(_buffer);
	}

	protected int actual_read() {
		return fixedLen() + streamLength();
	}

	/**
	 * Returns the byte array
	 * @return byte[] array of bytes or null
	 */
	protected byte[] getBytes() {
		return _buffer;
	}

	/**
	 * Write a String to an output stream as an EExtString according to the
	 * current encoding scheme.  The current encoding scheme may be queried via
	 * getEncoding().
	 * @exception IOException if an I/O error occurs
	 */
	protected void output(DataOutputStream dataOutputStream) throws IOException {
		if (stringIsEmpty())
			return;

		dataOutputStream.writeInt(_buffer.length);

		dataOutputStream.write(_buffer);
	}

	private boolean stringIsEmpty() {
		return _buffer == null || (_buffer.length == 0);
	}

	/**
	 * Returns the String object this EExtString contains
	 */
	protected String string() {
		// the internal format is a byte array

		// first check if there is a string to return
		if (stringIsEmpty())
			return null;

		if (!_specialFormat) {
			try {
				return new String(_buffer, ENCODING);
			} catch (UnsupportedEncodingException e) {
				return null;
			}
		} else {

			// for special formatting support there must be the following:
			// 1) a valid engineSession
			// 2) formatting enabled
			// 3) valid formatting class

			if (getEPDCEngineSession() == null
				|| !getEPDCEngineSession().isFormattingEnabled()) {
				return null; // this could be some kind of backup processing
			} else { // use the formatting class 
				try {
					Class cls = Class.forName(getEPDCEngineSession().getFormattingJavaClassName());
					IFormattedString fs = (IFormattedString) cls.newInstance();
					String formattedString = fs.decodeString(_buffer);
					return formattedString;
				} catch (ClassNotFoundException e) {
					return null;
				} catch (Exception e) {
					return null;
				}
			}
		}
	}

	/**
	 * Returns the fixed length of this EExtString
	 */
	protected int fixedLen() {
		return 4;
	}

	/**
	 * Returns the number of bytes (_not_ the number of _characters) the
	 * specified string would occupy if it were written to a byte stream as an
	 * EExtString in the current encoding scheme.  The current encoding scheme
	 * may be queried via getEncoding().
	 */
	protected int varLen() {
		return streamLength();
	}

	
	
	/**
	 * Returns the total number of bytes this EExtString will occupy
	 */
	protected int totalBytes() {
		// NOTE:  We _MUST_ override EPDC_Base totalBytes because we need to
		// detect if our string is empty or not.  We don't output offsets for
		// empty strings.
		if (stringIsEmpty())
			return 0;

		return super.totalBytes();
	}

	/**
	 * Method streamLength.
	 * @return int length of stream
	 */
	protected int streamLength() {
		if (_buffer == null)
			return 0;
		else
			return _buffer.length;
	}

	private byte[] _buffer;
	private boolean _specialFormat = false;
	private final static String ENCODING = "UTF-8";

}