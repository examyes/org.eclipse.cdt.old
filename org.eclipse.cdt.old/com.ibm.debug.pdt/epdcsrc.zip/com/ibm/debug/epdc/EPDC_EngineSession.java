package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1997, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

/**
 * This class is a structure of EPDC information that contains information
 * about the current EPDC session
 */
public class EPDC_EngineSession {

	public short _debugEngineID;
	public short _debugEnginePlatformID;
	public int _defaultSettings;
	public int _processDetachAction;

	public ERepGetViews[] _viewInfo;
	public ERepGetLanguages[] _languageInfo;
	public ERepGetExceptions[] _exceptionsInfo;
	public EFunctCustTable _functCustomTable;

	public ERepTypesNumGet _repInfo;

	public int _negotiatedEPDCVersion;

	private boolean _formattingChecked = false;
	private boolean _formattingEnabled = false;
	private String _formattingJavaClassName;

	/**
	 * Check if string formatting enabled
	 */
	public boolean isFormattingEnabled() {
		if (_formattingJavaClassName == null)
			return false;
		if (_formattingChecked)
			return _formattingEnabled;
		else {	// check to see if formatting should be enabled
			_formattingChecked = true;
			// try to load the formatting class 
			// this will most likely have to be more complicated depending on how these classes are shipped.
			try {
				Class c = Class.forName(_formattingJavaClassName);
				if (IFormattedString.class.isInstance(c))
					_formattingEnabled = true;
			} catch(ClassNotFoundException e) {
			}
			return _formattingEnabled;
		}
	}
	
	/**
	 * Gets the formatting Java Class name
	 * @return Returns a String
	 */
	public String getFormattingJavaClassName() {
		return _formattingJavaClassName;
	}

	/**
	 * Sets the Java formatting Class Name.
	 * @param javaClassName The name of the Java class used to format Strings
	 */
	public void setFormattingJavaClassName(String javaClassName) {
		_formattingJavaClassName = javaClassName;
	}

}