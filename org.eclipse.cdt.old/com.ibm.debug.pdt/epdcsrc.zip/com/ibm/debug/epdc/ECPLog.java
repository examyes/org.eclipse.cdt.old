package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/**
 * This class represents 1 or more log lines that will become part of the command
 * log change packet.
 * There are 3 ways to use this class.
 * 1) create it with one line
 * 2) create it with an array of lines
 * 3) create it with no parms and add lines 
 */

public class ECPLog extends EPDC_ChangeItem {

	private ArrayList _logLines;

	private int _varLen = 0;

	/**
	 * Creates a command log with no lines.
	 * Add lines to this using the add???Line(String) methods
	 */

	public ECPLog() {
	}

	/**
	 * Used to decode an ECPLog from an incoming reply packet
	 * @param packetBuffer
	 * @param dataInputStream
	 * @param engineSession
	 * @throws IOException
	 */
	protected ECPLog(
		byte[] packetBuffer,
		DataInputStream dataInputStream,
		EPDC_EngineSession engineSession)
		throws IOException {

		dataInputStream.readInt(); // reserved for future use

		int numCommandLogLines = dataInputStream.readInt(); // number of log lines

		int lineArrayOffset = dataInputStream.readInt();

		// read in the array of lines

		// first get a buffer at the correct offset
		DataInputStream dis = new OffsetDataInputStream(packetBuffer, lineArrayOffset);

		if (_logLines == null)
			_logLines = new ArrayList();

		for (int i = 0; i < numCommandLogLines; i++)
			_logLines.add(EStdLogLine.createLogLine(dis));

	}

	/*
	 * @see EPDC_ChangeItem#toDataStreams(DataOutputStream, DataOutputStream, int)
	 */

	protected int toDataStreams(
		DataOutputStream fixedData,
		DataOutputStream varData,
		int baseOffset)
		throws IOException, BadEPDCCommandException {

		int offset = baseOffset;

		writeInt(fixedData, 0); // reserved

		int numCommandLogLines = _logLines.size();

		writeInt(fixedData, numCommandLogLines); // number of lines

		if (numCommandLogLines == 0) // if no lines write out 0 offset 
			writeInt(fixedData, 0);
		else {
			writeInt(fixedData, offset);
			for (int i = 0; i < numCommandLogLines; i++)
				 ((EStdLogLine) (_logLines.get(i))).output(varData);

		}

		return fixedLen() + varLen();
	}

	/*
	 * @see EPDC_Base#fixedLen()
	 */
	protected int fixedLen() {
		return 12;
	}

	/*
	 * @see EPDC_Base#varLen()
	 */
	protected int varLen() {
		if (_varLen == 0 && _logLines != null) { // if zero then calculate it
			// total up the length of all the lines
			for (int i = 0; i < _logLines.size(); i++)
				_varLen += ((EStdLogLine) (_logLines.get(i))).fixedLen()
					+ ((EStdLogLine) (_logLines.get(i))).varLen();

		}

		return _varLen;
	}

	/**
	 * Return an array of log lines
	 * @return array of log lines.  A zero length array will be returned if there 
	 * are no lines
	 */

	public EStdLogLine[] getLogLines() {
		if (_logLines == null)
			return new EStdLogLine[0];

		EStdLogLine[] tmpArray = new EStdLogLine[_logLines.size()];

		for (int i = 0; i < _logLines.size(); i++)
			tmpArray[i] = (EStdLogLine) (_logLines.get(i));

		return tmpArray;
	}

	/**
	 * Add a command log line to this change item
	 * @param logLine as a String
	 */
	public void addCmdLogLine(String logLine) {
		if (_logLines == null)
			_logLines = new ArrayList();

		// AB todo ... change bit on log line before adding to array

		_logLines.add(new EStdCmdLogLine(logLine));
	}

	/**
	 * Add a program output line to this change item
	 * @param logLine as a String
	 */
	public void addPgmOutputLine(String logLine) {
		if (_logLines == null)
			_logLines = new ArrayList();

		// AB todo ... change bit on log line before adding to array

		_logLines.add(new EStdPgmOutputLine(logLine));
	}

	/**
	 * Add a program error line to this change item
	 * @param logLine as a String
	 */
	public void addPgmErrorLine(String logLine) {
		if (_logLines == null)
			_logLines = new ArrayList();

		// AB todo ... change bit on log line before adding to array

		_logLines.add(new EStdPgmErrorLine(logLine));
	}

	/**
	* Gets the number of log lines in this change packet
	* @return Returns a int
	*/
	public int getNumLogLines() {
		if (_logLines == null)
			return 0;
		else
			return _logLines.size();
	}

}