package com.ibm.debug.epdc;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1998, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// com/ibm/debug/epdc/EPDC_Request.java, java-epdc, eclipse-dev
// Version 1.59.1.1 (last modified 11/21/01 09:24:16)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import com.ibm.debug.internal.pdt.connection.Connection;

/**
 * Request packet class
 */
public abstract class EPDC_Request extends EPDC_Base {

	/**
	 * All request classes inherit from this class
	 */
	protected EPDC_Request(byte[] inBuffer) throws IOException {
		super(inBuffer);
		_request_code = readInt();
		_total_bytes = readInt();
	}

	protected EPDC_Request(int request_code) {
		_request_code = request_code;
	}

	/**
	 * Reads a request packet from 'connection' and puts it into 'bos'.
	 * @return The request code.
	 */

	private static int getPacket(Connection connection, ByteArrayOutputStream bos)
		throws IOException {
		DataOutputStream dos = new DataOutputStream(bos);

		connection.beginPacketRead();
		DataInputStream inStream = new DataInputStream(connection.getInputStream());

		int reqCode = inStream.readInt(); // get request code
		dos.writeInt(reqCode);
		int totBytes = inStream.readInt(); // get total bytes
		dos.writeInt(totBytes);

		byte[] b = new byte[totBytes - 8];

		if (b.length > 0) {
			inStream.readFully(b);
			dos.write(b);
		}

		connection.endPacketRead(EPDC.RequestPacket);

		return reqCode;
	}


	/**
	 * Decodes and returns a request object from an EPDC connection
	 * based on the request type
	 */
	static public EPDC_Request decodeRequestStream(Connection connection)
		throws IOException {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();

		int reqCode = getPacket(connection, bos);

		byte[] packetByteArray = bos.toByteArray();

		switch (reqCode) {
			case EPDC.Remote_BreakpointClear :
				return new EReqBreakpointClear(packetByteArray);
			case EPDC.Remote_BreakpointDisable :
				return new EReqBreakpointDisable(packetByteArray);
			case EPDC.Remote_BreakpointEnable :
				return new EReqBreakpointEnable(packetByteArray);
			case EPDC.Remote_BreakpointEvent :
				return new EReqBreakpointEvent(packetByteArray);
			case EPDC.Remote_BreakpointLocation :
				return new EReqBreakpointLocation(packetByteArray);
			case EPDC.Remote_CommandLog :
				return new EReqCommandLog(packetByteArray);
			case EPDC.Remote_ContextConvert :
				return new EReqContextConvert(packetByteArray);
			case EPDC.Remote_ContextQualGet :
				return new EReqContextQualGet(packetByteArray);
			case EPDC.Remote_EntrySearch :
				return new EReqEntrySearch(packetByteArray);
			case EPDC.Remote_EntryWhere :
				return new EReqEntryWhere(packetByteArray);
			case EPDC.Remote_ExceptionStatusChange :
				return new EReqExceptionStatusChange(packetByteArray);
			case EPDC.Remote_Execute :
				return new EReqExecute(packetByteArray);
			case EPDC.Remote_Expression :
				return new EReqExpression(packetByteArray);
			case EPDC.Remote_ExpressionDisable :
				return new EReqExpressionDisable(packetByteArray);
			case EPDC.Remote_ExpressionEnable :
				return new EReqExpressionEnable(packetByteArray);
			case EPDC.Remote_ExpressionFree :
				return new EReqExpressionFree(packetByteArray);
			case EPDC.Remote_ExpressionRepTypeSet :
				return new EReqExpressionRepTypeSet(packetByteArray);
			case EPDC.Remote_ExpressionSubTree :
				return new EReqExpressionSubTree(packetByteArray);
			case EPDC.Remote_ExpressionSubTreeDelete :
				return new EReqExpressionSubTreeDelete(packetByteArray);
			case EPDC.Remote_ExpressionValueModify :
				return new EReqExpressionValueModify(packetByteArray);
			case EPDC.Remote_Initialize_Debug_Engine :
				return new EReqInitializeDE(packetByteArray);
			case EPDC.Remote_LocalVariable :
				return new EReqLocalVariable(packetByteArray);
			case EPDC.Remote_LocalVariableFree :
				return new EReqLocalVariableFree(packetByteArray);
			case EPDC.Remote_PartGet :
				return new EReqPartGet(packetByteArray);
			case EPDC.Remote_PartOpen :
				return new EReqPartOpen(packetByteArray);
			case EPDC.Remote_PartSet :
				return new EReqPartSet(packetByteArray);
			case EPDC.Remote_PointerDeref :
				return new EReqPointerDeref(packetByteArray);
			case EPDC.Remote_PreparePgm :
				return new EReqPreparePgm(packetByteArray);
			case EPDC.Remote_ProcessAttach :
				return new EReqProcessAttach(packetByteArray);
			case EPDC.Remote_ProcessAttach2 :
				return new EReqProcessAttach2(packetByteArray);
			case EPDC.Remote_ProcessDetach :
				return new EReqProcessDetach(packetByteArray);
			case EPDC.Remote_ProcessDetailsGet :
				return new EReqProcessDetailsGet(packetByteArray);
			case EPDC.Remote_ProcessListGet :
				return new EReqProcessListGet(packetByteArray);
			case EPDC.Remote_RepForTypeSet :
				return new EReqRepForTypeSet(packetByteArray);
			case EPDC.Remote_Stack :
				return new EReqStack(packetByteArray);
			case EPDC.Remote_StackBuildView :
				return new EReqStackBuildView(packetByteArray);
			case EPDC.Remote_StackDetailsGet :
				return new EReqStackDetailsGet(packetByteArray);
			case EPDC.Remote_StackFree :
				return new EReqStackFree(packetByteArray);
			case EPDC.Remote_StartPgm :
				return new EReqStartPgm(packetByteArray);
			case EPDC.Remote_StringFind :
				return new EReqStringFind(packetByteArray);
			case EPDC.Remote_Terminate_Debug_Engine :
				return new EReqTerminateDE(packetByteArray);
			case EPDC.Remote_TerminatePgm :
				return new EReqTerminatePgm(packetByteArray);
			case EPDC.Remote_ThreadFreeze :
				return new EReqThreadFreeze(packetByteArray);
			case EPDC.Remote_ThreadThaw :
				return new EReqThreadThaw(packetByteArray);
			case EPDC.Remote_TypesNumGet :
				return new EReqTypesNumGet(packetByteArray);
			case EPDC.Remote_Version :
				return new EReqVersion(packetByteArray);
			case EPDC.Remote_ProgramInput :
				return new EReqProgramInput(packetByteArray);
			case EPDC.Remote_ViewsVerify :
				return new EReqVerifyViews(packetByteArray);
			case EPDC.Remote_Halt :
				return new EReqRemoteHalt(packetByteArray);
			case EPDC.Remote_ViewSearchPath :
				return new EReqViewSearchPath(packetByteArray);
			case EPDC.Remote_ViewFileInfoSet :
				return new EReqViewFileInfoSet(packetByteArray);
			case EPDC.Remote_StorageUsageCheckSet :
				return new EReqStorageUsageCheckSet(packetByteArray);
			case EPDC.Remote_Storage2 :
				return new EReqStorage2(packetByteArray);
			case EPDC.Remote_StorageRangeSet2 :
				return new EReqStorageRangeSet2(packetByteArray);
			case EPDC.Remote_StorageStyleSet :
				return new EReqStorageStyleSet(packetByteArray);
			case EPDC.Remote_StorageEnablementSet :
				return new EReqStorageEnablementSet(packetByteArray);
			case EPDC.Remote_StorageUpdate :
				return new EReqStorageUpdate(packetByteArray);
			case EPDC.Remote_StorageFree :
				return new EReqStorageFree(packetByteArray);
			case EPDC.Remote_RegistersValueSet :
				return new EReqRegistersValueSet(packetByteArray);
			case EPDC.Remote_RegistersDetailsGet :
				return new EReqRegistersDetailsGet(packetByteArray);
			case EPDC.Remote_Registers2 :
				return new EReqRegisters2(packetByteArray);
			case EPDC.Remote_RegistersFree2 :
				return new EReqRegistersFree2(packetByteArray);
			case EPDC.Remote_ThreadInfoGet :
				return new EReqThreadInfoGet(packetByteArray);

			default :
				System.out.println("Unknown epdc request typeCode:" + reqCode);
				return null;
		}
	}

	/**
	 * Calculate total bytes, give connection object a chance to write out a
	 * packet prefix, then stream out this object.
	 */

	public final void output(Connection connection) throws IOException {
		_total_bytes = fixedLen() + varLen();

		connection.beginPacketWrite(_total_bytes);

		DataOutputStream dataOutputStream =
			new DataOutputStream(connection.getOutputStreamBuffer());

		output(dataOutputStream);
		connection.endPacketWrite(EPDC.RequestPacket);
	}

	protected void output(DataOutputStream dataOutputStream) throws IOException {
		dataOutputStream.writeInt(_request_code);
		dataOutputStream.writeInt(_total_bytes);
	}

	/** Return the length of the fixed component */
	protected int fixedLen() {
		return _fixed_length;
	}

	/** Return the length of the variable component */
	protected int varLen() {
		return 0;
	}

	/**
	 * Returns the request code
	 *    See interface EPDC for request code values
	 *
	 */
	public int requestCode() {
		return _request_code;
	}

	public void write(PrintWriter printWriter) {
		printWriter.println("--------REQUEST--------");
		printWriter.println();
		printWriter.println("REQUEST TYPE: " + getName());
		increaseIndentLevel();
		if (getDetailLevel() >= DETAIL_LEVEL_MEDIUM) {
			indent(printWriter);
			printWriter.print("Request Code : " + _request_code);
			printWriter.println("    Length : " + _total_bytes);
		}
		decreaseIndentLevel();
	}

	/**
	 * Write out a packet to 'printWriter' in hex representation.
	 */

	public static void write(
		PrintWriter printWriter,
		Connection connection,
		boolean readOnly) {
		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();

		try {
			int reqCode = getPacket(connection, byteStream);

			if (readOnly)
				return;

			// Get a byte array which contains the entire packet:

			byte[] packet = byteStream.toByteArray();

			printWriter.print(
				"Request Code : " + reqCode + " (" + getHexDigits(reqCode) + ")");
			printWriter.println(
				"    Length : " + packet.length + " (" + getHexDigits(packet.length) + ")");

			EPDC_Base.write(printWriter, packet);
		} catch (IOException excp) {
			printWriter.println("Error: IOException occurred trying to read packet.");
		}
	}
	
	public String getName() {
		return super.getName(_request_code);
	}
	

	private int _request_code;
	private int _total_bytes;
	private static final int _fixed_length = 8;

}