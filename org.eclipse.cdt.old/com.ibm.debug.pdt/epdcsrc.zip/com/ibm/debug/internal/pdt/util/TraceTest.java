package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.util.*;
import java.awt.Frame;
import java.awt.event.*;

/**
 * This class is used to test the JT (JavaTrace) TraceLogger.
 * @see     TraceTest#main(java.lang.String[])
 */
public class TraceTest
{ TraceTest() { super(); }

  /** TraceTest.main() runs a test of the JavaTrace facility (TraceLogger).
   *  <p>USAGE: start java -DJT_LOG TraceCatcher   //starts TraceCatcher (with catchLog)
   * <br>USAGE: java TraceTest [8888] [appName]
   * <br>USAGE: java [-DJT_LOG -DJT_HOST=localhost -DJT_DEBUG=1 -DJT_ERROR=1 -DJT_EVENT=1] TraceTest [8888] [appName]
   *
   * @param args[0]  is the int 'x' port number to send outgoing log messages (added to JT_PORT)
   * @param args[1]  is the String "XYZ_appName" application name to use during logging
   * @param JT_LOG   is the Logger cmdLine property to also create a logFile "JT_L8xxx.txt"
   * @param JT_HOST  is the Logger cmdLine property to send output to socket/catcher instead of System.out
   * @param JT_PORT  is the Logger cmdLine property to specify the base port (Default=8880)
   * @param JT_DBG   is the Logger cmdLine property controlling the level of debug messages (Default=1)
   * @param JT_ERR   is the Logger cmdLine property controlling the level of error messages (Default=1)
   * @param JT_EVT   is the Logger cmdLine property controlling the level of event messages (Default=1)
   * @see     TraceLogger
   * @see     TraceCatcher
   */
   public static void main(String[] args)
   {   //*********** see if cmdLineArgs for appName
       String appName = "";
       if (args.length > 0)  //*** appName
          appName = args[0];

       //*********** start TraceLogger
       TraceLogger jt = new TraceLogger(appName);

       //*********** generate several messages
       System.out.println("this is normal System.out, text-1");
       System.err.println("this is normal System.err, text-1");
       if(jt.DBG)jt.dbg(1,"this is a JT_DBG macro message, level 1");
       if(jt.DBG)jt.dbg(2,"this is a JT_DBG message, level 2");
       if(jt.DBG)jt.dbg(3,"this is a JT_DBG message, level 3");
       if(jt.DBG)jt.dbg(4,"this is a JT_DBG message, level 4");
       if(jt.EVT)jt.evt(1,"this is a JT_EVT message, level 1");
       if(jt.EVT)jt.evt(2,"this is a JT_EVT message, level 2");
       if(jt.EVT)jt.evt(3,"this is a JT_EVT message, level 3");
       if(jt.ERR)jt.err(1,"this is a JT_ERR message, level 1, NO FRAME");

    //*********** sleep 5 secs, then generate error messages with frames
    try { Thread.sleep(5000L); }
    catch (InterruptedException e)     { }
    catch (Exception e) { System.out.println("unexpected exception"); }

       TraceFrame tFrm;
       tFrm = new TraceFrame();
       if(jt.ERR)jt.err(1,"this is a JT_ERR message, level 1, FRAME", tFrm);
       if(jt.ERR)jt.err(2,"this is a JT_ERR message, level 2, FRAME", tFrm);
       if(jt.ERR)jt.err(3,"this is a JT_ERR message, level 3, FRAME", tFrm);

    //*********** sleep 5 secs, then generate flush and exit
    try { Thread.sleep(5000L); }
    catch (InterruptedException e)     { }
    catch (Exception e) { if(jt.DBG)jt.dbg(1,"unexpected exception"); }

       jt.dbg(1,"this is JT_DBG message, about to flush(), then exit");
       jt.flush();  //optional, ensures final System.out sent down socket
       System.exit(0);
   }
}

class TraceFrame extends Frame implements WindowListener
{  public TraceFrame()
   {  setSize(400, 300);
      addWindowListener(this);
      setTitle("TraceFrame setTitle() goes here");
      show();
   }
   public TraceFrame(String s)
   {  this();
      setTitle(s);
   }
   public void windowClosed(WindowEvent e)      {}
   public void windowIconified(WindowEvent e)   {}
   public void windowOpened(WindowEvent e)      {}
   public void windowClosing(WindowEvent e)     { setVisible(false); }   //System.exit(0);}
   public void windowDeiconified(WindowEvent e) {}
   public void windowActivated(WindowEvent e)   {}
   public void windowDeactivated(WindowEvent e) {}


}

