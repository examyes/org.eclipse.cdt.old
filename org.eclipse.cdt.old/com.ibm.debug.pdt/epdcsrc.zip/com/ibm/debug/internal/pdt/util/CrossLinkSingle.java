package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

/**
 * The <code>CrossLinkSingle</code> class implements a back referenced
 * link.  It is similar to the <code>CrossLinkSingle</code> class, but
 * can contain only one link.
 * This facilitates the building of one-to-one and one-to-many relationships
 * between vectors.
 *
 */

import com.ibm.debug.internal.pdt.util.*;

public class CrossLinkSingle extends CrossLink
{
  /**
   * Constructs an empty object.
   *
   * @param   node              the object at the node that is "owns" this CrossLink.
   */
  public CrossLinkSingle(DestroyableObject node)
  {
    super(node);
    _crossLink = null;
  }

  /**
   * Destroy the object, removing all internal references.
   */
  public void destroy()
  {
    removeAllElements();
    super.destroy();
  }

  /**
   * Destroy the node linked to by this object. This may be called as part of
   * destroying the node attached to this object to clean up the references so
   * that garbage collection can release the storage.
   *
   * @exception  IllegalArgumentException  if link is not destroyed
   */
  public void destroyLinkedNodes()
  {
    if (null != _crossLink && null != _crossLink._node)
    {
      _crossLink._node.destroy();

      // verify that the link has been dropped
      if (_crossLink != null)
        throw new IllegalArgumentException();
    }
  }

  /**
   * Adds the specified component to this object.  If a cross-link already
   * exists, the new one replaces the existing one.
   *
   * @param   obj   the component to be added.
   * @exception  IllegalArgumentException  if the object currently exists in the vector
   */
  public void addElement(CrossLink obj)
  {
    if (_crossLink == obj)
      throw new IllegalArgumentException();

    if (obj.contains(this))
      throw new IllegalArgumentException();

    if (_crossLink != null)
      _crossLink.removeElementNoCheck(this);

    _crossLink = obj;
    obj.addElementNoCheck(this);
  }

  /**
   * Replaces the current component.
   * <p>
   * No error checking is performed, and the back chain is not maintained.
   *
   * @param   obj   the component to be added.
   */
  protected void addElementNoCheck(CrossLink obj)
  {
    _crossLink = obj;
  }

  /**
   * Removes the argument from this vector. If
   * the object is found in this vector, each component in the vector
   * with an index greater or equal to the object's index is shifted
   * downward to have an index one smaller than the value it had previously.
   *
   * @param   obj   the component to be removed.
   * @return  <code>true</code> if the argument was a component of this
   *          vector; <code>false</code> otherwise.
   */
  public boolean removeElement(CrossLink obj)
  {
    if (_crossLink != obj)
      return false;

    _crossLink.removeElementNoCheck(this);
    _crossLink = null;
    return true;
  }

  /**
   * Removes a component from this vector. If
   * the object is found in this vector, each component in the vector
   * with an index greater or equal to the object's index is shifted
   * downward to have an index one smaller than the value it had previously.
   *
   * @param   obj   the component to be removed.
   * @return  <code>true</code> if the argument was a component of this
   *          vector; <code>false</code> otherwise.
   */
  public void removeElementNoCheck(CrossLink obj)
  {
    _crossLink = null;
  }

  /**
   * Removes all components from this vector and sets its size to zero.
   */
  public void removeAllElements()
  {
    if (_crossLink != null)
    {
      _crossLink.removeElementNoCheck(this);
      _crossLink = null;
    }
  }

  /**
   * Returns the number of components in this vector.
   *
   * @return  the number of components in this vector.
   */
  public int size()
  {
    return (_crossLink == null) ? 0 : 1;
  }

  /**
   * Tests if the specified object is a component in this vector.
   *
   * @param   elem   an object.
   * @return  <code>true</code> if the specified object is a component in
   *          this vector; <code>false</code> otherwise.
   */
  public boolean contains(CrossLink elem)
  {
    return (elem == _crossLink);
  }

  /**
   * Returns the element at the cross-link
   *
   * @return     The indicated cross-link.
   *             A null Object is returned if a cross-link does not exist
   */
  public CrossLink element()
  {
    return _crossLink;
  }

  /**
   * Returns the node at the cross-link.
   *
   * @return     The node at the specified index.
   *             A null Object is returned if a cross-link does not exist.
   */
  public DestroyableObject indicatedNode()
  {
    if (_crossLink == null)
      return null;

    return _crossLink._node;
  }

  /**
   * Tests if this vector has no components.
   *
   * @return  <code>true</code> if this vector has no components;
   *          <code>false</code> otherwise.
   */
  public boolean isEmpty()
  {
    return _crossLink == null;
  }

  private CrossLink _crossLink;
}

