package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

//import java.util.*;
import java.io.*;
public class getEnvar extends Object
{
  private static TraceLogger tl = new TraceLogger("Util_getEnvar");

  public static String WindowsGetEnvar(String envarName)
  {  String envarValue = "";

     // First see if the value has been added to the debugger
     // properties i.e. the wrappers add WINDIR.
     envarValue = System.getProperty("IBMDebug." + envarName);
     if( envarValue != null && envarValue.length() > 0 )
     {
       if(tl.DBG)tl.dbg(1,
          "WindowsGetEnvar using java environment for " + envarName + "=" + envarValue);
       return envarValue;
     }

     // Shell out to access the OS runtime environment */
     envarName = "%"+envarName+"%";

     if( Platform.isWindows() )
     { if(tl.DBG)tl.dbg(1,
          "WindowsGetEnvar using a new shell to retrieve envar " + envarName);
       String shell = "cmd.exe /C ";
       if( Platform.is95() || Platform.is98() )
           shell = "command.com /C ";
       try
       {  if(tl.DBG)tl.dbg(2,
             "Windows envarName=" +envarName );
          Process p=Runtime.getRuntime().exec(shell +" echo "+envarName);
          BufferedReader s= new BufferedReader (new InputStreamReader(p.getInputStream()));
          envarValue=s.readLine();
          s.close();
          if(tl.DBG)tl.dbg(2,
             "Windows envarValue=" +envarValue );
          //System.getProperties().list(System.out);
       }catch(java.io.IOException e)
       {  if(tl.ERR)tl.err(1,
             "Windows getEnvar exception for envarName="+envarName +", exception="+e );
       }
     }
     else
        if(tl.ERR)tl.err(1,
             "WindowsGetEnvar called on non-Windows platform" );

     if(tl.EVT)tl.evt(2,
        "Windows " +envarName +"=" +envarValue );
     return envarValue;
  }

  public static void main(String[] args)
  {
     String s = WindowsGetEnvar("USERPROFILE");
     System.out.println( "UserProfile="+s );
     s = WindowsGetEnvar("USERNAME");
     System.out.println( "UserName="+s );
  }

}
