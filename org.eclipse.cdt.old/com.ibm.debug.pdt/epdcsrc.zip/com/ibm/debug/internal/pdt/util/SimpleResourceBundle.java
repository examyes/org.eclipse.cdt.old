package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.util.*;

/**
 * This class provides a simple ResourceBundle
 */
public class SimpleResourceBundle
{

   ResourceBundle resourceBundle;

   public SimpleResourceBundle(String fileName)
   {
      try
      {
         resourceBundle = ResourceBundle.getBundle(fileName);
      }
      catch (Exception e)
      {
      }
   }

   public ResourceBundle getRealResourceBundle()
   {
      return resourceBundle;
   }

   public Object getObject(String s)
   {
      if (resourceBundle == null) return null;
      try
      {
         return resourceBundle.getObject(s);
      }
      catch (Exception e)
      {
         return null;
      }

   }

   public String getString(String s)
   {
      if (resourceBundle == null) return null;
      try
      {
         return resourceBundle.getString(s);
      }
      catch (Exception e)
      {
         return null;
      }

   }

   public int getInt(String s)
   {
      if (resourceBundle == null) return -1;
      String valueAsString = null;
      try
      {
         valueAsString = resourceBundle.getString(s);
         int valueAsInt = Integer.parseInt(valueAsString);
         return valueAsInt;
      }
      catch (Exception e)
      {
         return -1;
      }

   }

   public String [] getStringArray(String s)
   {
      if (resourceBundle == null) return null;
      try
      {
         return resourceBundle.getStringArray(s);
      }
      catch (Exception e)
      {
         return null;
      }

   }

}

