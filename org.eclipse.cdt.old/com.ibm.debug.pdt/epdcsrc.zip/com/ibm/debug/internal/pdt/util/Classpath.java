package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.util.*;

/**
 * ClassPath class provides various utility methods a the classpath
 */
public class Classpath
{

   public Vector classpathVector = new Vector();
   public String classpath;
   public String stringPathSeparator = System.getProperty("path.separator");

   /**
    * Create the classpath.  This contructor will read the system classpath and prepare
    * for subsequent queries.
    */
   public Classpath()
   {
      classpath = System.getProperty("java.class.path");
      initPathArray(classpath);
   }

   /**
    * Create the classpath from the specified string.  The conitructor will process the string
    * and prepare for subsequent queries.
    */
   public Classpath(String path)
   {
      this.classpath = path;
      initPathArray(path);
   }

   private void initPathArray(String path)
   {
      char[] pathArray = path.toCharArray();
      StringBuffer str = new StringBuffer();
      for(int i = 0; i < pathArray.length; i++) {
        if(pathArray[i] == stringPathSeparator.charAt(0))
        {
          classpathVector.addElement(str.toString().trim());
          str.setLength(0);
        }
        else
        {
          str.append(pathArray[i]);
        }
      }
   }

   /**
    * Return the classpath broken up into elements of a vector. Note that the path separator is
    * not inluded.
    */
   public Vector getClasspathAsVector()
   {
      return classpathVector;
   }

   /**
    * Return the classpath broken up into elements of an array. Note that the path separator is
    * not inluded.
    */
   public String [] getClasspathAsArray()
   {
      if (classpathVector == null || classpathVector.size() == 0) return null;
      int numElems = classpathVector.size();
      String [] array = new String [numElems];
      for (int i = 0; i < numElems; i++)
      {
         array[i] = (String)classpathVector.elementAt(i);
      }
      return array;
   }

   /**
    * Return the classpath as a string.
    */
   public String getClasspath()
   {
      return classpath;
   }

   /**
    * Return the classpath as a string.
    */
   public String toString()
   {
      return getClasspath();
   }

   /**
    * Return the class separator as a string
    */
   public String getStringPathSeparator()
   {
      return stringPathSeparator;
   }

   /**
    * Return the path which contains the specified string.
    */
   public String findPathWhichContains(String fileName)
   {
      Vector vec = getClasspathAsVector();
      for (int i = 0; i < vec.size(); i++)
      {
         String str = (String)vec.elementAt(i);
         if (str.indexOf(fileName) >= 0)
         {
            return str;
         }
      }
      return null;
   }
}

