package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

/**
 * An interface to remove all links to other objects from a given object.
 * This is to be called when it is certain that the object will no longer
 * be used, as the object is left in an unusable state.
 */

public interface DestroyableObject
{
   /**
    * When the object is no longer needed, the <code>destroy</code> method
    * is to be called to null out all references internal to the object.  This
    * insures that unreferenced objects contain no circular references,
    * which cause problems in the garbage collection routines. The state of
    * the object after this method is called is indeterminate, and the object
    * is (presumably) unusable.
    *
    */
  public void destroy();
}
