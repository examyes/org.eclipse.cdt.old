package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 1998, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.lang.*;

/** Class to test for the presence of the Java debug APIs.
  * Either, neither, or both may be availble
  */
public class DebugApiTest
{
  /** Return true if the JDI interface used by the
    * Java Platform Debug Architecture is available */
  static public boolean isJDIAvailable()
  {
    // test for the base class of the JDI interface
    try
    {
      Class.forName("com.sun.jdi.Bootstrap");
      return true;
    }
    catch (ClassNotFoundException excp)
    {}
    return false;
  }

  /** Return true if the Sun Tools Debug API
    * is available */
  static public boolean isSunToolsDebugAvailable()
  {
    // Test for the base class of the Sun Tools debug interface
    try
    {
      Class.forName("sun.tools.debug.RemoteDebugger");
      return true;
    }
    catch (ClassNotFoundException excp)
    {}
    return false;
  }
}
