package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.util.*;

/**
 * Locale sensative MessageBundle
 */
public class LocaleMessageBundle
{
  private String         _lang       = "";
  private String         _bundleName = null;
  private ResourceBundle _messages   = null;
  private TraceLogger trace = new TraceLogger("Locale");


/** Try to use the system's default locale, if we fail we will use en_US
  * (note: may switch this with 'setLang')
  */
  public LocaleMessageBundle (String bundleName)
  {
      if( bundleName==null || bundleName.equals("") )
          bundleName = "com.ibm.debug.internal.pdt.util.MessagesBundle";
      _bundleName = bundleName;

      if (!setLocale(Locale.getDefault()))
      {
         if (setLocale(new Locale("en","US","")))
         {
            errorOutput(getResourceString("DEFAULT_LOCALE_NOT_SUPPORTED_MSG"));
         }
         else
         {
            errorOutput("CRITICAL ERROR: "+bundleName+"_en.properties resource file missing.");
            System.exit(-1);
         }
      }
  }

/** The user set a different locale, switch to it
  */
  public boolean setLang(String lang)
  {
     if (setLocale(localeFromString(lang)))
     {
        _lang = lang;
        return true;
     }
     else
     {
        errorOutput(getResourceString("SPECIFIED_LOCALE_NOT_SUPPORTED_MSG"));
        return false;
        //System.exit(-1);
     }
  }

 /** The user set a different lang, convert to locale and switch to it
   */
   public synchronized boolean setLocale(Locale locale)
   {
      try
      {
         // Note: need the fully qualified name here or may not find the resource bundle
         _messages = ResourceBundle.getBundle(_bundleName, locale);
      }
      catch (MissingResourceException e)
      {
         return false;
      }

      if (_messages== null)
         return false;
      else
         return true;
   }

 /** Get a resource string. The locale will match the system's default locale setting
   * (or specific setting if 'setLang' was used to override)
   */
   public synchronized String getResourceString(String key)
   {  String msg;
      if (_messages!= null)
      {
         try
         {
            msg = _messages.getString(key);
         }
         catch (MissingResourceException e)
         {
            msg = "INTERNAL ERROR: Could not find Resource: " +key;
            debugOutput(msg);
         }
      }
      else
      {
         msg = "INTERNAL ERROR: Could not find Resource: " +key;
         debugOutput(msg);
      }
      return msg;
   }

  /** Returns a new Locale from a string (eg. "en_US")
   */
   private synchronized Locale localeFromString(String lang)
   {
      StringTokenizer tok = new StringTokenizer(lang,"_");
      String language = tok.nextToken();
      String country = "";
      String variant = "";
      if (tok.hasMoreTokens())
         country = tok.nextToken();
      if (tok.hasMoreTokens())
         variant = tok.nextToken();

      return new Locale(language,country,variant);
   }

   private void errorOutput(String msg)
   {
     if(trace.ERR)trace.err(1,"LocaleMessageBundle ERROR: "+msg);
   }
   private void debugOutput(String msg)
   {
     if(trace.DBG)trace.dbg(1,"LocaleMessageBundle DEBUG: "+msg);
   }

}
