package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.io.*;
import java.net.*;
import java.beans.*;

public class SocketTester extends Thread
{
   static private int port=8002;
//   static private ServerSocket serverSocket;

   public SocketTester()
   {}

   static public void main(String[] args)
   {
     if(args!=null && args.length!=0 && args[0]!=null)
     {  if( !args[0].equals("") )
        {  try {  port = Integer.parseInt (args[0]);   }
           catch (NumberFormatException e)
           {   System.out.println("ERROR: INVALID_PORT STRING="+args[0]);
               System.exit(-1);
           }
           if ( port<1000 || port>99999 )
           {   System.out.println("ERROR: INVALID_PORT VALUE="+Integer.toString(port));
               System.exit(-1);
           }
        }
     }
     else
     {   port=8002;
         System.out.println("WARNING: no Args[0], defaulting to port="+port );
     }
     ServerSocket serverSocket = serverSocketCreate();
     if (serverSocket!=null)
        serverSocketListen(serverSocket);
     clientSocketCreateAndClose();
     if (serverSocket!=null)
        serverSocketClose(serverSocket);
   }

   static public ServerSocket serverSocketCreate()
   {   System.out.println("INFO: beginning serverSocker Create socket=" +port);
       ServerSocket serverSocket =null;
       try
       {  serverSocket = new ServerSocket(port);           }
       catch (IOException e)
       {  System.out.println("???ERROR-SERVER??? serverSocket Create exception="+e);           }
       return serverSocket;
   }

   static public void serverSocketListen(ServerSocket serverSocket)
   {   System.out.println("INFO: beginning serverSocket Listen()" );
           try
           {  int i = serverSocket.getSoTimeout();
              System.out.println("INFO: serverSocket get SO_Timeout="+i );
              serverSocket.setSoTimeout(1000);
              System.out.println("INFO: serverSocket set SO_Timeout=1000msec" );
              Socket socket = serverSocket.accept();
              if(socket!=null)
              {  System.out.println("INFO: serverSocket AcceptConnection received");
                 InputStream inputStream = socket.getInputStream();
                 OutputStream outputStream = socket.getOutputStream();
              }
              else
                 System.out.println("ERROR: input/output serverSocket AcceptConnection socket=null");
              return;
           }
           catch (IOException e)
           {  System.out.println("INFO: serverSocket AcceptConnection failed (time-out)");
           }
   }

   static public void clientSocketCreateAndClose()
   {    System.out.println("INFO: beginning clientSocket CreateAndClose()" );
        try
        {  Socket socket = new Socket("localhost", port);
           System.out.println("INFO: clientSocket created" );
           int i = socket.getSoLinger();
           System.out.println("INFO: clientSocket get SO_Linger="+i );
           socket.setSoLinger(true, 1000);
           System.out.println("INFO: clientSocket set SO_Linger=1000" );
           String dummyCmd = "test message";
           try
           {  System.out.println("INFO: clientSocket output="+dummyCmd );
              OutputStream outputStream = socket.getOutputStream();
              BufferedWriter requestWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
              requestWriter.write(dummyCmd.toCharArray(), 0, dummyCmd.length());
              requestWriter.newLine(); requestWriter.flush(); requestWriter.close();
           }
           catch (Exception e)
           {   System.out.println("ERROR: Could not write (clientSocket is closed) exception="+e);
           }

           socket.close();
           socket=null;
           System.out.println("!!!CLIENT-SUCCESS!!! clientSocket now closed" );
       }
       catch (IOException e)
       {   System.out.println("???ERROR-CLIENT???:  clientSocket Create exception="+e );
       }
   }

   static public void serverSocketClose(ServerSocket serverSocket)
   {  System.out.println("INFO: beginning serverSocket Close()" );
      try
      {    if(serverSocket!=null)
              serverSocket.close();
           serverSocket=null;
           System.out.println("!!!SERVER-SUCCESS!!! serverSocket now closed" );
      }
      catch (IOException e)
      {   System.out.println("ERROR: serverSocket Close exception="+e );
      }
   }

}
