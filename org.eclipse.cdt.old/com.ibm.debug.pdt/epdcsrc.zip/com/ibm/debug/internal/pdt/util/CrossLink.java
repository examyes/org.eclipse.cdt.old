package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

/**
 * The <code>CrossLink</code> class is an internal interface desribing
 * the common elements of all implementations.  <code>CrossLink</code>
 * objects are used in maintaining many-to-many, one-to-many, and many-to-one
 * lists.
 *
 */

import com.ibm.debug.internal.pdt.util.*;

abstract public class CrossLink
{
  /**
   * Constructs an empty object
   *
   * @param   node   the object at the node that is to be linked.
   */
  public CrossLink(DestroyableObject node)
  {
    _node = node;
  }

  /**
   * Destroy the object, removing all internal references.  This must be called
   * to remove all internal references, or garbage collection may be unable
   * to release the storage owned by the object.  Objects derived from
   * the <code>CrossLink</code> class should also call <code>super.destroy()</code>.
   */
  public void destroy()
  {
    _node = null;
  }

  /**
   * Destroy the nodes linked to by this object. This may be called as part of
   * destroying the node attached to this object to clean up the references so
   * that garbage collection can release the storage.
   *
   * @exception  IllegalArgumentException  If it can be determined that the
   *                                       links are not properly destroyed.
   */
  abstract public void destroyLinkedNodes();

  /**
   * Adds the specified component to the <code>CrossLink</code> object.
   * If the <code>CrossLink</code> class can hold only one element, the component
   * replaces the current element.  Otherwise, the new component is added
   * to the list of elements.
   *
   * @param   obj   The component to be added.
   * @exception  IllegalArgumentException  If either <code>contains(obj)</code>
   *                   or <code>obj.contains(this)</code> returns <code>true</code>.
   */
  abstract public void addElement(CrossLink obj);

  /**
   * Removes the specified component from the <code>CrossLink</code>.
   *
   * @param   obj   The component to be removed.
   * @return  <code>true</code> if the argument is a component of the
   *          <code>CrossLink</code>; <code>false</code> otherwise.
   */
  abstract public boolean removeElement(CrossLink obj);

  /**
   * Removes all components from the <code>CrossLink</code> object.
   */
  abstract public void removeAllElements();

  /**
   * Returns the number of components in the <code>CrossLink</code> object.
   *
   * @return  the number of components in the <code>CrossLink</code> object.
   */
  abstract public int size();

  /**
   * Tests if the specified object is an element of the <code>CrossLink</code> object.
   *
   * @param   elem   an object.
   * @return  <code>true</code> if the specified object is an element of
   *          the <code>CrossLink</code>; <code>false</code> otherwise.
   */
  abstract public boolean contains(CrossLink elem);

  /**
   * Tests if the <code>CrossLink</code> object has no elements.
   *
   * @return  <code>true</code> if the <code>CrossLink</code> object has no elements;
   *          <code>false</code> otherwise.
   */
  abstract public boolean isEmpty();

  /**
   * Adds the specified component to the <code>CrossLink</code> object.
   * If the <code>CrossLink</code> class can hold only one element, the component
   * replaces the current element.  Otherwise, the new component is added
   * to the list of elements.
   * <p>
   * No error checking is performed, and the back chain is not maintained.
   * This method is provided to allow derived classes to build the back chains
   * without having the overhead of catching exceptions.
   *
   * @param   obj   the component to be added.
   */
  abstract protected void addElementNoCheck(CrossLink obj);

  /**
   * Removes the specified component to the <code>CrossLink</code>.
   * <p>
   * No error checking is performed, and the back chain is not maintained.
   * This method is provided to allow derived classes to build the back chains
   * without having the overhead of catching exceptions.
   *
   * @param   obj   the component to be removed.
   */
  abstract protected void removeElementNoCheck(CrossLink obj);

  /**
   * The object containing the data associated with this node.
   */
  protected DestroyableObject _node;
}

