package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This class implements the JT (JavaTrace) TraceCatcher.
 * <p>TraceCatcher.main()
 * <ul>
 * <li>monitors the JT_PORT, accepts connections and the resulting socket
 * <li>creates up to MAX_CONNECTION individual TraceThreads, one per active socket/connection
 * <li>each TraceThread.run() redefines System.in to become a socket InputStream
 * <li>each InputStream message is then copied onto System.out (and optionally to a log)
 * </ul>
 *
 * @see     TraceThread
 * @see     TraceLogger
 * @see     TraceCatcher#main(java.lang.String[])
 */
public class TraceCatcher
{ TraceCatcher() { super(); }

  /** main program to start the TraceCatcher.
   *
   *
   * @param JT_PORT is the int cmdLine property of the port to accept incoming log messages (DEFAULT=TraceLogger.JT_PORT)
   * @param JT_LOG  is the cmdLine property to also create a logFile "JT_Catch.txt"
   * @see     TraceCatcher#MAX_CONNECTIONS
   * @see     TraceLogger#JT_PORT
   * @return <code>System.exit(-1)</code> if there is an initialization failure
   */
  public static void main(String[] args)
  {  if (init_Initialization("")==false)
        System.exit(-1);

     // Copyright
     showMessage("COPYRIGHT_MSG",null);

     // *************************************************************************
     //       check cmdLine "appNames" and java cmdLine Properties
     // ***************************************************************************
     String s = System.getProperty("JT_PORT");
     if(s!=null)
     {  if( !s.equals("") )
        {  try {  tracePort = Integer.parseInt (s);   }
           catch (NumberFormatException e)
           {   showError("INVALID_JT_PORT",s);
               System.exit(-1);
           }
           if ( tracePort<8000 || tracePort>8999 )
           {   showError("INVALID_PORT",Integer.toString(tracePort));
               System.exit(-1);
           }
        }
     }
     s = System.getProperty("JT_LOG");
     if(s!=null)
     {  traceLog = true;
        if(traceLog)
        {   try { osLog = new PrintWriter(new FileOutputStream(traceLogName), true);  }
            catch (Exception e)
            {   showMessage("CANNOT_OPEN_CATCHER_FILE",traceLogName);
            }
        }
     }

     // *************************************************************************
     //       Create server socket
     // ***************************************************************************
     try
     {  server = new ServerSocket(tracePort,0);
     }
     catch (IOException e)
     {  showError("PORT_IN_USE_MSG",null);
        System.err.println(e.getMessage());
        System.exit(-1);
     }
     catch (Exception e)
     {  handleException(e);
        System.exit(-1);
     }

     // *************************************************************************
     //       Wait for connection socket, then Create thread to handle it
     // ***************************************************************************
     TraceThread [] thrd = new TraceThread[MAX_CONNECTIONS];
     int t=0;
     for( t=0; t<MAX_CONNECTIONS; t++ )
     while(true)
     {  for( t=0; t<MAX_CONNECTIONS; t++ )
        {
           if( thrd[t]!=null && thrd[t].socket==null)
           {   thrd[t]=null;
           }
           if( thrd[t]==null )
           {  try
              {  //showMessage("WAITING_FOR_CONNECTION_ON_PORT_MSG",null );
                 socket = server.accept();
              }catch (Exception e)
              {  handleException(e);
                 break;
              }
              //showMessage("CONNECTION_ESTABLISHED_MSG",null );
              thrd[t] = new TraceThread(t, socket, osLog, args);
              break;
           }
        }
        if(t>=MAX_CONNECTIONS)
        {    System.out.println("*************** connection overload");
             System.exit(-1);
        }
     }

  }

  // ***************************************************************************
  // Internationalization Initialization
  // ***************************************************************************
  /**
   * International Initialization
   * <ul>
   * <li>if language=="" gets the system default language/country/variant
   * <li>gets the appropriate MessagesBundle_xx.properties</li>
   * </ul>
   *
   * @param   language  the <code>String</code> language to be used
   */
  private static boolean init_Initialization(String language)
  {  if (language.equals(""))      // If language not specified use the default
     {  Locale defaultLocale = Locale.getDefault();
        language = defaultLocale.getLanguage();
        country  = defaultLocale.getCountry();
        variant  = defaultLocale.getVariant();
     }

     _messagesBundle = null;
     Locale locale = new Locale(language,country,variant);
     try
     {  _messagesBundle=ResourceBundle.getBundle("com.ibm.debug.internal.pdt.util.MessagesBundle",locale);
     }
     catch (MissingResourceException e)
     {  System.out.println("No resource file for language=\""+language+
           "\" country=\""+country+"\" variant=\""+variant+"\"");
        return false;
     }

     if (_messagesBundle == null)
     {  System.out.println("Can't create ResourceBundle for language=\""+
           language+"\" country=\""+country+"\" variant=\""+variant+"\"");
        return false;
     }

     return true;
  }

  /**
   * Get a resource string from the messages ResourceBundle object
   *
   * @param   key      the <code>String</code> key to be found in the MessageBundle
   */
  static String getResourceString(String key)
  {  try
     {  return _messagesBundle.getString(key);
     }
     catch (MissingResourceException e)
     {  System.out.println ("Error: Resource "+key+" not found");
        return "Error: Resource "+key+" not found";
     }
  }

  // ***************************************************************************
  // Display Messages/Errors and handle unexpected Exceptions
  // ***************************************************************************
  /**
   * called to display normal operations messages.
   *
   * @param   msg      the <code>String</code> to be displayed
   */
   private static void showMessage(String m, String extraText)
   {  String s = getResourceString("JT_CATCHER") + getResourceString(m);
      if(extraText!=null)
         s = s + " " + extraText;
      System.out.println(s);
      if(osLog!=null)
         osLog.println(s);
   }
   private static void showError(String m, String extraText)
   {  String s = getResourceString("JT_CATCHER") + getResourceString(m);
      if(extraText!=null)
         s = s + " " + extraText;
      System.err.println(s);
      if(osLog!=null)
         osLog.println(s);
   }
   private static void handleException(Exception e)
   {  System.err.println(e.toString());
      System.err.println(e.getMessage());
      e.printStackTrace();
   }

  // ***************************************************************************
  // Data members
  // ***************************************************************************
  /** The maximum of TCP socket connections allowed (20) */
  public static final  int    MAX_CONNECTIONS=20;
  /** The JT_LOG log file name ("JT_Catch.txt") */
  private static String traceLogName="JT_Catch.txt";
  private static int tracePort     = TraceLogger.JT_PORT;
  private static String language   = "";
  private static String country    = "";
  private static String variant    = "";
  private static boolean traceLog  = false;
  private static PrintWriter osLog = null;
  private static ResourceBundle _messagesBundle;
  private static ServerSocket server= null;
  private static Socket socket      = null;


}
