package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.io.*;
import java.util.Vector;

public class LineInputStreamReader extends InputStreamReader
{
   private InputStream is = null;
   private boolean lineReady = false;
   private Vector lines = new Vector();
   private ThreadedReader tr = null;

   public LineInputStreamReader(InputStream is_)
   {  super(is_);
      is = is_;
      tr = new ThreadedReader(is);
      tr.start();
   }

   public boolean ready()
   {
       return lineReady;
   }

   public synchronized String readLine()
   {
       String str = (String)lines.elementAt(0);
       try {  lines.removeElementAt(0); }
       catch ( IndexOutOfBoundsException exc)
       {
       };
       lineReady = !lines.isEmpty();
       return str;
   }

   private synchronized void setLine(String str)
   {
       lines.addElement(str);
       lineReady = true;
   }


  private class ThreadedReader extends Thread
  {
    private InputStreamReader isr = null;
    private BufferedReader rdr = null;
//    private char[] isrBuffer = new char[1024+10];
    private ThreadedReader(InputStream is)
    { isr = new InputStreamReader(is);
      rdr = new BufferedReader(isr);
    }
    public void run()
    {
       String txt = "";
       while(rdr!=null)
       {
          try
          {
             txt = rdr.readLine();
             if(txt!=null)
                setLine(txt);
             else
                close();
          }
          catch(java.io.IOException excp)
          {
             close();
          }
       }
       close();
    }
    private void close()
    {
       if(TraceLogger.TRACE.EVT) TraceLogger.TRACE.evt(
          2,"LineInputStreamReader CLOSING" );
       stop();
       if(rdr!=null)
          try { rdr.close(); }
          catch(java.io.IOException excp) {}
       rdr = null;
       lineReady = false;
    } // end of run
  }
}