package com.ibm.debug.internal.pdt.util;

////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2001, 2002 International Business Machines Corporation. All rights reserved.
// This program and the accompanying materials are made available under the terms of
// the Common Public License which accompanies this distribution.
//
// %W%
// Version %I% (last modified %G% %U%)
////////////////////////////////////////////////////////////////////////////////

/**
 * Note: This class/interface is part of an interim API that is still under
 * development and expected to change significantly before reaching stability.
 * It is being made available at this early stage to solicit feedback from
 * pioneering adopters on the understanding that any code that uses this API
 * will almost certainly be broken (repeatedly) as the API evolves.
 */

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * <code>TraceThread</code> is a class which implements a runnable
 * thread which listens on a TraceCatcher socket and echos
 * all incoming messages to the <code>System.out</code> and
 * optionally copies these messages to a <code>PrintStream</code> file.
 * <p>Note that TraceThread is created from within TraceCatcher.
 *
 * @see     TraceCatcher
 */
class TraceThread implements Runnable
{
  /**
   * constructs a <code>TraceThread</code> on the specified socket
   *
   * @param   thrdNumber the int current TraceCatcher threadNumber(required)
   * @param   socket     the int current TraceCatcher socket (required)
   * @param   osLog      the PrintStream to the log file (or null)
   * @see     TraceCatcher
   * @see     run
   */
  public TraceThread(int thrdNumber, Socket sock, PrintWriter os, String[] args)
  {  socket = sock;
     osLog=os;
     if(args.length>0)
     {  numberOfAppNames = args.length;
        appNames = new String[numberOfAppNames];
        for( int i=0; i<args.length; i++ )
        {   appNames[i]="_"+args[i];
        }
     }
     thrd = new Thread(this);
     thrd.start();
     threadNumber=thrdNumber;
  }

  /**
   * runs <code>TraceThread(int, PrintStream)</code> on the specified socket:
   * <ul>
   * <li>creates a server socket on the specified port
   * <li>waits for a connection and accepts it
   * <li>creates an <code>InputStream</code> to the socket and re-assigns <code>System.in</code>
   * <li>reads incoming messages and echos to <code>System.out</code> and <code>PrintStream</code> log
   * <li>when connection is lost, loops back and waits again.</li>
   * </ul>
   *
   * @param   thrdNumber the int current TraceCatcher threadNumber (required)
   * @param   socket     the int TraceCatcher socket (required)
   * @param   osLog      the PrintStream to the log file (or null)
   * @see     TraceThread
   * @see     TraceCatcher
   */
  public void run()
  {     showMessage("CONNECTION_ESTABLISHED_MSG");

        InputStream is=null;
        BufferedReader br=null;
        try
        {  is = socket.getInputStream();
           br = new BufferedReader(new InputStreamReader(is));
           System.setIn(is);   // set System.in to be the socket input stream
        }catch (Exception e) {
           showError("UNABLE_TO_ASSIGN_SOCKET_TO SYSTEM_IN");
           handleException(e);
           return;
        }

        // loop until signalled to stop
        try
        {  String data="";
           while(data!=null)
           {  //if (br.ready())  //if this is used then dont get disconnect exception !!
              {  data = br.readLine();
                 showData(data);
              }
           }
        }catch(SocketException e)
        {  showMessage("CONNECTION_LOST_MSG");
        }catch (Exception e)
        {  handleException(e);
        }

        try
        {  if (socket != null)   socket.close();
        }catch (Exception e)
        {  handleException(e);
        }
        socket=null;
        return;
   }

  /**
   * called to display incoming socket data.
   */
   private void showData(String m)
   {  if(numberOfAppNames>=1)
      {  int i=0;
         for( i=0; i<numberOfAppNames; i++ )
         {  int j=appNames[i].length();
            if((5+j)<=m.length() )
            {  String s = m.substring(5,5+j);
               if(s.equals(appNames[i]))
                  break;
            }
         }
         if(i==numberOfAppNames)
            if(m.length()>=6 && m.charAt(1)==':' && m.charAt(5)=='_' )
               return;
      }
      System.out.println(threadNumber +":" +m );
      if(osLog!=null)
         osLog.println(threadNumber +":" +m );
   }

  /**
   * called to display normal operations messages.
   */
   private void showMessage(String m)
   {  System.out.println(threadNumber +":"
         +TraceCatcher.getResourceString("JT_CATCHER")
         +TraceCatcher.getResourceString(m) );
      if(osLog!=null)
         osLog.println(threadNumber +":"
            +TraceCatcher.getResourceString("JT_CATCHER")
            +TraceCatcher.getResourceString(m) );
   }

  /**
   * called to unexpected error messages
   */
   private void showError(String m)
   {  System.err.println(threadNumber +":"
         +TraceCatcher.getResourceString("JT_CATCHER")
         +TraceCatcher.getResourceString(m) );
      if(osLog!=null)
         osLog.println(threadNumber +":"
             +TraceCatcher.getResourceString("JT_CATCHER")
             +TraceCatcher.getResourceString(m) );
   }

  /**
   * Called when an unexpected exception occurs.
   */
   private void handleException(Exception e)
   {  System.err.println(threadNumber +":"
         +TraceCatcher.getResourceString("JT_CATCHER")
         +TraceCatcher.getResourceString("CAUGHT_EXCEPTION")
         + e.toString() );
      System.err.println(threadNumber +":"
         +TraceCatcher.getResourceString("JT_CATCHER")
         +e.getMessage() );
      e.printStackTrace(System.err);
      if(osLog!=null)
      {  osLog.println(threadNumber +":"
            +TraceCatcher.getResourceString("JT_CATCHER")
            +TraceCatcher.getResourceString("CAUGHT_EXCEPTION")
            + e.toString() );
         osLog.println(threadNumber +":"
            +TraceCatcher.getResourceString("JT_CATCHER")
            +e.getMessage() );
         e.printStackTrace(osLog);
      }
   }

   // ************ Data Members *************
   public  Socket       socket       = null;
   private Thread       thrd         = null;
   private int          threadNumber = 0;
   private PrintWriter  osLog        = null;
   private String[]     appNames     = null;
   private int numberOfAppNames      = 0;


}
