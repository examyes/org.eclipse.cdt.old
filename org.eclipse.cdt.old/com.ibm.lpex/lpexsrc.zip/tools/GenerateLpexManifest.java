//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// GenerateLpexManifest - utility to generate a manifest file for the LPEX jar.
//----------------------------------------------------------------------------

package tools;

import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;

import com.ibm.lpex.core.LpexConstants;


/**
 * This utility generates a manifest file for the LPEX jar, lpexManifest.
 * The file is imported during the build into the LPEX jar.  It includes
 * the LPEX version (Specification-Version attribute) and build date
 * (Implementation-Version attribute).
 *
 * @see com.ibm.lpex.core.LpexConstants#LPEX_VERSION
 */
public class GenerateLpexManifest
{
   public static void main(String[] args)
   {
      try {
         FileWriter fileWriter = new FileWriter("lpexManifest");
         BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

         bufferedWriter.write("Specification-Version: " + LpexConstants.LPEX_VERSION);
         bufferedWriter.newLine();

         String buildDate = DateFormat.getDateInstance(DateFormat.MEDIUM)
                                      .format(new Date());
         bufferedWriter.write("Implementation-Version: " + buildDate);
         bufferedWriter.newLine();
         bufferedWriter.close();
         }
      catch(IOException e) {
         System.out.println("ERROR - GenerateLpexManifest: cannot open lpexManifest.");
         }

      System.exit(0);
   }
}