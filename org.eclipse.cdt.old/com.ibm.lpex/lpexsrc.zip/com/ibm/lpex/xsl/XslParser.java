//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1999, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// XslParser - document parser for XSL (derived from the HTML document parser).
//----------------------------------------------------------------------------

package com.ibm.lpex.xsl;

import java.util.Properties;
import java.util.ResourceBundle;

import com.ibm.lpex.core.LpexCharStream;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexView;

import com.ibm.lpex.cc.LpexXslParserTokenManager;
import com.ibm.lpex.cc.Token;
import com.ibm.lpex.cc.TokenMgrError;


/**
 * Document parser for XSL.
 */
public class XslParser extends LpexCommonParser
{
   // the input stream the view feeds, and the lexer for this parser
   private LpexCharStream stream;
   private XslLexer       lexer;

   private static ResourceBundle resource =
      ResourceBundle.getBundle("com.ibm.lpex.xsl.Profile");


   /**
    * Constructor.
    * Add all of the parser specifics to the Lpex view.
    * Initializes the Lpex view for the parser:  it sets up all the style
    * attributes, classes, etc. for the language-sensitive edit features
    * supported.
    *
    * @param lpexView the LPEX document view associated with this parser
    */
   public XslParser(LpexView lpexView)
   {
      super(lpexView);        // LpexCommonParser constructor (view := lpexView)
      initializeParser();     // initialize LpexView with our stuff

      // instantiate an input stream for this view, and the lexer.
      stream = new LpexCharStream(view);
      lexer  = new XslLexer(stream);
   }

   /**
    * Total parse of the entire document.
    */
   public void           parseAll()
   {
      lexer.totalParse();
   }

   /**
    * Incremental parse.
    *
    * @param element the element whose committed change triggered the parse,
    *                or the element that precedes / follows a deleted block.
    *                The parser may identify other neighbouring elements that
    *                will have to be reparsed as a unit
    */
   public void           parseElement(int element)
   {
      lexer.parse(element);
   }

   /**
    * Returns the parser's properties profile resource bundle.
    */
   public ResourceBundle getProfile()
   {
      return resource;
   }

   /**
    * Returns "XSL", the language supported by this parser.
    *
    * @see com.ibm.lpex.core.LpexCommonParser#LANGUAGE_XSL
    */
   public String         getLanguage()
   {
      return LANGUAGE_XSL;
   }

   /**
    * Initialize the parser for an LPEX document view: set up style attributes
    * for the styles we need, classes, etc., and initialize the view
    * for the language-sensitive edit features supported.
    */
   private void          initializeParser()
   {
      // set common attributes for the styles we use
      String tokenHighlight = getProperty("tokenHighlight");
      setStyleAttributes(tokenHighlight == null || !tokenHighlight.equals("off"));
   }

   /**
    * Define parser's style attributes.
    *
    * @param colours true = token highlighting,
    *                false = no token highlighting
    */
   public void           setStyleAttributes(boolean colours)
   {
      String toBackground = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                        BACKGROUND_COLOR,
                                                        toBackground);
      if (colours) {
         setStyle("_t=u", attributes);         // Layout blanks, Text, =,
                                               //  Unrecognized tag name
         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("kd", attributes);         // Tag name, Tag delimiter

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_LIBRARY,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("a",   attributes);         // Tag attribute name

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_STRING,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("v",   attributes);         // Tag attribute value

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("c",   attributes);         // Comment

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_ERROR,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("e",   attributes);         // Lexical error
         }
      else                                    // drop the nice colours
         setStyle("_t=ukdavce", attributes);
   }
}


/**
 * Subclass LpexXslParserTokenManager (our token manager) for LPEX-specific
 * operations.
 */
final class XslLexer extends LpexXslParserTokenManager implements LpexConstants
{
   // the input stream feeding this parser and its LPEX view, our parser itself
   private LpexCharStream stream;
   private LpexView       view;
   private XslParser      parser;

   // LPEX classes we use
   static final String
      CLASS_CODE         = "code",          // any markup / text on the line
      CLASS_SPACE        = "space",         // empty line
      CLASS_TAG          = "tag",           // <tag>
      CLASS_FWDLINK      = "forwardLink",   // links multi-line
      CLASS_BWDLINK      = "backwardLink",  //   structures
      CLASS_CDATASECTION = "cdataSection",  // CDATA Section
      CLASS_COMMENT      = "comment",       // comment
      CLASS_ERROR        = "error";         // syntax error

   long
      classCode,
      classSpace,
      classTag,
      classForwardLink,
      classBackwardLink,
      classCdataSection,
      classComment,
      classError,
      classAll;

   // comments state for FWDLINK & BWDLINK
   private long comments, cdataSections;

   // keeping track of some doc structures - start element of a markup tag
   private int beginTag;

   // last token (t.kind) processed
   private int lastToken;


   /**
    * Constructor.  Use LpexXslParserTokenManager's constructor, then
    * initialize any other specific information of ours.
    */
   XslLexer(LpexCharStream charstream)
   {
      super(charstream /*,DEFAULT*/);
      stream = charstream;
      view = stream.getLpexView();

      // register the classes we use
      // & get their allocated bit-masks
      classCode         = view.registerClass(CLASS_CODE);
      classSpace        = view.registerClass(CLASS_SPACE);
      classTag          = view.registerClass(CLASS_TAG);
      classForwardLink  = view.registerClass(CLASS_FWDLINK);
      classBackwardLink = view.registerClass(CLASS_BWDLINK);
      classCdataSection = view.registerClass(CLASS_CDATASECTION);
      classComment      = view.registerClass(CLASS_COMMENT);
      classError        = view.registerClass(CLASS_ERROR);
      classAll = classCode | classSpace | classTag |
                 classForwardLink | classBackwardLink | classCdataSection |
                 classComment | classError;
   }

   /**
    * Total parse of the file.  Done initially, after a document has been
    * loaded in LPEX, or after the <b>updateProfile</b> command.
    */
   void           totalParse()
   {
      // remember our parser (can't do this in the XslLexer constructor, as
      // the calling parser is also just being constructed at that moment...)
      if (parser == null)
         parser = (XslParser)view.parser();

      doParse(1, view.elements(), false);     // do the parse on entire document
   }

   /**
    * Incremental parse.
    *
    * @param element the (first) element that triggered the parse
    */
   void           parse(int element)
   {
      doParse(evaluateBeginElement(element),  // parse optimal range
              evaluateEndElement(element),
              true);                          // clear their parsePending flags
   }

   /**
    * Parse a range of elements.
    * Called by both totalParse() and parse().
    *
    * @param beginElement first element in range
    * @param endElement   last element in the range
    * @param clearPending true = clear parsePending once done with an element
    */
   private void   doParse(int beginElement, int endElement,
                          boolean clearPending)
   {
      // clear existing lexical errors (if any) in the parse range
      // removeMessages(beginElement, endElement); // N/A right now...

      // initialize parse operation & get parsing
      stream.Init(beginElement, endElement, classAll, classSpace, '_', clearPending);
      ReInit(stream /*,DEFAULT*/);                // initialize our TokenManager
      cdataSections = 0;
      comments = 0;
      beginTag = 0;
      lastToken = EOF;

      int elements = view.elements();
      Token matchedToken = null;
      while (true) {
         try {
            processToken(matchedToken = getNextToken());
            // on EOF, we may have to extend the parse range
            if (matchedToken.kind == EOF) {
               if (beginTag != 0 ||
                   (cdataSections & classForwardLink) != 0 ||
                   (comments & classForwardLink) != 0) {
                  int oldEndElement = endElement;
                  do {               // could re-evaluateEndElement() instead??!
                     endElement++;
                     } while ((endElement <= elements) && view.show(endElement));
                  if (endElement > elements)
                     break;
                  stream.Expand(endElement);
                  // clear old messages in the newly expanded parse range
                  // removeMessages(oldEndElement+1, endElement); // N/A for now
                  }
               else
                  break;
               }
            }
         catch (TokenMgrError e) {            // EOF in middle of token/bad char
            stream.setStyles(stream.getBeginColumn(),
                             stream.getEndColumn(), 'e');
            stream.setClasses(classError | classCode);
            // do we really want to say "syntax error" when browsers accept
            // virtually anything, and we're not really validating anything -
            // the 'e' style is more than enough for now... -as-
            //addMessage(stream.getEndLine(),       // matchedToken.endLine bad!
            //           "syntaxError");
            if (stream.EOFSeen()) {                 // EOF (styles already set)?
               stream.setCurrentStyles();           //  do it again, complete
               break;                               //  & that's it, folks...
               }

            stream.skipChar();       // skip the error character (presumably...)
            ReInit(stream);                               //  & continue past it
            }
         }

      /* if EOFed in middle of an unended <tag>, set links for next parse */
      if (beginTag != 0) {
         setTag(beginTag, stream.getEndLine(), classTag);
         stream.setCurrentStyles();    // EOFed, ensure here it's set in element
         }
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * up to the top of the file.
    * Extra lines may be included as follows:
    * - the previous non-show line is included if it has been modified or if it
    *   has a classForwardLink, or if the current line has a classBackwardLink,
    *   or if a line between the current and the previous was deleted;
    * - once an extra line is included, the one previous to it is also checked.
    *
    * @param elem main line that triggered the parse
    * @return suggested start line for parsing (may be a show line)
    */
   private int    evaluateBeginElement(int elem)
   {
      int  tryElem;          // an element preceding elem
      long classes,          // classes of current elem
           tryClasses;       //  & classes of element preceding it

      /* always include previous line: e.g., Enter at the end of a line in error
         will open a new element pushing that line's message one down, we clear
         this error (now in our parse range), so it's lost! */
      if (elem > 1)
         elem--;

      // get current line's class
      for (;  elem > 1 && view.show(elem);  elem--) {}
      classes = view.elementClasses(elem);

      // LOOP BACKWARDS (up to top of the file)...
      while (elem > 1) {
         for (tryElem=elem-1;  tryElem > 1 && view.show(tryElem);  tryElem--) {}
         tryClasses = view.elementClasses(tryElem);               // prev line's

         // Include prev line in parse range and go on searching if *any* of:
         //   (a) current line has a BWDLINK;
         //   (b) previous non-show line has a FWDLINK;
         //   (c) line(s) between previous and current line was/were deleted;
         //   (d) previous non-show line has been modified.
         if ((classes & classBackwardLink)   == 0  &&
             (tryClasses & classForwardLink) == 0
             /*&&(view.parsePending(elem) & LX_PENDING_DELETE)==0*/
             /*&&(view.parsePending(tryElem) & PARSE_PENDING_CHANGE_MASK)==0*/)
            break;

         classes = tryClasses;
         elem    = tryElem;
         }

      return elem;
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * to the bottom of the file.
    * Extra lines may be included as follows:
    * - the next line is included if it's been modified, or if it has a class
    *   classBackwardLink, or is just a SHOW line;
    *   or if the current line has a class of classForwardLink or has no SEMICOLON;
    * - once an extra line is included, the one after it is also checked.
    *
    * @param element main line that triggered the parse
    */
   private int    evaluateEndElement(int element)
   {
      int elements = view.elements();

      // LOOP FORWARDS (down to bottom of the file)...
      int endElem = element;
      for (; endElem < elements; endElem++) {
         long classes = view.elementClasses(endElem);

         // Include next line in parse range and go on searching if *any* of:
         //   (a) current line has a FWDLINK;
         //   (b) next line is just a SHOW line;
         //   (c) next line was modified;
         //   (d) next line has a classBackwardLink.
         // Also: current line has PARSE_PENDING_NEXT_DELETED_MASK?!? *as*
         if (((classes & classForwardLink) == 0)  &&
             (!view.show(endElem+1))              &&
             ((view.parsePending(endElem+1) & PARSE_PENDING_CHANGE_MASK) == 0) &&
             ((view.elementClasses(endElem+1) & classBackwardLink) == 0)) {
            break;                               // break out of loop
            }
         }

      return endElem;
   }

   /**
    * Like JavaCC's CommonTokenAction(), which is called just before
    * getNextToken() returns a matched token.
    * Comments are SPECIAL_TOKENs, and are being processed by setComment().
    * White space is SKIPped altogether.
    *
    * @param t matched token returned by XslLexer/LpexXslTokenManager
    * @see #setComment
    */
   private void   processToken(Token t)
   {
      char style;
      long classes = classCode;
      int  currentToken = t.kind;

      //System.out.println("  processToken() \""+t.image+"\" "+currentToken+
      //                   "  "+t.beginColumn+","+t.endColumn);

      switch (currentToken) {
         /*---------*/
         /*  token  */
         /*---------*/
         case STAGO:       // '<'
         case ETAGO:       // "</"
         case SDECL:       // "<!"
         case SPIO:        // "<?"
              style = 'd';
              beginTag = t.endLine;
              break;

         case ETAGOO:      // attribute '<'
         case STAGOO:      // attribute "</"
              style = 'd';
              break;

         case TAGE:        // '>'
         case TAGC:
         case EPIO:        // "?>"
              style = 'd';
              setTag(beginTag, t.endLine, classTag);
              beginTag = 0;
              break;

         /*-------------*/
         /*  tag names  */
         /*-------------*/
         case XML:
              style = 'k';
              break;

         case XSL_APPLYIMPORTS:
         case XSL_APPLYTEMPLATES:
         case XSL_ATTRIBUTE:
         case XSL_ATTRIBUTESET:
         case XSL_CALLTEMPLATE:
         case XSL_CHOOSE:
         case XSL_COMMENT:
         case XSL_COPY:
         case XSL_COPYOF:
         case XSL_DECIMALFORMAT:
         case XSL_ELEMENT:
         case XSL_OFOREACH:
         case XSL_IF:
         case XSL_IMPORT:
         case XSL_INCLUDE:
         case XSL_KEY:
         case XSL_LOCALE:
         case XSL_MESSAGE:
         case XSL_NAMESPACEALIAS:
         case XSL_NUMBER:
         case XSL_OTHERWISE:
         case XSL_OUTPUT:
         case XSL_PARAM:
         case XSL_PI:
         case XSL_PRESERVESPACE:
         case XSL_SORT:
         case XSL_STRIPSPACE:
         case XSL_STYLESHEET:
         case XSL_TEMPLATE:
         case XSL_TEXT:
         case XSL_VALUEOF:
         case XSL_VARIABLE:
         case XSL_WITHPARAM:
              style = 'k';
              break;

         case ATTLIST:     // declarations
         case DOCTYPE:
         case ELEMENT:
         case ENTITY:
              style = 'k';
              break;

         case UNKNOWN:     // unrecognized tag
         case PITARGET:    // PI target
              style = 'u';
              break;

         case XMLNS:
         case XML_LANG:
         case XML_SPACE:
              style = 'k';
              break;

         case A_NAME:      // attribute name
         case DECLSTUFF:   // any declaration (tag too...) junk...
              style = 'a';
              break;

         case A_EQ:        // '='
              style = '=';
              break;

         case CDATA:       // attribute value
         case CONT_QUOTE:  // accumulated quoted stuff inside <!declarations...
         case CONT_SQUARE: // accumulated quoted stuff inside <!declarations...
         case SQUOTEE:
         case DQUOTEE:
         case PIVAL:
         case SSQUARE:
         case ESQUARE:
              style = 'v';
              break;

         case TEXT:
              style = 't'; // text
              break;

         //case EOF:
         default:
              //classes = 0;
              lastToken = currentToken;
              return;
         }

      lastToken = currentToken;
      stream.setStyles(t.beginColumn, t.endColumn, style);
      stream.setClasses(classes);
   }

   /**
    * Set style & class for comments.  Activated by \n, \r, or --> encountered
    * while in a comment SPECIAL_TOKEN.  SPECIAL_TOKEN, rather than TOKEN, is
    * used for these, as we don't need to see the same tokens in processToken()
    * too, nor have them recorded in the parse.
    *
    * Does the real work for the extended dummy in LpexXslParser.jj.
    *
    * @param t special token
    */
   protected void setComment(Token t)
   {
      long classes = classComment;

      if (t.kind == CONT_COMMENT)
         classes |= classForwardLink;         // comment to be continued
      if ((comments & classForwardLink) != 0) // continuing comment:
         classes |= classBackwardLink;        //  double-link it
      comments = classes;

      if (t.endColumn >= t.beginColumn)
         stream.setStyles(t.beginColumn, t.endColumn, 'c');
      stream.setClasses(classes);
   }

   /**
    * Set CDATA section style.  Activated by \n, \r, or --> encountered while
    * in a CDATA section SPECIAL_TOKEN.
    * Does the real work for the subclassed dummy in LpexXslParser.jj.
    *
    * @param t special token
    */
   protected void setCdataSection(Token t)
   {
      long classes = classCdataSection;

      if (t.kind == CONT_CDATA_SECTION)
         classes |= classForwardLink;              // comment to be continued
      if ((cdataSections & classForwardLink) != 0) // continuing comment:
         classes |= classBackwardLink;             //  double-link it
      cdataSections = classes;

      if (t.endColumn >= t.beginColumn)
         stream.setStyles(t.beginColumn, t.endColumn, 't');
      stream.setClasses(classes);
   }

   /**
    * Set a class (tagClass) in all the elements of a document structure
    * (tagBegin .. tagEnd), and double-link them for future incremental parses.
    * Currently used for (multi-line) tags.
    *
    * @param tagBegin start element belonging to the document structure
    * @param tagEnd   last element belonging to the structure
    * @param tagClass the class bit-mask to set:  classTag
    */
   private void   setTag(int tagBegin, int tagEnd, long tagClass)
   {
      // for a multi-line tag, double-link classes
      long classes = (tagBegin < tagEnd)? tagClass | classForwardLink : tagClass;
      int currentElement = stream.getEndLine();
      for (int i = tagBegin; i <= tagEnd; i++) {
         if (view.show(i))
            continue;
         if (i == tagEnd)
            classes &= ~classForwardLink;
         if (i == currentElement)
            stream.setClasses(classes);
         else
            view.setElementClasses(i,
                                view.elementClasses(i) & ~classSpace | classes);
         classes |= classBackwardLink;
         }
   }

// /**
//  * Display an error message for an element.  N/A
//  */
// private void addMessage (int element, String message)
// {
//    parser.addMessage(element,
//           LpexResources.message(parser.getLanguage() + "." + message));
// }
//
// /**
//  * Remove error messages for a given range of elements.  N/A
//  */
// private void removeMessages (int beginElement, int endElement)
// {
//    parser.removeMessages(beginElement, endElement);
// }
}