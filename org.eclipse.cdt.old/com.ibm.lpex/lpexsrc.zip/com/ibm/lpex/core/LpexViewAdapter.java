//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexViewAdapter - adapter class for LpexViewListener.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * An abstract adapter class for receiving document view events.
 * The methods in this class are empty, and do not stop any of the editor
 * actions for which the events are issued.
 *
 * <p>This is a convenience class for creating listener objects.  Extend this
 * class to create a document view listener, and override only the methods for
 * the events of interest.  If you implement the <code>LpexViewListener</code>
 * interface, you have to define all its methods;  this abstract class defines
 * null methods for all of them, so you must define methods only for those
 * events you care about.  This also eliminates the need for coding updates if
 * new event notifications are defined in LpexViewListener.
 *
 * <p>Create a listener object using your class, and then register it with a
 * document view using the view's <code>addLpexViewListener()</code> method.
 * When an event occurs, the relevant method in the listener object is invoked.
 * Example:
 * <pre>
 *   myLpexView.addLpexViewListener(new LpexViewAdapter() {
 *      // called after the updateProfile command has completed
 *      public void updateProfile(LpexView lpexView) {
 *         handleUpdateProfile(lpexView);
 *         }
 *      }); </pre>
 *
 * @see LpexView#addLpexViewListener
 */
public abstract class LpexViewAdapter implements LpexViewListener
{
 /**
  * This method is invoked just before the screen is displayed.
  * The screen is rebuilt and displayed after every user action.  It is also
  * rebuilt and displayed when the <b>screenShow</b> editor command is invoked.
  */
 public void showing(LpexView lpexView) {}

 /**
  * This method is invoked after the screen display is complete.
  */
 public void shown(LpexView lpexView) {}

 /**
  * This method is invoked just before the document is saved.
  * If you return <code>true</code>, then the remaining listeners
  * will not be invoked and the save will be aborted.
  */
 public boolean saving(LpexView lpexView) { return false; }

 /**
  * This method is invoked after the document has been saved.
  */
 public void saved(LpexView lpexView) {}

 /**
  * This method is invoked just before a document rename occurs.
  * If you return <code>true</code>, then the remaining listeners
  * will not be invoked and the rename will be aborted.
  */
 public boolean renaming(LpexView lpexView) { return false; }

 /**
  * This method is invoked after the document has been renamed.
  */
 public void renamed(LpexView lpexView) {}

 /**
  * This method is invoked after an attempt has been made to edit a
  * readonly document.
  */
 public void readonly(LpexView lpexView) {}

 /**
  * This method is invoked after the <b>updateProfile</b> editor command
  * has completed processing.
  */
 public void updateProfile(LpexView lpexView) {}

 /**
  * This method is invoked when the document view is disposed.
  */
 public void disposed(LpexView lpexView) {}
}