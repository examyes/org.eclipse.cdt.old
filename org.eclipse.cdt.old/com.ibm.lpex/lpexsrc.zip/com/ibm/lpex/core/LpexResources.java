//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexResources - access editor resource files.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.MissingResourceException;
import java.util.ResourceBundle;


/**
 * This class can be used to access a resource file of the editor.
 * Methods without a resource bundle argument use the editor's main resource
 * file, <code>com.ibm.lpex.core.Resources.properties</code>.
 *
 * <p>In the resource files accessed by this class, for any single-quote
 * (apostrophe) ', two single-quotes '' must be <b>always</b> used.
 * For example: <pre>
 *   action.keyInvalid="{0}" n''est pas une touche d''action valide. </pre>
 */
public final class LpexResources
{
 // cannot start the editor without it...
 private static final ResourceBundle _mainResourceBundle =
    ResourceBundle.getBundle("com.ibm.lpex.core.Resources");

 private static Object oneArgument[]  = new Object[1];
 private static Object twoArguments[] = new Object[2];


 /**
  * Retrieve from the editor's main resource file the message (resource string)
  * with the specified key.
  *
  * @return <code>null</code> if not found
  */
 public static String message(String key)
 {
  return message(_mainResourceBundle, key, (Object[])null);
 }

 /**
  * Retrieve from the specified resource file the message (resource string)
  * with the specified key.
  *
  * @return <code>null</code> if not found
  */
 public static String message(ResourceBundle resourceBundle, String key)
 {
  return message(resourceBundle, key, (Object[])null);
 }

 /**
  * Retrieve from the editor's main resource file the message (resource string)
  * with the specified key and perform argument substitution.
  *
  * <p>Message substitution is indicated by <code>{n}</code> (where n = 0 .. 9);
  * to display braces, enclose them in single quotes (e.g., '{');
  * to display a single quote, use two consecutive single quote characters.
  *
  * @return <code>null</code> if message not found
  */
 public static String message(String key, Object[] arguments)
 {
  return message(_mainResourceBundle, key, arguments);
 }

 /**
  * Retrieve from the specified resource file the message (resource string)
  * with the specified key and perform argument substitution.
  *
  * <p>Message substitution is indicated by <code>{n}</code> (where n = 0 .. 9);
  * to display braces, enclose them in single quotes (e.g., '{');
  * to display a single quote, use two consecutive single quote characters.
  *
  * @return <code>null</code> if message not found
  */
 public static String message(ResourceBundle resourceBundle, String key, Object[] arguments)
 {
  try
   {
    String m = resourceBundle.getString(key);
    if ((arguments == null || arguments.length == 0) && m.indexOf('\'') == -1)
     {
      return m;
     }

    StringBuffer buffer = new StringBuffer();
    boolean inQuotes = false;
    for (int i = 0; i < m.length(); i++)
     {
      char c = m.charAt(i);
      if (inQuotes)
       {
        if (c != '\'')
         {
          buffer.append(c);
         }
        else
         {
          inQuotes = false;
         }
       }
      else
       {
        switch (c)
         {

          case '\'':
           {
            // (a) two single quotes: keep one
            if ((i+1) < m.length() && (m.charAt(i+1) == '\''))
             {
              i++;
              buffer.append(c);
             }
            // (b) one single quote: start of quoted text
            else
             {
              inQuotes = true;
             }
            break;
           }

          case '{':
           {
            i++;
            while (i < m.length())
             {
              c = m.charAt(i);
              if (c == '}')
               {
                break;
               }
              i++;
              if (c >= '0' && c <= '9')
               {
                int arg = c - '0';
                if (arguments != null && arg < arguments.length)
                 {
                  buffer.append(arguments[arg].toString());
                 }
               }
             }
            break;
           }

          default:
           {
            buffer.append(c);
            break;
           }
         }
       }
     }

    return buffer.toString();
   }
  catch (MissingResourceException e) {}

  return null;
 }

 /**
  * Retrieve from the editor's main resource file the message (resource string)
  * with the specified key and a single integer substitution argument.
  *
  * @return <code>null</code> if not found
  */
 public static String message(String key, int arg1)
 {
  return message(_mainResourceBundle, key, arg1);
 }

 /**
  * Retrieve from the specified resource file the message (resource string)
  * with the specified key and a single integer substitution argument.
  *
  * @return <code>null</code> if not found
  */
 public static String message(ResourceBundle resourceBundle, String key, int arg1)
 {
  oneArgument[0] = new Integer(arg1);
  return message(resourceBundle, key, oneArgument);
 }

 /**
  * Retrieve from the editor's main resource file the message (resource string)
  * with the specified key and two integer substitution arguments.
  *
  * @return <code>null</code> if not found
  */
 public static String message(String key, int arg1, int arg2)
 {
  return message(_mainResourceBundle, key, arg1, arg2);
 }

 /**
  * Retrieve from the specified resource file the message (resource string)
  * with the specified key and two integer substitution arguments.
  *
  * @return <code>null</code> if not found
  */
 public static String message(ResourceBundle resourceBundle, String key, int arg1, int arg2)
 {
  twoArguments[0] = new Integer(arg1);
  twoArguments[1] = new Integer(arg2);
  return message(resourceBundle, key, twoArguments);
 }

 /**
  * Retrieve from the editor's main resource file the message (resource string)
  * with the specified key and a single substitution argument.
  *
  * @return <code>null</code> if not found
  */
 public static String message(String key, String arg1)
 {
  return message(_mainResourceBundle, key, arg1);
 }

 /**
  * Retrieve from the specified resource file the message (resource string)
  * with the specified key and a single substitution argument.
  *
  * @return <code>null</code> if not found
  */
 public static String message(ResourceBundle resourceBundle, String key, String arg1)
 {
  if (arg1 == null)
   {
    arg1 = "";
   }

  oneArgument[0] = arg1;
  return message(resourceBundle, key, oneArgument);
 }

 /**
  * Retrieve from the editor's main resource file the message (resource string)
  * with the specified key and two substitution arguments.
  *
  * @return <code>null</code> if not found
  */
 public static String message(String key, String arg1, String arg2)
 {
  return message(_mainResourceBundle, key, arg1, arg2);
 }

 /**
  * Retrieve from the specified resource file the message (resource string)
  * with the specified key and two substitution arguments.
  *
  * @return <code>null</code> if not found
  */
 public static String message(ResourceBundle resourceBundle, String key, String arg1, String arg2)
 {
  if (arg1 == null)
   {
    arg1 = "";
   }
  if (arg2 == null)
   {
    arg2 = "";
   }

  twoArguments[0] = arg1;
  twoArguments[1] = arg2;
  return message(resourceBundle, key, twoArguments);
 }

 /**
  * Separate the '&amp;' symbol from the text used for a label or caption.
  *
  * @param key the key into Resources.properties
  *
  * @return an array of two Strings, whose first element is the text without the
  *         '&amp;', and whose second element is an uppercased String whose only
  *         letter is the mnemonic;  if no '&amp;' is found, the second element
  *         is null
  */
 public static String[] textMnemonic(String key)
 {
  String[] texts = new String[2];
  if (key != null)
   {
    texts[0] = message(key);
    if (texts[0] == null)
     {
      texts[0] = key;
     }

    int indexOfMnemonic = texts[0].indexOf('&');
    if (indexOfMnemonic >= 0 && indexOfMnemonic + 1 < texts[0].length())
     {
      texts[0] = texts[0].substring(0, indexOfMnemonic) +
                 texts[0].substring(indexOfMnemonic + 1, texts[0].length());
      texts[1] = (texts[0].substring(indexOfMnemonic, indexOfMnemonic + 1)).toUpperCase();
     }
   }

  return texts;
 }
}