//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// MarkList - manages the marks of a document view.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages the list of marks for a document view.
 */
final class MarkList extends List
{
 private View    _view;
 private boolean _ignoreChanges;
 private boolean _includedMarks;
 private int     _lastMarkId;
 private List    _changedMarks;
 private List    _deletedMarks;


 MarkList(View view)
  {
   _view = view;
  }

 Node remove(Node node)
  {
   super.remove(node);
   Mark mark = ((MarkNode)node).mark();
   mark.clear();
   return node;
  }

 /**
  * During View.splitElement() and View.joinElements(), we want to do the text
  * changes and the marks updating separately:  during the text changes,
  * the _ignoreChanges flag will be on.
  */
 void setIgnoreChanges(boolean ignoreChanges)
  {
   _ignoreChanges = ignoreChanges;
  }

 static int id(String name)
  {
   if (name == null || name.length() == 0 || name.charAt(0) != '#')
    {
     return 0;
    }

   int id = 0;
   try
    {
     id = Integer.parseInt(name.substring(1));
    }
   catch(NumberFormatException e) {}

   return id;
  }

 Mark find(String name)
  {
   if (name == null || name.length() == 0)
    {
     return find(_lastMarkId);
    }

   int id = id(name);
   if (id != 0)
    {
     return find(id);
    }

   for (MarkNode markNode = (MarkNode)first();
        markNode != null;
        markNode = (MarkNode)markNode.next())
    {
     Mark mark = markNode.mark();
     String currentName = mark.name();
     if (currentName == null)
      {
       break;
      }
     if (currentName.equals(name))
      {
       return mark;
      }
    }

   return null;
  }

 Mark find(int id)
  {
   for (MarkNode markNode = (MarkNode)last();
        markNode != null;
        markNode = (MarkNode)markNode.prev())
    {
     Mark mark = markNode.mark();
     if (mark.id() == id)
      {
       return mark;
      }
    }

   return null;
  }

 Mark firstNamed()
  {
   MarkNode markNode = (MarkNode)first();
   if (markNode != null && markNode.mark().name() != null)
    {
     return markNode.mark();
    }

   return null;
  }

 Mark nextNamed(Mark mark)
  {
   for (MarkNode markNode = (MarkNode)first();
        markNode != null;
        markNode = (MarkNode)markNode.next())
    {
     if (mark == markNode.mark())
      {
       markNode = (MarkNode)markNode.next();
       if (markNode != null && markNode.mark().name() != null)
        {
         return markNode.mark();
        }
       break;
      }
    }

   return null;
  }

 Mark prevNamed(Mark mark)
  {
   for (MarkNode markNode = (MarkNode)first();
        markNode != null;
        markNode = (MarkNode)markNode.next())
    {
     if (mark == markNode.mark())
      {
       markNode = (MarkNode)markNode.prev();
       if (markNode != null && markNode.mark().name() != null)
        {
         return markNode.mark();
        }
       break;
      }
    }

   return null;
  }

 Mark set(String name, Element element1, Element element2, boolean sticky)
  {
   int id = id(name);
   Mark mark = find(name);
   if (mark != null)
    {
     id = mark.id();
     mark.clear();
    }

   if (id <= _lastMarkId)
    {
     return new ElementMark(name, id, element1, element2, sticky);
    }

   return null;
  }

 Mark set(String name, Element element1, int position1, Element element2, int position2,
          boolean sticky)
  {
   int id = id(name);
   Mark mark = find(name);
   if (mark != null)
    {
     id = mark.id();
     mark.clear();
    }

   if (id <= _lastMarkId)
    {
     return new CharacterMark(name, id, element1, position1, element2, position2, sticky);
    }

   return null;
  }

 void checkIncludedMarks()
  {
   for (MarkNode markNode = (MarkNode)first();
        markNode != null;
        markNode = (MarkNode)markNode.next())
    {
     if (markNode.mark()._included)
      {
       return;
      }
    }

   _includedMarks = false;
  }

 void elementRemoved(Element element)
  {
   // this should be called before the element is removed
   if (!_ignoreChanges)
    {
     ElementView.MarkNode next = null;
     for (ElementView.MarkNode markNode = element.elementView(_view)._firstMarkNode;
          markNode != null;
          markNode = next)
      {
       next = markNode._next;
       markNode.mark().elementRemoved(element);
      }
    }
  }

 void elementInserted(Element element)
  {
   // this should be called after the element is inserted
   if (!_ignoreChanges)
    {
     Element previousElement = element.prev();
     if (previousElement != null)
      {
       ElementView.MarkNode next = null;
       for (ElementView.MarkNode markNode = previousElement.elementView(_view)._firstMarkNode;
            markNode != null;
            markNode = next)
        {
         next = markNode._next;
         markNode.mark().elementInserted(element);
        }
      }

     Element nextElement = element.next();
     if (nextElement != null)
      {
       ElementView.MarkNode next = null;
       for (ElementView.MarkNode markNode = nextElement.elementView(_view)._firstMarkNode;
            markNode != null;
            markNode = next)
        {
         next = markNode._next;
         markNode.mark().elementInserted(element);
        }
      }
    }
  }

 void textDeleted(Element element, int position, int length)
  {
   // called before the text is deleted
   if (!_ignoreChanges)
    {
     ElementView.MarkNode next = null;
     for (ElementView.MarkNode markNode = element.elementView(_view)._firstMarkNode;
          markNode != null;
          markNode = next)
      {
       next = markNode._next;
       markNode.mark().textDeleted(element, position, length);
      }
    }
  }

 void textReplaced(Element element, int position, int length)
  {
   if (!_ignoreChanges)
    {
     ElementView.MarkNode next = null;
     for (ElementView.MarkNode markNode = element.elementView(_view)._firstMarkNode;
          markNode != null;
          markNode = next)
      {
       next = markNode._next;
       markNode.mark().textReplaced(element, position, length);
      }
    }
  }

 void textInserted(Element element, int position, int length)
  {
   if (!_ignoreChanges)
    {
     ElementView.MarkNode next = null;
     for (ElementView.MarkNode markNode = element.elementView(_view)._firstMarkNode;
          markNode != null;
          markNode = next)
      {
       next = markNode._next;
       markNode.mark().textInserted(element, position, length);
      }
    }
  }

 /**
  * Called from View.joinElements(), before the actual text changes are carried
  * out, to update the marks altered by the join.
  */
 void joinElements(Element element1, Element element2)
  {
   if (!_ignoreChanges)
    {
     ElementView.MarkNode next = null;

     // 1.- update any marks in the first element
     for (ElementView.MarkNode markNode = element1.elementView(_view)._firstMarkNode;
          markNode != null;
          markNode = next)
      {
       next = markNode._next;
       markNode.mark().joinElements(element1, element2);
      }

     // 2.- update any marks in the joined element
     if (element2 != null)
      {
       next = null;
       for (ElementView.MarkNode markNode = element2.elementView(_view)._firstMarkNode;
            markNode != null;
            markNode = next)
        {
         next = markNode._next;
         markNode.mark().joinElements(element1, element2);
        }
      }
    }
  }

 /**
  * Called from View.splitElement(), after the text changes have been carried
  * out, to update the marks altered by the split.
  */
 void splitElement(Element element, int position)
  {
   if (!_ignoreChanges)
    {
     ElementView.MarkNode next = null;

     // 1.- update any marks from the pre-split position of element
     for (ElementView.MarkNode markNode = element.elementView(_view)._firstMarkNode;
          markNode != null;
          markNode = next)
      {
       next = markNode._next;
       markNode.mark().splitElement(element, position);
      }

     // 2.- update any marks from the post-split position, now a new element
     element = element.next();
     if (element != null)
      {
       Element nextElement = element.next();
       if (nextElement != null)
        {
         next = null;
         for (ElementView.MarkNode markNode = nextElement.elementView(_view)._firstMarkNode;
              markNode != null;
              markNode = next)
          {
           next = markNode._next;
           markNode.mark().elementInserted(element);
          }
        }
      }
    }
  }

 void validate()
  {
   for (MarkNode markNode = (MarkNode)first();
        markNode != null;
        markNode = (MarkNode)markNode.next())
    {
     markNode.mark().updateExcludedHeader();
    }
  }

 String style(Element element, String style)
  {
   ElementView.MarkNode firstMarkNode = element.elementView(_view)._firstMarkNode;
   if (firstMarkNode != null)
    {
     StringBuffer buffer;
     if (style != null)
      {
       buffer = new StringBuffer(style);
      }
     else
      {
       buffer = new StringBuffer();
      }

     for (ElementView.MarkNode markNode = firstMarkNode;
          markNode != null;
          markNode = markNode._next)
      {
       markNode.mark().style(element, buffer);
      }

     return buffer.toString();
    }

   return style;
  }

 StyleAttributes defaultStyleAttributes(Element element)
  {
   ElementView.MarkNode firstMarkNode = element.elementView(_view)._firstMarkNode;
   for (ElementView.MarkNode markNode = element.elementView(_view)._firstMarkNode;
        markNode != null;
        markNode = markNode._next)
    {
     StyleAttributes defaultStyleAttributes = markNode.mark().defaultStyleAttributes();
     if (defaultStyleAttributes != null)
      {
       return defaultStyleAttributes;
      }
    }

   return null;
  }

 boolean visible(Element element)
  {
   if (_includedMarks)
    {
     for (ElementView.MarkNode markNode = element.elementView(_view)._firstMarkNode;
          markNode != null;
          markNode = markNode._next)
      {
       if (markNode.mark().included())
        {
         return true;
        }
      }

     return false;
    }

   for (ElementView.MarkNode markNode = element.elementView(_view)._firstMarkNode;
        markNode != null;
        markNode = markNode._next)
    {
     if (markNode.mark().excluded())
      {
       return false;
      }
    }

   return true;
  }

 boolean namedMarks()
  {
   boolean namedMarks = false;
   MarkNode markNode = (MarkNode)first();
   return markNode != null && markNode.mark().name() != null;
  }

 /**
  * This method may be used to determine if the specified element is a header
  * element for an excluded mark.
  * If the markExcludedHeader parameter for a mark is on, the specified mark
  * will have a header element when it is excluded.  The header element is a
  * show element whose text indicates how many lines are excluded.
  *
  * @return the excluded mark, or
  *         <code>null</code> if not an excluded-mark header element
  */
 Mark headerMark(Element element)
  {
   if (element != null && element.show())
    {
     // go through all the marks, look for an excluded one with this header element
     for (MarkNode markNode = (MarkNode)first();
          markNode != null;
          markNode = (MarkNode)markNode.next())
      {
       if (markNode.mark().excludedHeaderElement() == element)
        {
         return markNode.mark();
        }
      }
    }

   return null;
  }

 /**
  * Remove prefix commands' exclude marks.  Called from View.updateProfile().
  *
  * If one changes the profile (updateProfile command) while there are exclude
  * marks created with one of the prefix command profiles (xedit, seu, ispf),
  * then one cannot remove them if he switches to a profile that doesn't have
  * prefix commands (e.g., lpex).
  */
 void removePrefixExcludeMarks()
  {
   MarkNode nextMarkNode;
   for (MarkNode markNode = (MarkNode)first();
        markNode != null;
        markNode = nextMarkNode)
    {
     nextMarkNode = (MarkNode)markNode.next();
     if (markNode.mark().excluded() &&
         markNode.mark().name().startsWith(ProcessPrefixCommand.PREFIX_MARK_NAME))
      {
       markNode.mark().clear();
      }
    }
  }

 boolean protect(Element element)
  {
   if (element != null)
    {
     for (ElementView.MarkNode markNode = element.elementView(_view)._firstMarkNode;
          markNode != null;
          markNode = markNode._next)
      {
       if (markNode.mark().protect())
        {
         return true;
        }
      }
    }

   return false;
  }

 boolean insertElementProtect(Element element)
  {
   if (element != null)
    {
     for (ElementView.MarkNode markNode = element.elementView(_view)._firstMarkNode;
          markNode != null;
          markNode = markNode._next)
      {
       if (markNode.mark().protect() && markNode.mark().element2() != element)
        {
         return true;
        }
      }
    }

   return false;
  }

 boolean insertElementBeforeProtect(Element element)
  {
   if (element != null)
    {
     for (ElementView.MarkNode markNode = element.elementView(_view)._firstMarkNode;
          markNode != null;
          markNode = markNode._next)
      {
       if (markNode.mark().protect() && markNode.mark().element1() != element)
        {
         return true;
        }
      }
    }

   return false;
  }

 List changedMarks()
  {
   if (_changedMarks == null)
    {
     _changedMarks = new List();
    }
   return _changedMarks;
  }

 List deletedMarks()
  {
   if (_deletedMarks == null)
    {
     _deletedMarks = new List();
    }
   return _deletedMarks;
  }

 /**
  * Called from Screen to send all pending mark notifications to the willing
  * listeners.
  */
 void triggerListeners()
  {
   if (_changedMarks != null)
    {
     for (MarkNode markNode = (MarkNode)_changedMarks.first();
          markNode != null;
          markNode = (MarkNode)markNode.next())
      {
       markNode.mark().markChanged();
      }
     _changedMarks = null;
    }

   if (_deletedMarks != null)
    {
     for (MarkNode markNode = (MarkNode)_deletedMarks.first();
          markNode != null;
          markNode = (MarkNode)markNode.next())
      {
       markNode.mark().markDeleted();
      }

     // listeners processed notification, can now clear list of deleted marks
     _deletedMarks = null;
    }
  }

 /**
  * This method can be called during the processing of a mark-deleted
  * notification (before _deletedMarks is nulled).
  */
 String deletedMarkName(int id)
  {
   if (_deletedMarks != null)
    {
     for (MarkNode markNode = (MarkNode)_deletedMarks.first();
          markNode != null;
          markNode = (MarkNode)markNode.next())
      {
       Mark mark = markNode.mark();
       if (mark.id() == id)
        {
         return mark.name();
        }
      }
    }
   return null;
  }

 /**
  * Remove a mark listener from all the marks in this view's list for which it
  * is registered.
  */
 void removeListener(LpexMarkListener listener)
  {
   if (listener != null)
    {
     for (MarkNode markNode = (MarkNode)first();
          markNode != null;
          markNode = (MarkNode)markNode.next())
      {
       markNode.mark().removeListener(listener);
      }
    }
  }


 /**
  * Mark, the base class for ElementMark and CharacterMark.
  * A Mark is also a list of MarkListenerNodes.
  */
 abstract class Mark extends List
  {
   protected String  _name;
   protected Element _element1;
   protected Element _element2;
   protected int     _id;
   protected boolean _dirty;
   protected boolean _included;
   protected boolean _excluded;
   protected boolean _highlight;
   protected char    _styleCharacter;
   protected boolean _topSticky;
   protected boolean _bottomSticky;
   protected boolean _excludedHeader;
   protected boolean _protect;

   private   Element _excludedHeaderElement;
   private   int     _excludedLineCount;
   private   boolean _cleared;


   /**
    * Mark constructor.
    */
   Mark(String name, int id, Element element1, Element element2, boolean sticky)
    {
     if (name != null && name.length() == 0)
      {
       name = null;
      }
     _name = name;
     _element1 = element1;
     _element2 = element2;
     for (Element element = element1;
          element != null && element != element2.next();
          element = element.next())
      {
       addElement(element);
      }

     if (id == 0)
      {
       _lastMarkId++;
       _id = _lastMarkId;
      }
     else
      {
       _id = id;
      }

     _styleCharacter = '!';
     _topSticky = sticky;
     _bottomSticky = sticky;

     MarkNode markNode = new MarkNode(this);
     if (name == null)
      {
       MarkList.this.addBefore(null, markNode);
      }
     else
      {
       MarkList.this.addAfter(null, markNode);
      }

     _cleared = false;
    }

   View view()
    {
     return _view;
    }

   MarkList markList()
    {
     return MarkList.this;
    }

   String name()
    {
     return (_name != null)? _name : "#"+_id;
    }

   Element element1()
    {
     return _element1;
    }

   abstract int position1();

   Element element2()
    {
     return _element2;
    }

   abstract int position2();

   int id()
    {
     return _id;
    }

   boolean dirty()
    {
     return _dirty;
    }

   void setIncluded(boolean included)
    {
     if (_included != included)
      {
       _included = included;
       if (!included)
        {
         checkIncludedMarks();
        }
       else
        {
         _includedMarks = true;
        }
       _view.setVisibleElementOrdinalsInvalid();
       _view.setMaxElementWidthInvalid();
       _view.setMaxPrefixAreaWidthInvalid();
       _view.expandAll(false);
      }
    }

   boolean included()
    {
     return _included;
    }

   void setExcluded(boolean excluded)
    {
     if (_excluded != excluded)
      {
       _excluded = excluded;
       _view.setVisibleElementOrdinalsInvalid();
       _view.setMaxElementWidthInvalid();
       _view.setMaxPrefixAreaWidthInvalid();
       _view.expandAll(false);
      }
    }

   boolean excluded()
    {
     return _excluded;
    }

   void setHighlight(boolean highlight)
    {
     if (_highlight != highlight)
      {
       _highlight = highlight;
       resetDisplayStyle();
      }
    }

   boolean highlight()
    {
     return _highlight;
    }

   void setStyleCharacter(char styleCharacter)
    {
     if (_styleCharacter != styleCharacter)
      {
       _styleCharacter = styleCharacter;
       if (_highlight)
        {
         resetDisplayStyle();
        }
      }
    }

   char styleCharacter()
    {
     return _styleCharacter;
    }

   void setExcludedHeader(boolean excludedHeader)
    {
     if (excludedHeader != _excludedHeader)
      {
       _excludedHeader = excludedHeader;
      }
    }

   boolean excludedHeader()
    {
     return _excludedHeader;
    }

   void setProtect(boolean protect)
    {
     _protect = protect;
    }

   boolean protect()
    {
     return _protect;
    }

   Element excludedHeaderElement()
    {
     return _excludedHeaderElement;
    }

   LpexDocumentLocation documentLocation()
    {
     return new LpexDocumentLocation(_view.document().elementList().ordinalOf(element1()),
                                     position1());
    }

   abstract void elementRemoved(Element element);
   abstract void elementInserted(Element element);
   abstract void textDeleted(Element element, int position, int length);
   abstract void textReplaced(Element element, int position, int length);
   abstract void textInserted(Element element, int position, int length);
   abstract void joinElements(Element element1, Element element2);
   abstract void splitElement(Element element, int position);
   abstract void style(Element element, StringBuffer buffer);
   abstract String query();
   abstract StyleAttributes defaultStyleAttributes();

   void markChanged()
    {
     this.beginScanning();
     for (MarkListenerNode node = (MarkListenerNode)this.first();
          node != null;
          node = (MarkListenerNode)node.next())
      {
       node.listener().markChanged(_view.lpexView(), _id);
      }
     this.endScanning();
    }

   void markDeleted()
    {
     this.beginScanning();
     // go through all mark listeners registered with this mark
     for (MarkListenerNode node = (MarkListenerNode)this.first();
          node != null;
          node = (MarkListenerNode)node.next())
      {
       node.listener().markDeleted(_view.lpexView(), _id);
      }
     this.endScanning();
    }

   /**
    * Mark was deleted - add it to the deleted-marks list (to notify any
    * registered mark listeners later), and clear it from the view.
    */
   protected void deleted()
    {
     clear();
     deletedMarks().addBefore(null, new MarkNode(this));
    }

   protected void dirtied()
    {
     if (!_dirty)
      {
       _dirty = true;
       changedMarks().addBefore(null, new MarkNode(this));
      }
    }

   void clear()
    {
     if (!_cleared)
      {
       for (Element element = _element1;
            element != null && element != _element2.next();
            element = element.next())
        {
         clearElement(element);
        }
       _element1 = null;
       _element2 = null;
       _cleared = true;

       if (_excludedHeaderElement != null && _excludedHeaderElement._partOfList)
        {
         _view.deleteElement(_excludedHeaderElement);
        }
       _excludedHeaderElement = null;
       _excludedLineCount = 0;

       for (MarkNode markNode = (MarkNode)MarkList.this.first();
            markNode != null;
            markNode = (MarkNode)markNode.next())
        {
         if (markNode.mark() == this)
          {
           MarkList.this.remove(markNode);
          }
        }

       if (_included)
        {
         checkIncludedMarks();
        }

       if (_highlight)
        {
         resetDisplayStyle();
        }
      }
    }

   /**
    * Clear this mark from an element's list of marks:  element doesn't belong
    * to this mark any longer.
    */
   void clearElement(Element element)
    {
     ElementView elementView = element.elementView(_view);
     ElementView.MarkNode prevNode = null;
     for (ElementView.MarkNode markNode = elementView._firstMarkNode;
          markNode != null;
          markNode = markNode._next)
      {
       if (markNode.mark() == this)
        {
         if (prevNode == null)
          {
           elementView._firstMarkNode = markNode._next;
          }
         else
          {
           prevNode._next = markNode._next;
          }
        }
       else
        {
         prevNode = markNode;
        }
      }

     if (_highlight)
      {
       elementView.resetDisplayStyle();
      }
    }

   /**
    * Add this mark to element's list of marks for the view:  the element was
    * added to this mark, or the mark was moved to the element.
    * The call has no effect if this mark already appears on the element's list.
    */
   void addElement(Element element)
    {
     ElementView elementView = element.elementView(_view);
     for (ElementView.MarkNode markNode = elementView._firstMarkNode;
          markNode != null;
          markNode = markNode._next)
      {
       if (markNode.mark() == this)
        {
         return;
        }
      }

     ElementView.MarkNode markNode = new ElementView.MarkNode(this);
     markNode._next = elementView._firstMarkNode;
     elementView._firstMarkNode = markNode;
     if (_highlight)
      {
       elementView.resetDisplayStyle();
      }
    }

   void resetDisplayStyle()
    {
     for (Element element = _element1;
          element != null && element != _element2.next();
          element = element.next())
      {
       element.elementView(_view).resetDisplayStyle();
      }
    }

   void addListener(LpexMarkListener listener)
    {
     this.addAfter(null, new MarkListenerNode(listener));
    }

   void removeListener(LpexMarkListener listener)
    {
     MarkListenerNode node = this.find(listener);
     if (node != null)
      {
       this.remove(node);
      }
    }

   MarkListenerNode find(LpexMarkListener listener)
    {
     for (MarkListenerNode node = (MarkListenerNode)this.first();
          node != null;
          node = (MarkListenerNode)node.next())
      {
       if (node.listener() == listener)
        {
         return node;
        }
      }
     return null;
    }

   void updateExcludedHeader()
    {
     if (_excluded && _excludedHeader && _element1 != null)
      {
       if (_excludedHeaderElement != null && _excludedHeaderElement._partOfList)
        {
         Element nextVisible;
         for (nextVisible = _excludedHeaderElement.next();
              nextVisible != null && (!nextVisible.elementView(_view).expandHideVisible() ||
                                      nextVisible.show());
              nextVisible = nextVisible.next()) {}
         if (nextVisible != null)
          {
           ElementList elementList = _view.document().elementList();
           if (elementList.ordinalOf(nextVisible) < elementList.ordinalOf(_element1))
            {
             _view.deleteElement(_excludedHeaderElement);
            }
          }
        }

       if (_excludedHeaderElement == null)
        {
         _excludedHeaderElement = new Element(_view);
        }

       if (!_excludedHeaderElement._partOfList)
        {
         _view.document().elementList().addBefore(_view, _element1, _excludedHeaderElement);
        }

       int startLine = _view.document().elementList().nonShowOrdinalOf(_element1);
       int endLine = _view.document().elementList().nonShowOrdinalOf(_element2);
       int lines = endLine - startLine + 1;
       if (_excludedLineCount != lines)
        {
         _excludedLineCount = lines;
         if (lines == 1)
          {
           _excludedHeaderElement.setText(_view,
              LpexResources.message(LpexConstants.MSG_MARK_1_LINE_EXCLUDED));
          }
         else
          {
           _excludedHeaderElement.setText(_view,
              LpexResources.message(LpexConstants.MSG_MARK_N_LINES_EXCLUDED, lines));
          }
        }
      }
     else
      {
       if (_excludedHeaderElement != null)
        {
         _view.deleteElement(_excludedHeaderElement);
         _excludedHeaderElement = null;
         _excludedLineCount = 0;
        }
      }
    }
  }


 class ElementMark extends Mark
  {
   ElementMark(String name,
               int id,
               Element element1,
               Element element2,
               boolean sticky)
    {
     super(name, id, element1, element2, sticky);
    }

   int position1()
    {
     return 1;
    }

   int position2()
    {
     return (_element1 != null)? _element1.end() : 1;
    }

   void elementRemoved(Element element)
    {
     clearElement(element);
     if (element == _element1 && element == _element2)
      {
       deleted();
       return;
      }
     if (element == _element1)
      {
       _element1 = element.next();
      }
     if (element == _element2)
      {
       _element2 = element.prev();
      }
     dirtied();
    }

   void elementInserted(Element element)
    {
     if (element == _element1.prev())
      {
       if (_topSticky)
        {
         _element1 = element;
        }
       else
        {
         return;
        }
      }

     if (element == _element2.next())
      {
       if (_bottomSticky)
        {
         _element2 = element;
        }
       else
        {
         return;
        }
      }

     addElement(element);
     dirtied();
    }

   void textDeleted(Element element, int position, int length)
    {
     dirtied();
    }

   void textReplaced(Element element, int position, int length)
    {
     dirtied();
    }

   void textInserted(Element element, int position, int length)
    {
     dirtied();
    }

   /**
    * element2 is going to be appended to element1 - update this element mark
    * if it is affected.
    */
   void joinElements(Element element1, Element element2)
    {
     if (element2 == _element1)
      {
       _element1 = element1;
      }

     if (element2 == _element2)
      {
       _element2 = element1;
      }

     clearElement(element2); // ensure mark is not (any longer) in element2's list
     addElement(element1);   //  but is in element1's

     dirtied();
    }

   void splitElement(Element element, int position)
    {
     if (!_protect || _bottomSticky || element != _element2)
      {
       Element newElement = element.next();
       if (element == _element2)
        {
         _element2 = newElement;
        }
       addElement(newElement);
       dirtied();
      }
    }

   void style(Element element, StringBuffer buffer)
    {
     if (_highlight)
      {
       int highlightStart = 0;
       int highlightLength = element.length();
       int oldLength = buffer.length();
       if (oldLength < highlightStart + highlightLength)
        {
         buffer.setLength(highlightStart + highlightLength);
         for (int i = oldLength; i < highlightStart; i++)
          {
           buffer.setCharAt(i, '!');
          }
        }

       for (int i = highlightStart; i < highlightStart + highlightLength; i++)
        {
         buffer.setCharAt(i, _styleCharacter);
        }
      }
    }

   String query()
    {
     Document document = _view.document();
     ElementList elementList = document.elementList();
     int element1 = elementList.ordinalOf(_element1) + document.linesBeforeStart();
     int element2 = elementList.ordinalOf(_element2) + document.linesBeforeStart();
     StringBuffer queryString = new StringBuffer(32);
     if (_topSticky || _bottomSticky)
      {
       queryString.append("sticky ");
      }

     queryString.append("element ");
     queryString.append(element1);
     queryString.append(' ');
     queryString.append(element2);

     return queryString.toString();
    }

   StyleAttributes defaultStyleAttributes()
    {
     return _highlight? _view.styleAttributesList().find(_styleCharacter) : null;
    }
  }


 class CharacterMark extends Mark
  {
   private int _position1;
   private int _position2;

   CharacterMark(String name,
                 int id,
                 Element element1,
                 int position1,
                 Element element2,
                 int position2,
                 boolean sticky)
    {
     super(name, id, element1, element2, sticky);
     _position1 = position1;
     _position2 = position2;

     if (_element1 == _element2 && _position2 < _position1)
      {
       _position2 = _position1;
      }
    }

   int position1()
    {
     return _position1;
    }

   int position2()
    {
     return _position2;
    }

   void elementRemoved(Element element)
    {
     if (element == _element1 && element == _element2)
      {
       deleted();
       return;
      }

     if (element == _element1)
      {
       _element1 = element.next();
       _position1 = 1;
       if (_highlight)
        {
         _element1.elementView(_view).resetDisplayStyle();
        }
      }

     if (element == _element2)
      {
       _element2 = element.prev();
       _position2 = _element2.end();
       if (_element1 == _element2 && _position2 < _position1)
        {
         _position2 = _position1;
        }
       if (_highlight)
        {
         _element2.elementView(_view).resetDisplayStyle();
        }
      }

     dirtied();
    }

   void elementInserted(Element element)
    {
     if (element == _element1.prev())
      {
       if (_topSticky && _position1 == 1)
        {
         _element1 = element;
        }
       else
        {
         return;
        }
      }

     if (element == _element2.next())
      {
       if (_bottomSticky && _position2 >= _element2.length())
        {
         _element2 = element;
         _position2 = element.length();
        }
       else            // these lines were missing
        {              //   in the code?!?!
         return;
        }              //      -as- 5/2001
      }

     addElement(element);
     dirtied();
    }

   void textDeleted(Element element, int position, int length)
    {
     boolean changed = true;
     boolean deleted = false;
     int position2 = position + length - 1;

     if (_element1 == _element2)
      {
       changed = (_position1 <= position  && _position2 >= position) ||
                 (_position1 <= position2 && _position2 >= position2);
       deleted = _position1 >= position && _position2 <= position2;
       if (!deleted)
        {
         if (_position1 > position2)
          {
           // delete is before mark
           _position1 -= length;
          }
         else if (_position1 > position)
          {
           // delete includes start of mark
           _position1 = position;
          }

         if (_position2 > position2)
          {
           // end of delete is before mark end
           _position2 -= length;
          }
         else if (_position2 > position)
          {
           // delete includes end of mark
           _position2 = position;
          }
        }
      }

     else if (element == _element1)
      {
       changed = _position1 <= position2;
       if (_position1 > position2)
        {
         // delete is before mark
         _position1 -= length;
        }
       else if (_position1 > position)
        {
         // delete includes start of mark
         _position1 = position;
        }
      }

     else if (element == _element2)
      {
       changed = _position2 >= position;
       if (_position2 > position2)
        {
         // end of delete is before mark end
         _position2 -= length;
        }
       else if (_position2 > position)
        {
         // delete includes end of mark
         _position2 = position;
        }
      }

     if (deleted)
      {
       deleted();
      }
     else if (changed)
      {
       dirtied();
      }
    }

   void textReplaced(Element element, int position, int length)
    {
     boolean changed = true;
     int position2 = position + length - 1;
     if (_element1 == _element2)
      {
       changed = (position >= _position1 && position <= _position2) ||
                 (position2 >= _position1 && position2 <= _position2);
      }
     else if (element == _element1)
      {
       changed = _position1 <= position2;
      }
     else if (element == _element2)
      {
       changed = _position2 >= position;
      }

     if (changed)
      {
       dirtied();
      }
    }

   void textInserted(Element element, int position, int length)
    {
     boolean changed = true;
     if (element == _element1 && element == _element2)
      {
       boolean topChanged = (_topSticky) ? (_position1 <= position) : (_position1 < position);
       boolean bottomChanged = (_bottomSticky) ? ((_position2 + 1) >= position) : (_position2 >= position);
       changed = topChanged || bottomChanged;
       if ((!_topSticky && _position1 >= position) ||
           (_topSticky && _position1 > position))
        {
         // insert is before mark
         _position1 += length;
        }
       if ((!_bottomSticky && _position2 >= position) ||
           (_bottomSticky && (_position2 + 1) >= position))
        {
         // insert is before end of mark
         _position2 += length;
        }
      }

     else if (element == _element1)
      {
       changed = (_topSticky) ? (_position1 <= position) : (_position1 < position);
       if ((!_topSticky && _position1 >= position) ||
           (_topSticky && _position1 > position))
        {
         // insert is before mark
         _position1 += length;
        }
      }

     else if (element == _element2)
      {
       changed = (_bottomSticky) ? ((_position2 + 1) >= position) : (_position2 >= position);
       if ((!_bottomSticky && _position2 >= position) ||
           (_bottomSticky && (_position2 + 1) >= position))
        {
         _position2 += length;
        }
      }

     if (changed)
      {
       dirtied();
      }
    }

   /**
    * element2 is going to be appended to element1 - update this character mark
    * if it is affected.
    */
   void joinElements(Element element1, Element element2)
    {
     boolean changed = true; // assume mark contents changed
     if (_element2 == element1)
      {
       changed = _position2 > element1.length();
      }

     if (element2 == _element1)
      {
       changed = false;
       _element1 = element1;
       _position1 += element1.length();
       if (_highlight)
        {
         _element1.elementView(_view).resetDisplayStyle();
        }
      }

     if (element2 == _element2)
      {
       changed = element2 != _element1;
       _element2 = element1;
       _position2 += element1.length();
       if (_element1 == _element2 && _position2 < _position1)
        {
         _position2 = _position1;
        }
       if (_highlight)
        {
         _element2.elementView(_view).resetDisplayStyle();
        }
      }

     clearElement(element2); // ensure mark is not (any longer) in element2's list
     addElement(element1);   //  but is in element1's

     if (changed)
      {
       dirtied();
      }
    }

   void splitElement(Element element, int position)
    {
     Element newElement = element.next();
     if (newElement != null)
      {
       boolean changed = true; // assume mark contents changed
       if (_element1 == _element2)
        {
         changed = _position1 < position && _position2 >= position;
        }
       else if (_element1 == element)
        {
         changed = _position1 < position;
        }
       else if (_element2 == element)
        {
         changed = _position2 >= position;
        }

       if (_element1 == element && position <= _position1)
        {
         _position1 -= position - 1;
         _element1 = newElement;
         clearElement(element);
         if (_highlight)
          {
           _element1.elementView(_view).resetDisplayStyle();
          }
        }

       if (_element2 == element && position <= _position2)
        {
         _position2 -= position - 1;
         _element2 = newElement;
         if (_highlight)
          {
           _element2.elementView(_view).resetDisplayStyle();
          }
        }

       if (_element2 != element)
        {
         addElement(newElement);
        }

       if (changed)
        {
         dirtied();
        }
      }
    }

   void style(Element element, StringBuffer buffer)
    {
     if (_highlight)
      {
       int highlightStart = 0;
       int highlightLength = 0;
       if (_element1 == element && _element2 == element)
        {
         highlightStart = _position1 - 1;
         highlightLength = _position2 - _position1 + 1;
        }
       else if (_element1 == element)
        {
         highlightStart = _position1 - 1;
         highlightLength = element.length() - _position1 + 1;
         if (highlightLength < 1)
          {
           highlightLength = 1;
          }
        }
       else if (_element2 == element)
        {
         highlightLength = _position2;
        }
       else
        {
         highlightLength = element.length();
        }

       int oldLength = buffer.length();
       if (oldLength < highlightStart + highlightLength)
        {
         buffer.setLength(highlightStart + highlightLength);
         for (int i = oldLength; i < highlightStart; i++)
          {
           buffer.setCharAt(i, '!');
          }
        }

       for (int i = highlightStart; i < highlightStart + highlightLength; i++)
        {
         buffer.setCharAt(i, _styleCharacter);
        }
      }
    }

   String query()
    {
     Document document = _view.document();
     ElementList elementList = document.elementList();
     int element1 = elementList.ordinalOf(_element1) + document.linesBeforeStart();
     int element2 = elementList.ordinalOf(_element2) + document.linesBeforeStart();
     StringBuffer queryString = new StringBuffer(32);
     if (_topSticky || _bottomSticky)
      {
       queryString.append("sticky ");
      }

     queryString.append(element1);
     queryString.append(' ');
     queryString.append(_position1);
     queryString.append(' ');
     queryString.append(element2);
     queryString.append(' ');
     queryString.append(_position2);

     return queryString.toString();
    }

   StyleAttributes defaultStyleAttributes()
    {
     return null;
    }
  }


 static final class MarkNode extends ListNode
  {
   Mark _mark;

   MarkNode(Mark mark)
    {
     _mark = mark;
    }

   Mark mark()
    {
     return _mark;
    }
  }
}


final class MarkListenerNode extends ListNode
{
 private LpexMarkListener _listener;

 MarkListenerNode(LpexMarkListener listener)
 {
  _listener = listener;
 }

 LpexMarkListener listener()
 {
  return _listener;
 }
}