//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ActionHandler - handles all built-in & user-defined actions in LPEX.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.printing.Printer;
import org.eclipse.swt.printing.PrinterData;


/**
 * This class handles the editor actions of a view.
 * There is one instance of this class for every document view.
 *
 * The class manages the built-in and user-defined actions, as well as the
 * current key and mouse event mappings.
 */
final class ActionHandler implements LpexConstants
 {
  // reduce source code dependencies on Java AWT/Swing / Eclipse SWT
  // keyAction modifier masks
  private static final int
   KEY_ALT       = SWT.ALT,             // the alt key modifier mask
// KEY_ALT_GRAPH = SWT.ALT | SWT.CTRL,  // the alt-graph key modifier mask
                                        // -as- n/u yet in AWT/Swing JLPEX,
                                        //      SWT gives Alt+Ctrl for it
   KEY_CTRL      = SWT.CTRL,            // the control key modifier mask
   KEY_META      = SWT.ALT,             // the meta key modifier mask
                                        // *as* n/a Windows SWT.META...
   KEY_SHIFT     = SWT.SHIFT,           // the shift key modifier mask
   KEY_BUTTON1   = SWT.BUTTON1,         // the mouse button1 modifier mask
   KEY_BUTTON2   = SWT.BUTTON2,         // the mouse button2 modifier mask
   KEY_BUTTON3   = SWT.BUTTON3;         // the mouse button3 modifier mask

  private View _view;

  private KeyActionList   _textAreaKeyActionList;
  private KeyActionList   _prefixAreaKeyActionList;
  private KeyActionList   _commandLineKeyActionList;
  private KeyActionList   _currentKeyActionList;

  private MouseActionList _textAreaMouseActionList;
  private MouseActionList _prefixAreaMouseActionList;
  private MouseActionList _expandHideAreaMouseActionList;

  // list of the user-defined actions for this document view
  private ActionList _actionList;

  private int        _availableActionId;
  private Point      _currentMousePoint = new Point(0,0);
  private String     _argument;
  private boolean    _settingArgument;
  private int        _lastKeyActionId = ACTION_INVALID;
  private String     _lastKeyActionArgument;
  private int        _userActionId = ACTION_INVALID;
  private int        _lastUserActionId = ACTION_INVALID;

  private Key _currentKey;
  private int _currentKeyModifiers;
  private int _currentKeyContext;

  private final static int MAX_REPEAT = 10000;

  // cursor context
  private final static int
   CONTEXT_INVALID          = 0x00000000,
   CONTEXT_TEXT_AREA        = 0x00000001,
   CONTEXT_PREFIX_AREA      = 0x00000002,
   CONTEXT_COMMAND_LINE     = 0x00000004,
   CONTEXT_EXPAND_HIDE_AREA = 0x00000008;

  // LPEX's own mouse event ids for the LPEX actions.
  // Used more in the swt version, to make up for the lack of MouseEvent.id()...
  final static int
   MOUSE_EVENT_INVALID       =  0, // awt swt
   MOUSE_EVENT_CLICKED       =  1, // awt  -   button is pressed & released
   MOUSE_EVENT_DRAGGED       =  2, // awt swt  mouse is dragged
   MOUSE_EVENT_ENTERED       =  3, // awt swt  mouse cursor enters a component
   MOUSE_EVENT_EXITED        =  4, // awt swt  mouse cursor exits a component
   MOUSE_EVENT_MOVED         =  5, // awt swt  mouse is moved
   MOUSE_EVENT_POPUP         =  6, // awt  -
   MOUSE_EVENT_PRESSED       =  7, // awt swt  button pressed
   MOUSE_EVENT_RELEASED      =  8, // awt swt  button released
   MOUSE_EVENT_HOVER         =  9, //  -  swt  mouse hover

   MOUSE_EVENT_DOUBLECLICKED = 10; //  -  swt: only used for event.id();  we make
                                   //          this into a _PRESSED x 2 action

  /**
   * keyCode: the integer code associated with the key in a key event:
   *          the integer code for an actual key on the keyboard.
   *          <code>keyCode</code> is a unique value assigned to each of the
   *          keys on the keyboard.  There is a common set of key codes that can
   *          be fired by most keyboards.  The symbolic name for a key code
   *          should be used rather than the code value itself.
   *
   *          AWT KeyEvent:  KEY_TYPED events do not have a keyCode value -
   *          VK_UNDEFINED is always returned.
   */
  private static final int VK_UNDEFINED = 0x0;

  /**
   * keyChar: the character associated with the key in a key event.
   *          E.g., for the key-typed event for shift + "a", key char is
   *          the value for "A".  <code>keyChar</code> is a valid Unicode
   *          character that is fired by a key or a key combination on
   *          a keyboard.
   *
   *          AWT KeyEvent:  KEY_PRESSED and KEY_RELEASED events which don't map
   *          to a valid Unicode character (e.g., the "down" arrow key, a cursor
   *          motion action) use CHAR_UNDEFINED for the keyChar value;
   *          KEY_TYPED events cannot have keyChar as CHAR_UNDEFINED.
   */
  private static final char CHAR_UNDEFINED = 0x0;

  /**
   * The keys LPEX recognizes for the keyAction parameter.
   * Method getKey(KeyEvent e) below maps an SWT KeyEvent to one of these Keys.
   * NB Keys must be in keyName alphabetical order for the binary search.
   */
  private static Key _keys[] =
   {
//          keyName             keyCode                   keyChar            ignoreShift
//          =======             =======                   =======            ===========
    new Key("0",                VK_UNDEFINED,             '0',               false),
    new Key("1",                VK_UNDEFINED,             '1',               false),
    new Key("2",                VK_UNDEFINED,             '2',               false),
    new Key("3",                VK_UNDEFINED,             '3',               false),
    new Key("4",                VK_UNDEFINED,             '4',               false),
    new Key("5",                VK_UNDEFINED,             '5',               false),
    new Key("6",                VK_UNDEFINED,             '6',               false),
    new Key("7",                VK_UNDEFINED,             '7',               false),
    new Key("8",                VK_UNDEFINED,             '8',               false),
    new Key("9",                VK_UNDEFINED,             '9',               false),
    new Key("a",                VK_UNDEFINED,             'a'/*also 'A'*/,   false),
//  new Key("accept",           KeyEvent.VK_ACCEPT,       CHAR_UNDEFINED,    false),
//  new Key("add",              KeyEvent.VK_ADD,          CHAR_UNDEFINED,    false),
//  new Key("again",            KeyEvent.VK_AGAIN,        CHAR_UNDEFINED,    false),
//  new Key("allCandidates",    KeyEvent.VK_ALL_CANDIDATES, CHAR_UNDEFINED,  false), // All Candidates function key (Alt+VK_CONVERT)
    new Key("ampersand",        VK_UNDEFINED,             '&',               true),
    new Key("asterisk",         VK_UNDEFINED,             '*',               true),
    new Key("atSign",           VK_UNDEFINED,             '@',               true),
    new Key("b",                VK_UNDEFINED,             'b',               false),
    new Key("backQuote",        VK_UNDEFINED,             '`',               true),
    new Key("backSlash",        VK_UNDEFINED,             '\\',              false),
    new Key("backSpace",        VK_UNDEFINED,             SWT.BS,            false),
    new Key("c",                VK_UNDEFINED,             'c',               false),
//  new Key("cancel",           KeyEvent.VK_CANCEL,       CHAR_UNDEFINED,    false),
//  new Key("capsLock",         KeyEvent.VK_CAPS_LOCK,    CHAR_UNDEFINED,    false),
//  new Key("clear",            KeyEvent.VK_CLEAR,        CHAR_UNDEFINED,    false),
    new Key("closeBrace",       VK_UNDEFINED,             '}',               true),
    new Key("closeBracket",     VK_UNDEFINED,             ']',               false),
    new Key("closeParenthesis", VK_UNDEFINED,             ')',               true),
//  new Key("codeInput",        KeyEvent.VK_CODE_INPUT,   CHAR_UNDEFINED,    false), // Code Input function key
    new Key("colon",            VK_UNDEFINED,             ':',               true),
    new Key("comma",            VK_UNDEFINED,             ',',               false),
//  new Key("compose",          VK_COMPOSE,               CHAR_UNDEFINED,    false), // Compose function key
//  new Key("convert",          KeyEvent.VK_CONVERT,      CHAR_UNDEFINED,    false),
//  new Key("copy",             KeyEvent.VK_COPY,         CHAR_UNDEFINED,    false),
//  new Key("cut",              KeyEvent.VK_CUT,          CHAR_UNDEFINED,    false),
    new Key("d",                VK_UNDEFINED,             'd',               false),
//  new Key("decimal",          KeyEvent.VK_DECIMAL,      CHAR_UNDEFINED,    false),
    new Key("delete",           VK_UNDEFINED,             SWT.DEL,           false),
//  new Key("divide",           KeyEvent.VK_DIVIDE,       CHAR_UNDEFINED,    false),
    new Key("dollarSign",       VK_UNDEFINED,             '$',               true),
    new Key("doubleQuote",      VK_UNDEFINED,             '"',               true),
    new Key("down",             SWT.ARROW_DOWN,           CHAR_UNDEFINED,    false),
    new Key("e",                VK_UNDEFINED,             'e',               false),
    new Key("end",              SWT.END,                  CHAR_UNDEFINED,    false),
    new Key("enter",            VK_UNDEFINED,             SWT.CR,            false),
    new Key("equals",           VK_UNDEFINED,             '=',               false),
    new Key("escape",           VK_UNDEFINED,             SWT.ESC,           false),
    new Key("exclamationMark",  VK_UNDEFINED,             '!',               true),
    new Key("f",                VK_UNDEFINED,             'f',               false),
    new Key("f1",               SWT.F1,                   CHAR_UNDEFINED,    false),
    new Key("f10",              SWT.F10,                  CHAR_UNDEFINED,    false),
    new Key("f11",              SWT.F11,                  CHAR_UNDEFINED,    false),
    new Key("f12",              SWT.F12,                  CHAR_UNDEFINED,    false),
    new Key("f2",               SWT.F2,                   CHAR_UNDEFINED,    false),
    new Key("f3",               SWT.F3,                   CHAR_UNDEFINED,    false),
    new Key("f4",               SWT.F4,                   CHAR_UNDEFINED,    false),
    new Key("f5",               SWT.F5,                   CHAR_UNDEFINED,    false),
    new Key("f6",               SWT.F6,                   CHAR_UNDEFINED,    false),
    new Key("f7",               SWT.F7,                   CHAR_UNDEFINED,    false),
    new Key("f8",               SWT.F8,                   CHAR_UNDEFINED,    false),
    new Key("f9",               SWT.F9,                   CHAR_UNDEFINED,    false),
//  new Key("f13" - "f24",      KeyEvent.VK_F13 - VK_F24, CHAR_UNDEFINED,    false),
//  new Key("final",            KeyEvent.VK_FINAL,        CHAR_UNDEFINED,    false),
//  new Key("find",             KeyEvent.VK_FIND,         CHAR_UNDEFINED,    false),
//  new Key("fullWidth",        KeyEvent.VK_FULL_WIDTH,   CHAR_UNDEFINED,    false), // Full-Width Characters function key
    new Key("g",                VK_UNDEFINED,             'g',               false),
    new Key("greaterThanSign",  VK_UNDEFINED,             '>',               true),
    new Key("h",                VK_UNDEFINED,             'h',               false),
//  new Key("halfWidth",        KeyEvent.VK_HALF_WIDTH,   CHAR_UNDEFINED,    false), // Half-Width Characters function key
//  new Key("help",             KeyEvent.VK_HELP,         CHAR_UNDEFINED,    false),
//  new Key("hiragana",         KeyEvent.VK_HIRAGANA,     CHAR_UNDEFINED,    false), // Hiragana function key
    new Key("home",             SWT.HOME,                 CHAR_UNDEFINED,    false),
    new Key("hyphen",           VK_UNDEFINED,             '-',               false),
    new Key("i",                VK_UNDEFINED,             'i',               false),
    new Key("insert",           SWT.INSERT,               CHAR_UNDEFINED,    false),
//  new Key("invertedExclamationMark", KeyEvent.VK_INVERTED_EXCLAMATION_MARK, CHAR_UNDEFINED, false),
    new Key("j",                VK_UNDEFINED,             'j',               false),
//  new Key("japaneseHiragana", KeyEvent.VK_JAPANESE_HIRAGANA, CHAR_UNDEFINED, false), // Japanese-Hiragana function key
//  new Key("japaneseKatakana", KeyEvent.VK_JAPANESE_KATAKANA, CHAR_UNDEFINED, false), // Japanese-Katakana function key
//  new Key("japaneseRoman",    KeyEvent.VK_JAPANESE_ROMAN, CHAR_UNDEFINED,  false), // Japanese-Roman function key
    new Key("k",                VK_UNDEFINED,             'k',               false),
//  new Key("kana",             KeyEvent.VK_KANA,         CHAR_UNDEFINED,    false),
//  new Key("kanji",            KeyEvent.VK_KANJI,        CHAR_UNDEFINED,    false),
    new Key("karat",            VK_UNDEFINED,             '^',               true),
//  new Key("katakana",         KeyEvent.VK_KATAKANA,     CHAR_UNDEFINED,    false), // Katakana function key
    new Key("l",                VK_UNDEFINED,             'l',               false),
    new Key("left",             SWT.ARROW_LEFT,           CHAR_UNDEFINED,    false),
    new Key("lessThanSign",     VK_UNDEFINED,             '<',               true),
    new Key("m",                VK_UNDEFINED,             'm',               false),
//  new Key("minus",            KeyEvent.VK_MINUS,        CHAR_UNDEFINED,    false),
//  new Key("modechange",       KeyEvent.VK_MODECHANGE,   CHAR_UNDEFINED,    false),
//  new Key("multiply",         KeyEvent.VK_MULTIPLY,     CHAR_UNDEFINED,    false),
    new Key("n",                VK_UNDEFINED,             'n',               false),
//  new Key("nonconvert",       KeyEvent.VK_NONCONVERT,   CHAR_UNDEFINED,    false),
//  new Key("numLock",          KeyEvent.VK_NUM_LOCK,     CHAR_UNDEFINED,    false),
    new Key("numberSign",       VK_UNDEFINED,             '#',               true),
//  new Key("numpad0",          KeyEvent.VK_NUMPAD0,      CHAR_UNDEFINED,    false),
//  new Key("numpad1",          KeyEvent.VK_NUMPAD1,      CHAR_UNDEFINED,    false),
//  new Key("numpad2",          KeyEvent.VK_NUMPAD2,      CHAR_UNDEFINED,    false),
//  new Key("numpad3",          KeyEvent.VK_NUMPAD3,      CHAR_UNDEFINED,    false),
//  new Key("numpad4",          KeyEvent.VK_NUMPAD4,      CHAR_UNDEFINED,    false),
//  new Key("numpad5",          KeyEvent.VK_NUMPAD5,      CHAR_UNDEFINED,    false),
//  new Key("numpad6",          KeyEvent.VK_NUMPAD6,      CHAR_UNDEFINED,    false),
//  new Key("numpad7",          KeyEvent.VK_NUMPAD7,      CHAR_UNDEFINED,    false),
//  new Key("numpad8",          KeyEvent.VK_NUMPAD8,      CHAR_UNDEFINED,    false),
//  new Key("numpad9",          KeyEvent.VK_NUMPAD9,      CHAR_UNDEFINED,    false),
    new Key("o",                VK_UNDEFINED,             'o',               false),
    new Key("openBrace",        VK_UNDEFINED,             '{',               true),
    new Key("openBracket",      VK_UNDEFINED,             '[',               false),
    new Key("openParenthesis",  VK_UNDEFINED,             '(',               true),
    new Key("p",                VK_UNDEFINED,             'p',               false),
    new Key("pageDown",         SWT.PAGE_DOWN,            CHAR_UNDEFINED,    false),
    new Key("pageUp",           SWT.PAGE_UP,              CHAR_UNDEFINED,    false),
//  new Key("paste",            KeyEvent.VK_PASTE,        CHAR_UNDEFINED,    false),
//  new Key("pause",            KeyEvent.VK_PAUSE,        CHAR_UNDEFINED,    false),
    new Key("percent",          VK_UNDEFINED,             '%',               true),
    new Key("period",           VK_UNDEFINED,             '.',               false),
    new Key("plus",             VK_UNDEFINED,             '+',               true),
//  new Key("previousCandidate", KeyEvent.VK_PREVIOUS_CANDIDATE, CHAR_UNDEFINED, false), // Previous Candidate function key
//  new Key("printscreen",      KeyEvent.VK_PRINTSCREEN,  CHAR_UNDEFINED,    false),
//  new Key("props",            KeyEvent.VK_PROPS,        CHAR_UNDEFINED,    false),
    new Key("q",                VK_UNDEFINED,             'q',               false),
    new Key("questionMark",     VK_UNDEFINED,             '?',               true),
    new Key("quote",            VK_UNDEFINED,             '\'',              false),
    new Key("r",                VK_UNDEFINED,             'r',               false),
    new Key("right",            SWT.ARROW_RIGHT,          CHAR_UNDEFINED,    false),
//  new Key("romanCharacters",  KeyEvent.VK_ROMAN_CHARACTERS, CHAR_UNDEFINED), // Roman Characters function key
    new Key("s",                VK_UNDEFINED,             's',               false),
//  new Key("scrollLock",       KeyEvent.VK_SCROLL_LOCK,  CHAR_UNDEFINED,    false),
    new Key("semicolon",        VK_UNDEFINED,             ';',               false),
//  new Key("separater",        KeyEvent.VK_SEPARATER,    CHAR_UNDEFINED,    false),
    new Key("slash",            VK_UNDEFINED,             '/',               false),
    new Key("space",            VK_UNDEFINED,             ' ',               false),
//  new Key("stop",             KeyEvent.VK_STOP,         CHAR_UNDEFINED,    false),
//  new Key("subtract",         KeyEvent.VK_SUBTRACT,     CHAR_UNDEFINED,    false),
    new Key("t",                VK_UNDEFINED,             't',               false),
    new Key("tab",              VK_UNDEFINED,             '\t' /*(char)0x9*/, false),
    new Key("tilde",            VK_UNDEFINED,             '~',               true),
    new Key("u",                VK_UNDEFINED,             'u',               false),
    new Key("underscore",       VK_UNDEFINED,             '_',               true),
//  new Key("undo",             KeyEvent.VK_UNDO,         CHAR_UNDEFINED,    false),
    new Key("up",               SWT.ARROW_UP,             CHAR_UNDEFINED,    false),
    new Key("v",                VK_UNDEFINED,             'v',               false),
    new Key("verticalBar",      VK_UNDEFINED,             '|',               true),
    new Key("w",                VK_UNDEFINED,             'w',               false),
    new Key("x",                VK_UNDEFINED,             'x',               false),
    new Key("y",                VK_UNDEFINED,             'y',               false),
    new Key("z",                VK_UNDEFINED,             'z',               false)
//  none of the KeyEvent.VK_DEAD_XXX keys...
   };

  /**
   * Table of the supported mouse action events.
   * NB Actions must be in alphabetical order for the binary search.
   */
  private static TableNode _mouseEvents[] =
   {
    new TableNode("clicked",  MOUSE_EVENT_CLICKED),
    new TableNode("dragged",  MOUSE_EVENT_DRAGGED),
    new TableNode("entered",  MOUSE_EVENT_ENTERED),
    new TableNode("exited",   MOUSE_EVENT_EXITED),
    new TableNode("hover",    MOUSE_EVENT_HOVER),
    new TableNode("moved",    MOUSE_EVENT_MOVED),
    new TableNode("popup",    MOUSE_EVENT_POPUP),
    new TableNode("pressed",  MOUSE_EVENT_PRESSED),
    new TableNode("released", MOUSE_EVENT_RELEASED)
   };

  /**
   * Table of the LPEX built-in actions.
   * NB Actions must be in alphabetical order for the binary search.
   */
  private static TableNode _actions[] =
   {
    new TableNode("appendToActionArgument", ACTION_APPEND_TO_ACTION_ARGUMENT),
    new TableNode("backSpace", ACTION_BACK_SPACE),
    new TableNode("blockCopy", ACTION_BLOCK_COPY),
    new TableNode("blockDelete", ACTION_BLOCK_DELETE),
    new TableNode("blockFill", ACTION_BLOCK_FILL),
    new TableNode("blockLowerCase", ACTION_BLOCK_LOWER_CASE),
    new TableNode("blockMarkAll", ACTION_BLOCK_MARK_ALL),
    new TableNode("blockMarkBottom", ACTION_BLOCK_MARK_BOTTOM),
    new TableNode("blockMarkCharacter", ACTION_BLOCK_MARK_CHARACTER),
    new TableNode("blockMarkDown", ACTION_BLOCK_MARK_DOWN),
    new TableNode("blockMarkElement", ACTION_BLOCK_MARK_ELEMENT),
    new TableNode("blockMarkElementAtMouse", ACTION_BLOCK_MARK_ELEMENT_AT_MOUSE),
    new TableNode("blockMarkEnd", ACTION_BLOCK_MARK_END),
    new TableNode("blockMarkHome", ACTION_BLOCK_MARK_HOME),
    new TableNode("blockMarkLeft", ACTION_BLOCK_MARK_LEFT),
    new TableNode("blockMarkNextWord", ACTION_BLOCK_MARK_NEXT_WORD),
    new TableNode("blockMarkPageDown", ACTION_BLOCK_MARK_PAGE_DOWN),
    new TableNode("blockMarkPageLeft", ACTION_BLOCK_MARK_PAGE_LEFT),
    new TableNode("blockMarkPageRight", ACTION_BLOCK_MARK_PAGE_RIGHT),
    new TableNode("blockMarkPageUp", ACTION_BLOCK_MARK_PAGE_UP),
    new TableNode("blockMarkPrevWord", ACTION_BLOCK_MARK_PREV_WORD),
    new TableNode("blockMarkRectangle", ACTION_BLOCK_MARK_RECTANGLE),
    new TableNode("blockMarkRectangleAtMouse", ACTION_BLOCK_MARK_RECTANGLE_AT_MOUSE),
    new TableNode("blockMarkRight", ACTION_BLOCK_MARK_RIGHT),
    new TableNode("blockMarkToMouse", ACTION_BLOCK_MARK_TO_MOUSE),
    new TableNode("blockMarkTop", ACTION_BLOCK_MARK_TOP),
    new TableNode("blockMarkUp", ACTION_BLOCK_MARK_UP),
    new TableNode("blockMarkWord", ACTION_BLOCK_MARK_WORD),
    new TableNode("blockMarkWordAtMouse", ACTION_BLOCK_MARK_WORD_AT_MOUSE),
    new TableNode("blockMove", ACTION_BLOCK_MOVE),
    new TableNode("blockOverlay", ACTION_BLOCK_OVERLAY),
    new TableNode("blockShiftLeft", ACTION_BLOCK_SHIFT_LEFT),
    new TableNode("blockShiftRight", ACTION_BLOCK_SHIFT_RIGHT),
    new TableNode("blockUnmark", ACTION_BLOCK_UNMARK),
    new TableNode("blockUpperCase", ACTION_BLOCK_UPPER_CASE),
    new TableNode("bottom", ACTION_BOTTOM),
    new TableNode("capitalizeWord", ACTION_CAPITALIZE_WORD),
    new TableNode("clearPrefix", ACTION_CLEAR_PREFIX),
    new TableNode("commandLine", ACTION_COMMAND_LINE),
    new TableNode("compare", ACTION_COMPARE),
    new TableNode("compareClear", ACTION_COMPARE_CLEAR),
    new TableNode("compareNext", ACTION_COMPARE_NEXT),
    new TableNode("comparePrevious", ACTION_COMPARE_PREVIOUS),
    new TableNode("compareRefresh", ACTION_COMPARE_REFRESH),
    new TableNode("copy", ACTION_COPY),
    new TableNode("cursorToMouse", ACTION_CURSOR_TO_MOUSE),
    new TableNode("cut", ACTION_CUT),
    new TableNode("delete", ACTION_DELETE),
    new TableNode("deleteBlankLines", ACTION_DELETE_BLANK_LINES),
    new TableNode("deleteLine", ACTION_DELETE_LINE),
    new TableNode("deleteNextWord", ACTION_DELETE_NEXT_WORD),
    new TableNode("deletePrevWord", ACTION_DELETE_PREV_WORD),
    new TableNode("deleteToLineStart", ACTION_DELETE_TO_LINE_START),
    new TableNode("deleteWhiteSpace", ACTION_DELETE_WHITE_SPACE),
    new TableNode("down", ACTION_DOWN),
    new TableNode("duplicateLine", ACTION_DUPLICATE_LINE),
    new TableNode("eclipseCopy", ACTION_ECLIPSE_COPY),
    new TableNode("eclipseCut", ACTION_ECLIPSE_CUT),
    //new TableNode("eclipseDelete", ACTION_ECLIPSE_DELETE),
    new TableNode("eclipsePaste", ACTION_ECLIPSE_PASTE),
    new TableNode("end", ACTION_END),
    new TableNode("excludeSelection", ACTION_EXCLUDE_SELECTION),
    new TableNode("execCommand", ACTION_EXEC_COMMAND),
    new TableNode("expandHideAtMouse", ACTION_EXPAND_HIDE_AT_MOUSE),
    new TableNode("filterSelection", ACTION_FILTER_SELECTION),
    new TableNode("find", ACTION_FIND),
    new TableNode("findAndReplace", ACTION_FIND_AND_REPLACE),
    new TableNode("findAndReplaceNext", ACTION_FIND_AND_REPLACE_NEXT),
    new TableNode("findAndReplaceUp", ACTION_FIND_AND_REPLACE_UP),
    new TableNode("findBlockEnd", ACTION_FIND_BLOCK_END),
    new TableNode("findBlockStart", ACTION_FIND_BLOCK_START),
    new TableNode("findLastChange", ACTION_FIND_LAST_CHANGE),
    new TableNode("findMark", ACTION_FIND_MARK),
    new TableNode("findNext", ACTION_FIND_NEXT),
    new TableNode("findQuickMark", ACTION_FIND_QUICK_MARK),
    new TableNode("findSelection", ACTION_FIND_SELECTION),
    new TableNode("findUp", ACTION_FIND_UP),
    new TableNode("get", ACTION_GET),
    new TableNode("help", ACTION_HELP),
    new TableNode("hexEditLine", ACTION_HEX_EDIT_LINE),
    new TableNode("home", ACTION_HOME),
    new TableNode("indentText", ACTION_INDENT_TEXT),
    new TableNode("insertFileName", ACTION_INSERT_FILE_NAME),
    new TableNode("insertLeftBrace", ACTION_INSERT_LEFT_BRACE),
    new TableNode("insertNot", ACTION_INSERT_NOT),
    new TableNode("insertRightBrace", ACTION_INSERT_RIGHT_BRACE),
    new TableNode("insertTab", ACTION_INSERT_TAB),
    new TableNode("insertToTab", ACTION_INSERT_TO_TAB),
    new TableNode("join", ACTION_JOIN),
    new TableNode("keyRecorderPlay", ACTION_KEY_RECORDER_PLAY),
    new TableNode("keyRecorderStart", ACTION_KEY_RECORDER_START),
    new TableNode("keyRecorderStop", ACTION_KEY_RECORDER_STOP),
    new TableNode("killLine", ACTION_KILL_LINE),
    new TableNode("killRegion", ACTION_KILL_REGION),
    new TableNode("left", ACTION_LEFT),
    new TableNode("locateLine", ACTION_LOCATE_LINE),
    new TableNode("lowerCaseRegion", ACTION_LOWER_CASE_REGION),
    new TableNode("lowerCaseWord", ACTION_LOWER_CASE_WORD),
    new TableNode("nameMark", ACTION_NAME_MARK),
    new TableNode("newLine", ACTION_NEW_LINE),
    new TableNode("nextTabStop", ACTION_NEXT_TAB_STOP),
    new TableNode("nextWord", ACTION_NEXT_WORD),
    new TableNode("nullAction", ACTION_NULL_ACTION),
    new TableNode("oneSpace", ACTION_ONE_SPACE),
    new TableNode("openLine", ACTION_OPEN_LINE),
    new TableNode("pageDown", ACTION_PAGE_DOWN),
    new TableNode("pageLeft", ACTION_PAGE_LEFT),
    new TableNode("pageRight", ACTION_PAGE_RIGHT),
    new TableNode("pageUp", ACTION_PAGE_UP),
    new TableNode("paste", ACTION_PASTE),
    new TableNode("popupAtCursor", ACTION_POPUP_AT_CURSOR),
    new TableNode("popupAtMouse", ACTION_POPUP_AT_MOUSE),
    new TableNode("preferences", ACTION_PREFERENCES),
    new TableNode("prefixBackSpace", ACTION_PREFIX_BACK_SPACE),
    new TableNode("prefixDelete", ACTION_PREFIX_DELETE),
    new TableNode("prefixEnd", ACTION_PREFIX_END),
    new TableNode("prefixHome", ACTION_PREFIX_HOME),
    new TableNode("prefixLeft", ACTION_PREFIX_LEFT),
    new TableNode("prefixRight", ACTION_PREFIX_RIGHT),
    new TableNode("prefixTruncate", ACTION_PREFIX_TRUNCATE),
    new TableNode("prevTabStop", ACTION_PREV_TAB_STOP),
    new TableNode("prevWord", ACTION_PREV_WORD),
    new TableNode("print", ACTION_PRINT),
    new TableNode("processPrefix", ACTION_PROCESS_PREFIX),
    new TableNode("redo", ACTION_REDO),
    new TableNode("reload", ACTION_RELOAD),
    new TableNode("rename", ACTION_RENAME),
    new TableNode("right", ACTION_RIGHT),
    new TableNode("save", ACTION_SAVE),
    new TableNode("saveAs", ACTION_SAVE_AS),
    new TableNode("saveToWriter", ACTION_SAVE_TO_WRITER),
    new TableNode("scrollBottom", ACTION_SCROLL_BOTTOM),
    new TableNode("scrollCenter", ACTION_SCROLL_CENTER),
    new TableNode("scrollTop", ACTION_SCROLL_TOP),
    new TableNode("setActionArgument", ACTION_SET_ACTION_ARGUMENT),
    new TableNode("setParser", ACTION_SET_PARSER),
    new TableNode("setQuickMark", ACTION_SET_QUICK_MARK),
    new TableNode("setQuickMarkAll", ACTION_SET_QUICK_MARK_ALL),
    new TableNode("setQuickMarkWord", ACTION_SET_QUICK_MARK_WORD),
    new TableNode("showAll", ACTION_SHOW_ALL),
    new TableNode("split", ACTION_SPLIT),
    new TableNode("splitAndShift", ACTION_SPLIT_AND_SHIFT),
    new TableNode("splitLine", ACTION_SPLIT_LINE),
    new TableNode("textWindow", ACTION_TEXT_WINDOW),
    new TableNode("toggleCaseSensitive", ACTION_TOGGLE_CASE_SENSITIVE),
    new TableNode("toggleInsert", ACTION_TOGGLE_INSERT),
    new TableNode("toggleKeyRecording", ACTION_TOGGLE_KEY_RECORDING),
    new TableNode("toggleRegularExpression", ACTION_TOGGLE_REGULAR_EXPRESSION),
    new TableNode("top", ACTION_TOP),
    new TableNode("transposeCharacters", ACTION_TRANSPOSE_CHARACTERS),
    new TableNode("transposeLines", ACTION_TRANSPOSE_LINES),
    new TableNode("transposeWords", ACTION_TRANSPOSE_WORDS),
    new TableNode("truncate", ACTION_TRUNCATE),
    new TableNode("undo", ACTION_UNDO),
    new TableNode("up", ACTION_UP),
    new TableNode("upperCaseRegion", ACTION_UPPER_CASE_REGION),
    new TableNode("upperCaseWord", ACTION_UPPER_CASE_WORD),
    new TableNode("windowBottom", ACTION_WINDOW_BOTTOM),
    new TableNode("windowTop", ACTION_WINDOW_TOP),
    new TableNode("wordEnd", ACTION_WORD_END),
    new TableNode("wordStart", ACTION_WORD_START),
    new TableNode("yank", ACTION_YANK),
    new TableNode("yankPrevious", ACTION_YANK_PREVIOUS),
   };

  /**
   * lpex baseProfile key actions.
   */
  private final static String lpexKeyActions =
    "a-b.t blockMarkCharacter " +
    "a-backSpace.t.p.secondary undo " +
    "a-c.t blockCopy " +
    "a-d.t.p.c blockDelete " +
    "a-i.t.p.c blockLowerCase " +
    "a-j.t join " +
    "a-k.t.p.c blockUpperCase " +
    "a-l.t blockMarkElement " +
    "a-m.t blockMove " +
    "a-pageDown.t.p.c findBlockEnd " +
    "a-pageUp.t.p.c findBlockStart " +
    "a-q.t.p.c findQuickMark " +
    "a-r.t blockMarkRectangle " +
    "a-s.t split " +
    "a-u.t.p.c blockUnmark " +
    "a-z.t blockOverlay " +
    "backSpace.p prefixBackSpace " +
    "backSpace.t backSpace " +
    "c-a.t.p.c blockMarkAll " +
    "c-b.t.p nullAction " +
    "c-backSpace.t.p.c deleteLine " +
    "c-c.p nullAction " +
    "c-c.t copy " +
    "c-d.t.p duplicateLine " +
    "c-delete.p prefixTruncate " +
    "c-delete.t truncate " +
    "c-e.t.p nullAction " +
    "c-end.t.p.c bottom " +
    "c-enter.t.p.c openLine " +
    "c-f.t.p.c find " +
    "c-g.t.p nullAction " +
    "c-h.t.p nullAction " +
    "c-home.t.p.c top " +
    "c-i.t.p nullAction " +
    "c-insert.t.secondary copy " +
    "c-j.t.p.c findLastChange " +
    "c-k.t.p nullAction " +
    "c-l.t.p.c locateLine " +
    "c-left.t prevWord " +
    "c-m.t.p nullAction " +
    "c-n.t.p.c findNext " +
    "c-o.t.p nullAction " +
    "c-p.t.p.c print " +
    "c-pageDown.t.p.c pageRight " +
    "c-pageUp.t.p.c pageLeft " +
    "c-q.p nullAction " +
    "c-q.t setQuickMark " +
    "c-r.t.p nullAction " +
    "c-right.t nextWord " +
    "c-s-a.t.p nullAction " +
    "c-s-b.t.p nullAction " +
    "c-s-c.t.p nullAction " +
    "c-s-d.t.p nullAction " +
    "c-s-e.t.p nullAction " +
    "c-s-end.t blockMarkBottom " +
    "c-s-f.t.p.c findAndReplace " +
    "c-s-g.t.p nullAction " +
    "c-s-h.t.p nullAction " +
    "c-s-home.t blockMarkTop " +
    "c-s-i.t.p nullAction " +
    "c-s-j.t.p nullAction " +
    "c-s-k.t.p nullAction " +
    "c-s-l.t.p nullAction " +
    "c-s-left.t blockMarkPrevWord " +
    "c-s-m.t.p nullAction " +
    "c-s-n.t.p compareNext " +
    "c-s-o.t.p nullAction " +
    "c-s-p.t.p comparePrevious " +
    "c-s-pageDown.t blockMarkPageRight " +
    "c-s-pageUp.t blockMarkPageLeft " +
    "c-s-q.t.p nullAction " +
    "c-s-r.t.p compareRefresh " +
    "c-s-right.t blockMarkNextWord " +
    "c-s-s.t.p nullAction " +
    "c-s-t.t.p nullAction " +
    "c-s-u.t.p nullAction " +
    "c-s-v.t.p nullAction " +
    "c-s-w.t.p nullAction " +
    "c-s-x.t.p nullAction " +
    "c-s-y.t.p nullAction " +
    "c-s-z.t.p.secondary redo " +
    "c-s.t.p.c save " +
    "c-t.t.p nullAction " +
    "c-u.t.p.c findUp " +
    "c-v.p nullAction " +
    "c-v.t paste " +
    "c-w.t.p.c showAll " +
    "c-x.p nullAction " +
    "c-x.t cut " +
    "c-y.t.p redo " +
    "c-z.t.p undo " +
    "delete.p prefixDelete " +
    "delete.t delete " +
    "down.t.p down " +
    "end.p prefixEnd " +
    "end.t end " +
    "enter.t splitLine " +
    "escape.t.p commandLine " +
    "f1.t.p.c help " +
    "f7.t.p.c blockShiftLeft " +
    "f8.t.p.c blockShiftRight " +
    "home.p prefixHome " +
    "home.t home " +
    "insert.t.p toggleInsert " +
    "left.p prefixLeft " +
    "left.t left " +
    "pageDown.t.p.c pageDown " +
    "pageUp.t.p.c pageUp " +
    "right.p prefixRight " +
    "right.t right " +
    "s-delete.t.secondary cut " +
    "s-down.t blockMarkDown " +
    "s-end.t blockMarkEnd " +
    "s-enter.t newLine " +
    "s-f10.p popupAtCursor " +
    "s-f10.t popupAtCursor " +
    "s-home.t blockMarkHome " +
    "s-insert.t.secondary paste " +
    "s-left.t blockMarkLeft " +
    "s-pageDown.t blockMarkPageDown " +
    "s-pageUp.t blockMarkPageUp " +
    "s-right.t blockMarkRight " +
    "s-tab.p prefixHome " +
    "s-tab.t prevTabStop " +
    "s-up.t blockMarkUp " +
    "tab.p home " +
    "tab.t insertToTab " +
    "up.t.p up ";

  /**
   * lpex baseProfile mouse actions.
   */
  private final static String lpexMouseActions =
    "1-dragged.t.p.e blockMarkToMouse " +
    "1-pressed.1.e expandHideAtMouse " +
    "1-pressed.1.t.p cursorToMouse " +
    "1-pressed.2.e expandHideAtMouse " +
    "1-pressed.2.t.p blockMarkWordAtMouse " +
    "1-pressed.3.e expandHideAtMouse " +
    "a-1-dragged.t.p.e blockMarkToMouse " +
    "a-1-pressed.1.t.p.e cursorToMouse " +
    "a-1-pressed.2.t.p.e blockMarkRectangleAtMouse " +
    "a-c-1-pressed.1.t.p.e blockUnmark " +
    "a-c-pressed.1.t.p.e blockUnmark " +
    "a-c-s-1-pressed.1.t.p.e blockUnmark " +
    "a-c-s-pressed.1.t.p.e blockUnmark " +
    "a-dragged.t.p.e blockMarkToMouse " +
    "a-pressed.1.t.p.e cursorToMouse " +
    "a-pressed.2.t.p.e blockMarkRectangleAtMouse " +
    "c-1-dragged.t.p.e blockMarkToMouse " +
    "c-1-pressed.1.t.p.e cursorToMouse " +
    "c-1-pressed.2.t.p.e blockMarkElementAtMouse " +
    "c-dragged.t.p.e blockMarkToMouse " +
    "c-pressed.1.t.p.e cursorToMouse " +
    "c-pressed.2.t.p.e blockMarkElementAtMouse " +
    "dragged.t.p.e blockMarkToMouse " +
    "popup.t.p.e popupAtMouse " +
    "pressed.1.e expandHideAtMouse " +
    "pressed.1.t.p cursorToMouse " +
    "pressed.2.e expandHideAtMouse " +
    "pressed.2.t.p blockMarkWordAtMouse " +
    "pressed.3.e expandHideAtMouse " +
    "s-1-dragged.t.p.e blockMarkToMouse " +
    "s-1-pressed.1.t.p.e blockMarkToMouse " +
    "s-dragged.t.p.e blockMarkToMouse " +
    "s-pressed.1.t.p.e blockMarkToMouse ";

  /**
   * brief baseProfile key & mouse actions.
   */
  private final static String briefKeyActions =
    "a-a.t blockMarkCharacter " +
    "a-backSpace.t deleteNextWord " +
    "a-c.t blockMarkRectangle " +
    "a-d.t deleteLine " +
    "a-enter.t.secondary splitLine " +
    "a-f.t insertFileName " +
    "a-f5.t.p.c findUp " +
    "a-f6.t.p.c findAndReplaceUp " +
    "a-g.t.p.c locateLine " +
    "a-h.t.p.c help " +
    "a-i.t.p toggleInsert " +
    "a-j.t.p.c findQuickMark " +
    "a-k.t truncate " +
    "a-l.t blockMarkElement " +
    "a-m.t.secondary blockMarkCharacter " +
    "a-o.t.p.c rename " +
    "a-p.t.p.c print " +
    "a-r.t.p.c get " +
    "a-s.t split " +
    "a-t.t.p.c.secondary findAndReplace " +
    "a-u.t.p undo " +
    "a-w.t.p.c save " +
    "a-y.t.p.c findBlockStart " +
    "c-b.t.p.c scrollBottom " +
    "c-backSpace.t deletePrevWord " +
    "c-c.t.p.c scrollCenter " +
    "c-d.t.p.c.secondary pageDown " +
    "c-e.t.p.c.secondary pageUp " +
    "c-end.t.p.c windowBottom " +
    "c-f5.t.p.c toggleCaseSensitive " +
    "c-f6.t.p.c toggleRegularExpression " +
    "c-home.t.p.c windowTop " +
    "c-k.t deleteToLineStart " +
    "c-pageDown.t.p.c bottom " +
    "c-pageUp.t.p.c top " +
    "c-s-backSpace.t deleteLine " +
    "c-t.t.p.c scrollTop " +
    "c-u.t.p.c redo " +
    "f10.t.p.c commandLine " +
    "f5.t.p.c find " +
    "f6.t.p.c findAndReplace " +
    "f7.t.p.c keyRecorderStart " +
    "f8.t.p.c keyRecorderPlay " +
    "s-enter.t.secondary splitLine " +
    "s-f5.t.p.c findNext " +
    "s-f6.t.p.c findAndReplaceNext " +
    "s-f7.t.p.c keyRecorderStop";
  private final static String briefMouseActions = "";

  /**
   * emacs baseProfile key & mouse actions.
   * "Alt-" key definitions are also provided for the "Meta-" key definitions.
   */
  private final static String emacsKeyActions =
    "a-0.t appendToActionArgument " +
    "a-1.t appendToActionArgument " +
    "a-2.t appendToActionArgument " +
    "a-3.t appendToActionArgument " +
    "a-4.t appendToActionArgument " +
    "a-5.t appendToActionArgument " +
    "a-6.t appendToActionArgument " +
    "a-7.t appendToActionArgument " +
    "a-8.t appendToActionArgument " +
    "a-9.t appendToActionArgument " +
    "a-atSign.t setQuickMarkWord " +
    "a-b.t prevWord " +
    "a-backSlash.t deleteWhiteSpace " +
    "a-backSpace.t deletePrevWord " +
    "a-c.t capitalizeWord " +
    "a-d.t deleteNextWord " +
    "a-delete.t deletePrevWord " +
    "a-f.t nextWord " +
    "a-greaterThanSign.t bottom " +
    "a-hyphen.t appendToActionArgument " +
    "a-i.t insertTab " +
    "a-l.t lowerCaseWord " +
    "a-lessThanSign.t top " +
    "a-percent.t findAndReplace " +
    "a-space.t oneSpace " +
    "a-t.t transposeWords " +
    "a-u.t upperCaseWord " +
    "a-v.t.c pageUp " +
    "a-x.t commandLine " +
    "a-y.t yankPrevious " +
    "backSpace.t backSpace " +
    "c-0.t appendToActionArgument " +
    "c-1.t appendToActionArgument " +
    "c-2.t appendToActionArgument " +
    "c-3.t appendToActionArgument " +
    "c-4.t appendToActionArgument " +
    "c-5.t appendToActionArgument " +
    "c-6.t appendToActionArgument " +
    "c-7.t appendToActionArgument " +
    "c-8.t appendToActionArgument " +
    "c-9.t appendToActionArgument " +
    "c-a-0.t appendToActionArgument " +
    "c-a-1.t appendToActionArgument " +
    "c-a-2.t appendToActionArgument " +
    "c-a-3.t appendToActionArgument " +
    "c-a-4.t appendToActionArgument " +
    "c-a-5.t appendToActionArgument " +
    "c-a-6.t appendToActionArgument " +
    "c-a-7.t appendToActionArgument " +
    "c-a-8.t appendToActionArgument " +
    "c-a-9.t appendToActionArgument " +
    "c-a-hyphen.t appendToActionArgument " +
    "c-a-o.t splitAndShift " +
    "c-a-s.t find " +
    "c-a.t home " +
    "c-atSign.t setQuickMark " +
    "c-b.t left " +
    "c-c.t nullAction " +
    "c-d.t delete " +
    "c-e.t end " +
    "c-f.t right " +
    "c-g.t.c nullAction " +
    "c-hyphen.t appendToActionArgument " +
    "c-i.t nullAction " +
    "c-j.t nullAction " +
    "c-k.t killLine " +
    "c-l.t.c scrollCenter " +
    "c-m-0.t appendToActionArgument " +
    "c-m-1.t appendToActionArgument " +
    "c-m-2.t appendToActionArgument " +
    "c-m-3.t appendToActionArgument " +
    "c-m-4.t appendToActionArgument " +
    "c-m-5.t appendToActionArgument " +
    "c-m-6.t appendToActionArgument " +
    "c-m-7.t appendToActionArgument " +
    "c-m-8.t appendToActionArgument " +
    "c-m-9.t appendToActionArgument " +
    "c-m-hyphen.t appendToActionArgument " +
    "c-m-o.t splitAndShift " +
    "c-m-s.t find " +
    "c-m.t nullAction " +
    "c-n.t down " +
    "c-o.t split " +
    "c-p.t up " +
    "c-q.t nullAction " +
    "c-r.t.c findUp " +
    "c-s.c findNext " +
    "c-s.t find " +
    "c-space.t setQuickMark " +
    "c-t.t transposeCharacters " +
    "c-u.t setActionArgument " +
    "c-underscore.t.c undo " +
    "c-v.t.c pageDown " +
    "c-w.t killRegion " +
    "c-x,c-l.t lowerCaseRegion " +
    "c-x,c-o.t deleteBlankLines " +
    "c-x,c-s.t.c save " +
    "c-x,c-t.t transposeLines " +
    "c-x,c-u.t upperCaseRegion " +
    "c-x,c-w.t.c saveAs " +
    "c-x,c-x.t findQuickMark " +
    "c-x,closeParenthesis.t keyRecorderStop " +
    "c-x,e keyRecorderPlay " +
    "c-x,greaterThanSign.t.c pageRight " +
    "c-x,h setQuickMarkAll " +
    "c-x,i.t.c get " +
    "c-x,lessThanSign.t.c pageLeft " +
    "c-x,openParenthesis.t keyRecorderStart " +
    "c-x,u.t.c undo " +
    "c-y.t yank " +
    "c-z.t nullAction " +
    "delete.t backSpace " +
    "down.t down " +
    "end.t bottom " +
    "enter.t splitLine " +
    "escape,0.t appendToActionArgument " +
    "escape,1.t appendToActionArgument " +
    "escape,2.t appendToActionArgument " +
    "escape,3.t appendToActionArgument " +
    "escape,4.t appendToActionArgument " +
    "escape,5.t appendToActionArgument " +
    "escape,6.t appendToActionArgument " +
    "escape,7.t appendToActionArgument " +
    "escape,8.t appendToActionArgument " +
    "escape,9.t appendToActionArgument " +
    "escape,atSign.t setQuickMarkWord " +
    "escape,b.t prevWord " +
    "escape,backSlash.t deleteWhiteSpace " +
    "escape,backSpace.t deletePrevWord " +
    "escape,c-o.t splitAndShift " +
    "escape,c-s.t find " +
    "escape,c.t capitalizeWord " +
    "escape,d.t deleteNextWord " +
    "escape,delete.t deletePrevWord " +
    "escape,f.t nextWord " +
    "escape,greaterThanSign.t bottom " +
    "escape,hyphen.t appendToActionArgument " +
    "escape,l.t lowerCaseWord " +
    "escape,lessThanSign.t top " +
    "escape,m-y.t yankPrevious " +
    "escape,percent.t findAndReplace " +
    "escape,space.t oneSpace " +
    "escape,t.t transposeWords " +
    "escape,u.t upperCaseWord " +
    "escape,v.t.c pageUp " +
    "escape,x.t commandLine " +
    "home.t top " +
    "insert.t toggleInsert " +
    "left.t left " +
    "m-0.t appendToActionArgument " +
    "m-1.t appendToActionArgument " +
    "m-2.t appendToActionArgument " +
    "m-3.t appendToActionArgument " +
    "m-4.t appendToActionArgument " +
    "m-5.t appendToActionArgument " +
    "m-6.t appendToActionArgument " +
    "m-7.t appendToActionArgument " +
    "m-8.t appendToActionArgument " +
    "m-9.t appendToActionArgument " +
    "m-atSign.t setQuickMarkWord " +
    "m-b.t prevWord " +
    "m-backSlash.t deleteWhiteSpace " +
    "m-backSpace.t deletePrevWord " +
    "m-c.t capitalizeWord " +
    "m-d.t deleteNextWord " +
    "m-delete.t deletePrevWord " +
    "m-f.t nextWord " +
    "m-greaterThanSign.t bottom " +
    "m-hyphen.t appendToActionArgument " +
    "m-l.t lowerCaseWord " +
    "m-lessThanSign.t top " +
    "m-percent.t findAndReplace " +
    "m-space.t oneSpace " +
    "m-t.t transposeWords " +
    "m-u.t upperCaseWord " +
    "m-v.t.c pageUp " +
    "m-x.t commandLine " +
    "m-y.t yankPrevious " +
    "pageDown.t.c pageDown " +
    "pageUp.t.c pageUp " +
    "right.t right " +
    "tab.t indentText " +
    "up.t up ";
  private final static String emacsMouseActions = "";

  /**
   * epm baseProfile key & mouse actions.
   */
  private final static String epmKeyActions =
    "a-b.t blockMarkRectangle " +
    "a-e.t.p.c findBlockEnd " +
    "a-enter.t.secondary splitLine " +
    "a-f.t.p.c blockFill " +
    "a-n.t insertFileName " +
    "a-w.t blockMarkWord " +
    "a-y.t.p.c findBlockStart " +
    "a-z.t blockMarkCharacter " +
    "c-0.t insertRightBrace " +
    "c-6.t insertNot " +
    "c-9.t insertLeftBrace " +
    "c-b.t.p.c findMark " +
    "c-d.t deleteNextWord " +
    "c-e.t truncate " +
    "c-enter.t.secondary splitLine " +
    "c-f.t.p.c findNext " +
    "c-f1.t upperCaseWord " +
    "c-f2.t lowerCaseWord " +
    "c-f3.t.p.c blockUpperCase " +
    "c-f4.t.p.c blockLowerCase " +
    "c-f5.t wordStart " +
    "c-f6.t wordEnd " +
    "c-f7.t blockShiftLeft " +
    "c-f8.t blockShiftRight " +
    "c-i.t.p commandLine " +
    "c-k.t.p duplicateLine " +
    "c-l.t execCommand " +
    "c-m.t nameMark " +
    "c-r.t.p.c toggleKeyRecording " +
    "c-s-backSpace.t deleteLine " +
    "c-s.t.p.c find " +
    "c-t.t.p.c keyRecorderPlay " +
    "c-tab.t insertTab " +
    "c-u.t.p undo " +
    "f2.t.p.c save " +
    "f3.t.p.c rename " +
    "f9.t.p.c undo " +
    "s-enter.t.secondary splitLine " +
    "s-f1.t.p.c pageLeft " +
    "s-f2.t.p.c pageRight " +
    "s-f3.t.p.c pageUp " +
    "s-f4.t.p.c pageDown";
  private final static String epmMouseActions = "";

  /**
   * seu baseProfile key & mouse actions.
   */
  private final static String seuKeyActions =
    "enter.p processPrefix " +
    "f5.t.p.c clearPrefix " +
    "f7.t.p.c pageUp " +
    "f8.t.p.c pageDown " +
    "s-f2.t.p.c find " +
    "s-f4.t.p.c findNext " +
    "s-f5.t.p.c findAndReplace " +
    "s-f7.t.p.c pageLeft " +
    "s-f8.t.p.c pageRight";
  private final static String seuMouseActions = "";

  /**
   * ispf baseProfile key & mouse actions.
   */
  private final static String ispfKeyActions =
    "enter.p processPrefix";
  private final static String ispfMouseActions = "";

  /**
   * xedit baseProfile key & mouse actions.
   */
  private final static String xeditKeyActions =
    "enter.p processPrefix " +
    "f11.t.p.c pageRight " +
    "f5.t.p.c findNext " +
    "f6.t.p.c find " +
    "f7.t.p.c pageUp " +
    "f8.t.p.c pageDown";
  private final static String xeditMouseActions = "";


  /**
   * Construct an action handler for a document view.
   */
  ActionHandler(View view)
   {
    _view = view;

    _textAreaKeyActionList = new KeyActionList(CONTEXT_TEXT_AREA);
    _prefixAreaKeyActionList = new KeyActionList(CONTEXT_PREFIX_AREA);
    _commandLineKeyActionList = new KeyActionList(CONTEXT_COMMAND_LINE);
    _currentKeyActionList = null;

    _textAreaMouseActionList = new MouseActionList(CONTEXT_TEXT_AREA);
    _prefixAreaMouseActionList = new MouseActionList(CONTEXT_PREFIX_AREA);
    _expandHideAreaMouseActionList = new MouseActionList(CONTEXT_EXPAND_HIDE_AREA);

    _actionList = new ActionList();
    _availableActionId = ACTION_USER;
   }

  void clearActionLists()
   {
    _textAreaKeyActionList.clear();
    _prefixAreaKeyActionList.clear();
    _commandLineKeyActionList.clear();

    _textAreaMouseActionList.clear();
    _prefixAreaMouseActionList.clear();
    _expandHideAreaMouseActionList.clear();

    _actionList.clear();
   }

  /**
   * Do our share of the <b>updateProfile</b> command.
   */
  void updateProfile()
   {
    clearActionLists();

    String baseProfile = _view.baseProfile();
    if (!"emacs".equals(baseProfile))
     {
      defineKeyActions(lpexKeyActions, "lpex");
     }
    defineMouseActions(lpexMouseActions, "lpex");

    if (baseProfile != null)
     {
      if (baseProfile.equals("brief"))
       {
        defineKeyActions(briefKeyActions, "brief");
        defineMouseActions(briefMouseActions, "brief");
       }
      else if (baseProfile.equals("emacs"))
       {
        defineKeyActions(emacsKeyActions, "emacs");
        defineMouseActions(emacsMouseActions, "emacs");
       }
      else if (baseProfile.equals("epm"))
       {
        defineKeyActions(epmKeyActions, "epm");
        defineMouseActions(epmMouseActions, "epm");
       }
      else if (baseProfile.equals("seu"))
       {
        defineKeyActions(seuKeyActions, "seu");
        defineMouseActions(seuMouseActions, "seu");
       }
      else if (baseProfile.equals("xedit"))
       {
        defineKeyActions(xeditKeyActions, "xedit");
        defineMouseActions(xeditMouseActions, "xedit");
       }
      else if (baseProfile.equals("ispf"))
       {
        defineKeyActions(ispfKeyActions, "ispf");
        defineMouseActions(ispfMouseActions, "ispf");
       }
     }

    String userActions =
      UpdateProfileCommand.UserActionsParameter.getParameter().currentValue(_view);
    if (userActions != null)
     {
      LpexStringTokenizer st = new LpexStringTokenizer(userActions);
      while (st.hasMoreTokens())
       {
        String action = st.nextToken();
        if (st.hasMoreTokens())
         {
          defineAction(action, st.nextToken());
         }
        else
         {
          _view.setLpexMessageText(MSG_ACTION_USERACTIONSINVALID, action);
         }
       }
     }

    UpdateProfileCommand.UserKeyActionsParameter userKeyActionsParameter =
      UpdateProfileCommand.UserKeyActionsParameter.getParameter();
    String userKeyActions = userKeyActionsParameter.currentValue(_view);
    if (userKeyActions != null)
     {
      defineKeyActions(userKeyActions, userKeyActionsParameter.name());
     }

    UpdateProfileCommand.UserMouseActionsParameter userMouseActionsParameter =
      UpdateProfileCommand.UserMouseActionsParameter.getParameter();
    String userMouseActions = userMouseActionsParameter.currentValue(_view);
    if (userMouseActions != null)
     {
      defineMouseActions(userMouseActions, userMouseActionsParameter.name());
     }
   }

  private void defineKeyActions(String keyActions, String setting)
   {
    LpexStringTokenizer st = new LpexStringTokenizer(keyActions);

    while (st.hasMoreTokens())
     {
      String key = st.nextToken();
      if (st.hasMoreTokens())
       {
        defineKeyAction(key, st.nextToken());
       }
      else
       {
        _view.setLpexMessageText(MSG_ACTION_KEYACTIONSINVALID, setting, key);
       }
     }
   }

  boolean defineKeyAction(String keyString, String actionString)
   {
    int modifiersArray[] = getKeyModifiersArray(keyString);
    Key keyArray[] = getKeyArray(keyString);
    int context = getKeyContext(keyString);
    boolean secondary = getSecondary(keyString);
    for (int i = 0; i < keyArray.length; i++)
     {
      if (keyArray[i] == null)
       {
        _view.setLpexMessageText(MSG_ACTION_KEYINVALID, keyString);
        return false;
       }
     }

    if (context == CONTEXT_INVALID)
     {
      _view.setLpexMessageText(MSG_ACTION_KEYINVALID, keyString);
      return false;
     }

    if ((context & CONTEXT_TEXT_AREA) != 0)
     {
      if (!_view.vi())
       {
        _textAreaKeyActionList.defineKeyAction(modifiersArray, keyArray,
                                               secondary, actionString);
       }
     }

    if ((context & CONTEXT_PREFIX_AREA) != 0)
     {
      _prefixAreaKeyActionList.defineKeyAction(modifiersArray, keyArray,
                                               secondary, actionString);
     }

    if ((context & CONTEXT_COMMAND_LINE) != 0)
     {
      _commandLineKeyActionList.defineKeyAction(modifiersArray, keyArray,
                                                secondary, actionString);
     }

    return true;
   }

  /**
   * List all the key-action assignments in effect for this document view.
   * See the <b>keys</b> parameter.
   */
  String keys()
   {
    // 1.- text-area key actions
    String keys = _textAreaKeyActionList.keys() + " ";
    // 2.- add prefix-area keys if the active profile supports prefix commands
    if (!_view.prefixProtect())
     {
      keys += _prefixAreaKeyActionList.keys() + " ";
     }
    // 3.- add the command-line key actions
    keys += _commandLineKeyActionList.keys();
    return keys.trim();
   }

  String keyActionString(String keyString)
   {
    int modifiersArray[] = getKeyModifiersArray(keyString);
    Key keyArray[] = getKeyArray(keyString);
    int context = getKeyContext(keyString);

    KeyActionList.KeyAction keyAction = findKey(modifiersArray, keyArray, context);
    return (keyAction != null)? keyAction.actionString() : null;
   }

  /**
   * @param context only one key context is currently accepted! -as-
   */
  KeyActionList.KeyAction findKey(int modifiers, Key key, int context)
   {
    KeyActionList.KeyAction keyAction = null;
    if (context == CONTEXT_TEXT_AREA)
     {
      keyAction = _textAreaKeyActionList.findKey(modifiers, key);
     }
    else if (context == CONTEXT_PREFIX_AREA)
     {
      keyAction = _prefixAreaKeyActionList.findKey(modifiers, key);
     }
    else if (context == CONTEXT_COMMAND_LINE)
     {
      keyAction = _commandLineKeyActionList.findKey(modifiers, key);
     }
    return keyAction;
   }

  /**
   * @param context only one key context is currently accepted! -as-
   */
  KeyActionList.KeyAction findKey(int modifiersArray[], Key keyArray[], int context)
   {
    KeyActionList.KeyAction keyAction = null;
    if (context == CONTEXT_TEXT_AREA)
     {
      keyAction = _textAreaKeyActionList.findKey(modifiersArray, keyArray);
     }
    else if (context == CONTEXT_PREFIX_AREA)
     {
      keyAction = _prefixAreaKeyActionList.findKey(modifiersArray, keyArray);
     }
    else if (context == CONTEXT_COMMAND_LINE)
     {
      keyAction = _commandLineKeyActionList.findKey(modifiersArray, keyArray);
     }
    return keyAction;
   }

  /**
   * This method is called when a key event is detected.
   * Called from TextWindow (key events in the text window), and
   * CommandLine (key events in the command line).
   */
  void doKeyEvent(KeyEvent e)
   {
    Composite textWindow = (_view.window() != null)? _view.window().textWindow() : null;
    if (textWindow == e.widget)
     {
      _currentKeyContext = _view.inPrefix()? CONTEXT_PREFIX_AREA : CONTEXT_TEXT_AREA;
     }
    else
     {
      _currentKeyContext = CONTEXT_COMMAND_LINE;
     }

    _currentKeyModifiers = e.stateMask;
    _currentKey = getKey(e);

    //System.out.println("  ActionHandler key = "+((_currentKey != null)?
    //                                    _currentKey.keyName() : "<none>"));

    /*========================================================*/
    /*  (A) vi baseProfile IN text area - see ViHandler.java  */
    /*========================================================*/
    if (_currentKeyContext == CONTEXT_TEXT_AREA && _view.vi())
     {
      char c = e.character;
      // Ctrl+I == '\t' (c = 0x9), no extra work needed like in AWT
      if (c == CHAR_UNDEFINED)
       {
        switch (e.keyCode)
         {
          case SWT.ARROW_DOWN:
           {
            c = 'j';
            break;
           }
          case SWT.ARROW_LEFT:
           {
            c = 'h';
            break;
           }
          case SWT.PAGE_DOWN:
           {
            c = 6; // ^F
            break;
           }
          case SWT.PAGE_UP:
           {
            c = 2; // ^B
            break;
           }
          case SWT.ARROW_RIGHT:
           {
            c = 'l';
            break;
           }
          case SWT.ARROW_UP:
           {
            c = 'k';
            break;
           }
          default:
           {
            break;
           }
         }
       }

      if (c != CHAR_UNDEFINED)
       {
        _view.beginUserAction();
        _view.viHandler().processCharacter(c);
        //awt: e.consume();
        _view.endUserAction();
        Document.screenShow();
       }
     }

    /*==============================================*/
    /*  (B) non-vi baseProfile OR not in text area  */
    /*==============================================*/
    else
     {
      char c = e.character; // AWT: e.getKeyChar();
      KeyActionList.KeyAction
        keyAction = (_currentKeyActionList == null)?
                     findKey(_currentKeyModifiers, _currentKey, _currentKeyContext) :
                     _currentKeyActionList.findKey(_currentKeyModifiers, _currentKey);

      //if (keyAction != null)
      //  System.out.println("  keyAction="+keyAction.keyString()+" = "+keyAction.actionString());
      //else
      //  System.out.println("  keyAction=<none>");

      if ((/*AWT: id == KeyEvent.KEY_PRESSED &&*/
            _currentKey != null &&
            (keyAction != null || _currentKeyActionList != null)) ||

          // a non-action, regular character in the text window
          (_currentKeyActionList == null &&
            /*AWT: id == KeyEvent.KEY_TYPED &&*/
            keyAction == null &&
            c != CHAR_UNDEFINED &&
            e.widget == textWindow))
       {
        int actionId = (keyAction != null)? keyAction.actionId() : ACTION_INVALID;
        _view.beginUserAction(actionId);
        /*---------------------------------------------------------*/
        /* 1.- keyAction == null AND _currentKeyActionList != null */
        /*---------------------------------------------------------*/
        if (_currentKeyActionList != null && keyAction == null)
         {
          _view.screen().setMessageText(null);
          _currentKeyActionList = null;
         }
        /*-----------------------*/
        /* 2.- keyAction != null */
        /*-----------------------*/
        else if (keyAction != null)
         {
          if (keyAction.keyActionList() != null)
           {
            _currentKeyActionList = keyAction.keyActionList();
            _view.screen().setMessageText(keyAction.keyString());
           }
          else
           {
            if (_currentKeyActionList != null)
             {
              _view.screen().setMessageText(null);
              _currentKeyActionList = null;
             }
            if (actionId == ACTION_INVALID)
             {
              _view.setLpexMessageText(MSG_ACTION_INVALID, keyAction.actionString());
             }
            else
             {
              _lastKeyActionId = actionId;
              _lastKeyActionArgument = _argument;
              boolean recording = KeyRecorder.keyRecorder().recording();
              doActionIfAvailable(actionId);
              if (recording == KeyRecorder.keyRecorder().recording())
               {
                KeyRecorder.keyRecorder().recordAction(actionId, _argument);
               }
              setArgument(null);
             }
           }
         }
        /*---------------------------------------------------------*/
        /* 3.- keyAction == null AND _currentKeyActionList == null */
        /*---------------------------------------------------------*/
        else
         {
          if (_settingArgument && validArgumentCharacter(c))
           {
            appendToArgument(c);
           }
          else
           {
            // don't enter & record undefined Alt+<char>s key combos as <char>s...
            // (*as* to do it for the entire case 3. ??)
            // but allow Tab/displayable Alt+Ctrl+<char>s (Alt+Ctrl is what e.g.,
            // the German keyboard gives for the AltGr key)
            if ((_currentKeyModifiers & KEY_ALT)  == 0 ||
                ((_currentKeyModifiers & KEY_CTRL) != 0 &&
                 (c == '\t' || c >= ' '))) // AWT: gives a nice CHAR_UNDEFINED for the
             {                             // chars we try to filter-out here ourselves
              int repeat = repeat();
              for (int i = 0; i < repeat; i++)
               {
                _view.receiveCharacter(c);
                KeyRecorder.keyRecorder().recordCharacter(_view.insertMode(), c);
               }
              setArgument(null);
             }
           }
         }

        //awt: e.consume();
        _view.endUserAction();
        Document.screenShow();
       }
     }
   }

  static int[] getKeyModifiersArray(String keyString)
   {
    keyString = keyString.replace(',', ' ');
    LpexStringTokenizer st = new LpexStringTokenizer(keyString);
    int count = st.countTokens();
    int modifiersArray[] = new int[count];
    for (int i = 0; i < count; i++)
     {
      modifiersArray[i] = getKeyModifiers(st.nextToken());
     }
    return modifiersArray;
   }

  /**
   * keyString:  a-c-s-backSpace.t
   * return:     KEY_ALT | KEY_CTRL | KEY_SHIFT
   */
  private static int getKeyModifiers(String keyString)
   {
    int modifiers = 0;
    for (int i = 1;  i < keyString.length() && keyString.charAt(i) == '-';  i += 2)
     {
      switch (keyString.charAt(i-1))
       {
        case 'a':
         {
          modifiers |= KEY_ALT;
          break;
         }
        case 'c':
         {
          modifiers |= KEY_CTRL;
          break;
         }
        case 'm':
         {
          modifiers |= KEY_META;
          break;
         }
        case 's':
         {
          modifiers |= KEY_SHIFT;
          break;
         }
        default: // not a key modifier
         {
          return modifiers;
         }
       }
     }

    return modifiers;
   }

  /**
   * Get the sequence of keys defined for a key action.
   * For example, for definition "escape,percent.t commandLine", keyString is:
   *   "escape,percent.t"
   * and key array returned is:
   *   [0]="escape", [1]="percent".
   */
  private static Key[] getKeyArray(String keyString)
   {
    keyString = keyString.replace(',', ' ');
    LpexStringTokenizer st = new LpexStringTokenizer(keyString);
    int count = st.countTokens();
    Key keyArray[] = new Key[count];
    for (int i = 0; i < count; i++)
     {
      keyArray[i] = getKey(st.nextToken(), i == count - 1);
     }
    return keyArray;
   }

  private static Key getKey(String keyString, boolean last)
   {
    while (keyString.startsWith("a-") ||
           keyString.startsWith("c-") ||
           keyString.startsWith("m-") ||
           keyString.startsWith("s-"))
     {
      keyString = keyString.substring(2);
     }

    int indexOfDot = keyString.indexOf(".");
    if (indexOfDot >= 0 && last)
     {
      keyString = keyString.substring(0, indexOfDot);
     }

    return (Key)Key.binarySearch(_keys, keyString);
   }

  /**
   * Return a Key from our table of defined _keys[] which matches the KeyEvent
   * <code>e</code>.  Called from doKeyEvent().
   * A Key contains the key name (used for defining keyAction's), its keyChar,
   * and its keyCode.
   *
   * <p>For more details on SWT key processing, see:
   * - org.eclipse.swt.widgets.Display ControlKey()
   * - org.eclipse.swt.widgets.Control WM_KEYDOWN(), WM_KEYUP()
   * - org.eclipse.swt.custom.StyledText handleKey() & related.
   */
  static Key getKey(KeyEvent e)
   {
    char keyChar  = e.character; // awt: e.getKeyChar();
    int keyCode = e.keyCode;     // awt: e.getKeyCode();
    int modifiers = e.stateMask; // awt: e.getModifiers();

    //-as- Eclipse R2.0 GTK+ 20020125 gives keychar == keycode,
    //     but we only have *one* of them in our Key table...
    boolean charLikeCode = (keyChar == keyCode);

    // decode the actual stuff behind a Ctrl+<stuff> combination
    if ((modifiers & KEY_CTRL) != 0 &&
        // (1/2002 but don't do it for Ctrl+Alt+<stuff> - which, by
        // the way, is what the German keyboard's AltGr key gives)
        (modifiers & KEY_ALT) == 0)
     {
      //*as* SWT Windows: Ctrl+Enter gives 0x0A, like Ctrl+j!?...
      if (keyChar == 0x0A && "win32".equals(SWT.getPlatform()))
       {
        keyChar = SWT.CR;
       }
      //*as* SWT Linux (Motif & GTK): Ctrl+Enter gives 0x0D, like Ctrl+m!?...
      else if (keyChar == 0x0D &&
               ("gtk".equals(SWT.getPlatform()) || "motif".equals(SWT.getPlatform())))
       {
        keyChar = SWT.CR;
       }
      else if (keyChar >= 1 && keyChar <= 31) // A..Z [{ \| ]} ^6 _-
       {
        keyChar += 64;                        // Ctrl+a (0x1=1) ==>'A' (0x41=65)
        //System.out.println(" ...keyChar adjusted for Ctrl ="+keyChar);
       }
     }

    // Eclipse R2.0 GTK+ 20020125 gives SWT.LF for the Enter key...
    else if (keyChar == SWT.LF)
     {
      keyChar = SWT.CR;
     }

    // SWT: for letters, go to lowercase, like we define key actions (in AWT
    //      the keyCode is the same for both lower- and upper-case letters,
    //      but we have no keyCode for the letters in SWT...)
    if (keyChar >= 'A' && keyChar <= 'Z')
     {
      keyChar += ('a' - 'A');
     }

    // fixup equal keyCode with any keyChar adjustments done above
    if (charLikeCode)
     {
      keyCode = keyChar;
     }

    Key key;
    for (int i = 0; i < _keys.length; i++)
     {
      key = _keys[i];
      // AWT: try best match between the AWT KeyEvent and our own Key definitions
      // SWT: trying *only* match (i.e., both keyChar & keyCode) between the
      //      SWT KeyEvent and our own Key definitions was fine until Eclipse R2.0
      //      GTK+ came along (e.g., build 20020125), where KeyEvent's keyChar is
      //      usually identical to its keyCode (instead of either being 0);  don't
      //      know if it will stay like this, but at least for now try more than
      //      just the exact match...
      if (key.keyCode() == keyCode && key.keyChar() == keyChar)
       {
        return key;
       }

      // further tries (see comment above)...
      // Case to be careful about on Eclipse R2.0 GTK 20020125, so we don't
      // find first "Backspace" in our table upon "End" key press / etc.:
      //             GTK                   Windows
      //             KeyEvent. KeyEvent.   KeyEvent. KeyEvent.    _keys[]   _keys[]
      //  key        keyChar   keyCode     keyChar   keyCode      keyChar   keyCode
      //  ---        --------- ---------   --------- ---------    -------   -------
      //  Backspace  0x8       0x8         0x8           0        SWT.BS       0
      //  End        0x8       0x1000008    0        0x1000008       0      SWT.END

      // (1) KeyEvent has a keyCode - SWT code tests keyCode first and,
      //     if there is one, uses just it
      if (keyCode != VK_UNDEFINED)
       {
        // SWT right now just puts *either* keyCode or keyChar in its binding
        // tables;  our _keys[] table also only defines either for each key...
        if (keyCode == key.keyCode() /*&& key.keyChar() == CHAR_UNDEFINED*/)
         {
          return key;
         }
        if (keyCode == key.keyChar() /*&& key.keyCode() == VK_UNDEFINED*/)
         {
          return key;
         }
       }
      // (2) KeyEvent has no keyCode, just keyChar
      else if (keyChar != CHAR_UNDEFINED)
       {
        if (keyChar == key.keyChar())
         {
          return key;
         }
       }
     }//end "for"

    return null;
   }

  static int getKeyContext(String keyString)
   {
    int context = 0;
    while (keyString.startsWith("a-") ||
           keyString.startsWith("c-") ||
           keyString.startsWith("m-") ||
           keyString.startsWith("s-"))
     {
      keyString = keyString.substring(2);
     }

    int indexOfDot = keyString.indexOf(".");
    if (indexOfDot >= 0)
     {
      keyString = keyString.substring(indexOfDot + 1);
     }
    else
     {
      keyString = "";
     }

    while (keyString.length() > 0)
     {
      String contextString;
      indexOfDot = keyString.indexOf(".");
      if (indexOfDot >= 0)
       {
        contextString = keyString.substring(0, indexOfDot);
        keyString = keyString.substring(indexOfDot + 1);
       }
      else
       {
        contextString = keyString;
        keyString = "";
       }

      if (contextString.length() > 0 && !contextString.equals("secondary"))
       {
        if (contextString.length() > 1)
         {
          return CONTEXT_INVALID;
         }

        switch(contextString.charAt(0))
         {
          case 't':
           {
            context |= CONTEXT_TEXT_AREA;
            break;
           }
          case 'p':
           {
            context |= CONTEXT_PREFIX_AREA;
            break;
           }
          case 'c':
           {
            context |= CONTEXT_COMMAND_LINE;
            break;
           }
          default:
           {
            return CONTEXT_INVALID;
           }
         }
       }
     }

    return (context == 0)? CONTEXT_TEXT_AREA : context;
   }

  static boolean getSecondary(String keyString)
   {
    while (keyString.startsWith("a-") ||
           keyString.startsWith("c-") ||
           keyString.startsWith("m-") ||
           keyString.startsWith("s-"))
     {
      keyString = keyString.substring(2);
     }

    int indexOfDot = keyString.indexOf(".");
    if (indexOfDot >= 0)
     {
      keyString = keyString.substring(indexOfDot + 1);
     }
    else
     {
      keyString = "";
     }

    while (keyString.length() > 0)
     {
      String contextString;
      indexOfDot = keyString.indexOf(".");
      if (indexOfDot >= 0)
       {
        contextString = keyString.substring(0, indexOfDot);
        keyString = keyString.substring(indexOfDot + 1);
       }
      else
       {
        contextString = keyString;
        keyString = "";
       }
      if (contextString.equals("secondary"))
       {
        return true;
       }
     }

    return false;
   }

  String keyText(int actionId)
   {
    KeyActionList.KeyAction keyAction = _textAreaKeyActionList.findPrimaryKey(actionId);
    if (keyAction != null)
     {
      String keyName = keyAction.key().keyName();
      String keyText = LpexResources.message("action." + keyName);
      if (keyText == null)
       {
        keyText = keyName.toUpperCase();
       }
      if ((keyAction.modifiers() & KEY_SHIFT) != 0)
       {
        keyText = LpexResources.message(MSG_ACTION_SHIFT) + "+" + keyText;
       }
      if ((keyAction.modifiers() & KEY_ALT) != 0)
       {
        keyText = LpexResources.message(MSG_ACTION_ALT) + "+" + keyText;
       }
      if ((keyAction.modifiers() & KEY_CTRL) != 0)
       {
        keyText = LpexResources.message(MSG_ACTION_CONTROL) + "+" + keyText;
       }
      if (KEY_META != KEY_ALT && //don't duplicate (m-a-key) on SWT Windows...
          (keyAction.modifiers() & KEY_META) != 0)
       {
        keyText = LpexResources.message(MSG_ACTION_META) + "+" + keyText;
       }
      return keyText;
     }

    return null;
   }

  String keyString(int actionId)
   {
    KeyActionList.KeyAction keyAction = _textAreaKeyActionList.findPrimaryKey(actionId);
    return (keyAction != null)? keyAction.keyString() : null;
   }

  /**
   * Return the last keystroke that was issued by the user.
   * Called by CurrentKeyParameter.
   */
  String currentKeyString()
   {
    if (_currentKey == null)
     {
      return null;
     }

    String keyString = _currentKey.keyName();
    if ((_currentKeyModifiers & KEY_SHIFT) != 0)
     {
      keyString = "s-" + keyString;
     }
    if ((_currentKeyModifiers & KEY_ALT) != 0)
     {
      keyString = "a-" + keyString;
     }
    if ((_currentKeyModifiers & KEY_CTRL) != 0)
     {
      keyString = "c-" + keyString;
     }
    if (KEY_META != KEY_ALT && //don't duplicate (m-a-key) on SWT Windows...
        (_currentKeyModifiers & KEY_META) != 0)
     {
      keyString = "m-" + keyString;
     }

    if ((_currentKeyContext & CONTEXT_TEXT_AREA) != 0)
     {
      keyString += ".t";
     }
    if ((_currentKeyContext & CONTEXT_PREFIX_AREA) != 0)
     {
      keyString += ".p";
     }
    if ((_currentKeyContext & CONTEXT_COMMAND_LINE) != 0)
     {
      keyString += ".c";
     }

    return keyString;
   }

  private void defineMouseActions(String mouseActions, String setting)
   {
    LpexStringTokenizer st = new LpexStringTokenizer(mouseActions);

    while (st.hasMoreTokens())
     {
      String mouseEvent = st.nextToken();
      if (st.hasMoreTokens())
       {
        defineMouseAction(mouseEvent, st.nextToken());
       }
      else
       {
        _view.setLpexMessageText(MSG_ACTION_MOUSEACTIONSINVALID, setting, mouseEvent);
       }
     }
   }

  boolean defineMouseAction(String mouseEvent, String actionString)
   {
    int modifiers  = getMouseModifiers(mouseEvent);
    int eventId    = getMouseEventId(mouseEvent);
    int clickCount = getMouseClickCount(mouseEvent);
    int context    = getMouseContext(mouseEvent);

    if (eventId == MOUSE_EVENT_INVALID ||
        (clickCount <= 0 && (eventId == MOUSE_EVENT_CLICKED ||
                             eventId == MOUSE_EVENT_PRESSED ||
                             eventId == MOUSE_EVENT_RELEASED)) ||
        context == CONTEXT_INVALID)
     {
      _view.setLpexMessageText(MSG_ACTION_MOUSEEVENTINVALID, mouseEvent);
      return false;
     }

    if ((context & CONTEXT_TEXT_AREA) != 0)
     {
      _textAreaMouseActionList.defineMouseAction(modifiers, eventId,
                                                 clickCount, actionString);
     }

    if ((context & CONTEXT_PREFIX_AREA) != 0)
     {
      _prefixAreaMouseActionList.defineMouseAction(modifiers, eventId,
                                                   clickCount, actionString);
     }

    if ((context & CONTEXT_EXPAND_HIDE_AREA) != 0)
     {
      _expandHideAreaMouseActionList.defineMouseAction(modifiers, eventId,
                                                       clickCount, actionString);
     }

    return true;
   }

  String mouseEvents()
   {
    String mouseEvents = _textAreaMouseActionList.mouseEvents() + " " +
                         _prefixAreaMouseActionList.mouseEvents() + " " +
                         _expandHideAreaMouseActionList.mouseEvents();
    return mouseEvents.trim();
   }

  String mouseActionString(String mouseEvent)
   {
    int modifiers  = getMouseModifiers(mouseEvent);
    int eventId    = getMouseEventId(mouseEvent);
    int clickCount = getMouseClickCount(mouseEvent);
    int context    = getMouseContext(mouseEvent);

    MouseActionList.MouseAction mouseAction = findMouseEvent(modifiers, eventId,
                                                             clickCount, context);
    return (mouseAction != null)? mouseAction.actionString() : null;
   }

  MouseActionList.MouseAction findMouseEvent(int modifiers, int eventId,
                                             int clickCount, int context)
   {
    MouseActionList.MouseAction mouseAction = null;
    if (context == CONTEXT_TEXT_AREA)
     {
      mouseAction = _textAreaMouseActionList.findMouseEvent(modifiers, eventId,
                                                            clickCount);
     }

    else if (context == CONTEXT_PREFIX_AREA)
     {
      mouseAction = _prefixAreaMouseActionList.findMouseEvent(modifiers, eventId,
                                                              clickCount);
     }

    else if (context == CONTEXT_EXPAND_HIDE_AREA)
     {
      mouseAction = _expandHideAreaMouseActionList.findMouseEvent(modifiers, eventId,
                                                                  clickCount);
     }

    return mouseAction;
   }

  // This method is called when a mouse event is detected (see TextWindow.java).
  private int _lastMousePressedModifiers;
  void doMouseEvent(MouseEvent e, int eID)
   {
    // awt: e.getModifiers();
    // swt: unless it's a mouse drag event, we don't need the SWT.BUTTONn flags
    //      info in the e.stateMask, so overwrite with the e.button instead, in
    //      order to keep all this information in one int, like for awt
    int modifiers = e.stateMask;
    if (eID != MOUSE_EVENT_DRAGGED) {
       modifiers &= ~(SWT.BUTTON1 | SWT.BUTTON2 | SWT.BUTTON3);
       if (e.button == 1)
          modifiers |= SWT.BUTTON1;
       else if (e.button == 2)
          modifiers |= SWT.BUTTON2;
       else if (e.button == 3)
          modifiers |= SWT.BUTTON2;
       }

    int eventId = eID;
    int clickCount = 0;
//  if (e.isPopupTrigger())
//   {
//    eventId = MOUSE_EVENT_POPUP;
//   }
//  else
     {
      switch (eID) // awt: e.getID(), returning e.g., MouseEvent.MOUSE_PRESSED
       {
        case MOUSE_EVENT_CLICKED:
         {
          clickCount = 1; /* awt: e.getClickCount(); */
          break;
         }
        case MOUSE_EVENT_DRAGGED:
         {
          modifiers = _lastMousePressedModifiers;
          break;
         }
        case MOUSE_EVENT_PRESSED:
         {
          clickCount = 1; /* awt: e.getClickCount(); */
          _lastMousePressedModifiers = modifiers;
          break;
         }
        case MOUSE_EVENT_RELEASED:
         {
          clickCount = 1; /* awt: e.getClickCount(); */
          break;
         }
        case MOUSE_EVENT_ENTERED:
        case MOUSE_EVENT_EXITED:
        case MOUSE_EVENT_MOVED:
        case MOUSE_EVENT_HOVER:         // swt only
         {
          break;
         }
        case MOUSE_EVENT_DOUBLECLICKED: // swt only
         {
          eventId = MOUSE_EVENT_PRESSED;
          clickCount = 2;
          break;
         }
        default:
         {
          eventId = MOUSE_EVENT_INVALID;
          break;
         }
       }
     }

    _currentMousePoint.x = e.x; // awt: e.getPoint();
    _currentMousePoint.y = e.y;

    int x = _currentMousePoint.x;
    int context = CONTEXT_TEXT_AREA;
    if (x > 0 && _view.screen().prefixAreaWidth() > 0 &&
        _view.screen().prefixAreaWidth() > x)
     {
      context = CONTEXT_PREFIX_AREA;
     }
    if (x > 0 && _view.screen().expandHideAreaWidth() > 0 &&
        _view.screen().expandHideAreaWidth() > x)
     {
      context = CONTEXT_EXPAND_HIDE_AREA;
     }

    MouseActionList.MouseAction mouseAction =
      findMouseEvent(modifiers, eventId, clickCount, context);
    if (mouseAction != null)
     {
      int actionId = mouseAction.actionId();
      _view.beginUserAction(actionId);
      if (actionId == ACTION_INVALID)
       {
        _view.setLpexMessageText(MSG_ACTION_INVALID, mouseAction.actionString());
       }
      else
       {
        doActionIfAvailable(actionId);
        setArgument(null);
       }

      //awt: e.consume();
      _view.endUserAction();
      Document.screenShow();
     }
   }

  /**
   * mouseEvent:  a-c-1-pressed.1.t.p.e
   * return:      KEY_ALT | KEY_CTRL | KEY_BUTTON1
   */
  private static int getMouseModifiers(String mouseEvent)
   {
    int modifiers = 0;
    for (int i = 1;  i < mouseEvent.length() && mouseEvent.charAt(i) == '-';  i += 2)
     {
      switch (mouseEvent.charAt(i-1))
       {
        case '1':
         {
          modifiers |= KEY_BUTTON1;
          break;
         }
        case '2':
         {
          modifiers |= KEY_BUTTON2;
          break;
         }
        case '3':
         {
          modifiers |= KEY_BUTTON3;
          break;
         }
        case 'a':
         {
          modifiers |= KEY_ALT;
          break;
         }
        case 'c':
         {
          modifiers |= KEY_CTRL;
          break;
         }
        case 'm':
         {
          modifiers |= KEY_META;
          break;
         }
        case 's':
         {
          modifiers |= KEY_SHIFT;
          break;
         }
        default: // not a mouse modifier
         {
          return modifiers;
         }
       }
     }

    return modifiers;
   }

  static int getMouseEventId(String mouseEvent)
   {
    while (mouseEvent.startsWith("1-") ||
           mouseEvent.startsWith("2-") ||
           mouseEvent.startsWith("3-") ||
           mouseEvent.startsWith("a-") ||
           mouseEvent.startsWith("c-") ||
           mouseEvent.startsWith("m-") ||
           mouseEvent.startsWith("s-"))
     {
      mouseEvent = mouseEvent.substring(2);
     }

    int indexOfDot = mouseEvent.indexOf(".");
    if (indexOfDot >= 0)
     {
      mouseEvent = mouseEvent.substring(0, indexOfDot);
     }

    TableNode tableNode = TableNode.binarySearch(_mouseEvents, mouseEvent);
    return (tableNode != null)? tableNode.id() : MOUSE_EVENT_INVALID;
   }

  static int getMouseClickCount(String mouseEvent)
   {
    int clickCount = 0;
    while (mouseEvent.startsWith("1-") ||
           mouseEvent.startsWith("2-") ||
           mouseEvent.startsWith("3-") ||
           mouseEvent.startsWith("a-") ||
           mouseEvent.startsWith("c-") ||
           mouseEvent.startsWith("m-") ||
           mouseEvent.startsWith("s-"))
     {
      mouseEvent = mouseEvent.substring(2);
     }

    int indexOfDot = mouseEvent.indexOf(".");
    if (indexOfDot >= 0)
     {
      mouseEvent = mouseEvent.substring(indexOfDot + 1);
     }
    else
     {
      mouseEvent = "";
     }

    indexOfDot = mouseEvent.indexOf(".");
    if (indexOfDot >= 0)
     {
      mouseEvent = mouseEvent.substring(0, indexOfDot);
     }
    if (mouseEvent.length() > 0)
     {
      try
       {
        clickCount = Integer.parseInt(mouseEvent);
       }
      catch(NumberFormatException e) {}
     }

    return clickCount;
   }

  static int getMouseContext(String mouseEvent)
   {
    int context = 0;
    while (mouseEvent.startsWith("1-") ||
           mouseEvent.startsWith("2-") ||
           mouseEvent.startsWith("3-") ||
           mouseEvent.startsWith("a-") ||
           mouseEvent.startsWith("c-") ||
           mouseEvent.startsWith("m-") ||
           mouseEvent.startsWith("s-"))
     {
      mouseEvent = mouseEvent.substring(2);
     }

    int indexOfDot = mouseEvent.indexOf(".");
    if (indexOfDot >= 0)
     {
      mouseEvent = mouseEvent.substring(indexOfDot + 1);
     }
    else
     {
      mouseEvent = "";
     }

    indexOfDot = mouseEvent.indexOf(".");
    if (indexOfDot >= 0)
     {
      try
       {
        int clickCount = Integer.parseInt(mouseEvent.substring(0, indexOfDot));
        mouseEvent = mouseEvent.substring(indexOfDot + 1);
       }
      catch(NumberFormatException e) {}
     }
    else if (mouseEvent.length() > 0)
     {
      try
       {
        int clickCount = Integer.parseInt(mouseEvent);
        mouseEvent = "";
       }
      catch(NumberFormatException e) {}
     }

    while (mouseEvent.length() > 0)
     {
      String contextString;
      indexOfDot = mouseEvent.indexOf(".");
      if (indexOfDot >= 0)
       {
        contextString = mouseEvent.substring(0, indexOfDot);
        mouseEvent = mouseEvent.substring(indexOfDot + 1);
       }
      else
       {
        contextString = mouseEvent;
        mouseEvent = "";
       }

      if (contextString.length() > 0)
       {
        if (contextString.length() > 1)
         {
          return CONTEXT_INVALID;
         }
        switch(contextString.charAt(0))
         {
          case 't':
           {
            context |= CONTEXT_TEXT_AREA;
            break;
           }
          case 'p':
           {
            context |= CONTEXT_PREFIX_AREA;
            break;
           }
          case 'e':
           {
            context |= CONTEXT_EXPAND_HIDE_AREA;
            break;
           }
          default:
           {
            return CONTEXT_INVALID;
           }
         }
       }
     }

    return (context == 0)? CONTEXT_TEXT_AREA : context;
   }

  Point currentMousePoint()
   {
    return _currentMousePoint;
   }

  void triggerAction(int actionId)
   {
    _view.beginUserAction(actionId);
    doAction(actionId);
    setArgument(null);
    _view.endUserAction();
    Document.screenShow();
   }

  /**
   * Find the id of an actionString - either the id assigned to a user-defined
   * action (in the _actionList table), or the default id defined for a built-in
   * action (in our _actions table).
   */
  int id(String actionString)
   {
    if (actionString != null)
     {
      actionString = actionString.trim();
      Action userAction = _actionList.find(actionString);
      return (userAction != null)? userAction.id() : defaultId(actionString);
     }
    return ACTION_INVALID;
   }

  /**
   * Find the default id defined for a built-in action (in our _actions table).
   */
  private static int defaultId(String actionString)
   {
    TableNode tableNode = TableNode.binarySearch(_actions, actionString);
    return (tableNode != null)? tableNode.id() : ACTION_INVALID;
   }

  boolean actionAvailable(int id)
   {
    Action userAction = _actionList.find(id);
    if (userAction != null)
     {
      return userAction.lpexAction().available(_view.lpexView());
     }
    return defaultActionAvailable(id);
   }

  boolean defaultActionAvailable(int id)
   {
    boolean actionAvailable = true;

    Document document = _view.document();
    Element element = _view.documentPosition().element();
    int position = _view.documentPosition().position();

    switch(id)
     {
      case ACTION_INVALID:
       {
        return false;
       }
      case ACTION_BACK_SPACE:
       {
        actionAvailable = element != null &&
                          !element.show() &&
                          !_view.readonly() &&
                          !_view.markList().protect(element);
        break;
       }
      case ACTION_BLOCK_COPY:
       {
        actionAvailable = Block.anythingSelected() &&
                          element != null &&
                          !_view.readonly() &&
                          !_view.markList().insertElementProtect(element);
        break;
       }
      case ACTION_BLOCK_DELETE:
      case ACTION_BLOCK_FILL:
      case ACTION_BLOCK_LOWER_CASE:
       {
        actionAvailable = Block.view() == _view &&
                          Block.anythingUnprotectedSelected() &&
                          !_view.readonly();
        break;
       }
      case ACTION_BLOCK_MARK_ALL:
      case ACTION_ECLIPSE_SELECT_ALL:
      case ACTION_BLOCK_MARK_BOTTOM:
      case ACTION_BLOCK_MARK_CHARACTER:
      case ACTION_BLOCK_MARK_DOWN:
      case ACTION_BLOCK_MARK_ELEMENT:
      case ACTION_BLOCK_MARK_END:
      case ACTION_BLOCK_MARK_HOME:
      case ACTION_BLOCK_MARK_LEFT:
      case ACTION_BLOCK_MARK_NEXT_WORD:
      case ACTION_BLOCK_MARK_PAGE_DOWN:
      case ACTION_BLOCK_MARK_PAGE_LEFT:
      case ACTION_BLOCK_MARK_PAGE_RIGHT:
      case ACTION_BLOCK_MARK_PAGE_UP:
      case ACTION_BLOCK_MARK_PREV_WORD:
      case ACTION_BLOCK_MARK_RECTANGLE:
      case ACTION_BLOCK_MARK_RIGHT:
      case ACTION_BLOCK_MARK_TOP:
      case ACTION_BLOCK_MARK_UP:
      case ACTION_BLOCK_MARK_WORD:
       {
        actionAvailable = element != null;
        break;
       }
      case ACTION_BLOCK_MOVE:
       {
        actionAvailable = element != null &&
                          Block.anythingSelected() &&
                          !Block.anythingProtectedSelected() &&
                          !_view.readonly() &&
                          !Block.view().readonly();
        break;
       }
      case ACTION_BLOCK_OVERLAY:
       {
        actionAvailable = element != null &&
                          Block.anythingSelected() &&
                          (Block.type() == Block.RECTANGLE ||
                           Block.type() == Block.ELEMENT) &&
                          !element.show() &&
                          !_view.markList().protect(element) &&
                          !_view.readonly();
        break;
       }
      case ACTION_BLOCK_SHIFT_LEFT:
      case ACTION_BLOCK_SHIFT_RIGHT:
       {
        actionAvailable = Block.view() == _view &&
                          Block.anythingUnprotectedSelected() &&
                          (Block.type() == Block.RECTANGLE ||
                           Block.type() == Block.ELEMENT) &&
                          !_view.readonly();
        break;
       }
      case ACTION_BLOCK_UNMARK:
       {
        actionAvailable = Block.view() == _view &&
                          Block.anythingSelected();
        break;
       }
      case ACTION_BLOCK_UPPER_CASE:
       {
        actionAvailable = Block.view() == _view &&
                          Block.anythingUnprotectedSelected() &&
                          !_view.readonly();
        break;
       }
      case ACTION_COMMAND_LINE:
       {
        actionAvailable = !_view.vi() &&
                          _view.window() != null;
        break;
       }
      case ACTION_COPY:
      case ACTION_ECLIPSE_COPY:
       {
        actionAvailable = Block.view() == _view &&
                          Block.anythingSelected();
        break;
       }
      case ACTION_CUT:
      case ACTION_ECLIPSE_CUT:
       {
        actionAvailable = Block.view() == _view &&
                          Block.anythingSelected() &&
                          !Block.anythingProtectedSelected() &&
                          !_view.readonly();
        break;
       }
      case ACTION_DELETE:
      case ACTION_ECLIPSE_DELETE:
       {
        actionAvailable = element != null &&
                          !element.show() &&
                          !_view.readonly() &&
                          !_view.markList().protect(element);
        break;
       }
      case ACTION_DELETE_BLANK_LINES:
       {
        actionAvailable = element != null &&
                          !_view.readonly();
        break;
       }
      case ACTION_DELETE_LINE:
       {
        actionAvailable = element != null &&
                          !_view.readonly() &&
                          !_view.markList().protect(element);
        break;
       }
      case ACTION_DELETE_NEXT_WORD:
      case ACTION_DELETE_PREV_WORD:
       {
        actionAvailable = element != null &&
                          !_view.readonly();
        break;
       }
      case ACTION_DELETE_TO_LINE_START:
      case ACTION_DELETE_WHITE_SPACE:
      case ACTION_DUPLICATE_LINE:
       {
        actionAvailable = element != null &&
                          !element.show() &&
                          !_view.readonly() &&
                          !_view.markList().protect(element);
        break;
       }
      case ACTION_EXEC_COMMAND:
       {
        actionAvailable = element != null;
        break;
       }
      case ACTION_EXCLUDE_SELECTION:
      case ACTION_FILTER_SELECTION:
       {
        actionAvailable = Block.view() == _view &&
                          Block.anythingSelected();
        break;
       }
      case ACTION_FIND_AND_REPLACE:
       {
        actionAvailable = !_view.readonly();
        break;
       }
      case ACTION_FIND_AND_REPLACE_NEXT:
      case ACTION_FIND_AND_REPLACE_UP:
       {
        String findText = FindTextCommand.findTextParameter().currentValue(_view);
        actionAvailable = findText != null &&
                          findText.length() != 0 &&
                          !_view.readonly();
        break;
       }
      case ACTION_FIND_BLOCK_END:
      case ACTION_FIND_BLOCK_START:
       {
        actionAvailable = Block.view() == _view &&
                          Block.anythingSelected();
        break;
       }
      case ACTION_FIND_LAST_CHANGE:
       {
        actionAvailable = document.undo().jumpAvailable();
        break;
       }
      case ACTION_FIND_MARK:
       {
        actionAvailable = _view.markList().namedMarks();
        break;
       }
      case ACTION_FIND_NEXT:
       {
        String findText = FindTextCommand.findTextParameter().currentValue(_view);
        actionAvailable = findText != null &&
                          findText.length() != 0;
        break;
       }
      case ACTION_FIND_QUICK_MARK:
       {
        actionAvailable = _view.markList().find("@QUICK") != null;
        break;
       }
      case ACTION_FIND_SELECTION:
       {
        actionAvailable = Block.view() == _view &&
                          Block.anythingSelected();
        break;
       }
      case ACTION_FIND_UP:
       {
        String findText = FindTextCommand.findTextParameter().currentValue(_view);
        actionAvailable = findText != null &&
                          findText.length() != 0;
        break;
       }
      case ACTION_GET:
       {
        actionAvailable = !_view.readonly();
        if (actionAvailable && element != null)
         {
          if (element.show())
           {
            if (_view.markList().insertElementProtect(element))
             {
              actionAvailable = false;
             }
           }
          else if (_view.markList().protect(element))
           {
            actionAvailable = false;
           }
         }
        break;
       }
      case ACTION_HEX_EDIT_LINE:
       {
        actionAvailable = element != null;
        break;
       }
      case ACTION_INDENT_TEXT:
      case ACTION_INSERT_FILE_NAME:
      case ACTION_INSERT_LEFT_BRACE:
      case ACTION_INSERT_NOT:
      case ACTION_INSERT_RIGHT_BRACE:
      case ACTION_INSERT_TAB:
       {
        actionAvailable = element != null &&
                          !element.show() &&
                          !_view.readonly() &&
                          !_view.markList().protect(element);
        break;
       }
      case ACTION_JOIN:
       {
        Element element2 = (element != null)? (element.nextVisibleNonShow(_view)) : null;
        actionAvailable = element != null &&
                          element2 != null &&
                          !_view.readonly() &&
                          !element.show() &&
                          !element2.show() &&
                          !_view.markList().protect(element) &&
                          !_view.markList().protect(element2);
        break;
       }
      case ACTION_KEY_RECORDER_PLAY:
       {
        actionAvailable = !KeyRecorder.keyRecorder().recording() &&
                          KeyRecorder.keyRecorder().anythingRecorded();
        break;
       }
      case ACTION_KEY_RECORDER_START:
       {
        actionAvailable = !KeyRecorder.keyRecorder().recording();
        break;
       }
      case ACTION_KEY_RECORDER_STOP:
       {
        actionAvailable = KeyRecorder.keyRecorder().recording();
        break;
       }
      case ACTION_KILL_LINE:
       {
        actionAvailable = element != null &&
                          !element.show() &&
                          !_view.readonly() &&
                          !_view.markList().protect(element);
        break;
       }
      case ACTION_KILL_REGION:
      case ACTION_LOWER_CASE_REGION:
       {
        actionAvailable = !_view.readonly() &&
                          element != null &&
                          _view.markList().find("@QUICK") != null;
        break;
       }
      case ACTION_LOWER_CASE_WORD:
       {
        actionAvailable = !_view.readonly() &&
                          element != null;
        break;
       }
      case ACTION_NEW_LINE:
       {
        actionAvailable = element != null &&
                          element.next() != null;
        break;
       }
      case ACTION_ONE_SPACE:
       {
        actionAvailable = element != null &&
                          !element.show() &&
                          !_view.readonly() &&
                          !_view.markList().protect(element);
        break;
       }
      case ACTION_OPEN_LINE:
      case ACTION_PASTE:
      case ACTION_ECLIPSE_PASTE:
       {
        actionAvailable = element != null &&
                          !_view.readonly() &&
                          !_view.markList().insertElementProtect(element);
        break;
       }
      case ACTION_PRINT:
      case ACTION_ECLIPSE_PRINT:
       {
        // see org.eclipse.jface.text.TextViewer.java/isPrintable();  initially
        // LPEX was always returning true, as it brings up the PrintDialog, which
        // can (in theory) also redirect to a file, but it turns out that on platforms
        // where printing is not supported there is no such dialog, therefore this
        // appears to be the only way to enable/disable the print menu/toolbar items...
        PrinterData[] printerList = Printer.getPrinterList();
        actionAvailable = printerList != null && printerList.length > 0;
        break;
       }
      case ACTION_REDO:
      case ACTION_ECLIPSE_REDO:
       {
        actionAvailable = document.undo().redoAvailable() &&
                          !_view.readonly();
        break;
       }
      case ACTION_RELOAD:
       {
        actionAvailable = document.name() != null &&
                          document.name().length() > 0;
        break;
       }
      case ACTION_SHOW_ALL:
       {
        actionAvailable = _view.includedClasses() != Classes.ALL ||
                          _view.excludedClasses() != Classes.NONE;
        break;
       }
      case ACTION_SPLIT:
      case ACTION_SPLIT_AND_SHIFT:
      case ACTION_SPLIT_LINE:
       {
        actionAvailable = element != null &&
                          !_view.readonly() &&
                          !_view.markList().insertElementProtect(element);
        break;
       }
      case ACTION_TEXT_WINDOW:
       {
        actionAvailable = _view.window() != null;
        break;
       }
      case ACTION_TRANSPOSE_CHARACTERS:
       {
        actionAvailable = element != null &&
                          !element.show() &&
                          !_view.readonly() &&
                          !_view.markList().protect(element);
        break;
       }
      case ACTION_TRANSPOSE_LINES:
      case ACTION_TRANSPOSE_WORDS:
       {
        actionAvailable = element != null &&
                          !_view.readonly();
        break;
       }
      case ACTION_TRUNCATE:
       {
        actionAvailable = element != null &&
                          !element.show() &&
                          !_view.readonly() &&
                          !_view.markList().protect(element);
        break;
       }
      case ACTION_UNDO:
      case ACTION_ECLIPSE_UNDO:
       {
        actionAvailable = document.undo().undoAvailable() &&
                          !_view.readonly();
        break;
       }
      case ACTION_UPPER_CASE_REGION:
       {
        actionAvailable = !_view.readonly() &&
                          element != null &&
                          _view.markList().find("@QUICK") != null;
        break;
       }
      case ACTION_UPPER_CASE_WORD:
       {
        actionAvailable = !_view.readonly() &&
                          element != null;
        break;
       }
      case ACTION_YANK:
       {
        actionAvailable = !_view.readonly() &&
                          KillRing.killStringAvailable();
        break;
       }
      case ACTION_YANK_PREVIOUS:
       {
        actionAvailable = !_view.readonly() &&
                          KillRing.killStringAvailable() &&
                          document.undo().lastChangeWasYank();
        break;
       }

      // ACTION_ECLIPSE_SHIFT_RIGHT
      // ACTION_ECLIPSE_SHIFT_LEFT
      // ACTION_ECLIPSE_PREFIX
      // ACTION_ECLIPSE_STRIP_PREFIX
      default:
       {
        break;
       }
     }
    return actionAvailable;
   }

  /**
   * @see #doActionIfAvailable
   */
  void doAction(int id)
   {
    Action userAction = _actionList.find(id);
    if (userAction != null)
     {
      userAction.lpexAction().doAction(_view.lpexView());
     }
    else
     {
      doDefaultAction(id);
     }
   }

  /**
   * Like doaction(), but user-defined actions are only run if they are
   * available (no such protection seems necessary for LPEX's built-in actions).
   * This protects from running non-available actions with the <b>action</b>
   * command (normally only issued from the LPEX command line), or by pressing
   * the (menu accelerator) key to which the action is assigned (note that the
   * menu items are already automatically disabled when their associated action
   * is not available).
   *
   * @see #doAction
   * @see com.ibm.lpex.core.ActionCommand
   */
  void doActionIfAvailable(int id)
   {
    Action userAction = _actionList.find(id);
    if (userAction != null)
     {
      if (userAction.lpexAction().available(_view.lpexView()))
       {
        userAction.lpexAction().doAction(_view.lpexView());
       }
     }
    else
     {
      doDefaultAction(id);
     }
   }

  void doDefaultAction(int id)
   {
    Document document = _view.document();
    Element element = _view.documentPosition().element();
    int position = _view.documentPosition().position();
    int repeat = repeat();
    boolean reverse = repeat < 0;
    if (reverse)
     {
      repeat = -repeat;
     }

    switch(id)
     {
      // // Action "eclipseDelete":  try to emulate a simple "Delete" key sent
      // // to LpexView.  Eclipse's desktop takes over the "Delete"/"Del" keys,
      // // and sends them as "Delete" action to the text widget.  LPEX attempts
      // // to process them depending on the current focus (text area, command
      // // line, etc.) and, whenever possible, its current keyActions.
      // // Note: above not done as of Eclipse driver 0.043, so this not needed:
      // // ACTION_ECLIPSE_DELETE is restored to a regular ACTION_DELETE...
      // case ACTION_ECLIPSE_DELETE: {
      //  if (_view.window() == null)
      //   break;
      //  // (a) text window - emulate key to ensure it gets recorded, etc.
      //  Control textWindow = _view.window().textWindow();
      //  if (textWindow.isFocusControl()) {
      //   Event e = new Event();
      //   e.widget = textWindow;
      //   e.character = SWT.DEL;
      //   //e.keyCode   = 0;
      //   //e.stateMask = 0;
      //   ((TextWindow)textWindow).processKeyEvent(new KeyEvent(e));
      //   return;
      //   }
      //  // (b) somewhere in the command line - pass it on
      //  ((CommandLine)_view.window().commandLine()).deleteKey();
      //  break;
      //  }

      case ACTION_APPEND_TO_ACTION_ARGUMENT:
       {
        if (_currentKey != null &&
            _currentKey.keyChar() != CHAR_UNDEFINED)
         {
          appendToArgument(_currentKey.keyChar());
         }
        break;
       }
      case ACTION_BACK_SPACE:
       {
        if (repeat > 1)
         {
          document.resetUserActionElements();
         }
        if (!reverse)
         {
          String deleteText = _view.backSpace(repeat);
          if (deleteText.length() > 1)
           {
            KillRing.prefaceKillString(_view, deleteText);
           }
         }
        else
         {
          String deleteText = _view.delete(repeat);
          if (deleteText.length() > 1)
           {
            KillRing.appendKillString(_view, deleteText);
           }
         }
        break;
       }
      case ACTION_BLOCK_COPY:
       {
        if (!reverse && element != null && _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            Block.copy(_view);
           }
         }
        break;
       }
      case ACTION_BLOCK_DELETE:
       {
        if (Block.view() == _view && _view.changeAllowed())
         {
          Block.delete();
         }
        break;
       }
      case ACTION_BLOCK_FILL:
       {
        if (Block.view() == _view &&
            Block.anythingUnprotectedSelected() && _view.changeAllowed())
         {
          String label = LpexResources.message(MSG_COMMANDLINE_FILL_CHARACTER);
          InputCommand.doCommand(_view,
            LpexStringTokenizer.addQuotes(label) + " " +
            LpexStringTokenizer.addQuotes("block fill "));
         }
        break;
       }
      case ACTION_BLOCK_LOWER_CASE:
       {
        if (Block.view() == _view && _view.changeAllowed())
         {
          Block.lowerCase();
         }
        break;
       }
      case ACTION_BLOCK_MARK_ALL:
      case ACTION_ECLIPSE_SELECT_ALL:
       {
        Block.clear();
        _view.documentPosition().top();
        Block.set(Block.CHARACTER, _view);
        _view.documentPosition().bottom();
        Block.set(Block.CHARACTER, _view);
        break;
       }
      case ACTION_BLOCK_MARK_BOTTOM:
       {
        Block.set(_view);
        _view.documentPosition().bottom();
        Block.set(_view);
        break;
       }
      case ACTION_BLOCK_MARK_CHARACTER:
       {
        Block.set(Block.CHARACTER, _view);
        break;
       }
      case ACTION_BLOCK_MARK_DOWN:
       {
        Block.set(_view);
        for (int i = 0; i < repeat; i++)
         {
          if (!reverse)
           {
            _view.documentPosition().down();
           }
          else
           {
            _view.documentPosition().up();
           }
          Block.set(_view);
         }
        break;
       }
      case ACTION_BLOCK_MARK_ELEMENT:
       {
        Block.set(Block.ELEMENT, _view);
        break;
       }
      case ACTION_BLOCK_MARK_ELEMENT_AT_MOUSE:
       {
        Block.clear();
        setDocumentPosition(currentMousePoint());
        Block.set(Block.ELEMENT, _view);
        break;
       }
      case ACTION_BLOCK_MARK_END:
       {
        Block.set(_view);
        _view.documentPosition().end();
        Block.set(_view);
        break;
       }
      case ACTION_BLOCK_MARK_HOME:
       {
        Block.set(_view);
        _view.documentPosition().home();
        Block.set(_view);
        break;
       }
      case ACTION_BLOCK_MARK_LEFT:
       {
        _view.selectCharacter(repeat, reverse);
        break;
       }
      case ACTION_BLOCK_MARK_NEXT_WORD:
       {
        _view.selectWord(repeat, !reverse);
        break;
       }
      case ACTION_BLOCK_MARK_PAGE_DOWN:
       {
        Block.set(_view);
        for (int i = 0; i < repeat; i++)
         {
          if (reverse)
           {
            _view.documentPosition().pageUp();
           }
          else
           {
            _view.documentPosition().pageDown();
           }
          Block.set(_view);
         }
        break;
       }
      case ACTION_BLOCK_MARK_PAGE_LEFT:
       {
        if (element != null)
         {
          if (Block.type() == Block.ELEMENT || Block.view() != _view)
           {
            Block.clear();
           }
          if (Block.type() == Block.NONE &&
              BlockCommand.DefaultTypeParameter.getParameter().currentValue(_view) ==
                Block.ELEMENT)
           {
            Block.set(Block.STREAM, _view);
           }
          else
           {
            Block.set(_view);
           }
          for (int i = 0; i < repeat; i++)
           {
            if (!reverse)
             {
              //_view.documentPosition().pageLeft();
              _view.documentPosition().positionPageLeft();
             }
            else
             {
              //_view.documentPosition().pageRight();
              _view.documentPosition().positionPageRight();
             }
            Block.set(_view);
           }
         }
        break;
       }
      case ACTION_BLOCK_MARK_PAGE_RIGHT:
       {
        if (element != null)
         {
          if (Block.type() == Block.ELEMENT || Block.view() != _view)
           {
            Block.clear();
           }
          if (Block.type() == Block.NONE &&
              BlockCommand.DefaultTypeParameter.getParameter().currentValue(_view) ==
                Block.ELEMENT)
           {
            Block.set(Block.STREAM, _view);
           }
          else
           {
            Block.set(_view);
           }
          for (int i = 0; i < repeat; i++)
           {
            if (reverse)
             {
              //_view.documentPosition().pageLeft();
              _view.documentPosition().positionPageLeft();
             }
            else
             {
              //_view.documentPosition().pageRight();
              _view.documentPosition().positionPageRight();
             }
            Block.set(_view);
           }
         }
        break;
       }
      case ACTION_BLOCK_MARK_PAGE_UP:
       {
        Block.set(_view);
        for (int i = 0; i < repeat; i++)
         {
          if (!reverse)
           {
            _view.documentPosition().pageUp();
           }
          else
           {
            _view.documentPosition().pageDown();
           }
          Block.set(_view);
         }
        break;
       }
      case ACTION_BLOCK_MARK_PREV_WORD:
       {
        _view.selectWord(repeat, reverse);
        break;
       }
      case ACTION_BLOCK_MARK_RECTANGLE:
       {
        Block.set(Block.RECTANGLE, _view);
        break;
       }
      case ACTION_BLOCK_MARK_RECTANGLE_AT_MOUSE:
       {
        Block.clear();
        setDocumentPosition(currentMousePoint());
        Block.set(Block.RECTANGLE, _view);
        break;
       }
      case ACTION_BLOCK_MARK_RIGHT:
       {
        _view.selectCharacter(repeat, !reverse);
        break;
       }
      case ACTION_BLOCK_MARK_TO_MOUSE:
       {
        Block.set(_view);
        setDocumentPosition(currentMousePoint());
        Block.set(_view);
        break;
       }
      case ACTION_BLOCK_MARK_TOP:
       {
        Block.set(_view);
        _view.documentPosition().top();
        Block.set(_view);
        break;
       }
      case ACTION_BLOCK_MARK_UP:
       {
        Block.set(_view);
        for (int i = 0; i < repeat; i++)
         {
          if (!reverse)
           {
            _view.documentPosition().up();
           }
          else
           {
            _view.documentPosition().down();
           }
          Block.set(_view);
         }
        break;
       }
      case ACTION_BLOCK_MARK_WORD:
       {
        Block.clear();
        _view.documentPosition().right();
        _view.documentPosition().prevWord();
        if (BlockCommand.DefaultTypeParameter.getParameter().currentValue(_view) ==
              Block.ELEMENT)
         {
          Block.set(Block.STREAM, _view);
         }
        else
         {
          Block.set(_view);
         }
        if (Block.type() == Block.STREAM)
         {
          _view.documentPosition().nextWordEnd(1);
         }
        else
         {
          _view.documentPosition().nextWordEnd();
         }
        Block.set(_view);

        if (_view.documentPosition().above(element, position) ||
            (Block.type() == Block.STREAM &&
             _view.documentPosition().equals(element, position)))
         {
          Block.clear();
          _view.documentPosition().jump(element, position);
         }
        break;
       }
      case ACTION_BLOCK_MARK_WORD_AT_MOUSE:
       {
        setDocumentPosition(currentMousePoint());
        doAction(ACTION_BLOCK_MARK_WORD);
        break;
       }
      case ACTION_BLOCK_MOVE:
       {
        if (element != null && _view.changeAllowed())
         {
          Block.move(_view);
         }
        break;
       }
      case ACTION_BLOCK_OVERLAY:
       {
        if (element != null && _view.changeAllowed())
         {
          Block.overlay(_view);
         }
        break;
       }
      case ACTION_BLOCK_SHIFT_LEFT:
       {
        BlockCommand.doCommand(_view, "shift left " + repeat());
        break;
       }
      case ACTION_BLOCK_SHIFT_RIGHT:
       {
        BlockCommand.doCommand(_view, "shift right " + repeat());
        break;
       }
      case ACTION_BLOCK_UNMARK:
       {
        if (Block.view() == _view)
         {
          Block.clear();
         }
        break;
       }
      case ACTION_BLOCK_UPPER_CASE:
       {
        if (Block.view() == _view && _view.changeAllowed())
         {
          Block.upperCase();
         }
        break;
       }
      case ACTION_BOTTOM:
       {
        doDefaultAction(ACTION_SET_QUICK_MARK);
        _view.documentPosition().documentBottom(); // bottom of complete document
        break;
       }
      case ACTION_CAPITALIZE_WORD:
       {
        if (element != null && _view.changeAllowed())
         {
          document.resetUserActionElements();
          if (!reverse)
           {
            boolean moveToNextWord = true;
            if (!element.show())
             {
              String text = element.text();
              if (position >= 1 && position <= text.length())
               {
                char c = text.charAt(position - 1);
                if (c != ' ' && c != '\t')
                 {
                  moveToNextWord = false;
                 }
               }
             }
            if (moveToNextWord)
             {
              if (!_view.documentPosition().nextWord())
               {
                repeat = 0;
               }
             }
           }
          for (int i = 0; i < repeat; i++)
           {
            if (reverse)
             {
              if (_view.documentPosition().prevWord())
               {
                _view.changeCase(1, true);
               }
              else
               {
                repeat = 0;
               }
             }
            else
             {
              _view.changeCase(1, true);
              if (!_view.documentPosition().nextWord())
               {
                repeat = 0;
               }
             }
           }
         }
        break;
       }
      case ACTION_CLEAR_PREFIX:
       {
        for (element = document.elementList().first();
             element != null;
             element = element.next())
         {
          element.elementView(_view).setPrefixText(null);
         }
        break;
       }
      case ACTION_COMMAND_LINE:
       {
        if (!_view.vi() && _view.window() != null)
         {
          CommandLine commandLine = (CommandLine)_view.window().commandLine();
          commandLine.setForceVisible(true);
          commandLine.setMode(CommandLine.MODE_COMMANDS);
          _view.window().commandLineRequestFocus();
         }
        break;
       }
      case ACTION_COMPARE:
       {
        CompareCommand.doCommand(_view, "prompt");
        break;
       }
      case ACTION_COMPARE_CLEAR:
       {
        CompareCommand.doCommand(_view, "clear");
        break;
       }
      case ACTION_COMPARE_NEXT:
       {
        for (int i = 0; i < repeat; i++)
         {
          CompareCommand.doCommand(_view, reverse? "previous" : "next");
         }
        break;
       }
      case ACTION_COMPARE_PREVIOUS:
       {
        for (int i = 0; i < repeat; i++)
         {
          CompareCommand.doCommand(_view, reverse? "next" : "previous");
         }
        break;
       }
      case ACTION_COMPARE_REFRESH:
       {
        CompareCommand.doCommand(_view, "refresh");
        break;
       }
      case ACTION_COPY:
      case ACTION_ECLIPSE_COPY:
       {
        if (Block.view() == _view)
         {
          Block.copyToClipboard();
         }
        break;
       }
      case ACTION_CURSOR_TO_MOUSE:
       {
        setDocumentPosition(currentMousePoint());
        break;
       }
      case ACTION_CUT:
      case ACTION_ECLIPSE_CUT:
       {
        if (Block.view() == _view && _view.changeAllowed())
         {
          Block.cutToClipboard();
         }
        break;
       }
      case ACTION_DELETE:
      case ACTION_ECLIPSE_DELETE:
       {
        if (repeat > 1)
         {
          document.resetUserActionElements();
         }
        if (repeat > 0)
         {
          String deleteText = _view.delete(repeat);
          if (deleteText.length() > 1)
           {
            KillRing.appendKillString(_view, deleteText);
           }
         }
        else
         {
          String deleteText = _view.backSpace(-repeat);
          if (deleteText.length() > 1)
           {
            KillRing.prefaceKillString(_view, deleteText);
           }
         }
        break;
       }
      case ACTION_DELETE_BLANK_LINES:
       {
        if (element != null && _view.changeAllowed())
         {
          boolean solitaryBlankLine = false;
          if (!element.show() && element.text().trim().length() == 0)
           {
            solitaryBlankLine = true;
            Element prevElement = element.prevVisibleNonShow(_view);
            while (prevElement != null && prevElement.text().trim().length() == 0 &&
                   !_view.markList().protect(prevElement))
             {
              solitaryBlankLine = false;
              _view.deleteElement(prevElement);
              prevElement = element.prevVisibleNonShow(_view);
             }
           }
          Element nextElement = element.nextVisibleNonShow(_view);
          while (nextElement != null && nextElement.text().trim().length() == 0 &&
                 !_view.markList().protect(nextElement))
           {
            solitaryBlankLine = false;
            _view.deleteElement(nextElement);
            nextElement = element.nextVisibleNonShow(_view);
           }
          if (solitaryBlankLine && !_view.markList().protect(element))
           {
            _view.deleteElement(element);
           }
         }
        break;
       }
      case ACTION_DELETE_LINE:
       {
        if (!reverse)
         {
          String deleteText = "";
          for (int i = 0; i < repeat; i++)
           {
            element = _view.documentPosition().element();
            position = _view.documentPosition().position();
            if (element != null && (element.show() || _view.changeAllowed()))
             {
              if (!element.show())
               {
                deleteText += "\n" + element.text();
               }
              _view.deleteElement(element);
             }
           }
          KillRing.appendKillString(_view, deleteText);
         }
        break;
       }
      case ACTION_DELETE_NEXT_WORD:
       {
        if (element != null && _view.changeAllowed())
         {
          document.resetUserActionElements();
          if (element.show())
           {
            if (reverse)
             {
              element = element.prevVisibleNonShow(_view);
              if (element != null)
               {
                position = element.end();
               }
             }
            else
             {
              element = element.nextVisibleNonShow(_view);
              position = 1;
             }
            _view.documentPosition().jump(element, position);
           }
          for (int i = 0; i < repeat; i++)
           {
            if (reverse)
             {
              if (!_view.documentPosition().prevWord())
               {
                repeat = 0;
               }
             }
            else
             {
              if (!_view.documentPosition().nextWordEnd(1))
               {
                repeat = 0;
               }
             }
           }
          String deleteText = _view.deleteText(element, position,
                                               _view.documentPosition().element(),
                                               _view.documentPosition().position());
          if (reverse)
           {
            KillRing.prefaceKillString(_view, deleteText);
           }
          else
           {
            KillRing.appendKillString(_view, deleteText);
           }
         }
        break;
       }
      case ACTION_DELETE_PREV_WORD:
       {
        if (element != null && _view.changeAllowed())
         {
          document.resetUserActionElements();
          if (element.show())
           {
            if (!reverse)
             {
              element = element.prevVisibleNonShow(_view);
              if (element != null)
               {
                position = element.end();
               }
             }
            else
             {
              element = element.nextVisibleNonShow(_view);
              position = 1;
             }
            _view.documentPosition().jump(element, position);
           }
          for (int i = 0; i < repeat; i++)
           {
            if (!reverse)
             {
              if (!_view.documentPosition().prevWord())
               {
                repeat = 0;
               }
             }
            else
             {
              if (!_view.documentPosition().nextWordEnd(1))
               {
                repeat = 0;
               }
             }
           }
          String deleteText = _view.deleteText(element, position,
                                               _view.documentPosition().element(),
                                               _view.documentPosition().position());
          if (!reverse)
           {
            KillRing.prefaceKillString(_view, deleteText);
           }
          else
           {
            KillRing.appendKillString(_view, deleteText);
           }
         }
        break;
       }
      case ACTION_DELETE_TO_LINE_START:
       {
        if (element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          String deleteText = null;
          if (position > 1 && element.text().length() >= position)
           {
            deleteText = _view.deleteText(element, 1, position - 1);
           }
          KillRing.prefaceKillString(_view, deleteText);
         }
        break;
       }

      case ACTION_DELETE_WHITE_SPACE:
       {
        if (element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          String text = element.text();
          if (text.length() > 0)
           {
            if (position > text.length())
             {
              position = text.length() + 1;
              _view.documentPosition().end();
             }

            while (position > 1)
             {
              char c = text.charAt(position - 2);
              if (c != ' ' && c != '\t')
               {
                break;
               }
              position--;
             }

            int len = 0;
            while (position + len <= text.length())
             {
              char c = text.charAt(position + len - 1);
              if (c != ' ' && c != '\t')
               {
                break;
               }
              len++;
             }

            if (len > 0)
             {
              _view.deleteText(element, position, len);
             }
           }
         }
        break;
       }

      case ACTION_DOWN:
       {
        if (reverse)
         {
          _view.documentPosition().up(repeat);
         }
        else
         {
          _view.documentPosition().down(repeat);
         }
        break;
       }
      case ACTION_DUPLICATE_LINE:
       {
        if (element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          String text = element.text();
          text = "\n" + text;
          _view.documentPosition().end();
          _view.setIgnoreFields();
          for (int i = 0; i < repeat; i++)
           {
            _view.insertText(text);
           }
          _view.resetIgnoreFields();
         }
        break;
       }
      case ACTION_END:
       {
        _view.documentPosition().end();
        break;
       }
      case ACTION_EXCLUDE_SELECTION:
       {
        String findText = Block.selectedText();
        if (findText != null)
         {
          int index = findText.indexOf("\n");
          if (index != -1)
           {
            findText = findText.substring(0, index);
           }
          if (findText.length() != 0)
           {
            FindTextCommand.FindTextParameter p = FindTextCommand.findTextParameter();
            String oldValue = p.value(_view);
            p.setValue(_view, findText);
            FindTextCommand.doCommand(_view, "exclude all");
            p.setValue(_view, oldValue);
           }
         }
        break;
       }
      case ACTION_EXEC_COMMAND:
       {
        if (element != null)
         {
          String text = element.text();
          if (text.length() != 0)
           {
            _view.commandHandler().doCommand(text);
           }
         }
        break;
       }
      case ACTION_EXPAND_HIDE_AT_MOUSE:
       {
        if (_view.screen().inTopExpandHideHeader(currentMousePoint()))
         {
          _view.setTopExpanded(!_view.topExpanded());
          _view.documentPosition().top();
         }
        else
         {
          setDocumentPosition(currentMousePoint());
          element = _view.documentPosition().element();
          if (element != null)
           {
            ElementView elementView = element.elementView(_view);
            if (elementView.expandHideHeader())
             {
              elementView.setExpanded(!elementView.expanded());
             }
           }
         }
        break;
       }
      case ACTION_FILTER_SELECTION:
       {
        String findText = Block.selectedText();
        if (findText != null)
         {
          int index = findText.indexOf("\n");
          if (index != -1)
           {
            findText = findText.substring(0, index);
           }
          if (findText.length() != 0)
           {
            FindTextCommand.FindTextParameter p = FindTextCommand.findTextParameter();
            if (p.value(_view) == null)
             {
              p.setDefaultValue(findText);
             }
            else
             {
              p.setValue(_view, findText);
             }
            FindTextCommand.doCommand(_view, "all");
           }
         }
        break;
       }
      case ACTION_FIND:
       {
        if (_view.window() != null)
         {
          CommandLine commandLine = (CommandLine)_view.window().commandLine();
          // if already in MODE_FIND, stay there & do a find next
          if (commandLine.getMode() == CommandLine.MODE_FIND)
           {
            String findText = FindTextCommand.findTextParameter().currentValue(_view);
            if (findText != null && findText.length() != 0)
             {
              FindTextCommand.doCommand(_view, "");
             }
           }
          else
           {
            commandLine.setForceVisible(true);
            commandLine.setMode(CommandLine.MODE_FIND);
            _view.window().commandLineRequestFocus();
           }
         }
        break;
       }
      case ACTION_FIND_AND_REPLACE:
       {
        if (_view.window() != null && !_view.readonly())
         {
          CommandLine commandLine = (CommandLine)_view.window().commandLine();
          // if already in MODE_FIND_AND_REPLACE, stay there & do a find next
          if (commandLine.getMode() == CommandLine.MODE_FIND_AND_REPLACE)
           {
            String findText = FindTextCommand.findTextParameter().currentValue(_view);
            if (findText != null && findText.length() != 0)
             {
              FindTextCommand.doCommand(_view, "");
             }
           }
          else
           {
            commandLine.setForceVisible(true);
            commandLine.setMode(CommandLine.MODE_FIND_AND_REPLACE);
            _view.window().commandLineRequestFocus();
           }
         }
        break;
       }
      case ACTION_FIND_AND_REPLACE_NEXT:
       {
        String findText = FindTextCommand.findTextParameter().currentValue(_view);
        if (findText != null && findText.length() != 0 && _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            FindTextCommand.doCommand(_view, reverse? "replace up" : "checkStart replace");
           }
         }
        break;
       }
      case ACTION_FIND_AND_REPLACE_UP:
       {
        String findText = FindTextCommand.findTextParameter().currentValue(_view);
        if (findText != null && findText.length() != 0 && _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            FindTextCommand.doCommand(_view, reverse? "checkStart replace" : "replace up");
           }
         }
        break;
       }
      case ACTION_FIND_BLOCK_END:
       {
        _view.setInPrefix(false); // if in prefix area, move cursor to text area
        _view.documentPosition().blockBottom();
        if (_view.window() != null)
         {
          _view.window().textWindowRequestFocus();
         }
        break;
       }
      case ACTION_FIND_BLOCK_START:
       {
        _view.setInPrefix(false); // if in prefix area, move cursor to text area
        _view.documentPosition().blockTop();
        if (_view.window() != null)
         {
          _view.window().textWindowRequestFocus();
         }
        break;
       }
      case ACTION_FIND_LAST_CHANGE:
       {
        _view.setInPrefix(false); // if in prefix area, move cursor to text area
        document.undo().jump(_view);
        if (_view.window() != null)
         {
          _view.window().textWindowRequestFocus();
         }
        break;
       }
      case ACTION_FIND_MARK:
       {
        if (_view.window() != null)
         {
          CommandLine commandLine = (CommandLine)_view.window().commandLine();
          commandLine.setForceVisible(true);
          commandLine.setMode(CommandLine.MODE_FIND_MARK);
          _view.window().commandLineRequestFocus();
         }
        break;
       }
      case ACTION_FIND_NEXT:
       {
        String findText = FindTextCommand.findTextParameter().currentValue(_view);
        if (findText != null && findText.length() != 0)
         {
          for (int i = 0; i < repeat; i++)
           {
            FindTextCommand.doCommand(_view, reverse? "up" : "");
           }
         }
        break;
       }
      case ACTION_FIND_QUICK_MARK:
       {
        _view.setInPrefix(false); // if in prefix area, move cursor to text area
        DocumentPosition.Preserve preservedPosition1 = _view.documentPosition().preserve();
        LocateCommand.doCommand(_view, "mark @QUICK");
        DocumentPosition.Preserve preservedPosition2 = _view.documentPosition().preserve();
        preservedPosition1.restore();
        doDefaultAction(ACTION_SET_QUICK_MARK);
        preservedPosition2.restore();
        _view.documentPosition().disposePreserve(preservedPosition1);
        _view.documentPosition().disposePreserve(preservedPosition2);
        if (_view.window() != null)
         {
          _view.window().textWindowRequestFocus();
         }
        break;
       }
      case ACTION_FIND_SELECTION:
       {
        String findText = Block.selectedText();
        if (findText != null)
         {
          int index = findText.indexOf("\n");
          if (index != -1)
           {
            findText = findText.substring(0, index);
           }
          if (findText.length() != 0)
           {
            FindTextCommand.FindTextParameter p = FindTextCommand.findTextParameter();
            if (p.value(_view) == null)
             {
              p.setDefaultValue(findText);
             }
            else
             {
              p.setValue(_view, findText);
             }
            for (int i = 0; i < repeat; i++)
             {
              FindTextCommand.doCommand(_view, reverse? "up" : "");
             }
           }
         }
        break;
       }
      case ACTION_FIND_UP:
       {
        String findText = FindTextCommand.findTextParameter().currentValue(_view);
        if (findText != null && findText.length() != 0)
         {
          for (int i = 0; i < repeat; i++)
           {
            FindTextCommand.doCommand(_view, reverse? "" : "up");
           }
         }
        break;
       }
      case ACTION_GET:
       {
        boolean actionAvailable = true;
        if (element != null)
         {
          if (element.show())
           {
            if (_view.markList().insertElementProtect(element))
             {
              actionAvailable = false;
             }
           }
          else if (_view.markList().protect(element))
           {
            actionAvailable = false;
           }
         }
        if (actionAvailable && _view.changeAllowed())
         {
          GetCommand.doCommand(_view, "prompt " +
                               LpexStringTokenizer.addQuotes(_view.document().name()));
         }
        break;
       }
      case ACTION_HELP:
       {
        LpexParser lpexParser = _view.parsePendingList().lpexParser();
        String helpPage=null;
        if (lpexParser != null)
         {
          helpPage = lpexParser.getHelpPage();
         }
        if (helpPage==null)
          helpPage = _view.lpexView().defaultHelp();
        HelpCommand.displayURL(helpPage, _view);
        break;
       }
      case ACTION_HEX_EDIT_LINE:
       {
        if (_view.lpexView().frame() != null)
         {
          new EditLine(_view.lpexView());
         }
        break;
       }
      case ACTION_HOME:
       {
        _view.setInPrefix(false);
        _view.documentPosition().home();
        break;
       }

      case ACTION_INDENT_TEXT:
       {
        if (element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          // calculate desired indent position according to line above
          int indentPosition = 1;
          Element prevElement = element.prevNonShow();
          while (prevElement != null)
           {
            String p = prevElement.text();
            if ((p.trim()).length() > 0)  // found a previous non-blank line
             {
              int i = 0;
              while (p.charAt(i) == ' ' || p.charAt(i) == '\t') { i++; }
              // text cursor column -> display cursor column
              indentPosition = _view.displayColumn(prevElement.elementView(_view), i+1);
              break;
             }
            prevElement = prevElement.prevNonShow();
           }

          // if not at the right indent already, reposition current line's text
          indentPosition--;
          String t = element.text();
          int i = 0;
          while (i < t.length() && (t.charAt(i)==' ' || t.charAt(i)=='\t')) { i++; }
          if (indentPosition != i)  // current line's indent is different
           {
            int savedDisplayPosition = _view.displayColumn(element.elementView(_view), position);

            if (i > 0)
             {
              _view.deleteText(element, 1, i);
             }
            if (indentPosition > 0)
             {
              StringBuffer indentString = new StringBuffer(indentPosition);
              for (; indentPosition > 0; indentPosition--)
               {
                indentString.append(' ');
               }
              _view.insertText(element, 1, indentString.toString());
             }

            position = _view.positionFromDisplayPosition(element.elementView(_view),
                                                         savedDisplayPosition);
            _view.documentPosition().jump(element, position);
           }
         }
        break;
       }

      case ACTION_INSERT_FILE_NAME:
       {
        if (!reverse)
         {
          String text = document.name();
          if (element != null && !element.show() &&
              !_view.markList().protect(element) &&
              text != null && text.length() > 0 && _view.changeAllowed())
           {
            for (int i = 0; i < repeat; i++)
             {
              _view.insertText(text);
             }
           }
         }
        break;
       }
      case ACTION_INSERT_LEFT_BRACE:
       {
        if (!reverse && element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            _view.insertText("\u007b");
           }
         }
        break;
       }
      case ACTION_INSERT_NOT:
       {
        if (!reverse && element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            _view.insertText("\u00ac");
           }
         }
        break;
       }
      case ACTION_INSERT_RIGHT_BRACE:
       {
        if (!reverse && element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            _view.insertText("\u007d");
           }
         }
        break;
       }
      case ACTION_INSERT_TAB:
       {
        if (!reverse && element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            _view.insertText("\u0009");
           }
         }
        break;
       }

      case ACTION_INSERT_TO_TAB:
       {
        if (_view.insertMode() && element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          int displayPosition =
              _view.displayColumnForTabs(element.elementView(_view), position);
          TabsParameter.Settings tabs = TabsParameter.getParameter().currentValue(_view);
          int tabStop = 1;
          if (tabs._tabStops != null)
           {
            int i = 0;
            while (tabStop <= displayPosition && i < tabs._tabStops.length)
             {
              tabStop = tabs._tabStops[i];
              i++;
             }
           }
          if (tabStop <= displayPosition && tabs._tabIncrement > 0)
           {
            while (tabStop <= displayPosition)
             {
              tabStop += tabs._tabIncrement;
             }
           }
          if (tabStop > displayPosition)
           {
            int len = tabStop - displayPosition;
            StringBuffer buffer = new StringBuffer(len);
            for (int i = 0; i < len; i++)
             {
              buffer.append(' ');
             }
            _view.insertText(buffer.toString());
           }
         }
        else
         {
          _view.documentPosition().nextTabStop();
         }
        break;
       }

      case ACTION_JOIN:
       {
        if (!reverse && element != null && !element.show() &&
            !_view.markList().protect(element) &&
            _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            Element element2 = (element != null)?
                                element.nextVisibleNonShow(_view) : null;
            if (element2 != null && !element2.show() &&
                !_view.markList().protect(element2))
             {
              _view.padTextTo(element, position);
              _view.joinElements(element, element2);
             }
           }
         }
        break;
       }
      case ACTION_KEY_RECORDER_PLAY:
       {
        if (!reverse)
         {
          for (int i = 0; i < repeat; i++)
           {
            KeyRecorder.keyRecorder().play(_view);
           }
         }
        break;
       }
      case ACTION_KEY_RECORDER_START:
       {
        KeyRecorder.keyRecorder().setRecording(true);
        KeyRecorder.keyRecorder().clear();
        break;
       }
      case ACTION_KEY_RECORDER_STOP:
       {
        KeyRecorder.keyRecorder().setRecording(false);
        break;
       }
      case ACTION_KILL_LINE:
       {
        if (element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          document.resetUserActionElements();
          String deleteText = "";
          String text = element.text();
          if (_argument == null || _argument.length() == 0)
           {
            if (text.length() >= position)
             {
              deleteText = _view.deleteText(element, position,
                                            text.length() - position + 1);
             }
            else
             {
              Element nextElement = element.nextVisibleNonShow(_view);
              if (nextElement != null && !_view.markList().protect(nextElement))
               {
                _view.padTextTo(element, position);
                _view.joinElements(element, nextElement);
                deleteText = "\n";
               }
             }
            KillRing.appendKillString(_view, deleteText);
           }
          else if (!reverse && repeat > 0)
           {
            for (int i = 0; i < repeat; i++)
             {
              text = element.text();
              if (text.length() >= position)
               {
                deleteText += _view.deleteText(element, position,
                                               text.length() - position + 1);
               }
              Element nextElement = element.nextVisibleNonShow(_view);
              if (nextElement != null && !_view.markList().protect(nextElement))
               {
                _view.padTextTo(element, position);
                _view.joinElements(element, nextElement);
                deleteText += "\n";
               }
              else
               {
                break;
               }
             }
            KillRing.appendKillString(_view, deleteText);
           }
          else
           {
            if (text != null && text.length() > 0 && position > 1)
             {
              deleteText = _view.deleteText(element, 1, position - 1);
             }
            for (int i = 0; i < repeat && element != null; i++)
             {
              Element prevElement = element.prevVisibleNonShow(_view);
              if (prevElement != null)
               {
                text = prevElement.text();
                deleteText = _view.deleteText(prevElement, 1, text.length()) + "\n" +
                             deleteText;
                _view.joinElements(prevElement, element);
               }
              element = prevElement;
             }
            KillRing.prefaceKillString(_view, deleteText);
           }
         }
        break;
       }
      case ACTION_KILL_REGION:
       {
        MarkList.Mark quickMark = _view.markList().find("@QUICK");
        if (quickMark != null && element != null && _view.changeAllowed())
         {
          document.resetUserActionElements();
          Element quickMarkElement = quickMark.element1();
          int quickMarkPosition = quickMark.position1();
          boolean forward = _view.documentPosition().above(quickMarkElement,
                                                           quickMarkPosition);
          String deleteText = _view.deleteText(element, position,
                                               quickMarkElement, quickMarkPosition);
          if (forward)
           {
            KillRing.appendKillString(_view, deleteText);
           }
          else
           {
            KillRing.prefaceKillString(_view, deleteText);
           }
         }
        break;
       }
      case ACTION_LEFT:
       {
        if (!reverse)
         {
          if (_view.screen().currentPrefixArea() && repeat >= position)
           {
            // if there are sequence numbers on the left,
            // first ensure we scroll them into view
            _view.documentPosition().home();

            _view.setInPrefix(true);
            _view.documentPosition().prefixEnd();
           }
          else
           {
            _view.documentPosition().left(repeat);
           }
         }
        else
         {
          _view.documentPosition().right(repeat);
         }
        break;
       }

      case ACTION_LOCATE_LINE:
       {
        // 1.- if set & showing, locate sequence number
        if (_view.document().elementList().sequenceNumbersNumWidth() > 0 &&
            (!_view.currentHideSequenceNumbers() ||
             (_view.screen().currentPrefixArea() == true &&
              PrefixAreaTextParameter.getParameter().currentValue(_view) ==
                 View.PREFIX_AREA_TEXT_SEQUENCENUMBERS)))
         {
          int n = 0;
          if (element != null)
           {
            if (element.show())
             {
              element = element.prevNonShow();
             }
            if (element != null)
             {
              n = element.sequenceNumber();
             }
           }

          String sequenceNumber = String.valueOf(n);
          int width = _view.document().elementList().sequenceNumbersWidth();
          while (sequenceNumber.length() < width)
           {
            sequenceNumber = "0" + sequenceNumber;
           }
          while (sequenceNumber.length() > width)
           {
            sequenceNumber = sequenceNumber.substring(1);
           }

          String label = LpexResources.message(MSG_COMMANDLINE_SEQUENCE_NUMBER);
          InputCommand.doCommand(_view,
            LpexStringTokenizer.addQuotes(label) + " " +
            LpexStringTokenizer.addQuotes(sequenceNumber) + " " +
            LpexStringTokenizer.addQuotes("locate emphasis sequenceNumber "));
         }

        // 2.- else, locate line number
        else
         {
          String label = LpexResources.message(MSG_COMMANDLINE_LINE_NUMBER);
          InputCommand.doCommand(_view,
            LpexStringTokenizer.addQuotes(label) + " " +
            LpexStringTokenizer.addQuotes("locate emphasis line "));
         }
        break;
       }

      case ACTION_LOWER_CASE_WORD:
       {
        if (element != null && _view.changeAllowed())
         {
          document.resetUserActionElements();
          if (!reverse)
           {
            boolean moveToNextWord = true;
            if (!element.show())
             {
              String text = element.text();
              if (position >= 1 && position <= text.length())
               {
                char c = text.charAt(position - 1);
                if (c != ' ' && c != '\t')
                 {
                  moveToNextWord = false;
                 }
               }
             }
            if (moveToNextWord)
             {
              if (!_view.documentPosition().nextWord())
               {
                repeat = 0;
               }
             }
           }
          for (int i = 0; i < repeat; i++)
           {
            element = _view.documentPosition().element();
            position = _view.documentPosition().position();
            if (reverse)
             {
              if (_view.documentPosition().prevWord())
               {
                int wordLength;
                if (element == _view.documentPosition().element())
                 {
                  wordLength = position - _view.documentPosition().position();
                 }
                else
                 {
                  wordLength = _view.documentPosition().element().length() -
                               _view.documentPosition().position() + 1;
                 }
                _view.changeCase(wordLength, false);
               }
              else
               {
                repeat = 0;
               }
             }
            else
             {
              int wordLength = ElementList.nextWordEnd(element, position - 1) -
                               position + 1;
              _view.changeCase(wordLength, false);
              if (!_view.documentPosition().nextWord())
               {
                repeat = 0;
               }
             }
           }
         }
        break;
       }
      case ACTION_LOWER_CASE_REGION:
       {
        MarkList.Mark quickMark = _view.markList().find("@QUICK");
        if (quickMark != null && element != null && _view.changeAllowed())
         {
          document.resetUserActionElements();
          _view.changeCase(element, position,
                           quickMark.element1(), quickMark.position1(),
                           false);
         }
        break;
       }
      case ACTION_NAME_MARK:
       {
        String label = LpexResources.message(MSG_COMMANDLINE_NAME_MARK);
        InputCommand.doCommand(_view,
          LpexStringTokenizer.addQuotes(label) + " " +
          LpexStringTokenizer.addQuotes("set mark."));
        break;
       }
      case ACTION_NEW_LINE:
       {
        if (reverse)
         {
          _view.documentPosition().up(repeat);
         }
        else
         {
          _view.documentPosition().down(repeat);
         }
        _view.documentPosition().home();
        break;
       }
      case ACTION_NEXT_TAB_STOP:
       {
        for (int i = 0; i < repeat; i++)
         {
          if (reverse)
           {
            if (_view.documentPosition().position() > 1)
             {
              _view.documentPosition().prevTabStop();
             }
            else // on position 1
             {
              // if there are sequence numbers on the left,
              // first ensure we scroll them into view
              _view.documentPosition().home();

              if (_view.screen().currentPrefixArea())
               {
                _view.setInPrefix(true);
                _view.documentPosition().prefixHome();
               }
             }
           }
          else // !reverse
           {
            _view.documentPosition().nextTabStop();
           }
         }
        break;
       }
      case ACTION_NEXT_WORD:
       {
        for (int i = 0; i < repeat; i++)
         {
          if (reverse)
           {
            _view.documentPosition().prevWord();
           }
          else
           {
            _view.documentPosition().nextWord();
           }
         }
        break;
       }

      // this action is defined to prevent e.g., a Ctrl+<letter> key combo to
      // insert the ^<letter> character in the text window...
      case ACTION_NULL_ACTION:
       {
        break;
       }

      case ACTION_ONE_SPACE:
       {
        if (element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          doDefaultAction(ACTION_DELETE_WHITE_SPACE);
          _view.insertText(" ");
         }
        break;
       }
      case ACTION_OPEN_LINE:
       {
        if (!_view.markList().insertElementProtect(element) && _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            if (reverse)
             {
              _view.documentPosition().home();
             }
            else
             {
              _view.documentPosition().end();
             }
            _view.splitElement();
           }
         }
        break;
       }
      case ACTION_PAGE_DOWN:
       {
        for (int i = 0; i < repeat; i++)
         {
          if (!reverse)
           {
            _view.documentPosition().pageDown();
           }
          else
           {
            _view.documentPosition().pageUp();
           }
         }
        break;
       }
      case ACTION_PAGE_LEFT:
       {
        for (int i = 0; i < repeat; i++)
         {
          if (reverse)
           {
            //_view.documentPosition().pageRight();
            _view.documentPosition().positionPageRight();
           }
          else
           {
            // orig code was just scrolling screen one page left, not moving the cursor
            //_view.documentPosition().pageLeft();
            _view.documentPosition().positionPageLeft();
           }
         }
        break;
       }
      case ACTION_PAGE_RIGHT:
       {
        for (int i = 0; i < repeat; i++)
         {
          if (!reverse)
           {
            // orig code was just scrolling screen one page right, not moving the cursor
            //_view.documentPosition().pageRight();
            _view.documentPosition().positionPageRight();
           }
          else
           {
            //_view.documentPosition().pageLeft();
            _view.documentPosition().positionPageLeft();
           }
         }
        break;
       }
      case ACTION_PAGE_UP:
       {
        for (int i = 0; i < repeat; i++)
         {
          if (reverse)
           {
            _view.documentPosition().pageDown();
           }
          else
           {
            _view.documentPosition().pageUp();
           }
         }
        break;
       }

      // currently, this action only works inside a VA Base LPEX plugin, with
      // LpexTextViewer.fillContextMenu() setting up the popup menu items
      case ACTION_POPUP_AT_CURSOR:
       {
        if (_view.window() != null)
         {
          Menu menu = _view.window().getMenu();
          if (menu != null) {
             Point cursor = _view.window().textWindow()
                                 .toDisplay(new Point(_view.screen().cursorX(),
                                                      _view.screen().cursorY()));
             menu.setLocation(cursor.x, cursor.y);
             menu.setVisible(true);
             // *as* now clear swt.widgets.Menu.hasLocation whenever implemented...
             }
         }
        break;
       }
      // currently, this action only works inside a VA Base LPEX plugin, with
      // LpexTextViewer.fillContextMenu() setting up the popup menu items
      case ACTION_POPUP_AT_MOUSE:
       {
        if (_view.window() != null)
         {
          Menu menu = _view.window().getMenu();
          if (menu != null) {
             // *as* setLocation not needed when can clear swt.widgets.Menu.hasLocation...
             Point mouse = _view.window().getDisplay().getCursorLocation();
             menu.setLocation(mouse.x, mouse.y);
             menu.setVisible(true);
             }
         }
        break;
       }

      case ACTION_PASTE:
      case ACTION_ECLIPSE_PASTE:
       {
        if (!reverse && element != null &&
            !_view.markList().insertElementProtect(element) &&
            _view.changeAllowed())
         {
          String text = LpexUtilities.getClipboardContents();
          if (text != null)
           {
            document.resetUserActionElements();
            _view.tryToDeleteStreamBlock();
            for (int i = 0; i < repeat; i++)
             {
              element = _view.documentPosition().element();
              if (element.show())
               {
                _view.documentPosition().end();
                _view.insertText("\n" + text);
               }
              else
               {
                _view.insertText(text);
               }
             }
           }
         }
        break;
       }
      case ACTION_PREFERENCES:
       {
//      Shell frame = _view.lpexView().frame();
//      if (frame instanceof JFrame)
//       {
//        LpexView lpexViews[] = new LpexView[1];
//        lpexViews[0] = _view.lpexView();
//        try
//         {
//          Class lpexPreferencesClass = Class.forName("com.ibm.lpex.preferences.LpexPreferences");
//          Class[] parameterTypes = { JFrame.class, LpexView[].class };
//          Constructor constructor = lpexPreferencesClass.getConstructor(parameterTypes);
//          Object[] arguments = { frame, lpexViews };
//          constructor.newInstance(arguments);
//         }
//        catch (Exception e) {}
//       }
        break;
       }
      case ACTION_PREFIX_BACK_SPACE:
       {
        if (reverse)
         {
          _view.deletePrefixText(repeat);
         }
        else
         {
          position = _view.documentPosition().prefixPosition();
          if (repeat > position)
           {
            repeat = position;
           }
          _view.documentPosition().prefixLeft(repeat);
          _view.deletePrefixText(repeat);
         }
        break;
       }
      case ACTION_PREFIX_DELETE:
       {
        if (!reverse)
         {
          _view.deletePrefixText(repeat);
         }
        else
         {
          position = _view.documentPosition().prefixPosition();
          if (repeat > position)
           {
            repeat = position;
           }
          _view.documentPosition().prefixLeft(repeat);
          _view.deletePrefixText(repeat);
         }
        break;
       }
      case ACTION_PREFIX_END:
       {
        _view.documentPosition().prefixEnd();
        break;
       }
      case ACTION_PREFIX_HOME:
       {
        _view.documentPosition().prefixHome();
        break;
       }
      case ACTION_PREFIX_LEFT:
       {
        if (element != null)
         {
          if (!reverse)
           {
            _view.documentPosition().prefixLeft(repeat);
           }
          else
           {
            if (element.elementView(_view).prefixEnd() >=
                _view.documentPosition().prefixPosition() + repeat)
             {
              _view.documentPosition().prefixRight(repeat);
             }
            else
             {
              _view.setInPrefix(false);
              _view.documentPosition().home();
             }
           }
         }
        break;
       }
      case ACTION_PREFIX_RIGHT:
       {
        if (element != null)
         {
          if (reverse)
           {
            _view.documentPosition().prefixLeft(repeat);
           }
          else
           {
            if (element.elementView(_view).prefixEnd() >=
                _view.documentPosition().prefixPosition() + repeat)
             {
              _view.documentPosition().prefixRight(repeat);
             }
            else
             {
              _view.setInPrefix(false);
              _view.documentPosition().home();
             }
           }
         }
        break;
       }
      case ACTION_PREFIX_TRUNCATE:
       {
        if (element != null)
         {
          String text = element.elementView(_view).prefixText();
          position = _view.documentPosition().prefixPosition();
          if (text != null && text.length() >= position)
           {
            _view.deletePrefixText(text.length() - position + 1);
           }
         }
        break;
       }
      case ACTION_PREV_TAB_STOP:
       {
        for (int i = 0; i < repeat; i++)
         {
          if (!reverse)
           {
            if (_view.documentPosition().position() > 1)
             {
              _view.documentPosition().prevTabStop();
             }
            else // on position 1
             {
              // if there are sequence numbers on the left,
              // first ensure we scroll them into view
              _view.documentPosition().home();

              if (_view.screen().currentPrefixArea())
               {
                _view.setInPrefix(true);
                _view.documentPosition().prefixHome();
               }
             }
           }
          else // reverse
           {
            _view.documentPosition().nextTabStop();
           }
         }
        break;
       }
      case ACTION_PREV_WORD:
       {
        for (int i = 0; i < repeat; i++)
         {
          if (!reverse)
           {
            _view.documentPosition().prevWord();
           }
          else
           {
            _view.documentPosition().nextWord();
           }
         }
        break;
       }
      case ACTION_PRINT:
      case ACTION_ECLIPSE_PRINT:
       {
        PrintCommand.doCommand(_view, "prompt");
        break;
       }
      case ACTION_PROCESS_PREFIX:
       {
        String baseProfile = _view.baseProfile();
        _view.commandHandler().doCommand("processPrefix " + baseProfile);
        break;
       }
      case ACTION_REDO:
      case ACTION_ECLIPSE_REDO:
       {
        if (_view.changeAllowed())
         {
          if (reverse)
           {
            document.undo().undo(_view, repeat);
           }
          else
           {
            document.undo().redo(_view, repeat);
           }
         }
        break;
       }
      case ACTION_RELOAD:
       {
        LoadCommand.doCommand(_view, "");
        break;
       }
      case ACTION_RENAME:
       {
        String name = _view.document().name();
        String label = LpexResources.message(MSG_COMMANDLINE_FILE_NAME);
        InputCommand.doCommand(_view,
          LpexStringTokenizer.addQuotes(label) + " " +
          LpexStringTokenizer.addQuotes(name) + " " +
          LpexStringTokenizer.addQuotes("set name "));
        break;
       }
      case ACTION_RIGHT:
       {
        if (reverse)
         {
          if (_view.screen().currentPrefixArea() && repeat >= position)
           {
            // if there are sequence numbers on the left,
            // first ensure we scroll them into view
            _view.documentPosition().home();

            _view.setInPrefix(true);
            _view.documentPosition().prefixEnd();
           }
          else
           {
            _view.documentPosition().left(repeat);
           }
         }
        else
         {
          _view.documentPosition().right(repeat);
         }
        break;
       }
      case ACTION_SAVE:
       {
        SaveCommand.doCommand(_view, "");
        break;
       }
      case ACTION_SAVE_AS:
       {
        String name = _view.document().name();
        if (name == null)
         {
          SaveCommand.doCommand(_view, "prompt");
         }
        else
         {
          SaveCommand.doCommand(_view, "prompt " +
                                LpexStringTokenizer.addQuotes(_view.document().name()));
         }
        break;
       }
      case ACTION_SAVE_TO_WRITER:
       {
        SaveCommand.doCommand(_view, _view.getSaveWriter(), "");
        break;
       }
      case ACTION_SCROLL_BOTTOM:
       {
        _view.screen().setCursorRow(_view.screen().rows());
        break;
       }
      case ACTION_SCROLL_CENTER:
       {
        _view.screen().setCursorRow((_view.screen().rows() + 1) / 2);
        break;
       }
      case ACTION_SCROLL_TOP:
       {
        _view.screen().setCursorRow(1);
        break;
       }
      case ACTION_SET_ACTION_ARGUMENT:
       {
        if (_argument == null || _argument.length() == 0)
         {
          _argument = "";
          _settingArgument = true;
         }
        else
         {
          for (int i = 0; i < _argument.length(); i++)
           {
            if (_argument.charAt(i) != '*')
             {
              _settingArgument = false;
              break;
             }
           }
         }
        if (_settingArgument)
         {
          _argument += '*';
         }
        break;
       }
      case ACTION_SET_PARSER:
       {
        if (_view.window() != null)
         {
          CommandLine commandLine = (CommandLine)_view.window().commandLine();
          commandLine.setForceVisible(true);
          commandLine.setMode(CommandLine.MODE_SET_PARSER);
          _view.window().commandLineRequestFocus();
         }
        break;
       }
      case ACTION_SET_QUICK_MARK:
       {
        SetCommand.doCommand(_view, "mark.@QUICK");
        _view.setLpexMessageText(MSG_MARK_QUICK_MARK_SET);
        break;
       }
      case ACTION_SET_QUICK_MARK_ALL:
       {
        _view.documentPosition().bottom();
        doDefaultAction(ACTION_SET_QUICK_MARK);
        _view.documentPosition().top();
        break;
       }
      case ACTION_SET_QUICK_MARK_WORD:
       {
        DocumentPosition.Preserve preservedPosition = _view.documentPosition().preserve();
        for (int i = 0; i < repeat; i++)
         {
          if (reverse)
           {
            _view.documentPosition().prevWord();
           }
          else
           {
            _view.documentPosition().nextWordEnd(1);
           }
         }
        doDefaultAction(ACTION_SET_QUICK_MARK);
        preservedPosition.restore();
        _view.documentPosition().disposePreserve(preservedPosition);
        break;
       }
      case ACTION_SHOW_ALL:
       {
        _view.setIncludedClasses(Classes.ALL);
        _view.setExcludedClasses(Classes.NONE);
        break;
       }
      case ACTION_SPLIT:
       {
        if (!reverse && element != null &&
            !_view.markList().insertElementProtect(element) &&
            _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            _view.splitElement();
            _view.documentPosition().jump(element, position);
           }
         }
        break;
       }
      case ACTION_SPLIT_AND_SHIFT:
       {
        if (element != null && !_view.markList().insertElementProtect(element) &&
            _view.changeAllowed())
         {
          _view.splitElement();
          _view.shift(position - 1);
          _view.documentPosition().jump(element, position);
         }
        break;
       }
      case ACTION_SPLIT_LINE:
       {
        if (!reverse && element != null &&
            !_view.markList().insertElementProtect(element) &&
            _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            _view.splitElement();
           }
         }
        break;
       }
      case ACTION_TEXT_WINDOW:
       {
        if (_view.window() != null)
         {
          _view.window().textWindowRequestFocus();
         }
        break;
       }
      case ACTION_TOGGLE_CASE_SENSITIVE:
       {
        FindTextCommand.AsisParameter p = FindTextCommand.asisParameter();
        boolean asis = p.currentValue(_view);
        asis = !asis;
        if (p.value(_view) == Parameter.DEFAULT)
         {
          p.setDefaultValue(asis? Parameter.ON : Parameter.OFF);
         }
        else
         {
          p.setValue(_view, asis? Parameter.ON : Parameter.OFF);
         }
       }
      case ACTION_TOGGLE_INSERT:
       {
        _view.setInsertMode(!_view.insertMode());
        break;
       }
      case ACTION_TOGGLE_KEY_RECORDING:
       {
        KeyRecorder.keyRecorder().setRecording(!KeyRecorder.keyRecorder().recording());
        break;
       }
      case ACTION_TOGGLE_REGULAR_EXPRESSION:
       {
        FindTextCommand.RegularExpressionParameter p =
           FindTextCommand.regularExpressionParameter();
        boolean regularExpression = p.currentValue(_view);
        regularExpression = !regularExpression;
        if (p.value(_view) == Parameter.DEFAULT)
         {
          p.setDefaultValue(regularExpression? Parameter.ON : Parameter.OFF);
         }
        else
         {
          p.setValue(_view, regularExpression? Parameter.ON : Parameter.OFF);
         }
        break;
       }
      case ACTION_TOP:
       {
        doDefaultAction(ACTION_SET_QUICK_MARK);
        _view.documentPosition().documentTop(); // top of complete document
        break;
       }
      case ACTION_TRANSPOSE_CHARACTERS:
       {
        if (element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            position = _view.documentPosition().position();
            if (reverse)
             {
              position--;
             }
            if (position >= element.text().length())
             {
              position = element.end() - 1;
             }
            if (position > 1)
             {
              String deleteText = _view.deleteText(element, position - 1);
              _view.insertText(element, position, deleteText);
              if (!reverse)
               {
                position++;
               }
              _view.documentPosition().jump(element, position);
             }
           }
         }
        break;
       }
      case ACTION_TRANSPOSE_LINES:
       {
        if (element != null && _view.changeAllowed())
         {
          for (int i = 0; i < repeat; i++)
           {
            if (reverse)
             {
              element = element.prevVisibleNonShow(_view);
              if (element == null || _view.markList().protect(element))
               {
                break;
               }
             }
            Element element2 = element.prevVisibleNonShow(_view);
            if (element2 == null || _view.markList().protect(element2))
             {
              break;
             }
            String deleteText  = _view.deleteText(element,  1, element.text().length());
            String deleteText2 = _view.deleteText(element2, 1, element2.text().length());
            _view.insertText(element2, 1, deleteText);
            _view.insertText(element, 1, deleteText2);
            if (!reverse)
             {
              element = element.nextVisibleNonShow(_view);
              if (element == null || _view.markList().protect(element))
               {
                break;
               }
             }
            _view.documentPosition().jump(element, 1);
           }
         }
        break;
       }
      case ACTION_TRANSPOSE_WORDS:
       {
        if (element != null && _view.changeAllowed())
         {
          if (repeat < 0)
           {
            repeat = -repeat;
           }
          for (int i = 0; i < repeat; i++)
           {
            element = _view.documentPosition().element();
            position = _view.documentPosition().position();
            if (element.show())
             {
              element = element.nextVisibleNonShow(_view);
              position = 1;
             }
            int firstWordLength = 0;
            int secondWordLength = 0;
            DocumentPosition.Preserve firstWordDocumentPosition = null;
            DocumentPosition.Preserve secondWordDocumentPosition = null;
            while (element != null)
             {
              position = ElementList.prevWord(element, position);
              if (position != 0)
               {
                _view.documentPosition().jump(element, position);
                firstWordLength = ElementList.nextWordEnd(element, position - 1) -
                                  position + 1;
                firstWordDocumentPosition = _view.documentPosition().preserve();
                break;
               }
              element = element.prevVisibleNonShow(_view);
              if (element != null)
               {
                position = element.end();
               }
             }
            while (element != null)
             {
              position = reverse? ElementList.prevWord(element, position) :
                                  ElementList.nextWord(element, position);
              if (position != 0)
               {
                _view.documentPosition().jump(element, position);
                secondWordLength = ElementList.nextWordEnd(element, position - 1) -
                                   position + 1;
                secondWordDocumentPosition = _view.documentPosition().preserve();
                break;
               }
              if (reverse)
               {
                element = element.prevVisibleNonShow(_view);
                if (element != null)
                 {
                  position = element.end();
                 }
               }
              else
               {
                element = element.nextVisibleNonShow(_view);
                position = 0;
               }
             }
            if (firstWordLength != 0 && secondWordLength != 0)
             {
              firstWordDocumentPosition.restore();
              String firstWord = _view.deleteText(firstWordLength);
              secondWordDocumentPosition.restore();
              String secondWord = _view.deleteText(secondWordLength);
              firstWordDocumentPosition.restore();
              _view.insertText(secondWord);
              secondWordDocumentPosition.restore();
              _view.insertText(firstWord);
             }
            if (firstWordDocumentPosition != null)
             {
              _view.documentPosition().disposePreserve(firstWordDocumentPosition);
             }
            if (secondWordDocumentPosition != null)
             {
              _view.documentPosition().disposePreserve(secondWordDocumentPosition);
             }
           }
         }
        break;
       }
      case ACTION_TRUNCATE:
       {
        if (element != null && !element.show() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          String text = element.text();
          if (text.length() >= position)
           {
            _view.deleteText(element, position, text.length() - position + 1);
           }
         }
        break;
       }
      case ACTION_UNDO:
      case ACTION_ECLIPSE_UNDO:
       {
        if (_view.changeAllowed())
         {
          if (!reverse)
           {
            document.undo().undo(_view, repeat);
           }
          else
           {
            document.undo().redo(_view, repeat);
           }
         }
        break;
       }
      case ACTION_UP:
       {
        if (reverse)
         {
          _view.documentPosition().down(repeat);
         }
        else
         {
          _view.documentPosition().up(repeat);
         }
        break;
       }
      case ACTION_UPPER_CASE_WORD:
       {
        if (element != null && _view.changeAllowed())
         {
          document.resetUserActionElements();
          if (!reverse)
           {
            boolean moveToNextWord = true;
            if (!element.show())
             {
              String text = element.text();
              if (position >= 1 && position <= text.length())
               {
                char c = text.charAt(position - 1);
                if (c != ' ' && c != '\t')
                 {
                  moveToNextWord = false;
                 }
               }
             }
            if (moveToNextWord)
             {
              if (!_view.documentPosition().nextWord())
               {
                repeat = 0;
               }
             }
           }
          for (int i = 0; i < repeat; i++)
           {
            element  = _view.documentPosition().element();
            position = _view.documentPosition().position();
            if (reverse)
             {
              if (_view.documentPosition().prevWord())
               {
                int wordLength;
                if (element == _view.documentPosition().element())
                 {
                  wordLength = position - _view.documentPosition().position();
                 }
                else
                 {
                  wordLength = _view.documentPosition().element().length() -
                               _view.documentPosition().position() + 1;
                 }
                _view.changeCase(wordLength, true);
               }
              else
               {
                repeat = 0;
               }
             }
            else
             {
              int wordLength = ElementList.nextWordEnd(element, position - 1) -
                               position + 1;
              _view.changeCase(wordLength, true);
              if (!_view.documentPosition().nextWord())
               {
                repeat = 0;
               }
             }
           }
         }
        break;
       }
      case ACTION_UPPER_CASE_REGION:
       {
        MarkList.Mark quickMark = _view.markList().find("@QUICK");
        if (quickMark != null && element != null && _view.changeAllowed())
         {
          document.resetUserActionElements();
          _view.changeCase(element, position,
                           quickMark.element1(), quickMark.position1(),
                           true);
         }
        break;
       }
      case ACTION_WINDOW_BOTTOM:
       {
        _view.documentPosition().windowBottom();
        break;
       }
      case ACTION_WINDOW_TOP:
       {
        _view.documentPosition().windowTop();
        break;
       }
      case ACTION_WORD_END:
       {
        if (element != null)
         {
          int prevWordStart = ElementList.prevWord(element, position);
          int prevWordEnd = 0;
          if (prevWordStart > 0)
           {
            prevWordEnd = ElementList.nextWordEnd(element, prevWordStart);
            if (prevWordEnd + 1 >= position)
             {
              _view.documentPosition().jump(element, prevWordEnd + 1);
              break;
             }
           }
          int nextWordEnd = ElementList.nextWordEnd(element, position);
          if (nextWordEnd > 0)
           {
            int nextWordStart = ElementList.prevWord(element, nextWordEnd);
            if (nextWordStart <= position)
             {
              _view.documentPosition().jump(element, nextWordEnd + 1);
              break;
             }
           }

          if (prevWordEnd != 0 || nextWordEnd != 0)
           {
            if (nextWordEnd == 0)
             {
              _view.documentPosition().jump(element, prevWordEnd + 1);
             }
            else if (prevWordEnd == 0)
             {
              _view.documentPosition().jump(element, nextWordEnd + 1);
             }
            else if (position - prevWordEnd + 1 > nextWordEnd + 1 - position)
             {
              _view.documentPosition().jump(element, nextWordEnd + 1);
             }
            else
             {
              _view.documentPosition().jump(element, prevWordEnd + 1);
             }
           }
         }
        break;
       }
      case ACTION_WORD_START:
       {
        if (element != null)
         {
          int prevWordStart = ElementList.prevWord(element, position);
          if (prevWordStart > 0)
           {
            int prevWordEnd = ElementList.nextWordEnd(element, prevWordStart);
            if (prevWordEnd + 1 >= position)
             {
              _view.documentPosition().jump(element, prevWordStart);
              break;
             }
           }
          int nextWordEnd = ElementList.nextWordEnd(element, position);
          int nextWordStart = 0;
          if (nextWordEnd > 0)
           {
            nextWordStart = ElementList.prevWord(element, nextWordEnd);
            if (nextWordStart <= position)
             {
              _view.documentPosition().jump(element, nextWordStart);
              break;
             }
           }

          if (prevWordStart != 0 || nextWordStart != 0)
           {
            if (nextWordStart == 0)
             {
              _view.documentPosition().jump(element, prevWordStart);
             }
            else if (prevWordStart == 0)
             {
              _view.documentPosition().jump(element, nextWordStart);
             }
            else if (position - prevWordStart > nextWordStart - position)
             {
              _view.documentPosition().jump(element, nextWordStart);
             }
            else
             {
              _view.documentPosition().jump(element, prevWordStart);
             }
           }
         }
        break;
       }
      case ACTION_YANK:
       {
        if (element != null && !element.show() && KillRing.killStringAvailable() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          document.resetUserActionElements();
          _view.insertText(KillRing.currentKillString());
          DocumentPosition.Preserve preservedPosition =
                                    _view.documentPosition().preserve();
          _view.documentPosition().jump(element, position);
          doDefaultAction(ACTION_SET_QUICK_MARK);
          preservedPosition.restore();
          _view.documentPosition().disposePreserve(preservedPosition);
         }
        break;
       }
      case ACTION_YANK_PREVIOUS:
       {
        if (element != null && !element.show() &&
            KillRing.killStringAvailable() &&
            document.undo().lastChangeWasYank() &&
            !_view.markList().protect(element) && _view.changeAllowed())
         {
          document.undo().undo(_view, 1, true, true);
          KillRing.previousKillString(repeat);
          doDefaultAction(ACTION_YANK);
         }
        break;
       }

      // ACTION_ECLIPSE_SHIFT_RIGHT
      // ACTION_ECLIPSE_SHIFT_LEFT
      // ACTION_ECLIPSE_PREFIX
      // ACTION_ECLIPSE_STRIP_PREFIX
      default:
       {
        break;
       }
     }
   }

  private void setDocumentPosition(Point point)
   {
    _view.documentPosition().setPosition(point.x, point.y);
   }

  /**
   * Define a new LPEX action.
   * @param actionString - action name
   * @param lpexAction   - LpexAction object (implements LpexAction interface)
   *                       which carries out the action
   * @return previous LpexAction defined for this actionString, if any
   */
  LpexAction defineAction(String actionString, LpexAction lpexAction)
   {
    // remove any previous definition of this action from our action lists
    LpexAction oldLpexAction = null;
    Action action = _actionList.find(actionString);
    if (action != null)
     {
      oldLpexAction = action.lpexAction();
      _textAreaKeyActionList.actionRemoved(action.id());
      _prefixAreaKeyActionList.actionRemoved(action.id());
      _commandLineKeyActionList.actionRemoved(action.id());
      _textAreaMouseActionList.actionRemoved(action.id());
      _prefixAreaMouseActionList.actionRemoved(action.id());
      _expandHideAreaMouseActionList.actionRemoved(action.id());
      _actionList.remove(action);
     }

    // establish the new (definition of this) user-defined action
    if (lpexAction != null)
     {
      int actionId = defaultId(actionString);
      if (actionId == ACTION_INVALID)
       {
        actionId = _availableActionId;
        _availableActionId++;
       }

      action = new Action(actionId, actionString, lpexAction);
      _actionList.addAfter(null, action);
     }

    return oldLpexAction;
   }

  /**
   * Define a new LPEX action.
   * @param actionString - action name
   * @param lpexAction   - name of class implementing the LpexAction object
   *                       which carries out the action
   */
  LpexAction defineAction(String actionString, String className)
   {
    LpexAction lpexAction = null;
    if (className != null && className.length() > 0)
     {
      Class actionClass = null;
      try
       {
        actionClass = Class.forName(className);
       }
      catch(ClassNotFoundException e) {}
      // if couldn't load, try the alternative class loader if set
      if (actionClass == null && _view.getClassLoader() != null)
       {
        try
         {
          actionClass = Class.forName(className, true, _view.getClassLoader());
         }
        catch(ClassNotFoundException e) {}
       }
      if (actionClass == null)
       {
        _view.setLpexMessageText(MSG_CLASS_NOTFOUND, className);
        return null;
       }

      if (!LpexAction.class.isAssignableFrom(actionClass))
       {
        _view.setLpexMessageText(MSG_CLASS_INVALID, className, "LpexAction");
        return null;
       }

      try
       {
        Constructor actionConstructor = actionClass.getConstructor(null);
        lpexAction = (LpexAction) actionConstructor.newInstance(null);
       }
      catch (InvocationTargetException e)
       {
        e.getTargetException().printStackTrace();
        return null;
       }
      catch (Exception e)
       {
        _view.setLpexMessageText(MSG_CLASS_INVALID, className, "LpexAction");
        return null;
       }
     }

    return defineAction(actionString, lpexAction);
   }

  /**
   * Retrieve the LpexAction object which carries out the LPEX action named
   * <code>actionString</code>.
   */
  LpexAction action(String actionString)
   {
    Action action = _actionList.find(actionString);
    return (action != null)? action.lpexAction() : null;
   }

  /**
   * Returns a list of all the user-[re]defined action names.
   * Called by ActionsParameter (the <b>actions</b> parameter).
   */
  String actions()
   {
    _actionList.sort();

    StringBuffer actions = new StringBuffer(200);
    boolean first = true;
    for (Action action = (Action)_actionList.first();
         action != null;
         action = (Action)action.next())
     {
      if (!first)
       {
        actions.append(' ');
       }
      first = false;
      actions.append(action.actionString());
     }
    return actions.toString();
   }

  /**
   * Retrieve the name of the class which carries out LPEX action named
   * <code>actionString</code>.
   */
  String actionClass(String actionString)
   {
    Action action = _actionList.find(actionString);
    return (action != null)? action.lpexAction().getClass().getName() : null;
   }

  // -as- These are currently handled in com.ibm.lpex.alef.LpexTextViewer,
  // due to the support provided by Eclipse for this...
  //
  // boolean populateMenu(Menu menu, String menuDefinition)
  //  {
  //   return populateSubmenu(menu, new LpexStringTokenizer(menuDefinition));
  //  }
  //
  // boolean populatePopupMenu(Menu popupMenu, String menuDefinition)
  //  {
  //   return populateSubmenu(popupMenu, new LpexStringTokenizer(menuDefinition));
  //  }
  //
  // private boolean populateSubmenu(Menu menu, LpexStringTokenizer st)
  //  {
  //   // ...
  //   return true;
  //  }
  //
  // private static void setTextAndMnemonic(MenuItem menuItem, String token)
  //  {
  //   // ...
  //  }

///**
// * Event received by the ActionListener we registered for a menu item in
// * populateSubmenu().
// */
//public void actionPerformed(ActionEvent e)
// {
//  String action = e.getActionCommand();
//  int actionId = id(action);
//  if (actionId != ACTION_INVALID)
//   {
//    triggerAction(actionId);
//   }
// }

  String argument()
   {
    return _argument;
   }

  void setArgument(String argument)
   {
    if (_userActionId != ACTION_SET_ACTION_ARGUMENT &&
        _userActionId != ACTION_APPEND_TO_ACTION_ARGUMENT)
     {
      _argument = argument;
      _settingArgument = false;
     }
   }

  private void appendToArgument(char c)
   {
    if (_argument == null)
     {
      _argument = "";
     }
    _argument += c;
   }

  private boolean validArgumentCharacter(char c)
   {
    if (c >= '0' && c <= '9')
     {
      return true;
     }

    if (c == '-')
     {
      if (_argument == null || _argument.length() == 0)
       {
        return true;
       }
      for (int i = 0; i < _argument.length(); i++)
       {
        if (_argument.charAt(i) != '*')
         {
          return false;
         }
       }
      return true;
     }

    return false;
   }

  int repeat()
   {
    int repeat = 1;
    if (_argument != null && _argument.length() > 0)
     {
      int i = 0;
      while (i < _argument.length() && _argument.charAt(i) == '*')
       {
        if (repeat < MAX_REPEAT)
         {
          repeat *= 4;
         }
        i++;
       }

      if (i < _argument.length())
       {
        repeat = 0;
        boolean negative = false;
        if (_argument.charAt(i) == '-')
         {
          negative = true;
          i++;
         }
        while (i < _argument.length())
         {
          char c = _argument.charAt(i);
          if (c >= '0' && c <= '9')
           {
            if (repeat < MAX_REPEAT)
             {
              repeat = repeat * 10 + (c - '0');
             }
           }
          else if (c == '-')
           {
            negative = true;
           }
          i++;
         }
        if (negative)
         {
          if (repeat == 0)
           {
            repeat = -1;
           }
          else
           {
            repeat = -repeat;
           }
         }
       }
     }

    return repeat;
   }

  int lastKeyActionId()
   {
    return _lastKeyActionId;
   }

  String lastKeyActionArgument()
   {
    return _lastKeyActionArgument;
   }

  int userActionId()
   {
    return _userActionId;
   }

  int lastUserActionId()
   {
    return _lastUserActionId;
   }

  void setUserActionId(int actionId)
   {
    _lastUserActionId = _userActionId;
    _userActionId = actionId;
   }


  /**
   * Internal representation of a key for our table of supported keys:
   * its name, its keyChar, its keyCode, and
   * an ignoreShift flag for keys that can only be entered by using Shift
   * (awt: disregards the Shift modifier if (key.keyChar() != CHAR_UNDEFINED)).
   */
  private final static class Key extends TableNode
  {
   private int     _keyCode;
   private char    _keyChar;
   private boolean _ignoreShift;

   Key(String keyName, int keyCode, char keyChar, boolean ignoreShift)
   {
    super(keyName, keyCode);
    _keyCode = keyCode;
    _keyChar = keyChar;
    _ignoreShift = ignoreShift;
   }

   String keyName()
   {
    return string();
   }

   int keyCode()
   {
    return _keyCode;
   }

   char keyChar()
   {
    return _keyChar;
   }

   // Ignore Shift modifier (for keys that can only be entered via it)?
   // awt: if (key.keyChar() != KeyEvent.CHAR_UNDEFINED)
   boolean ignoreShift()
   {
    return _ignoreShift;
   }
  }


  /**
   * A list of key actions.
   *
   * Three key-action lists are maintained for a view:  one for the text-edit
   * area, one for the prefix-commands area, and one for the command line.
   *
   * Some key actions may also have a key-action list, e.g. in the emacs
   * base profile.
   */
  final class KeyActionList extends List
  {
   private int _context;
   private KeyAction _prefixKeyAction;

   /**
    * Construct a key-action list for a given context:  the text area,
    * the prefix area, or the command line.
    */
   KeyActionList(int context)
   {
    _context = context;
   }

   /**
    * @param modifiers,&nbsp;key key
    * @param secondary <code>false</code> = set as primary key for this action
    * @param actionString action to associate with key
    */
   private void defineKeyAction(int modifiers, Key key,
                                boolean secondary, String actionString)
   {
    /*---------------------------------------------------------------*/
    /*  if an action was previously defined for this key, remove it  */
    /*---------------------------------------------------------------*/
    KeyAction keyAction = findKey(modifiers, key);
    if (keyAction != null)
     {
      String oldActionString = keyAction.actionString(); // remember original action
      remove(keyAction);

      // if the original action just unassociated from this key has no longer
      // a primary key assigned, promote any of its secondary key associations
      // to primary (NB if we're actually redefining the same action with the
      // same key, i.e., oldActionString == actionString, it will be taken
      // care of later below...)
      if (oldActionString != null && findPrimaryKey(oldActionString) == null)
       {
        // this redefinition case not common, otherwise should optimize like
        // findPrimaryKey(String): 1st binary search for built-in actions...
        for (keyAction = (KeyAction)first();
             keyAction != null;
             keyAction = (KeyAction)keyAction.next())
         {
          if (keyAction.actionString() != null &&
              keyAction.actionString().equals(oldActionString))
           {
            keyAction.setSecondary(false);
            break;
           }
         }
       }
     }

    /*-------------------------------------------------------------------*/
    /*  if an action name actually specified, associate the key with it  */
    /*-------------------------------------------------------------------*/
    if (actionString != null && actionString.length() > 0)
     {
      // if defining a primary key action, any previous primary key defined
      // for this action becomes secondary
      if (!secondary)
       {
        keyAction = findPrimaryKey(actionString);
        if (keyAction != null)
         {
          keyAction.setSecondary(true);
         }
       }
      keyAction = new KeyAction(modifiers, key, secondary, actionString);
      addBefore(null, keyAction);
     }
   }

   void defineKeyAction(int modifiersArray[], Key keyArray[],
                        boolean secondary, String actionString)
   {
    defineKeyAction(0, modifiersArray, keyArray, secondary, actionString);
   }

   private void defineKeyAction(int level, int modifiersArray[], Key keyArray[],
                                boolean secondary, String actionString)
   {
    if (level == (keyArray.length - 1))
     {
      defineKeyAction(modifiersArray[level], keyArray[level], secondary, actionString);
     }
    else
     {
      KeyAction keyAction = findKey(modifiersArray[level], keyArray[level]);
      KeyActionList keyActionList = null;
      if (keyAction != null)
       {
        remove(keyAction);
        keyActionList = keyAction.keyActionList();
       }
      if (keyActionList == null)
       {
        keyActionList = new KeyActionList(_context);
       }
      keyActionList.defineKeyAction(level + 1, modifiersArray, keyArray,
                                    secondary, actionString);
      if (keyActionList.first() != null)
       {
        keyAction = new KeyAction(modifiersArray[level], keyArray[level], keyActionList);
        addBefore(null, keyAction);
        keyActionList._prefixKeyAction = keyAction;
       }
     }
   }

   KeyAction findKey(int modifiers, Key key)
   {
    if (key != null)
     {
      KeyAction keyAction;
      for (keyAction = (KeyAction)first();
           keyAction != null && !keyAction.keyEquals(modifiers, key);
           keyAction = (KeyAction)keyAction.next()) {}
      if (keyAction != null)
       {
        remove(keyAction);
        addAfter(null, keyAction);
       }
      return keyAction;
     }
    return null;
   }

   KeyAction findKey(int modifiersArray[], Key keyArray[])
   {
    return findKey(0, modifiersArray, keyArray);
   }

   private KeyAction findKey(int level, int modifiersArray[], Key keyArray[])
   {
    KeyAction keyAction = findKey(modifiersArray[level], keyArray[level]);
    if (level == (keyArray.length - 1))
     {
      return keyAction;
     }

    if (keyAction.keyActionList() != null)
     {
      return keyAction.keyActionList().findKey(level + 1, modifiersArray, keyArray);
     }

    return null;
   }

   /**
    * Find the primary key-action assignment for actionId in this key list.
    */
   KeyAction findPrimaryKey(int actionId)
   {
    KeyAction keyAction;
    for (keyAction = (KeyAction)first();
         keyAction != null && !keyAction.primaryKey(actionId);
         keyAction = (KeyAction)keyAction.next()) {}
    return keyAction;
   }

   /**
    * Find the primary key-action assignment for actionString in this key list.
    */
   KeyAction findPrimaryKey(String actionString)
   {
    // try to speed this up if it's a built-in action...
    int actionId = defaultId(actionString);
    KeyAction keyAction;
    if (actionId != ACTION_INVALID)
     {
      keyAction = findPrimaryKey(actionId);
     }

    // else, just look for the actionString in the list...
    else
     {
      for (keyAction = (KeyAction)first();
           keyAction != null && !keyAction.primaryKey(actionString);
           keyAction = (KeyAction)keyAction.next()) {}
     }

    return keyAction;
   }

   void actionRemoved(int actionId)
   {
    if (actionId >= ACTION_USER)
     {
      KeyAction keyAction;
      for (keyAction = (KeyAction)first();
           keyAction != null;
           keyAction = (KeyAction)keyAction.next())
       {
        if (keyAction.actionId() == actionId)
         {
          keyAction.resetActionId();
         }
       }
     }
   }

   void sort()
   {
    boolean swap;
    do
     {
      swap = false;
      for (KeyAction keyAction = (KeyAction)first();
           keyAction != null;
           keyAction = (KeyAction)keyAction.next())
       {
        KeyAction next = (KeyAction)keyAction.next();
        if (next != null)
         {
          if (keyAction.keyString().compareTo(next.keyString()) > 0)
           {
            remove(keyAction);
            addAfter(next, keyAction);
            keyAction = next;
            swap = true;
           }
         }
       }
     } while (swap);
   }

   /**
    * Return all the keys in this list of key actions.
    */
   String keys()
   {
    sort();

    // ideally, this method should be called with a length estimate: larger
    // for e.g., the text-area keys, small for keyAction.keyActionList()s...
    StringBuffer keys = new StringBuffer(1500);
    boolean first = true;
    for (KeyAction keyAction = (KeyAction)first();
         keyAction != null;
         keyAction = (KeyAction)keyAction.next())
     {
      if (!first)
       {
        keys.append(' ');
       }
      first = false;

      if (keyAction.keyActionList() != null)
       {
        keys.append(keyAction.keyActionList().keys());
       }
      else
       {
        keys.append(keyAction.keyString());
       }
     }
    return keys.toString();
   }


   /**
    * LPEX key action for our KeyActionList:  an action assignment for a
    * specified key or series of keys.
    */
   final class KeyAction extends ListNode
   {
    private int     _modifiers;
    private Key     _key;

    // several keys can trigger the same action, but only one key can be
    // defined as the primary key for an action (it is the one that will
    // appear as the accelerator on menus)
    private boolean _secondary;

    private String  _actionString;
    private int     _actionId;
    private KeyActionList _keyActionList;

    /**
     * Constructor.
     */
    KeyAction(int modifiers, Key key, boolean secondary, String actionString)
    {
     // ignore Shift modifier for keys that can only be entered via it
     if (key.ignoreShift())
      {
       modifiers &= ~KEY_SHIFT;
      }

     _modifiers = modifiers;
     _key = key;
     _secondary = secondary;
     _actionString = actionString;    // this KeyAction is for a
     //_keyActionList = null;         //  single-key to action assignment...
     _actionId = ACTION_INVALID;
    }

    /**
     * Constructor.
     */
    KeyAction(int modifiers, Key key, KeyActionList keyActionList)
    {
     // ignore Shift modifier for keys that can only be entered via it
     if (key.ignoreShift())
      {
       modifiers &= ~KEY_SHIFT;
      }

     _modifiers = modifiers;
     _key = key;
     //_secondary = false;
     //_actionString = null;          // this KeyAction is for just one key in a
     _keyActionList = keyActionList;  //  series of keys assigned to an action...
     _actionId = ACTION_INVALID;
    }

    int actionId()
    {
     if (_actionId == ACTION_INVALID) // (_actionId is established lazily, so
      {                               //  we don't waste time in constructor)
       _actionId = id(_actionString);
      }
     return _actionId;
    }

    int modifiers()
    {
     return _modifiers;
    }

    Key key()
    {
     return _key;
    }

    String actionString()
    {
     return _actionString;
    }

    String keyString()
    {
     StringBuffer keyString = new StringBuffer(32);

     if (KEY_META != KEY_ALT && //don't duplicate (m-a-key) on SWT Windows...
         (_modifiers & KEY_META) != 0)
      {
       keyString.append("m-");
      }
     if ((_modifiers & KEY_CTRL) != 0)
      {
       keyString.append("c-");
      }
     if ((_modifiers & KEY_ALT) != 0)
      {
       keyString.append("a-");
      }
     if ((_modifiers & KEY_SHIFT) != 0)
      {
       keyString.append("s-");
      }

     keyString.append(_key.keyName());

     if (_keyActionList == null)
      {
       if ((_context & CONTEXT_TEXT_AREA) != 0)
        {
         keyString.append(".t");
        }
       if ((_context & CONTEXT_PREFIX_AREA) != 0)
        {
         keyString.append(".p");
        }
       if ((_context & CONTEXT_COMMAND_LINE) != 0)
        {
         keyString.append(".c");
        }
       if (_secondary)
        {
         keyString.append(".secondary");
        }
      }

     String prefixKeyString = "";
     for (KeyAction prefixKeyAction = prefixKeyAction();
          prefixKeyAction != null;
          prefixKeyAction = prefixKeyAction.prefixKeyAction())
      {
       prefixKeyString = prefixKeyAction.keyString() + ',' + prefixKeyString;
      }
     return prefixKeyString + keyString.toString();
    }

    boolean secondary()
    {
     return _secondary;
    }

    void setSecondary(boolean secondary)
    {
     _secondary = secondary;
    }

    boolean keyEquals(int modifiers, Key key)
    {
     // ignore Shift modifier for keys that can only be entered via it
     if (key.ignoreShift())
      {
       modifiers &= ~KEY_SHIFT;
      }

     return (_modifiers == modifiers) && (_key == key);
    }

    /**
     * Is this KeyAction setting the primary key for the action specified?
     */
    boolean primaryKey(int actionId)
    {
     return !_secondary && actionId == actionId();
    }

    /**
     * Is this KeyAction setting the primary key for the action specified?
     */
    boolean primaryKey(String actionString)
    {
     return !_secondary && actionString.equals(_actionString);
    }

    void resetActionId()
    {
     _actionId = ACTION_INVALID;
    }

    KeyActionList keyActionList()
    {
     return _keyActionList;
    }

    KeyAction prefixKeyAction()
    {
     return _prefixKeyAction;
    }
   }

  }


  /**
   * A list of mouse actions.
   * Three mouse-action lists are maintained for a view:  one for the text-edit
   * area, one for the prefix-commands area, and one for the expand/hide area.
   */
  final class MouseActionList extends List
  {
   private int _context;

   /**
    * Construct a mouse-action list for a given context:  the text area,
    * the prefix area, or the expand/hide area.
    */
   MouseActionList(int context)
   {
    _context = context;
   }

   void defineMouseAction(int modifiers, int eventId, int clickCount,
                          String actionString)
   {
    MouseAction mouseAction = findMouseEvent(modifiers, eventId, clickCount);
    if (mouseAction != null)
     {
      remove(mouseAction);
     }
    if (actionString != null && actionString.length() > 0)
     {
      mouseAction = new MouseAction(modifiers, eventId, clickCount, actionString);
      addBefore(null, mouseAction);
     }
   }

   MouseAction findMouseEvent(int modifiers, int eventId, int clickCount)
   {
    MouseAction mouseAction;
    for (mouseAction = (MouseAction) first();
         mouseAction != null &&
           !mouseAction.mouseEventEquals(modifiers, eventId, clickCount);
         mouseAction = (MouseAction) mouseAction.next()) {}
    if (mouseAction != null)
     {
      remove(mouseAction);
      addAfter(null, mouseAction);
     }
    return mouseAction;
   }

   void actionRemoved(int actionId)
   {
    if (actionId >= ACTION_USER)
     {
      MouseAction mouseAction;
      for (mouseAction = (MouseAction) first();
           mouseAction != null;
           mouseAction = (MouseAction) mouseAction.next())
       {
        if (mouseAction.actionId() == actionId)
         {
          mouseAction.resetActionId();
         }
       }
     }
   }

   void sort()
   {
    boolean swap;
    do
     {
      swap = false;
      for (MouseAction mouseAction = (MouseAction)first();
           mouseAction != null;
           mouseAction = (MouseAction)mouseAction.next())
       {
        MouseAction next = (MouseAction)mouseAction.next();
        if (next != null)
         {
          if (mouseAction.event().compareTo(next.event()) > 0)
           {
            remove(mouseAction);
            addAfter(next, mouseAction);
            mouseAction = next;
            swap = true;
           }
         }
       }
     } while (swap);
   }

   String mouseEvents()
   {
    sort();

    StringBuffer mouseEvents = new StringBuffer(450);
    boolean first = true;
    for (MouseAction mouseAction = (MouseAction)first();
         mouseAction != null;
         mouseAction = (MouseAction)mouseAction.next())
     {
      if (!first)
       {
        mouseEvents.append(' ');
       }
      first = false;
      mouseEvents.append(mouseAction.event());
     }
    return mouseEvents.toString();
   }


   /**
    * LPEX mouse action for our MouseActionList.
    */
   final class MouseAction extends ListNode
   {
    private int    _modifiers;
    private int    _eventId;
    private int    _clickCount;
    private String _actionString;
    private int    _actionId;

    MouseAction(int modifiers, int eventId, int clickCount, String actionString)
    {
     _modifiers = modifiers;
     _eventId = eventId;
     _clickCount = clickCount;
     if (_eventId == MOUSE_EVENT_POPUP)
      {
       _modifiers = 0;
       _clickCount = 0;
      }
     _actionString = actionString;
     _actionId = ACTION_INVALID;
    }

    int actionId()
    {
     if (_actionId == ACTION_INVALID)
      {
       _actionId = id(_actionString);
      }
     return _actionId;
    }

    int modifiers()
    {
     return _modifiers;
    }

    int eventId()
    {
     return _eventId;
    }

    int clickCount()
    {
     return _clickCount;
    }

    String actionString()
    {
     return _actionString;
    }

    String event()
    {
     StringBuffer event = new StringBuffer(28);

     if ((_modifiers & SWT.BUTTON3) != 0) // swt
      {
       event.append("3-");
      }
     if ((_modifiers & SWT.BUTTON2) != 0) // swt
      {
       event.append("2-");
      }
     if ((_modifiers & SWT.BUTTON1 /*awt: MouseEvent.BUTTON1_MASK*/) != 0)
      {
       event.append("1-");
      }
     if ((_modifiers & SWT.ALT) != 0)     // swt
      {
       event.append("a-");
      }
     //awt: also handles MouseEvent.META_MASK, conflict of identical mask defines
     if ((_modifiers & SWT.CTRL /*awt: MouseEvent.CTRL_MASK*/) != 0)
      {
       event.append("c-");
      }
     if ((_modifiers & SWT.SHIFT /*awt: MouseEvent.SHIFT_MASK*/) != 0)
      {
       event.append("s-");
      }

     TableNode tableNode = TableNode.sequentialSearch(_mouseEvents, _eventId);
     event.append((tableNode != null)? tableNode.string() : "???");

     if (_clickCount > 0)
      {
       event.append('.').append(_clickCount);
      }
     if ((_context & CONTEXT_TEXT_AREA) != 0)
      {
       event.append(".t");
      }
     if ((_context & CONTEXT_PREFIX_AREA) != 0)
      {
       event.append(".p");
      }
     if ((_context & CONTEXT_EXPAND_HIDE_AREA) != 0)
      {
       event.append(".e");
      }

     return event.toString();
    }

    boolean mouseEventEquals(int modifiers, int eventId, int clickCount)
    {
     if (eventId == MOUSE_EVENT_POPUP && _eventId == MOUSE_EVENT_POPUP)
      {
       return true;
      }
     return _modifiers == modifiers &&
            _eventId == eventId &&
            _clickCount == clickCount;
    }

    void resetActionId()
    {
     _actionId = ACTION_INVALID;
    }
   }
  }


  /**
   * This class is used to manage a list of Actions.
   */
  final static class ActionList extends List
  {
   // Locate the action assigned to the specified action id.
   Action find(int id)
   {
    for (Node current = first(); current != null; current = current.next())
     {
      if (((Action)current).id() == id)
       {
        return (Action) current;
       }
     }
    return null;
   }

   // Locate the action assigned to the specified name string.
   Action find(String actionString)
   {
    for (Node current = first(); current != null; current = current.next())
     {
      if (((Action)current).actionString().equals(actionString))
       {
        return (Action) current;
       }
     }
    return null;
   }

   // Sort the list of Actions by their name.
   void sort()
   {
    boolean swap;
    do
     {
      swap = false;
      for (Action action = (Action)first();
           action != null;
           action = (Action)action.next())
       {
        Action next = (Action)action.next();
        if (next != null)
         {
          if (action.actionString().compareTo(next.actionString()) > 0)
           {
            remove(action);
            addAfter(next, action);
            action = next;
            swap = true;
           }
         }
       }
     }
    while (swap);
   }
  }


  /**
   * This class is used to manage an action.
   */
  final static class Action extends ListNode
  {
   private int        _id;
   private String     _actionString;
   private LpexAction _lpexAction;

   /**
    * Construct an action instance:
    * the action id, the action name, and the LpexClass implementing it.
    */
   Action(int id, String actionString, LpexAction lpexAction)
   {
    _id = id;
    _actionString = actionString;
    _lpexAction = lpexAction;
   }

   int id()
   {
    return _id;
   }

   String actionString()
   {
    return _actionString;
   }

   LpexAction lpexAction()
   {
    return _lpexAction;
   }
  }
 }