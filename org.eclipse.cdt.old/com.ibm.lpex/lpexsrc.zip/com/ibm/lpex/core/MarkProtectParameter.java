//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// MarkProtectParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class MarkProtectParameter extends ParameterOnOffOnly
{
 private static MarkProtectParameter _parameter;

 static MarkProtectParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new MarkProtectParameter();
   }
  return _parameter;
 }

 private MarkProtectParameter()
 {
  super(PARAMETER_MARK_PROTECT);
 }

 boolean setValue(View view, String qualifier, boolean value)
 {
  if (view != null)
   {
    MarkList.Mark mark = view.markList().find(qualifier);
    if (mark != null)
     {
      mark.setProtect(value);
     }
   }

  return true;
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return view != null && view.markList().find(qualifier) != null;
 }

 boolean value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    MarkList.Mark mark = view.markList().find(qualifier);
    if (mark != null)
     {
      return mark.protect();
     }
   }

  return false;
 }
}