//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ShowSosiParameter - handles the showSosi parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>showSosi</b> parameter.
 * Parameter scope:  document view.
 *
 * The Parameter class it extends provides the framework for handling
 * parameters in LPEX (setting install values, the SET and QUERY commands, etc.).
 */
final class ShowSosiParameter extends ParameterOnOffDefault
{
   /**
    * The singleton ShowSosiParameter (static _parameter) object handles (by
    * mostly delegating to View) showSosi for all the views (note that all its
    * methods have a View argument passed in).
    *
    * The actual value of a view's showSosi is stored in the View (_showSosi,
    * initialized to Parameter.DEFAULT).
    * View has the actual methods to:
    *   setShowSosi() [to ON, OFF, DEFAULT],
    *   get showSosi() [ON, OFF, DEFAULT, INSTALL],
    *   get currentShowSosi() [view's currently effective true/false value], and
    *   handle a showSosiChanged() notification for the view.
    */
   private static ShowSosiParameter _parameter;

   static ShowSosiParameter getParameter ()
   {
      if (_parameter == null)
         _parameter = new ShowSosiParameter();
      return _parameter;
   }

   /**
    * Private constructor - ShowSosiParameter is not instantiated directly, but
    * via a first call to ShowSosiParameter.getParameter().
    */
   private ShowSosiParameter ()
   {
      // construct a Parameter.OnOffDefault with the _name PARAMETER_SHOW_SOSI,
      // and a _hardCodedValue = true (ON).
      super(PARAMETER_SHOW_SOSI, true);
   }

   /**
    * Set the showSosi parameter (delegate it to the View.setShowSosi()).
    * @param  value  Parameter.ON, .OFF, .DEFAULT (one of .ON, .OFF, .INSTALL)
    */
   boolean setValue (View view, int value)
   {
      if (view != null)
         view.setShowSosi(value);
      return true;
   }

   /**
    * Handle the notification of a change in the actual true/false value of the
    * view's showSosi parameter (delegate it to the View.showSosiChanged()).
    */
   void currentValueChanged (View view)
   {
      view.showSosiChanged();
   }

   /**
    * Get the showSosi parameter (delegate it to the View.showSosi()).
    * @return  Parameter.ON, .OFF, .DEFAULT (in .ON, .OFF, .INSTALL), .INSTALL
    */
   int value (View view)
   {
      return (view != null)? view.showSosi() : Parameter.DEFAULT;
   }
}