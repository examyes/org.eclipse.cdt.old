//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Block - manage the block selection.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class is used to manage the editor block selection.
 * There is only one block selection, regardless of the number of documents
 * and views.
 */
final class Block
{
 // block types
 final static int
  NONE      = 0, // TYPE_FIRST
  STREAM    = 1,
  CHARACTER = 2,
  RECTANGLE = 3,
  ELEMENT   = 4; // TYPE_LAST

 private static int     _type = NONE;
 private static View    _view;
 private static Element _anchorElement;
 private static int     _anchorPosition;
 private static Element _selectionElement;
 private static int     _selectionPosition;


 static int type()
  {
   return _type;
  }

 static boolean anythingSelected()
  {
   if (!selectionVisible())
    {
     return false;
    }
   if (_type == STREAM && _anchorElement == _selectionElement &&
       _anchorPosition == _selectionPosition)
    {
     return false;
    }

   return true;
  }

 static boolean anythingUnprotectedSelected()
  {
   if (anythingSelected())
    {
     Element lastElement = bottomElement().next();
     for (Element element = topElement();
          element != lastElement;
          element = element.next())
      {
       if (element.visible(_view) && !_view.markList().protect(element))
        {
         return true;
        }
      }
    }

   return false;
  }

 static boolean anythingProtectedSelected()
  {
   if (anythingSelected())
    {
     Element lastElement = bottomElement().next();
     for (Element element = topElement();
          element != lastElement;
          element = element.next())
      {
       if (element.visible(_view) && _view.markList().protect(element))
        {
         return true;
        }
      }
    }

   return false;
  }

 private static boolean selectionVisible()
  {
   return topElement() != null;
  }

 static View view()
  {
   return _view;
  }

 static Element anchorElement()
  {
   return _anchorElement;
  }

 static int anchorPosition()
  {
   int position = _anchorPosition;
   if (_type == ELEMENT)
    {
     if (anchorAtTop())
      {
       position = 1;
      }
     else if (_anchorElement != null)
      {
       position = _anchorElement.end();
      }
    }
   return position;
  }

 // n/u
 // static Element selectionElement()
 // {
 //  return _selectionElement;
 // }

 // n/u
 // static int selectionPosition()
 // {
 //  int position = _selectionPosition;
 //  if (_type == ELEMENT)
 //   {
 //    if (!anchorAtTop())
 //     {
 //      position = 1;
 //     }
 //    else if (_selectionElement != null)
 //     {
 //      position = _selectionElement.end();
 //     }
 //   }
 //  return position;
 // }

 static void set(int type, View view, Element element, int position)
  {
   if (element != null)
    {
     if (type < NONE || type > ELEMENT)
      {
       type = NONE;
      }
     if (type != _type || type == NONE || view != _view || !selectionVisible())
      {
       clear();
      }

     if (type != NONE)
      {
       if (_type == NONE)
        {
         _type = type;
         _view = view;
         _anchorElement = element;
         _anchorPosition = position;
        }
       _selectionElement = element;
       _selectionPosition = position;
      }
    }
  }

 static void set(int type, View view)
  {
   if (view != null)
    {
     set(type, view, view.documentPosition().element(), view.documentPosition().position());
    }
  }

 static void set(View view)
  {
   if (view != null)
    {
     int type = _type;
     if (type == NONE || !selectionVisible())
      {
       type = BlockCommand.DefaultTypeParameter.getParameter().currentValue(view);
      }
     set(type, view);
    }
  }

 /**
  * Clear the block (unselect).
  */
 static void clear()
  {
   _view = null;
   _anchorElement = null;
   _selectionElement = null;
   _type = NONE;
  }

 static void validate()
  {
   if (_type == STREAM)
    {
     DocumentPosition documentPosition = _view.documentPosition();
     if (documentPosition.element() != _selectionElement ||
         documentPosition.position() != _selectionPosition)
      {
       clear();
      }
    }
  }

 static boolean anchorAtTop()
  {
   boolean anchorAtTop = false;
   if (_anchorElement != null)
    {
     if (_anchorElement != _selectionElement)
      {
       ElementList elementList = _view.document().elementList();
       anchorAtTop = elementList.ordinalOf(_anchorElement) <=
                     elementList.ordinalOf(_selectionElement);
      }
     else
      {
       if (_type != ELEMENT)
        {
         anchorAtTop = _anchorPosition <= _selectionPosition;
        }
       else
        {
         anchorAtTop = true;
        }
      }
    }

   return anchorAtTop;
  }

 static void elementRemoved(Element element)
  {
   if (element == _anchorElement)
    {
     if (_type == STREAM || _anchorElement == _selectionElement)
      {
       clear();
      }
     else
      {
       if (anchorAtTop())
        {
         _anchorElement = element.next();
         _anchorPosition = 1;
        }
       else
        {
         _anchorElement = element.prev();
         _anchorPosition = _anchorElement.length();
         if (_anchorPosition == 0)
          {
           _anchorPosition = 1;
          }
        }

       if (_anchorElement == null)
        {
         clear();
        }
      }
    }

   if (element == _selectionElement)
    {
     if (_type == STREAM)
      {
       clear();
      }
     else
      {
       if (!anchorAtTop())
        {
         _selectionElement = element.next();
         _selectionPosition = 1;
        }
       else
        {
         _selectionElement = element.prev();
         _selectionPosition = element.length();
         if (_selectionPosition == 0)
          {
           _selectionPosition = 1;
          }
        }

       if (_selectionElement == null)
        {
         clear();
        }
      }
    }
  }

 static boolean partOfBlock(View view, Element element)
  {
   boolean partOfBlock = false;
   if (view != null && element != null && view == _view)
    {
     if (element.visible(_view) && anythingSelected())
      {
       ElementList elementList = view.document().elementList();
       int topOrdinal = elementList.ordinalOf(topElement());
       int bottomOrdinal = elementList.ordinalOf(bottomElement());
       int elementOrdinal = elementList.ordinalOf(element);
       partOfBlock = elementOrdinal >= topOrdinal &&
                     elementOrdinal <= bottomOrdinal;
      }
    }
   return partOfBlock;
  }

 // n/u
 // private static boolean partOfBlock(View view, LpexDocumentLocation documentLocation)
 // {
 // boolean partOfBlock = false;
 // Element element = view.document().elementList().elementAt(documentLocation.element);
 // if (partOfBlock(view, element))
 //  {
 //   switch (_type)
 //    {
 //     case STREAM:
 //      {
 //       partOfBlock = (element != topElement() ||
 //                      topPosition() <= documentLocation.position) &&
 //                     (element != bottomElement() ||
 //                      bottomPosition() > documentLocation.position);
 //       break;
 //      }
 //     case CHARACTER:
 //      {
 //       partOfBlock = (element != topElement() ||
 //                      topPosition() <= documentLocation.position) &&
 //                     (element != bottomElement() ||
 //                      bottomPosition() >= documentLocation.position);
 //       break;
 //      }
 //     case ELEMENT:
 //      {
 //       partOfBlock = true;
 //       break;
 //      }
 //     case RECTANGLE:
 //      {
 //       int pixelPosition = element.elementView(_view).pixelPosition(documentLocation.position);
 //       partOfBlock = pixelPosition >= leftPixelPosition() &&
 //                     pixelPosition < rightPixelPosition();
 //       break;
 //      }
 //     default:
 //      {
 //       break;
 //      }
 //    }
 //  }
 // return partOfBlock;
 // }

 private static boolean allShow()
  {
   Element lastElement = bottomElement().next();
   for (Element element = topElement();
        element != lastElement;
        element = element.next())
    {
     if (element.visible(_view))
      {
       if (!element.show())
        {
         return false;
        }
      }
    }
   return true;
  }

 static Element topElement()
  {
   Element lastElement = anchorAtTop()? _selectionElement : _anchorElement;
   if (lastElement != null)
    {
     lastElement = lastElement.next();
    }
   for (Element topElement = anchorAtTop()? _anchorElement : _selectionElement;
        topElement != null && topElement != lastElement;
        topElement = topElement.next())
    {
     if (topElement.visible(_view))
      {
       return topElement;
      }
    }

   return null;
  }

 static int topPosition()
  {
   Element topElement = topElement();
   if (anchorAtTop())
    {
     if (_type == ELEMENT || topElement != _anchorElement)
      {
       return 1;
      }
     return _anchorPosition;
    }

   if (_type == ELEMENT || topElement != _selectionElement)
    {
     return 1;
    }

   return _selectionPosition;
  }

 static Element bottomElement()
  {
   Element firstElement = anchorAtTop()? _anchorElement : _selectionElement;
   if (firstElement != null)
    {
     firstElement = firstElement.prev();
    }

   for (Element bottomElement = anchorAtTop()? _selectionElement : _anchorElement;
        bottomElement != null && bottomElement != firstElement;
        bottomElement = bottomElement.prev())
    {
     if (bottomElement.visible(_view))
      {
       return bottomElement;
      }
    }

   return null;
  }

 static int bottomPosition()
  {
   Element bottomElement = bottomElement();
   if (anchorAtTop())
    {
     if (_type == ELEMENT || bottomElement != _selectionElement)
      {
       return (bottomElement != null)? bottomElement.end() : 1;
      }
     return _selectionPosition;
    }

   if (_type == ELEMENT || bottomElement != _anchorElement)
    {
     return (bottomElement != null)? bottomElement.end() : 1;
    }

   return _anchorPosition;
  }

 static int leftPixelPosition()
  {
   if (_type != RECTANGLE || !anythingSelected())
    {
     return 0;
    }

   int leftTop = topElement().elementView(_view).
                 pixelPosition(topPosition());
   int leftBottom = bottomElement().elementView(_view).
                    pixelPosition(bottomPosition());
   return (leftTop < leftBottom)? leftTop : leftBottom;
  }

 static int rightPixelPosition()
  {
   if (_type != RECTANGLE || !anythingSelected())
    {
     return 0;
    }

   int rightTop = topElement().elementView(_view).
                  pixelCharPosition(topPosition()+1);
   int rightBottom = bottomElement().elementView(_view).
                     pixelCharPosition(bottomPosition()+1);
   return (rightBottom > rightTop)? rightBottom : rightTop;
  }

 static int leftPosition(View view, Element element)
  {
   if (!partOfBlock(view, element) || element.text().length() == 0)
    {
     return 0;
    }

   int leftPosition = 1;
   switch (_type)
    {
     case STREAM:
     case CHARACTER:
      {
       if (topElement() == element)
        {
         leftPosition = topPosition();
        }
       else if (_type == STREAM && bottomElement() == element && bottomPosition() <= 1)
        {
         leftPosition = 0;
        }
       break;
      }
     case RECTANGLE:
      {
       leftPosition = view.position(element.elementView(view), leftPixelPosition());
      }
    }

   if (element.text().length() < leftPosition)
    {
     leftPosition = 0;
    }

   return leftPosition;
  }

 static int rightPosition(View view, Element element)
  {
   if (!partOfBlock(view, element) || element.text().length() == 0)
    {
     return 0;
    }

   int rightPosition = element.text().length();
   switch (_type)
    {
     case STREAM:
     case CHARACTER:
      {
       if (bottomElement() == element)
        {
         int rightBlockPosition = bottomPosition();
         if (_type == STREAM)
          {
           rightBlockPosition--;
          }
         if (rightBlockPosition < rightPosition)
          {
           rightPosition = rightBlockPosition;
          }
        }
       else if (topElement() == element && topPosition() > rightPosition)
        {
         rightPosition = 0;
        }
       break;
      }
     case RECTANGLE:
      {
       int rightBlockPosition = view.position(element.elementView(view),
                                              rightPixelPosition() - 1);
       if (rightBlockPosition < rightPosition)
        {
         rightPosition = rightBlockPosition;
        }
      }
    }

   return rightPosition;
  }


 static void delete()
  {
   if (anythingUnprotectedSelected() && _view.changeAllowed())
    {
     View view = _view; // remember block's view (we may clear the block)

     _view.document().resetUserActionElements();
     switch(_type)
      {
       case STREAM:
       case CHARACTER:
        {
         Element topElement = topElement();
         Element bottomElement = bottomElement();
         int topPosition = topPosition();
         int bottomPosition = bottomPosition();
         if (_type == CHARACTER)
          {
           bottomPosition++;
          }
         clear();
         view.deleteText(topElement, topPosition, bottomElement, bottomPosition);
         break;
        }

       case ELEMENT:
        {
         Element element;
         Element next;
         Element first = topElement();
         Element last = bottomElement().next();
         clear();
         for (element = first, next = null;
              element != last && element != null;
              element = next)
          {
           next = element.next();
           if (element.visible(view) && !view.markList().protect(element))
            {
             element.setDeletePending(true);
            }
          }
         boolean forceAllVisible = view.forceAllVisible();
         view.setForceAllVisible(true);
         for (element = first, next = null;
              element != last && element != null;
              element = next)
          {
           next = element.next();
           if (element.deletePending())
            {
             element.setDeletePending(false);
             view.deleteElement(element);
            }
          }
         view.setForceAllVisible(forceAllVisible);
         break;
        }

       case RECTANGLE:
        {
         int leftPosition = leftPixelPosition();
         int rightPosition = rightPixelPosition();

         for (Element element = topElement();
              element != bottomElement().next() && element != null;
              element = element.next())
          {
           if (!element.show() && !_view.markList().protect(element))
            {
             ElementView elementView = element.elementView(_view);
             if (elementView.visible())
              {
               int startPosition = _view.position(elementView, leftPosition);
               int endPosition   = _view.position(elementView, rightPosition-1);
               _view.deleteText(element, startPosition, endPosition - startPosition + 1);
              }
            }
          }
         clear();
         break;
        }

       default:
        {
         return;
        }
      }

     view.verifyDocumentSection(); // ensure document-section boundaries still OK
    }
  }

 static void copy(View view)
  {
   Element element = view.documentPosition().element();
   if (element != null && view.markList().insertElementProtect(element))
    {
     return;
    }

   if (view.changeAllowed())
    {
     view.document().resetUserActionElements();
     String text = selectedText();
     insertText(view, text, _type);
    }
  }

 static void move(View view)
  {
   if (anythingSelected() && !anythingProtectedSelected() &&
       _view.changeAllowed() && view.changeAllowed())
    {
     view.document().resetUserActionElements();
     _view.document().resetUserActionElements();
     String text = selectedText();
     int type = _type;
     delete();
     insertText(view, text, type);
    }
  }

 static void overlay(View view)
  {
   overlay(view, false);
  }

 static void overlay(View view, boolean transparent)
  {
   Element element = view.documentPosition().element();
   if ((_type == ELEMENT || _type == RECTANGLE) &&
       !element.show() && !view.markList().protect(element) && view.changeAllowed())
    {
     int type = _type;
     view.document().resetUserActionElements();
     int position = view.documentPosition().position();
     String text = selectedText();
     if (_type == RECTANGLE)
      {
       view.overlayRectangle(text, transparent);
      }
     else
      {
       view.overlayElements(text, transparent);
      }

     // re-set the block after the operation
     clear();
     set(type, view, element, position);
     int endPosition = view.documentPosition().position();
     if (type == RECTANGLE && endPosition > 1)
      {
       endPosition--;
      }

     set(type, view, view.documentPosition().element(), endPosition);
    }
  }

 // called from copy() and move()
 private static void insertText(View view, String text, int type)
  {
   Element element = view.documentPosition().element();
   boolean ignoreFieldsSet = false;
   if (type == ELEMENT || element == null || element.show() || view.markList().protect(element))
    {
     view.documentPosition().end();
     view.insertText("\n");
     view.setIgnoreFields();
     ignoreFieldsSet = true;
    }

   if (text != null)
    {
     Element startElement = view.documentPosition().element();
     int startPosition = view.documentPosition().position();
     if (type == RECTANGLE)
      {
       view.insertTextRectangle(text);
      }
     else
      {
       view.insertText(text);
      }

     // re-set the block after the operation
     clear();
     set(type, view, startElement, startPosition);
     int endPosition = view.documentPosition().position();
     if ((type == CHARACTER || type == RECTANGLE) &&
         endPosition > 1)
      {
       endPosition--;
      }
     set(type, view, view.documentPosition().element(), endPosition);
    }

   if (ignoreFieldsSet)
    {
     view.resetIgnoreFields();
    }
  }

 static void upperCase()
  {
   changeCase(true);
  }

 static void lowerCase()
  {
   changeCase(false);
  }

 private static void changeCase(boolean upperCase)
  {
   if (anythingUnprotectedSelected() && _view.changeAllowed())
    {
     _view.document().resetUserActionElements();
     int bottomPosition = bottomPosition();
     if (_type == CHARACTER)
      {
       bottomPosition++;
      }
     _view.changeCase(topElement(), topPosition(),
                      bottomElement(), bottomPosition,
                      upperCase, _type == RECTANGLE);
    }
  }

 /**
  * Fill the block with repeating fillString characters.
  */
 static void fill(String fillString)
  {
   if (anythingUnprotectedSelected() && _view.changeAllowed())
    {
     _view.document().resetUserActionElements();
     Element topElement = topElement();
     Element bottomElement = bottomElement();
     Element lastElement = bottomElement.next();

     for (Element element = topElement;
          element != lastElement;
          element = element.next())
      {
       if (!element.show())
        {
         ElementView elementView = element.elementView(_view);
         if (elementView.visible())
          {
           switch (_type)
            {
             case STREAM:
             case CHARACTER:
              {
               if (element == topElement && element == bottomElement)
                {
                 int length = bottomPosition() - topPosition();
                 if (_type == CHARACTER)
                  {
                   length += 1;
                  }
                 _view.fill(element, topPosition(), length, fillString);
                }
               else if (element == topElement)
                {
                 _view.fill(element, topPosition(), fillString);
                }
               else if (element == bottomElement)
                {
                 int length = bottomPosition();
                 if (_type == STREAM)
                  {
                   length -= 1;
                  }
                 _view.fill(element, 1, length, fillString);
                }
               else
                {
                 _view.fill(element, fillString);
                }
               break;
              }

             case ELEMENT:
              {
               _view.fill(element, fillString);
               break;
              }

             case RECTANGLE:
              {
               int leftPosition  = _view.position(elementView, leftPixelPosition());
               int rightPosition = _view.position(elementView, rightPixelPosition()-1);
               _view.fill(element, leftPosition, rightPosition - leftPosition + 1,
                          fillString);
               break;
              }

             default:
            }
          }
        }
      }
    }
  }

 static void shift(int count)
  {
   if ((_type == ELEMENT || _type == RECTANGLE) &&
       anythingUnprotectedSelected() && _view.changeAllowed())
    {
     _view.document().resetUserActionElements();
     Element topElement = topElement();
     Element bottomElement = bottomElement();
     Element lastElement = bottomElement.next();
     for (Element element = topElement;
          element != lastElement;
          element = element.next())
      {
       if (!element.show())
        {
         ElementView elementView = element.elementView(_view);
         if (elementView.visible())
          {
           if (_type == ELEMENT)
            {
             _view.shift(element, count);
            }
           else
            {
             int position = _view.position(elementView, leftPixelPosition());
             _view.shift(element, position, count);
            }
          }
        }
      }

     if (_type == RECTANGLE)
      {
       _selectionPosition += count;
       _anchorPosition += count;
       if (_selectionPosition <= 0)
        {
         _selectionPosition = 1;
        }
       if (_anchorPosition <= 0)
        {
         _anchorPosition = 1;
        }
      }
    }
  }

 static int selectedTextStart(View view, Element element)
  {
   int start = 0;
   if (partOfBlock(view, element))
    {
     switch(_type)
      {
       case STREAM:
        {
         if (topElement() == bottomElement())
          {
           if (element == topElement())
            {
             start = topPosition();
            }
          }
         else if (element == topElement())
          {
           if (topPosition() <= element.length())
            {
             start = topPosition();
            }
          }
         else if (element == bottomElement())
          {
           if (bottomPosition() > 1)
            {
             start = 1;
            }
          }
         else
          {
           if (element.length() > 0)
            {
             start = 1;
            }
          }
         break;
        }

       case CHARACTER:
        {
         if (topElement() == bottomElement())
          {
           if (element == topElement())
            {
             start = topPosition();
            }
          }
         else if (element == topElement())
          {
           if (topPosition() <= element.length())
            {
             start = topPosition();
            }
          }
         else if (element == bottomElement())
          {
           start = 1;
          }
         else
          {
           if (element.length() > 0)
            {
             start = 1;
            }
          }
         break;
        }

       case ELEMENT:
        {
         if (element.length() > 0)
          {
           start = 1;
          }
         break;
        }

       case RECTANGLE:
        {
         start = _view.position(element.elementView(_view), leftPixelPosition());
         break;
        }

       default:
        {
         break;
        }
      }
    }
   return start;
  }

 static int selectedTextEnd(View view, Element element)
  {
   int end = 0;
   if (partOfBlock(view, element))
    {
     switch(_type)
      {
       case STREAM:
        {
         if (topElement() == bottomElement())
          {
           if (element == topElement())
            {
             end = bottomPosition() - 1;
            }
          }
         else if (element == topElement())
          {
           if (topPosition() <= element.length())
            {
             end = element.length();
            }
          }
         else if (element == bottomElement())
          {
           end = bottomPosition() - 1;
          }
         else
          {
           end = element.length();
          }
         break;
        }

       case CHARACTER:
        {
         if (topElement() == bottomElement())
          {
           if (element == topElement())
            {
             end = bottomPosition();
            }
          }
         else if (element == topElement())
          {
           if (topPosition() <= element.length())
            {
             end = element.length();
            }
          }
         else if (element == bottomElement())
          {
           end = bottomPosition();
          }
         else
          {
           end = element.length();
          }
         break;
        }

       case ELEMENT:
        {
         end = element.length();
         break;
        }

       case RECTANGLE:
        {
         end = _view.position(element.elementView(_view), rightPixelPosition()-1);
         break;
        }
       default:
        {
         break;
        }
      }
    }
   return end;
  }

 static int selectedTextLength(View view, Element element)
  {
   int start = selectedTextStart(view, element);
   int end = selectedTextStart(view, element);
   int len;
   if (start != 0 && end != 0)
    {
     len = end - start + 1;
     if (len < 0)
      {
       len = 0;
      }
    }
   else
    {
     len = 0;
    }

   return len;
  }

 private static int selectedTextLength()
  {
   int len = -1;
   if (anythingSelected())
    {
     len = 0;
     Element element;
     Element lastElement = bottomElement().next();
     boolean first = true;
     boolean includeShow = allShow();
     for (element = topElement();
          element != lastElement;
          element = element.next())
      {
       if (includeShow || !element.show())
        {
         if (element.visible(_view))
          {
           if (!first)
            {
             len += 1; // length of line delimiter ('\n')
            }
           len += selectedTextLength(_view, element);
           first = false;
          }
        }
      }
    }

   return len;
  }

 private static void appendSelectedText(StringBuffer buffer)
  {
   if (anythingSelected())
    {
     Element element;
     Element lastElement = bottomElement().next();
     boolean first = true;
     boolean includeShow = allShow();
     for (element = topElement();
          element != lastElement;
          element = element.next())
      {
       if (includeShow || !element.show())
        {
         if (element.visible(_view))
          {
           if (!first)
            {
             buffer.append('\n'); // append line delimiter
            }
           int start = selectedTextStart(_view, element);
           if (start > 0)
            {
             int end = selectedTextEnd(_view, element);
             String elementText = element.text();
             int elementTextLength = elementText.length();
             for (int i = start; i <= end; i++)
              {
               char c;
               if (i <= elementTextLength)
                {
                 c = elementText.charAt(i - 1);
                }
               else
                {
                 c = ' ';
                }
               buffer.append(c);
              }
            }
           first = false;
          }
        }
      }
    }
  }

 static String selectedText()
  {
   if (selectedTextLength() >= 0)
    {
     StringBuffer text = new StringBuffer(selectedTextLength());
     appendSelectedText(text);
     return text.toString();
    }

   return null;
  }

 static void copyToClipboard()
  {
   int len = selectedTextLength();
   if (len >= 0)
    {
     StringBuffer text = new StringBuffer(len+1);
     appendSelectedText(text);
     if (_type == ELEMENT)
      {
       text.append('\n'); // append line delimiter
      }
     LpexUtilities.setClipboardContents(text.toString());
    }
  }

 static void cutToClipboard()
  {
   if (anythingSelected() && !anythingProtectedSelected() && _view.changeAllowed())
    {
     copyToClipboard();
     delete();
    }
  }
}