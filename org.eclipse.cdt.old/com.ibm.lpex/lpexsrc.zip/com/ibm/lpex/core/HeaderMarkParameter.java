//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// HeaderMarkParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class HeaderMarkParameter extends ParameterQuery
{
 private static HeaderMarkParameter _parameter;

 static HeaderMarkParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new HeaderMarkParameter();
   }
  return _parameter;
 }

 private HeaderMarkParameter()
 {
  super(PARAMETER_HEADER_MARK);
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null && documentLocation != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    MarkList.Mark mark = view.markList().headerMark(element);
    if (mark != null)
     {
      return mark.name();
     }
   }

  return null;
 }
}