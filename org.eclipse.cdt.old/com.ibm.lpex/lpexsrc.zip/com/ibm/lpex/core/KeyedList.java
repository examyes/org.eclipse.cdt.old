//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// KeyedList - manages a list of keyed values.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class is used to manage a list of keyed values.
 */
final class KeyedList extends List
{
 Object query(String key)
 {
  if (key != null)
   {
    KeyedNode keyedNode = find(key);
    if (keyedNode != null)
     {
      return keyedNode._value;
     }
   }

  return null;
 }

 void set(String key, Object value)
 {
  if (key != null)
   {
    KeyedNode keyedNode = find(key);
    if (keyedNode != null)
     {
      if (value == null)
       {
        remove(keyedNode);
       }
      else
       {
        keyedNode._value = value;
       }
     }

    else
     {
      if (value != null)
       {
        keyedNode = new KeyedNode(key, value);
        addAfter(null, keyedNode);
       }
     }
   }
 }

 String keyList()
 {
  sort();

  StringBuffer keyList = null;
  for (KeyedNode keyedNode = (KeyedNode)first();
       keyedNode != null;
       keyedNode = (KeyedNode)keyedNode.next())
   {
    if (keyList == null)
     {
      keyList = new StringBuffer(300);
     }
    if (keyList.length() > 0)
     {
      keyList.append(' ');
     }
    keyList.append(keyedNode._key);
   }

  return (keyList != null)? keyList.toString() : "";
 }

 private KeyedNode find(String key)
 {
  if (key != null)
   {
    for (KeyedNode keyedNode = (KeyedNode)first();
         keyedNode != null;
         keyedNode = (KeyedNode)keyedNode.next())
     {
      if (key.equals(keyedNode._key))
       {
        return keyedNode;
       }
     }
   }

  return null;
 }

 private void sort()
 {
  boolean swap;
  do
   {
    swap = false;
    for (KeyedNode keyedNode = (KeyedNode)first();
         keyedNode != null;
         keyedNode = (KeyedNode)keyedNode.next())
     {
      KeyedNode next = (KeyedNode)keyedNode.next();
      if (next != null)
       {
        if (keyedNode._key.compareTo(next._key) > 0)
         {
          remove(keyedNode);
          addAfter(next, keyedNode);
          keyedNode = next;
          swap = true;
         }
       }
     }
   } while (swap);
 }


 private final static class KeyedNode extends ListNode
 {
  String _key;
  Object _value;

  KeyedNode(String key, Object value)
  {
   _key = key;
   _value = value;
  }
 }
}