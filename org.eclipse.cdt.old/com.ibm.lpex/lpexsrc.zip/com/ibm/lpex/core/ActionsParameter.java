//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ActionsParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ActionsParameter extends ParameterQuery
{
 private static ActionsParameter _parameter;

 static ActionsParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ActionsParameter();
   }
  return _parameter;
 }

 private ActionsParameter()
 {
  super(PARAMETER_ACTIONS);
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.actionHandler().actions() : null;
 }
}