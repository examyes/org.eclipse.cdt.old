//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// InsertTextCommand - handle the insertText command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>insertText</b> command.
 */
final class InsertTextCommand
{
 static boolean doCommand(View view, String parameters)
 {
  if (view != null)
   {
    view.insertText(parameters);
   }
  return true;
 }
}