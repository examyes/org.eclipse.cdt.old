//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SequenceTextParameter - handle the sequenceText parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>sequenceText</b> parameter.
 */
final class SequenceTextParameter extends Parameter
{
 private static SequenceTextParameter _parameter;

 static SequenceTextParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new SequenceTextParameter();
   }
  return _parameter;
 }

 private SequenceTextParameter()
 {
  super(LpexConstants.PARAMETER_SEQUENCE_TEXT);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  if (view != null)
   {
    Element element = view.documentPosition().element();
    if (element != null)
     {
      if (element.show())
       {
        view.setLpexMessageText(LpexConstants.MSG_SEQUENCENUMBERS_SHOWELEMENT);
       }
      else
       {
        element.setSequenceText(parameters);
       }
     }
   }

  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null && documentLocation != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    if (element != null)
     {
      return element.sequenceText();
     }
   }

  return null;
 }
}