//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// EditLine - hex editing of a text element.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

// Placeholder pending SWT implementation...
final class EditLine
{
   EditLine(LpexView lpexView)
   {
      lpexView._view.screen().setMessageText("\"EditLine\" not yet supported in this version...");
   }
}