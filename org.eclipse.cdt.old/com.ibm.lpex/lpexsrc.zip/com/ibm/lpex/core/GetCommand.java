//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// GetCommand - handles the get command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>get</b> command.
 */
final class GetCommand
{
 static boolean doCommand(View view, String parameters)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (!st.hasMoreTokens())
   {
    return CommandHandler.noParameters(view, "get");
   }

  boolean prompt = false;
  String token = st.nextToken();
  if (token.equals("prompt"))
   {
    prompt = true;
    token = st.hasMoreTokens()? st.nextToken() : null;
   }

  if (LpexStringTokenizer.isInvalidQuotedString(token))
   {
    return CommandHandler.invalidQuotedParameter(view, token, "get");
   }
  String fileName = LpexStringTokenizer.removeQuotes(token);

  if (st.hasMoreTokens())
   {
    return CommandHandler.invalidParameter(view, st.nextToken(), "get");
   }

  // command format is correct, now if we have a view do it
  if (view != null)
   {
    if (prompt)
     {
      if (fileName == null || fileName.length() == 0)
       {
        fileName = view.document().name();
       }

      fileName = LpexUtilities.fileDialog(view,
                               LpexResources.message(LpexConstants.MSG_FILEDIALOG_GET),
                               false,
                               fileName);
     }

    if (fileName != null)
     {
      view.get(fileName);
     }
   }

  return true;
 }
}