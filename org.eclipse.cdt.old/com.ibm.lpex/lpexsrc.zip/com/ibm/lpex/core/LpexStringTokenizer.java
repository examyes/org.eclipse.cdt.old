//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexStringTokenizer - parse tokens in a string.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.Enumeration;
import java.util.NoSuchElementException;


/**
 * The string tokenizer class allows an application to break a
 * string into tokens.  The tokenization is similar to the one
 * done by the <code>java.util.StringTokenizer</code> class.
 * The main difference is that a quoted string will be returned
 * as a single token.
 */
public final class LpexStringTokenizer implements Enumeration
{
 private String _str;
 private int    _currentPosition;
 private int    _maxPosition;

 private final static String _delimiters = " \t\n\r\""; // token delimiters
 private final static String _whiteSpace = " \t\n\r";   // white space


 /**
  * Constructs a string tokenizer from the specified string.
  */
 public LpexStringTokenizer(String str)
  {
   _str = str;
   _maxPosition = str.length();
  }

 /**
  * Skips white space.
  */
 private void skipWhiteSpace()
  {
   while (_currentPosition < _maxPosition &&
          _whiteSpace.indexOf(_str.charAt(_currentPosition)) >= 0)
   {
    _currentPosition++;
   }
  }

 /**
  * Tests if there are more tokens available from this tokenizer's string.
  *
  * @return <code>true</code> if there are more tokens available from this
  *         tokenizer's string; <code>false</code> otherwise
  */
 public boolean hasMoreTokens()
  {
   skipWhiteSpace();
   return _currentPosition < _maxPosition;
  }

 /**
  * Returns the next token from this string tokenizer.
  *
  * @return the next token from this string tokenizer
  *
  * @exception NoSuchElementException if there are no more tokens in this
  *              tokenizer's string
  */
 public String nextToken()
  {
   skipWhiteSpace();
   if (_currentPosition >= _maxPosition)
    {
     throw new NoSuchElementException();
    }

   int start = _currentPosition;
   if (_str.charAt(_currentPosition) == '"')
    {
     _currentPosition++;
     while (_currentPosition < _maxPosition)
      {
       char c = _str.charAt(_currentPosition);
       if (c == '"')
        {
         _currentPosition++;
         break;
        }
       if (c == '\\')
        {
         _currentPosition++;
         if (_currentPosition >= _maxPosition)
          {
           break;
          }
        }
       _currentPosition++;
      }
    }

   else
    {
     while ((_currentPosition < _maxPosition) &&
            (_delimiters.indexOf(_str.charAt(_currentPosition)) < 0))
      {
       _currentPosition++;
      }
    }

   return _str.substring(start, _currentPosition);
  }

 /**
  * Returns the same value as the <code>hasMoreTokens()</code>
  * method.  The method is provided so that this class can implement the
  * <code>Enumeration</code> interface.
  *
  * @return <code>true</code> if there are more tokens;
  *         <code>false</code> otherwise
  *
  * @see java.util.Enumeration
  * @see #hasMoreTokens
  */
 public boolean hasMoreElements()
  {
   return hasMoreTokens();
  }

 /**
  * Returns the same value as the <code>nextToken()</code> method,
  * except that its declared return value is <code>Object</code> rather than
  * <code>String</code>.  The method is provided so that this class can
  * implement the <code>Enumeration</code> interface.
  *
  * @return the next token in the string.
  * @exception NoSuchElementException if there are no more tokens in this
  *              tokenizer's string
  *
  * @see java.util.Enumeration
  * @see #nextToken
  */
 public Object nextElement()
  {
   return nextToken();
  }

 /**
  * Calculates the number of times that this tokenizer's
  * <code>nextToken()</code> method can be called before it generates an
  * exception.
  *
  * @return the number of tokens remaining in the string
  *
  * @see #nextToken
  */
 public int countTokens()
  {
   int count = 0;
   int currpos = _currentPosition;

   while (currpos < _maxPosition)
    {
     while ((currpos < _maxPosition) &&
            (_whiteSpace.indexOf(_str.charAt(currpos)) >= 0))
      {
       currpos++;
      }

     if (currpos >= _maxPosition)
      {
       break;
      }

     int start = currpos;
     if (_str.charAt(currpos) == '"')
      {
       currpos++;
       while (currpos < _maxPosition)
        {
         char c = _str.charAt(currpos);
         if (c == '"')
          {
           currpos++;
           break;
          }
         if (c == '\\')
          {
           currpos++;
           if (currpos >= _maxPosition)
            {
             break;
            }
          }
         currpos++;
        }
      }

     else
      {
       while (currpos < _maxPosition &&
              _delimiters.indexOf(_str.charAt(currpos)) < 0)
        {
         currpos++;
        }
      }
     count++;
    }

   return count;
  }

 /**
  * Return any text remaining in the string that is being tokenized.
  */
 public String remainingText()
  {
   if (_currentPosition >= _maxPosition)
    {
     return "";
    }

   if (_whiteSpace.indexOf(_str.charAt(_currentPosition)) >= 0)
    {
     return _str.substring(_currentPosition + 1);
    }

   return _str.substring(_currentPosition);
  }

 /**
  * Convenience routine for adding quotes to a string.  Quotes <code>"</code>
  * are added to the beginning and end of the string, and any quotes and
  * backslashes that are part of the string are prefixed with a backslash.
  */
 public static String addQuotes(String string)
  {
   if (string == null)
    {
     return null;
    }

   int len = string.length();

   StringBuffer quotedString = new StringBuffer(len+8); // estimate result length
   quotedString.append('\"');
   for (int i = 0; i < len; i++)
    {
     char c = string.charAt(i);
     if (c == '\\' || c == '\"')
      {
       quotedString.append('\\');
      }
     quotedString.append(c);
    }
   quotedString.append('\"');

   return quotedString.toString();
  }

 /**
  * Convenience routine for removing quotes from a string.  If the string
  * is <code>null</code>, empty, or doesn't begin with a quote <code>"</code>,
  * the original string is returned.  All backslashes, except those that are
  * prefixed by another backslash, are removed as well.
  *
  * @param string assumes that <code>isValidQuotedString(string)</code> returned
  *               <code>true</code>
  *
  * @see #trimQuotes
  * @see #isValidQuotedString
  */
 public static String removeQuotes(String string)
  {
   if (string != null)
    {
     int len = string.length();
     if (len > 0 && string.charAt(0) == '"')
      {
       StringBuffer unquotedString = new StringBuffer(len);
       for (int i = 1; i < len - 1; i++)
        {
         char c = string.charAt(i);
         if (c == '\\')
          {
           i++;
           c = string.charAt(i);
          }
         unquotedString.append(c);
        }
       return unquotedString.toString();
      }
    }

   return string;
  }

 /**
  * Convenience routine for removing the leading and trailing quotes from a
  * string.  If the string is not a quoted string, then the original string
  * is returned.
  *
  * @see #removeQuotes
  */
 public static String trimQuotes(String string)
  {
   if (string != null) {
      int end = string.length();
      if (end > 0) {
         int start = 0;
         if (string.charAt(0) == '"')
            start = 1;
         if (end > 1 && string.charAt(end-1) == '"')
            end--;
         return string.substring(start, end);
         }
      }

   return string;
  }

 /**
  * Convenience routine for checking if a string is a valid quoted string.
  * A string is a valid quoted string only if it starts with a quote
  * <code>"</code>, ends with a quote, and any imbedded quotes are prefixed
  * with a backslash character <code>\"</code>.  If there are backslash
  * characters in the quoted string, they must be prefixed with another
  * backslash character <code>\\</code>.
  */
 public static boolean isValidQuotedString(String string)
  {
   if (string == null)
    {
     return false;
    }

   int len = string.length();
   if (len < 2 || string.charAt(0) != '"' || string.charAt(len - 1) != '"')
    {
     return false;
    }

   for (int i = 1; i < len - 1; i++)
    {
     char c = string.charAt(i);
     if (c == '\\')
      {
       i++;
       if (i == len - 1)
        {
         return false;
        }
      }
    }

   return true;
  }

 /**
  * Convenience routine for checking if a string is an invalid quoted string.
  * An invalid quoted string starts with a quote but does not have a proper
  * end delimiter.
  *
  * @see #isValidQuotedString
  */
 public static boolean isInvalidQuotedString(String string)
  {
   if (string != null && string.length() > 0 && string.charAt(0) == '"')
    {
     return !isValidQuotedString(string);
    }

   return false;
  }
}