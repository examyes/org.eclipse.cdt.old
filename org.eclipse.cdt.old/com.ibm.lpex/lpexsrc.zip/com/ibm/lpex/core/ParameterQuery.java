//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterQuery
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

abstract class ParameterQuery extends Parameter
{
 ParameterQuery(String name)
 {
  super(name);
 }

 boolean isQueryOnly(String qualifier)
 {
  return true;
 }

 boolean set(View view, String qualifier, String parameters)
 {
  return false;
 }
}