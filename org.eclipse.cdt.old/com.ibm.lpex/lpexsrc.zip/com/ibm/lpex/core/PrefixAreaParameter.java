//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// PrefixAreaParameter - handles the prefixArea parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class PrefixAreaParameter extends ParameterOnOffDefault
{
 private static PrefixAreaParameter _parameter;

 static PrefixAreaParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new PrefixAreaParameter();
   }
  return _parameter;
 }

 private PrefixAreaParameter()
 {
  super(PARAMETER_PREFIX_AREA, false);
 }

 boolean setValue(View view, int value)
 {
  if (view != null)
   {
    view.screen().setPrefixArea(value);
   }
  return true;
 }

 int value(View view)
 {
  return (view != null)? view.screen().prefixArea() : Parameter.DEFAULT;
 }
}