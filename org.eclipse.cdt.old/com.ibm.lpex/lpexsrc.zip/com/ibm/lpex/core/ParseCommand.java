//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParseCommand - handles the parse command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>parse</b> command.
 */
final class ParseCommand
{
 static boolean doCommand(View view, String parameters)
 {
  boolean all = false;

  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    if (token.equals("all"))
     {
      all = true;
     }
    else
     {
      return CommandHandler.invalidParameter(view, token, "parse");
     }

    if (st.hasMoreTokens())
     {
      return CommandHandler.invalidParameter(view, st.nextToken(), "parse");
     }
   }

  if (view != null)
   {
    if (all)
     {
      view.parsePendingList().totalParse();
     }
    else
     {
      view.parsePendingList().parse();
     }
   }

  return true;
 }
}