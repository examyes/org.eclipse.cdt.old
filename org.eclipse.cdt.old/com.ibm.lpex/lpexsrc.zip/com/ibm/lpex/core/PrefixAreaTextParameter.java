//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// PrefixAreaTextParameter - handles the prefixAreaText parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>prefixAreaText</b> parameter.
 * The ParameterDefault class it extends provides the framework for handling
 * parameters with install, default, and current values.
 */
final class PrefixAreaTextParameter extends ParameterDefault
{
 /**
  * A singleton PrefixAreaTextParameter (static _parameter) object handles (by
  * occasionally delegating to View) the view-scoped prefixAreaText for all the
  * views (note that all its methods have a View argument passed in).
  *
  * A view's actual prefixAreaText parameter setting is stored in the View:
  *   int _prefixAreaTextParm
  */
 private static PrefixAreaTextParameter _parameter;

 private boolean _installValueLoaded;
 private int     _installValue;
 private boolean _defaultValueLoaded;
 private int     _defaultValue;


 static PrefixAreaTextParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new PrefixAreaTextParameter();
   }
  return _parameter;
 }

 /**
  * Private constructor - PrefixAreaTextParameter is not instantiated directly,
  * but through the first call to static PrefixAreaTextParameter.getParameter().
  */
 private PrefixAreaTextParameter()
 {
  // construct a ParameterDefault with the name PARAMETER_PREFIX_AREA_TEXT
  super(PARAMETER_PREFIX_AREA_TEXT);

  // listen to changes in the LPEX Install profile, for a possible value
  // change of install.prefixAreaText
  Install.addProfileChangedListener(new Install.ProfileChangedListener()
   {
    public void profileChanged()
     {
      _installValueLoaded = false;
     }
   });

  // listen to changes in the LPEX profile, for a possible value
  // change of default.prefixAreaText
  Profile.addProfileChangedListener(new Profile.ProfileChangedListener()
   {
    public void profileChanged()
     {
      _defaultValueLoaded = false;
     }
   });
 }

 /**
  * Retrieve the install value from the setting in the LPEX Install profile:
  *   install.prefixAreaText=lineNumbers | sequenceNumbers
  * If none defined in this profile, use a hard-coded default value.
  */
 private int installValue()
 {
  if (!_installValueLoaded)
   {
    _installValue = View.PREFIX_AREA_TEXT_LINENUMBERS; // default hard-coded value
    String value = Install.getString(PARAMETER_INSTALL + name());
    if (value != null)
     {
      if (value.equals("sequenceNumbers"))
       {
        _installValue = View.PREFIX_AREA_TEXT_SEQUENCENUMBERS;
       }
     }
    _installValueLoaded = true;
   }

  return _installValue;
 }

 /**
  * Retrieve the default value from the setting in the LPEX profile:
  *   default.prefixAreaText=[lineNumbers | sequenceNumbers]
  * If none defined in this profile, we return NONE in order to
  * use the install value.
  */
 private int defaultValue()
 {
  if (!_defaultValueLoaded)
   {
    String value = Profile.getString(PARAMETER_DEFAULT + name());
    if (value == null)
     {
      _defaultValue = View.PREFIX_AREA_TEXT_NONE; // will use install setting
     }
    else
     {
      if (value.equals("sequenceNumbers"))
       {
        _defaultValue = View.PREFIX_AREA_TEXT_SEQUENCENUMBERS;
       }
      else
       {
        _defaultValue = View.PREFIX_AREA_TEXT_LINENUMBERS;
       }
     }
    _defaultValueLoaded = true;
   }

  return _defaultValue;
 }

 /**
  * Retrieve current actual value of prefixAreaText parameter for a view.
  */
 int currentValue(View view)
 {
  int value = value(view);
  if (value == View.PREFIX_AREA_TEXT_NONE)
   {
    value = defaultValue();
    if (value == View.PREFIX_AREA_TEXT_NONE)
     {
      value = installValue();
     }
   }

  return value;
 }

 /**
  * Process the command:
  *   set prefixAreaText [default | lineNumbers | sequenceNumbers]
  */
 boolean set(View view, String qualifier, String parameters)
 {
  int value = View.PREFIX_AREA_TEXT_NONE;
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    if (token.equals("lineNumbers"))
     {
      value = View.PREFIX_AREA_TEXT_LINENUMBERS;
     }
    else if (token.equals("sequenceNumbers"))
     {
      value = View.PREFIX_AREA_TEXT_SEQUENCENUMBERS;
     }
    else if (token.equals("default"))
     {
      value = View.PREFIX_AREA_TEXT_NONE;
     }
    else
     {
      return CommandHandler.invalidParameter(view, token, "set " + name());
     }

    if (st.hasMoreTokens())
     {
      return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name());
     }
   }

  return setValue(view, value);
 }

 private boolean setValue(View view, int value)
 {
  if (view != null)
   {
    if (view._prefixAreaTextParm != value)
     {
      view._prefixAreaTextParm = value;
      view.setPrefixAreaWidthsInvalid(); // re-set prefix area text for all elements
      }
   }

  return true;
 }

 /**
  * Process the command:
  *   set default.prefixAreaText [install | lineNumbers | sequenceNumbers]
  */
 boolean setDefault(View view, String qualifier, String parameters)
 {
  int value = View.PREFIX_AREA_TEXT_NONE;
  String token = null;

  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    token = st.nextToken();
    if (token.equals("lineNumbers"))
     {
      value = View.PREFIX_AREA_TEXT_LINENUMBERS;
     }
    else if (token.equals("sequenceNumbers"))
     {
      value = View.PREFIX_AREA_TEXT_SEQUENCENUMBERS;
     }
    else if (token.equals("install"))
     {
      value = View.PREFIX_AREA_TEXT_NONE;
     }
    else
     {
      return CommandHandler.invalidParameter(view, token, "set default." + name());
     }

    if (st.hasMoreTokens())
     {
      return CommandHandler.invalidParameter(view, st.nextToken(), "set default." + name());
     }
   }

  _defaultValue = value;
  _defaultValueLoaded = true;
  if (_defaultValue != View.PREFIX_AREA_TEXT_NONE)
   {
    Profile.putString("default." + this.name(), token);
   }
  else
   {
    Profile.remove("default." + this.name());
   }

  return true;
 }

 /**
  * Process the command:
  *   query prefixAreaText
  */
 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    int value = value(view);
    return (value == View.PREFIX_AREA_TEXT_NONE)? "default" : getTypeName(value);
   }

  return null;
 }

 /**
  * Return current value of the parameter for the view,
  * or NONE if its setting is "default".
  */
 int value(View view)
 {
  return (view == null)? View.PREFIX_AREA_TEXT_NONE : view._prefixAreaTextParm;
 }

 /**
  * Process the command:
  *   query install.prefixAreaText
  *
  * @return "lineNumbers" or "sequenceNumbers"
  */
 String queryInstall(String qualifier)
 {
  return getTypeName(installValue());
 }

 /**
  * Process the command:
  *   query default.prefixAreaText
  *
  * @return "install" or "lineNumbers" or "sequenceNumbers"
  */
 String queryDefault(String qualifier)
 {
  int value = defaultValue();
  return (value == View.PREFIX_AREA_TEXT_NONE)? "install" : getTypeName(value);
 }

 /**
  * Process the command:
  *   query current.prefixAreaText
  *
  * @return "lineNumbers" or "sequenceNumbers"
  */
 String queryCurrent(View view, String qualifier)
 {
  return getTypeName(currentValue(view));
 }

 private static String getTypeName(int type)
 {
  switch (type)
   {
    case View.PREFIX_AREA_TEXT_LINENUMBERS:
     {
      return "lineNumbers";
     }
    case View.PREFIX_AREA_TEXT_SEQUENCENUMBERS:
     {
      return "sequenceNumbers";
     }
   }

  return null;
 }
}