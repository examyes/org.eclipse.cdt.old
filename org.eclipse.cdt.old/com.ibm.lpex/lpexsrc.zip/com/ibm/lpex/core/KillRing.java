//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// KillRing - handle the kill ring.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages the kill ring.
 */
final class KillRing
{
 private static final int MAX = 30;
 private static String _killStrings[] = new String[MAX];
 private static int _currentKill = -1;
 private static int _newestKill = -1;
 private static View _lastKillView;
 private static int _lastKillActionId = LpexConstants.ACTION_INVALID;


 private KillRing() {}

 static String currentKillString()
 {
  return (_currentKill >= 0)? _killStrings[_currentKill] : null;
 }

 static String previousKillString(int count)
 {
  if (_currentKill >= 0)
   {
    int previousKill = _currentKill;
    if (count > 0)
     {
      for (int i = 0; i < count; i++)
       {
        previousKill = _currentKill - 1;
        if (previousKill < 0)
         {
          previousKill = MAX - 1;
          while (previousKill > 0 && _killStrings[previousKill] == null)
           {
            previousKill--;
           }
         }
       }
     }

    else
     {
      for (int i = count; i < 0; i++)
       {
        previousKill = previousKill + 1;
        if (previousKill >= MAX || _killStrings[previousKill] == null)
         {
          previousKill = 0;
         }
       }
     }

    _currentKill = previousKill;
    return _killStrings[previousKill];
   }

  return null;
 }

 static void appendKillString(View view, String killString)
 {
  if (killString != null && killString.length() > 0)
   {
    if (isNewKill(view))
     {
      saveNewKillString(view, killString);
     }
    else
     {
      _killStrings[_newestKill] += killString;
      _currentKill = _newestKill;
     }
   }

  _lastKillView = view;
  _lastKillActionId = view.actionHandler().userActionId();
 }

 static void prefaceKillString(View view, String killString)
 {
  if (killString != null && killString.length() > 0)
   {
    if (isNewKill(view))
     {
      saveNewKillString(view, killString);
     }
    else
     {
      _killStrings[_newestKill] = killString + _killStrings[_newestKill];
      _currentKill = _newestKill;
     }
   }

  _lastKillView = view;
  _lastKillActionId = view.actionHandler().userActionId();
 }

 static void disposeView(View view)
 {
  if (view == _lastKillView)
   {
    _lastKillView = null;
    _lastKillActionId = LpexConstants.ACTION_INVALID;
   }
 }

 static boolean killStringAvailable()
 {
  return _currentKill != -1;
 }

 private static void saveNewKillString(View view, String killString)
 {
  if (killString != null && killString.length() > 0)
   {
    _newestKill++;
    if (_newestKill >= MAX)
     {
      _newestKill = 0;
     }
    _killStrings[_newestKill] = killString;
    _currentKill = _newestKill;
   }
 }

 private static boolean isNewKill(View view)
 {
  return _newestKill == -1 ||
         _lastKillActionId == LpexConstants.ACTION_INVALID ||
         _lastKillView != view ||
         _lastKillActionId != view.actionHandler().lastUserActionId();
 }

 private static void endKill(View view)
 {
  _currentKill = _newestKill;
  _lastKillView = view;
  _lastKillActionId = view.actionHandler().userActionId();
 }
}