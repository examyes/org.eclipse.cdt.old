//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ClassParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ClassParameter extends ParameterOnOffOnly
{
 private static ClassParameter _parameter;

 static ClassParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ClassParameter();
   }
  return _parameter;
 }

 private ClassParameter()
 {
  super(PARAMETER_CLASS);
 }

 boolean setValue(View view, String qualifier, boolean value)
 {
  if (view != null)
   {
    if (value)
     {
      view.classes().register(qualifier);
     }
    else
     {
      view.classes().deregister(qualifier);
     }
   }
  return true;
 }

 boolean value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? (view.classes().mask(qualifier) != 0) : false;
 }
}