//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// IncludedClassesParameter - handles the includedClasses parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>includedClasses</b> parameter.
 */
final class IncludedClassesParameter extends Parameter
{
 private static IncludedClassesParameter _parameter;

 static IncludedClassesParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new IncludedClassesParameter();
   }
  return _parameter;
 }

 private IncludedClassesParameter()
 {
  super(LpexConstants.PARAMETER_INCLUDED_CLASSES);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  if (view != null)
   {
    long classes = 0;
    boolean ok = true; // this flag is used to work around a problem in the JIT

    LpexStringTokenizer st = new LpexStringTokenizer(parameters);
    while (ok && st.hasMoreTokens())
     {
      String token = st.nextToken();
      long mask = view.classes().mask(token);
      if (mask == 0)
       {
        CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
        ok = false;
       }
      classes |= mask;
     }

    if (!ok)
     {
      return false;
     }

    if (classes == Classes.NONE)
     {
      classes = Classes.ALL;
     }

    view.setIncludedClasses(classes);
   }

  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  long classes = view.includedClasses();
  if (classes == Classes.ALL)
   {
    classes = Classes.NONE;
   }

  return (view != null)? view.classes().names(classes) : null;
 }
}