//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// List
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class is used to manage a list of objects.
 */
class List
{
 /**
  * This interface can be implemented to describe a node in the List.
  */
 interface Node
  {
   Node next();
   void setNext(Node node);
   Node prev();
   void setPrev(Node node);
   boolean removePending();
   void setRemovePending();
  }


 Node _first;
 Node _last;

 /**
  * Retrieve the first object in the list.
  */
 Node first()
  {
   return _first;
  }

 /**
  * Retrieve the last object in the list.
  */
 Node last()
  {
   return _last;
  }

 /**
  * Add the specified node after prev.
  */
 void addAfter(Node prev, Node node)
  {
   if (node != null)
    {
     Node next;
     if (prev == null)
      {
       next = _first;
       _first = node;
      }
     else
      {
       next = prev.next();
       prev.setNext(node);
      }

     node.setPrev(prev);
     node.setNext(next);

     if (next != null)
      {
       next.setPrev(node);
      }
     else
      {
       _last = node;
      }
    }
  }

 /**
  * Add the specifed node before next.
  */
 void addBefore(Node next, Node node)
  {
   if (node != null)
    {
     Node prev;
     if (next == null)
      {
       prev = _last;
       _last = node;
      }
     else
      {
       prev = next.prev();
       next.setPrev(node);
      }

     node.setNext(next);
     node.setPrev(prev);

     if (prev != null)
      {
       prev.setNext(node);
      }
     else
      {
       _first = node;
      }
    }
  }

 private int _scanning;
 private boolean _removePending;

 /**
  * Remove the specfied node from the list.
  */
 Node remove(Node node)
  {
   if (_scanning > 0)
    {
     node.setRemovePending();
     _removePending = true;
     return null;
    }
   else
    {
     Node prev = node.prev();
     Node next = node.next();
     if (prev != null)
      {
       prev.setNext(next);
      }
     else
      {
       _first = next;
      }

     if (next != null)
      {
       next.setPrev(prev);
      }
     else
      {
       _last = prev;
      }

     node.setNext(null);
     node.setPrev(null);
     return node;
    }
  }

 void beginScanning()
  {
   _scanning++;
  }

 void endScanning()
  {
   if (_scanning > 0)
    {
     _scanning--;

     if (_scanning == 0)
      {
       if (_removePending)
        {
         _removePending = false;
         Node next = null;
         for (Node node = first();
              node != null;
              node = next)
          {
           next = node.next();
           if (node.removePending())
            {
             remove(node);
            }
          }
        }
      }
    }
  }

 /**
  * Remove all of the nodes from the list.
  */
 void clear()
  {
   while (first() != null)
    {
     remove(first());
    }
  }
}