//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterDefault
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

abstract class ParameterDefault extends Parameter
{
 ParameterDefault(String name)
 {
  super(name);
 }

 boolean hasInstallSetting()
 {
  return true;
 }

 boolean hasDefaultSetting()
 {
  return true;
 }

 boolean hasCurrentSetting()
 {
  return true;
 }
}