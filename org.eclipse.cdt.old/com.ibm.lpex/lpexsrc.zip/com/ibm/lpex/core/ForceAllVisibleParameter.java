//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ForceAllVisibleParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ForceAllVisibleParameter extends ParameterOnOffOnly
{
 private static ForceAllVisibleParameter _parameter;

 static ForceAllVisibleParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ForceAllVisibleParameter();
   }
  return _parameter;
 }

 private ForceAllVisibleParameter()
 {
  super(PARAMETER_FORCE_ALL_VISIBLE);
 }

 boolean setValue(View view, String qualifier, boolean value)
 {
  if (view != null)
   {
    view.setForceAllVisible(value);
   }
  return true;
 }

 boolean value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.forceAllVisible() : false;
 }
}