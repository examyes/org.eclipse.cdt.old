//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// MessageLineParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class MessageLineParameter extends ParameterOnOffDefault
{
 private static MessageLineParameter _parameter;

 static MessageLineParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new MessageLineParameter();
   }
  return _parameter;
 }

 private MessageLineParameter()
 {
  super(PARAMETER_MESSAGE_LINE, true);
 }

 boolean setValue(View view, int value)
 {
  if (view != null)
   {
    view.screen().setMessageLine(value);
   }
  return true;
 }

 int value(View view)
 {
  return (view != null)? view.screen().messageLine() : Parameter.DEFAULT;
 }
}