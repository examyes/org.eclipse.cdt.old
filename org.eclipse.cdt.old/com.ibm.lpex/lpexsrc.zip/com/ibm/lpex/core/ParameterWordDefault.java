//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterWordDefault - framework for handling word parameters with
// install, default, and current settings.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * The Parameter <- ParameterDefault <- ParameterWordDefault abstract class
 * provides a framework for handling editor parameters that accept a single
 * word, and have install, default, and current values.
 * It handles commands SET and QUERY [install.|default.|current.]<parm>, etc.
 *
 * @see ParameterStringDefault
 */
abstract class ParameterWordDefault extends ParameterDefault
{
 private String  _hardCodedValue;
 private String  _installValue;
 private boolean _installValueLoaded;
 private String  _defaultValue;
 private boolean _defaultValueLoaded;


 ParameterWordDefault(String name, String hardCodedValue)
  {
   super(name);
   _hardCodedValue = hardCodedValue;
   Install.addProfileChangedListener(new Install.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _installValueLoaded = false;
       if (defaultValue() == null)
        {
         for (Document document = Document._firstDocument;
              document != null;
              document = document._next)
          {
           for (View view = document._firstView; view != null; view = view._next)
            {
             if (value(view) == null)
              {
               currentValueChanged(view);
              }
            }
          }
        }
      }
    });

   Profile.addProfileChangedListener(new Profile.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _defaultValueLoaded = false;
       for (Document document = Document._firstDocument;
            document != null;
            document = document._next)
        {
         for (View view = document._firstView; view != null; view = view._next)
          {
           if (value(view) == null)
            {
             currentValueChanged(view);
            }
          }
        }
      }
    });
  }

 String installValue()
  {
   if (!_installValueLoaded)
    {
     String value = Install.getString(PARAMETER_INSTALL + name());
     _installValue = (value == null)? _hardCodedValue : value;
     _installValueLoaded = true;
    }
   return _installValue;
  }

 private void loadDefaultValue()
  {
   if (!_defaultValueLoaded)
    {
     _defaultValue = Profile.getString(PARAMETER_DEFAULT + name());
     _defaultValueLoaded = true;
    }
  }

 String defaultValue()
  {
   loadDefaultValue();
   return _defaultValue;
  }

 boolean setDefaultValue(String value)
  {
   _defaultValue = value;
   _defaultValueLoaded = true;
   if (_defaultValue != null)
    {
     Profile.putString(PARAMETER_DEFAULT + name(), _defaultValue);
    }
   else
    {
     Profile.remove(PARAMETER_DEFAULT + name());
    }

   for (Document document = Document._firstDocument;
        document != null;
        document = document._next)
    {
     for (View view = document._firstView; view != null; view = view._next)
      {
       if (value(view) == null)
        {
         currentValueChanged(view);
        }
      }
    }

   return true;
  }

 String currentValue(View view)
  {
   String value = value(view);
   if (value == null)
    {
     value = defaultValue();
     if (value == null)
      {
       value = installValue();
      }
    }

   return "null".equals(value)? null : value;
  }

 boolean set(View view, String qualifier, String parameters)
  {
   String value = "null";
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     value = token.equals("default")? null : token;
     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name(qualifier));
      }
    }

   // when command is:      value here is:
   // SET <param>           "null"
   // SET <param> default   null
   // SET <param> xxx       "xxx"
   return setValue(view, value);
  }

 abstract boolean setValue(View view, String value);

 boolean setDefault(View view, String qualifier, String parameters)
  {
   String value = "null";
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     value = token.equals("install")? null : token;
     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(),
                                              "set " + PARAMETER_DEFAULT + name(qualifier));
      }
    }

   // when command is:              value here is:
   // SET default.<param>           "null"
   // SET default.<param> install   null
   // SET default.<param> xxx       "xxx"
   return setDefaultValue(value);
  }

 void currentValueChanged(View view) {}

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   if (view == null)
    {
     return null;
    }

   String value = value(view);
   if (value == null)
    {
     return "default";
    }

   return value.equals("null")? null : value;
  }

 abstract String value(View view);

 String queryInstall(String qualifier)
  {
   return installValue();
  }

 String queryDefault(String qualifier)
  {
   String value = defaultValue();
   if (value == null)
    {
     return "install";
    }

   return value.equals("null")? null : value;
  }

 String queryCurrent(View view, String qualifier)
  {
   return currentValue(view);
  }
}