//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SequenceDefaultTextParameter - handle the sequenceDefaultText parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * SourceDefaultTextParameter handles the sequenceDefaultText LPEX parameter.
 * The Parameter <- ParameterDefault <- ParameterWordDefault class it extends
 * provides the framework for handling word (string) parameters with install
 * and default values (commands SET and QUERY [install. | default. | current.],
 * etc.).
 */
final class SequenceDefaultTextParameter extends ParameterWordDefault
{
   /**
    * Singleton SequenceDefaultTextParameter object handles (by occasionally
    * delegating to Document) sequenceDefaultText for all the documents (note
    * that all its methods have a View argument passed in).
    *
    * The actual value of a document's sequenceDefaultText is stored in the
    * document's element list (_sequenceDefaultTextParm).
    */
   private static SequenceDefaultTextParameter _parameter;

   static  SequenceDefaultTextParameter getParameter()
   {
      if (_parameter == null)
         _parameter = new SequenceDefaultTextParameter();
      return _parameter;
   }

   /**
    * Private constructor - SequenceDefaultTextParameter
    * is not created directly, but via a first call to
    * SequenceDefaultTextParameter.getParameter().
    */
   private SequenceDefaultTextParameter()
   {
      // construct a Parameter.WordDefault with the _name
      // PARAMETER_SEQUENCE_DEFAULT_TEXT, and a _hardCodedValue null
      super(PARAMETER_SEQUENCE_DEFAULT_TEXT, null);
   }

   /**
    * Set the sequenceDefaultText parameter for this view's document.
    *
    * @param value null / "null" = default to the install default-text string,
    *              "install" = set to the install default text,
    *              else = a specific sequence-numbers default text
    */
   boolean setValue(View view, String value)
   {
      if (view != null) {
         view.document().elementList().setSequenceDefaultTextParm(value);
         currentValueChanged(view); // assume change from previous value...
         }
      return true;
   }

   /**
    * Handle the notification of a change in the actual sequence default text
    * of the document, by further notifying the document's element list.
    *
    * Called by ParameterWordDefault when the default. value of the parameter
    * changes.  We call it ourselves in here when the value of the parameter
    * is (assumingly) changed.
    */
   void    currentValueChanged(View view)
   {
      view.document().elementList().sequenceDefaultTextChanged();
   }

   /**
    * Retrieve the document's sequenceDefaultText parameter value.
    *
    * @return <code>null</code> when the current setting is DEFAULT,
    *         or else a specific text
    */
   String  value(View view)
   {
      return (view != null)? view.document().elementList()._sequenceDefaultTextParm : null;
   }
}