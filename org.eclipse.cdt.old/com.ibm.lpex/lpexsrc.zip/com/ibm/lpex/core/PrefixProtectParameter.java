//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// PrefixProtectParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class PrefixProtectParameter extends ParameterOnOffOnly
{
 private static PrefixProtectParameter _parameter;

 static PrefixProtectParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new PrefixProtectParameter();
   }
  return _parameter;
 }

 private PrefixProtectParameter()
 {
  super(PARAMETER_PREFIX_PROTECT);
 }

 boolean setValue(View view, String qualifier, boolean value)
 {
  if (view != null)
   {
    view.setPrefixProtect(value);
   }
  return true;
 }

 boolean value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.prefixProtect() : false;
 }
}