//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// MessageTextParameter - handles the messageText parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>messageText</b> parameter.
 */
final class MessageTextParameter extends Parameter
{
 private static MessageTextParameter _parameter;

 static MessageTextParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new MessageTextParameter();
   }
  return _parameter;
 }

 private MessageTextParameter()
 {
  super(LpexConstants.PARAMETER_MESSAGE_TEXT);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  if (view != null)
   {
    view.screen().setMessageText(parameters);
   }
  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.screen().messageText() : null;
 }
}