//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// StatusParameter - handles the status parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>status</b> parameter.
 */
final class StatusParameter extends Parameter
{
 private static StatusParameter _parameter;

 static StatusParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new StatusParameter();
   }
  return _parameter;
 }

 private StatusParameter()
 {
  super(LpexConstants.PARAMETER_STATUS);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  if (parameters != null)
   {
    parameters = parameters.trim();
    if (parameters.length() == 0)
     {
      parameters = null;
     }
   }

  CommandHandler._status = parameters;
  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return CommandHandler._status;
 }
}