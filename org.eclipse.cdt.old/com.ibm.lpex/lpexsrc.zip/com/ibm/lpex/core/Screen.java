//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Screen - manage the Java LPEX screen: edit area + scroll bars;
// the status, command, etc. lines
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;


/**
 * This class manages the screen:  the display/refresh of the edit window.
 * There is one instance of this class for every document View.
 */
final class Screen implements LpexConstants, ControlListener
{
 boolean _processingPendingJump;

 // internal styleAttributes-qualifiers ids
 static final int
  STYLE_INVALID          = -1,
  STYLE_FIRST            =  0,
  STYLE_ADDED_LINES      =  0,
  STYLE_BACKGROUND       =  1,
  STYLE_DEFAULT          =  2,
  STYLE_DELETED_LINES    =  3,
  STYLE_EMPHASIS         =  4,
  STYLE_EXPAND_HIDE      =  5,
  STYLE_FORMAT_LINE      =  6,
  STYLE_MESSAGE_LINE     =  7,
  STYLE_PREFIX_AREA      =  8,
  STYLE_PREFIX_TEXT      =  9,
  STYLE_SELECTION        = 10,
  STYLE_SEQUENCE_NUMBER  = 11,
  STYLE_SEQUENCE_TEXT    = 12,
  STYLE_STATUS_LINE      = 13,
  STYLE_LAST             = 13;

 // qualifiers for the styleAttributes parameter
 // NB Styles must be in alphabetical order for the binary search.
 private static TableNode[] _styles =
  {
   new TableNode("addedLines",     STYLE_ADDED_LINES),
   new TableNode("background",     STYLE_BACKGROUND),
   new TableNode("default",        STYLE_DEFAULT),
   new TableNode("deletedLines",   STYLE_DELETED_LINES),
   new TableNode("emphasis",       STYLE_EMPHASIS),
   new TableNode("expandHide",     STYLE_EXPAND_HIDE),
   new TableNode("formatLine",     STYLE_FORMAT_LINE),
   new TableNode("messageLine",    STYLE_MESSAGE_LINE),
   new TableNode("prefixArea",     STYLE_PREFIX_AREA),
   new TableNode("prefixText",     STYLE_PREFIX_TEXT),
   new TableNode("selection",      STYLE_SELECTION),
   new TableNode("sequenceNumber", STYLE_SEQUENCE_NUMBER),
   new TableNode("sequenceText",   STYLE_SEQUENCE_TEXT),
   new TableNode("statusLine",     STYLE_STATUS_LINE),
  };

 // LPEX's reserved style characters
 static final char
  CHAR_STYLE_DEFAULT         = '!',
  CHAR_STYLE_SEQUENCE_NUMBER = '\u0001',
  CHAR_STYLE_SEQUENCE_TEXT   = '\u0002';

 private View _view;
 private int  _rows;               // fully visible rows on the screen
 private int  _cursorRow;
 private int  _scroll;
 private int  _cursorPosition;
 private int  _cursorWidth;
 private int  _emphasisWidth;
 private int  _prefixCursorPosition;
 private int  _prefixScroll;
 private int  _prefixCursorWidth;
 private Row  _topRow;
 private Row  _cachedRows;
 private Font _font;
 private TextFontMetrics _textFontMetrics;
 private Rectangle _size;          // net text area's size (without scrollbars)

 // Screen.TextScrollBar objects wrappering actual LpexWindow scrollbar widgets
 private HorizontalScrollBar _horizontalScrollBar;
 private VerticalScrollBar   _verticalScrollBar;

 private boolean    _layoutRequired;
 private LpexWindow _lpexWindow;
 private String     _messageText;
 private String     _formatLineText;
 private boolean    _newMessage;
 private String     _palette;
 private int        _expandHideWidth;

 // screen parameters settings
 private int _prefixArea  = Parameter.DEFAULT;
 private int _expandHide  = Parameter.DEFAULT;
 private int _statusLine  = Parameter.DEFAULT;
 private int _formatLine  = Parameter.DEFAULT;
 private int _messageLine = Parameter.DEFAULT;
 private int _commandLine = Parameter.DEFAULT;

 private StyleAttributes _styleAttributes[] = new StyleAttributes[STYLE_LAST + 1];


 static int styleId(String styleName)
  {
   styleName = styleName.trim();
   TableNode tableNode = TableNode.binarySearch(_styles, styleName);
   return (tableNode != null)? tableNode.id() : STYLE_INVALID;
  }

 static String styleName(int styleId)
  {
   TableNode tableNode = TableNode.sequentialSearch(_styles, styleId);
   return (tableNode != null)? tableNode.string() : null;
  }

 /*---------------------------*/
 /*  ControlListener methods  */
 /*---------------------------*/
 public void controlResized(ControlEvent e)
  {
   resized();
   Document.screenShow();
  }

 public void controlMoved(ControlEvent e) {}

 /*----------------*/
 /*  Screen stuff  */
 /*----------------*/
 Screen(View view)
  {
   _view = view;
   _cursorRow = 1;
  }

 /**
  * Retrieve the horizontal scroll-bar controller object.
  */
 HorizontalScrollBar horizontalScrollBar()
  {
   if (_horizontalScrollBar == null)
    {
     _horizontalScrollBar = new HorizontalScrollBar();
    }
   return _horizontalScrollBar;
  }

 /**
  * Retrieve the vertical scroll-bar controller object.
  */
 VerticalScrollBar verticalScrollBar()
  {
   if (_verticalScrollBar == null)
    {
     _verticalScrollBar = new VerticalScrollBar();
    }
   return _verticalScrollBar;
  }

 void setFont(Font font)
  {
   _font = font;
   newFont();
  }

 void newFont()
  {
   _textFontMetrics = null;
   _view.setElementWidthsInvalid();
   _view.setPrefixAreaWidthsInvalid();
   validateFontMetrics();
   setRows();
   _expandHideWidth = 0;
  }

 private boolean validateFontMetrics()
  {
   if (_textFontMetrics == null)
    {
     //awt: _textFontMetrics = new TextFontMetrics((textWindow != null) ?
     //                       textWindow.getFontMetrics(currentFont()) : null);
     _textFontMetrics = new TextFontMetrics(this);

     _view.setElementWidthsInvalid();
     _view.setPrefixAreaWidthsInvalid();
     setRows();
    }
   return _textFontMetrics != null;
  }

 Font font()
  {
   return _font;
  }

 Font currentFont()
  {
   return FontParameter.getParameter().currentValue(_view);
  }

 TextFontMetrics textFontMetrics()
  {
   validateFontMetrics();
   return _textFontMetrics;
  }

 /**
  * Dissociate this Screen from its current LpexWindow, and optionally
  * associate it with a new LpexWindow.
  */
 void setWindow(LpexWindow lpexWindow)
  {
   if (_lpexWindow != null)
    {
     // when notified that SWT LpexWindow control is going to be disposed, e.g.
     // TextPart.handleDispose(), its children may have been already disposed!
     if (!_lpexWindow.textWindow().isDisposed())
        _lpexWindow.textWindow().removeControlListener(this);
    }

   horizontalScrollBar().changeLpexWindow(_lpexWindow, lpexWindow);
   verticalScrollBar().changeLpexWindow(_lpexWindow, lpexWindow);

   _lpexWindow = lpexWindow;
   if (_lpexWindow != null)
    {
     _textFontMetrics = null;
     _lpexWindow.textWindow().addControlListener(this);
     resized();
    }
  }

 /**
  * Query text window's width.
  */
 int width()
  {
   return (_size != null)? _size.width : 0;
  }

 int expandHideAreaWidth()
  {
   if (_view.hiddenElements() && currentExpandHide())
    {
     if (_expandHideWidth == 0 && _textFontMetrics != null)
      {
       int w1 = _textFontMetrics.stringWidth("+ ");
       int w2 = _textFontMetrics.stringWidth("- ");
       if (w1 > w2)
        {
         _expandHideWidth = w1;
        }
       else
        {
         _expandHideWidth = w2;
        }
      }
     return _expandHideWidth;
    }
   return 0;
  }

 int prefixAreaWidth()
  {
   return currentPrefixArea()? _view.maxPrefixAreaWidth() : 0;
  }

 /**
  * Return the net width of the element text in the text area.
  * The width returned doesn't contain the vertical scroll bar, the prefix
  * area, and the expand/hide area.
  */
 int textAreaWidth()
  {
   int textAreaWidth = (_size != null)? _size.width : 0;
   textAreaWidth -= prefixAreaWidth() + expandHideAreaWidth();
   if (textAreaWidth < 0)
    {
     textAreaWidth = 0;
    }
   return textAreaWidth;
  }

 int cursorX()
  {
   int cursorX = expandHideAreaWidth();
   if (_view.inPrefix())
    {
     cursorX += _prefixCursorPosition - _prefixScroll;
    }
   else
    {
     cursorX += prefixAreaWidth() + _cursorPosition - _scroll;
    }
   return cursorX;
  }

 int cursorY()
  {
   int cursorY = 0;
   TextFontMetrics textFontMetrics = textFontMetrics();
   if (_textFontMetrics != null)
    {
     cursorY = _cursorRow * _textFontMetrics.textHeight();
    }
   return cursorY;
  }

 // Called by controlResized() listener notification, and by setWindow() when
 // a new LpexWindow is associated with this Screen.
 private void resized()
  {
   //Point _size = _lpexWindow.textWindow().getSize();  // incl. own scrollbars
   _size = _lpexWindow.textWindow().getClientArea();    // net text area
   validateFontMetrics();
   setRows();
  }

 private void clearRows()
  {
   while (_topRow != null)
    {
     Row temp = _topRow;
     _topRow = _topRow._next;
     temp.reset();
     temp._next = _cachedRows;
     _cachedRows = temp;
    }
  }

 private void setRows()
  {
   if (_size != null &&
       _textFontMetrics != null &&
       _textFontMetrics.textHeight() != 0)
    {
     clearRows();
     _rows = _size.height / _textFontMetrics.textHeight();
     setCursorRow(_cursorRow);
     TextWindow textWindow = this.textWindow();
     if (textWindow != null)
      {
       textWindow.invalidateText();
      }
    }
  }

 int rows()
  {
   return _rows;
  }

 TextWindow textWindow()
  {
   return (_view.window() != null)? (TextWindow)_view.window().textWindow() : null;
  }

 /**
  * Set cursor's screen row.
  */
 void setCursorRow(int cursorRow)
  {
   if (cursorRow < 1)                      // don't go beyond top of the screen
    {
     cursorRow = 1;
    }
   if (cursorRow > rows() && rows() != 0)  // don't go beyond bottom of the screen
    {
     cursorRow = rows();
    }

   _cursorRow = cursorRow;
   _view.documentPosition().resetJumpPending();
  }

 private Row rowNode(int row)
  {
   if (row > 0)
    {
     int i = 1;
     for (Row rowNode = _topRow; rowNode != null; rowNode = rowNode._next)
      {
       if (i == row)
        {
         return rowNode;
        }
       i++;
      }
    }
   return null;
  }

 /**
  * Retrieve the element for a display row.
  */
 Element element(int row)
  {
   Row rowNode = rowNode(row);
   return (rowNode != null)? rowNode._element : null;
  }

 String expandHideText(int row)
  {
   Row rowNode = rowNode(row);
   return (rowNode != null)? rowNode._expandHideText : null;
  }

 boolean inTopExpandHideHeader(Point p)
  {
   return _topRow != null && _topRow._expandHideText != null &&
          p.x >= 0 && _size != null && p.x <= _size.width &&
          p.y >= 0 && _textFontMetrics != null && p.y < _textFontMetrics.textHeight();
  }

 int cursorRow()
  {
   return _cursorRow;
  }

 /**
  * Return the scroll to the left of the current screen (in pixels).
  */
 int scroll()
  {
   return _scroll;
  }

 void setScroll(int scroll)
  {
   _scroll = scroll;
   if (_scroll < 0)
    {
     _scroll = 0;
    }
  }

 String palette()
  {
   return _palette;
  }

 void setStyleAttributes(int id, StyleAttributes styleAttributes)
  {
   if (id >= STYLE_FIRST && id <= STYLE_LAST)
    {
     _styleAttributes[id] = styleAttributes;
    }
  }

 StyleAttributes styleAttributes(int id)
  {
   if (id >= STYLE_FIRST && id <= STYLE_LAST)
    {
     if (_styleAttributes[id] == null)
      {
       _styleAttributes[id] = UpdateProfileCommand.PaletteAttributesParameter
                                 .getParameter()
                                 .currentValue(_view, styleName(id), _palette);
      }
     return _styleAttributes[id];
    }
   return null;
  }

 void setMessageText(String messageText)
  {
   _messageText = messageText;
   _newMessage = true;
  }

 String messageText()
  {
   return _messageText;
  }

 void setFormatLineText(String formatLineText)
  {
   _formatLineText = formatLineText;
  }

 String formatLineText()
  {
   return _formatLineText;
  }

 boolean newMessage()
  {
   return _newMessage;
  }

 void resetNewMessage()
  {
   _newMessage = false;
  }

 void setPrefixArea(int prefixArea)
  {
   _prefixArea = prefixArea;
  }

 int prefixArea()
  {
   return _prefixArea;
  }

 boolean currentPrefixArea()
  {
   return PrefixAreaParameter.getParameter().currentValue(_view);
  }

 void setExpandHide(int expandHide)
  {
   _expandHide = expandHide;
   _view.setVisibleElementOrdinalsInvalid();
  }

 int expandHide()
  {
   return _expandHide;
  }

 boolean currentExpandHide()
  {
   return ExpandHideParameter.getParameter().currentValue(_view);
  }

 void setStatusLine(int statusLine)
  {
   _statusLine = statusLine;
  }

 int statusLine()
  {
   return _statusLine;
  }

 boolean currentStatusLine()
  {
   return StatusLineParameter.getParameter().currentValue(_view);
  }

 /**
  * Set formatLine parameter value.
  */
 void setFormatLine(int formatLine)
  {
   _formatLine = formatLine;
  }

 /**
  * Query formatLine parameter value.
  */
 int formatLine()
  {
   return _formatLine;
  }

 /**
  * Query current.formatLine.
  * @return true = "on", false = "off"
  */
 boolean currentFormatLine()
  {
   return FormatLineParameter.getParameter().currentValue(_view);
  }

 void setMessageLine(int messageLine)
  {
   _messageLine = messageLine;
  }

 int messageLine()
  {
   return _messageLine;
  }

 boolean currentMessageLine()
  {
   return MessageLineParameter.getParameter().currentValue(_view);
  }

 void setCommandLine(int commandLine)
  {
   _commandLine = commandLine;
  }

 int commandLine()
  {
   return _commandLine;
  }

 boolean currentCommandLine()
  {
   return CommandLineParameter.getParameter().currentValue(_view);
  }

 /**
  * Do Screen's part of the updateProfile command.
  * Called by View.updateProfile().
  */
 void updateProfile()
  {
   String baseProfile = _view.baseProfile();
   if (baseProfile != null &&
       (baseProfile.equals("seu") ||
        baseProfile.equals("xedit") ||
        baseProfile.equals("ispf")))
    {
     // View.updateProfile() has already set prefixProtect to "off", and also
     // prefixAreaText to "sequenceNumbers" if col.1 sequenceNumbers are set
     _prefixArea = Parameter.ON;
    }
   else
    {
     // View.updateProfile() has already set prefixProtect to "on"
     _prefixArea = Parameter.DEFAULT;
    }

   if ("vi".equals(baseProfile))
    {
     _commandLine = Parameter.OFF;
    }
   else
    {
     _commandLine = Parameter.DEFAULT;
    }

   _palette = UpdateProfileCommand.PaletteParameter.getParameter().currentValue(_view);

   for (int id = STYLE_FIRST; id <= STYLE_LAST; id++)
    {
     StyleAttributes styleAttributes =
       UpdateProfileCommand.PaletteAttributesParameter
                           .getParameter().currentValue(_view, styleName(id), _palette);
     setStyleAttributes(id, styleAttributes);

     // for our reserved sequence-numbers styles, also update view's styles list
     if (id == STYLE_SEQUENCE_NUMBER)
      {
       _view.styleAttributesList().set(CHAR_STYLE_SEQUENCE_NUMBER, styleAttributes);
      }
     else if (id == STYLE_SEQUENCE_TEXT)
      {
       _view.styleAttributesList().set(CHAR_STYLE_SEQUENCE_TEXT, styleAttributes);
      }
    }
  }

 private void buildTextWindow()
  {
   if (rows() > 0)
    {
     if (!_processingPendingJump)
      {
       _processingPendingJump = true;
       _view.documentPosition().processPendingJump();
       _processingPendingJump = false;
      }

     clearRows();
     for (int i = 0; i < _rows; i++)
      {
       Row rowNode;
       if (_cachedRows != null)
        {
         rowNode = _cachedRows;
         _cachedRows = rowNode._next;
        }
       else
        {
         rowNode = new Row();
        }
       rowNode._next = _topRow;
       _topRow = rowNode;
      }
     setCursorRow(_cursorRow);

     if (!_processingPendingJump)
      {
       Block.validate();
       _view.markList().validate();
      }

     Element currentElement = _view.documentPosition().element();
     if (currentElement != null)
      {
       int elementsAboveCurrent = _view.visibleElementOrdinalOf(currentElement) - 1;
       int elementsBelowCurrent = _view.visibleElementCount() - elementsAboveCurrent - 1;

       if (elementsBelowCurrent < rows() - _cursorRow)
        {
         _cursorRow = rows() - elementsBelowCurrent;
        }

       if (elementsAboveCurrent < _cursorRow - 1)
        {
         _cursorRow = elementsAboveCurrent + 1;
        }

       Element e;
       int i;
       for (i = _cursorRow, e = currentElement;
            i > 0 && e != null;
            i--, e = e.prevVisible(_view))
        {
         rowNode(i)._element = e;
        }

       for (i = _cursorRow + 1, e = currentElement.nextVisible(_view);
            i <= rows() && e != null;
            i++, e = e.nextVisible(_view))
        {
         rowNode(i)._element = e;
        }

       if (!_processingPendingJump)
        {
         ElementView elementView = currentElement.elementView(_view);
         int prefixAreaWidth = prefixAreaWidth();
         if (prefixAreaWidth == 0)
          {
           _view.setInPrefix(false);
          }
         int textAreaWidth = textAreaWidth();
         int position = _view.documentPosition().position();
         _cursorPosition = elementView.pixelCharPosition(position);
         int currentCharWidth = _view.charWidth(currentElement, position);
         if (_cursorPosition > _scroll + textAreaWidth - currentCharWidth)
          {
           _scroll = _cursorPosition - textAreaWidth + currentCharWidth;
          }

         if (_cursorPosition < _scroll)
          {
           _scroll = _cursorPosition;
          }

         if ((!_view.vi() && _view.insertMode()) ||
             (Block.view() == _view &&
              Block.type() == Block.STREAM && Block.anythingSelected()))
          {
           _cursorWidth = 2;
          }
         else
          {
           _cursorWidth = currentCharWidth;
          }

         int emphasisLength = _view.documentPosition().emphasisLength();
         if (emphasisLength > 0)
          {
           _emphasisWidth = elementView.pixelPosition(position + emphasisLength) -
                            _cursorPosition;
          }
         else
          {
           _emphasisWidth = 0;
          }

         position = _view.documentPosition().prefixPosition();
         _prefixCursorPosition = _view.prefixPixelPosition(elementView, position);
         currentCharWidth = _view.prefixCharWidth(elementView, position);
         if (currentCharWidth == 0)
          {
           currentCharWidth = 2;
          }
         _prefixScroll = elementView.prefixScroll();
         if (_prefixCursorPosition > _prefixScroll + prefixAreaWidth - currentCharWidth)
          {
           _prefixScroll = _prefixCursorPosition - prefixAreaWidth + currentCharWidth;
          }

         if (_prefixCursorPosition < _prefixScroll)
          {
           _prefixScroll = _prefixCursorPosition;
          }
         elementView.setPrefixScroll(_prefixScroll);
         _prefixCursorWidth = _view.insertMode()? 2 : currentCharWidth;
        }
      }

     if (_topRow._element == null && currentExpandHide())
      {
       _topRow._expandHideText = _view.topExpandHideText();
      }

    }
  }

 void build()
  {
   if (_lpexWindow != null)
    {
     validateFontMetrics();
     buildTextWindow();
     horizontalScrollBar().build();
     verticalScrollBar().build();
    }
  }

 void show()
  {
   if (_view.vi())
    {
     _view.viHandler().verifyMode();
    }

   // send any mark notifications that are pending
   _view.markList().triggerListeners();
   // send a readonly view notification if one is pending
   _view.listenerList().readonly();
   // send any cursor notifications if needed & cursor listeners registered
   _view.triggerCursorListeners();

   /*================================================================*/
   /* inform our listeners a new screen is going to be built & shown */
   /*================================================================*/
   _view.listenerList().showing();

   build();

   if (_view.window() != null)
    {
     boolean layoutRequired = false;
     StyleAttributes backgroundStyle = styleAttributes(STYLE_BACKGROUND);
     Font font = this.currentFont();

     // status line - calculate the values for Row & Column
     Element currentElement = _view.documentPosition().element();
     ElementList elementList = _view.document().elementList();
     int row;
     int column;
     int formatLineColumn;
     if (currentElement == null)
      {
       row = 0;
       column = 0;
       formatLineColumn = 0;
      }
     else
      {
       ElementView elementView = currentElement.elementView(_view);
       row = elementList.nonShowOrdinalOf(currentElement) +
             // bump up row by number of lines before the loaded document section
             _view.document().linesBeforeStart();
       column = _view.currentColumn(elementView);
       formatLineColumn = _view.currentFormatLineColumn(elementView);
      }

     StatusLine statusLine = (StatusLine)_lpexWindow.statusLine();
     statusLine.rowField().setRow(row);
     statusLine.columnField().setColumn(column);
     int inputMode = StatusLine.INPUT_MODE_INSERT;
     if (_view.vi())
      {
       int mode = _view.viHandler().mode();
       if (mode == ViHandler.MODE_REPLACE)
        {
         inputMode = StatusLine.INPUT_MODE_REPLACE;
        }
       else if (mode != ViHandler.MODE_INSERT)
        {
         inputMode = StatusLine.INPUT_MODE_COMMAND;
        }
      }
     else if (!_view.insertMode())
      {
       inputMode = StatusLine.INPUT_MODE_REPLACE;
      }
     statusLine.inputModeField().setInputMode(inputMode);
     statusLine.changesField().setChanges(_view.document().undo().changes());
     statusLine.browseField().setBrowseMode(_view.readonly());
     if (statusLine.setFont(font, _textFontMetrics))
      {
       layoutRequired = true;
      }
     statusLine.setStyleAttributes(styleAttributes(STYLE_STATUS_LINE));
     if (currentStatusLine() != statusLine.isVisible())
      {
       statusLine.setVisible(currentStatusLine());
       layoutRequired = true;
      }

     // separator between status line & format line
     Separator separator0 = (Separator)_lpexWindow.separator0();
     separator0.setColor(backgroundStyle.backgroundColor());

     // format line, under the status line
     FormatLine formatLine = (FormatLine)_lpexWindow.formatLine();
     formatLine.setColumn(formatLineColumn);
     if (formatLine.setFont(font, _textFontMetrics))
      {
       layoutRequired = true;
      }
     if (currentFormatLine() != formatLine.isVisible())
      {
       formatLine.setVisible(currentFormatLine());
       layoutRequired = true;
      }
     formatLine.showing(_view); // let format line further check its own validity

     // separator between format line & text window (edit area)
     Separator separator1 = (Separator)_lpexWindow.separator1();
     separator1.setColor(backgroundStyle.backgroundColor());

     // separator between text window & message line
     Separator separator2 = (Separator)_lpexWindow.separator2();
     separator2.setColor(backgroundStyle.backgroundColor());

     // message line
     MessageLine messageLine = (MessageLine)_lpexWindow.messageLine();
     messageLine.setText(_messageText);
     if (messageLine.setFont(font, _textFontMetrics))
      {
       layoutRequired = true;
      }
     messageLine.setStyleAttributes(styleAttributes(STYLE_MESSAGE_LINE));
     if (currentMessageLine() != messageLine.isVisible())
      {
       messageLine.setVisible(currentMessageLine());
       layoutRequired = true;
      }

     // command line, under the message line
     CommandLine commandLine = (CommandLine)_lpexWindow.commandLine();
     if (commandLine.forceVisible())
      {
       if (!commandLine.isVisible())
        {
         commandLine.setVisible(true);
         layoutRequired = true;
        }
      }
     else if (currentCommandLine() != commandLine.isVisible())
      {
       commandLine.setVisible(currentCommandLine());
       layoutRequired = true;
      }

     TextWindow textWindow = this.textWindow();
     textWindow.setLines(rows());
     int y = 0;

     StyleAttributesList styleAttributesList = _view.styleAttributesList();
     StyleAttributes defaultStyle    = styleAttributes(STYLE_DEFAULT);
     StyleAttributes expandHideStyle = styleAttributes(STYLE_EXPAND_HIDE);
     StyleAttributes prefixAreaStyle = styleAttributes(STYLE_PREFIX_AREA);
     StyleAttributes prefixTextStyle = styleAttributes(STYLE_PREFIX_TEXT);
     StyleAttributes selectionStyle  = styleAttributes(STYLE_SELECTION);
     StyleAttributes emphasisStyle   = styleAttributes(STYLE_EMPHASIS);

     // block selection info
     int textHeight = _textFontMetrics.textHeight();
     //int maxAscent = _textFontMetrics.maxAscent();
     boolean hasBlock;         // element is part of a block
     boolean hasElementBlock;  // if hasBlock, further indicate if it's ELEMENT
     int blockPosition;
     int blockEndPosition;
     //int blockPosition1; *as* assume col.1 as/400 seq numbers for now...
     //int blockEndPosition1;

     // sequence numbers info (so they don't participate in selection)
     int sequenceNumbersColumn = elementList.sequenceNumbersColumn();
     int sequenceNumbersWidth  = elementList.sequenceNumbersWidth();
     boolean hasSequenceNumbers = sequenceNumbersWidth != 0 &&
                                  !_view.currentHideSequenceNumbers() &&
                                  _view.getSequenceNumbersStyle().length() > 0 &&
                                  // *as* assume col.1 as/400 seq numbers for now...
                                  sequenceNumbersColumn == 1;

     int expandHideWidth = expandHideAreaWidth();
     int prefixAreaTextValue = PrefixAreaTextParameter.getParameter().currentValue(_view);
     int prefixAreaWidth = prefixAreaWidth();
     formatLine.setMargin(expandHideWidth + prefixAreaWidth);

     /*==========================================*/
     /* set up all the rows 1 .. rows() to build */
     /*==========================================*/
     Element element = null;
     for (int i = 1; i <= rows(); i++)
      {
       boolean hasCursor;
       boolean hasPrefixCursor;
       StyleAttributes elementDefaultStyle;
       String expandHideText;
       String prefixText;
       StyleAttributes prefixStyle;
       int prefixScroll;
       String text;
       String style;
       int styleLength;
       element = this.element(i);

       /*-------------------------------------------------------------*/
       /*  (a) this screen row corresponds to an actual text element  */
       /*-------------------------------------------------------------*/
       if (element != null)
        {
         hasCursor = (i == _cursorRow) && textWindow.focusGained() && !_view.inPrefix();
         hasPrefixCursor = i == _cursorRow && textWindow.focusGained() &&
                           _view.inPrefix();
         ElementView elementView = element.elementView(_view);
         elementDefaultStyle = _view.markList().defaultStyleAttributes(element);
         if (elementDefaultStyle == null)
          {
           elementDefaultStyle = defaultStyle;
          }
         expandHideText = elementView.expandHideText();

         // (a) user entered a prefix command
         prefixText = elementView.prefixText();
         if (prefixText != null && prefixText.length() > 0)
          {
           prefixStyle = prefixTextStyle;
           prefixScroll = elementView.prefixScroll();
          }
         // (b) default prefix area text
         else
          {
           // sequenceNumbers or [if none set] lineNumbers
           prefixText = "";
           if (prefixAreaTextValue == View.PREFIX_AREA_TEXT_SEQUENCENUMBERS)
            {
             prefixText = elementList.getSequenceNumbersDisplayString(element, _view);
            }
           if (prefixText.length() == 0)
            {
             prefixText = element.lineNumberText(6);
            }

           prefixStyle = prefixAreaStyle;
           prefixScroll = 0;
          }

         text = elementView.displayText().text;
         if (text == null)
          {
           text = "";
          }
         style = elementView.displayStyle();
         styleLength = (style != null)? style.length() : 0;

         // record the element areas that are part of a block
         hasBlock = Block.partOfBlock(_view, element);
         hasElementBlock = (hasBlock)? Block.type() == Block.ELEMENT : false;
         blockPosition = 0;
         blockEndPosition = 0;
         //blockPosition1 = 0; *as* assume col.1 as/400 seq numbers for now...
         //blockEndPosition1 = 0;
         if (hasBlock)
          {
           // 1.- ELEMENT block w/o sequence numbers: selection on entire line
           if (hasElementBlock)
            {
              // 2.- ELEMENT block with sequence numbers: don't select them
              if (hasSequenceNumbers)
               {
                hasElementBlock = false;
                // *as* assume col.1 as/400 seq numbers for now...
                blockPosition = elementView.pixelPosition(sequenceNumbersColumn);
                blockEndPosition = _size.width + _scroll;
               }
            }
           else
            {
             Element topElement = Block.topElement();
             Element bottomElement = Block.bottomElement();
             int topPosition = Block.topPosition();
             int bottomPosition = Block.bottomPosition();

             // 3.- STREAM / CHARACTER block
             if (Block.type() == Block.STREAM ||
                 Block.type() == Block.CHARACTER)
              {
               // establish block-selection start position
               if (topElement == element)
                {
                 blockPosition = elementView.pixelPosition(topPosition);
                }
               else
                {
                 blockPosition = 0;
                 if (hasSequenceNumbers)
                  {
                   // *as* assume col.1 as/400 seq numbers for now...
                   blockPosition = elementView.pixelPosition(sequenceNumbersColumn);
                  }
                }

               // establish block-selection end position
               if (bottomElement == element)
                {
                 if (Block.type() == Block.STREAM)
                  {
                   bottomPosition -= 1;
                  }
                 blockEndPosition = elementView.pixelCharPosition(bottomPosition + 1);
                }
               else
                {
                 blockEndPosition = elementView.width();
                }

               if (blockEndPosition <= blockPosition)
                {
                 // show a bit of selection meat on empty lines
                 blockEndPosition = blockPosition + 2;
                }
              }

             // 4.- RECTANGLE block
             else if (Block.type() == Block.RECTANGLE)
              {
               blockPosition = Block.leftPixelPosition();
               blockEndPosition = Block.rightPixelPosition();
              }
             if (i == _cursorRow &&
                 blockPosition == _cursorPosition &&
                 blockEndPosition == _cursorPosition + _cursorWidth)
              {
               hasBlock = false;
              }
            }
          }//end "hasBlock"
        }

       /*---------------------------------------------------------------------------*/
       /*  (b) element == null: this screen row is beyond the actual text elements  */
       /*---------------------------------------------------------------------------*/
       else
        {
         hasCursor = false;
         hasPrefixCursor = false;
         elementDefaultStyle = backgroundStyle;
         expandHideText = this.expandHideText(i);
         if (expandHideText == null)
          {
           expandHideText = "";
          }
         prefixText = "";
         prefixStyle = prefixAreaStyle;
         prefixScroll = 0;
         text = "";
         style = null;
         styleLength = 0;
         hasBlock = false;
         hasElementBlock = false;
         blockPosition = 0;
         blockEndPosition = 0;
        }

       // set text line info, invalidate on any changes since last paint
       TextWindow.Line line = textWindow.line(i);
       line.setSize(_size.width, textHeight);
       line.setY(y);
       line.setFont(font, _textFontMetrics);
       line.setTextPosition(y /*awt: +maxAscent*/);
       line.setDefaultStyleAttributes(elementDefaultStyle);
       line.setExpandHideText(expandHideText);
       line.setExpandHideWidth(expandHideWidth);
       line.setExpandHideStyleAttributes(expandHideStyle);
       line.setPrefixText(prefixText);
       line.setPrefixWidth(prefixAreaWidth);
       line.setPrefixStyleAttributes(prefixStyle);
       line.setText(text);
       line.setTextStyleAttributesLength(styleLength);
       // invalidate line if affected by any style or styleAttributes that changed
       line.setTextStyleAttributes(style, styleAttributesList);
       line.setSelectionStyleAttributes(selectionStyle);
       line.setEmphasisStyleAttributes(emphasisStyle);

       line.setCursorPosition(_cursorPosition);
       line.setCursorWidth(_cursorWidth);
       line.setHasCursor(hasCursor);

       line.setScroll(_scroll);
       line.setPrefixCursorPosition(_prefixCursorPosition);
       line.setPrefixCursorWidth(_prefixCursorWidth);
       line.setHasPrefixCursor(hasPrefixCursor);
       line.setPrefixScroll(prefixScroll);

       line.setHasBlock(hasBlock);
       line.setBlock(blockPosition, blockEndPosition-blockPosition); // *as* assume col.1 as/400 seq numbers for now...
       line.setHasElementBlock(hasElementBlock);

       line.setEmphasisWidth((i == _cursorRow)? _emphasisWidth : 0);

       y += textHeight;
      }//end "for rows()"

     // & set up leftover area at textWindow bottom below all full-height rows
     textWindow.setBottomHeight(_size.height - y);

     // use backgroundStyle if the last row was not a text row
     if (element == null && rows() > 0)
      {
       textWindow.setBottomStyleAttributes(backgroundStyle);
      }
     else
      {
       textWindow.setBottomStyleAttributes(defaultStyle);
      }

     /*=========================================================================*/
     /* invalidate min. of status/format/message lines & text area on screen    */
     /* (initiate all redraw()s here for all *we*'ve changed in screen content) */
     /*=========================================================================*/
     statusLine.updateStatus();
     separator0.updateSeparator();
     formatLine.updateFormat();
     separator1.updateSeparator();
     textWindow.updateText(true);
     textWindow.updateBottom();
     messageLine.updateMessage();
     separator2.updateSeparator();

     /*======================================================*/
     /* re-layout if the visibility of any scrollbar changed */
     /*======================================================*/
     if (verticalScrollBar().update())
      {
       layoutRequired = true;
       // verticalScrollBar on/off, as in swt is not a separate widget, does
       // not really affect layout: we must just re-build() & re-show() -as-
      }

     if (horizontalScrollBar().update())
      {
       layoutRequired = true;
       // horizontalScrollBar on/off affects layout because a separator line
       // will also turn on/off...
      }

     /*======================================================================*/
     /* re-layout() LpexWindow if visibility of any screen component changed */
     /*======================================================================*/
     if (layoutRequired)
      {
       // Swing:
       // _lpexWindow.revalidate();
       // swt:
       _lpexWindow.layout();
      }
    }

   /*=======================================================*/
   /* inform our listeners a new screen has just been shown */
   /*=======================================================*/
   _view.listenerList().shown();
  }


 /**
  * Base class for managing LpexWindow's screen's scroll bars.
  *
  * <p>The concrete scroll bar classes (which extend abstract TextScrollBar)
  * manage the ScrollBar widgets which are created in the TextWindow:  their
  * visibility, size, position, etc.
  */
 abstract class TextScrollBar implements SelectionListener
 {
  protected int     _value;          // ScrollBar selection
  protected int     _visibleAmount;  // ScrollBar thumb size
  protected int     _minimum;
  protected int     _maximum;

  protected int     _unitIncrement;  // e.g., 1 line for vertical bar
  protected int     _blockIncrement; // e.g., a screenful of lines for vertical bar

  protected boolean _needed;         // ScrollBar must be [made] visible
  protected boolean _updateRequired; // ScrollBar actual settings are out-of-date

  // we're refreshing the screen as a result of the user moving ScrollBar
  protected boolean _tracking;

  protected int     _lastTrackValue;


  // rebuild the scroll bar & indicate if _updateRequired and _needed
  abstract void build();

  // associate scroll bar with a new LpexWindow
  abstract void changeLpexWindow(LpexWindow oldWindow, LpexWindow newWindow);

  // retrieve the SWT ScrollBar widget
  abstract ScrollBar scrollBar();


  /**
   * Update the current scroll bar values into the actual ScrollBar widget.
   * Returns <code>true</code> if scroll bar's visibility toggled and,
   * therefore, a new LpexWindow layout is required.
   */
  boolean update()
   {
    boolean layoutRequired = false;
    if (!_tracking && _updateRequired)
     {
      if (scrollBar() != null)
       {
        if (scrollBar().getVisible() != _needed)
         {
          scrollBar().setVisible(_needed);
          layoutRequired = true;
         }
        scrollBar().setValues(_value,           // selection
                              _minimum,         // minimum
                              _maximum,         // maximum
                              _visibleAmount,   // thumb
                              _unitIncrement,   // increment
                              _blockIncrement); // pageIncrement
        _updateRequired = false;
       }
     }

    return layoutRequired;
   }

  /**
   * Query whether the scroll bar is needed (i.e., should be [made] visible).
   */
  boolean needed()
   {
    return _needed;
   }
 }

 /**
  * LpexWindow's screen's horizontal scroll bar.
  */
 final class HorizontalScrollBar extends TextScrollBar
 {
  HorizontalScrollBar()
   {
    _minimum = 0;
   }

  void build()
   {
    // 1.- establish the horizontal scroll bar values for the current screen
    int value = scroll(); // scroll to the left of the current screen (in pixels)
    int visibleAmount = textAreaWidth();
    int maximum = _view.maxElementWidth();
    int unitIncrement = 1;
    if (textFontMetrics() != null)
     {
      maximum += textFontMetrics().spaceWidth();
      unitIncrement = textFontMetrics().spaceWidth();
     }
    int currentWidth = scroll() + visibleAmount;
    if (currentWidth > maximum)
     {
      maximum = currentWidth;
     }
    int blockIncrement = visibleAmount;

    // 2.- see if the actual ScrollBar current values are different
    if (_value != value ||
        _visibleAmount != visibleAmount ||
        _maximum != maximum ||
        _blockIncrement != blockIncrement ||
        _unitIncrement != unitIncrement)
     {
      _updateRequired = true;
      _value = value;
      _visibleAmount = visibleAmount;
      _maximum = maximum;
      _blockIncrement = blockIncrement;
      _unitIncrement = unitIncrement;
     }

    // 3.- check if must change the visibility of the scroll bar
    boolean needed = visibleAmount < maximum;
    if (needed != _needed)
     {
      _updateRequired = true;
      _needed = needed;
     }
   }

  /**
   * Dissociate this scroll bar object from its current LpexWindow,
   * and optionally associate it with a new LpexWindow & its ScrollBar.
   */
  void changeLpexWindow(LpexWindow oldLpexWindow, LpexWindow newLpexWindow)
   {
    if (oldLpexWindow != null)
     {
      // when notified that SWT LpexWindow control is going to be disposed, e.g.
      // TextPart.handleDispose(), its children may have been already disposed!
      if (!oldLpexWindow.textWindow().isDisposed())
         oldLpexWindow.horizontalScrollBar().removeSelectionListener(this);
     }
    if (newLpexWindow != null)
     {
      newLpexWindow.horizontalScrollBar().addSelectionListener(this);
     }
    _updateRequired = true;
   }

  /**
   * Retrieve the SWT ScrollBar widget for the screen's horizontal scroll bar,
   * which we manage here.
   */
  ScrollBar scrollBar()
   {
    return (_lpexWindow != null)? _lpexWindow.horizontalScrollBar() : null;
   }

  // horizontal ScrollBar's SelectionListener - user clicked ScrollBar/moved thumb
  // When widgetSelected() is called, the event object detail field contains
  // one of the following values:  0 - for the end of a drag;  SWT.DRAG;
  // SWT.HOME;  SWT.END;  SWT.ARROW_DOWN;  SWT.ARROW_UP;  SWT.PAGE_DOWN;
  // SWT.PAGE_UP.  Notification widgetDefaultSelected() is not called.
  public void widgetDefaultSelected(SelectionEvent e) {}
  public void widgetSelected(SelectionEvent e)
   {
    int scroll = _view.screen().scroll();
    int newScroll = scrollBar().getSelection(); /*awt: getValue();*/
    if (scroll > newScroll)
     {
      _view.documentPosition().scrollLeft(scroll - newScroll);
     }
    else if (scroll < newScroll)
     {
      _view.documentPosition().scrollRight(newScroll - scroll);
     }
    if (newScroll == _lastTrackValue && _updateRequired)
     {
      Document.screenShow();
     }
    else
     {
      _tracking = true;
      Document.screenShow();
      _tracking = false;
     }
    _lastTrackValue = newScroll;
   }
 }

 /**
  * LpexWindow's screen's vertical scroll bar.
  */
 final class VerticalScrollBar extends TextScrollBar
 {
  VerticalScrollBar()
   {
    _minimum = 1;
    _unitIncrement = 1;
   }

  void build()
   {
    // 1.- establish the vertical scroll bar values for the current screen
    int value;
    Element topElement = element(1); // the element on the top display row
    if (topElement != null)
     {
      value = _view.visibleElementOrdinalOf(topElement);
     }
    else
     {
      value = 1;
     }
    value += _view.document().linesBeforeStart(); // bump up by unloaded top lines

    int visibleAmount = rows();

    int maximum = _view.visibleElementCount() + 1 +
                  _view.document().linesBeforeStart() + _view.document().linesAfterEnd();
    if (visibleAmount > maximum)
     {
      visibleAmount = maximum;
     }
    if (maximum < 1)
     {
      visibleAmount = 0;
      maximum = 1;
     }
    if (value > maximum)
     {
      value = maximum;
     }

    int blockIncrement = rows();

    // 2.- see if the actual ScrollBar current values are different
    if (_value != value ||
        _visibleAmount != visibleAmount ||
        _maximum != maximum ||
        _blockIncrement != blockIncrement)
     {
      _updateRequired = true;
      _value = value;
      _visibleAmount = visibleAmount;
      _maximum = maximum;
      _blockIncrement = blockIncrement;
     }

    // 3.- check if must change the visibility of the scroll bar
    boolean needed = _minimum + visibleAmount < maximum;
    if (needed != _needed)
     {
      _updateRequired = true;
      _needed = needed;
      buildTextWindow();
      // may have to rebuild horizontal scroll bar (?! e.g., we're here due to a Ctrl+G)
      horizontalScrollBar().build();
     }
   }

  /**
   * Dissociate this scroll bar object from its current LpexWindow,
   * and optionally associate it with a new LpexWindow & its ScrollBar.
   */
  void changeLpexWindow(LpexWindow oldLpexWindow, LpexWindow newLpexWindow)
   {
    if (oldLpexWindow != null)
     {
      // when notified that SWT LpexWindow control is going to be disposed, e.g.
      // TextPart.handleDispose(), its children may have been already disposed!
      if (!oldLpexWindow.textWindow().isDisposed())
         oldLpexWindow.verticalScrollBar().removeSelectionListener(this);
     }
    if (newLpexWindow != null)
     {
      newLpexWindow.verticalScrollBar().addSelectionListener(this);
     }
    _updateRequired = true;
   }

  /**
   * Retrieve the SWT ScrollBar widget for the screen's vertical scroll bar,
   * which we manage here.
   */
  ScrollBar scrollBar()
   {
    return (_lpexWindow != null)? _lpexWindow.verticalScrollBar() : null;
   }

  // vertical ScrollBar's SelectionListener - user clicked ScrollBar/moved thumb
  // When widgetSelected() is called, the event object detail field contains
  // one of the following values:  0 - for the end of a drag;  SWT.DRAG;
  // SWT.HOME;  SWT.END;  SWT.ARROW_DOWN;  SWT.ARROW_UP;  SWT.PAGE_DOWN;
  // SWT.PAGE_UP.  Notification widgetDefaultSelected() is not called.
  public void widgetDefaultSelected(SelectionEvent e) {}
  public void widgetSelected(SelectionEvent e)
   {
    int topElementNumber;
    Element topElement = _view.screen().element(1);
    if (topElement != null)
     {
      topElementNumber = _view.visibleElementOrdinalOf(topElement);
     }
    else
     {
      topElementNumber = 1;
     }
    topElementNumber += _view.document().linesBeforeStart(); // bump up by unloaded top lines

    int newElementNumber = scrollBar().getSelection(); /*awt: getValue();*/
    // NB scrollUp(..)/Down(..) may trigger request to extend current document section
    if (topElementNumber > newElementNumber)
     {
      _view.documentPosition().scrollUp(topElementNumber - newElementNumber);
     }
    else if (newElementNumber > topElementNumber)
     {
      _view.documentPosition().scrollDown(newElementNumber - topElementNumber);
     }

    if (_lastTrackValue == newElementNumber && _updateRequired)
     {
      Document.screenShow();
     }
    else
     {
      _tracking = true;
      Document.screenShow();
      _tracking = false;
     }

    _lastTrackValue = newElementNumber;
   }
 }


 final static class Row
 {
  Element _element;
  String  _expandHideText;
  Row     _next;

  void reset()
   {
    _element = null;
    _expandHideText = null;
   }
 }
}