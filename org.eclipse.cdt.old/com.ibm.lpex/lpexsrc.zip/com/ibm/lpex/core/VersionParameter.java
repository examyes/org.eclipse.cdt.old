//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// VersionParameter - handles the version parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>version</b> parameter.
 *
 * <p>A utility such as tools/GenerateLpexManifest.java may be used in the build
 * to create an lpexManifest file, such as this:
 * <pre>
 *   Specification-Version: 1.3.0
 *   Implementation-Version: Oct 23, 2001
 * </pre>
 * This file is then imported into the LPEX jar.  As shown in the example above,
 * the lpexManifest file includes the LPEX version (Specification-Version
 * attribute) and the build date (Implementation-Version attribute).
 */
final class VersionParameter extends ParameterQuery
{
 private static VersionParameter _parameter;

 static VersionParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new VersionParameter();
   }
  return _parameter;
 }

 private VersionParameter()
 {
  super(PARAMETER_VERSION);
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return LpexUtilities.getVersion();
 }
}