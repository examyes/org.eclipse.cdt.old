//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexDocumentSectionListener - defines a listener for managing the document
// section currently loaded in the editor.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Interface LpexDocumentSectionListener can be implemented to manage the
 * document section currently loaded in the editor.  After loading a document
 * section and setting information regarding the number of lines in the complete
 * document, the application responds to the document-listener notifications by
 * expanding the document section as requested.
 *
 * <p>Create a listener object using this class, and then register it with a
 * document view using the view's <code>addLpexDocumentSectionListener()</code>
 * method.  When the editor determines that the currently-loaded document
 * section must be extended, the <code>addLines()</code> method in the listener
 * object is invoked.
 * Example:
 * <pre>
 *   myLpexView.addLpexDocumentSectionListener(new LpexDocumentSectionListener() {
 *      // we must extend the document section
 *      public boolean addLines(LpexView lpexView, int lineNeeded) {
 *         return loadItUp(lpexView, lineNeeded);
 *         }
 *      }); </pre>
 *
 * <p>This feature is only provided for certain specific applications.
 * Normally, the editor loads and operates on the complete document (file).
 *
 * <p>When an application only loads a section of the document, it should take
 * certain features into consideration:
 * <ul>
 *  <li>Most editor parameters and commands apply to the complete document.
 *      For example, the "Row" field on the status line, displayed line numbers,
 *      the numeric part of sequence numbers, the <b>resequence</b> command,
 *      etc. apply to the entire document
 *  <li>API methods defined in LpexView, on the other hand, allow the application
 *      to easily control the editor widget for the current document section only.
 *      For example, while "query elements" entered on the editor command line
 *      (and, consequently, the method lpexView.queryInt("elements");) will
 *      return, say, 500, the API method call lpexView.elements() will return 100
 *      if the current document section has 100 text elements (i.e., is preceded
 *      and/or followed by a total of 400 lines which have not been loaded in the
 *      editor)
 *  <li>Most actions and commands only operate on the current document section.
 *      For example, commands <b>print, save, set mark, findText, sort,
 *      compare, locate sequenceNumber, locate sequenceText</b>,
 *      and actions <b>blockMarkAll, blockMarkTop, blockMarkBottom,
 *      setQuickMarkAll</b>.
 *      They do not trigger a request for extending this document section.
 *      To make them operate on the entire document, the application should
 *      extend these actions and commands to first load the complete document in
 *  <li>Similarly, filtered views (such as filter selection, and Ctrl+G - action
 *      <b>functions</b>, which displays only the function headers in C/C++
 *      documents) only apply to the elements in the document section that is
 *      currently loaded in the editor.
 *      The horizontal scroll bar only reflects the longest element in the
 *      current document section, and it may change when the section is expanded
 *  <li>Document parsers, unless specifically written to handle a partial
 *      document appropriately, operate only on the currently-loaded section and
 *      do not trigger requests to extend it.  This section's boundaries should
 *      not split multiline language-specific constructs, or parsers may
 *      misinterpret the document syntax
 *  <li>A request to expand the current document section may be issued, before
 *      or after the operation, by these
 *      commands:  <b>locate element, locate line, delete</b>;
 *      actions:  <b>top, bottom, up, down, pageUp, pageDown,
 *      blockMarkUp, blockMarkDown, blockMarkPageUp, blockMarkPageDown,
 *      blockDelete, newLine</b>;
 *      and by user selection of the vertical scroll bar in the edit window.
 * </ul>
 *
 * @see LpexView#addLpexDocumentSectionListener
 * @see LpexView#removeLpexDocumentSectionListener
 * @see LpexView#setLinesOutsideDocumentSection
 * @see LpexView#linesBeforeStart
 * @see LpexView#linesAfterEnd
 */
public interface LpexDocumentSectionListener
{
 /**
  * This method is invoked when it was determined that the currently-loaded
  * document section should be extended.  A minimum of about two screen rows
  * of lines is expected to be loaded around the current line in each document
  * view.
  *
  * @param lpexView the view of the editor document which triggered the request
  *        to add lines
  * @param lineNeeded the first line before the document section, or the last
  *        line after the document section, in the range of lines with which the
  *        current document section must be expanded;  lineNeeded already includes
  *        the minimum threshold indicated
  */
 public boolean addLines(LpexView lpexView, int lineNeeded);
}