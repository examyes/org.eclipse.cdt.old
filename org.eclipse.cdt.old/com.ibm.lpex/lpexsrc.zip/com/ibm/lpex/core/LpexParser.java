//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexParser - document parser interface.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Interface LpexParser can be implemented to define a document parser.
 *
 * <p>A parser is associated with one particular view of a document.
 * The parser must have a constructor whose parameter is this view:
 * <pre>
 *   MyLpexParser(LpexView lpexView) {} </pre>
 *
 * @see LpexCommonParser
 */
public interface LpexParser
{
 /**
  * Remove all of the parser specifics from the document view.
  * For example, remove any listeners you added, and dispose of any resources.
  * Note that classes, style attributes, commands, and actions are already
  * automatically removed by the editor.
  *
  * @see LpexCommonParser#resetParser
  */
 public void resetParser();

 /**
  * Total parse.  Parse the entire document.
  *
  * @see LpexCommonParser#totalParse
  */
 public void totalParse();

 /**
  * Incremental parse.  Parse change(s) to a document.
  *
  * @param element the element whose committed change triggered the parse,
  *                or the element that precedes / follows a deleted block;
  *                the parser may identify other neighbouring elements that
  *                will have to be reparsed as a unit
  *
  * @see LpexCommonParser#parse
  */
 public void parse(int element);

 /**
  * Retrieve a parser property.
  *
  * @param key property name
  * @see LpexCommonParser#getProperty
  */
 public String getProperty(String key);

 /**
  * Retrieve the name of the HTML help panel that the parser identifies
  * as appropriate for the token currently selected.
  *
  * @see LpexCommonParser#getHelpPage
  */
 public String getHelpPage();
}