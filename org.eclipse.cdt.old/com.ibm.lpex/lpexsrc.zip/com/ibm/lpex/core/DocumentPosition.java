//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DocumentPosition - manages the current (cursor) position for a view.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages a view's current (cursor) position in the document.
 * There is one instance of this class per document view.
 */
final class DocumentPosition
{
 private View _view;                 // the view for which we maintain the position
 private Element _element;           // cursor element

 private int _position;              // ONE-based current char index in element's text
 private int _desiredPixelPosition;  // -1 = recalculate pixel offset into
                                     //      display text from _position
 private int _direction;             // visual cursor direction (MUST set with setDirection()!)
 public static final int             //  (for bidi processing)
  LTR = 0,                           //  ==>  (e.g., Home, End, right-arrowing through English text)
  RTL = 1;                           //  <==  (e.g., left-arrowing through Hebrew text)

 private int _emphasisLength;
 private Element _emphasisElement;
 private int _emphasisPosition;

 private int _prefixPosition;             // ONE-based current col position in prefix area
 private int _desiredPrefixPixelPosition; // -1 = recalculate pixel offset into
                                          //      prefix text from _prefixPosition
 private Element _jumpElement;

 private boolean _ignoreChanges;          // set during View.java #joinElements() and #splitElement

 private Preserve _topPreserve;           // list of Preserve objects in use
 private Preserve _cachedPreserves;       // cache of available Preserve objects


 /**
  * Construct a current document position for a view.
  */
 DocumentPosition(View view)
  {
   _view = view;
   top(); // set view's position to the top of the currently-loaded document section
  }

 /**
  * Calculate & return this current position's element.
  */
 Element element()
  {
   if (_element == null)
    {
     top(); // start looking from the top of the currently-loaded document section
    }

   if (_element != null && !_element.visible(_view))
    {
     Element nextVisible = _element.nextVisible(_view);
     if (nextVisible != null)
      {
       _element = nextVisible;
      }
     else
      {
       _element = _element.prevVisible(_view);
      }

     _prefixPosition = 1;
     _position = 1;
     setDirection(LTR);
     _desiredPixelPosition = -1;
     _desiredPrefixPixelPosition = -1;
    }

   return _element;
  }

 /**
  * Retrieve the character index in the element.
  */
 int position()
  {
   return _position;
  }

 /**
  * Retrieve the visual cursor direction.
  */
 int direction()
  {
   return _direction;
  }

 /**
  * [Re-]set the visual cursor direction.
  */
 private void setDirection(int newDirection)
  {
   _direction = newDirection;
   //*as* if (LpexUtilities.isBidi())
   //        re-set the language too!?...
  }

 int prefixPosition()
  {
   return _prefixPosition;
  }

 /**
  * Set prefix position to column <code>n</code> inside the prefix area.
  */
 void setPrefixPosition(int n)
  {
   if (!_ignoreChanges)
    {
     _prefixPosition = n;
     if (_element == null)
      {
       _prefixPosition = 1;
      }
     else
      {
       int prefixEnd = _element.elementView(_view).prefixEnd();
       if (_prefixPosition > prefixEnd)
        {
         _prefixPosition = prefixEnd;
        }
       if (_prefixPosition < 1)
        {
         _prefixPosition = 1;
        }
      }

     _desiredPrefixPixelPosition = -1;
    }
  }

 /**
  * Return the view associated with this document position.
  */
 View view()
  {
   return _view;
  }

 /**
  * Move the document position to the top (beginning) of the document section
  * that is currently loaded in the editor.
  */
 void top()
  {
   if (!_ignoreChanges)
    {
     _element = _view.document().elementList().first();
     if (_element != null && !_element.visible(_view))
      {
       _element = _element.nextVisible(_view);
      }
     if (_element != null &&
         _view.visibleElementOrdinalOf(_element) > 1)
      {
       _view.screen().setCursorRow(_view.visibleElementOrdinalOf(_element));
      }

     _prefixPosition = 1;
     _position = 1;
     setDirection(LTR);
     _desiredPixelPosition = -1;
     _desiredPrefixPixelPosition = -1;
    }
  }

 /**
  * Move the document position to the top (beginning) of the complete document.
  */
 void documentTop()
  {
   if (!_ignoreChanges)
    {
     // check & trigger beginning expansion of currently-loaded document section
     _view.verifyDocumentSectionLine(1);

     top();
    }
  }

 /**
  * Move the document position to the bottom (end) of the document section that
  * is currently loaded in the editor.
  */
 void bottom()
  {
   if (!_ignoreChanges)
    {
     _element = _view.document().elementList().last();
     if (_element != null)
      {
       if (!_element.visible(_view))
        {
         _element = _element.prevVisible(_view);
        }
       if (_element != null)
        {
         _prefixPosition = 1;
         _position = _element.end();
         setDirection(LTR);
         _desiredPixelPosition = -1;
         _desiredPrefixPixelPosition = -1;
        }
      }
    }
  }

 /**
  * Move the document position to the bottom (end) of the complete document.
  */
 void documentBottom()
  {
   if (!_ignoreChanges)
    {
     // check & trigger end expansion of currently-loaded document section
     _view.verifyDocumentSectionLine(_view.document().linesCount());

     bottom();
    }
  }

// /**
//  * N/U
//  * Move the document position to the next visible element in the file.
//  */
// int next()
//  {
//   return next(1);
//  }

 /**
  * Move the document position to the <code>n</code>th next visible element
  * in the document.
  *
  * @return the actual number of elements moved
  */
 int next(int n)
  {
   if (!_ignoreChanges && _element != null)
    {
     for (int i = 0; i < n; i++)
      {
       Element next = _element.nextVisible(_view);
       if (next != null)
        {
         _element = next;
        }
       else
        {
         return i;
        }
      }
     return n;
    }

   return 0;
  }

// /**
//  * N/U
//  * Move the document position to the previous visible element in the file.
//  */
// int prev()
//  {
//   return prev(1);
//  }

 /**
  * Move the document position to the <code>n</code>th previous visible element
  * in the document.
  *
  * @return the actual number of elements moved
  */
 int prev(int n)
  {
   if (!_ignoreChanges && _element != null)
    {
     for (int i = 0; i < n; i++)
      {
       Element prev = _element.prevVisible(_view);
       if (prev != null)
        {
         _element = prev;
        }
       else
        {
         return i;
        }
      }
     return n;
    }

   return 0;
  }

 /**
  * Move the cursor one visible element down inside the current screen.
  * If at the bottom of the screen, the screen also scrolls up one row.
  *
  * Actions <b>down</b> and <b>up</b> call this method.
  */
 void down()
  {
   down(1);
  }

 /**
  * Move the cursor <code>n</code> visible elements down inside the current screen.
  * When at the bottom of the screen (during this operation), the screen also
  * scrolls up (up to) <code>n</code> rows.
  *
  * Actions <b>down</b> and <b>up</b> call this method.
  */
 void down(int n)
  {
   if (!_ignoreChanges && _element != null)
    {
     // estimate (worst case) & trigger expansion of currently-loaded document section
     _view.verifyDocumentSectionDelta(n);

     preserveDesiredPosition(); // try to keep cursor's pixel position across lines
     next(n);
     adjustToDesiredPosition();
     _view.screen().setCursorRow(_view.screen().cursorRow() + n);
    }
  }

 /**
  * Page down.
  * Move the document position <code>n</code> visible elements down
  * in the document, where <code>n</code> is the number of screen rows.
  * The screen scrolls up, and the cursor is stationary if possible.
  */
 void pageDown()
  {
   if (!_ignoreChanges)
    {
     int n = _view.screen().rows();

     // estimate (worst case) & trigger expansion of currently-loaded document section
     _view.verifyDocumentSectionDelta(n);

     preserveDesiredPosition(); // try to keep cursor's pixel position across lines
     next(n);
     adjustToDesiredPosition();
    }
  }

 /**
  * Move the cursor one visible element up inside the current screen.
  * If at the top of the screen, the screen also scrolls down one row.
  *
  * Actions <b>up</b> and <b>down</b> call this method.
  */
 void up()
  {
   up(1);
  }

 /**
  * Move the cursor <code>n</code> visible elements up inside the current screen.
  * When at the top of the screen (during this operation), the screen also
  * scrolls down (up to) <code>n</code> rows.
  *
  * Actions <b>up</b> and <b>down</b> call this method.
  */
 void up(int n)
  {
   if (!_ignoreChanges && _element != null)
    {
     // estimate (worst case) & trigger expansion of currently-loaded document section
     _view.verifyDocumentSectionDelta(-n);

     preserveDesiredPosition(); // try to keep cursor's pixel position across lines
     int actualN = prev(n);
     adjustToDesiredPosition();

     // adjust current screen row, so we don't scroll the screen with cursor stationary
     _view.screen().setCursorRow(_view.screen().cursorRow() - actualN);

     if (actualN < n && _element != null &&
         _view.visibleElementOrdinalOf(_element) > 1)
      {
       int remainingN = n - actualN;
       _view.screen().setCursorRow(_view.screen().cursorRow() + remainingN);
      }
    }
  }

 /**
  * Page up.
  * Try to move the document position <code>n</code> visible elements up
  * in the document, where <code>n</code> is the number of screen rows.
  * The screen scrolls down, and the cursor is stationary if possible.
  */
 void pageUp()
  {
   if (!_ignoreChanges)
    {
     int n = _view.screen().rows();

     // estimate (worst case) & trigger expansion of currently-loaded document section
     _view.verifyDocumentSectionDelta(-n);

     preserveDesiredPosition(); // try to keep cursor's pixel position across lines
     int actualN = prev(n);
     adjustToDesiredPosition();

     if (actualN < n && _element != null &&
         _view.visibleElementOrdinalOf(_element) > 1)
      {
       int remainingN = n - actualN;
       _view.screen().setCursorRow(_view.screen().cursorRow() + remainingN);
      }
    }
  }

 /**
  * Move the cursor position one column to the right.
  *
  * Called by:
  *  ActionHandler.java in ACTION_BLOCK_MARK_WORD
  *  View.java #selectCharacter() (Shift+<=)
  *  ViHandler.java #insertAfter(), #pasteAfter(), #toggleCharacterCase()
  *
  * @see #arrowRight()
  */
 void right()
  {
   right(1);
  }

 /**
  * Move the cursor position <code>n</code> columns to the right.
  *
  * Called by:
  *  View.java #replaceText(), to select/emphasize found text
  *  ViHandler.java #right()
  *
  * @see #arrowRight(int)
  */
 void right(int n)
  {
   if (!_ignoreChanges)
    {
     // must re-build cursor position from new _position in text
     _desiredPixelPosition = -1;

     _position += n;
    }
  }

 /**
  * Move the cursor position one column to the (logical) right.  This is the
  * implementation for the right-arrow key movement.
  *
  * @see #right()
  */
 void arrowRight()
  {
   if (!_ignoreChanges)
    {
     // must re-build cursor position from new _position in text
     _desiredPixelPosition = -1;

     /*----------------------------------------------------------------------*/
     /*  (1) insert mode on a bidi boundary, may just change the _direction  */
     /*----------------------------------------------------------------------*/
     if (_view.insertMode() && LpexUtilities.isBidi())
      {
       ElementView elementView = _element.elementView(_view);
       boolean currRTL = elementView.isRightToLeft(_position);
       boolean prevRTL = elementView.isRightToLeft(_position-1);
       if (currRTL != prevRTL)
        {
         if (_direction == LTR && currRTL)
          {
           setDirection(RTL);
           //System.out.println(" ==> just switch direction LTR -> RTL...");
           return;
          }
         if (_direction == RTL && !currRTL)
          {
           setDirection(LTR);
           //System.out.println(" ==> just switch direction RTL -> LTR...");
           return;
          }
        }
      }

     /*--------------------------------------------------*/
     /*  (2) normal right-arrowing through logical text  */
     /*--------------------------------------------------*/
     _position++; // advance, keep direction as is
    }
  }

 /**
  * Move the cursor position <code>n</code> columns to the (logical) right.
  *
  * Called by:
  *  ActionHandler.java ACTION_RIGHT, ACTION_LEFT
  *  ViHandler.java #arrowRight()
  *
  * @see #right(int)
  */
 void arrowRight(int n)
  {
   for (; n > 0; n--)
    {
     arrowRight();
    }
  }

 void prefixRight()
  {
   prefixRight(1);
  }

 void prefixRight(int n)
  {
   setPrefixPosition(_prefixPosition + n);
  }

 /**
  * Move the cursor position one column to the left.
  *
  * Called by:
  *  View.java #backSpace(), #selectCharacter() ("Shift+<=")
  *  ViHandler.java (Esc), #pasteAfter(), #paste()
  *
  * @see #arrowLeft()
  */
 void left()
  {
   left(1);
  }

 /**
  * Move the cursor position <code>n</code> columns to the left.
  *
  * Called by:
  *  View.java to select/emphasize found text
  *  ViHandler.java (Ctrl+W), #left(), #deleteCharacterBefore()
  *
  * @see #arrowLeft(int)
  */
 void left(int n)
  {
   if (!_ignoreChanges)
    {
     // must re-build cursor position from new _position in text
     _desiredPixelPosition = -1;

     _position -= n;
     if (_position < 1)
      {
       _position = 1;

       // if cursor is at leftest possible, but there are sequence
       // numbers still scrolled left outside the view, reveal them
       //_view.screen().build(); // no need...
       _view.screen().setScroll(0);
      }
    }
  }

 /**
  * Move the cursor position one column to the (logical) left.  This is the
  * implementation for the left-arrow key movement.
  *
  * @see #left()
  */
 void arrowLeft()
  {
   if (!_ignoreChanges)
    {
     // must re-build cursor position from new _position in text
     _desiredPixelPosition = -1;

     /*----------------------------------------------------------------------*/
     /*  (1) insert mode on a bidi boundary, may just change the _direction  */
     /*----------------------------------------------------------------------*/
     if (_view.insertMode() && LpexUtilities.isBidi())
      {
       ElementView elementView = _element.elementView(_view);
       boolean currRTL = elementView.isRightToLeft(_position);
       boolean prevRTL = elementView.isRightToLeft(_position-1);
       if (currRTL != prevRTL)
        {
         if (_direction == RTL && currRTL)
          {
           setDirection(LTR);
           //System.out.println(" <== just switch direction RTL -> LTR...");
           return;
          }
         if (_direction == LTR && !currRTL)
          {
           setDirection(RTL);
           //System.out.println(" <== just switch direction LTR -> RTL...");
           return;
          }
        }
      }

     /*-------------------------------------------------*/
     /*  (2) normal left-arrowing through logical text  */
     /*-------------------------------------------------*/
     _position--;
     //System.out.println(" <== back cursor to prev position "+_position);

     if (_position < 1)
      {
       _position = 1;

       // if cursor is at leftest possible, but there are sequence
       // numbers still scrolled left outside the view, reveal them
       //_view.screen().build(); // no need...
       _view.screen().setScroll(0);
      }
    }
  }

 /**
  * Move the cursor position <code>n</code> columns to the (logical) left.
  *
  * Called by:
  *  ActionHandler.java ACTION_LEFT, ACTION_RIGHT
  *  ViHandler.java #arrowLeft()
  *
  * @see #left(int)
  */
 void arrowLeft(int n)
  {
   for (; n > 0; n--)
    {
     arrowLeft();
    }
  }

 void prefixLeft()
  {
   prefixLeft(1);
  }

 void prefixLeft(int n)
  {
   setPrefixPosition(_prefixPosition - n);
  }

 /**
  * Move to the next tab stop.
  */
 void nextTabStop()
  {
   if (_ignoreChanges)
    {
     return;
    }

   Element element = element();
   if (element != null)
    {
     ElementView elementView = element.elementView(_view);
     int displayPosition = _view.displayColumnForTabs(elementView, _position);
     // tabs are expanded only after any sequence numbers, remember delta
     int sequenceNumbersDelta = _view.displayColumn(elementView, _position) - displayPosition;
     TabsParameter.Settings tabs = TabsParameter.getParameter().currentValue(_view);
     int tabStop = 1;
     if (tabs._tabStops != null)
      {
       int i = 0;
       while (tabStop <= displayPosition && i < tabs._tabStops.length)
        {
         tabStop = tabs._tabStops[i];
         i++;
        }
      }

     if (tabStop <= displayPosition && tabs._tabIncrement > 0)
      {
       while (tabStop <= displayPosition)
        {
         tabStop += tabs._tabIncrement;
        }
      }

     if (tabStop > displayPosition)
      {
       _position = _view.positionFromDisplayPosition(elementView,
                                                     tabStop + sequenceNumbersDelta);
       //setDirection(LTR); // if on LTR-RTL boundary, else by context?!
       _desiredPixelPosition = -1;
      }
    }
  }

 /**
  * Move to the next word.
  */
 boolean nextWord()
  {
   if (!_ignoreChanges && _element != null)
    {
     Element newElement = _element;
     int newPosition = _position;
     //setDirection(LTR); // if on LTR-RTL boundary, else by context?!
     if (newElement.show())
      {
       newElement = newElement.nextVisibleNonShow(_view);
       if (newElement != null)
        {
         newPosition = 0;
        }
      }

     while (newElement != null)
      {
       newPosition = ElementList.nextWord(newElement, newPosition);
       if (newPosition != 0)
        {
         jump(newElement, newPosition);
         return true;
        }
       newElement = newElement.nextVisibleNonShow(_view);
       newPosition = 0;
      }
    }

   return false;
  }

 boolean nextWordEnd()
  {
   return nextWordEnd(0);
  }

 /**
  * Move to the end of the next word.
  *
  * @param offset current-position delta
  */
 boolean nextWordEnd(int offset)
  {
   if (!_ignoreChanges && _element != null)
    {
     Element newElement = _element;
     int newPosition = _position - offset;
     //setDirection(LTR); // if on LTR-RTL boundary, else by context?!
     if (newElement.show())
      {
       newElement = newElement.nextVisibleNonShow(_view);
       if (newElement != null)
        {
         newPosition = 0;
        }
      }

     while (newElement != null)
      {
       newPosition = ElementList.nextWordEnd(newElement, newPosition);
       if (newPosition != 0)
        {
         jump(newElement, newPosition + offset);
         return true;
        }
       newElement = newElement.nextVisibleNonShow(_view);
       newPosition = 0;
      }
    }

   return false;
  }

 /**
  * Move to the previous tab stop.
  */
 void prevTabStop()
  {
   if (_ignoreChanges)
    {
     return;
    }

   Element element = element();
   if (element != null)
    {
     ElementView elementView = element.elementView(_view);
     int displayPosition = _view.displayColumnForTabs(elementView, _position);
     // tabs are expanded only after any sequence numbers, remember delta
     int sequenceNumbersDelta = _view.displayColumn(elementView, _position) - displayPosition;

     TabsParameter.Settings tabs = TabsParameter.getParameter().currentValue(_view);
     int prevTabStop = 1;
     int tabStop = 1;

     if (tabs._tabStops != null)
      {
       int i = 0;
       while (tabStop < displayPosition && i < tabs._tabStops.length)
        {
         prevTabStop = tabStop;
         tabStop = tabs._tabStops[i];
         i++;
        }
      }

     if (tabStop < displayPosition && tabs._tabIncrement > 0)
      {
       while (tabStop < displayPosition)
        {
         prevTabStop = tabStop;
         tabStop += tabs._tabIncrement;
        }
      }

     // try going back, to tabStop or (if too high) to prevTabStop
     int newTabStop = (tabStop < displayPosition)? tabStop : prevTabStop;
     if (newTabStop < displayPosition)
      {
       _position = _view.positionFromDisplayPosition(elementView,
                                                     newTabStop + sequenceNumbersDelta);
       //setDirection(RTL); // if on LTR-RTL boundary, else by context?!
       _desiredPixelPosition = -1;
      }
    }
  }

 /**
  * Move to the previous word.
  */
 boolean prevWord()
  {
   if (!_ignoreChanges && _element != null)
    {
     Element newElement = _element;
     int newPosition = _position;
     //setDirection(RTL); // if on LTR-RTL boundary, else by context?!
     if (newElement.show())
      {
       newElement = newElement.prevVisibleNonShow(_view);
       if (newElement != null)
        {
         newPosition = newElement.end();
        }
      }

     while (newElement != null)
      {
       newPosition = ElementList.prevWord(newElement, newPosition);
       if (newPosition != 0)
        {
         jump(newElement, newPosition);
         return true;
        }

       newElement = newElement.prevVisibleNonShow(_view);
       if (newElement != null)
        {
         newPosition = newElement.end();
        }
      }
    }

   return false;
  }

 boolean prevWordEnd()
  {
   return prevWordEnd(0);
  }

 /**
  * Move to the previous word end.
  *
  * @param offset current-position delta
  */
 boolean prevWordEnd(int offset)
  {
   if (!_ignoreChanges && _element != null)
    {
     Element newElement = _element;
     int newPosition = _position - offset;
     //setDirection(RTL); // if on LTR-RTL boundary, else by context?!
     if (newElement.show())
      {
       newElement = newElement.prevVisibleNonShow(_view);
       if (newElement != null)
        {
         newPosition = newElement.end();
        }
      }

     while (newElement != null)
      {
       newPosition = ElementList.prevWordEnd(newElement, newPosition);
       if (newPosition != 0)
        {
         jump(newElement, newPosition + offset);
         return true;
        }

       newElement = newElement.prevVisibleNonShow(_view);
       if (newElement != null)
        {
         newPosition = newElement.end();
        }
      }
    }

   return false;
  }

// /**
//  * N/U
//  * Scroll the screen one page to the left.
//  */
// void pageLeft()
//  {
//   scrollLeft(_view.screen().textAreaWidth());
//  }

 /**
  * Move the cursor one page to the left.
  */
 void positionPageLeft()
  {
   if (!_ignoreChanges && _element != null)
    {
     int width = _view.screen().textAreaWidth();

     // try to keep cursor pixel position on the screen stationary, scroll the screen right
     _view.screen().build();
     _view.screen().setScroll(_view.screen().scroll() - width);

     while (_position > 1 && width > 0)
      {
       _position--;
       width -= _view.charWidth(_element, _position);
      }
     //setDirection(RTL); // if on LTR-RTL boundary, else by context?!
     _desiredPixelPosition = -1;
    }
  }

// /**
//  * N/U
//  * Scroll the screen one page to the right.
//  */
// void pageRight()
//  {
//   scrollRight(_view.screen().textAreaWidth());
//  }

 /**
  * Move the cursor one page to the right.
  */
 void positionPageRight()
  {
   if (!_ignoreChanges && _element != null)
    {
     int width = _view.screen().textAreaWidth();

     // try to keep cursor pixel position on the screen stationary, scroll the screen left
     _view.screen().build();
     _view.screen().setScroll(_view.screen().scroll() + width);

     while (width > 0)
      {
       width -= _view.charWidth(_element, _position);
       _position++;
      }
     //setDirection(LTR); // if on LTR-RTL boundary, else by context?!
     _desiredPixelPosition = -1;
    }
  }

 /**
  * Move to the beginning of a line.
  */
 void home()
  {
   if (!_ignoreChanges)
    {
     // if there are sequence numbers on the left , ensure we first
     // scroll them in view, then move cursor to the first text position
     //_view.screen().build(); // DON'T: Shift+=> won't hold stream selection across lines...
     _view.screen().setScroll(0);

     _position = 1;
     setDirection(LTR);
     _desiredPixelPosition = -1;
    }
  }

 void prefixHome()
  {
   if (!_ignoreChanges)
    {
     _prefixPosition = 1;
     _desiredPrefixPixelPosition = -1;
    }
  }

 /**
  * Move to the end of a line.
  */
 void end()
  {
   if (!_ignoreChanges)
    {
     _position = (_element != null)? _element.end() : 1;
     setDirection(LTR);
     _desiredPixelPosition = -1;
    }
  }

 void prefixEnd()
  {
   if (!_ignoreChanges)
    {
     _prefixPosition = (_element != null)? _element.elementView(_view).prefixEnd() : 1;
     _desiredPrefixPixelPosition = -1;
    }
  }

// /**
//  * N/U
//  * Scroll the screen down one visible element.
//  * When the cursor is at the top of the screen, it stays on the top
//  * screen row, and is therefore moved down one visible element.
//  * If the screen cannot scroll down, the cursor moves up
//  * one row inside this screen.
//  */
// void scrollDown()
//  {
//   scrollDown(1);
//  }

 /**
  * Scroll the screen down <code>n</code> visible elements.
  * When the cursor is at the top of the screen (during this operation),
  * it stays on the top screen row, and is therefore moved down (up to)
  * <code>n</code> visible elements.
  * When the screen cannot scroll down (during this operation), the cursor
  * moves up (up to) <code>n</code> rows inside this screen.
  *
  * The Screen's vertical scroll bar listener also calls this method.
  */
 void scrollDown(int n)
  {
   if (_ignoreChanges)
    {
     return;
    }

   // estimate (worst case) & trigger expansion of currently-loaded document section
   _view.verifyDocumentSectionDelta(n);

   Screen screen = _view.screen();
   int rows = screen.rows();
   preserveDesiredPosition(); // try to keep cursor's pixel position across lines

   for (int i = 0; i < n; i++)
    {
     screen.build();
     int cursorRow = screen.cursorRow();
     // 1.- as long as the screen can scroll down, move cursor's row up
     //     (cursor preserves the element it is positioned on)
     if (cursorRow > 1 &&
         screen.element(rows) != null &&
         screen.element(rows).nextVisible(_view) != null)
      {
       screen.setCursorRow(cursorRow - 1); // try to move cursor up one screen row
      }
     // 2.- afterwards, adjust document position for the rest of the scroll count
     //     (the cursor staying on the top screen row)
     else
      {
       // move the document position to the <n-i>th
       // next visible element in the document & break out
       next(n - i);
       break;
      }
    }

   adjustToDesiredPosition();
  }

// /**
//  * N/U
//  * Scroll the screen up one visible element.
//  * If the screen cannot scroll up, the cursor moves down
//  * one row inside this screen.
//  */
// void scrollUp()
//  {
//   scrollUp(1);
//  }

 /**
  * Scroll the screen up <code>n</code> visible elements.
  * When the cursor is at the bottom of the screen (during this operation),
  * it stays on the bottom screen row, and is therefore moved up (up to)
  * <code>n</code> visible elements.
  * When the screen cannot scroll up (during this operation), the cursor
  * moves down (up to) <code>n</code> rows inside this screen.
  *
  * The Screen's vertical scroll bar listener also calls this method.
  */
 void scrollUp(int n)
  {
   if (_ignoreChanges)
    {
     return;
    }

   // estimate (worst case) & trigger expansion of currently-loaded document section
   _view.verifyDocumentSectionDelta(-n);

   Screen screen = _view.screen();
   int rows = screen.rows();
   preserveDesiredPosition(); // try to keep cursor's pixel position across lines

   for (int i = 0; i < n; i++)
    {
     screen.build();
     int cursorRow = screen.cursorRow();
     if (cursorRow < rows &&
         screen.element(1) != null &&
         _view.visibleElementOrdinalOf(screen.element(1)) > 1)
      {
       screen.setCursorRow(cursorRow + 1);
      }
     else
      {
       prev(n - i);
       break;
      }
    }

   adjustToDesiredPosition();
  }

// /**
//  * N/U
//  * Scroll the screen left one column.
//  */
// void scrollLeft()
//  {
//   if (!_ignoreChanges && _element != null)
//    {
//     _view.screen().build();
//     // want to reveal the next character on the current line on the left
//     ElementView elementView = _element.elementView(_view);
//     int scroll = _view.screen().scroll();               // curr screen scroll (pixels)
//     int position = _view.position(elementView, scroll); // & its character equivalent
//     if (position > 1)
//      {
//       position--;
//      }
//
//     int pixelPosition = elementView.pixelPosition(position); // char-1 position
//     scrollLeft(scroll - pixelPosition);
//    }
//  }

 /**
  * Scroll the screen left <code>n</code> pixels.
  *
  * The Screen's horizontal scroll bar listener also calls this method.
  */
 void scrollLeft(int n)
  {
   if (!_ignoreChanges && _element != null)
    {
     _view.screen().build();
     _view.screen().setScroll(_view.screen().scroll() - n);
     int newScroll = _view.screen().scroll();
     int screenWidth = _view.screen().textAreaWidth();
     ElementView elementView = _element.elementView(_view);

     // don't let the cursor position fall over the right margin of the screen
     while (_position > 0 &&
            elementView.pixelPosition(_position) >
            newScroll + screenWidth - _view.charWidth(_element, _position))
      {
       _position--;
      }
     _desiredPixelPosition = -1;
    }
  }

// /**
//  * N/U
//  * Scroll the screen right one position.
//  */
// void scrollRight()
//  {
//   if (!_ignoreChanges && _element != null)
//    {
//     _view.screen().build();
//     // want to reveal the next character on the current line on the right
//     ElementView elementView = _element.elementView(_view);
//     int scroll = _view.screen().scroll();
//     int rightSide = scroll + _view.screen().textAreaWidth();
//     int position = _view.position(elementView, rightSide);
//
//     int pixelPosition = elementView.pixelPosition(position + 1);
//     scrollRight(pixelPosition - rightSide);
//    }
//  }

 /**
  * Scroll the screen right <code>n</code> pixels.
  *
  * The Screen's horizontal scroll bar listener also calls this method.
  */
 void scrollRight(int n)
  {
   if (!_ignoreChanges && _element != null)
    {
     _view.screen().build();
     _view.screen().setScroll(_view.screen().scroll() + n);
     int newScroll = _view.screen().scroll();
     int width = _view.screen().textAreaWidth();
     ElementView elementView = _element.elementView(_view);

     // don't let the cursor position fall below the left margin of the screen
     while (elementView.pixelPosition(_position) < newScroll)
      {
       _position++;
      }
     _desiredPixelPosition = -1;
    }
  }

 void windowBottom()
  {
   _view.screen().build();
   int x = _view.screen().rows() - _view.screen().cursorRow();
   down(x);
  }

 void windowTop()
  {
   _view.screen().build();
   int x = _view.screen().cursorRow() - 1;
   up(x);
  }

 void windowMiddle()
  {
   _view.screen().build();
   int x = _view.screen().cursorRow() - ((_view.screen().rows() + 1) / 2);
   if (x < 0)
    {
     down(-x);
    }
   else
    {
     up(x);
    }
  }

 /**
  * Move the cursor to the specified position in the document section that is
  * currently loaded in the editor.
  */
 void jump(Element element, int position)
  {
   if (!_ignoreChanges && element != null)
    {
     _position = position;
     //*as* setDirection(..); ?!?!?!
     _desiredPixelPosition = -1;

     if (element != _element)
      {
       _prefixPosition = 1;
       _desiredPrefixPixelPosition = -1;
      }
     _jumpElement = _element;
     _element = element;
    }
  }

 void jump(LpexDocumentLocation documentLocation)
  {
   if (!_ignoreChanges)
    {
     Element element = _view.document().elementList().elementAt(documentLocation.element);
     jump(element, documentLocation.position);
    }
  }

 void resetJumpPending()
  {
   _jumpElement = null;
  }

 void processPendingJump()
  {
   if (_jumpElement != null)
    {
     Element element = _element;
     _element = _jumpElement;
     _jumpElement = null;
     Screen screen = _view.screen();
     screen.build();

     int rows = screen.rows();
     int i;
     for (i = 1; i <= rows && screen.element(i) != element; i++) {;}
     if (i <= rows)
      {
       screen.setCursorRow(i);
      }
     _element = element;
    }
  }

 void setPosition(int x, int y)
  {
   if (_ignoreChanges)
    {
     return;
    }

   Screen screen = _view.screen();
   screen.build();
   int row = (y / screen.textFontMetrics().textHeight()) + 1;

   Element element = null;
   if (row < 1)
    {
     element = screen.element(1).prevVisible(_view);
     row = 1;
    }
   if (row > screen.rows())
    {
     row = screen.rows();
     element = screen.element(row);
     if (element != null)
      {
       element = element.nextVisible(_view);
      }
    }

   if (element == null)
    {
     element = screen.element(row);
    }
   while (element == null && row > 1)
    {
     row--;
     element = screen.element(row);
    }

   if (element != null)
    {
     ElementView elementView = element.elementView(_view);
     int expandHideAreaWidth = screen.expandHideAreaWidth();
     int prefixAreaWidth = screen.prefixAreaWidth();
     if (x > expandHideAreaWidth &&
         x < expandHideAreaWidth + prefixAreaWidth)
      {
       _view.setInPrefix(true);
       _prefixPosition = _view.prefixPosition(elementView, x - expandHideAreaWidth);
       _desiredPrefixPixelPosition = -1;
       if (_element != element)
        {
         _position = 1;
         //*as* setDirection(..); ?!?!?!
         _desiredPixelPosition = -1;
        }
      }
     else
      {
       _view.setInPrefix(false);
       int screenWidth = _view.screen().width();
       if (x > screenWidth)
        {
         x = screenWidth;
        }
       else if (x < expandHideAreaWidth + prefixAreaWidth)
        {
         x = expandHideAreaWidth + prefixAreaWidth - 1;
        }
       _position = _view.position(elementView, screen.scroll() + x -
                                               expandHideAreaWidth - prefixAreaWidth);
       if (_position < 1)
        {
         _position = 1;
        }
       //*as* setDirection(..); ?!?!?!
       _desiredPixelPosition = -1;
       if (element != _element)
        {
         _prefixPosition = 1;
         _desiredPrefixPixelPosition = -1;
        }
      }

     screen.setCursorRow(row);
     _element = element;
    }
  }

 boolean above(Element element, int position)
  {
   return compare(element, position) == 1;
  }

 boolean below(Element element, int position)
  {
   return compare(element, position) == -1;
  }

 boolean equals(Element element, int position)
  {
   return compare(element, position) == 0;
  }

 int compare(Element element, int position)
  {
   if (element == _element)
    {
     if (position == _position)
      {
       return 0;
      }
     return (position > _position)? 1 : -1;
    }

   ElementList elementList = _view.document().elementList();
   return (elementList.ordinalOf(element) > elementList.ordinalOf(_element))? 1 : 0;
  }

 /**
  * Record the desired pixel position as the cursor pixel position (inside
  * the current element), and similarly the desired pixel prefix position.
  * Used when moving cursor vertically (between lines), and trying to keep
  * its alignment inside e.g., variable-pitch text.
  */
 private void preserveDesiredPosition()
  {
   if (!_ignoreChanges && _element != null)
    {
     if (_desiredPixelPosition < 0)
      {
       // record the pixel position in displayText that corresponds to
       // _position into the element text
       _desiredPixelPosition =
         // in bidi, cursor position is not the curr char's pixel position...
         //_element.elementView(_view).pixelPosition(_position);
         _view.cursorPixelPosition(_element, _position);
      }

     if (_desiredPrefixPixelPosition < 0)
      {
       _desiredPrefixPixelPosition =
         _view.prefixPixelPosition(_element.elementView(_view), _prefixPosition);
      }
    }
  }

 /**
  * Set _position & _prefixPosition according to their
  * desired pixel positions (if any).
  */
 private void adjustToDesiredPosition()
  {
   if (!_ignoreChanges && _element != null)
    {
     if (_desiredPixelPosition >= 0)
      {
       _position =
         _view.position(_element.elementView(_view), _desiredPixelPosition);
      }

     if (_desiredPrefixPixelPosition >= 0)
      {
       _prefixPosition =
         _view.prefixPosition(_element.elementView(_view), _desiredPrefixPixelPosition);
      }
    }
  }

 void blockTop()
  {
   if (!_ignoreChanges)
    {
     if (Block.type() != Block.NONE && Block.view() == _view)
      {
       jump(Block.topElement(), Block.topPosition());
      }
    }
  }

 void blockBottom()
  {
   if (!_ignoreChanges)
    {
     if (Block.type() != Block.NONE && Block.view() == _view)
      {
       jump(Block.bottomElement(), Block.bottomPosition());
      }
    }
  }

 /**
  * Return the current (cursor) position as an LpexDocumentLocation.
  */
 LpexDocumentLocation documentLocation()
  {
   int element = _view.document().elementList().ordinalOf(element());
   return new LpexDocumentLocation(element, position());
  }

 int emphasisLength()
  {
   if (_emphasisLength > 0)
    {
     // if the cursor moved away from the emphasis, clear it
     if (_element != _emphasisElement || _position != _emphasisPosition)
      {
       _emphasisLength = 0;
      }
    }

   return _emphasisLength;
  }

 /**
  * Clear / set a new emphasis from the current position.
  */
 void setEmphasisLength(int emphasisLength)
  {
   if (!_ignoreChanges)
    {
     if (emphasisLength > 0)
      {
       _emphasisLength   = emphasisLength;
       _emphasisElement  = _element;
       _emphasisPosition = _position;
      }
     else
      {
       _emphasisLength = 0;
      }
    }
  }

 /**
  * Get a Preserve object from the cache.
  */
 Preserve preserve()
  {
   Preserve preserve;
   if (_cachedPreserves != null)
    {
     preserve = _cachedPreserves;
     _cachedPreserves = preserve._next;
    }
   else
    {
     preserve = new Preserve();
    }

   preserve.init();
   preserve._next = _topPreserve;
   _topPreserve = preserve;

   return preserve;
  }

 /**
  * Dispose a Preserve object & return it to the cache.
  */
 void disposePreserve(Preserve preserve)
  {
   preserve.reset();
   Preserve prevPreserve = null;
   for (Preserve p = _topPreserve; p != null; p = p._next)
    {
     if (p == preserve)
      {
       if (prevPreserve == null)
        {
         _topPreserve = preserve._next;
        }
       else
        {
         prevPreserve._next = preserve._next;
        }

       preserve._next = _cachedPreserves;
       _cachedPreserves = preserve;
       break;
      }

     prevPreserve = p;
    }
  }

 /**
  * Ask to temporarily ignore any changes happening to this position.
  * Called during the processing of View.joinElements() and View.splitElement().
  */
 void setIgnoreChanges(boolean ignoreChanges)
  {
   _ignoreChanges = ignoreChanges;
  }

 void elementRemoved(Element element)
  {
   if (!_ignoreChanges)
    {
     if (_element == element)
      {
       if (element.next() != null)
        {
         _element = element.next();
        }
       else
        {
         _element = element.prev();
        }
       _position = 1;
       setDirection(LTR);
       _desiredPixelPosition = -1;
       _prefixPosition = 1;
       _desiredPrefixPixelPosition = -1;
      }

     if (_emphasisElement == element)
      {
       _emphasisLength = 0;
       _emphasisElement = null;
      }

     if (_jumpElement == element)
      {
       if (element.next() != null)
        {
         _jumpElement = element.next();
        }
       else
        {
         _jumpElement = element.prev();
        }
      }

     for (Preserve preserve = _topPreserve;
          preserve != null;
          preserve = preserve._next)
      {
       preserve.elementRemoved(element);
      }
    }
  }

 void textInserted(Element element, int position, int length)
  {
   if (!_ignoreChanges)
    {
     if (_element == element && _position >= position)
      {
       _position += length;
       _desiredPixelPosition = -1;
      }

     for (Preserve preserve = _topPreserve;
          preserve != null;
          preserve = preserve._next)
      {
       preserve.textInserted(element, position, length);
      }
    }
  }

 void prefixTextInserted(Element element, int prefixPosition, int length)
  {
   if (!_ignoreChanges)
    {
     if (_element == element && _prefixPosition >= prefixPosition)
      {
       _prefixPosition += length;
       _desiredPrefixPixelPosition = -1;
      }

     for (Preserve preserve = _topPreserve;
          preserve != null;
          preserve = preserve._next)
      {
       preserve.prefixTextInserted(element, prefixPosition, length);
      }
    }
  }

 void textDeleted(Element element, int position, int length)
  {
   if (!_ignoreChanges)
    {
     if (_element == element && _position > position)
      {
       if (_position >= position + length)
        {
         _position -= length;
        }
       else
        {
         _position = position;
        }
       _desiredPixelPosition = -1;
      }

     for (Preserve preserve = _topPreserve;
          preserve != null;
          preserve = preserve._next)
      {
       preserve.textDeleted(element, position, length);
      }
    }
  }

 void prefixTextDeleted(Element element, int prefixPosition, int length)
  {
   if (!_ignoreChanges)
    {
     if (_element == element && _prefixPosition > prefixPosition)
      {
       if (_prefixPosition >= prefixPosition + length)
        {
         _prefixPosition -= length;
        }
       else
        {
         _prefixPosition = prefixPosition;
        }
       _desiredPrefixPixelPosition = -1;
      }

     for (Preserve preserve = _topPreserve;
          preserve != null;
          preserve = preserve._next)
      {
       preserve.prefixTextDeleted(element, prefixPosition, length);
      }
    }
  }

 void splitElement(Element element, int position)
  {
   if (!_ignoreChanges)
    {
     if (_element == element && _position >= position)
      {
       _element = element.next();
       _position = _position - position + 1;
       _prefixPosition = 1;
       _desiredPixelPosition = -1;
       _desiredPrefixPixelPosition = -1;
       _view.screen().setCursorRow(_view.screen().cursorRow() + 1);
      }

     for (Preserve preserve = _topPreserve;
          preserve != null;
          preserve = preserve._next)
      {
       preserve.splitElement(element, position);
      }
    }
  }

 void joinElements(Element element1, Element element2)
  {
   if (!_ignoreChanges)
    {
     if (_element == element2)
      {
       _element = element1;
       _position = element1.length() + _position;
       _prefixPosition = 1;
       _desiredPixelPosition = -1;
       _desiredPrefixPixelPosition = -1;
      }

     for (Preserve preserve = _topPreserve;
          preserve != null;
          preserve = preserve._next)
      {
       preserve.joinElements(element1, element2);
      }
    }
  }


 /**
  * This class maintains information necessary to restore the enclosing
  * document position following an operation.
  *
  * <p>Note that the preserved document location may, nevertheless, be updated
  * during certain text operations that affect it - e.g., when the text
  * underneath the preserved location is being deleted.  This feature should be
  * taken into consideration when using such API methods as
  *   LpexView#doCommand(LpexDocumentLocation commandLocation, String commandString),
  * which promise not to affect the current (cursor) location.</p>
  */
 final class Preserve
 {
  Preserve _next;

  private Element _element;
  private int     _position;
  private int     _desiredPixelPosition;

  private int     _emphasisLength;
  private Element _emphasisElement;
  private int     _emphasisPosition;

  private int     _prefixPosition;
  private int     _desiredPrefixPixelPosition;

  private Element _jumpElement;
  private int     _cursorRow;


  void init()
  {
   this._element                    = DocumentPosition.this._element;
   this._position                   = DocumentPosition.this._position;
   this._desiredPixelPosition       = DocumentPosition.this._desiredPixelPosition;

   this._emphasisLength             = DocumentPosition.this._emphasisLength;
   this._emphasisElement            = DocumentPosition.this._emphasisElement;
   this._emphasisPosition           = DocumentPosition.this._emphasisPosition;

   this._prefixPosition             = DocumentPosition.this._prefixPosition;
   this._desiredPrefixPixelPosition = DocumentPosition.this._desiredPrefixPixelPosition;

   this._jumpElement                = DocumentPosition.this._jumpElement;
   _cursorRow = _view.screen().cursorRow();
  }

  void reset()
  {
   this._element         = null;
   this._emphasisElement = null;
   this._jumpElement     = null;
  }

  void restore()
  {
   DocumentPosition.this._element                    = this._element;
   DocumentPosition.this._position                   = this._position;
   DocumentPosition.this._desiredPixelPosition       = this._desiredPixelPosition;

   DocumentPosition.this._emphasisLength             = this._emphasisLength;
   DocumentPosition.this._emphasisElement            = this._emphasisElement;
   DocumentPosition.this._emphasisPosition           = this._emphasisPosition;

   DocumentPosition.this._prefixPosition             = this._prefixPosition;
   DocumentPosition.this._desiredPrefixPixelPosition = this._desiredPrefixPixelPosition;

   _view.screen().setCursorRow(_cursorRow);
   DocumentPosition.this._jumpElement                = this._jumpElement;
  }

  void elementRemoved(Element element)
  {
   if (this._element == element)
    {
     if (element.next() != null)
      {
       this._element = element.next();
      }
     else
      {
       this._element = element.prev();
      }

     this._position = 1;
     this._desiredPixelPosition = -1;
     this._prefixPosition = 1;
     this._desiredPrefixPixelPosition = -1;
    }

   if (this._emphasisElement == element)
    {
     this._emphasisLength = 0;
     this._emphasisElement = null;
    }

   if (this._jumpElement == element)
    {
     if (element.next() != null)
      {
       this._jumpElement = element.next();
      }
     else
      {
       this._jumpElement = element.prev();
      }
    }
  }

  void textInserted(Element element, int position, int len)
  {
   if (this._element == element && this._position >= position)
    {
     this._position += len;
     this._desiredPixelPosition = -1;
    }
  }

  void prefixTextInserted(Element element, int prefixPosition, int len)
  {
   if (this._element == element && this._prefixPosition >= prefixPosition)
    {
     this._prefixPosition += len;
     this._desiredPrefixPixelPosition = -1;
    }
  }

  /**
   * Adjust the preserved position when the text underneath is being deleted.
   */
  void textDeleted(Element element, int position, int len)
  {
   if (this._element == element && this._position > position)
    {
     if (this._position >= position + len)
      {
       this._position -= len;
      }
     else
      {
       this._position = position;
      }

     this._desiredPixelPosition = -1;
    }
  }

  void prefixTextDeleted(Element element, int prefixPosition, int len)
  {
   if (this._element == element && this._prefixPosition > prefixPosition)
    {
     if (this._prefixPosition >= prefixPosition + len)
      {
       this._prefixPosition -= len;
      }
     else
      {
       this._prefixPosition = prefixPosition;
      }

     this._desiredPrefixPixelPosition = -1;
    }
  }

  /**
   * If the preserved position is on that part of the element being split into
   * a new element, adjust it to the new element.
   */
  void splitElement(Element element, int position)
  {
   if (this._element == element && this._position >= position)
    {
     this._element = element.next();
     this._position = this._position - position + 1;
     this._desiredPixelPosition = -1;
     this._prefixPosition = 1;
     this._desiredPrefixPixelPosition = -1;
     this._cursorRow += 1;
    }
  }

  /**
   * If the preserved position is on the element being joined, adjust it to the
   * new compound element.
   */
  void joinElements(Element element1, Element element2)
  {
   if (this._element == element2)
    {
     this._element = element1;
     this._position = element1.length() + this._position;
     this._desiredPixelPosition = -1;
     this._prefixPosition = 1;
     this._desiredPrefixPixelPosition = -1;
    }
  }
 }
}