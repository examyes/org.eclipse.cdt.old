//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SetCommand - handles the set command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>set</b> command.
 */
final class SetCommand
{
 static boolean doCommand(View view, String parameters)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (!st.hasMoreTokens())
   {
    return CommandHandler.noParameters(view, "set");
   }

  String token = st.nextToken();
  Parameter parameter = Parameters.getParameter(token);
  String qualifier = Parameters.getQualifierString(token);
  if (parameter == null || parameter.isQueryOnly(qualifier))
   {
    return CommandHandler.invalidParameter(view, token, "set");
   }

  int tokenIndex = parameters.indexOf(token);
  parameters = parameters.substring(tokenIndex + token.length());
  if (parameters.length() > 0 && parameters.charAt(0) == ' ')
   {
    parameters = parameters.substring(1);
   }

  return parameter.set(view, qualifier, parameters);
 }
}