//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ExpandTabsParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ExpandTabsParameter extends ParameterOnOffDefault
{
 private static ExpandTabsParameter _parameter;

 static ExpandTabsParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ExpandTabsParameter();
   }
  return _parameter;
 }

 private ExpandTabsParameter()
 {
  super(PARAMETER_EXPAND_TABS, true);
 }

 boolean setValue(View view, int value)
 {
  if (view != null)
   {
    view.setExpandTabs(value);
   }
  return true;
 }

 void currentValueChanged(View view)
 {
  view.expandTabsChanged();
 }

 int value(View view)
 {
  return (view != null)? view.expandTabs() : Parameter.DEFAULT;
 }
}