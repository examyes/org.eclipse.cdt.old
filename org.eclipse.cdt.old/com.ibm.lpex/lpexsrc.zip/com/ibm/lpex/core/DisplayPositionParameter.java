//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DisplayPositionParameter - displayPosition parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>displayPosition</b> parameter.
 */
final class DisplayPositionParameter extends ParameterIntegerOnly
{
 private static DisplayPositionParameter _parameter;

 static DisplayPositionParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new DisplayPositionParameter();
   }
  return _parameter;
 }

 private DisplayPositionParameter()
 {
  super(PARAMETER_DISPLAY_POSITION);
 }

 boolean setValue(View view, String qualifier, int value)
 {
  if (value <= 0)
   {
    return CommandHandler.invalidParameter(view, String.valueOf(value), "set " + name());
   }

  if (view != null)
   {
    Element element = view.documentPosition().element();
    if (element != null)
     {
      int position = view.positionFromDisplayPosition(element.elementView(view), value);
      view.documentPosition().jump(element, position);
     }
   }

  return true;
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation,
                          String qualifier)
 {
  return view != null && documentLocation != null &&
         view.document().elementList().elementAt(documentLocation.element) != null;
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null && documentLocation != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    if (element != null)
     {
      // in SBCS it's enough to return the character offset into the display text:
      // return element.elementView(view).displayCharPosition(documentLocation.position);
      return view.displayColumn(element.elementView(view), documentLocation.position);
     }
   }

  return 0;
 }
}