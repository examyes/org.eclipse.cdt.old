//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// StyleAttributesParameter - manages the styleAttributes parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>styleAttributes</b> parameter.
 */
final class StyleAttributesParameter extends Parameter
{
 private static StyleAttributesParameter _parameter;

 static StyleAttributesParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new StyleAttributesParameter();
   }
  return _parameter;
 }

 private StyleAttributesParameter()
 {
  super(LpexConstants.PARAMETER_STYLE_ATTRIBUTES);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  int styleId = Screen.styleId(qualifier);
  if (styleId == Screen.STYLE_INVALID && qualifier.length() != 1)
   {
    return CommandHandler.invalidParameter(view, qualifier, "set " + name());
   }
  if (!StyleAttributes.checkStyleAttributes(view, parameters, "set " + name(qualifier)))
   {
    return false;
   }

  StyleAttributes styleAttributes = StyleAttributes.getStyleAttributes(parameters);
  if (view != null)
   {
    // (a) predefined style attribute (e.g., "default", "emphasis")
    if (styleId != Screen.STYLE_INVALID)
     {
      view.screen().setStyleAttributes(styleId, styleAttributes);
      // for our reserved sequence-numbers styles, also update view's styles list
      if (styleId == Screen.STYLE_SEQUENCE_NUMBER)
       {
        view.styleAttributesList().set(Screen.CHAR_STYLE_SEQUENCE_NUMBER, styleAttributes);
       }
      else if (styleId == Screen.STYLE_SEQUENCE_TEXT)
       {
        view.styleAttributesList().set(Screen.CHAR_STYLE_SEQUENCE_TEXT, styleAttributes);
       }
     }

    // (b) style character (e.g., '!', 'c')
    else
     {
      char styleCharacter = qualifier.charAt(0);
      if (styleCharacter == '!')
       {
        view.screen().setStyleAttributes(Screen.STYLE_DEFAULT, styleAttributes);
       }
      else
       {
        view.styleAttributesList().set(styleCharacter, styleAttributes);
       }
     }
   }

  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    StyleAttributes styleAttributes = null;
    int styleId = Screen.styleId(qualifier);
    if (styleId != Screen.STYLE_INVALID)
     {
      styleAttributes = view.screen().styleAttributes(styleId);
     }
    else if (qualifier.length() == 1)
     {
      char styleCharacter = qualifier.charAt(0);
      if (styleCharacter == '!')
       {
        styleAttributes = view.screen().styleAttributes(Screen.STYLE_DEFAULT);
       }
      else
       {
        styleAttributes = view.styleAttributesList().find(styleCharacter);
       }
     }

    if (styleAttributes != null)
     {
      return styleAttributes.queryString();
     }
   }

  return null;
 }
}