//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FindTextOptions - findText command settings.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import com.ibm.lpex.util.RegularExpression;


/**
 * The set of options for the <b>findText</b> command.
 */
final class FindTextOptions
{
 boolean _up;
 boolean _checkStart;
 boolean _replace;
 boolean _all;
 boolean _quiet;
 boolean _noBeep;
 boolean _mark;
 boolean _columns;
 int     _startColumn = 1;
 int     _endColumn = 80;
 boolean _block;
 boolean _wrap = true;
 boolean _asis;
 boolean _emphasis = true;
 String  _replaceText;
 String  _findText;
 RegularExpression _regularExpression;
 int     _foundTextLength;
}