//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FindTextOptions - findText command settings.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import com.ibm.lpex.util.RegularExpression;


/**
 * Set of options for running a <b>findText</b> command.
 *
 * The parameters for the <b>findText</b> command are divided into two groups.
 * The first group of optional parameters includes up, checkStart, replace,
 * all, quiet, and noBeep.  If only these options are specified, the
 * <b>findText</b> command will use the values indicated by the
 * <b>current.findText.xxx</b> parameters to perform the search.
 *
 * If you specify any of the parameters from the second group, the
 * <b>current.findText.xxx</b> parameters will be ignored and only
 * the options specified will be taken into account.
 */
final class FindTextOptions
{
 // 1st group
 boolean _up;
 boolean _checkStart;
 boolean _replace;
 boolean _exclude;
 boolean _all;
 boolean _quiet;
 boolean _noBeep;

 // 2nd group
 boolean _mark;
 boolean _columns;
 int     _startColumn = 1;
 int     _endColumn = 80;
 boolean _block;
 boolean _wrap = true;
 boolean _asis;
 boolean _emphasis = true;
 String  _replaceText;
 String  _findText;
 RegularExpression _regularExpression;
 int     _foundTextLength;
}