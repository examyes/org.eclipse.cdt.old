//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ScrollParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ScrollParameter extends ParameterIntegerOnly
{
 private static ScrollParameter _parameter;

 static ScrollParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ScrollParameter();
   }
  return _parameter;
 }

 private ScrollParameter()
 {
  super(PARAMETER_SCROLL);
 }

 boolean setValue(View view, String qualifier, int value)
 {
  if (view != null)
   {
    view.screen().setScroll(value);
   }

  return true;
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.screen().scroll() : 0;
 }
}