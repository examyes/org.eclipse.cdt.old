//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FormatLineTextParameter - handles the formatLineText parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>formatLineText</b> parameter.
 */
final class FormatLineTextParameter extends Parameter
{
   private static FormatLineTextParameter _parameter;

   static FormatLineTextParameter getParameter()
   {
      if (_parameter == null)
         _parameter = new FormatLineTextParameter();
      return _parameter;
   }

   private FormatLineTextParameter()
   {
     super(LpexConstants.PARAMETER_FORMAT_LINE_TEXT);
   }

   boolean set(View view, String qualifier, String parameters)
   {
      if (view != null)
         view.screen().setFormatLineText(parameters);
      return true;
   }

   String query(View view, LpexDocumentLocation documentLocation, String qualifier)
   {
      return (view != null)? view.screen().formatLineText() : null;
   }
}