//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterCharacterOnly - base class for simple character parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Base, abstract class for simple character parameters (without install,
 * default, and current settings).
 *
 * <p>Note that if the parameter is longer than one character, Integer.decode()
 * is used to read in values for the set command.
 * Method Integer.decode(String) decodes a String into an Integer.  It accepts
 * decimal, hexadecimal, and octal numbers, in the following formats:
 *   [-]      decimal constant
 *   [-] 0x   hex constant
 *   [-] #    hex constant
 *   [-] 0    octal constant
 * The result is negative if the first character of the specified String is
 * the negative sign.  No whitespace characters are permitted in the String.
 */
abstract class ParameterCharacterOnly extends ParameterCharacterQuery
{
 ParameterCharacterOnly(String name)
 {
  super(name);
 }

 boolean isQueryOnly(String qualifier)
 {
  return false;
 }

 boolean set(View view, String qualifier, String parameters)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (!st.hasMoreTokens())
   {
    return CommandHandler.incomplete(view, "set " + name(qualifier));
   }

  String token = st.nextToken();
  char value;
  if (token.length() > 1)
   {
    try
     {
      value = (char)Integer.decode(token).intValue();
     }
    catch(NumberFormatException e)
     {
      return CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
     }
   }
  else
   {
    value = token.charAt(0);
   }

  if (st.hasMoreTokens())
   {
    return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name(qualifier));
   }

  return setValue(view, qualifier, value);
 }

 abstract boolean setValue(View view, String qualifier, char value);
}