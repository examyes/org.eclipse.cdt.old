//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterOnOffQuery
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

abstract class ParameterOnOffQuery extends ParameterQuery
{
 ParameterOnOffQuery(String name)
 {
  super(name);
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return view != null;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (isQueryAvailable(view, documentLocation, qualifier))
   {
    return value(view, documentLocation, qualifier)? "on" : "off";
   }
  return null;
 }

 abstract boolean value(View view, LpexDocumentLocation documentLocation, String qualifier);
}