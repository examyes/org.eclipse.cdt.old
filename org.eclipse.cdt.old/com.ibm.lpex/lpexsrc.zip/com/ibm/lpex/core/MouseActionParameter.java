//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// MouseActionParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class MouseActionParameter extends ParameterWordOnly
{
 private static MouseActionParameter _parameter;

 static MouseActionParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new MouseActionParameter();
   }
  return _parameter;
 }

 private MouseActionParameter()
 {
  super(PARAMETER_MOUSE_ACTION);
 }

 boolean setValue(View view, String qualifier, String value)
 {
  return (view != null)? view.actionHandler().defineMouseAction(qualifier, value) : true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.actionHandler().mouseActionString(qualifier) : null;
 }
}