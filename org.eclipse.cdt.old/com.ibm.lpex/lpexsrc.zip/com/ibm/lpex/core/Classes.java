//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Classes - manages the element classes for one view.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages the element classes registered in one document view.
 * It holds a list of ClassNodes for the classes registered in the view.
 * There is one instance of this class for every document view.
 */
final class Classes
{
 static final long
  NONE      = 0x0000000000000000L,
  DEFAULT   = 0x0000000000000001L,
  FIND_TEXT = 0x8000000000000000L,
  USER      = 0x7ffffffffffffffeL,    // classes available for user
  ALL       = 0xffffffffffffffffL;    // bit-mask to see if more bits available

 private long _usedBits = FIND_TEXT | DEFAULT;
 private ClassNode _firstClass;       // list of registered classes


 private boolean bitsAvailable()
 {
  return _usedBits != ALL;
 }

 /**
  * Register an element class.  Return its allocated bit-mask, or 0 if failed.
  */
 long register(String name)
 {
  if (_usedBits != ALL)
   {
    ClassNode classNode = find(name);
    if (classNode != null)
     {
      return classNode.mask();
     }

    long mask = 1;
    for (int i = 0; i < 64; i++)
     {
      if ((_usedBits & mask) == 0)
       {
        _usedBits |= mask;
        classNode = new ClassNode(name, mask);
        classNode._next = _firstClass;
        _firstClass = classNode;
        return mask;
       }
      mask <<= 1;
     }
   }

  return 0;
 }

 void deregister(String name)
 {
  ClassNode previousNode = null;
  for (ClassNode classNode = _firstClass;
       classNode != null;
       classNode = classNode._next)
   {
    if (classNode.name().equals(name))
     {
      _usedBits &= ~classNode.mask();
      if (previousNode == null)
       {
        _firstClass = classNode._next;
       }
      else
       {
        previousNode._next = classNode._next;
       }
      break;
     }
    previousNode = classNode;
   }
 }

 /**
  * Return the bit-mask for one or more registered classes.
  */
 long mask(String names)
 {
  long mask = 0;
  LpexStringTokenizer st = new LpexStringTokenizer(names);
  while (st.hasMoreTokens())
   {
    String name = st.nextToken();
    ClassNode classNode = find(name);
    if (classNode != null)
     {
      mask |= classNode.mask();
     }
   }
  return mask;
 }

 String names(long mask)
 {
  boolean first = true;
  long currentMask = 1;
  StringBuffer names = new StringBuffer(220);
  for (int i = 0; i < 64; i++)
   {
    if ((mask & currentMask) != 0)
     {
      ClassNode classNode = find(currentMask);
      if (classNode != null)
       {
        if (!first)
         {
          names.append(' ');
         }
        first = false;
        names.append(classNode.name());
       }
     }
    currentMask <<= 1;
   }
  return names.toString();
 }

 String list()
 {
  boolean first = true;
  StringBuffer list = new StringBuffer(220);
  for (ClassNode classNode = _firstClass;
       classNode != null;
       classNode = classNode._next)
   {
    if (!first)
     {
      list.append(' ');
     }
    first = false;
    list.append(classNode.name());
   }

  return list.toString();
 }

 private ClassNode find(String name)
 {
  for (ClassNode classNode = _firstClass;
       classNode != null;
       classNode = classNode._next)
   {
    if (classNode.name().equals(name))
     {
      return classNode;
     }
   }

  return null;
 }

 private ClassNode find(long mask)
 {
  for (ClassNode classNode = _firstClass;
       classNode != null;
       classNode = classNode._next)
   {
    if ((mask & classNode.mask()) != 0)
     {
      return classNode;
     }
   }

  return null;
 }
}


/**
 * Double-linked node describing one registered element class.
 */
final class ClassNode extends ListNode
{
 ClassNode _next;
 private String _name;
 private long _mask;

 ClassNode(String name, long mask)
 {
  _name = name;
  _mask = mask;
 }

 String name()
 {
  return _name;
 }

 long mask()
 {
  return _mask;
 }
}