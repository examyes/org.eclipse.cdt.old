//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterCharacterDefault - base class for character parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Base, abstract class for character parameters with install, default, and
 * current settings.
 *
 * <p>Note that if the parameter is longer than one character, Integer.decode()
 * is used to read in values for the set commands.
 * Method Integer.decode(String) decodes a String into an Integer.  It accepts
 * decimal, hexadecimal, and octal numbers, in the following formats:
 *   [-]      decimal constant
 *   [-] 0x   hex constant
 *   [-] #    hex constant
 *   [-] 0    octal constant
 * The result is negative if the first character of the specified String is
 * the negative sign.  No whitespace characters are permitted in the String.
 */
abstract class ParameterCharacterDefault extends ParameterDefault
{
 private char    _hardCodedValue;
 private char    _installValue;
 private boolean _installValueLoaded;
 private char    _defaultValue;
 private boolean _defaultValueLoaded;


 /**
  * Constructor.
  * Installs change listeners on the Install and defaults profiles.
  *
  * @param name parameter's name
  * @param hardCodedValue hard-coded value of the parameter
  */
 ParameterCharacterDefault(String name, char hardCodedValue)
  {
   super(name);
   _hardCodedValue = hardCodedValue;
   Install.addProfileChangedListener(new Install.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _installValueLoaded = false;
       if (defaultValue() == 0)
        {
         for (Document document = Document._firstDocument;
              document != null;
              document = document._next)
          {
           for (View view = document._firstView; view != null; view = view._next)
            {
             if (value(view) == 0)
              {
               currentValueChanged(view);
              }
            }
          }
        }
      }
    });

   Profile.addProfileChangedListener(new Profile.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _defaultValueLoaded = false;
       for (Document document = Document._firstDocument;
            document != null;
            document = document._next)
        {
         for (View view = document._firstView; view != null; view = view._next)
          {
           if (value(view) == 0)
            {
             currentValueChanged(view);
            }
          }
        }
      }
    });
  }

 /**
  * Retrieve the install value or, lacking that, the hard-coded value.
  */
 char installValue()
  {
   if (!_installValueLoaded)
    {
     char value = 0;
     String install = Install.getString(PARAMETER_INSTALL + name());
     if (install != null)
      {
       try
        {
         value = (char)Integer.decode(install).intValue();
        }
       catch(NumberFormatException e) {}
      }

     if (value == 0)
      {
       _installValue = _hardCodedValue;
      }
     else
      {
       _installValue = value;
      }

     _installValueLoaded = true;
    }

   return _installValue;
  }

 protected void loadDefaultValue()
  {
   if (!_defaultValueLoaded)
    {
     _defaultValue = 0;
     String value = Profile.getString(PARAMETER_DEFAULT + name());
     if (value != null)
      {
       try
        {
         _defaultValue = (char)Integer.decode(value).intValue();
        }
       catch(NumberFormatException e) {}
      }

     _defaultValueLoaded = true;
    }
  }

 char defaultValue()
  {
   loadDefaultValue();
   return _defaultValue;
  }

 boolean setDefaultValue(char value)
  {
   _defaultValue = value;
   _defaultValueLoaded = true;

   if (_defaultValue != 0)
    {
     Profile.putString(PARAMETER_DEFAULT + name(), String.valueOf(_defaultValue));
    }
   else
    {
     Profile.remove(PARAMETER_DEFAULT + name());
    }

   for (Document document = Document._firstDocument;
        document != null;
        document = document._next)
    {
     for (View view = document._firstView; view != null; view = view._next)
      {
       if (value(view) == 0)
        {
         currentValueChanged(view);
        }
      }
    }

   return true;
  }

 char currentValue(View view)
  {
   char value = value(view);
   if (value == 0)
    {
     value = defaultValue();
     if (value == 0)
      {
       value = installValue();
      }
    }

   return value;
  }

 boolean set(View view, String qualifier, String parameters)
  {
   char value = 0;
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("default"))
      {
       value = 0;
      }
     else
      {
       if (token.length() > 1)
        {
         try
          {
           value = (char)Integer.decode(token).intValue();
          }
         catch(NumberFormatException e)
          {
           return CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
          }
        }
       else
        {
         value = token.charAt(0);
        }
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name(qualifier));
      }
    }

   return setValue(view, qualifier, value);
  }

 abstract boolean setValue(View view, String qualifier, char value);

 boolean setDefault(View view, String qualifier, String parameters)
  {
   char value = 0;
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("install"))
      {
       value = 0;
      }
     else
      {
       if (token.length() > 1)
        {
         try
          {
           value = (char)Integer.decode(token).intValue();
          }
         catch(NumberFormatException e)
          {
           return CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
          }
        }
       else
        {
         value = token.charAt(0);
        }
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(),
                                              "set " + PARAMETER_DEFAULT + name(qualifier));
      }
    }

   return setDefaultValue(value);
  }

 void currentValueChanged(View view) {}

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   if (view != null)
    {
     char value = value(view);
     return (value == 0)? "default" : String.valueOf(value);
    }

   return "0";
  }

 abstract char value(View view);

 String queryInstall(String qualifier)
  {
   return String.valueOf(installValue());
  }

 String queryDefault(String qualifier)
  {
   char value = defaultValue();
   return (value == 0)? "install" : String.valueOf(value);
  }

 String queryCurrent(View view, String qualifier)
  {
   return String.valueOf(currentValue(view));
  }
}