//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// KeyListenerList - handles a view's list of LpexKeyListeners.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.widgets.Event;

/**
 * This class manages the LpexKeyListeners for a document view.
 * There is up to one instance of this class created for each LpexView.
 */
final class KeyListenerList extends List
{
 KeyListenerList() {}

 /**
  * Add an LpexKeyListener.  A listener is only registered once, additional
  * calls are without effect.
  */
 void addListener(LpexKeyListener listener)
 {
  if (find(listener) == null)
   {
    addAfter(null, new ListenerNode(listener));
   }
 }

 /**
  * Remove an LpexKeyListener, if registered.
  * @return true if there are no more registered LpexKeyListeners in this list
  */
 boolean removeListener(LpexKeyListener listener)
 {
  if (listener != null)
   {
    ListenerNode node = find(listener);
    if (node != null)
     {
      remove(node);
     }
   }

  return first() == null;
 }

 /**
  * Send the <i>keyPressed</i> notification event to all registered
  * LpexKeyListeners.
  */
 void keyPressed(Event event)
 {
    beginScanning();
    for (ListenerNode node = (ListenerNode)first();
         node != null;
         node = (ListenerNode)node.next())
     {
      node.listener().keyPressed(event);
     }
    endScanning();
 }

 /**
  * Find a registered LpexKeyListener in the list.
  */
 ListenerNode find(LpexKeyListener listener)
 {
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    if (node.listener() == listener)
     {
      return node;
     }
   }
  return null;
 }


 /**
  * Node for one LpexKeyListener in a KeyListenerList.
  */
 private static class ListenerNode extends ListNode
 {
  private LpexKeyListener _listener;

  ListenerNode(LpexKeyListener listener)
  {
   _listener = listener;
  }

  LpexKeyListener listener()
  {
   return _listener;
  }
 }
}