//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexCopyright - LPEX copyright statements.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Copyright statements for LPEX development.
 */
public interface LpexCopyright
{
 public static final String
  C01   = "(C) Copyright IBM Corporation 2001. All Rights Reserved.",
  C0001 = "(C) Copyright IBM Corporation 2000, 2001. All Rights Reserved.",
  C9901 = "(C) Copyright IBM Corporation 1999, 2001. All Rights Reserved.",
  C9801 = "(C) Copyright IBM Corporation 1998, 2001. All Rights Reserved.",

  C00   = "(C) Copyright IBM Corporation 2000. All Rights Reserved.",
  C9900 = "(C) Copyright IBM Corporation 1999, 2000. All Rights Reserved.",
  C9800 = "(C) Copyright IBM Corporation 1998, 2000. All Rights Reserved.",

  C99   = "(C) Copyright IBM Corporation 1999. All Rights Reserved.",
  C9899 = "(C) Copyright IBM Corporation 1998, 1999. All Rights Reserved.";
}