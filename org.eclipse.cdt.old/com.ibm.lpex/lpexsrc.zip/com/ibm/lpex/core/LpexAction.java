//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexAction - define an LPEX action.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Interface LpexAction can be implemented to define a user action.
 * An action can be assigned to a key or series of keys with the
 * <b>set keyAction</b> editor command, or to a mouse event with the
 * <b>set mouseAction</b> editor command.
 *
 * @see LpexView#defineAction
 * @see com.ibm.lpex.samples.TestAction
 */
public interface LpexAction
{
 /**
  * This method in the defined action will be called to run the action.
  *
  * <p>An action may be run (e.g., from the LPEX command line) with the
  * <b>action</b> editor command, by selecting an associated menu item, or
  * by activating the key or the mouse event to which the action is assigned.
  *
  * @param lpexView the document view in which the action is issued
  */
 public void doAction(LpexView lpexView);

 /**
  * This method in the defined action will be called to query the availability
  * of the action.
  *
  * <p>When this method returns <code>false</code>, menu items associated
  * with this user action will be disabled, the key or mouse event to which
  * this action is assigned will not run it, and neither will the
  * <b>action</b> command.
  *
  * @param lpexView the document view for which the action availability is
  *                 queried
  */
 public boolean available(LpexView lpexView);
}