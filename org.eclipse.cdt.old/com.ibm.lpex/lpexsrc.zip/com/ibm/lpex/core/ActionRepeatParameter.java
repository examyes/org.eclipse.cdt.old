//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ActionRepeatParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ActionRepeatParameter extends ParameterIntegerQuery
{
 private static ActionRepeatParameter _parameter;

 static ActionRepeatParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ActionRepeatParameter();
   }
  return _parameter;
 }

 private ActionRepeatParameter()
 {
  super(PARAMETER_ACTION_REPEAT);
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.actionHandler().repeat() : 0;
 }
}