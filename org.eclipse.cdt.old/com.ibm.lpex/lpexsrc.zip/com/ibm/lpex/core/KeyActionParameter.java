//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// KeyActionParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class KeyActionParameter extends ParameterWordOnly
{
 private static KeyActionParameter _parameter;

 static KeyActionParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new KeyActionParameter();
   }
  return _parameter;
 }

 private KeyActionParameter()
 {
  super(PARAMETER_KEY_ACTION);
 }

 boolean setValue(View view, String qualifier, String value)
 {
  return (view != null)? view.actionHandler().defineKeyAction(qualifier, value) : true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.actionHandler().keyActionString(qualifier) : null;
 }
}