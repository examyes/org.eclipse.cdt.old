//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SystemPropertyParameter - the systemProperty parameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>systemProperty</b> parameter.
 * The parameter provides access to the java.lang.System properties (e.g.,
 * java.home, java.class.path, user.dir, and any -D java invocation setting).
 *
 * <p>This parameter is useful for debugging purposes.  Modifying any system
 * property may not be effective, as LPEX has already initialized by now, its
 * *.properties files for the active locale have been loaded, etc.
 *
 * <p>Due to its specific nature, this parameter has not been documented in
 * the editor Reference.
 */
final class SystemPropertyParameter extends ParameterWordOnly
{
 private static SystemPropertyParameter _parameter;

 static SystemPropertyParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new SystemPropertyParameter();
   }
  return _parameter;
 }

 private SystemPropertyParameter()
 {
  super(PARAMETER_SYSTEM_PROPERTY);
 }

 boolean setValue(View view, String qualifier, String value)
 {
  if (LpexStringTokenizer.isValidQuotedString(value))
   {
    value = LpexStringTokenizer.removeQuotes(value);
   }

  try
   {
    System.setProperty(qualifier, value);
    return true;
   }
  catch(NullPointerException x)
   {
    CommandHandler.noParameters(view, "set " + name());
   }
  catch(Exception x)
   {
    CommandHandler.invalidParameter(view, value, "set " + name());
   }
  return false;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  try
   {
    return System.getProperty(qualifier);
   }
  catch(Exception x) {}
  return null;
 }
}