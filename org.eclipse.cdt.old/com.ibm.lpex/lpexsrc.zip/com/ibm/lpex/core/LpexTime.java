//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexTime
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.Date;


/**
 * This class facilitates code-performance measurements.
 */
public final class LpexTime
{
 private static String _lastEvent;
 private static long _lastTime;


 // no instantiation for this class
 private LpexTime() {}

 public static void recordEvent(String event)
 {
  long time = (new Date()).getTime();
  if (_lastEvent != null)
   {
    long delta = time - _lastTime;
    if (delta > 1)
     {
      System.out.println("\"" + _lastEvent + "\"" + " to " + "\"" + event + "\" =" + delta);
     }
   }

  _lastEvent = event;
  _lastTime = (new Date()).getTime();
 }
}