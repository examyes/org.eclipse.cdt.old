//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CurrentKeyParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class CurrentKeyParameter extends ParameterQuery
{
 private static CurrentKeyParameter _parameter;

 static CurrentKeyParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new CurrentKeyParameter();
   }
  return _parameter;
 }

 private CurrentKeyParameter()
 {
  super(PARAMETER_CURRENT_KEY);
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.actionHandler().currentKeyString() : null;
 }
}