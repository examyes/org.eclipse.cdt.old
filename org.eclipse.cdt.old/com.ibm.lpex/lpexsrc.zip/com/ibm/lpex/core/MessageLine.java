//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// MessageLine - manages the message line.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.MouseTrackListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Layout;
import org.eclipse.swt.widgets.ScrollBar;


/**
 * This class manages the message line of an LpexWindow.
 * There is one instance of this class per instance of LpexWindow.
 */
final class MessageLine extends Composite
                        implements ControlListener, // MessageLine resizes
                                   MouseListener,   // mouse on scroll arrows
                                   MouseMoveListener,
                                   MouseTrackListener,
                                   PaintListener    // paint message line text
{
 private LpexWindow _lpexWindow;

 private boolean _messageValid;
 private String  _text;
 private Font    _font;
 private TextFontMetrics _textFontMetrics;
 private StyleAttributes _styleAttributes;

 private Composite _messageLineText;
 private int       _textStart;

 private boolean   _showArrows;
 private Composite _arrows;
 private boolean   _mouseOnRightArrow, _mouseOnLeftArrow;
 private Color     _arrowEnabledColor, _arrowDisabledColor;


 /**
  * Construct the message line for an LpexWindow.
  */
 MessageLine(LpexWindow lpexWindow)
 {
  super(lpexWindow, 0);
  _lpexWindow = lpexWindow;
  addControlListener(this);
  setLayout(new MessageLineLayout());

  _messageLineText = new Composite(this, SWT.NO_BACKGROUND | SWT.NO_FOCUS); // don't get focus
  _messageLineText.addPaintListener(this);
 }

 /**
  * When first needed, create the message-line text scroll arrows.
  */
 private void createArrows()
 {
  if (_arrows == null)
   {
    _arrowEnabledColor = getDisplay().getSystemColor(SWT.COLOR_WIDGET_FOREGROUND);
    _arrowDisabledColor = getDisplay().getSystemColor(SWT.COLOR_WIDGET_NORMAL_SHADOW);

    _arrows = new Composite(this, SWT.NO_BACKGROUND | SWT.NO_FOCUS);
    _arrows.setBackground(getDisplay().getSystemColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
    _arrows.addMouseListener(this);
    _arrows.addMouseTrackListener(this);
    _arrows.addMouseMoveListener(this);
    _arrows.addPaintListener(new PaintListener()
     {
      public void paintControl(PaintEvent e)
       {
        paintArrowsControl(e);
       }
     });
   }
 }

 /**
  * Return preferred size of the MessageLine.
  */
 public Point computeSize(int wHint, int hHint, boolean changed)
 {
  int height = 0;
  int width = 0;
  if (_textFontMetrics != null)
   {
    height = _textFontMetrics.textHeight();
    width  = _textFontMetrics.spaceWidth() * 40;
   }
  return new Point(width, height);
 }

 /*=============*/
 /*  listeners  */
 /*=============*/

 // ControlListener for the MessageLine Composite
 public void controlMoved(ControlEvent e) {}
 public void controlResized(ControlEvent e)
 {
  updateScrollArrows();
 }

 // MouseTrackListener for the scroll arrows
 public void mouseHover(MouseEvent e) {}
 public void mouseEnter(MouseEvent e)
 {
  mouseMove(e);
 }
 public void mouseExit(MouseEvent e)
 {
  if (_mouseOnRightArrow || _mouseOnLeftArrow)
   {
    _mouseOnRightArrow = _mouseOnLeftArrow = false;
    _arrows.redraw();
   }
 }

 // MouseMoveListener for the scroll arrows
 public void mouseMove(MouseEvent e)
 {
  if (e.y <= _arrows.getSize().y / 2) // on right arrow
   {
    if (!_mouseOnRightArrow)
     {
      _mouseOnRightArrow = true;
      _mouseOnLeftArrow  = false;
      _arrows.redraw();
     }
   }
  else
   {
    if (!_mouseOnLeftArrow)
     {
      _mouseOnLeftArrow  = true;
      _mouseOnRightArrow = false;
      _arrows.redraw();
     }
   }
 }

 // MouseListener for the scroll arrows
 public void mouseDoubleClick(MouseEvent e) {}
 public void mouseUp(MouseEvent e) {}
 public void mouseDown(MouseEvent e)
 {
  if (e.y <= _arrows.getSize().y / 2)  // scroll-right arrow
   {
    scrollRight();
   }
  else                                 // scroll-left arrow
   {
    scrollLeft();
   }
 }

 // PaintListener#paintControl() for the message line text
 public void paintControl(PaintEvent e)
 {
  GC g = e.gc;
  if (_styleAttributes != null)
   {
    Point size = getSize();

    // see setStyleAttributes(), we've already set our background for
    // the entire Control, so paintComponent()'s GC comes ready set to it...
    // g.setBackground(_styleAttributes.backgroundColor().getColor());
    g.fillRectangle(0, 0, size.x, size.y);

    if (_text != null)
     {
      // see setFont(), we've already set our font for the entire
      // Control, so paintComponent()'s GC comes ready set to it...
      // g.setFont(_font.getFont());

      // see setStyleAttributes(), we've already set our foreground for
      // the entire Control, so paintComponent()'s GC comes ready set to it...
      // g.setForeground(_styleAttributes.foregroundColor().getColor());
      g.drawString(_text,
                   _textStart,  // x
                   0,           // y (AWT: _textFontMetrics.maxAscent())
                   true);       // already filled background, draw transparently

      if (_styleAttributes.underline())
       {
        g.drawLine(_textStart, size.y-1,                                        // x1, y1
                   _textStart + _textFontMetrics.stringWidth(_text), size.y-1); // x2, y2
       }
     }
   }

  _messageValid = true;
 }

 // PaintListener#paintControl() for the arrows
 private void paintArrowsControl(PaintEvent e)
 {
  GC g = e.gc;
  Point size = _arrows.getSize();

  // we've already set our background, so paintComponent()'s GC already set to it...
  g.fillRectangle(0, 0, size.x, size.y);

  //  x        x
  //  1        2
  //         3
  //         xx
  //  1xxxxxxxx2
  //  6xxxxxxxx5   y1
  //         xx
  //    3    4
  //   xx
  //  2xxxxxxxx1   y2
  //  5xxxxxxxx6
  //   xx
  //    4
  int x1 = 3;
  int x2 = size.x - 3;
  int y1 = size.y / 3;
  int y2 = size.y - y1;

  if (_mouseOnRightArrow && scrollRightAvailable()) // enabled arrow
   {
    g.setForeground(_arrowEnabledColor);
   }
  else                                              // disabled arrow
   {
    g.setForeground(_arrowDisabledColor);
   }
  int[] rightArrow = { x1, y1-1,  x2, y1-1,  x2-2, y1-3,  x2-2, y1+2,  x2, y1,  x1, y1 };
  g.drawPolygon(rightArrow);

  if (_mouseOnLeftArrow && scrollLeftAvailable())
   {
    g.setForeground(_arrowEnabledColor);
   }
  else
   {
    g.setForeground(_arrowDisabledColor);
   }
  int[] leftArrow = { x2, y2,  x1, y2,  x1+2, y2-2,  x1+2, y2+3,  x1, y2+1,  x2, y2+1 };
  g.drawPolygon(leftArrow);
 }

 /*========================*/
 /*  message line control  */
 /*========================*/

 void setText(String text)
 {
  if (_text == null && text == null)
   {
    return;
   }

  if (_text == null || !(_text.equals(text)))
   {
    _text = text;           // new text
    _textStart = 0;
    _messageValid = false;  // update on the next Screen refresh
   }
 }

 boolean setFont(Font font, TextFontMetrics textFontMetrics)
 {
  if (_font == null || !(_font.equals(font)))
   {
    _font = font;
    _textFontMetrics = textFontMetrics;

     // swt: set font as the Control's, so paintComponent()'s GC comes
     // ready set to it and we don't have to re-set it
     _messageLineText.setFont(_font.getFont());

    _messageValid = false;  // update on the next Screen refresh
    return true;
   }

  return false;
 }

 void setStyleAttributes(StyleAttributes styleAttributes)
 {
  if (_styleAttributes == null || !(_styleAttributes.equals(styleAttributes)))
   {
    _styleAttributes = styleAttributes;

    // swt: set foreground & background as the Control's, so paintComponent()'s
    // GC comes ready set to them and we don't have to re-set them
    _messageLineText.setBackground(_styleAttributes.backgroundColor().getColor());
    _messageLineText.setForeground(_styleAttributes.foregroundColor().getColor());

    _messageValid = false;  // update on the next Screen refresh
   }
 }

 /**
  * Called every Screen refresh to redraw any pending message line changes.
  */
 void updateMessage()
 {
  if (!_messageValid && getSize().y != 0)
   {
    updateScrollArrows();
    _messageLineText.redraw();
   }
 }

 /**
  * Show/hide the message line scroll arrows.
  */
 private void updateScrollArrows()
 {
  boolean showArrows = (_textStart != 0) ||
                        (_text != null && _textFontMetrics.stringWidth(_text) > getSize().x);
  if (_showArrows != showArrows)
   {
    _showArrows = showArrows;
    createArrows();
    layout();
   }
 }

 /**
  * Scroll message line text right.
  */
 void scrollRight()
 {
  if (scrollRightAvailable())
   {
    int messageLineTextWidth = _messageLineText.getSize().x;
    int textWidth = _textFontMetrics.stringWidth(_text);

    _textStart -= messageLineTextWidth / 2;
    if (_textStart + textWidth + 1 < messageLineTextWidth)
     {
      _textStart = messageLineTextWidth - textWidth - 1;
     }
    if (!scrollRightAvailable())  // can't scroll right no more
     {
      _arrows.redraw();           //  disable right arrow
     }

    _messageLineText.redraw();
   }
 }

 /**
  * Scroll message line text left.
  */
 void scrollLeft()
 {
  if (scrollLeftAvailable())
   {
    _textStart += _messageLineText.getSize().x / 2;
    if (_textStart > 0)
     {
      _textStart = 0;
     }
    if (!scrollLeftAvailable())   // can't scroll left no more
     {
      updateScrollArrows();       //  arrows may be no longer needed
      _arrows.redraw();           //  or at least disable left arrow
     }

    _messageLineText.redraw();
   }
 }

 /**
  * Can message line text scroll right?
  */
 boolean scrollRightAvailable()
 {
  return _textStart + _textFontMetrics.stringWidth(_text) > _messageLineText.getSize().x;
 }

 /**
  * Can message line text scroll left?
  */
 boolean scrollLeftAvailable()
 {
  return _textStart != 0;
 }


 /**
  * This class manages the layout for the MessageLine Composite.
  */
 final class MessageLineLayout extends Layout
 {
  /**
   * Compute the preferred size of the MessageLine.
   */
  protected Point computeSize(Composite messageLine, int wHint, int hHint, boolean flushCache)
  {
   return messageLine.computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);
  }

  /**
   * Layout the children of the MessageLine.
   */
  protected void layout(Composite messageLine, boolean flushCache)
  {
   Rectangle messageLineRect = messageLine.getClientArea();
   int width  = messageLineRect.width;
   int height = messageLineRect.height;

   int arrowsWidth  = 0;
   if (_showArrows)
    {
     ScrollBar verticalScrollBar = _lpexWindow.verticalScrollBar();
     if (verticalScrollBar != null)
      {
       arrowsWidth = verticalScrollBar.getSize().x;
      }
     arrowsWidth = Math.max(12, arrowsWidth);
    }

   _messageLineText.setBounds(0, 0, width - arrowsWidth, height);
   if (_arrows != null)
    {
     _arrows.setBounds(width - arrowsWidth, 0, arrowsWidth, height);
    }
  }
 }
}