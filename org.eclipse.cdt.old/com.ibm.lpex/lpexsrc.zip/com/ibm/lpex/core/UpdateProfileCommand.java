//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// UpdateProfileCommand - handles the updateProfile command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>updateProfile</b> command.
 */
final class UpdateProfileCommand
{
 static final int BASE_PROFILE       = 1;
 static final int EXTENSIONS         = 2;
 static final int NO_PARSER          = 3;
 static final int PALETTE            = 4;
 static final int PALETTE_ATTRIBUTES = 5;
 static final int PALETTES           = 6;
 static final int PARSER             = 7;
 static final int PARSER_ASSOCIATION = 8;
 static final int PARSER_CLASS       = 9;
 static final int PARSERS            = 10;
 static final int USER_ACTIONS       = 11;
 static final int USER_COMMANDS      = 12;
 static final int USER_KEY_ACTIONS   = 13;
 static final int USER_MOUSE_ACTIONS = 14;
 static final int USER_PROFILE       = 15;

 private static TableNode[] _parameters =
  {
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_BASE_PROFILE,       BASE_PROFILE),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_EXTENSIONS,         EXTENSIONS),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_NO_PARSER,          NO_PARSER),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_PALETTE,            PALETTE),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_PALETTE_ATTRIBUTES, PALETTE_ATTRIBUTES),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_PALETTES,           PALETTES),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_PARSER,             PARSER),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_PARSER_ASSOCIATION, PARSER_ASSOCIATION),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_PARSER_CLASS,       PARSER_CLASS),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_PARSERS,            PARSERS),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_USER_ACTIONS,       USER_ACTIONS),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_USER_COMMANDS,      USER_COMMANDS),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_USER_KEY_ACTIONS,   USER_KEY_ACTIONS),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_USER_MOUSE_ACTIONS, USER_MOUSE_ACTIONS),
   new TableNode(LpexConstants.UPDATE_PROFILE_PARAMETER_USER_PROFILE,       USER_PROFILE)
  };


 static Parameter getParameter(String parameter)
  {
   TableNode p = TableNode.binarySearch(_parameters,
                                        Parameters.getParameterString(parameter));
   if (p != null)
    {
     switch (p.id())
      {
       case BASE_PROFILE:
        {
         return BaseProfileParameter.getParameter();
        }
       case EXTENSIONS:
        {
         return ExtensionsParameter.getParameter();
        }
       case NO_PARSER:
        {
         return NoParserParameter.getParameter();
        }
       case PALETTE:
        {
         return PaletteParameter.getParameter();
        }
       case PALETTES:
        {
         return PalettesParameter.getParameter();
        }
       case PALETTE_ATTRIBUTES:
        {
         return PaletteAttributesParameter.getParameter();
        }
       case PARSER:
        {
         return ParserParameter.getParameter();
        }
       case PARSER_ASSOCIATION:
        {
         return ParserAssociationParameter.getParameter();
        }
       case PARSER_CLASS:
        {
         return ParserClassParameter.getParameter();
        }
       case PARSERS:
        {
         return ParsersParameter.getParameter();
        }
       case USER_ACTIONS:
        {
         return UserActionsParameter.getParameter();
        }
       case USER_COMMANDS:
        {
         return UserCommandsParameter.getParameter();
        }
       case USER_KEY_ACTIONS:
        {
         return UserKeyActionsParameter.getParameter();
        }
       case USER_MOUSE_ACTIONS:
        {
         return UserMouseActionsParameter.getParameter();
        }
       case USER_PROFILE:
        {
         return UserProfileParameter.getParameter();
        }
       default:
        {
         break;
        }
      }
    }
   return null;
  }


 final static class BaseProfileParameter extends ParameterWordDefault
  {
   private static BaseProfileParameter _parameter;

   static BaseProfileParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new BaseProfileParameter();
      }
     return _parameter;
    }

   private BaseProfileParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_BASE_PROFILE, "lpex");
    }

   String name(String qualifier)
    {
     return name();
    }

   boolean setValue(View view, String value)
    {
     if (view != null)
      {
       view.updateProfileCommandSettings()._baseProfile = value;
      }
     return true;
    }

   String value(View view)
    {
     return (view != null)? view.updateProfileCommandSettings()._baseProfile : null;
    }
  }


 final static class ExtensionsParameter extends ParameterQualifierList
  {
   private static ExtensionsParameter _parameter;

   static ExtensionsParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new ExtensionsParameter();
      }
     return _parameter;
    }

   private ExtensionsParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_EXTENSIONS,
           PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_PARSER_ASSOCIATION);
    }

   KeyedList value(View view)
    {
     return (view != null)?
             view.updateProfileCommandSettings()._parserAssociations : null;
    }
  }


 final static class NoParserParameter extends ParameterOnOffDefault
  {
   private static NoParserParameter _parameter;

   static NoParserParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new NoParserParameter();
      }
     return _parameter;
    }

   private NoParserParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_NO_PARSER, false);
    }

   String name(String qualifier)
    {
     return name();
    }

   boolean setValue(View view, int value)
    {
     if (view != null)
      {
       view.updateProfileCommandSettings()._noParser = value;
      }
     return true;
    }

   int value(View view)
    {
     return (view != null)?
             view.updateProfileCommandSettings()._noParser : Parameter.DEFAULT;
    }
  }


 final static class PaletteParameter extends ParameterWordDefault
  {
   private static PaletteParameter _parameter;

   static PaletteParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new PaletteParameter();
      }
     return _parameter;
    }

   private PaletteParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_PALETTE, "white");
    }

   String name(String qualifier)
    {
     return name();
    }

   boolean setValue(View view, String value)
    {
     if (view != null)
      {
       view.updateProfileCommandSettings()._palette = value;
      }
     return true;
    }

   String value(View view)
    {
     return (view != null)? view.updateProfileCommandSettings()._palette : null;
    }
  }


 final static class PaletteAttributesParameter extends ParameterDefault
  {
   private static PaletteAttributesParameter _parameter;

   static PaletteAttributesParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new PaletteAttributesParameter();
      }
     return _parameter;
    }

   private PaletteAttributesParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_PALETTE_ATTRIBUTES);
    }

   StyleAttributes installValue(String style, String palette)
    {
     String value = Install.getString("install." + name(style + "." + palette));
     return StyleAttributes.getStyleAttributes(value);
    }

   Setting defaultValue(String style, String palette)
    {
     String value = Profile.getString("default." + name(style + "." + palette));
     return (value != null)? new Setting(StyleAttributes.getStyleAttributes(value)) : null;
    }

   boolean setDefaultValue(String style, String palette, Setting setting)
    {
     String key = "default." + name(style + "." + palette);
     if (setting == null)
      {
       Profile.remove(key);
      }
     else if (setting._styleAttributes == null)
      {
       Profile.putString(key, "null");
      }
     else
      {
       Profile.putString(key, setting._styleAttributes.queryString());
      }
     return true;
    }

   StyleAttributes currentValue(View view, String style, String palette)
    {
     Setting setting = (view != null)? value(view, style, palette) : null;
     if (setting == null)
      {
       setting = defaultValue(style, palette);
       if (setting == null)
        {
         setting = new Setting(installValue(style, palette));
        }
      }
     if (setting._styleAttributes == null)
      {
       String defaultStyleName = Screen.styleName(Screen.STYLE_DEFAULT);
       if (style.equals(defaultStyleName))
        {
         setting._styleAttributes = StyleAttributes.getStyleAttributes("0 0 170 255 255 255");
        }
       else
        {
         StyleAttributes styleAttributes = currentValue(view, defaultStyleName, palette);
         String backgroundColorString = styleAttributes.backgroundColorString();
         String styleAttributesString = null;
         switch (Screen.styleId(style))
          {
           case Screen.STYLE_ADDED_LINES:
            {
             styleAttributesString = "0 0 0 255 255 0";
             break;
            }
           case Screen.STYLE_BACKGROUND:
            {
             styleAttributesString = "0 0 0 204 204 204";
             break;
            }
           case Screen.STYLE_DEFAULT:
            {
             styleAttributesString = "0 0 170 255 255 255";
             break;
            }
           case Screen.STYLE_DELETED_LINES:
            {
             styleAttributesString = "0 0 0 255 0 0";
             break;
            }
           case Screen.STYLE_EMPHASIS:
            {
             styleAttributesString = "0 0 0 204 204 204";
             break;
            }
           case Screen.STYLE_EXPAND_HIDE:
            {
             styleAttributesString = "0 0 0 204 204 204 outline";
             break;
            }
           case Screen.STYLE_FORMAT_LINE:
            {
             styleAttributesString = "0 0 0 255 255 255";
             break;
            }
           case Screen.STYLE_MESSAGE_LINE:
            {
             styleAttributesString = "0 0 0 255 255 255";
             break;
            }
           case Screen.STYLE_PREFIX_AREA:
            {
             styleAttributesString = "0 0 0 204 204 204";
             break;
            }
           case Screen.STYLE_PREFIX_TEXT:
            {
             styleAttributesString = "255 0 255 204 204 204";
             break;
            }
           case Screen.STYLE_SELECTION:
            {
             styleAttributesString = "255 255 255 0 0 0";
             break;
            }
           case Screen.STYLE_SEQUENCE_NUMBER:
            {
             styleAttributesString = "0 0 0 192 192 192";
             break;
            }
           case Screen.STYLE_SEQUENCE_TEXT:
            {
             styleAttributesString = "0 0 255 192 192 192";
             break;
            }
           case Screen.STYLE_STATUS_LINE:
            {
             styleAttributesString = "0 0 0 255 255 255";
             break;
            }
           default:
            {
             break;
            }
          }

         styleAttributesString = StyleAttributes.convert(styleAttributesString,
                                                         "255 255 255",
                                                         backgroundColorString);
         setting._styleAttributes = StyleAttributes.getStyleAttributes(styleAttributesString);
        }
      }
     return setting._styleAttributes;
    }

   boolean set(View view, String qualifier, String parameters)
    {
     qualifier = Parameters.getQualifierString(qualifier);
     String style = Parameters.getParameterString(qualifier);
     int qualifierIndex = style.indexOf(".");
     if (qualifierIndex != -1)
      {
       style = qualifier.substring(0, qualifierIndex);
      }
     int styleId = Screen.styleId(style);
     if (styleId == Screen.STYLE_INVALID)
      {
       return CommandHandler.invalidParameter(view, style, "set " + name());
      }

     String palette = Parameters.getQualifierString(qualifier);
     LpexStringTokenizer st = new LpexStringTokenizer(parameters);
     Setting setting = null;
     if (st.hasMoreTokens())
      {
       String token = st.nextToken();
       if (!token.equals("default"))
        {
         if (!StyleAttributes.checkStyleAttributes(view, parameters, "set " + name(qualifier)))
          {
           return false;
          }
         setting = new Setting(StyleAttributes.getStyleAttributes(parameters));
        }
       else if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name(qualifier));
        }
      }
     else
      {
       setting = new Setting(null);
      }
     return setValue(view, style, palette, setting);
    }

   boolean setDefault(View view, String qualifier, String parameters)
    {
     qualifier = Parameters.getQualifierString(qualifier);
     String style = Parameters.getParameterString(qualifier);
     int qualifierIndex = style.indexOf(".");
     if (qualifierIndex != -1)
      {
       style = qualifier.substring(0, qualifierIndex);
      }
     int styleId = Screen.styleId(style);
     if (styleId == Screen.STYLE_INVALID)
      {
       return CommandHandler.invalidParameter(view, style, "set default." + name());
      }

     String palette = Parameters.getQualifierString(qualifier);
     LpexStringTokenizer st = new LpexStringTokenizer(parameters);
     Setting setting = null;
     if (st.hasMoreTokens())
      {
       String token = st.nextToken();
       if (!token.equals("install"))
        {
         if (!StyleAttributes.checkStyleAttributes(view, parameters,
                                                   "set default." + name(qualifier)))
          {
           return false;
          }
         setting = new Setting(StyleAttributes.getStyleAttributes(parameters));
        }
       else if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(),
                                               "set default." + name(qualifier));
        }
      }
     else
      {
       setting = new Setting(null);
      }

     return setDefaultValue(style, palette, setting);
    }

   String query(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     qualifier = Parameters.getQualifierString(qualifier);
     String style = Parameters.getParameterString(qualifier);
     int qualifierIndex = style.indexOf(".");
     if (qualifierIndex != -1)
      {
       style = qualifier.substring(0, qualifierIndex);
      }

     int styleId = Screen.styleId(style);
     if (styleId != Screen.STYLE_INVALID)
      {
       String palette = Parameters.getQualifierString(qualifier);
       Setting setting = value(view, style, palette);
       if (setting == null)
        {
         return "default";
        }
       else if (setting._styleAttributes != null)
        {
         return setting._styleAttributes.queryString();
        }
      }
     return null;
    }

   String queryInstall(String qualifier)
    {
     qualifier = Parameters.getQualifierString(qualifier);
     String style = Parameters.getParameterString(qualifier);
     int qualifierIndex = style.indexOf(".");
     if (qualifierIndex != -1)
      {
       style = qualifier.substring(0, qualifierIndex);
      }

     int styleId = Screen.styleId(style);
     if (styleId != Screen.STYLE_INVALID)
      {
       String palette = Parameters.getQualifierString(qualifier);
       StyleAttributes styleAttributes = installValue(style, palette);
       if (styleAttributes != null)
        {
         return styleAttributes.queryString();
        }
      }
     return null;
    }

   String queryDefault(String qualifier)
    {
     qualifier = Parameters.getQualifierString(qualifier);
     String style = Parameters.getParameterString(qualifier);
     int qualifierIndex = style.indexOf(".");
     if (qualifierIndex != -1)
      {
       style = qualifier.substring(0, qualifierIndex);
      }

     int styleId = Screen.styleId(style);
     if (styleId != Screen.STYLE_INVALID)
      {
       String palette = Parameters.getQualifierString(qualifier);
       Setting setting = defaultValue(style, palette);
       if (setting == null)
        {
         return "install";
        }
       if (setting._styleAttributes != null)
        {
         return setting._styleAttributes.queryString();
        }
      }
     return null;
    }

   String queryCurrent(View view, String qualifier)
    {
     qualifier = Parameters.getQualifierString(qualifier);
     String style = Parameters.getParameterString(qualifier);
     int qualifierIndex = style.indexOf(".");
     if (qualifierIndex != -1)
      {
       style = qualifier.substring(0, qualifierIndex);
      }

     int styleId = Screen.styleId(style);
     if (styleId != Screen.STYLE_INVALID)
      {
       String palette = Parameters.getQualifierString(qualifier);
       StyleAttributes styleAttributes = currentValue(view, style, palette);
       if (styleAttributes != null)
        {
         return styleAttributes.queryString();
        }
      }
     return null;
    }

   boolean setValue(View view, String style, String palette, Setting setting)
    {
     if (view != null)
      {
       int styleId = Screen.styleId(style);
       if (styleId == Screen.STYLE_INVALID)
        {
         return false;
        }
       KeyedList paletteAttributes[] = view.updateProfileCommandSettings()._paletteAttributes;
       if (paletteAttributes[styleId] == null)
        {
         paletteAttributes[styleId] = new KeyedList();
        }
       KeyedList palettes = paletteAttributes[styleId];
       palettes.set(palette, setting);
      }
     return true;
    }

   Setting value(View view, String style, String palette)
    {
     if (view != null)
      {
       KeyedList paletteAttributes[] = view.updateProfileCommandSettings()._paletteAttributes;
       if (paletteAttributes != null)
        {
         int styleId = Screen.styleId(style);
         if (styleId != Screen.STYLE_INVALID)
          {
           KeyedList palettes = paletteAttributes[styleId];
           if (palettes != null)
            {
             return (Setting) palettes.query(palette);
            }
          }
        }
      }
     return null;
    }


   final static class Setting
    {
     StyleAttributes _styleAttributes;
     Setting(StyleAttributes styleAttributes)
      {
       _styleAttributes = styleAttributes;
      }
    }
  }


 final static class PalettesParameter extends ParameterQualifierList
  {
   private static PalettesParameter _parameter;

   static PalettesParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new PalettesParameter();
      }
     return _parameter;
    }

   private PalettesParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_PALETTES,
           PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_PALETTE_ATTRIBUTES +
            Screen.styleName(Screen.STYLE_DEFAULT) + ".");
    }

   KeyedList value(View view)
    {
     return (view != null)?
             view.updateProfileCommandSettings()._paletteAttributes[Screen.STYLE_DEFAULT] : null;
    }
  }


 final static class ParserParameter extends ParameterWordDefault
  {
   private static ParserParameter _parameter;

   static ParserParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new ParserParameter();
      }
     return _parameter;
    }

   private ParserParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_PARSER, "associated");
    }

   String name(String qualifier)
    {
     return name();
    }

   boolean setValue(View view, String value)
    {
     if (view != null)
      {
       view.updateProfileCommandSettings()._parser = value;
      }
     return true;
    }

   String value(View view)
    {
     return (view != null)? view.updateProfileCommandSettings()._parser : null;
    }
  }


 final static class ParserAssociationParameter extends ParameterQualifiedWordDefault
  {
   private static ParserAssociationParameter _parameter;

   static ParserAssociationParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new ParserAssociationParameter();
      }
     return _parameter;
    }

   private ParserAssociationParameter()
    {
     super(PARAMETER_UPDATE_PROFILE);
    }

   boolean setValue(View view, String qualifier, String value)
    {
     if (view != null)
      {
       qualifier = Parameters.getQualifierString(qualifier);
       view.updateProfileCommandSettings()._parserAssociations.set(qualifier, value);
      }
     return true;
    }

   String value(View view, String qualifier)
    {
     qualifier = Parameters.getQualifierString(qualifier);
     return (view != null)?
            ((String)view.updateProfileCommandSettings()
                         ._parserAssociations.query(qualifier)) : null;
    }
  }


 final static class ParserClassParameter extends ParameterQualifiedWordDefault
  {
   private static ParserClassParameter _parameter;

   static ParserClassParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new ParserClassParameter();
      }
     return _parameter;
    }

   private ParserClassParameter()
    {
     super(PARAMETER_UPDATE_PROFILE);
    }

   boolean setValue(View view, String qualifier, String value)
    {
     if (view != null)
      {
       qualifier = Parameters.getQualifierString(qualifier);
       view.updateProfileCommandSettings()._parserClasses.set(qualifier, value);
      }
     return true;
    }

   String value(View view, String qualifier)
    {
     qualifier = Parameters.getQualifierString(qualifier);
     return (view != null)?
            ((String) view.updateProfileCommandSettings()
                          ._parserClasses.query(qualifier)) : null;
    }
  }


 final static class ParsersParameter extends ParameterQualifierList
  {
   private static ParsersParameter _parameter;

   static ParsersParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new ParsersParameter();
      }
     return _parameter;
    }

   private ParsersParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_PARSERS,
           PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_PARSER_CLASS);
    }

   KeyedList value(View view)
    {
     return (view != null)? view.updateProfileCommandSettings()._parserClasses : null;
    }
  }


 final static class UserActionsParameter extends ParameterWordsDefault
  {
   private static UserActionsParameter _parameter;

   static UserActionsParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new UserActionsParameter();
      }
     return _parameter;
    }

   private UserActionsParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_USER_ACTIONS, null);
    }

   boolean setValue(View view, String value)
    {
     if (view != null)
      {
       view.updateProfileCommandSettings()._userActions = value;
      }
     return true;
    }

   String value(View view)
    {
     return (view != null)? view.updateProfileCommandSettings()._userActions : null;
    }
  }


 final static class UserCommandsParameter extends ParameterWordsDefault
  {
   private static UserCommandsParameter _parameter;

   static UserCommandsParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new UserCommandsParameter();
      }
     return _parameter;
    }

   private UserCommandsParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_USER_COMMANDS, null);
    }

   boolean setValue(View view, String value)
    {
     if (view != null)
      {
       view.updateProfileCommandSettings()._userCommands = value;
      }
     return true;
    }

   String value(View view)
    {
     return (view != null)? view.updateProfileCommandSettings()._userCommands : null;
    }
  }


 final static class UserKeyActionsParameter extends ParameterWordsDefault
  {
   private static UserKeyActionsParameter _parameter;

   static UserKeyActionsParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new UserKeyActionsParameter();
      }
     return _parameter;
    }

   private UserKeyActionsParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_USER_KEY_ACTIONS, null);
    }

   boolean setValue(View view, String value)
    {
     if (view != null)
      {
       view.updateProfileCommandSettings()._userKeyActions = value;
      }
     return true;
    }

   String value(View view)
    {
     return (view != null)? view.updateProfileCommandSettings()._userKeyActions : null;
    }
  }


 final static class UserMouseActionsParameter extends ParameterWordsDefault
  {
   private static UserMouseActionsParameter _parameter;

   static UserMouseActionsParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new UserMouseActionsParameter();
      }
     return _parameter;
    }

   private UserMouseActionsParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_USER_MOUSE_ACTIONS, null);
    }

   boolean setValue(View view, String value)
    {
     if (view != null)
      {
       view.updateProfileCommandSettings()._userMouseActions = value;
      }
     return true;
    }

   String value(View view)
    {
     return (view != null)? view.updateProfileCommandSettings()._userMouseActions : null;
    }
  }


 final static class UserProfileParameter extends ParameterWordDefault
  {
   private static UserProfileParameter _parameter;

   static UserProfileParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new UserProfileParameter();
      }
     return _parameter;
    }

   private UserProfileParameter()
    {
     super(PARAMETER_UPDATE_PROFILE + UPDATE_PROFILE_PARAMETER_USER_PROFILE, null);
    }

   String name(String qualifier)
    {
     return name();
    }

   boolean setValue(View view, String value)
    {
     if (view != null)
      {
       view.updateProfileCommandSettings()._userProfile = value;
      }
     return true;
    }

   String value(View view)
    {
     return (view != null)? view.updateProfileCommandSettings()._userProfile : null;
    }
  }


 static boolean doCommand(View view, String parameters)
  {
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);

   boolean all = false;
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("all"))
      {
       all = true;
      }
     else
      {
       return CommandHandler.invalidParameter(view, token, "updateProfile");
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "updateProfile");
      }
    }

   if (all)
    {
     for (Document doc = Document._firstDocument; doc != null; doc = doc._next)
      {
       for (view = doc._firstView; view != null; view = view._next)
        {
         if (view.updateProfileIssued())
          {
           view.updateProfile();
          }
        }
      }
    }
   else if (view != null)
    {
     view.updateProfile();
    }

   return true;
  }


 /**
  * The settings of the <b>updateProfile</b> command for a view.
  */
 final static class Settings
 {
  String    _baseProfile;
  int       _noParser = Parameter.DEFAULT;
  String    _palette;
  KeyedList _paletteAttributes[] = new KeyedList[Screen.STYLE_LAST + 1];
  String    _parser;
  KeyedList _parserAssociations = new KeyedList();
  KeyedList _parserClasses = new KeyedList();
  String    _userActions;
  String    _userCommands;
  String    _userKeyActions;
  String    _userMouseActions;
  String    _userProfile;
 }
}