//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParsePendingList - parse pending list for a document view.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;


/**
 * This class is used to manage the list of parse-pending elements for a
 * document view.
 */
final class ParsePendingList extends List
{
 private View _view;
 private boolean _inParser;
 private boolean _parsing;
 private LpexParser _lpexParser;   // currently active parser class for View
 private String _parser;           //  & its name (e.g., "java")

 /**
  * Constructor.
  */
 ParsePendingList(View view)
  {
   _view = view;
  }

 String parser()
  {
   return _parser;
  }

 /**
  * Locate the parse pending node for the specified element.
  */
 ParsePending find(Element element)
  {
   if (element == null)
      return null;

   return element.elementView(_view).parsePending();
  }

 void setParsing(boolean parsing)
  {
   if (parsing != _parsing)
    {
     _parsing = parsing;
     if (!_parsing)
      {
       clear();
      }
    }
  }

 boolean parsing()
  {
   return _parsing;
  }

 void parse()
  {
   if (_lpexParser != null && !_inParser)
    {
     ParsePending parsePending = (ParsePending) first();
     ElementList elementList = _view.document().elementList();
     while(parsePending != null)
      {
       _inParser = true;
       _lpexParser.parse(elementList.ordinalOf(parsePending.element()));
       _inParser = false;
       if (parsePending == first())
        {
         remove(parsePending);
        }
       parsePending = (ParsePending) first();
      }
    }
  }

 void totalParse()
  {
   if (_lpexParser != null && !_inParser && _view.document().elementList().count() > 0)
    {
     setParsing(false);
     _inParser = true;
     _lpexParser.totalParse();
     _inParser = false;
     setParsing(true);
    }
  }

 void add(Element element, int type)
  {
   if (!_inParser && parsing())
    {
     ParsePending parsePending = find(element);
     if (parsePending == null)
      {
       parsePending = new ParsePending(element, type);
       addBefore(null, parsePending);
       element.elementView(_view).setParsePending(parsePending);
      }
     else
      {
       parsePending.addType(type);
      }
    }
  }

 Node remove(Node node)
  {
   Element element = ((ParsePending) node).element();
   element.elementView(_view).setParsePending(null);
   return super.remove(node);
  }

 void elementRemoved(Element element)
  {
   ParsePending parsePending = find(element);
   if (parsePending != null)
    {
     remove(parsePending);
    }
  }

 void updateProfile()
  {
   if (_lpexParser != null)
    {
     _lpexParser.resetParser();
     _lpexParser = null;
    }
   clear();

   String parser = null;
   if (!UpdateProfileCommand.NoParserParameter.getParameter().currentValue(_view))
    {
     // get parser name from updateProfile.parser parameter
     parser = UpdateProfileCommand.ParserParameter.getParameter().currentValue(_view);

     // if "associated", establish parser name as f(file extension)
     if ("associated".equals(parser))
      {
       parser = null;
       String extension = _view.document().name();
       if (extension != null)
        {
         int extensionStart = extension.lastIndexOf('.');
         if (extensionStart != -1)
          {
           extension = extension.substring(extensionStart);
           UpdateProfileCommand.ParserAssociationParameter p =
              UpdateProfileCommand.ParserAssociationParameter.getParameter();
           parser = p.currentValue(_view, "parserAssociation" + extension);
          }
        }
      }

     // load class defined for named parser & instantiate it
     if (parser != null && parser.length() > 0)
      {
       UpdateProfileCommand.ParserClassParameter p =
          UpdateProfileCommand.ParserClassParameter.getParameter();
       String className = p.currentValue(_view, "parserClass." + parser);
       if (className != null)
        {
         Class parserClass = null;
         try
          {
           parserClass = Class.forName(className);
          }
         catch(ClassNotFoundException e) {}

         // if couldn't load, try any of the alternative class loaders
         if (parserClass == null)
          {
           parserClass = View.alternativeLoadClass(className);
          }

         if (parserClass == null)
          {
           _view.setLpexMessageText(LpexConstants.MSG_CLASS_NOTFOUND, className);
          }
         else
          {
           if (!LpexParser.class.isAssignableFrom(parserClass))
            {
             _view.setLpexMessageText(LpexConstants.MSG_CLASS_INVALID, className, "LpexParser");
            }
           else
            {
             try
              {
               Class[] parameterTypes = { LpexView.class };
               Constructor parserConstructor = parserClass.getConstructor(parameterTypes);
               Object[] arguments = { _view.lpexView() };
               _lpexParser = (LpexParser) parserConstructor.newInstance(arguments);
              }
             catch (InvocationTargetException e)
              {
               e.getTargetException().printStackTrace();
              }
             catch (Exception e)
              {
               _view.setLpexMessageText(LpexConstants.MSG_CLASS_INVALID, className, "LpexParser");
              }
            }
          }
        }
      }
    }

   _parser = (_lpexParser != null)? parser : null;
   totalParse();
  }

 LpexParser lpexParser()
  {
   return _lpexParser;
  }
}