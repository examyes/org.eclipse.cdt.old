//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// BeepParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class BeepParameter extends ParameterOnOffOnly
{
 private static BeepParameter _parameter;
 private static boolean _value;


 static BeepParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new BeepParameter();
   }
  return _parameter;
 }

 private BeepParameter()
 {
  super(PARAMETER_BEEP);
 }

 boolean setValue(View view, String qualifier, boolean value)
 {
  _value = value;
  return true;
 }

 boolean setValue(boolean value)
 {
  _value = value;
  return true;
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return true;
 }

 boolean value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return _value;
 }

 boolean value()
 {
  return _value;
 }
}