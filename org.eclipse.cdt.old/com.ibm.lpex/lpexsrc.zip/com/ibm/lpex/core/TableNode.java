//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// TableNode
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

class TableNode
{
 private String _string;
 private int _id;


 TableNode(String string, int id)
 {
  _string = string;
  _id = id;
 }

 String string()
 {
  return _string;
 }

 int id()
 {
  return _id;
 }

 static TableNode binarySearch(TableNode[] table, String string)
 {
  int i, k;

  int hi = table.length - 1;
  int lo = 0;
  while (hi >= lo)
   {
    i = (hi + lo) / 2;
    k = string.compareTo(table[i]._string);
    if (k < 0)          // key is lower
     {
      hi = i - 1;
     }
    else if (k > 0)     // key is higher
     {
      lo = i + 1;
     }
    else
     {
      return table[i];  // we found it
     }
   }

  return null;          // we didn't find it
 }

 static TableNode sequentialSearch(TableNode[] table, int id)
 {
  for (int i = 0; i < table.length; i++)
   {
    if (table[i]._id == id)
     {
      return table[i];
     }
   }

  return null;
 }
}