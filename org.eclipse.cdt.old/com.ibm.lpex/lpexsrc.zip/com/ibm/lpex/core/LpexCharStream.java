//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexCharStream - input stream for LPEX parsers/tokenizers:
// an implementation of the JavaCC (Java Compiler Compiler) CharStream (here,
// renamed UCode_CharStream) interface, for LPEX document parsers.
// See com.ibm.lpex.cc.UCode_CharStream for additional information.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import com.ibm.lpex.cc.UCode_CharStream;


/**
 * A stream interface for LPEX document parsers.
 * This class feeds a lexer with the text in an LPEX document view, formatted
 * as a stream of Unicode characters.  It also provides methods for a
 * document parser to set element classes and styles in the text.
 */
public final class LpexCharStream implements UCode_CharStream
{
   /**
    * The current styles for the text element in the stream buffer.
    * The document parser sets, through e.g., setStyles(), the appropriate
    * styles as it parses the tokens;  then, the entire styles string is
    * automatically set in LPEX by LpexCharStream, through setCurrentStyles(),
    * when a new element is read in.
    *
    * @see #setCurrentStyles
    */
   public StringBuffer bufferStyles;

   /**
    * The current classes for the text element in the stream buffer.
    * The document parser sets the appropriate classes as it parses the tokens;
    * then the accumulated classes bit-mask is automatically set in LPEX by
    * LpexCharStream when a new element is read in.
    *
    * @see #setCurrentStyles
    */
   private long bufferClasses;

   private int      bufpos;              // 0-BASED buffer pos of last char read
   private boolean  EOFSeen;             // EOF was just returned
   private LpexView lpexView;
   private boolean  currentStylesSet;    // styles, classes set for current elem
   private int      currentElement, beginElement, endElement;
   private int      beginMargin, endMargin; // 0-BASED columns for readChar()s
   private String   buffer;              // the characters buffer
   private int      bufferLength;
   private int      tokenBegin,          // prev BeginToken() character
                    tokenBeginLine;      //   to keep chars for backup()
   private long     classClear, classSet;
   private char     styleDefault;
   private char     outMarginsStyle;
   private boolean  clearPending;        // say elementParsed() once done with?

   private boolean  skipShowLines=true;  // ignore SHOW elements (hardcoded now)


   /**
    * Constructor.
    *
    * @param lpexView the LpexView that provides the input stream
    */
   public          LpexCharStream(LpexView lpexView)
   {
      this.lpexView = lpexView;
   }

   /**
    * Return the next character in the stream.  This method can throw any
    * java.io.IOException.
    *
    * <p>An attempt to read a character beyond the end element of the stream
    * will throw a java.io.EOFException.  The range of elements in the stream is
    * specified by <code>beginElement .. endElement</code> in methods Init()
    * and Expand().
    *
    * @see #Init(int,int,long,long,char,boolean)
    * @see #Expand
    */
   /*synchronized*/ public final char readChar() throws java.io.IOException
   // dropped synchronized - not reading from a file, one stream per view,
   // one document parser per view...
   {
      if (buffer == null || bufpos >= bufferLength)
         FillBuff();

      bufpos++;

      if (beginMargin != 0 && bufpos < beginMargin())
         bufpos = beginMargin();
      if (endMargin != 0 && bufpos > endMargin())
         bufpos = bufferLength;

      return (bufpos >= bufferLength)? '\n' : buffer.charAt(bufpos);
   }

// /**
//  * @deprecated
//  * @see #getEndColumn
//  */
// public int getColumn()
// { return getEndColumn(); }

// /**
//  * @deprecated
//  * @see #getEndLine
//  */
// public int getLine()
// { return getEndLine(); }

   /**
    * Return ONE-based column number of the last character for the current
    * token (being matched after the last call to BeginToken()).
    */
   public int      getEndColumn()
   {
      return bufpos+1;
   }

   /**
    * Return the element number of the last character for the current token
    * (being matched after the last call to BeginToken()).
    */
   public int      getEndLine()
   {
      return currentElement;
   }

   /**
    * Return ONE-based column number of the first character for the current
    * token (being matched after the last call to BeginToken()).
    */
   public int      getBeginColumn()
   {
      return tokenBegin+1;
   }

   /**
    * Return the element number of the first character for the current token
    * (being matched after the last call to BeginToken()).
    */
   public int      getBeginLine()
   {
      return tokenBeginLine;
   }

   /**
    * Back up input stream by <code>amount</code> steps.  The lexer calls this
    * method if it had already read some characters, but couldn't use them to
    * match a (longer) token:  so they'll be used again as the prefix of the
    * next token.
    *
    * <p>This method may back up to a previous element (an element previously
    * readChar()-ed in this stream).  The same margins setting is assumed for
    * previous elements as is now in effect.
    *
    * @param amount number of characters to back up (push back) in the stream
    */
   public void     backup(int amount)
   {
      /*-----------------------------------------------------------------*/
      /*  called with 0 by TokenManagers to kill a bad JIT optimization  */
      /*-----------------------------------------------------------------*/
      if (amount == 0)
         return;

      EOFSeen = false;

      /*-------------------------------------*/
      /*  backup inside the current element  */
      /*-------------------------------------*/
      // bufpos now over the end margin - must be on element's added-in '\n':
      // most typical case is of the TokenManager pushing back the EOL
      if (endMargin != 0 && bufpos > endMargin()) {
         bufpos = endMargin();
         if (--amount == 0)
            return;
         }

      int diff = bufpos - beginMargin() - amount;
      if (diff >= -1) {
         bufpos -= amount;
         return;
         }

      /*--------------------------*/
      /*  backup across elements  */
      /*--------------------------*/
      //System.out.println("BACK UP ACROSS ELEMENTS element="+currentElement+
      //                   " bufpos="+bufpos+" amount="+amount);

      //  ***                        new
      //  0120123      amount diff  bufpos               without margins:
      //  xyzABCD        1      1      1                   xyz
      //       |         2      0      0                   ABCD
      //       |         3     -1     -1 / *2
      //       bufpos    4     -2    * 1                 same with margins:
      //       =2        5     -3    * 0                   ......xyz
      //                 6     -4    *-1                   ......ABCD.....
      while (diff < -1) {
         do {
            currentElement--;
            } while (skipShowLines && lpexView.show(currentElement));
         buffer = lpexView.elementText(currentElement);
         bufferLength = buffer.length();
         if (endMargin != 0 && bufferLength > endMargin()+1)
            bufferLength = endMargin()+1;
         diff += bufferLength - beginMargin() + 1; // +1 for the '\n' we add in!
         }

      bufpos = beginMargin() + diff;
      //System.out.println("  LANDED ON element="+currentElement+" bufpos="+bufpos);
      bufferStyles  = new StringBuffer(lpexView.elementStyle(currentElement));
      bufferClasses = lpexView.elementClasses(currentElement);
      currentStylesSet = false;
   }

   /**
    * Return the next character that marks the beginning of the next token.
    *
    * <p>Note:  LpexCharStream guarantees that all the characters remain in the
    * buffer between two successive calls to this method (i.e., the characters
    * from tokenBegin on), so that backup() works correctly.
    */
   public char     BeginToken() throws java.io.IOException
   {
      char c;
      try {
         c = readChar();
         }
      catch (java.io.IOException e) {
         tokenBegin = bufpos;
         tokenBeginLine = currentElement;
         throw e;
         }
      tokenBegin = bufpos;
      tokenBeginLine = currentElement;
      return c;
   }

   /**
    * Return the string from the marked token-beginning to the current buffer
    * position.
    *
    * <p>The current implementation of this method always returns an empty
    * string (<code>""</code>).
    */
   public String   GetImage()
   {
      // This method currently assumes that tokens do not span across LPEX text
      // elements!!  Also, it doesn't yet account for the margin setting in
      // effect!!  If tokenBegin is from a previous element, this method will
      // return "\n", under the assumption that the lexer is just asking for the
      // image of the end-of-line character (which we tuck in at the end of
      // elements which are inside the parse range).

      //System.out.println("  GetImage() from="+tokenBeginLine+","+tokenBegin+
      //                                 " to="+currentElement+","+bufpos);

      // tokenBegin from a previous element:  for now enough to assume is asking
      // for the image of the "\n" we've tucked in to end the previous line *as*
      //if (currentElement > tokenBeginLine || bufpos == bufferLength)
      //   return "\n";

      //return buffer.substring(tokenBegin, bufpos+1);

      return "";
   }

   final static char[] _suffix = {'\n'};
   /**
    * Return an array of characters that make up the suffix of length
    * <code>len</code> for the currently matched token.  Used to build up the
    * matched string for use in actions in the case of MORE.
    *
    * <p>The current implementation of this method always returns an array which
    * contains just one (<code>'\n'</code>) character.
    *
    * @param len number of characters in the suffix
    */
   public char[]   GetSuffix(int len)
   {
    //char[] ret = new char[len];
    //int j = bufpos - len + 1;
    //int buflen = bufferLength;
    //for (int i = 0; i < len; i++, j++) {
    // ret[i] = (j < buflen)? buffer.charAt(j) : '\n';
    // }
    //// what if len is larger (token across elements)!?!? *as*
    //// also, must account for margin settings in effect! *as*
    //return ret;

    return _suffix;
   }

   /**
    * The lexer calls this method to indicate it is done with the stream, so
    * that we can free any resources we hold.
    */
   public void     Done()
   {
      buffer = null;
      bufferLength = 0;
      bufferStyles = null;
   }

   /**
    * Initialize the stream for a parse range, for a specific document parser.
    * Parsing starts at the first character in <code>beginElement</code>,
    * subject to the margin settings in effect.
    *
    * @param beginElement begin element in the parse range
    * @param endElement   end element of the parse range.  <code>EOF</code>
    *                     will be returned when trying to read characters
    *                     past it
    * @param classClear   class bit(s) to be cleared for a new element read in -
    *                     the classClear bit(s) usually represent all the
    *                     classes assigned to, and handled by, the parser
    * @param classSet     class bit(s) to be set by default in a new element
    *                     read in - the classSet bit(s), usually set by the
    *                     parser to indicate blank elements, are cleared in
    *                     method setClasses()
    * @param styleDefault the default style character to be set for the entire
    *                     element when read in
    * @param clearPending <code>true</code> = once done with an element,
    *                     remove it from the parse-pending list.  This is
    *                     used in incremental parsing, when looking ahead of
    *                     just the current element which triggered the parse
    *                     action:  it prevents LPEX from calling the parser
    *                     once again for this element, it it was itself
    *                     modified (e.g., in a block-copy operation)
    *
    * @see #Init(int,int,int,long,long,char,boolean)
    */
   public void     Init(int beginElement, int endElement,
                        long classClear, long classSet,
                        char styleDefault, boolean clearPending)
   {
      this.beginElement  = beginElement;
      if (endElement > lpexView.elements())             // don't go overboard...
         this.endElement = lpexView.elements();
      else
         this.endElement = endElement;
      this.classClear    = classClear;
      this.classSet      = classSet;
      this.styleDefault  = styleDefault;
      this.clearPending  = clearPending;

      EOFSeen = false;
      currentElement = -1;
      beginMargin = endMargin = 0; // no real margins in effect yet
      currentStylesSet = true;     // no setting of styles & classes pending yet
      bufpos = -1;
      buffer = null;
      bufferLength = 0;
      if (bufferStyles == null)
         bufferStyles = new StringBuffer();
   }

   /**
    * Initialize the stream for a parse range, for a specific document parser.
    * Parsing starts from the given <code>beginPosition</code> in
    * <code>beginElement</code>, subject to the margin settings in effect.
    *
    * The first position in an element is 1.
    * The original element classes and the styles prior to
    * <code>beginPosition</code> are kept.
    *
    * @see #Init(int,int,long,long,char,boolean)
    */
   public void     Init(int beginElement, int beginPosition, int endElement,
                        long classClear, long classSet,
                        char styleDefault, boolean clearPending)
   {
      Init(beginElement, endElement, classClear, classSet, styleDefault, clearPending);

      if (beginPosition <= 1)
         return;

      currentElement = beginElement;
      buffer = lpexView.elementText(currentElement);
      bufferLength = buffer.length();
      bufpos = beginPosition - 2; // 0-based prior to first parse position

      // set original style up to beginPosition & default style
      // for the rest of the starting element
      bufferStyles.setLength(bufferLength);
      String originalStyles = lpexView.elementStyle(currentElement);
      int i = 0;
      for (; i < beginPosition-1; i++)
         bufferStyles.setCharAt(i, originalStyles.charAt(i));
      for (; i < bufferLength; i++)
         bufferStyles.setCharAt(i, styleDefault);

      // set original classes
      bufferClasses = lpexView.elementClasses(currentElement);
      currentStylesSet = false;
   }

   /**
    * Set a begin and/or an end margin for the characters to return.  Next call
    * to readChar() will return the next character positioned inside the margins
    * set by this method.
    *
    * <p>Method readChar() only returns characters that are positioned in
    * columns <code>beginMargin .. endMargin</code> of text elements.  The first
    * column of a text element is 1.  Setting margins for the characters to be
    * considered as part of the input stream buffer received by the parser is
    * useful in certain column-sensitive languages, such as PL/I.
    *
    * <p>A call to Init() clears any margins in effect:  all the characters in
    * the text elements of the view will be returned by subsequent readChar()
    * calls.
    *
    * <p>The style indicated will be set in the editor (by setCurrentStyles())
    * for the characters outside the margins in effect.
    *
    * @param beginMargin     begin margin;
    *                        0 indicates no begin margin in effect
    * @param endMargin       end margin (must not be below
    *                        <code>beginMargin</code>);
    *                        0 indicates no end margin in effect
    * @param outMarginsStyle style to be set for characters located outside
    *                        the margins
    *
    * @return <code>true</code>: all OK, the new margins are in effect
    *
    * @see #Init(int,int,long,long,char,boolean)
    * @see #setCurrentStyles
    */
   public boolean  setMargins(int beginMargin, int endMargin,
                              char outMarginsStyle)
   {
      if (beginMargin <= 1)
         beginMargin = 1;
      if (endMargin != 0 && endMargin < beginMargin)
         return false;

      // save margins internally as ZERO-BASED
      this.beginMargin = beginMargin - 1;
      this.endMargin   = (endMargin == 0)? 0 : endMargin-1;
      this.outMarginsStyle = outMarginsStyle;
      return true;
   }

   /**
    * Expand the existing stream in the same LpexView with one or more elements.
    * For example, the end element in the parse range may be increased when it
    * was determined that more incremental parsing needs to be done to complete
    * a language construct.
    *
    * <p>If any margins were previously set, they remain in effect.
    * If <code>endElement</code> is not above the current end element, no
    * change takes place in the existing range.
    *
    * @param endElement new end element of the parse range.  <code>EOF</code>
    *                   will be returned when trying to read characters past it
    *
    * @return the end element of the parse range
    */
   public int      Expand(int endElement)
   {
      if (endElement > lpexView.elements())      // don't go overboard...
         endElement = lpexView.elements();
      if (this.endElement < endElement) {        // if effectively an expansion:
         this.endElement = endElement;
         // decided to expand after received EOF i.e., end of the current range
         if (EOFSeen) { // when EOFSeen currentElement==original_this.endElement
            EOFSeen = false;
            bufpos = -1;
            buffer = null;
            bufferLength = 0;
            if (bufferStyles == null)
               bufferStyles = new StringBuffer();
            }
         }
      return this.endElement;
   }

   /**
    * Get an extra elementful of characters from LPEX.
    *
    * <p>The styles and classes accumulated in the current element are
    * first set in LPEX, and this element is removed from the parse-pending
    * list (if <code>clearPending</code> was indicated).
    * Then a new element in the parse range is attempted to be read in, and
    * its initial classes are set (<code>classClear</code> and
    * <code>classSet</code>).  If none available, an <code>EOF</code> exception
    * is thrown;  a subsequent EOFSeen() will return <code>true</code>.
    * This EOFSeen condition is cleared by Init(), Expand(), and backup().
    *
    * @see #Init(int,int,long,long,char,boolean)
    * @see #Expand
    * @see #backup
    */
   private void    FillBuff() throws java.io.IOException
   {
      if (!currentStylesSet &&
          (currentElement >= beginElement) && (currentElement <= endElement)) {
         setCurrentStyles();                // set current element's fonts 1st
         if (clearPending)                  //  & remove from parse-pending list
            lpexView.elementParsed(currentElement);
         }

      if (currentElement == -1)
         currentElement = beginElement-1;

      // if we ever unlock lines done with, ensure that elements from tokenBegin
      // .. up to here are kept around locked for backup()  -as-

      int tryElement = currentElement;
      do {              // try to advance to the next element in the parse range
         tryElement++;
         } while ((tryElement <= endElement) &&
                  (skipShowLines && lpexView.show(tryElement)));
      if (tryElement > endElement) {         // no more valid elements in range,
         EOFSeen = true;
         throw new java.io.EOFException();   //  was on end element: return EOF.
         }
      currentElement = tryElement;

      buffer = lpexView.elementText(currentElement);
      bufferLength = buffer.length();
      bufpos = -1;

      // set default style for the length of the newly-loaded element
      bufferStyles.setLength(bufferLength);
      for (int i = 0; i < bufferLength; i++)
         bufferStyles.setCharAt(i, styleDefault);

      // clear classClear & set classSet for the newly-loaded element
      bufferClasses =
             (lpexView.elementClasses(currentElement) & ~classClear) | classSet;
      currentStylesSet = false;
   }

   /**
    * Return the ZERO-based begin margin as it applies to the text element being
    * processed.
    * *as* MUST consider useSourceColumns if DBCS source encoding!!
    */
   private int     beginMargin()
   {
      // if (beginMargin == 0) return 0; // no calculations needed
      return beginMargin;
   }

   /**
    * Return the ZERO-based end margin as it applies to the text element being
    * processed.
    * *as* MUST consider useSourceColumns if DBCS source encoding!!
    */
   private int     endMargin()
   {
      // if (endMargin == 0) return 0; // no calculations needed
      return endMargin;
   }

   /**
    * Return the document view that provides this input stream.
    */
   public LpexView getLpexView()
   {
      return lpexView;
   }

   /**
    * Return the end element of the parse range.
    *
    * @see #Init(int,int,long,long,char,boolean)
    * @see #Expand
    */
   public int      getEndElement()
   {
      return endElement;
   }

   /**
    * Check whether <code>EOF</code> was encountered on the last character read.
    * Useful in determining the cause of a TokenMgrError.
    * The EOFSeen condition is cleared by Init(), Expand(), and backup().
    *
    * @see #Init(int,int,long,long,char,boolean)
    * @see #Expand
    * @see #backup
    */
   public boolean  EOFSeen()
   {
      return EOFSeen;
   }

   /**
    * Skip a character in the stream.  Used to skip the last error character
    * and continue parsing.
    */
   public void     skipChar()
   {
      bufpos++;
   }

   /**
    * Go (back) to the start of the current element.
    */
   public void     backupToStart()
   {
      bufpos = -1;
   }

   /**
    * Set additional styles in the current element.
    * The style for a token located at <code>beginCol .. endCol</code> is set to
    * the specified <code>style</code> character.
    * This method does not take into account any margin setting in effect.
    *
    * <p>Style characters for the text element in the stream buffer are being
    * set by the document parser (e.g., through this method) as it parses the
    * tokens;  then, the entire styles string is automatically set in the editor
    * by LpexCharStream (through setCurrentStyles()) when a new element is read
    * in.
    *
    * @param beginCol begin column (first column in an element is 1)
    * @param endCol   end column
    * @param style    the style character
    *
    * @see #setCurrentStyles
    */
   public void     setStyles(int beginCol, int endCol, char style)
   {
      //bufferStyles.    // use mixed-case styles, like old LPEX!? -as-
      // setCharAt(beginCol-1, java.lang.Character.toUpperCase(style));
      //for (int i = beginCol; i < endCol; i++)
      // bufferStyles.setCharAt(i, style);

      // take care of the case of a single-char TokenMgrError (an error *not*
      // trapped in the .jj grammar with <BAD:~[]>), which gives e.g., a
      // getBeginColumn()=1 getEndColumn()=0 for a bad char in col.1:
      if (endCol < beginCol)
         endCol++;

      for (int i = beginCol-1;
           i < endCol && i < bufferStyles.length();  // ignore e.g., extra 'EOL'
           i++)
         bufferStyles.setCharAt(i, style);
   }

   /**
    * Set additional classes in the current element.
    * The <code>classes</code> bit-mask specified, if non-zero, is added to the
    * current element after the default <code>classSet</code> bit(s) specified
    * in Init() are first cleared.
    *
    * <p>The current classes for the text element in the stream buffer are
    * being set by the document parser (through this method) as it parses the
    * tokens;  then, the accumulated classes bit-mask is automatically set in
    * the editor by LpexCharStream (through setCurrentStyles()) when a new
    * element is read in.
    *
    * @param classes the classes bit-mask to be added to the current element
    *
    * @see #Init(int,int,long,long,char,boolean)
    * @see #setCurrentStyles
    */
   public void     setClasses(long classes)
   {
      if (classes != 0) {
         bufferClasses &= ~classSet;
         bufferClasses |= classes;
         }
   }

   /**
    * Set the styles and classes of the current element in the editor.
    * The styles (in bufferStyles) and the classes that have been set in the
    * current element by the parser through setStyles() and setClasses(), are
    * now set in the editor.
    *
    * <p>This method is called automatically by LpexCharStream when a new
    * element is being read in an attempt to fill the stream buffer for the next
    * readChar().  A parser may want to explicitly call this method when, for
    * example, a lexical error caused by <code>EOF</code> was raised (i.e.,
    * after LpexCharStream has already called this method for the element), in
    * order to update the element with <i>this error</i>'s styles & classes.
    * A parser may also call this method when switching to another subparser
    * (lexer) for the rest of an element.
    *
    * <p>If margin settings are in effect, the style indicated by
    * <code>outMarginsStyle</code> in setMargins() will be set in the editor
    * for all the characters outside the margins.
    *
    * @see #setStyles
    * @see #setClasses
    * @see #setMargins
    */
   public void     setCurrentStyles()
   {
      if (beginMargin != 0)
         for (int i = 0; i < beginMargin() && i < bufferStyles.length(); i++)
            bufferStyles.setCharAt(i, outMarginsStyle);
      if (endMargin != 0)
         for (int i = endMargin()+1; i < bufferStyles.length(); i++)
            bufferStyles.setCharAt(i, outMarginsStyle);

      lpexView.setElementStyle(currentElement, bufferStyles.toString());
      lpexView.setElementClasses(currentElement, bufferClasses);
      currentStylesSet = true;
   }
}