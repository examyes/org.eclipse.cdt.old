//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FontParameter - font Parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class FontParameter extends ParameterFontDefault
{
 private static FontParameter _parameter;

 static FontParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new FontParameter();
   }
  return _parameter;
 }

 /**
  * Create a parameter named PARAMETER_FONT, with a hard-coded default value
  * of the default LPEX font.
  */
 private FontParameter()
 {
  super(PARAMETER_FONT, Font.decodeFont(null));
 }

 boolean setValue(View view, Font value)
 {
  if (view != null)
   {
    view.screen().setFont(value);
   }
  return true;
 }

 void currentValueChanged(View view)
 {
  view.screen().newFont();
 }

 Font value(View view)
 {
  return (view != null)? view.screen().font() : null;
 }
}