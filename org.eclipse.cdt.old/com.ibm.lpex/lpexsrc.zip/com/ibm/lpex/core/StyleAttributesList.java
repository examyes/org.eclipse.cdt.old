//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// StyleAttributesList
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class is used to manage a list of StyleAttributes.
 */
final class StyleAttributesList extends List
{
 private StyleAttributesNode _lastFound;
 private char _lastFoundStyleCharacter;


 /**
  * Locate the style attributes for a specified style character.
  */
 StyleAttributes find(char styleCharacter)
 {
  StyleAttributesNode node = findNode(styleCharacter);
  if (node != null)
   {
    return node.styleAttributes();
   }

  return null;
 }

 void set(char styleCharacter, StyleAttributes styleAttributes)
 {
  StyleAttributesNode node = findNode(styleCharacter);
  if (node == null)
   {
    if (styleAttributes != null)
     {
      node = new StyleAttributesNode(styleCharacter, styleAttributes);
     }
    addBefore(null, node);
   }

  else
   {
    if (styleAttributes != null)
     {
      node.setStyleAttributes(styleAttributes);
     }
    else
     {
      remove(node);
     }
   }
 }

 Node remove(Node node)
 {
  if (node == _lastFound)
   {
    _lastFound = null;
   }
  super.remove(node);
  return node;
 }

 private StyleAttributesNode findNode(char styleCharacter)
 {
  if (_lastFound != null && _lastFoundStyleCharacter == styleCharacter)
   {
    return _lastFound;
   }

  for (Node current = first(); current != null; current = current.next())
   {
    if (((StyleAttributesNode) current).styleCharacter() == styleCharacter)
     {
      _lastFound = (StyleAttributesNode) current;
      _lastFoundStyleCharacter = styleCharacter;
      return _lastFound;
     }
   }

  return null;
 }
}


/**
 * This class is used to manage the style attributes for a style character.
 */
final class StyleAttributesNode extends ListNode
{
 private char _styleCharacter;
 private StyleAttributes _styleAttributes;

 StyleAttributesNode(char styleCharacter, StyleAttributes styleAttributes)
 {
  _styleCharacter = styleCharacter;
  _styleAttributes = styleAttributes;
 }

 char styleCharacter()
 {
  return _styleCharacter;
 }

 StyleAttributes styleAttributes()
 {
  return _styleAttributes;
 }

 void setStyleAttributes(StyleAttributes styleAttributes)
 {
  _styleAttributes = styleAttributes;
 }
}