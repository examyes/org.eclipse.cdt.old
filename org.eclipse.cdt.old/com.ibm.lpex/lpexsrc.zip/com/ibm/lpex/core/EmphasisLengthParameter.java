//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// EmphasisLengthParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class EmphasisLengthParameter extends ParameterIntegerOnly
{
 private static EmphasisLengthParameter _parameter;

 static EmphasisLengthParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new EmphasisLengthParameter();
   }
  return _parameter;
 }

 private EmphasisLengthParameter()
 {
  super(PARAMETER_EMPHASIS_LENGTH);
 }

 boolean setValue(View view, String qualifier, int value)
 {
  if (view != null)
   {
    view.documentPosition().setEmphasisLength(value);
   }
  return true;
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.documentPosition().emphasisLength() : 0;
 }
}