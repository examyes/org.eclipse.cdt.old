//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DeleteCommand - handles the delete command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>delete</b> command.
 */
final class DeleteCommand
{
 static boolean doCommand(View view, String parameters)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);

  int count = 1;
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    try
     {
      count = Integer.parseInt(token);
      if (count < 1)
       {
        return CommandHandler.invalidParameter(view, token, "delete");
       }

      if (st.hasMoreTokens())
       {
        return CommandHandler.invalidParameter(view, st.nextToken(), "delete");
       }
     }
    catch(NumberFormatException e)
     {
      return CommandHandler.invalidParameter(view, token, "delete");
     }
   }

  // command parameters are correct, now do it if we have a view
  if (view != null)
   {
    ElementList elementList = view.document().elementList();
    int availableElements = elementList.count() -
                            elementList.ordinalOf(view.documentPosition().element()) + 1;
    if (count > availableElements)
     {
      count = availableElements;
     }

    for (int i = 0; i < count; i++)
     {
      view.deleteElement(view.documentPosition().element());
     }

    view.verifyDocumentSection(); // may have to expand document section now
   }

  return true;
 }
}