//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SortCommand - handles the sort command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.text.Collator;

/**
 * This class implements the <b>sort</b> command.
 * It handles the sorting of text elements inside the document section that is
 * currently loaded in the editor.  It does not trigger a request for extending
 * this document section.
 */
final class SortCommand
{
 private static Collator _collator;

 static boolean doCommand(View view, String parameters)
 {
  // 1.- set up sorting defaults
  boolean selection = (Block.view() == view) && Block.anythingSelected();
  boolean all = !selection;
  int startElement = 0;
  int endElement = 0;
  FieldOptions options = new FieldOptions();
  if (selection && Block.type() == Block.RECTANGLE)
   {
    options._blockRectangle = true;
   }

  // 2.- override defaults with any specified parameters
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    if (token.equals("all"))
     {
      all = true;
      selection = false;
      options._blockRectangle = false;
      token = null;
     }
    else if (token.equals("selection"))
     {
      selection = true;
      options._blockRectangle = Block.type() == Block.RECTANGLE;
      all = false;
      token = null;
     }
    else if (token.equals("elementRange"))
     {
      selection = false;
      all = false;
      options._blockRectangle = false;
      startElement = 1;
      endElement = (view != null)? view.document().elementList().count() : 0;

      if (st.hasMoreTokens())
       {
        token = st.nextToken();
        try
         {
          startElement = Integer.parseInt(token) -
                         // adjust from complete doc -> currently loaded doc section
                         ((view != null)? view.document().linesBeforeStart() : 0);
          if (startElement < 1)
           {
            return CommandHandler.invalidParameter(view, token, "sort");
           }

          token = null;
          if (st.hasMoreTokens())
           {
            token = st.nextToken();
            try
             {
              endElement = Integer.parseInt(token) -
                           // adjust from complete doc -> currently loaded doc section
                           ((view != null)? view.document().linesBeforeStart() : 0);
              if (endElement < 1)
               {
                return CommandHandler.invalidParameter(view, token, "sort");
               }
              token = null;
             }
            catch (NumberFormatException e) {}
           }
         }
        catch (NumberFormatException e)
         {
          return CommandHandler.integerMissing(view, "elementRange", "sort");
         }
       }
      else
       {
        return CommandHandler.integerMissing(view, "elementRange", "sort");
       }
     }

    FieldOptions currentFieldOptions = options;
    while (token != null || st.hasMoreTokens())
     {
      if (token == null)
       {
        token = st.nextToken();
       }

      if (token.equals("descending"))
       {
        currentFieldOptions._descending = true;
        token = null;
       }

      else if (token.equals("numeric"))
       {
        currentFieldOptions._numeric = true;
        token = null;
       }

      else if (token.equals("localeSensitive"))
       {
        currentFieldOptions._localeSensitive = true;
        token = null;
        if (_collator == null)
         {
          _collator = Collator.getInstance();
         }
       }

      else if (token.equals("columnRange"))
       {
        currentFieldOptions._blockRectangle = false;
        if (st.hasMoreTokens())
         {
          token = st.nextToken();
          try
           {
            currentFieldOptions._startColumn = Integer.parseInt(token);
            if (currentFieldOptions._startColumn < 1)
             {
              return CommandHandler.invalidParameter(view, token, "sort");
             }
            token = null;
            if (st.hasMoreTokens())
             {
              token = st.nextToken();
              try
               {
                currentFieldOptions._endColumn = Integer.parseInt(token);
                if (currentFieldOptions._endColumn < 1)
                 {
                  return CommandHandler.invalidParameter(view, token, "sort");
                 }
                token = null;
               }
              catch (NumberFormatException e) {}
             }
           }
          catch (NumberFormatException e)
           {
            return CommandHandler.integerMissing(view, "columnRange", "sort");
           }
         }
        else
         {
          return CommandHandler.integerMissing(view, "columnRange", "sort");
         }
       }

      else if (token.equals("newField"))
       {
        FieldOptions newFieldOptions = new FieldOptions();
        currentFieldOptions._next = newFieldOptions;
        currentFieldOptions = newFieldOptions;
        token = null;
       }

      else
       {
        return CommandHandler.invalidParameter(view, token, "sort");
       }
     }
   }

  // command format correct, but nothing to do if no view
  if (view == null)
   {
    return true;
   }

  if (all)
   {
    startElement = 1;
    endElement = view.document().elementList().count();
   }
  else if (selection)
   {
    if (Block.view() == view && Block.anythingSelected())
     {
      startElement = view.document().elementList().ordinalOf(Block.topElement());
      endElement = view.document().elementList().ordinalOf(Block.bottomElement());
     }
    else
     {
      startElement = 0;
      endElement = 0;
     }
   }

  // 3.- do the sorting
  sort(view, startElement, endElement, options);
  return true;
 }

 /**
  * Sort the given range of elements in the currently-loaded document section,
  * according to the given FieldOptions list.
  */
 static void sort(View view, int startElementOrdinal, int endElementOrdinal, FieldOptions options)
 {
  if (!view.changeAllowed())
   {
    return;
   }

  ElementList elementList = view.document().elementList();
  MarkList markList = view.markList();
  Element startElement = elementList.elementAt(startElementOrdinal);
  while (startElement != null &&
         (!startElement.visible(view) ||
          startElement.show() ||
          markList.protect(startElement)))
   {
    startElement = startElement.next();
   }

  Element endElement = elementList.elementAt(endElementOrdinal);
  while (endElement != null &&
         (!endElement.visible(view) ||
          endElement.show() ||
          markList.protect(endElement)))
   {
    endElement = endElement.prev();
   }

  if (startElement != null && endElement != null &&
      elementList.ordinalOf(startElement) < elementList.ordinalOf(endElement))
   {
    int count = 2;
    Element element;
    for (element = startElement.next();
         element != null && element != endElement;
         element = element.next())
     {
      if (element.visible(view) && !element.show() && !markList.protect(element))
       {
        count++;
       }
     }

    Element elements[] = new Element[count];
    elements[0] = startElement;
    elements[count - 1] = endElement;
    int i = 1;
    for (element = startElement.next();
         element != null && element != endElement;
         element = element.next())
     {
      if (element.visible(view) && !element.show() && !markList.protect(element))
       {
        elements[i] = element;
        i++;
       }
     }

    Element originalElements[] = new Element[count];
    for (i = 0; i < count; i++)
     {
      originalElements[i] = elements[i];
     }

    // do the quick sort
    quickSort(view, elements, 0, count - 1, options);

    String newTexts[] = new String[count];
    for (i = 0; i < count; i++)
     {
      if (originalElements[i] != elements[i])
       {
        newTexts[i] = elements[i].text();
       }
     }

    DocumentPosition documentPosition = view.documentPosition();
    DocumentPosition.Preserve preserve = documentPosition.preserve();
    for (i = 0; i < count; i++)
     {
      if (newTexts[i] != null)
       {
        documentPosition.jump(originalElements[i], 1);
        view.overlayElements(newTexts[i]);
       }
     }

    preserve.restore();
    documentPosition.disposePreserve(preserve);
   }
 }

 /**
  * Version of Hoare's quick-sort algorithm.  It handles arrays that are
  * already sorted, and arrays with duplicate keys.
  *
  * <p>Consider a one dimensional array as going from the lowest index on
  * the left to the highest index on the right.  The parameters to this
  * function are lowest index or left, and highest index or right.
  * First time around, this function is called with the parameters:
  *   lo0 = 0, hi0 = elements.length - 1.
  *
  * @param elements array of text elements
  * @param lo0      left boundary of array partition
  * @param hi0      right boundary of array partition
  */
 static void quickSort(View view, Element elements[], int lo0, int hi0, FieldOptions options)
  {
   int lo = lo0;
   int hi = hi0;
   Element mid;

   if (hi0 > lo0)
    {
     // arbitrarily establish partition element as the midpoint of the array
     mid = elements[(lo0 + hi0) / 2];

     // loop through the array until the indexes cross
     while (lo <= hi)
      {
       // find the first element that is greater than or equal to
       // the partition element starting from the left Index
       while (lo < hi0 && compare(view, elements[lo], mid, options) < 0)
        {
         ++lo;
        }

       // find an element that is smaller than or equal to
       // the partition element starting from the right Index
       while (hi > lo0 && compare(view, elements[hi], mid, options) > 0)
        {
         --hi;
        }

       // if the indexes have not crossed, swap
       if (lo <= hi)
        {
         Element temp;
         temp = elements[lo];
         elements[lo] = elements[hi];
         elements[hi] = temp;

         ++lo;
         --hi;
        }
      }

     // if the right index has not reached the left side of array,
     // must now sort the left partition
     if (lo0 < hi)
      {
       quickSort(view, elements, lo0, hi, options);
      }

     // if the left index has not reached the right side of array,
     // must now sort the right partition
     if (lo < hi0)
      {
       quickSort(view, elements, lo, hi0, options);
      }
    }
  }

 /**
  * Compare element1 and element2 as per the FieldOptions list passed in.
  */
 static int compare(View view, Element element1, Element element2, FieldOptions options)
  {
   int compare;
   do
    {
     String text1 = options.text(view, element1);
     String text2 = options.text(view, element2);
     if (options._numeric)
      {
       try
        {
         int integer1 = Integer.parseInt(text1.trim());
         int integer2 = Integer.parseInt(text2.trim());
         compare = integer1 - integer2;
        }
       catch (NumberFormatException e)
        {
         compare = text1.compareTo(text2);
        }
      }
     else if (options._localeSensitive)
      {
       compare = _collator.compare(text1, text2);
      }
     else
      {
       compare = text1.compareTo(text2);
      }

     if (compare != 0 && options._descending)
      {
       compare = -compare;
      }

     options = options._next;
    } while (compare == 0 && options != null);

   return compare;
  }


 final static class FieldOptions
 {
  FieldOptions _next;

  int _startColumn = 1;
  int _endColumn = -1;

  boolean _blockRectangle;
  boolean _numeric;
  boolean _descending;
  boolean _localeSensitive;

  /**
   * Return the text of an element as per this FieldOptions:
   * between the start .. end columns.
   */
  String text(View view, Element element)
  {
   int startColumn = _startColumn;
   int endColumn = _endColumn;
   if (_blockRectangle)
    {
     startColumn = Block.selectedTextStart(view, element);
     endColumn = Block.selectedTextEnd(view, element);
    }

   String text = element.text();
   if (startColumn > text.length())
    {
     text = "";
    }
   else if (startColumn > 1)
    {
     text = text.substring(startColumn - 1);
    }

   if (endColumn != -1)
    {
     int len = endColumn - startColumn + 1;
     if (len <= 0)
      {
       text = "";
      }
     else if (text.length() > len)
      {
       text = text.substring(0, len);
      }
    }

   return text;
  }
 }
}