//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterIntegerOnly - base class for simple integer parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Base, abstract class for simple decimal integer parameters (with no install,
 * default, and current values).
 */
abstract class ParameterIntegerOnly extends ParameterIntegerQuery
{
 ParameterIntegerOnly(String name)
 {
  super(name);
 }

 boolean isQueryOnly(String qualifier)
 {
  return false;
 }

 boolean set(View view, String qualifier, String parameters)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (!st.hasMoreTokens())
   {
    return CommandHandler.incomplete(view, "set " + name(qualifier));
   }

  String token = st.nextToken();
  int value;
  try
   {
    value = Integer.parseInt(token);
   }
  catch(NumberFormatException e)
   {
    return CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
   }

  if (st.hasMoreTokens())
   {
    return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name(qualifier));
   }

  return setValue(view, qualifier, value);
 }

 abstract boolean setValue(View view, String qualifier, int value);
}