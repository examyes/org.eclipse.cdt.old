//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LengthParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class LengthParameter extends ParameterIntegerQuery
{
 private static LengthParameter _parameter;

 static LengthParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new LengthParameter();
   }
  return _parameter;
 }

 private LengthParameter()
 {
  super(PARAMETER_LENGTH);
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return view != null && documentLocation != null &&
         view.document().elementList().elementAt(documentLocation.element) != null;
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null && documentLocation != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    if (element != null)
     {
      return element.length();
     }
   }

  return 0;
 }
}