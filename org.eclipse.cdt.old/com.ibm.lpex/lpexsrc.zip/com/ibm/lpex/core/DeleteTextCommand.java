//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DeleteTextCommand - handles the deleteText command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>deleteText</b> command.
 */
final class DeleteTextCommand
{
 static boolean doCommand(View view, String parameters)
 {
  int len = 1;

  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    try
     {
      len = Integer.parseInt(token);
      if (len < 1)
       {
        return CommandHandler.invalidParameter(view, token, "deleteText");
       }
      if (st.hasMoreTokens())
       {
        return CommandHandler.invalidParameter(view, st.nextToken(), "deleteText");
       }
     }
    catch(NumberFormatException e)
     {
      return CommandHandler.invalidParameter(view, token, "deleteText");
     }
   }

  // command format is correct, now if we have a view do it
  if (view != null)
   {
    view.deleteText(len);
   }

  return true;
 }
}