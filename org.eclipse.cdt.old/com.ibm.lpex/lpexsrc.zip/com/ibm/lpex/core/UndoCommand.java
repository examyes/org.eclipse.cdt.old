//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// UndoCommand - handles the undo command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>undo</b> command.
 */
final class UndoCommand
{
 static boolean doCommand(View view, String parameters)
 {
  int undoCount = 1;
  boolean quiet = false;
  boolean discard = false;

  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    if (token.equals("clear"))
     {
      if (st.hasMoreTokens())
       {
        return CommandHandler.invalidParameter(view, st.nextToken(), "undo clear");
       }
      if (view != null)
       {
        view.document().undo().clear();
       }
      return true;
     }

    if (token.equals("check"))
     {
      if (st.hasMoreTokens())
       {
        return CommandHandler.invalidParameter(view, st.nextToken(), "undo check");
       }
      if (view != null)
       {
        view.document().undo().check(view);
       }
      return true;
     }

    if (token.equals("resetChanges"))
     {
      if (st.hasMoreTokens())
       {
        return CommandHandler.invalidParameter(view, st.nextToken(), "undo resetChanges");
       }
      if (view != null)
       {
        view.document().undo().resetChanges(view);
       }
      return true;
     }

    try
     {
      undoCount = Integer.parseInt(token);
      token = st.hasMoreTokens()? st.nextToken() : null;
     }
    catch(NumberFormatException e) {}

    while (token != null)
     {
      if (undoCount >= 0 && token.equals("discard"))
       {
        discard = true;
       }
      else if (token.equals("quiet"))
       {
        quiet = true;
       }
      else
       {
        return CommandHandler.invalidParameter(view, token, "undo");
       }

      token = st.hasMoreTokens()? st.nextToken() : null;
     }
   }

  if (view != null)
   {
    if (undoCount >= 0)
     {
      view.document().undo().undo(view, undoCount, quiet, discard);
     }
    else
     {
      view.document().undo().redo(view, -undoCount, quiet);
     }
   }

  return true;
 }
}