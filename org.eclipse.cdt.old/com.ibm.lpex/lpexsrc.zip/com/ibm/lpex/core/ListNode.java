//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ListNode - a node in a List.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import com.ibm.lpex.core.List.Node;

/**
 * This class defines a node in a List.
 *
 * @see List
 */
class ListNode implements Node
{
 private Node _next;
 private Node _prev;
 private boolean _removePending;


 /**
  * Retrieve the next node in the list.
  */
 public Node next()
 {
  return _next;
 }

 /**
  * Set the next node in the list.
  */
 public void setNext(Node node)
 {
  _next = node;
 }

 /**
  * Retrieve the previous node in the list.
  */
 public Node prev()
 {
  return _prev;
 }

 /**
  * Set the previous node in the list.
  */
 public void setPrev(Node node)
 {
  _prev = node;
 }

 public void setRemovePending()
 {
  _removePending = true;
 }

 public boolean removePending()
 {
  return _removePending;
 }
}