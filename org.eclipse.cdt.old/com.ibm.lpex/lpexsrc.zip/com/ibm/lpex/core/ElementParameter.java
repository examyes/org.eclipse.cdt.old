//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ElementParameter - handles the element parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>element</b> parameter.
 * This parameter is query only.
 * It returns the ordinal number of the current element in the entire document.
 */
final class ElementParameter extends ParameterIntegerQuery
{
 private static ElementParameter _parameter;

 static ElementParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ElementParameter();
   }
  return _parameter;
 }

 private ElementParameter()
 {
  super(PARAMETER_ELEMENT);
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return view != null && documentLocation != null &&
         view.document().elementList().elementAt(documentLocation.element) != null;
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (documentLocation == null)? 0 : documentLocation.element +
                                         // add number of lines before loaded document section
                                         view.document().linesBeforeStart();
 }
}