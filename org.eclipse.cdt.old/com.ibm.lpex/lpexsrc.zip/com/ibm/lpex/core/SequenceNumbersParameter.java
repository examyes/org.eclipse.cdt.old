//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SequenceNumbersParameter - handles the sequenceNumbers parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>sequenceNumbers</b> parameter.
 * The ParameterDefault class it extends provides the framework for handling
 * parameters with install, default, and current values.
 */
final class SequenceNumbersParameter extends ParameterDefault
{
 /**
  * The singleton SequenceNumbersParameter (static _parameter) object handles
  * (by occasionally delegating to Document) the document-scoped sequenceNumbers
  * for all the documents (note that all its methods have a View or Document
  * argument passed in).
  *
  * The actual value of a document's sequenceNumbers is stored in the Document:
  * - private SequenceNumbersParameter.Settings _sequenceNumbersSettings = null;
  * - SequenceNumbersParameter.Settings sequenceNumbersSettings()
  */
 private static SequenceNumbersParameter _parameter;

 private final static int _hardCodedNumColumn  = 1;
 private final static int _hardCodedNumWidth   = 0;
 private final static int _hardCodedTextColumn = 1;
 private final static int _hardCodedTextWidth  = 0;

 private int     _installNumColumn;
 private int     _installNumWidth;
 private int     _installTextColumn;
 private int     _installTextWidth;
 private boolean _installValueLoaded;

 private int     _defaultNumColumn;
 private int     _defaultNumWidth;
 private int     _defaultTextColumn;
 private int     _defaultTextWidth;
 private boolean _defaultValueLoaded;
 private boolean _useInstallValue;


 static SequenceNumbersParameter getParameter()
  {
   if (_parameter == null)
    {
     _parameter = new SequenceNumbersParameter();
    }
   return _parameter;
  }

 /**
  * Private constructor - SequenceNumbersParameter is not instantiated
  * directly, but by the first call to SequenceNumbersParameter.getParameter().
  */
 private SequenceNumbersParameter()
  {
   // construct a ParameterDefault with the name PARAMETER_SEQUENCE_NUMBERS
   super(PARAMETER_SEQUENCE_NUMBERS);

   // listen to changes in the LPEX Install profile
   // (possible value change of install.sequenceNumbers)
   Install.addProfileChangedListener(new Install.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _installValueLoaded = false;
       if (useInstallValue())
        {
         defaultValueChanged();
        }
      }
    });

   // listen to changes in the LPEX profile
   // (possible value change of default.sequenceNumbers)
   Profile.addProfileChangedListener(new Profile.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _defaultValueLoaded = false;
       defaultValueChanged();
      }
    });
  }

 /**
  * Load values from the LPEX Install profile:
  *   install.sequenceNumbers=numColumn numWidth [textColumn textWidth]
  */
 private void loadInstallValue()
  {
   if (!_installValueLoaded)
    {
     _installNumColumn  = _hardCodedNumColumn;
     _installNumWidth   = _hardCodedNumWidth;
     _installTextColumn = _hardCodedTextColumn;
     _installTextWidth  = _hardCodedTextWidth;
     _installValueLoaded = true;

     int numColumn  = _hardCodedNumColumn;
     int numWidth   = _hardCodedNumWidth;
     int textColumn = _hardCodedTextColumn;
     int textWidth  = _hardCodedTextWidth;

     String value = Install.getString(PARAMETER_INSTALL + name());
     if (value != null)
      {
       LpexStringTokenizer st = new LpexStringTokenizer(value);
       try
        {
         if (st.hasMoreTokens())
          {
           numColumn = Integer.parseInt(st.nextToken());
           if (st.hasMoreTokens())
            {
             numWidth = Integer.parseInt(st.nextToken());
             if (st.hasMoreTokens())
              {
               textColumn = Integer.parseInt(st.nextToken());
               if (!st.hasMoreTokens())
                {
                 return;
                }
               textWidth = Integer.parseInt(st.nextToken());
               if (st.hasMoreTokens())
                {
                 return;
                }
              }

             if (validSequenceNumbers(numColumn, numWidth,
                                      textColumn, textWidth))
              {
               _installNumColumn  = numColumn;
               _installNumWidth   = numWidth;
               _installTextColumn = textColumn;
               _installTextWidth  = textWidth;
              }
            }
          }
        }
       catch (NumberFormatException e) {}
      }
    }
  }

 private int installNumColumn()
  {
   loadInstallValue();
   return _installNumColumn;
  }

 private int installTextColumn()
  {
   loadInstallValue();
   return _installTextColumn;
  }

 private int installNumWidth()
  {
   loadInstallValue();
   return _installNumWidth;
  }

 private int installTextWidth()
  {
   loadInstallValue();
   return _installTextWidth;
  }

 /**
  * Load values from the LPEX profile:
  *   default.sequenceNumbers=numColumn numWidth [textColumn textWidth]
  */
 private void loadDefaultValue()
  {
   if (!_defaultValueLoaded)
    {
     _useInstallValue = true;
     _defaultValueLoaded = true;

     int numColumn  = _installNumColumn;
     int numWidth   = _installNumWidth;
     int textColumn = _installTextColumn;
     int textWidth  = _installTextWidth;

     String value = Profile.getString(PARAMETER_DEFAULT + name());
     if (value != null)
      {
       LpexStringTokenizer st = new LpexStringTokenizer(value);
       try
        {
         if (st.hasMoreTokens())
          {
           numColumn = Integer.parseInt(st.nextToken());
           if (st.hasMoreTokens())
            {
             numWidth = Integer.parseInt(st.nextToken());
             if (st.hasMoreTokens())
              {
               textColumn = Integer.parseInt(st.nextToken());
               if (!st.hasMoreTokens())
                {
                 return;
                }

               textWidth = Integer.parseInt(st.nextToken());
               if (st.hasMoreTokens())
                {
                 return;
                }
              }

             if (validSequenceNumbers(numColumn, numWidth,
                                      textColumn, textWidth))
              {
               _useInstallValue = false;
               _defaultNumColumn  = numColumn;
               _defaultNumWidth   = numWidth;
               _defaultTextColumn = textColumn;
               _defaultTextWidth  = textWidth;
              }
            }
          }
        }
       catch (NumberFormatException e) {}
      }
    }
  }

 /**
  * Is default.sequenceNumbers = "install"?
  */
 private boolean useInstallValue()
  {
   loadDefaultValue();
   return _useInstallValue;
  }

 private int defaultNumColumn()
  {
   loadDefaultValue();
   return _defaultNumColumn;
  }

 private int defaultTextColumn()
  {
   loadDefaultValue();
   return _defaultTextColumn;
  }

 private int defaultNumWidth()
  {
   loadDefaultValue();
   return _defaultNumWidth;
  }

 private int defaultTextWidth()
  {
   loadDefaultValue();
   return _defaultTextWidth;
  }

 private boolean setDefaultValue(int numColumn, int numWidth,
                                 int textColumn, int textWidth,
                                 boolean useInstallValue)
  {
   _defaultNumColumn  = numColumn;
   _defaultNumWidth   = numWidth;
   _defaultTextColumn = textColumn;
   _defaultTextWidth  = textWidth;
   _useInstallValue = useInstallValue;
   _defaultValueLoaded = true;

   if (!_useInstallValue)
    {
     String value = _defaultNumColumn  +" "+ _defaultNumWidth +" "+
                    _defaultTextColumn +" "+ _defaultTextWidth;
     Profile.putString(PARAMETER_DEFAULT + name(), value);
    }
   else
    {
     Profile.remove(PARAMETER_DEFAULT + name());
    }

   defaultValueChanged();
   return true;
  }

 int currentNumColumn(Document document)
  {
   if (useDefaultValue(document))
    {
     return useInstallValue()? installNumColumn() : defaultNumColumn();
    }

   return numColumn(document);
  }

 int currentTextColumn(Document document)
  {
   if (useDefaultValue(document))
    {
     return useInstallValue()? installTextColumn() : defaultTextColumn();
    }

   return textColumn(document);
  }

 int currentNumWidth(Document document)
  {
   if (useDefaultValue(document))
    {
     return useInstallValue()? installNumWidth() : defaultNumWidth();
    }

   return numWidth(document);
  }

 int currentTextWidth(Document document)
  {
   if (useDefaultValue(document))
    {
     return useInstallValue()? installTextWidth() : defaultTextWidth();
    }

   return textWidth(document);
  }

 boolean set(View view, String qualifier, String parameters)
  {
   boolean useDefaultValue = true;
   int numColumn  = 1;
   int numWidth   = 0;
   int textColumn = 1;
   int textWidth  = 0;

   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (!token.equals("default"))
      {
       useDefaultValue = false;
       try
        {
         // numColumn numWidth
         numColumn = Integer.parseInt(token);
         if (numColumn < 1)
          {
           return CommandHandler.invalidParameter(view, token, "set " + name());
          }
         if (!st.hasMoreTokens())
          {
           return CommandHandler.incomplete(view, "set " + name());
          }

         token = st.nextToken();
         numWidth = Integer.parseInt(token);
         if (numWidth < 0 || numWidth > 9)
          {
           return CommandHandler.invalidParameter(view, token, "set " + name());
          }

         // [textColumn textWidth]
         if (st.hasMoreTokens())
          {
           token = st.nextToken();
           textColumn = Integer.parseInt(token);
           if (textColumn < 1)
            {
             return CommandHandler.invalidParameter(view, token, "set " + name());
            }
           if (!st.hasMoreTokens())
            {
             return CommandHandler.incomplete(view, "set " + name());
            }

           token = st.nextToken();
           textWidth = Integer.parseInt(token);
           if (!validSequenceNumbers(numColumn, numWidth, textColumn, textWidth))
            {
             return CommandHandler.invalidParameter(view, token, "set " + name());
            }
          }
        }
       catch(NumberFormatException e)
        {
         return CommandHandler.invalidParameter(view, token, "set " + name());
        }
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name());
      }
    }

   if (view != null)
    {
     return setValue(view, numColumn, numWidth,
                     textColumn, textWidth, useDefaultValue);
    }
   return true;
  }

 private boolean setValue(View view, int numColumn, int numWidth,
                          int textColumn, int textWidth, boolean useDefaultValue)
  {
   Document document = view.document();
   if (document != null)
    {
     Settings settings = document.sequenceNumbersSettings();
     settings._numColumn  = numColumn;
     settings._numWidth   = numWidth;
     settings._textColumn = textColumn;
     settings._textWidth  = textWidth;

     settings._useDefaultValue = useDefaultValue;
     currentValueChanged(view);
    }
   return true;
  }

 boolean setDefault(View view, String qualifier, String parameters)
  {
   boolean useInstallValue = true;
   int numColumn  = 1;
   int numWidth   = 0;
   int textColumn = 1;
   int textWidth  = 0;

   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (!token.equals("install"))
      {
       useInstallValue = false;
       try
        {
         // numColumn numWidth
         numColumn = Integer.parseInt(token);
         if (numColumn < 1)
          {
           return CommandHandler.invalidParameter(view, token, "set " + PARAMETER_DEFAULT + name());
          }
         if (!st.hasMoreTokens())
          {
           return CommandHandler.incomplete(view, "set " + PARAMETER_DEFAULT + name());
          }

         token = st.nextToken();
         numWidth = Integer.parseInt(token);
         if (numWidth < 0 || numWidth > 9)
          {
           return CommandHandler.invalidParameter(view, token, "set " + PARAMETER_DEFAULT + name());
          }

         // [textColumn textWidth]
         if (st.hasMoreTokens())
          {
           token = st.nextToken();
           textColumn = Integer.parseInt(token);
           if (textColumn < 1)
            {
             return CommandHandler.invalidParameter(view, token,
                                                    "set " + PARAMETER_DEFAULT + name());
            }
           if (!st.hasMoreTokens())
            {
             return CommandHandler.incomplete(view, "set " + PARAMETER_DEFAULT + name());
            }

           token = st.nextToken();
           textWidth = Integer.parseInt(token);
           if (!validSequenceNumbers(numColumn, numWidth, textColumn, textWidth))
            {
             return CommandHandler.invalidParameter(view, token,
                                                    "set " + PARAMETER_DEFAULT + name());
            }
          }
        }
       catch(NumberFormatException e)
        {
         return CommandHandler.invalidParameter(view, token, "set " + PARAMETER_DEFAULT + name());
        }
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(),
                                              "set " + PARAMETER_DEFAULT + name());
      }
    }

   return setDefaultValue(numColumn, numWidth, textColumn, textWidth, useInstallValue);
  }

 /**
  * Value of default.sequenceNumbers has changed:
  * update affected documents.
  */
 private void defaultValueChanged()
  {
   for (Document document = Document._firstDocument;
        document != null;
        document = document._next)
    {
     if (useDefaultValue(document))
      {
       currentValueChanged(document._firstView); // pick any view
      }
    }
  }

 /**
  * Value of current.sequenceNumbers for a document has changed:
  * update the document's elements.
  */
 private void currentValueChanged(View view)
  {
   Document document = view.document();
   if (document != null)
    {
     document.elementList().setSequenceNumbers(view,
                                               currentNumColumn(document),
                                               currentNumWidth(document),
                                               currentTextColumn(document),
                                               currentTextWidth(document));
    }
  }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   if (view != null)
    {
     Document document = view.document();
     if (useDefaultValue(document))
      {
       return "default";
      }

     return numColumn(document)  +" "+ numWidth(document) +" "+
            textColumn(document) +" "+ textWidth(document);
    }

   return null;
  }

 /**
  * Is document's sequenceNumbers = "default"?
  */
 private boolean useDefaultValue(Document document)
  {
   return (document==null)? true : document.sequenceNumbersSettings()._useDefaultValue;
  }

 private int numColumn(Document document)
  {
   return (document==null)? 1 : document.sequenceNumbersSettings()._numColumn;
  }

 private int textColumn(Document document)
  {
   return (document==null)? 1 : document.sequenceNumbersSettings()._textColumn;
  }

 private int numWidth(Document document)
  {
   return (document==null)? 0 : document.sequenceNumbersSettings()._numWidth;
  }

 private int textWidth(Document document)
  {
   return (document==null)? 0 : document.sequenceNumbersSettings()._textWidth;
  }

 String queryInstall(String qualifier)
  {
   return installNumColumn()  +" "+ installNumWidth() +" "+
          installTextColumn() +" "+ installTextWidth();
  }

 String queryDefault(String qualifier)
  {
   if (useInstallValue())
    {
     return "install";
    }

   return defaultNumColumn()  +" "+ defaultNumWidth() +" "+
          defaultTextColumn() +" "+ defaultTextWidth();
  }

 String queryCurrent(View view, String qualifier)
  {
   Document document = (view != null)? view.document() : null;
   return currentNumColumn(document)  +" "+ currentNumWidth(document) +" "+
          currentTextColumn(document) +" "+ currentTextWidth(document);
  }

 /**
  * Check validity of sequenceNumbers parameters.
  */
 private static boolean validSequenceNumbers(int numColumn, int numWidth,
                                             int textColumn, int textWidth)
  {
   // check individual values
   if (numWidth < 0 || numWidth > 9 || textWidth < 0 || textWidth > 9 ||
       numColumn < 1 || textColumn < 1)
    {
     return false;
    }

   // if both numbers and text, check they are adjacent
   return validSequenceAreas(numColumn, numWidth, textColumn, textWidth);
  }

 /**
  * Check sequenceNumbers areas are adjacent.
  * The individual sequenceNumbers parameters are assumed to be correct.
  *
  * @see #validSequenceNumbers
  */
 private static boolean validSequenceAreas(int numColumn, int numWidth,
                                           int textColumn, int textWidth)
  {
   // if both numbers and text, check they are adjacent
   if (numWidth != 0 && textWidth != 0)
    {
     return (numColumn < textColumn)?
                (numColumn + numWidth == textColumn) :
                (textColumn + textWidth == numColumn);
    }

   return true;
  }


 /**
  * A set of values for the sequenceNumbers setting in a document.
  */
 final static class Settings
  {
   boolean _useDefaultValue = true;

   int _numColumn  = 1;             // numeric part column
   int _numWidth   = 0;             //  & its width
   int _textColumn = 1;             // text part column
   int _textWidth  = 0;             //  & its width
  }
}