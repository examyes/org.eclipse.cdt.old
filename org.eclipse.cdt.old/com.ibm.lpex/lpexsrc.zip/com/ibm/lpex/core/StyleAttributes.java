//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// StyleAttributes - handles style attributes.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.Enumeration;
import java.util.Vector;

// Swing, but just an interface (N/U in Eclipse) - can still keep AWT&SWT common source
import javax.swing.text.AttributeSet;


/**
 * This class manages style attributes.
 *
 * @author Bruce Baker, IBM, Toronto
 * @author Adrian Storisteanu, IBM, Toronto
 * @author Thomas Sharp, IBM, Santa Teresa (accessibility)
 */
final class StyleAttributes extends ListNode implements AttributeSet
{
  // list of all the StyleAttributes in LPEX
 private static List _list = new List();

 // all features of a StyleAttributes
 private Color   _foregroundColor;
 private Color   _backgroundColor;
 private boolean _underline;
 private boolean _outline;

 // accessibility attribute names
 private static Vector _attributeNames;


 /**
  * Private constructor.
  */
 private StyleAttributes(Color foregroundColor, Color backgroundColor,
                         boolean underline, boolean outline)
 {
  _foregroundColor = foregroundColor;
  _backgroundColor = backgroundColor;
  _underline = underline;
  _outline = outline;

  // set up accessibility attribute names
  if (_attributeNames == null)
   {
    _attributeNames = new Vector();
    _attributeNames.addElement("font");
    _attributeNames.addElement("foreground");
    _attributeNames.addElement("background");
    _attributeNames.addElement("underline");
    _attributeNames.addElement("outline");
   }
 }

 /**
  * Optionally create and return an LPEX-wide shared StyleAttributes object for
  * the styleAttributesString given.
  * Example input: "128 0 255 0 0 255 underline".
  *
  * @return <code>null</code> if specified styleAttributesString is incorrect
  */
 static StyleAttributes getStyleAttributes(String styleAttributesString)
 {
  if (styleAttributesString == null)
   {
    return null;
   }

  LpexStringTokenizer st = new LpexStringTokenizer(styleAttributesString);
  if (!st.hasMoreTokens())
   {
    return null;
   }

  int integerParameters[] = new int[6];
  for (int i = 0; i < 6; i++)
   {
    if (!st.hasMoreTokens())
     {
      return null;
     }

    try
     {
      integerParameters[i] = Integer.parseInt(st.nextToken());
      if (integerParameters[i] < 0 || integerParameters[i] > 255)
       {
        return null;
       }
     }
    catch(NumberFormatException e)
     {
      return null;
     }
   }

  boolean underline = false;
  boolean outline = false;
  while (st.hasMoreTokens())
   {
    String token = st.nextToken();
    if (token.equals("underline"))
     {
      underline = true;
     }
    else if (token.equals("outline"))
     {
      outline = true;
     }
    else
     {
      return null;
     }
   }

  Color fg = new Color(integerParameters[0],
                       integerParameters[1],
                       integerParameters[2]);
  Color bg = new Color(integerParameters[3],
                       integerParameters[4],
                       integerParameters[5]);
  StyleAttributes styleAttributes;
  for (styleAttributes = (StyleAttributes)_list.first();
       styleAttributes != null && !styleAttributes.equals(fg, bg, underline, outline);
       styleAttributes = (StyleAttributes)styleAttributes.next()) {}

  if (styleAttributes == null) // not found in the existing list
   {
    styleAttributes = new StyleAttributes(fg, bg, underline, outline);
   }
  else // already in the list, just move it to the head of the list
   {
    _list.remove(styleAttributes);
    fg.dispose(); // dispose of underlying temp fonts resources
    bg.dispose();
   }

  _list.addAfter(null, styleAttributes);
  return styleAttributes;
 }

 /**
  * Return a new Color instance for the RGB string given.
  * Example input: "128 0 255".
  *
  * @return <code>null</code> if color string incorrect
  */
 private static Color getColor(String color)
 {
  if (color == null)
   {
    return null;
   }

  LpexStringTokenizer st = new LpexStringTokenizer(color);
  if (!st.hasMoreTokens())
   {
    return null;
   }

  int integerParameters[] = new int[3];
  for (int i = 0; i < 3; i++)
   {
    if (!st.hasMoreTokens())
     {
      return null;
     }

    try
     {
      integerParameters[i] = Integer.parseInt(st.nextToken());
      if (integerParameters[i] < 0 || integerParameters[i] > 255)
       {
        return null;
       }
     }
    catch(NumberFormatException e)
     {
      return null;
     }
   }

  if (st.hasMoreTokens())
   {
    return null;
   }

  return new Color(integerParameters[0],
                   integerParameters[1],
                   integerParameters[2]);
 }

 static boolean checkStyleAttributes(View view, String styleAttributesString, String command)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(styleAttributesString);
  if (!st.hasMoreTokens())
   {
    return true;
   }

  String token;
  for (int i = 0; i < 6; i++)
   {
    if (!st.hasMoreTokens())
     {
      return CommandHandler.incomplete(view, command);
     }

    token = st.nextToken();
    try
     {
      int integerParameters = Integer.parseInt(token);
      if (integerParameters < 0 || integerParameters > 255)
       {
        return CommandHandler.invalidParameter(view, token, command);
       }
     }
    catch(NumberFormatException e)
     {
      return CommandHandler.invalidParameter(view, token, command);
     }
   }

  while (st.hasMoreTokens())
   {
    token = st.nextToken();
    if (!token.equals("underline") && !token.equals("outline"))
     {
      return CommandHandler.invalidParameter(view, token, command);
     }
   }

  return true;
 }

 /**
  * Compare this StyleAttributes with the specified one.
  * They are equal if their features (foreground and background colors,
  * underline and outline attributes) are all equal.
  */
 boolean equals(StyleAttributes styleAttributes)
 {
  if (this == styleAttributes)
   {
    return true;
   }

  return styleAttributes != null &&
         equals(styleAttributes.foregroundColor(),
                styleAttributes.backgroundColor(),
                styleAttributes.underline(),
                styleAttributes.outline());
 }

 /**
  * Compare this StyleAttributes with the specified one for drawing purposes.
  * They are equal if their background (but not foreground) color, underline and
  * outline attributes are all equal.
  *
  * This method is used to optimize TextWindow#validateSublines() when the next
  * character is a space (i.e., it will not paint anything in the foreground).
  */
 boolean equalsInPainting(StyleAttributes styleAttributes)
 {
  //-as- commented code = optimized for our *very* specific validateSublines() use!
  //     (where we're comparing to a non-null, non-equal styleAttributes)

  //if (this == styleAttributes)
  // return true;
  //if (styleAttributes == null)
  // return false;

  // as we paint outline for an entire string of chars, don't concatenate diff styles
  if (_outline && !_foregroundColor.equals(styleAttributes.foregroundColor()))
   {
    return false;
   }

  return _backgroundColor.equals(styleAttributes.backgroundColor()) &&
         _underline == styleAttributes.underline() &&
         _outline == styleAttributes.outline();
 }

 private boolean equals(Color foregroundColor, Color backgroundColor,
                        boolean underline, boolean outline)
 {
  return _underline == underline && _outline == outline &&
         _foregroundColor.equals(foregroundColor) &&
         _backgroundColor.equals(backgroundColor);
 }

 Color foregroundColor()
 {
  return _foregroundColor;
 }

 Color backgroundColor()
 {
  return _backgroundColor;
 }

 String backgroundColorString()
 {
  StringBuffer buffer = new StringBuffer();
  buffer.append(_backgroundColor.getRed());
  buffer.append(' ');
  buffer.append(_backgroundColor.getGreen());
  buffer.append(' ');
  buffer.append(_backgroundColor.getBlue());
  return buffer.toString();
 }

 boolean underline()
 {
  return _underline;
 }

 boolean outline()
 {
  return _outline;
 }

 String queryString()
 {
  StringBuffer buffer = new StringBuffer();
  buffer.append(_foregroundColor.getRed());
  buffer.append(' ');
  buffer.append(_foregroundColor.getGreen());
  buffer.append(' ');
  buffer.append(_foregroundColor.getBlue());
  buffer.append(' ');
  buffer.append(_backgroundColor.getRed());
  buffer.append(' ');
  buffer.append(_backgroundColor.getGreen());
  buffer.append(' ');
  buffer.append(_backgroundColor.getBlue());

  if (_underline)
   {
    buffer.append(" underline");
   }
  if (_outline)
   {
    buffer.append(" outline");
   }

  return buffer.toString();
 }

 static String background(View view)
 {
  if (view != null)
   {
    StyleAttributes defaultStyleAttributes = view.screen().styleAttributes(Screen.STYLE_DEFAULT);
    if (defaultStyleAttributes != null)
     {
      Color backgroundColor = defaultStyleAttributes.backgroundColor();
      StringBuffer buffer = new StringBuffer();
      buffer.append(backgroundColor.getRed());
      buffer.append(' ');
      buffer.append(backgroundColor.getGreen());
      buffer.append(' ');
      buffer.append(backgroundColor.getBlue());
      return buffer.toString();
     }
   }

  return null;
 }

 /**
  * Return a new StylesAttributes String converted from one background color
  * to another.
  */
 static String convert(String styleAttributesString, String fromBackground, String toBackground)
 {
  if (styleAttributesString == null || fromBackground == null || toBackground == null)
   {
    return null;
   }

  if (fromBackground.equals(toBackground))
   {
    return styleAttributesString;
   }

  StyleAttributes styleAttributes = getStyleAttributes(styleAttributesString);
  if (styleAttributes == null)
   {
    return null;
   }

  Color fromBackgroundColor = getColor(fromBackground);
  Color toBackgroundColor = getColor(toBackground);
  StringBuffer buffer = new StringBuffer();
  buffer.append(convertColorComponent(styleAttributes.foregroundColor().getRed(),
                                      fromBackgroundColor.getRed(),
                                      toBackgroundColor.getRed()));
  buffer.append(' ');
  buffer.append(convertColorComponent(styleAttributes.foregroundColor().getGreen(),
                                      fromBackgroundColor.getGreen(),
                                      toBackgroundColor.getGreen()));
  buffer.append(' ');
  buffer.append(convertColorComponent(styleAttributes.foregroundColor().getBlue(),
                                      fromBackgroundColor.getBlue(),
                                      toBackgroundColor.getBlue()));
  buffer.append(' ');
  buffer.append(convertColorComponent(styleAttributes.backgroundColor().getRed(),
                                      fromBackgroundColor.getRed(),
                                      toBackgroundColor.getRed()));
  buffer.append(' ');
  buffer.append(convertColorComponent(styleAttributes.backgroundColor().getGreen(),
                                      fromBackgroundColor.getGreen(),
                                      toBackgroundColor.getGreen()));
  buffer.append(' ');
  buffer.append(convertColorComponent(styleAttributes.backgroundColor().getBlue(),
                                      fromBackgroundColor.getBlue(),
                                      toBackgroundColor.getBlue()));

  if (styleAttributes.underline())
   {
    buffer.append(" underline");
   }
  if (styleAttributes.outline())
   {
    buffer.append(" outline");
   }

  fromBackgroundColor.dispose(); // dispose of underlying temp fonts resources
  toBackgroundColor.dispose();

  return buffer.toString();
 }

 private static int convertColorComponent(int colorComponent,
                                          int fromColorComponent, int toColorComponent)
 {
  int contrast = colorComponent - fromColorComponent;
  boolean moreColorPreferred = true;
  if (contrast < 0)
   {
    contrast = -contrast;
    moreColorPreferred = false;
   }

  int moreColor = toColorComponent + contrast;
  int lessColor = toColorComponent - contrast;
  int moreColorOverflow = 0;
  if (moreColor > 255)
   {
    moreColorOverflow = moreColor - 255;
    moreColor = 255;
   }

  int lessColorOverflow = 0;
  if (lessColor < 0)
   {
    lessColorOverflow = -lessColor;
    lessColor = 0;
   }

  if (moreColorOverflow == 0 && lessColorOverflow == 0)
   {
    colorComponent = moreColorPreferred? moreColor : lessColor;
   }
  else if (moreColorOverflow > lessColorOverflow)
   {
    colorComponent = lessColor;
   }
  else
   {
    colorComponent = moreColor;
   }

  return colorComponent;
 }


 /*-----------------------------*/
 /*  AWT JLPEX - accessibility  */
 /*-----------------------------*/

 // Implementation of StyleAttributes, for the AccessibleTextWindow.
 // A collection of unique attributes.  This is a read-only,
 // immutable interface.  An attribute is basically a key and
 // a value assigned to the key.  The collection may represent
 // something like a style run, a logical style, etc.  These
 // are generally used to describe features that will contribute
 // to some graphical representation such, as a font.  The
 // set of possible keys is unbounded and can be anything.
 // Typically View implementations will respond to attribute
 // definitions and render something to represent the attributes.
 //
 // Attributes can potentially resolve in a hierarchy.  If a
 // key doesn't resolve locally, and a resolving parent
 // exists, the key will be resolved through the parent.

 /**
  * Returns the number of attributes contained in this set.
  *
  * @return the number of attributes >= 0
  */
 public int getAttributeCount()
 {
  return _attributeNames.size();
 }

 /**
  * Checks whether the named attribute has a value specified
  * in the set without resolving through another attribute set.
  *
  * @param attrName the attribute name
  * @return true if the attribute has a value specified
  */
 public boolean isDefined(Object attrName)
 {
  return _attributeNames.contains(attrName);
 }

 /**
  * Determines if the two attribute sets are equivalent.
  *
  * @param attr an attribute set
  * @return true if the sets are equivalent
  */
 public boolean isEqual(AttributeSet attr)
 {
  return ((getAttributeCount() == attr.getAttributeCount()) &&
          containsAttributes(attr));
 }

 /**
  * Returns an attribute set that is guaranteed not
  * to change over time.
  *
  * @return a copy of the attribute set
  */
 public AttributeSet copyAttributes()
 {
  Color fg = new Color(_foregroundColor.getRed(), _foregroundColor.getGreen(),
                       _foregroundColor.getBlue());
  Color bg = new Color(_backgroundColor.getRed(), _backgroundColor.getGreen(),
                       _backgroundColor.getBlue());
  return new StyleAttributes(fg, bg, _underline, _outline);
 }

 /**
  * Fetches the value of the given attribute.  If the value is not found
  * locally, the search is continued upward through the resolving parent
  * (if one exists), until the value is either found or there are no more
  * parents.  If the value is not found, null is returned.
  *
  * @param key the non-null key of the attribute binding
  * @return the value
  */
 public Object getAttribute(Object key)
 {
  if (key.equals("font"))
   {
    String fontname = LpexView.globalQuery("current.font");
    return Font.decodeFont(fontname);
   }

  if (key.equals("foreground"))
   {
    return _foregroundColor;
   }

  if (key.equals("background"))
   {
    return _backgroundColor;
   }

  if (key.equals("underline"))
   {
    return (_underline)? Boolean.TRUE : Boolean.FALSE;
   }

  if (key.equals("outline"))
   {
    return (_outline)? Boolean.TRUE : Boolean.FALSE;
   }

  return null;
 }

 /**
 * Returns an enumeration over the names of the attributes in the set.
 * The elements of the enumeration are all Strings.  The set does
 * not include the resolving parent, if one is defined.
 *
 * @return the names
 */
 public Enumeration getAttributeNames()
 {
  return _attributeNames.elements();
 }

 /**
 * Returns true if this set contains this attribute with an equal value.
 *
 * @param name the non-null attribute name
 * @param value the value
 * @return true if the set contains the attribute with an equal value
 */
 public boolean containsAttribute(Object name, Object value)
 {
  return isDefined(name) && getAttribute(name).equals(value);
 }

 /**
 * Returns true if this set contains all the attributes with equal values.
 *
 * @param attr the set of attributes to check against
 * @return true if this set contains all the attributes with equal values
 */
 public boolean containsAttributes(AttributeSet attr)
 {
  Object key;
  for (Enumeration e = attr.getAttributeNames(); e.hasMoreElements(); )
   {
    key = e.nextElement();
    if (!containsAttribute(key, attr.getAttribute(key)))
     {
      return false;
     }
   }

  return true;
 }

 /**
 * Gets the resolving parent.
 *
 * @return the parent
 */
 public AttributeSet getResolveParent()
 {
  // we would return an AttributeSet if the "font" attribute were inherited
  // from another implementation of AttributeSet
  return null;
 }
}