//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Element - represents one text element in a document.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class is used to manage a single element.
 * There is one instance of this class per line of Document text.
 */
final class Element
{
 Element _next;
 Element _prev;

 private String   _text;           // element's text
 private Document _document;       // the document this element belongs to
 private int      _flags;
 boolean          _partOfList;
 int              _ordinal;        // element number
 private int      _nonShowOrdinal; // line number

 // element's list of ElementViews for document's various views;
 // normally created when first queried (see #elementView(View))
 ElementView      _firstElementView;

 private int      _sequenceNumber; // value of sequence-numbers numeric part
 private String   _sequenceText;   // sequence-numbers text part

 // values for _flags
 private final static int
  TABS            = 0x00000001,    // element contains tabs
  RECORDED        = 0x00000002,
  RECORDED_DELETE = 0x00000004,
  RECORDED_CHANGE = 0x00000008,
  RECORDED_INSERT = 0x00000010,
  RECORDED_NEXT   = 0x00000020,
  SHOW            = 0x00000040,    // SHOW element
  DELETE_PENDING  = 0x00000080;


 /**
  * Create an element.
  */
 Element(Document document)
 {
  _document = document;
 }

 /**
  * Create an element with a given text content.
  *
  * Shortcut for:
  *   Element newElement = new Element(document);
  *   newElement.setText(view, text);
  * optimized for the newly-constructed element.
  *
  * @see #setText
  */
 Element(Document document, String text)
 {
  _document = document;
  _text = text;

  if (_text != null && _text.indexOf('\t') != -1)
   {
    _flags = TABS;
   }
 }

 /**
  * Create a <b>show</b> element.
  */
 Element(View view)
 {
  _document = view.document();
  _flags = SHOW;
  _firstElementView = new ElementView(this, view, true); // element, view, show
 }

 Element next()
 {
  return _next;
 }

 Element prev()
 {
  return _prev;
 }

 /**
  * (Re)set the element text.
  *
  * NOTE:  This is a low-level routine, it does NOT send/trigger a document-changed
  * notification for text elements;  a meaningful document-changed notification
  * MUST be sent by the higher-level function doing the change.
  *
  * @return true = element's sequence text was also modified
  *
  * @see #Element(Document,String)
  * @see #setText(View,String,boolean)
  */
 boolean setText(View view, String text)
 {
  return setText(view, text, true);
 }

 /**
  * (Re)set the element text.
  *
  * NOTE:  This is a low-level routine, it does NOT send/trigger a document-changed
  * notification for text elements;  a meaningful document-changed notification
  * MUST be sent by the higher-level function doing the change.
  *
  * @param maintainSequenceText true = update the sequence-numbers text part to the
  *                             sequence default text if maintaining sequence numbers
  * @return true = element's sequence text was also modified
  *
  * @see #setText(View,String)
  */
 boolean setText(View view, String text, boolean maintainSequenceText)
 {
  _text = text;
  for (ElementView elementView = _firstElementView;
       elementView != null;
       elementView = elementView._next)
   {
    elementView.resetDisplayText(); // also does the .setWidthInvalid()
   }

  boolean tabs = (_text != null)? _text.indexOf('\t') != -1 : false;
  if (tabs)
   {
    _flags |= TABS;
   }
  else
   {
    _flags &= ~TABS;
   }

  if (!show() && _partOfList)
   {
    _document.addParsePending(this, LpexConstants.PARSE_PENDING_CHANGE_MASK);

    ElementList elementList = _document.elementList();
    int textLimit = elementList.textLimit();
    if (textLimit > 0 && _text != null && view != null &&
        elementList.saveLength(this) > textLimit)
     {
      view.setLpexMessageText(LpexConstants.MSG_TEXTLIMIT_OVERFLOW);
     }

    // if maintainSequenceNumbers, set the sequenceDefaultText
    if (maintainSequenceText && elementList.maintainSequenceNumbers())
     {
      return setSequenceText(elementList.sequenceDefaultText());
     }
   }

  return false;
 }

 void setWidthsInvalid()
 {
  for (ElementView elementView = _firstElementView; // for all existing ElementViews
       elementView != null;
       elementView = elementView._next)
   {
    elementView.setWidthInvalid();
   }
 }

 void setPrefixAreaWidthsInvalid()
 {
  for (ElementView elementView = _firstElementView;
       elementView != null;
       elementView = elementView._next)
   {
    elementView.setPrefixAreaWidthInvalid();
   }
 }

 /**
  * Retrieve the element text.
  * If no text is set in the element, an empty String is returned.
  */
 String text()
 {
  return (_text == null)? "" : _text;
 }

 /**
  * Retrieve the end position.
  */
 int end()
 {
  return (_text != null)? _text.length() + 1 : 1;
 }

 int length()
 {
  return (_text != null)? _text.length() : 0;
 }

 void setRecorded(boolean recorded)
 {
  if (recorded)
   {
    _flags |= RECORDED;
   }
  else
   {
    _flags &= ~RECORDED;
   }
 }

 boolean recorded()
 {
  return (_flags & RECORDED) != 0;
 }

 void setRecordedDelete(boolean recordedDelete)
 {
  if (recordedDelete)
   {
    _flags |= RECORDED_DELETE;
   }
  else
   {
    _flags &= ~RECORDED_DELETE;
   }
 }

 boolean recordedDelete()
 {
  return (_flags & RECORDED_DELETE) != 0;
 }

 void setRecordedChange(boolean recordedChange)
 {
  if (recordedChange)
   {
    _flags |= RECORDED_CHANGE;
   }
  else
   {
    _flags &= ~RECORDED_CHANGE;
   }
 }

 boolean recordedChange()
 {
  return (_flags & RECORDED_CHANGE) != 0;
 }

 void setRecordedInsert(boolean recordedInsert)
 {
  if (recordedInsert)
   {
    _flags |= RECORDED_INSERT;
   }
  else
   {
    _flags &= ~RECORDED_INSERT;
   }
 }

 boolean recordedInsert()
 {
  return (_flags & RECORDED_INSERT) != 0;
 }

 void setRecordedNext(boolean recordedNext)
 {
  if (recordedNext)
   {
    _flags |= RECORDED_NEXT;
   }
  else
   {
    _flags &= ~RECORDED_NEXT;
   }
 }

 boolean recordedNext()
 {
  return (_flags & RECORDED_NEXT) != 0;
 }

 boolean show()
 {
  return (_flags & SHOW) != 0;
 }

 View showView()
 {
  for (ElementView elementView = _firstElementView;
       elementView != null;
       elementView = elementView._next)
   {
    if (elementView.show())
     {
      return elementView.view();
     }
   }
  return null;
 }

 /**
  * Clear this element's style & classes in the specified view.
  */
 void setDefaults(View view)
 {
  ElementView elementView = elementView(view);
  elementView.setStyle(null);
  elementView.setClasses(Classes.DEFAULT);
 }

 boolean visible(View view)
 {
  return elementView(view).visible();
 }

 Element nextVisible(View view)
 {
  return nextVisible(view, false);
 }

 Element nextVisible(View view, boolean wrap)
 {
  Element element;
  for (element = next();
       element != null && !element.visible(view);
       element = element.next()) {}
  if (element == null && wrap)
   {
    element = _document.elementList().first();
    if (!element.visible(view))
     {
      element = element.nextVisible(view, false);
     }
   }
  return element;
 }

 Element nextVisibleNonShow(View view)
 {
  return nextVisibleNonShow(view, false);
 }

 Element nextVisibleNonShow(View view, boolean wrap)
 {
  Element element = this;
  do
   {
    element = element.nextVisible(view);
   } while (element != null && element.show());

  if (element == null && wrap)
   {
    element = _document.elementList().first();
    if (!element.visible(view) || element.show())
     {
      element = element.nextVisibleNonShow(view, false);
     }
   }
  return element;
 }

 Element nextNonShow()
 {
  Element element = this;
  do
   {
    element = element.next();
   } while (element != null && element.show());

  return element;
 }

 Element prevVisible(View view)
 {
  return prevVisible(view, false);
 }

 Element prevVisible(View view, boolean wrap)
 {
  Element element;
  for (element = prev();
       element != null && !element.visible(view);
       element = element.prev()) {}

  if (element == null && wrap)
   {
    element = _document.elementList().last();
    if (!element.visible(view))
     {
      element = element.prevVisible(view, false);
     }
   }
  return element;
 }

 Element prevVisibleNonShow(View view)
 {
  return prevVisibleNonShow(view, false);
 }

 Element prevVisibleNonShow(View view, boolean wrap)
 {
  Element element = this;
  do
   {
    element = element.prevVisible(view);
   } while (element != null && element.show());

  if (element == null && wrap)
   {
    element = _document.elementList().last();
    if (!element.visible(view) || element.show())
     {
      element = element.prevVisibleNonShow(view, false);
     }
   }
  return element;
 }

 Element prevNonShow()
 {
  Element element = this;
  do
   {
    element = element.prev();
   } while (element != null && element.show());

  return element;
 }

 /**
  * Return element's ElementView for the specified view.
  * If none, first create one and link it in our list.
  */
 ElementView elementView(View view)
 {
  ElementView elementView;
  for (elementView = _firstElementView;
       elementView != null;
       elementView = elementView._next)
   {
    if (elementView.view() == view)
     {
      return elementView;
     }
   }

  elementView = new ElementView(this, view);
  elementView._next = _firstElementView;
  _firstElementView = elementView;
  return elementView;
 }

 void disposeView(View view)
 {
  ElementView prevElementView = null;
  ElementView elementView;
  for (elementView = _firstElementView;
       elementView != null && elementView.view() != view;
       elementView = elementView._next)
   {
    prevElementView = elementView;
   }

  if (elementView != null)
   {
    if (prevElementView == null)
     {
      _firstElementView = elementView._next;
     }
    else
     {
      prevElementView._next = elementView._next;
     }
   }
 }

 boolean tabs()
 {
  return (_flags & TABS) != 0;
 }

 /**
  * Return the currently-set non-show ordinal of the element.
  *
  * @see ElementList#nonShowOrdinalOf(Element)
  */
 int nonShowOrdinal()
 {
  return _nonShowOrdinal;
 }

 void setNonShowOrdinal(int nonShowOrdinal)
 {
  if (nonShowOrdinal != _nonShowOrdinal)
   {
    for (ElementView elementView = _firstElementView;
         elementView != null;
         elementView = elementView._next)
     {
      elementView.setPrefixAreaWidthInvalid();
     }
    _nonShowOrdinal = nonShowOrdinal;
   }
 }

 /**
  * Return the line number inside the (complete) document, as a String padded
  * with leading '0's to n positions.
  * Value of n is usually 6 (for the prefix area text when it's displaying
  * lineNumbers).
  */
 String lineNumberText(int n)
 {
  StringBuffer lineNumberText =
     new StringBuffer(String.valueOf(_nonShowOrdinal + _document.linesBeforeStart()));

  while (lineNumberText.length() < n)
   {
    lineNumberText.insert(0, '0');
   }

  return lineNumberText.toString();
 }

 int sequenceNumber()
 {
  return _sequenceNumber;
 }

 /**
  * Set the numeric part of the sequence numbers of this element.
  *
  * NOTE:  This is a low-level routine, it does NOT send/trigger a
  * document-changed notification;  an appropriate document-changed
  * notification MUST be sent by the higher-level function doing the change.
  *
  * @return true = sequence numbers are in effect, and the sequence number
  *                value for this element has indeed changed
  */
 boolean setSequenceNumber(int sequenceNumber)
 {
  if (sequenceNumber != _sequenceNumber)
   {
    _sequenceNumber = sequenceNumber;

    if (_document.elementList().sequenceNumbersWidth() > 0)
     {
      for (ElementView elementView = _firstElementView;
           elementView != null;
           elementView = elementView._next)
       {
        View view = elementView.view();
        // if sequence numbers displayed, invalidate display text
        if (!view.currentHideSequenceNumbers())
         {
          elementView.resetDisplayText();
         }
        // if prefix area displays sequence numbers, invalidate its width too
        if (PrefixAreaTextParameter.getParameter().currentValue(view) ==
            View.PREFIX_AREA_TEXT_SEQUENCENUMBERS)
         {
          elementView.setPrefixAreaWidthInvalid();
         }
       }
      return true;
     }

   }
  return false;
 }

 /**
  * Return the text part of the element's sequence numbers,
  * or an empty String if none.
  */
 String sequenceText()
 {
  return (_sequenceText == null)? "" : _sequenceText;
 }

 /**
  * Set the sequence-numbers text part.
  *
  * @return true = sequence numbers are in effect, and this element's sequence
  *                text was actually modified
  */
 boolean setSequenceText(String sequenceText)
 //-as- do a void quickSetSequenceText(), when called from ElementList#setSequencenumbers:
 //  without checking for change in seq text, .resetDisplayText(), etc.!?
 {
  int sequenceNumbersTextWidth = _document.elementList().sequenceNumbersTextWidth();
  if (sequenceNumbersTextWidth > 0)
   {
    if (sequenceText == null)
     {
      sequenceText = " ";
     }

    while (sequenceText.length() < sequenceNumbersTextWidth)
     {
      sequenceText += ' ';
     }
    if (sequenceText.length() > sequenceNumbersTextWidth)
     {
      sequenceText = sequenceText.substring(0, sequenceNumbersTextWidth);
     }

    if (!sequenceText.equals(_sequenceText)) //-as- do a faster compare?!
     {
      _sequenceText = sequenceText;
      for (ElementView elementView = _firstElementView;
           elementView != null;
           elementView = elementView._next)
       {
        View view = elementView.view();
        // if sequence numbers displayed, invalidate display text
        if (!view.currentHideSequenceNumbers())
         {
          elementView.resetDisplayText();
         }
        // if prefix area displays sequence numbers, invalidate its width too
        if (PrefixAreaTextParameter.getParameter().currentValue(view) ==
            View.PREFIX_AREA_TEXT_SEQUENCENUMBERS)
         {
          elementView.setPrefixAreaWidthInvalid();
         }
       }
      return true;
     }
   }
  return false;
 }

 /**
  * Dispose of the _sequenceText String.
  *
  * Called from our ElementList.setSequenceNumbers(), when the sequence
  * numbers setting changes from a text part to none.  resetDisplayText
  * (cf. #setSequenceText() above) was already done in a previous operation
  * on the element.
  */
 void disposeSequenceText()
 {
  _sequenceText = null;
 }

 /**
  * Retrieve this element's full text, i.e., including sequence numbers if "on".
  * If no text is set in the element, and no sequence numbers are set, an empty
  * String is returned.
  */
 String fullText()
 {
  return _document.elementList().fullText(this);
 }

 void setDeletePending(boolean deletePending)
 {
  if (deletePending)
   {
    _flags |= DELETE_PENDING;
   }
  else
   {
    _flags &= ~DELETE_PENDING;
   }
 }

 boolean deletePending()
 {
  return (_flags & DELETE_PENDING) != 0;
 }
}