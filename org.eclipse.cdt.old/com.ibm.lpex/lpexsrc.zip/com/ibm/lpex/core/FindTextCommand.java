//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FindTextCommand - handles the findText command & the findText.xxx parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import com.ibm.lpex.util.RegularExpression;
import com.ibm.lpex.util.RegularExpression.PatternException;


/**
 * This class implements the <b>findText</b> command.
 *
 * It searches text inside the document section that is currently loaded in
 * the editor.  It does not trigger a request for extending this document
 * section.  To search inside the complete document, the user should extend this
 * command to first load the complete document in.
 */
final class FindTextCommand
{
 // internal findText.xxx parameter ids
 static final int
  ASIS               =  1,
  BLOCK              =  2,
  COLUMNS            =  3,
  EMPHASIS           =  4,
  END_COLUMN         =  5,
  FIND_TEXT          =  6,
  MARK               =  7,
  REGULAR_EXPRESSION =  8,
  REPLACE_TEXT       =  9,
  START_COLUMN       = 10,
  WRAP               = 11;

 // NB The findtext.xxx parameters must be in alphabetical order for binary search
 private static TableNode[] _parameters =
  {
   new TableNode(LpexConstants.FIND_TEXT_PARAMETER_ASIS,               ASIS),
   new TableNode(LpexConstants.FIND_TEXT_PARAMETER_BLOCK,              BLOCK),
   new TableNode(LpexConstants.FIND_TEXT_PARAMETER_COLUMNS,            COLUMNS),
   new TableNode(LpexConstants.FIND_TEXT_PARAMETER_EMPHASIS,           EMPHASIS),
   new TableNode(LpexConstants.FIND_TEXT_PARAMETER_END_COLUMN,         END_COLUMN),
   new TableNode(LpexConstants.FIND_TEXT_PARAMETER_FIND_TEXT,          FIND_TEXT),
   new TableNode(LpexConstants.FIND_TEXT_PARAMETER_MARK,               MARK),
   new TableNode(LpexConstants.FIND_TEXT_PARAMETER_REGULAR_EXPRESSION, REGULAR_EXPRESSION),
   new TableNode(LpexConstants.FIND_TEXT_PARAMETER_REPLACE_TEXT,       REPLACE_TEXT),
   new TableNode(LpexConstants.FIND_TEXT_PARAMETER_START_COLUMN,       START_COLUMN),
   new TableNode(LpexConstants.FIND_TEXT_PARAMETER_WRAP,               WRAP),
  };


 static Parameter getParameter(String parameter)
 {
  TableNode p = TableNode.binarySearch(_parameters, Parameters.getParameterString(parameter));
  if (p != null)
   {
    switch (p.id())
     {
      case ASIS:
       {
        return asisParameter();
       }
      case BLOCK:
       {
        return blockParameter();
       }
      case COLUMNS:
       {
        return columnsParameter();
       }
      case EMPHASIS:
       {
        return emphasisParameter();
       }
      case END_COLUMN:
       {
        return endColumnParameter();
       }
      case FIND_TEXT:
       {
        return findTextParameter();
       }
      case MARK:
       {
        return markParameter();
       }
      case REGULAR_EXPRESSION:
       {
        return regularExpressionParameter();
       }
      case REPLACE_TEXT:
       {
        return replaceTextParameter();
       }
      case START_COLUMN:
       {
        return startColumnParameter();
       }
      case WRAP:
       {
        return wrapParameter();
       }
      default:
       {
        break;
       }
     }
   }

  return null;
 }


 final static class AsisParameter extends ParameterOnOffDefault
 {
  AsisParameter()
   {
    super(PARAMETER_FIND_TEXT + FIND_TEXT_PARAMETER_ASIS, false);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.findTextCommandSettings()._asis = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.findTextCommandSettings()._asis : Parameter.DEFAULT;
   }
 }

 private static AsisParameter _asisParameter;
 static AsisParameter asisParameter()
 {
  if (_asisParameter == null)
   {
    _asisParameter = new AsisParameter();
   }
  return _asisParameter;
 }


 final static class BlockParameter extends ParameterOnOffDefault
 {
  BlockParameter()
   {
    super(PARAMETER_FIND_TEXT + FIND_TEXT_PARAMETER_BLOCK, false);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.findTextCommandSettings()._block = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.findTextCommandSettings()._block : Parameter.DEFAULT;
   }
 }

 private static BlockParameter _blockParameter;
 static BlockParameter blockParameter()
 {
  if (_blockParameter == null)
   {
    _blockParameter = new BlockParameter();
   }
  return _blockParameter;
 }


 final static class ColumnsParameter extends ParameterOnOffDefault
 {
  ColumnsParameter()
   {
    super(PARAMETER_FIND_TEXT + FIND_TEXT_PARAMETER_COLUMNS, false);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.findTextCommandSettings()._columns = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.findTextCommandSettings()._columns : Parameter.DEFAULT;
   }
 }

 private static ColumnsParameter _columnsParameter;
 static ColumnsParameter columnsParameter()
 {
  if (_columnsParameter == null)
   {
    _columnsParameter = new ColumnsParameter();
   }
  return _columnsParameter;
 }


 final static class EmphasisParameter extends ParameterOnOffDefault
 {
  EmphasisParameter()
   {
    super(PARAMETER_FIND_TEXT + FIND_TEXT_PARAMETER_EMPHASIS, true);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.findTextCommandSettings()._emphasis = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.findTextCommandSettings()._emphasis : Parameter.DEFAULT;
   }
 }

 private static EmphasisParameter _emphasisParameter;
 static EmphasisParameter emphasisParameter()
 {
  if (_emphasisParameter == null)
   {
    _emphasisParameter = new EmphasisParameter();
   }
  return _emphasisParameter;
 }


 final static class EndColumnParameter extends ParameterIntegerDefault
 {
  EndColumnParameter()
   {
    super(PARAMETER_FIND_TEXT + FIND_TEXT_PARAMETER_END_COLUMN, 80);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value, boolean useDefaultValue)
   {
    if (view != null)
     {
      Settings settings = view.findTextCommandSettings();
      settings._endColumn = value;
      settings._useDefaultEndColumn = useDefaultValue;
     }
    return true;
   }

  boolean useDefaultValue(View view)
   {
    return (view != null)? view.findTextCommandSettings()._useDefaultEndColumn : true;
   }

  int value(View view)
   {
    return (view != null)? view.findTextCommandSettings()._endColumn : 0;
   }
 }

 private static EndColumnParameter _endColumnParameter;
 static EndColumnParameter endColumnParameter()
 {
  if (_endColumnParameter == null)
   {
    _endColumnParameter = new EndColumnParameter();
   }
  return _endColumnParameter;
 }


 final static class FindTextParameter extends ParameterStringDefault
 {
  FindTextParameter()
   {
    super(PARAMETER_FIND_TEXT + FIND_TEXT_PARAMETER_FIND_TEXT, null);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, String value)
   {
    if (view != null)
     {
      view.findTextCommandSettings()._findText = value;
     }
    return true;
   }

  String value(View view)
   {
    return (view != null)? view.findTextCommandSettings()._findText : null;
   }
 }

 private static FindTextParameter _findTextParameter;
 static FindTextParameter findTextParameter()
 {
  if (_findTextParameter == null)
   {
    _findTextParameter = new FindTextParameter();
   }
  return _findTextParameter;
 }


 final static class MarkParameter extends ParameterOnOffDefault
 {
  MarkParameter()
   {
    super(PARAMETER_FIND_TEXT + FIND_TEXT_PARAMETER_MARK, false);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.findTextCommandSettings()._mark = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.findTextCommandSettings()._mark : Parameter.DEFAULT;
   }
 }

 private static MarkParameter _markParameter;
 static MarkParameter markParameter()
 {
  if (_markParameter == null)
   {
    _markParameter = new MarkParameter();
   }
  return _markParameter;
 }


 final static class RegularExpressionParameter extends ParameterOnOffDefault
 {
  RegularExpressionParameter()
   {
    super(PARAMETER_FIND_TEXT + FIND_TEXT_PARAMETER_REGULAR_EXPRESSION, false);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.findTextCommandSettings()._regularExpression = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.findTextCommandSettings()._regularExpression : Parameter.DEFAULT;
   }
 }

 private static RegularExpressionParameter _regularExpressionParameter;
 static RegularExpressionParameter regularExpressionParameter()
 {
  if (_regularExpressionParameter == null)
   {
    _regularExpressionParameter = new RegularExpressionParameter();
   }
  return _regularExpressionParameter;
 }


 final static class ReplaceTextParameter extends ParameterStringDefault
 {
  ReplaceTextParameter()
   {
    super(PARAMETER_FIND_TEXT + FIND_TEXT_PARAMETER_REPLACE_TEXT, null);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, String value)
   {
    if (view != null)
     {
      view.findTextCommandSettings()._replaceText = value;
     }
    return true;
   }

  String value(View view)
   {
    return (view != null)? view.findTextCommandSettings()._replaceText : null;
   }
 }

 private static ReplaceTextParameter _replaceTextParameter;
 static ReplaceTextParameter replaceTextParameter()
 {
  if (_replaceTextParameter == null)
   {
    _replaceTextParameter = new ReplaceTextParameter();
   }
  return _replaceTextParameter;
 }


 final static class StartColumnParameter extends ParameterIntegerDefault
 {
  StartColumnParameter()
   {
    super(PARAMETER_FIND_TEXT + FIND_TEXT_PARAMETER_START_COLUMN, 1);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value, boolean useDefaultValue)
   {
    if (view != null)
     {
      Settings settings = view.findTextCommandSettings();
      settings._startColumn = value;
      settings._useDefaultStartColumn = useDefaultValue;
     }
    return true;
   }

  boolean useDefaultValue(View view)
   {
    return (view != null)? view.findTextCommandSettings()._useDefaultStartColumn : true;
   }

  int value(View view)
   {
    return (view != null)? view.findTextCommandSettings()._startColumn : 0;
   }
 }

 private static StartColumnParameter _startColumnParameter;
 static StartColumnParameter startColumnParameter()
 {
  if (_startColumnParameter == null)
   {
    _startColumnParameter = new StartColumnParameter();
   }
  return _startColumnParameter;
 }


 final static class WrapParameter extends ParameterOnOffDefault
 {
  WrapParameter()
   {
    super(PARAMETER_FIND_TEXT + FIND_TEXT_PARAMETER_WRAP, true);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.findTextCommandSettings()._wrap = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.findTextCommandSettings()._wrap : Parameter.DEFAULT;
   }
 }

 private static WrapParameter _wrapParameter;
 static WrapParameter wrapParameter()
 {
  if (_wrapParameter == null)
   {
    _wrapParameter = new WrapParameter();
   }
  return _wrapParameter;
 }

 static boolean doCommand(View view, String parameters)
  {
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   FindTextOptions options = new FindTextOptions();
   boolean useFindTextSettings = true;
   boolean regularExpression = false;

   while (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("up"))
      {
       options._up = true;
      }
     else if (token.equals("checkStart"))
      {
       options._checkStart = true;
      }
     else if (token.equals("replace"))
      {
       options._replace = true;
      }
     else if (token.equals("exclude"))
      {
       options._exclude = true;
      }
     else if (token.equals("all"))
      {
       options._all = true;
      }
     else if (token.equals("quiet"))
      {
       options._quiet = true;
      }
     else if (token.equals("noBeep"))
      {
       options._noBeep = true;
      }

     else if (token.equals("mark"))
      {
       options._mark = true;
       useFindTextSettings = false;
      }
     else if (token.equals("columns"))
      {
       options._columns = true;
       if (st.hasMoreTokens())
        {
         token = st.nextToken();
         try
          {
           options._startColumn = Integer.parseInt(token);
          }
         catch(NumberFormatException e)
          {
           return CommandHandler.invalidParameter(view, token, "findText");
          }

         if (st.hasMoreTokens())
          {
           token = st.nextToken();
           try
            {
             options._endColumn = Integer.parseInt(token);
            }
           catch(NumberFormatException e)
            {
             return CommandHandler.invalidParameter(view, token, "findText");
            }
          }
         else
          {
           return columnsMissing(view);
          }
        }
       else
        {
         return columnsMissing(view);
        }
       useFindTextSettings = false;
      }
     else if (token.equals("block"))
      {
       options._block = true;
       useFindTextSettings = false;
      }
     else if (token.equals("noWrap"))
      {
       options._wrap = false;
       useFindTextSettings = false;
      }
     else if (token.equals("asis"))
      {
       options._asis = true;
       useFindTextSettings = false;
      }
     else if (token.equals("noEmphasis"))
      {
       options._emphasis = false;
       useFindTextSettings = false;
      }
     else if (token.equals("regularExpression"))
      {
       regularExpression = true;
       useFindTextSettings = false;
      }
     else if (token.equals("replaceWith"))
      {
       options._replace = true;
       options._replaceText = "";
       if (st.hasMoreTokens())
        {
         token = st.nextToken();
         if (LpexStringTokenizer.isInvalidQuotedString(token))
          {
           return CommandHandler.invalidQuotedParameter(view, token, "findText");
          }
         options._replaceText = LpexStringTokenizer.removeQuotes(token);
        }
       useFindTextSettings = false;
      }
     else // the text to find
      {
       if (LpexStringTokenizer.isInvalidQuotedString(token))
        {
         return CommandHandler.invalidQuotedParameter(view, token, "findText");
        }
       options._findText = LpexStringTokenizer.removeQuotes(token);
       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "findText");
        }
       useFindTextSettings = false;
       break;
      }
    }

   // if no findText-command parameters from the 2nd group,
   // use the current.findText.xxx parameters
   if (useFindTextSettings)
    {
     options._mark        = markParameter().currentValue(view);
     options._columns     = columnsParameter().currentValue(view);
     options._startColumn = startColumnParameter().currentValue(view);
     options._endColumn   = endColumnParameter().currentValue(view);
     options._block       = blockParameter().currentValue(view);
     options._wrap        = wrapParameter().currentValue(view);
     options._asis        = asisParameter().currentValue(view);
     options._emphasis    = emphasisParameter().currentValue(view);
     regularExpression    = regularExpressionParameter().currentValue(view);
     options._replaceText = replaceTextParameter().currentValue(view);
     options._findText    = findTextParameter().currentValue(view);
    }

   if (options._findText == null || options._findText.length() == 0)
    {
     if (view != null)
      {
       view.setLpexMessageText(LpexConstants.MSG_FINDTEXTCOMMAND_NOFINDTEXT);
      }
     return useFindTextSettings;
    }

   if (!options._asis && !regularExpression)
    {
     options._findText = options._findText.toUpperCase();
    }
   else if (regularExpression)
    {
     try
      {
       options._regularExpression = new RegularExpression(options._findText, !options._asis);
      }
     catch (PatternException e)
      {
       if (!options._quiet)
        {
         if (view != null)
          {
           view.setLpexMessageText(LpexConstants.MSG_FINDTEXTCOMMAND_INVALIDPATTERN,
                                   options._findText);
           if (!options._noBeep)
            {
             BeepParameter.getParameter().setValue(true);
            }
          }
        }
       CommandHandler._status = LpexConstants.STATUS_FINDTEXT_INVALIDPATTERN;
       return true;
      }
    }

   if (view != null)
    {
     CommandHandler._status = null;
     view.findText(options);
    }

   return true;
  }

 static private boolean columnsMissing(View view)
  {
   if (view != null)
    {
     view.setLpexMessageText(LpexConstants.MSG_FINDTEXTCOMMAND_COLUMNSMISSING);
    }
   return false;
  }


 /**
  * The settings of the <b>findText.xxx</b> parameters for a document view.
  * There is up to one instance of this class for every View.
  */
 final static class Settings
 {
  int     _asis = Parameter.DEFAULT;
  int     _block = Parameter.DEFAULT;
  int     _columns = Parameter.DEFAULT;
  int     _emphasis = Parameter.DEFAULT;
  int     _endColumn;
  boolean _useDefaultEndColumn = true;
  String  _findText;
  int     _mark = Parameter.DEFAULT;
  int     _regularExpression = Parameter.DEFAULT;
  String  _replaceText;
  int     _startColumn;
  boolean _useDefaultStartColumn = true;
  int     _wrap = Parameter.DEFAULT;
 }
}