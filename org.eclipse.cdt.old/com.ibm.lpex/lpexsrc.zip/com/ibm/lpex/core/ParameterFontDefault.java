//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterFontDefault - base abstract class for font parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Base, abstract class for font parameters.
 */
abstract class ParameterFontDefault extends ParameterDefault
{
 protected Font    _hardCodedValue;
 protected Font    _installValue;
 protected boolean _installValueLoaded;
 protected Font    _defaultValue;
 protected boolean _defaultValueLoaded;

 // development platform (JDK AWT/Swing or Eclipse SWT) sensitive stuff
 private String _PARM_INSTALL;
 private String _PARM_DEFAULT;
 private String _PARM_DEFAULT_FONT_DATA;          // on SWT only
 private String QUALIFIER_FONT_DATA = "fontData"; // on SWT only


 /**
  * Constructor.
  */
 ParameterFontDefault(String name, Font hardCodedValue)
  {
   super(name);

   // on SWT, we use install.swt.font and default.swt.font
   if (LpexUtilities.getPlatform() == PLATFORM_SWT)
    {
     _PARM_INSTALL = PARAMETER_INSTALL + PLATFORM_SWT_KEY + name();
     _PARM_DEFAULT = PARAMETER_DEFAULT + PLATFORM_SWT_KEY + name();
     _PARM_DEFAULT_FONT_DATA = _PARM_DEFAULT + ".fontData";
    }
   else
    {
     _PARM_INSTALL = PARAMETER_INSTALL + name();
     _PARM_DEFAULT = PARAMETER_DEFAULT + name();
    }

   _hardCodedValue = hardCodedValue;
   Install.addProfileChangedListener(new Install.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _installValueLoaded = false;
       if (defaultValue() == null)
        {
         for (Document document = Document._firstDocument;
              document != null;
              document = document._next)
          {
           for (View view = document._firstView; view != null; view = view._next)
            {
             if (value(view) == null)
              {
               currentValueChanged(view);
              }
            }
          }
        }
      }
    });

   Profile.addProfileChangedListener(new Profile.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _defaultValueLoaded = false;
       for (Document document = Document._firstDocument;
            document != null;
            document = document._next)
        {
         for (View view = document._firstView; view != null; view = view._next)
          {
           if (value(view) == null)
            {
             currentValueChanged(view);
            }
          }
        }
      }
    });
  }

 Font installValue()
  {
   if (!_installValueLoaded)
    {
     String value = Install.getString(_PARM_INSTALL);
     _installValue = (value == null)? _hardCodedValue :
                                      Font.decodeFont(LpexStringTokenizer.removeQuotes(value));
     _installValueLoaded = true;
    }

   return _installValue;
  }

 protected void loadDefaultValue()
  {
   if (!_defaultValueLoaded)
    {
     String value = null;

     // SWT: see first if "default.swt.font.fontdata" was stored
     if (LpexUtilities.getPlatform() == PLATFORM_SWT)
      {
       value = Profile.getString(_PARM_DEFAULT_FONT_DATA);
       if (value != null)
        {
         _defaultValue = Font.decodeFontData(LpexStringTokenizer.removeQuotes(value));
        }
      }

     if (value == null)
      {
       value = Profile.getString(_PARM_DEFAULT);
       _defaultValue = (value == null)? null :
                                      Font.decodeFont(LpexStringTokenizer.removeQuotes(value));
      }

     _defaultValueLoaded = true;
    }
  }

 Font defaultValue()
  {
   loadDefaultValue();
   return _defaultValue;
  }

 boolean setDefaultValue(Font value)
  {
   _defaultValue = value;
   _defaultValueLoaded = true;
   if (_defaultValue != null)
    {
     Profile.putString(_PARM_DEFAULT,
                       LpexStringTokenizer.addQuotes(Font.nameString(_defaultValue)));
     if (LpexUtilities.getPlatform() == PLATFORM_SWT)
      {
       Profile.putString(_PARM_DEFAULT_FONT_DATA,
                       LpexStringTokenizer.addQuotes(Font.fontDataString(_defaultValue)));
      }
    }
   else
    {
     Profile.remove(_PARM_DEFAULT);
     if (LpexUtilities.getPlatform() == PLATFORM_SWT)
      {
       Profile.remove(_PARM_DEFAULT_FONT_DATA);
      }
    }

   for (Document document = Document._firstDocument;
        document != null;
        document = document._next)
    {
     for (View view = document._firstView; view != null; view = view._next)
      {
       if (value(view) == null)
        {
         currentValueChanged(view);
        }
      }
    }

   return true;
  }

 Font currentValue(View view)
  {
   Font value = value(view);
   if (value == null)
    {
     value = defaultValue();
     if (value == null)
      {
       value = installValue();
      }
    }

   return value;
  }

 boolean set(View view, String qualifier, String parameters)
  {
   Font value = null;
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (!token.equals("default"))
      {
       if (LpexStringTokenizer.isInvalidQuotedString(token))
        {
         return CommandHandler.invalidQuotedParameter(view, token, "set " + name());
        }

       token = LpexStringTokenizer.removeQuotes(token);
       if (QUALIFIER_FONT_DATA.equals(qualifier))
        {
         value = Font.decodeFontData(token);
        }
       else
        {
         value = Font.decodeFont(token);
        }
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name());
      }
    }

   return setValue(view, value);
  }

 abstract boolean setValue(View view, Font value);

 boolean setDefault(View view, String qualifier, String parameters)
  {
   Font value = null;
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (!token.equals("install"))
      {
       if (LpexStringTokenizer.isInvalidQuotedString(token))
        {
         return CommandHandler.invalidQuotedParameter(view, token,
                                                      "set " + PARAMETER_DEFAULT + name());
        }

       token = LpexStringTokenizer.removeQuotes(token);
       if (QUALIFIER_FONT_DATA.equals(qualifier))
        {
         value = Font.decodeFontData(token);
        }
       else
        {
         value = Font.decodeFont(token);
        }
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(),
                                              "set " + PARAMETER_DEFAULT + name());
      }
    }

   return setDefaultValue(value);
  }

 void currentValueChanged(View view) {}

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   if (view != null)
    {
     Font value = value(view);

     if (qualifier != null)
      {
       if (qualifier.equals(QUALIFIER_FONT_DATA))
        {
         if (value == null)
          {
           return queryDefault(qualifier);
          }
         return LpexStringTokenizer.addQuotes(Font.fontDataString(value));
        }
       return null;
      }

     return (value == null)? "default" : LpexStringTokenizer.addQuotes(Font.nameString(value));
    }

   return null;
  }

 abstract Font value(View view);

 String queryInstall(String qualifier)
  {
   Font value = installValue();

   if (qualifier != null)
    {
     if (qualifier.equals(QUALIFIER_FONT_DATA))
      {
       return LpexStringTokenizer.addQuotes(Font.fontDataString(value));
      }
     return null;
    }

   return LpexStringTokenizer.addQuotes(Font.nameString(value));
  }

 String queryDefault(String qualifier)
  {
   Font value = defaultValue();

   if (qualifier != null)
    {
     if (qualifier.equals(QUALIFIER_FONT_DATA))
      {
       if (value == null)
        {
         return queryInstall(qualifier);
        }
       return LpexStringTokenizer.addQuotes(Font.fontDataString(value));
      }
     return null;
    }

   return (value == null)? "install" : LpexStringTokenizer.addQuotes(Font.nameString(value));
  }

 String queryCurrent(View view, String qualifier)
  {
   Font value = currentValue(view);

   if (qualifier != null)
    {
     if (qualifier.equals(QUALIFIER_FONT_DATA))
      {
       return LpexStringTokenizer.addQuotes(Font.fontDataString(value));
      }
     return null;
    }

   return LpexStringTokenizer.addQuotes(Font.nameString(value));
  }
}