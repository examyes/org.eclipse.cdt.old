//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SequenceNumbersFormat - the sequenceNumbersFormat parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * SourceNumbersFormatParameter handles the sequenceNumbersFormat editor
 * parameter.
 * The Parameter <- ParameterDefault <- ParameterWordDefault class it extends
 * provides the framework for handling word (string) parameters with install
 * and default values (commands SET and QUERY [install. | default. | current.],
 * etc.).
 */
final class SequenceNumbersFormatParameter extends ParameterWordDefault
{
   /**
    * Singleton SequenceNumbersFormatParameter handles (by occasionally
    * delegating to View) the sequenceNumbersFormat for all the views
    * (note that all its methods have a View argument passed in).
    *
    * The parameter value of a view's sequenceNumbersFormat is stored
    * in the view (_sequenceNumbersFormatParm).
    */
   private static SequenceNumbersFormatParameter _parameter;

   static  SequenceNumbersFormatParameter getParameter()
   {
      if (_parameter == null)
         _parameter = new SequenceNumbersFormatParameter();
      return _parameter;
   }

   /**
    * Private constructor - SequenceNumbersFormatParameter
    * is not created directly, but via a first call to
    * SequenceNumbersFormatParameter.getParameter().
    */
   private SequenceNumbersFormatParameter()
   {
      // construct a Parameter.WordDefault with the _name
      // PARAMETER_SEQUENCE_NUMBERS_FORMAT, and a _hardCodedValue null
      super(PARAMETER_SEQUENCE_NUMBERS_FORMAT, null);
   }

   /**
    * Override ParameterWordDefault's, to accept blanks in the value string.
    */
   boolean set(View view, String qualifier, String parameters)
   {
    String value = "null";
    if (parameters.length() > 0)
     {
      value = parameters.equals("default")? null : parameters;
     }

    // when command is:      value here is:
    // SET <param>           "null"
    // SET <param> default   null
    // SET <param> xx yy     "xx yy"
    return setValue(view, value);
   }

   /**
    * Set the sequenceNumbersFormat parameter for this view.
    *
    * @param value null / "null" = default to the install format string,
    *              "install" = set to the install format text,
    *              else = a specific sequence-numbers format string
    */
   boolean setValue(View view, String value)
   {
      if (view != null) {
         view._sequenceNumbersFormatParm = value;
         currentValueChanged(view); // assume change from previous value...
         }
      return true;
   }

   /**
    * Override ParameterWordDefault's, to accept blanks in the value string.
    */
   boolean setDefault(View view, String qualifier, String parameters)
   {
    String value = "null";
    if (parameters.length() > 0)
     {
      value = parameters.equals("install")? null : parameters;
     }

    // when command is:              value here is:
    // SET default.<param>           "null"
    // SET default.<param> install   null
    // SET default.<param> xx yy     "xx yy"
    return setDefaultValue(value);
   }

   /**
    * Handle the notification of a change in the actual sequence numbers
    * display format for the view, by further notifying the view.
    *
    * Called by ParameterWordDefault when the default. value of the parameter
    * changes.  We call it ourselves in here when the value of the parameter
    * is (presumably) changed.
    */
   void    currentValueChanged(View view)
   {
      view.sequenceNumbersFormatChanged();
   }

   /**
    * Retrieve the view's sequenceNumbersFormat parameter value.
    *
    * @return <code>null</code> when the current setting is DEFAULT,
    *         or else a specific display format text
    */
   String  value(View view)
   {
      return (view != null)? view._sequenceNumbersFormatParm : null;
   }
}