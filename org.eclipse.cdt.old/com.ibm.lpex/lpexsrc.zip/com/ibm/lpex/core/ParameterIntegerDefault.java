//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterIntegerDefault - base class for integer parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Base, abstract class for integer parameters with install, default, and
 * current settings.
 */
abstract class ParameterIntegerDefault extends ParameterDefault
{
 private int     _hardCodedValue;
 private int     _installValue;
 private boolean _installValueLoaded;
 private int     _defaultValue;
 private boolean _useInstallValue;
 private boolean _defaultValueLoaded;


 ParameterIntegerDefault(String name, int hardCodedValue)
  {
   super(name);
   _hardCodedValue = hardCodedValue;
   Install.addProfileChangedListener(new Install.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _installValueLoaded = false;
       if (useInstallValue())
        {
         for (Document document = Document._firstDocument;
              document != null;
              document = document._next)
          {
           for (View view = document._firstView; view != null; view = view._next)
            {
             if (useDefaultValue(view))
              {
               currentValueChanged(view);
              }
            }
          }
        }
      }
    });

   Profile.addProfileChangedListener(new Profile.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _defaultValueLoaded = false;
       for (Document document = Document._firstDocument;
            document != null;
            document = document._next)
        {
         for (View view = document._firstView; view != null; view = view._next)
          {
           if (useDefaultValue(view))
            {
             currentValueChanged(view);
            }
          }
        }
      }
    });
  }

 int installValue()
  {
   if (!_installValueLoaded)
    {
     _installValue = Install.getInteger(PARAMETER_INSTALL + name(), _hardCodedValue);
     _installValueLoaded = true;
    }

   return _installValue;
  }

 private void loadDefaultValue()
  {
   if (!_defaultValueLoaded)
    {
     String value = Profile.getString(PARAMETER_DEFAULT + name());
     if (value != null)
      {
       try
        {
         _defaultValue = Integer.parseInt(value);
         _useInstallValue = false;
        }
       catch(NumberFormatException e)
        {
         _useInstallValue = true;
        }
      }
     else
      {
       _useInstallValue = true;
      }

     _defaultValueLoaded = true;
    }
  }

 boolean useInstallValue()
  {
   loadDefaultValue();
   return _useInstallValue;
  }

 int defaultValue()
  {
   loadDefaultValue();
   return _defaultValue;
  }

 boolean setDefaultValue(int value, boolean useInstallValue)
  {
   _defaultValue = value;
   _useInstallValue = useInstallValue;
   _defaultValueLoaded = true;
   if (!_useInstallValue)
    {
     Profile.putInteger(PARAMETER_DEFAULT + name(), _defaultValue);
    }
   else
    {
     Profile.remove(PARAMETER_DEFAULT + name());
    }

   for (Document document = Document._firstDocument;
        document != null;
        document = document._next)
    {
     for (View view = document._firstView; view != null; view = view._next)
      {
       if (useDefaultValue(view))
        {
         currentValueChanged(view);
        }
      }
    }

   return true;
  }

 int currentValue(View view)
  {
   if (useDefaultValue(view))
    {
     return useInstallValue()? installValue() : defaultValue();
    }

   return value(view);
  }

 boolean set(View view, String qualifier, String parameters)
  {
   boolean useDefaultValue = true;
   int value = 0;
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("default"))
      {
       useDefaultValue = true;
      }
     else
      {
       useDefaultValue = false;
       try
        {
         value = Integer.parseInt(token);
        }
       catch(NumberFormatException e)
        {
         return CommandHandler.invalidParameter(view, token, "set " + name());
        }
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name());
      }
    }

   return setValue(view, value, useDefaultValue);
  }

 abstract boolean setValue(View view, int value, boolean useDefaultValue);

 boolean setDefault(View view, String qualifier, String parameters)
  {
   boolean useInstallValue = true;
   int value = 0;
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("install"))
      {
       useInstallValue = true;
      }
     else
      {
       useInstallValue = false;
       try
        {
         value = Integer.parseInt(token);
        }
       catch(NumberFormatException e)
        {
         return CommandHandler.invalidParameter(view, token,
                                                "set " + PARAMETER_DEFAULT + name());
        }
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(),
                                              "set " + PARAMETER_DEFAULT + name());
      }
    }

   return setDefaultValue(value, useInstallValue);
  }

 void currentValueChanged(View view) {}

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   if (view != null)
    {
     return useDefaultValue(view)? "default" : String.valueOf(value(view));
    }

   return null;
  }

 abstract boolean useDefaultValue(View view);

 abstract int value(View view);

 String queryInstall(String qualifier)
  {
   return String.valueOf(installValue());
  }

 String queryDefault(String qualifier)
  {
   return useInstallValue()? "install" : String.valueOf(defaultValue());
  }

 String queryCurrent(View view, String qualifier)
  {
   return String.valueOf(currentValue(view));
  }
}