//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// HideSequenceNumbersParameter - handles the hideSequenceNumbers parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>hideSequenceNumbers</b> parameter.
 */
final class HideSequenceNumbersParameter extends ParameterOnOffDefault
{
 private static HideSequenceNumbersParameter _parameter;

 static HideSequenceNumbersParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new HideSequenceNumbersParameter();
   }
  return _parameter;
 }

 private HideSequenceNumbersParameter()
 {
  super(PARAMETER_HIDE_SEQUENCE_NUMBERS, false);
 }

 boolean setValue(View view, int value)
 {
  if (view != null)
   {
    view.setHideSequenceNumbers(value);
   }
  return true;
 }

 void currentValueChanged(View view)
 {
  view.hideSequenceNumbersChanged();
 }

 int value(View view)
 {
  return (view != null)? view.hideSequenceNumbers() : Parameter.DEFAULT;
 }
}