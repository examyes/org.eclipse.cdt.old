//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexViewListener - defines a listener to document view events.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Interface LpexViewListener can be implemented to listen to document view
 * events.
 *
 * <p>You may implement this interface to create a document view listener.
 * Create a listener object using this class, and then register it with a
 * document view using the view's <code>addLpexViewListener()</code> method.
 * When an event occurs, the relevant method in the listener object is invoked.
 *
 * <p>It is recommended that you use the <code>LpexViewAdapter</code> class
 * to create your document view listener.
 *
 * @see com.ibm.lpex.core.LpexView#addLpexViewListener
 * @see com.ibm.lpex.core.LpexView#removeLpexViewListener
 * @see com.ibm.lpex.core.LpexViewAdapter
 */
public interface LpexViewListener
{
 /**
  * This method is invoked just before the screen is displayed.
  * The screen is rebuilt and displayed after every user action.  It is
  * also rebuilt and displayed when the <b>screenShow</b> editor command
  * is issued.
  *
  * @see #shown
  */
 public void showing(LpexView lpexView);

 /**
  * This method is invoked after the screen display is complete.
  *
  * @see #showing
  */
 public void shown(LpexView lpexView);

 /**
  * This method is invoked just before the document is saved.
  * If you return <code>true</code>, then the remaining listeners
  * will not be invoked and the save will be aborted.
  *
  * @see #saved
  */
 public boolean saving(LpexView lpexView);

 /**
  * This method is invoked after the document has been saved.
  *
  * @see #saving
  */
 public void saved(LpexView lpexView);

 /**
  * This method is invoked just before the document rename occurs.
  * If you return <code>true</code>, then the remaining listeners
  * will not be invoked and the rename will be aborted.
  *
  * @see #renamed
  */
 public boolean renaming(LpexView lpexView);

 /**
  * This method is invoked after the document has been renamed.
  *
  * @see #renaming
  */
 public void renamed(LpexView lpexView);

 /**
  * This method is invoked after an attempt has been made to edit a
  * readonly document.
  */
 public void readonly(LpexView lpexView);

 /**
  * This method is invoked after the <b>updateProfile</b> editor command
  * has completed processing.
  */
 public void updateProfile(LpexView lpexView);

 /**
  * This method is invoked when the document view is disposed.
  */
 public void disposed(LpexView lpexView);
}