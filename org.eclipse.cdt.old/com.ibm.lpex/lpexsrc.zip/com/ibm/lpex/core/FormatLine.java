//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FormatLine - format line (horizontal ruler).
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;


/**
 * This class manages the format line area of an LPEX window.
 * There is one instance of this class per instance of LpexWindow.
 *
 * Note that all the calculations herein assume that a fixed-pitch font is
 * being used.
 */
final class FormatLine extends Composite
{
   private boolean    _formatValid;          // current format line up-to-date?
   private String     _text;                 // formatLineText
   private String     _displayText;          //  & cached display text
   private int        _column;               // cursor display column
   private int        _columnX;              //  (inside format line, in pixels)
   private int        _width;                // format line's width
   private Font       _font;                 //  & font
   private TextFontMetrics _textFontMetrics;
   private int        _spaceWidth = 1;       //  (ensure can divide if not set!)
   private StyleAttributes _styleAttributes; //  & style
   private int        _scroll;               // text view's scroll (pixels)
   private int        _margin;               //  & no-text (hide + prefix) area
   private int        _horizontalTrim;       //  & trim to text in TextWindow
   private int        _sequenceNumbersWidth;
   private boolean    _hideSequenceNumbers;
   private int        _sequenceNumbersFormattedWidth;


   /**
    * Construct the format line for an LpexWindow.
    */
   FormatLine(LpexWindow lpexWindow)
   {
      super(lpexWindow, SWT.NO_BACKGROUND | SWT.NO_FOCUS); // shouldn't get focus

      _horizontalTrim = -lpexWindow.textWindow().computeTrim(0,0,0,0).x;

      addPaintListener(new PaintListener() {
         public void paintControl(PaintEvent e) {
            paintComponent(e.gc);
            }
         });

      //validate();
   }

   /**
    * Return preferred size of the component.
    */
   public Point computeSize(int wHint, int hHint, boolean changed)
   {
      int height = 0;
      int width = 0;
      if (_textFontMetrics != null) {
         width  = _spaceWidth;               // one char is good enough...
         height = _textFontMetrics.textHeight() + 1;
         }
      return new Point(width, height);
   }

   /**
    * Do some painting.
    */
   private void paintComponent(GC g)
   {
      if (_styleAttributes != null) {
         /*============================*/
         /*  clear entire format line  */
         /*============================*/
         g.setBackground(_styleAttributes.backgroundColor().getColor());
         Point size = getSize();
         if (_width != size.x) {
            _width = size.x;
            _formatValid = false; // must redo _displayText
            }
         g.fillRectangle(0, 0, _width, size.y);

         /*=================*/
         /*  draw the text  */
         /*=================*/
         // swt: see setFont(), we've already set our font for the entire
         // Control, so paintComponent()'s GC comes ready set to it...
         // g.setFont(_font.getFont());
         g.setForeground(_styleAttributes.foregroundColor().getColor());

         // no format line in the left margin, where text doesn't show
    /**/ g.setClipping(_margin+_horizontalTrim, 0, _width - (_margin+_horizontalTrim), size.y);

         // draw the shortest string we can get away with
         int firstCol = _scroll / _spaceWidth;                  // ZERO-based
         int firstTextCol = firstCol;                           // ZERO-based
         int x = _margin+_horizontalTrim - _scroll % _spaceWidth;

         // if scrolled & sequence-numbers area is [partially] inside the scroll,
         // adjust the first column number (i.e., offset into ruler text)
         if (firstTextCol > 0 &&
             _sequenceNumbersWidth != 0 &&
             !_hideSequenceNumbers &&
             _sequenceNumbersFormattedWidth != 0) {
            if (firstTextCol <= _sequenceNumbersFormattedWidth)
               firstTextCol = 0;
            else
               firstTextCol -= _sequenceNumbersFormattedWidth;
            }

         if (!_formatValid) {
            String t;
            if (_text == null || _text.length() == 0)
               t = ruler(firstTextCol, firstTextCol + _width/_spaceWidth + 1);
            else
               t = (firstTextCol < _text.length())? _text.substring(firstTextCol) : "";

            /*---------------------------------------------------*/
            /*  adjust text to ignore the sequence-numbers area  */
            /*---------------------------------------------------*/
            if (_sequenceNumbersWidth != 0 &&
                !_hideSequenceNumbers &&
                _sequenceNumbersFormattedWidth != 0) {
               int col1 = firstCol + 1;                         // ONE-based
               if (col1 <= _sequenceNumbersFormattedWidth) {
                  // insert blanks for the sequence-numbers area
                  StringBuffer t2 = new StringBuffer(t);
                  int blanksToInsert = _sequenceNumbersFormattedWidth;
                  if (col1 > 1)
                     blanksToInsert -= col1 - 1;
                  for (int i = 0; i < blanksToInsert; i++)
                     t2.insert(0, ' ');
                  t = t2.toString();
                  }
               }
            _displayText = t;
            }

         g.drawString(_displayText, x, 0 /*awt: _textFontMetrics.maxAscent()*/,
                      true); // already filled background, draw transparently

         /*===================*/
         /*  draw the cursor  */
         /*===================*/
         if (_column > 0) {                      // if there is a visible cursor
            int col = _column - firstCol - 1;    // offset into displayed string
            g.setBackground(_styleAttributes.foregroundColor().getColor());
            x += col * _spaceWidth;
            g.fillRectangle(x, 0, _spaceWidth, size.y);

            g.setForeground(_styleAttributes.backgroundColor().getColor());
            // ensure col >= 0 into _displayText, in case we're using a non-fixed
            // font and our calculations are a bit out-of-sync with reality...
            char c = (col < 0 || col >= _displayText.length())? ' ' : _displayText.charAt(col);
            g.drawString(String.valueOf(c), x, 0 /*awt: _textFontMetrics.maxAscent()*/,
                         true); // already filled background, draw transparently
            _columnX = x;
            }

    /**/ //g.setClipping(null);
         }

      _formatValid = true;
   }

   /**
    * Return the default format line text to draw.
    *
    * @param firstCol ZERO-based first column to display
    * @param lastCol  last column number to display
    */
   private static String ruler(int firstCol, int lastCol)
   {
      if (firstCol == 0 && lastCol <= 110)
         return "----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8----+----9----+---10----+---11-";

      StringBuffer t = new StringBuffer(112);  // typical window of ~100 columns
      int firstNumber = firstCol + 1;
      int indent = firstCol % 10;              // anything prior to 10-column segments?
      if (indent != 0) {
         t.append(tenRulerColumns(firstNumber - indent).substring(indent));
         firstNumber += 10 - indent;
         }
      for (int i = firstNumber; i <= lastCol; i += 10) { // add up segments
         t.append(tenRulerColumns(i));
         }
      return t.toString();
   }

   /**
    * Create a 10-column segment for the ruler.
    *
    * @param beginCol first column in the segment (1 / 11 / 21 / etc.).
    */
   private static String tenRulerColumns(int beginCol)
   {
      if (beginCol < 91)
         return "----+----" + (beginCol/10+1);
      if (beginCol < 991)
         return "----+---"  + (beginCol/10+1);

      StringBuffer st = new StringBuffer(Integer.toString(beginCol/10+1));
      if (st.length() > 5)
         return "--" + st.toString().substring(0, 5) + "...";

      for (int i = 10 - st.length(); i > 0; i--)
         st.insert(0, (i == 5)? '+' : '-');
      return st.toString();
   }

   /**
    * Update format line's cursor display-column.
    */
   void setColumn(int column)
   {
      if (_column != column) {
         // if not redrawing entire format line, invalidate old+new cursors only
         if (_formatValid && getSize().y != 0) {
            Rectangle r = new Rectangle(_columnX, 0,
                                        _spaceWidth, getSize().y);
            redraw(r.x, r.y, r.width, r.height, false);

            _columnX += (column - _column) * _spaceWidth;
            r.x = _columnX;
            redraw(r.x, r.y, r.width, r.height, false);
            }
         else {
            _formatValid = false;
            }
         _column = column;
         }
   }

   /**
    * Set format line's font.
    *
    * @return <code>true</code> current format-line font changed
    */
   boolean setFont(Font font, TextFontMetrics textFontMetrics)
   {
      if (_font == null || !_font.equals(font)) {
         _font = font;
         _textFontMetrics = textFontMetrics;

         // swt: set font as the Control's, so paintComponent()'s GC comes
         // ready set to it and we don't have to re-set it
         setFont(_font.getFont());

         _spaceWidth = _textFontMetrics.spaceWidth();
         _formatValid = false;
         return true;
         }
      return false;
   }

   /**
    * Inform format line of editing area's left margin (expand/hide + prefix
    * areas), where there is no text.
    *
    * @param margin in pixels
    */
   void setMargin(int margin)
   {
      if (_margin != margin) {
         _margin = margin;
         _formatValid = false;
         }
   }

   /**
    * Our Screen tells us we're showing soon:  establish whether our cached
    * values are still valid (some were already handled by methods above),
    * or we must be updated.
    */
   void showing(View view)
   {
      // format line's text
      Screen screen = view.screen();
      String text = screen.formatLineText();
      if (_text == null && text == null)
         {}                                     // still the default format line
      else if (_text == null || text == null || !_text.equals(text)) {
         _text = text;
         _formatValid = false;
         }

      // view text's scroll factor
      int scroll = screen.scroll();
      if (_scroll != scroll) {
         _scroll = scroll;
         _formatValid = false;
         }

      // format line's style attributes
      StyleAttributes styleAttributes = screen.styleAttributes(Screen.STYLE_FORMAT_LINE);
      if (_styleAttributes == null || !(_styleAttributes.equals(styleAttributes))) {
         _styleAttributes = styleAttributes;
         _formatValid = false;
         }

      ElementList elementList = view.document().elementList();
      int sequenceNumbersWidth = elementList.sequenceNumbersWidth();
      if (_sequenceNumbersWidth != sequenceNumbersWidth) {
         _sequenceNumbersWidth = sequenceNumbersWidth;
         _formatValid = false;
         }

      if (_sequenceNumbersWidth != 0) {
         boolean hideSequenceNumbers = view.currentHideSequenceNumbers();
         if (_hideSequenceNumbers != hideSequenceNumbers) {
            _hideSequenceNumbers = hideSequenceNumbers;
            _formatValid = false;
            }

         if (!_hideSequenceNumbers) {
            int sequenceNumbersFormattedWidth = view.getSequenceNumbersStyle().length();
            if (_sequenceNumbersFormattedWidth != sequenceNumbersFormattedWidth) {
               _sequenceNumbersFormattedWidth = sequenceNumbersFormattedWidth;
               _formatValid = false;
               }
            }
         }
   }

   /**
    * Refresh the format line:  repaint if not up-to-date.
    */
   void updateFormat()
   {
      if (!_formatValid && getSize().y != 0)
         redraw(); // invalidate entire format line (if it isShowing)
   }
}