//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DirtyParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class DirtyParameter extends ParameterOnOffQuery
{
 private static DirtyParameter _parameter;

 static DirtyParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new DirtyParameter();
   }
  return _parameter;
 }

 private DirtyParameter()
 {
  super(PARAMETER_DIRTY);
 }

 boolean value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.document().undo().dirty() : false;
 }
}