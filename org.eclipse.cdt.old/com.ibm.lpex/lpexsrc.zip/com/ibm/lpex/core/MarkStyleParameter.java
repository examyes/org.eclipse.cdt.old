//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// MarkStyleParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class MarkStyleParameter extends ParameterCharacterOnly
{
 private static MarkStyleParameter _parameter;

 static MarkStyleParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new MarkStyleParameter();
   }
  return _parameter;
 }

 private MarkStyleParameter()
 {
  super(PARAMETER_MARK_STYLE);
 }

 boolean setValue(View view, String qualifier, char value)
 {
  if (view != null)
   {
    MarkList.Mark mark = view.markList().find(qualifier);
    if (mark != null)
     {
      mark.setStyleCharacter(value);
     }
   }

  return true;
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return view != null && view.markList().find(qualifier) != null;
 }

 char value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    MarkList.Mark mark = view.markList().find(qualifier);
    if (mark != null)
     {
      return mark.styleCharacter();
     }
   }

  return '!';
 }
}