//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// VisibleParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class VisibleParameter extends ParameterOnOffQuery
{
 private static VisibleParameter _parameter;

 static VisibleParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new VisibleParameter();
   }
  return _parameter;
 }

 private VisibleParameter()
 {
  super(PARAMETER_VISIBLE);
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return view != null && documentLocation != null &&
         view.document().elementList().elementAt(documentLocation.element) != null;
 }

 boolean value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    if (element != null)
     {
      return element.visible(view);
     }
   }

  return false;
 }
}