//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// InsertShowCommand - handle the insertShow command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>insertShow</b> command.
 */
final class InsertShowCommand
{
 static boolean doCommand(View view, String parameters)
 {
  if (view != null)
   {
    Element showElement = new Element(view);
    showElement.setText(view, parameters);
    view.insertElement(showElement);
   }
  return true;
 }
}