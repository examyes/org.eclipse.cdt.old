//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// InstallParameter - handles "query install.xxx" for an editor parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>install</b> parameter.
 *
 * This is a query-only parameter for editor parameters which
 * support an <b>install</b> setting.  Examples:
 * <pre>
 *   <b>query install.statusLine</b>,
 *   <b>query install.updateProfile.palette</b>. </pre>
 */
final class InstallParameter extends ParameterQuery
{
 private static InstallParameter _parameter;

 static InstallParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new InstallParameter();
   }
  return _parameter;
 }

 private InstallParameter()
 {
  super(PARAMETER_INSTALL);
 }

 /**
  * <b>query install.xxx</b>
  */
 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  Parameter p = Parameters.getParameter(qualifier);
  if (p != null && p.hasInstallSetting())
   {
    return p.queryInstall(Parameters.getQualifierString(qualifier));
   }

  return null; // no such parm / parm doesn't support an "install." setting
 }
}