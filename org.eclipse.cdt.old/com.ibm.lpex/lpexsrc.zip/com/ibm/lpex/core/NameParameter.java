//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// NameParameter - handles the name parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>name</b> parameter.
 */
final class NameParameter extends Parameter
{
 private static NameParameter _parameter;

 static NameParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new NameParameter();
   }
  return _parameter;
 }

 private NameParameter()
 {
  super(LpexConstants.PARAMETER_NAME);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  if (view != null)
   {
    view.document().setName(parameters);
   }

  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.document().name() : null;
 }
}