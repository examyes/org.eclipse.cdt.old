//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CommandsParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class CommandsParameter extends ParameterQuery
{
 private static CommandsParameter _parameter;

 static CommandsParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new CommandsParameter();
   }
  return _parameter;
 }

 private CommandsParameter()
 {
  super(PARAMETER_COMMANDS);
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.commandHandler().commands() : null;
 }
}