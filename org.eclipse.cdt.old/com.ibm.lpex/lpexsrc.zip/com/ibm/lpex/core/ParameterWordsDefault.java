//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterWordsDefault - base class for words parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Base, abstract class for parameters which consist of a list of words.
 */
abstract class ParameterWordsDefault extends ParameterDefault
{
 private String  _hardCodedValue;
 private String  _installValue;
 private boolean _installValueLoaded;
 private String  _defaultValue;
 private boolean _defaultValueLoaded;


 ParameterWordsDefault(String name, String hardCodedValue)
  {
   super(name);
   _hardCodedValue = hardCodedValue;
   Install.addProfileChangedListener(new Install.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _installValueLoaded = false;
       if (defaultValue() == null)
        {
         for (Document document = Document._firstDocument;
              document != null;
              document = document._next)
          {
           for (View view = document._firstView; view != null; view = view._next)
            {
             if (value(view) == null)
              {
               currentValueChanged(view);
              }
            }
          }
        }
      }
    });

   Profile.addProfileChangedListener(new Profile.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _defaultValueLoaded = false;
       for (Document document = Document._firstDocument;
            document != null;
            document = document._next)
        {
         for (View view = document._firstView; view != null; view = view._next)
          {
           if (value(view) == null)
            {
             currentValueChanged(view);
            }
          }
        }
      }
    });
  }

 String installValue()
  {
   if (!_installValueLoaded)
    {
     String value =
        LpexStringTokenizer.removeQuotes(Install.getString(PARAMETER_INSTALL + name()));
     _installValue = (value == null)? _hardCodedValue : value;
     _installValueLoaded = true;
    }

   return _installValue;
  }

 private void loadDefaultValue()
  {
   if (!_defaultValueLoaded)
    {
     _defaultValue =
        LpexStringTokenizer.removeQuotes(Profile.getString(PARAMETER_DEFAULT + name()));
     _defaultValueLoaded = true;
    }
  }

 String defaultValue()
  {
   loadDefaultValue();
   return _defaultValue;
  }

 boolean setDefaultValue(String value)
  {
   _defaultValue = value;
   _defaultValueLoaded = true;
   if (_defaultValue != null)
    {
     Profile.putString(PARAMETER_DEFAULT + name(), LpexStringTokenizer.addQuotes(_defaultValue));
    }
   else
    {
     Profile.remove(PARAMETER_DEFAULT + name());
    }

   for (Document document = Document._firstDocument; document != null; document = document._next)
    {
     for (View view = document._firstView; view != null; view = view._next)
      {
       if (value(view) == null)
        {
         currentValueChanged(view);
        }
      }
    }

   return true;
  }

 String currentValue(View view)
  {
   String value = value(view);
   if (value == null)
    {
     value = defaultValue();
     if (value == null)
      {
       value = installValue();
      }
    }

   return value;
  }

 boolean set(View view, String qualifier, String parameters)
  {
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (!st.hasMoreTokens())
    {
     return setValue(view, "");
    }

   String token = st.nextToken();
   if (!st.hasMoreTokens() && token.equals("default"))
    {
     return setValue(view, null);
    }

   String value = token;
   while (st.hasMoreTokens())
    {
     value += " " + st.nextToken();
    }
   return setValue(view, value);
  }

 abstract boolean setValue(View view, String value);

 boolean setDefault(View view, String qualifier, String parameters)
  {
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (!st.hasMoreTokens())
    {
     return setDefaultValue("");
    }

   String token = st.nextToken();
   if (!st.hasMoreTokens() && token.equals("install"))
    {
     return setDefaultValue(null);
    }

   String value = token;
   while (st.hasMoreTokens())
    {
     value += " " + st.nextToken();
    }
   return setDefaultValue(value);
  }

 void currentValueChanged(View view) {}

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   if (view != null)
    {
     String value = value(view);
     return (value == null)? "default" : value;
    }

   return null;
  }

 abstract String value(View view);

 String queryInstall(String qualifier)
  {
   return installValue();
  }

 String queryDefault(String qualifier)
  {
   String value = defaultValue();
   return (value == null)? "install" : value;
  }

 String queryCurrent(View view, String qualifier)
  {
   return currentValue(view);
  }
}