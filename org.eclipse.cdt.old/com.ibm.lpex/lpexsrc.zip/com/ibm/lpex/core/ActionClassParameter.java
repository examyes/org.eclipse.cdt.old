//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ActionClassParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ActionClassParameter extends ParameterWordOnly
{
 private static ActionClassParameter _parameter;

 static ActionClassParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ActionClassParameter();
   }
  return _parameter;
 }

 private ActionClassParameter()
 {
  super(PARAMETER_ACTION_CLASS);
 }

 boolean setValue(View view, String qualifier, String value)
 {
  if (view != null)
   {
    view.actionHandler().defineAction(qualifier, value);
   }
  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.actionHandler().actionClass(qualifier) : null;
 }
}