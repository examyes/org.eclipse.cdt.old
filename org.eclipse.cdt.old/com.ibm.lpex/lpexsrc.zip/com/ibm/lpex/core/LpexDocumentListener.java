//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexDocumentListener - defines a listener to text changes in the document.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Interface LpexDocumentListener can be implemented to listen to text changes
 * in the document.
 *
 * <p>The information provided applies to the entire text of the line,
 * i.e., including the sequence numbers, if set.  No notifications are sent for
 * <b>show</b> elements (such as document parser error-message lines).
 *
 * <p>Certain editing operations may trigger several consecutive notifications
 * for one change which has already been recorded in the text of an element.
 * For example, one <b>replaceText</b> command may trigger notifications
 * indicating the text replaced, the text inserted beyond the end of the original
 * line, and a sequence-numbers text part change.
 *
 * <p>Create a listener object using this class, and then register it with a
 * document view using LpexView's <code>addLpexDocumentListener()</code>
 * method.  When text changes occur in the currently-loaded document section,
 * the appropriate method in the listener object is invoked.
 * Example:
 * <pre>
 *   myLpexView.addLpexDocumentListener(new LpexDocumentListener() {
 *      // document text change
 *      public boolean documentChanged(LpexView lpexView, int type, int line, int position, int len) {
 *         return handleDocumentChange(lpexView, type, line, position, len);
 *         }
 *      }); </pre>
 *
 * @see LpexView#addLpexDocumentListener
 * @see LpexView#removeLpexDocumentListener
 */
public interface LpexDocumentListener
{
  /**
   * This notification is sent when text is deleted in a text element.
   * It is sent before the actual change takes place in the LPEX document.
   */
  public static final int TEXT_REMOVED     = 0;
  /**
   * This notification is sent when text is replaced in a text element.
   * It is sent after the actual change takes place in the LPEX document.
   */
  public static final int TEXT_REPLACED    = 1;
  /**
   * This notification is sent when text is inserted in a text element.
   * It is sent after the actual change takes place in the LPEX document.
   */
  public static final int TEXT_INSERTED    = 2;
  /**
   * This notification is sent when a text element is deleted from the document.
   * It is sent before the actual change takes place in the LPEX document.
   */
  public static final int ELEMENT_REMOVED  = 3;
  /**
   * This notification is sent when a text element is replaced in the document.
   * It is sent after the actual change takes place in the LPEX document.
   */
  public static final int ELEMENT_REPLACED = 4;
  /**
   * This notification is sent when a text element is inserted in the document.
   * It is sent after the actual change takes place in the LPEX document.
   */
  public static final int ELEMENT_INSERTED = 5;

 /**
  * This method is invoked when a text change occurs in the LPEX document.
  *
  * @param lpexView the view of the editor document that triggered the change
  * @param type     change type
  * @param line     document line affected, defined inside the document section
  *                 that is currently loaded in the editor
  * @param position first change position inside the line, or
  *                 0 for element notifications
  * @param len      length of the change in the line, or
  *                 0 for element notifications
  */
 public void documentChanged(LpexView lpexView, int type, int line, int position, int len);
}