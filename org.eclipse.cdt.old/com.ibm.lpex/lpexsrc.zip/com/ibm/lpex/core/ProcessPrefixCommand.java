//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ProcessPrefixCommand - handles the processPrefix command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;


//-as- after deletes, if the cursor is on an exclude-block header element, check
//     to see if we can collapse the exclude blocks around the deleted text into
//     one - see exclude() in here...


/**
 * This class implements the <b>processPrefix</b> command.
 * It handles the prefix commands for the <b>ispf</b>, <b>seu</b>, and
 * <b>xedit</b> base profiles.
 */
final class ProcessPrefixCommand
{
 // start of name for prefix marks
 static final String PREFIX_MARK_NAME = "ProcessPrefix";

 // SEU skeleton line
 private static String _skeleton;

 private final static int
  PROFILE_INVALID = 0,
  PROFILE_SEU     = 1,
  PROFILE_XEDIT   = 2,
  PROFILE_ISPF    = 3;

 private static final int
  SEU_INVALID                    =  0,
  SEU_LOCATE                     =  1,
  SEU_SCROLL_DOWN                =  2,
  SEU_SCROLL_UP                  =  3,
  SEU_CURRENT                    =  4,
  SEU_AFTER                      =  5,
  SEU_BEFORE                     =  6,
  SEU_DELETE                     =  7,
  SEU_BLOCK_DELETE               =  8,
  SEU_INSERT                     =  9,
  SEU_INSERT_SKELETON            = 10,
  SEU_SHIFT_LEFT                 = 11,
  SEU_BLOCK_SHIFT_LEFT           = 12,
  SEU_BLOCK_SHIFT_LEFT_TRUNCATE  = 13,
  SEU_PRINT                      = 14,
  SEU_BLOCK_PRINT                = 15,
  SEU_SHIFT_LEFT_TRUNCATE        = 16,
  SEU_OVERLAY                    = 17,
  SEU_BLOCK_OVERLAY              = 18,
  SEU_SHIFT_RIGHT                = 19,
  SEU_REPEAT                     = 20,
  SEU_BLOCK_REPEAT               = 21,
  SEU_BLOCK_SHIFT_RIGHT          = 22,
  SEU_BLOCK_SHIFT_RIGHT_TRUNCATE = 23,
  SEU_SHIFT_RIGHT_TRUNCATE       = 24,
  SEU_SKELETON                   = 25,
  SEU_SHOW_FIRST                 = 26,
  SEU_SHOW_LAST                  = 27,
  SEU_WINDOW                     = 28,
  SEU_EXCLUDE                    = 29,
  SEU_BLOCK_EXCLUDE              = 30;

 private static TableNode[] _seuCommands =
  {
   new TableNode("",    SEU_LOCATE),
   new TableNode("+",   SEU_SCROLL_DOWN),
   new TableNode("-",   SEU_SCROLL_UP),
   new TableNode("/",   SEU_CURRENT),
   new TableNode("a",   SEU_AFTER),
   new TableNode("b",   SEU_BEFORE),
   new TableNode("d",   SEU_DELETE),
   new TableNode("dd",  SEU_BLOCK_DELETE),
   new TableNode("i",   SEU_INSERT),
   new TableNode("is",  SEU_INSERT_SKELETON),
   new TableNode("l",   SEU_SHIFT_LEFT),
   new TableNode("ll",  SEU_BLOCK_SHIFT_LEFT),
   new TableNode("llt", SEU_BLOCK_SHIFT_LEFT_TRUNCATE),
   new TableNode("lp",  SEU_PRINT),
   new TableNode("lpp", SEU_BLOCK_PRINT),
   new TableNode("lt",  SEU_SHIFT_LEFT_TRUNCATE),
   new TableNode("o",   SEU_OVERLAY),
   new TableNode("oo",  SEU_BLOCK_OVERLAY),
   new TableNode("r",   SEU_SHIFT_RIGHT),
   new TableNode("rp",  SEU_REPEAT),
   new TableNode("rpp", SEU_BLOCK_REPEAT),
   new TableNode("rr",  SEU_BLOCK_SHIFT_RIGHT),
   new TableNode("rrt", SEU_BLOCK_SHIFT_RIGHT_TRUNCATE),
   new TableNode("rt",  SEU_SHIFT_RIGHT_TRUNCATE),
   new TableNode("s",   SEU_SKELETON),
   new TableNode("sf",  SEU_SHOW_FIRST),
   new TableNode("sl",  SEU_SHOW_LAST),
   new TableNode("w",   SEU_WINDOW),
   new TableNode("x",   SEU_EXCLUDE),
   new TableNode("xx",  SEU_BLOCK_EXCLUDE),
  };

 private static final int
  XEDIT_INVALID                    =  0,
  XEDIT_DUPLICATE                  =  1,
  XEDIT_BLOCK_DUPLICATE            =  2,
  XEDIT_SHIFT_LEFT_TRUNCATE        =  3,
  XEDIT_BLOCK_SHIFT_LEFT_TRUNCATE  =  4,
  XEDIT_SHIFT_RIGHT_TRUNCATE       =  5,
  XEDIT_BLOCK_SHIFT_RIGHT_TRUNCATE =  6,
  XEDIT_CURRENT                    =  7,
  XEDIT_SHIFT_LEFT                 =  8,
  XEDIT_BLOCK_SHIFT_LEFT           =  9,
  XEDIT_SHIFT_RIGHT                = 10,
  XEDIT_BLOCK_SHIFT_RIGHT          = 11,
  XEDIT_ADD                        = 12,
  XEDIT_DELETE                     = 13,
  XEDIT_BLOCK_DELETE               = 14,
  XEDIT_FOLLOWING                  = 15,
  XEDIT_INSERT                     = 16,
  XEDIT_PREVIOUS                   = 17,
  XEDIT_SHOW                       = 18,
  XEDIT_SHOW_ALL                   = 19,
  XEDIT_SHOW_FIRST                 = 20,
  XEDIT_SHOW_LAST                  = 21,
  XEDIT_EXCLUDE                    = 22,
  XEDIT_EXCLUDE_ALL                = 23,
  XEDIT_BLOCK_EXCLUDE              = 24;

 private static TableNode[] _xeditCommands =
  {
   new TableNode("\"",   XEDIT_DUPLICATE),
   new TableNode("\"\"", XEDIT_BLOCK_DUPLICATE),
   new TableNode("(",    XEDIT_SHIFT_LEFT_TRUNCATE),
   new TableNode("((",   XEDIT_BLOCK_SHIFT_LEFT_TRUNCATE),
   new TableNode(")",    XEDIT_SHIFT_RIGHT_TRUNCATE),
   new TableNode("))",   XEDIT_BLOCK_SHIFT_RIGHT_TRUNCATE),
   new TableNode("/",    XEDIT_CURRENT),
   new TableNode("<",    XEDIT_SHIFT_LEFT),
   new TableNode("<<",   XEDIT_BLOCK_SHIFT_LEFT),
   new TableNode(">",    XEDIT_SHIFT_RIGHT),
   new TableNode(">>",   XEDIT_BLOCK_SHIFT_RIGHT),
   new TableNode("a",    XEDIT_ADD),
   new TableNode("d",    XEDIT_DELETE),
   new TableNode("dd",   XEDIT_BLOCK_DELETE),
   new TableNode("f",    XEDIT_FOLLOWING),
   new TableNode("i",    XEDIT_INSERT),
   new TableNode("p",    XEDIT_PREVIOUS),
   new TableNode("s",    XEDIT_SHOW),
   new TableNode("s*",   XEDIT_SHOW_ALL),
   new TableNode("s+",   XEDIT_SHOW_FIRST),
   new TableNode("s-",   XEDIT_SHOW_LAST),
   new TableNode("x",    XEDIT_EXCLUDE),
   new TableNode("x*",   XEDIT_EXCLUDE_ALL),
   new TableNode("xx",   XEDIT_BLOCK_EXCLUDE),
  };

 private static final int
  ISPF_INVALID                    =  0,
  ISPF_SHIFT_LEFT_TRUNCATE        =  1,
  ISPF_BLOCK_SHIFT_LEFT_TRUNCATE  =  2,
  ISPF_SHIFT_RIGHT_TRUNCATE       =  3,
  ISPF_BLOCK_SHIFT_RIGHT_TRUNCATE =  4,
  ISPF_CURRENT                    =  5,
  ISPF_SHIFT_LEFT                 =  6,
  ISPF_BLOCK_SHIFT_LEFT           =  7,
  ISPF_SHIFT_RIGHT                =  8,
  ISPF_BLOCK_SHIFT_RIGHT          =  9,
  ISPF_AFTER                      = 10,
  ISPF_BEFORE                     = 11,
  ISPF_DELETE                     = 12,
  ISPF_BLOCK_DELETE               = 13,
  ISPF_SHOW_FIRST                 = 14,
  ISPF_INSERT                     = 15,
  ISPF_SHOW_LAST                  = 16,
  ISPF_LOWER_CASE                 = 17,
  ISPF_BLOCK_LOWER_CASE           = 18,
  ISPF_OVERLAY                    = 19,
  ISPF_BLOCK_OVERLAY              = 20,
  ISPF_DUPLICATE                  = 21,
  ISPF_BLOCK_DUPLICATE            = 22,
  ISPF_SHOW                       = 23,
  ISPF_UPPER_CASE                 = 24,
  ISPF_BLOCK_UPPER_CASE           = 25,
  ISPF_EXCLUDE                    = 26,
  ISPF_BLOCK_EXCLUDE              = 27;

 // "c", "m", "cc", "mm" will be handled in "a"/"b"/"o"/"oo" - see targetISPF()
 private static TableNode[] _ispfCommands =
  {
   new TableNode("(",   ISPF_SHIFT_LEFT_TRUNCATE),
   new TableNode("((",  ISPF_BLOCK_SHIFT_LEFT_TRUNCATE),
   new TableNode(")",   ISPF_SHIFT_RIGHT_TRUNCATE),
   new TableNode("))",  ISPF_BLOCK_SHIFT_RIGHT_TRUNCATE),
   new TableNode("/",   ISPF_CURRENT),
   new TableNode("<",   ISPF_SHIFT_LEFT),
   new TableNode("<<",  ISPF_BLOCK_SHIFT_LEFT),
   new TableNode(">",   ISPF_SHIFT_RIGHT),
   new TableNode(">>",  ISPF_BLOCK_SHIFT_RIGHT),
   new TableNode("a",   ISPF_AFTER),
   new TableNode("b",   ISPF_BEFORE),
   new TableNode("d",   ISPF_DELETE),
   new TableNode("dd",  ISPF_BLOCK_DELETE),
   new TableNode("f",   ISPF_SHOW_FIRST),
   new TableNode("i",   ISPF_INSERT),
   new TableNode("l",   ISPF_SHOW_LAST),
   new TableNode("lc",  ISPF_LOWER_CASE),
   new TableNode("lcc", ISPF_BLOCK_LOWER_CASE),
   new TableNode("o",   ISPF_OVERLAY),
   new TableNode("oo",  ISPF_BLOCK_OVERLAY),
   new TableNode("r",   ISPF_DUPLICATE),
   new TableNode("rr",  ISPF_BLOCK_DUPLICATE),
   new TableNode("s",   ISPF_SHOW),
   new TableNode("uc",  ISPF_UPPER_CASE),
   new TableNode("ucc", ISPF_BLOCK_UPPER_CASE),
   new TableNode("x",   ISPF_EXCLUDE),
   new TableNode("xx",  ISPF_BLOCK_EXCLUDE),
  };

 private final static int
  PROCESS_CONTINUE = 1,
  PROCESS_RESTART  = 2,
  PROCESS_QUIT     = 3;


 /**
  * Do the <b>processPrefix</b> command.
  *
  * @param parameters profile to use: "seu" or "xedit" or "ispf"
  */
 static boolean doCommand(View view, String parameters)
  {
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   int profile = PROFILE_INVALID;

   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("seu"))
      {
       profile = PROFILE_SEU;
      }
     else if (token.equals("xedit"))
      {
       profile = PROFILE_XEDIT;
      }
     else if (token.equals("ispf"))
      {
       profile = PROFILE_ISPF;
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "processPrefix");
      }
    }

   if (view != null && profile != PROFILE_INVALID)
    {
     int status;
     do
      {
       // go thru all doc's prefix commands (unless we stop on a fatal error)...
       status = PROCESS_CONTINUE;
       for (Element element = firstPrefix(view);
            element != null && status == PROCESS_CONTINUE;
            element = nextPrefix(view, element))
        {
         String prefixText = element.elementView(view).prefixText();
         switch (profile)
          {
           case PROFILE_SEU:
            {
             status = processSEU(view, element, prefixText);
             break;
            }
           case PROFILE_XEDIT:
            {
             status = processXEDIT(view, element, prefixText);
             break;
            }
           case PROFILE_ISPF:
            {
             status = processISPF(view, element, prefixText);
             break;
            }
           default:
            {
             break;
            }
          }
        }//end "for"
      } while (status == PROCESS_RESTART);
    }

   return true;
  }

 /**
  * Do one SEU prefix command.
  *
  * @param view       document view
  * @param element    element for the prefix command
  * @param prefixText prefix command (e.g., "dd")
  */
 private static int processSEU(View view, Element element, String prefixText)
  {
   String command = command(prefixText);
   int count = count(prefixText);
   TableNode tableNode = TableNode.binarySearch(_seuCommands, command);
   int commandId = (tableNode != null)? tableNode.id() : SEU_INVALID;
   switch (commandId)
    {
     case SEU_LOCATE:
      {
       if (count > 0)
        {
         Element e = view.document().elementList().nonShowElementAt(count);
         view.documentPosition().jump(e, 1);
        }
       element.elementView(view).setPrefixText(null);
       break;
      }
     case SEU_SCROLL_DOWN:
      {
       if (count == -1)
        {
         count = 1;
        }
       view.documentPosition().scrollDown(count);
       element.elementView(view).setPrefixText(null);
       break;
      }
     case SEU_SCROLL_UP:
      {
       if (count == -1)
        {
         count = 1;
        }
       view.documentPosition().scrollUp(count);
       element.elementView(view).setPrefixText(null);
       break;
      }
     case SEU_CURRENT:
      {
       if (count == -1)
        {
         view.screen().setCursorRow(1);
         view.documentPosition().jump(element, 1);
         element.elementView(view).setPrefixText(null);
        }
       break;
      }
     case SEU_AFTER:
     case SEU_BEFORE:
      {
       return targetSEU(view, element, command, count);
      }
     case SEU_DELETE:
      {
       if (view.changeAllowed())
        {
         if (count == -1)
          {
           count = 1;
          }
         element.elementView(view).setPrefixText(null);
         view.document().resetUserActionElements();
         while (count > 0 && element != null)
          {
           Element nextElement = element.nextVisible(view);
           view.deleteElement(element);
           element = nextElement;
           count--;
          }
         return PROCESS_RESTART;
        }
       break;
      }
     case SEU_BLOCK_DELETE:
      {
       if (count == -1 && view.changeAllowed())
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           count = count(prefixText);
           command = command(prefixText);
           if (count == -1 && command.equals("dd"))
            {
             view.document().resetUserActionElements();
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             endElement = endElement.nextVisible(view);
             do
              {
               Element nextElement = element.nextVisible(view);
               view.deleteElement(element);
               element = nextElement;
              }
             while (element != endElement);
             return PROCESS_RESTART;
            }
          }
        }
       break;
      }
     case SEU_INSERT:
      {
       return insert(view, element, count, null);
      }
     case SEU_INSERT_SKELETON:
      {
       return insert(view, element, count, _skeleton);
      }
     case SEU_SHIFT_LEFT:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, -count, false);
        }
       break;
      }
     case SEU_BLOCK_SHIFT_LEFT:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, -count, command, false);
      }
     case SEU_BLOCK_SHIFT_LEFT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, -count, command, true);
      }
     case SEU_PRINT:
      {
       if (count == -1)
        {
         count = 1;
        }
       Element endElement = element;
       while (count > 1 && endElement != null)
        {
         endElement = endElement.nextVisible(view);
         count--;
        }
       element.elementView(view).setPrefixText(null);
       PrintCommand.doCommand(view, "visible startElement " +
         view.document().elementList().ordinalOf(element) +
         " endElement " +
         view.document().elementList().ordinalOf(endElement));
       break;
      }
     case SEU_BLOCK_PRINT:
      {
       if (count == -1)
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           count = count(prefixText);
           command = command(prefixText);
           if (count == -1 && command.equals("lpp"))
            {
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             PrintCommand.doCommand(view, "visible startElement " +
               view.document().elementList().ordinalOf(element) +
               " endElement " +
               view.document().elementList().ordinalOf(endElement));
             break;
            }
          }
        }
       break;
      }
     case SEU_SHIFT_LEFT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, -count, true);
        }
       break;
      }
     case SEU_OVERLAY:
     case SEU_BLOCK_OVERLAY:
      {
       return targetSEU(view, element, command, count);
      }
     case SEU_SHIFT_RIGHT:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, count, false);
        }
       break;
      }
     case SEU_REPEAT:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         String text = element.text();
         text = '\n' + text;
         DocumentPosition.Preserve preserve = view.documentPosition().preserve();
         view.documentPosition().jump(element, element.end());
         while (count > 0)
          {
           view.insertText(text);
           count--;
          }
         preserve.restore();
         view.documentPosition().disposePreserve(preserve);
        }
       break;
      }
     case SEU_BLOCK_REPEAT:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           command = command(prefixText);
           if (command.equals("rpp"))
            {
             view.document().resetUserActionElements();
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             String text = "";
             do
              {
               if (!element.show())
                {
                 String elementText = element.text();
                 text += '\n' + elementText;
                }
               element = element.nextVisible(view);
              }
             while (element != endElement.next());
             DocumentPosition.Preserve preserve = view.documentPosition().preserve();
             view.documentPosition().jump(endElement, endElement.end());
             while (count > 0)
              {
               view.insertText(text);
               count--;
              }
             preserve.restore();
             view.documentPosition().disposePreserve(preserve);
             break;
            }
          }
        }
       break;
      }
     case SEU_BLOCK_SHIFT_RIGHT:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, count, command, false);
      }
     case SEU_BLOCK_SHIFT_RIGHT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, count, command, true);
      }
     case SEU_SHIFT_RIGHT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, count, true);
        }
       break;
      }
     case SEU_SKELETON:
      {
       if (count == -1)
        {
         _skeleton = element.text();
        }
       break;
      }
     case SEU_SHOW_FIRST:
      {
       return showFirst(view, element, count);
      }
     case SEU_SHOW_LAST:
      {
       return showLast(view, element, count);
      }
     case SEU_WINDOW:
      {
       if (count == -1)
        {
         count = 1;
        }
       element.elementView(view).setPrefixText(null);
       count--;
       view.documentPosition().home();
       if (count > 0)
        {
         view.documentPosition().scrollRight(count * view.screen().textFontMetrics().spaceWidth());
        }
       break;
      }
     case SEU_EXCLUDE:
      {
       if (count == -1)
        {
         count = 1;
        }
       Element endElement = element;
       while (count > 1)
        {
         endElement = endElement.nextVisible(view);
         count--;
        }
       element.elementView(view).setPrefixText(null);
       exclude(view, element, endElement);
       break;
      }
     case SEU_BLOCK_EXCLUDE:
      {
       if (count == -1)
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           count = count(prefixText);
           command = command(prefixText);
           if (count == -1 && command.equals("xx"))
            {
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             exclude(view, element, endElement);
             break;
            }
          }
        }
       break;
      }
     default:
      {
       break;
      }
    }

   return PROCESS_CONTINUE;
  }

 /**
  * Process an SEU target command - a, b, o, oo:
  * find its best-matching command (c[n], cr[n], m[n], cc, mm), process, then
  * finally clear both.
  *
  * @param targetCommand "a", "b", "o", "oo"
  *
  * @return PROCESS_QUIT     doc's prefix commands incorrect, stop processing;
  *         PROCESS_RESTART  target command processed & cleared, restart
  *                          processing the doc's prefix area;
  *         PROCESS_CONTINUE not a processable target command this one, just
  *                          continue with the doc's prefix commands
  */
 private static int targetSEU(View view,
                              Element targetElement, String targetCommand, int targetCount)
  {
   if (targetCount == -1)
    {
     targetCount = 1;
    }
   else if (targetCommand.equals("oo"))
    {
     return PROCESS_CONTINUE;
    }

   if (!view.changeAllowed())
    {
     view.documentPosition().jump(targetElement, 1);
     view.setInPrefix(true);
     return PROCESS_QUIT;
    }

   /*==================================*/
   /*  1.- establish endTargetElement  */
   /*==================================*/
   Element endTargetElement = null;
   if (targetCommand.equals("oo"))
    {
     for (endTargetElement = nextPrefix(view, targetElement);
          endTargetElement != null;
          endTargetElement = nextPrefix(view, endTargetElement))
      {
       String prefixText = endTargetElement.elementView(view).prefixText();
       int count = count(prefixText);
       String command = command(prefixText);
       if (count == -1 && command.equals("oo"))
        {
         break;
        }
      }
     if (endTargetElement == null)
      {
       return PROCESS_CONTINUE;
      }
    }

   else if (targetCommand.equals("o"))
    {
     endTargetElement = targetElement;
     for (int i = 1; i < targetCount; i++)
      {
       Element nextVisible = endTargetElement.nextVisible(view);
       if (nextVisible != null)
        {
         endTargetElement = nextVisible;
        }
       else
        {
         break;
        }
      }
    }

   /*============================*/
   /*  2.- establish sourceText  */
   /*============================*/
   boolean after = targetCommand.equals("a");
   boolean overlay = targetCommand.equals("oo") || targetCommand.equals("o");
   DocumentPosition.Preserve preserve = view.documentPosition().preserve();
   view.documentPosition().jump(targetElement, after? targetElement.end() : 1);
   view.document().resetUserActionElements();
   String sourceText = null;
   int sourceCount = 0;
   for (Element element = firstPrefix(view);
        element != null && sourceText == null;
        element = nextPrefix(view, element))
    {
     String prefixText = element.elementView(view).prefixText();
     String command = command(prefixText);
     int count = count(prefixText);
     /*-------------------------*/
     /*  a.- c[n], cr[n], m[n]  */
     /*-------------------------*/
     if (command.equals("c") || command.equals("cr") || command.equals("m"))
      {
       targetElement.elementView(view).setPrefixText(null);
       if (targetCommand.equals("oo"))
        {
         endTargetElement.elementView(view).setPrefixText(null);
        }
       if (command.equals("c") || command.equals("m"))
        {
         element.elementView(view).setPrefixText(null);
        }
       boolean move = command.equals("m");
       if (count == -1)
        {
         count = 1;
        }
       sourceText = "";
       boolean first = true;
       while (count > 0 && element != null)
        {
         if (!element.show())
          {
           sourceCount++;
           String text = element.text();
           if (!first)
            {
             sourceText += '\n';
            }
           first = false;
           sourceText += text;
          }
         Element nextElement = element.nextVisible(view);
         // moving - remove the original text
         if (move)
          {
           if (element == endTargetElement)
            {
             if (endTargetElement == targetElement)
              {
               endTargetElement = null;
               overlay = false;
               after = true;
              }
             else
              {
               endTargetElement = element.prevVisible(view);
              }
            }
           if (element == targetElement)
            {
             if (overlay)
              {
               targetElement = element.nextVisible(view);
              }
             else
              {
               if (element.next() != null)
                {
                 targetElement = element.next();
                 after = false;
                }
               else
                {
                 targetElement = element.prev();
                 after = true;
                }
              }
            }
           view.deleteElement(element);
          }

         element = nextElement;
         count--;
        }//end "while"
       break;
      }

     /*-------------------*/
     /*  b.- cc, ccr, mm  */
     /*-------------------*/
     else if (count == -1 && (command.equals("cc") ||
                              command.equals("ccr") ||
                              command.equals("mm")))
      {
       Element startElement = element;
       boolean retain = command.equals("ccr");
       boolean move = command.equals("mm");
       Element endElement = null;
       for (element = nextPrefix(view, element);
            element != null && endElement == null;
            element = nextPrefix(view, element))
        {
         prefixText = element.elementView(view).prefixText();
         command = command(prefixText);
         count = count(prefixText);
         if (count == -1 &&
             ((move && command.equals("mm") ||
              (!move && (command.equals("cc") || command.equals("ccr"))))))
          {
           if (!retain)
            {
             retain = command.equals("ccr");
            }
           endElement = element;
          }
        }
       if (endElement == null)
        {
         view.documentPosition().disposePreserve(preserve);
         view.documentPosition().jump(startElement, 1);
         view.setInPrefix(true);
         return PROCESS_QUIT;
        }
       targetElement.elementView(view).setPrefixText(null);
       if (targetCommand.equals("oo"))
        {
         endTargetElement.elementView(view).setPrefixText(null);
        }
       if (!retain)
        {
         startElement.elementView(view).setPrefixText(null);
         endElement.elementView(view).setPrefixText(null);
        }
       sourceText = "";
       boolean first = true;
       element = startElement;
       endElement = endElement.nextVisible(view);
       do
        {
         if (!element.show())
          {
           sourceCount++;
           String text = element.text();
           if (!first)
            {
             sourceText += '\n';
            }
           first = false;
           sourceText += text;
          }
         Element nextElement = element.nextVisible(view);
         if (move)
          {
           if (element == endTargetElement)
            {
             if (endTargetElement == targetElement)
              {
               endTargetElement = null;
               overlay = false;
               after = true;
              }
             else
              {
               endTargetElement = element.prevVisible(view);
              }
            }
           if (element == targetElement)
            {
             if (overlay)
              {
               targetElement = element.nextVisible(view);
              }
             else
              {
               if (element.next() != null)
                {
                 targetElement = element.next();
                 after = false;
                }
               else
                {
                 targetElement = element.prev();
                 after = true;
                }
              }
            }
           view.deleteElement(element);
          }
         element = nextElement;
        }
       while (element != endElement);
       break;
      }
    }//end "for"

   /*====================================*/
   /*  3.- process sourceText at target  */
   /*====================================*/
   if (sourceText != null)
    {
     if (overlay)
      {
       int overlayCount = 0;
       Element stopElement = endTargetElement.nextVisible(view);
       for (Element element = targetElement;
            element != stopElement;
            element = element.nextVisible(view))
        {
         if (!element.show())
          {
           overlayCount++;
          }
        }

       view.documentPosition().jump(endTargetElement, endTargetElement.end());
       while (overlayCount < sourceCount)
        {
         Element newElement = new Element(view.document());
         newElement.elementView(view).setForceVisible(true);
         view.insertElement(newElement);
         endTargetElement = newElement;
         overlayCount++;
        }
       if (targetElement.show())
        {
         targetElement = targetElement.nextVisibleNonShow(view);
        }
       view.documentPosition().jump(targetElement, 1);
       view.overlayElements(sourceText, true);
       stopElement = endTargetElement.nextVisible(view);
       for (Element element = targetElement;
            element != stopElement;
            element = element.nextVisible(view))
        {
         element.elementView(view).setForceVisible(false);
        }
      }
     else
      {
       for (int i = 0; i < targetCount; i++)
        {
         if (after)
          {
           view.documentPosition().end();
           view.insertText('\n' + sourceText);
          }
         else
          {
           view.documentPosition().home();
           view.insertText(sourceText + '\n');
           after = true;
          }
        }
      }
    }
   preserve.restore();
   view.documentPosition().disposePreserve(preserve);

   if (sourceText == null)  //*as* no command for target, leave it 'hanging'...
    {
     return PROCESS_CONTINUE;
    }

   return PROCESS_RESTART;
  }

 /**
  * Do one XEDIT prefix command.
  *
  * @param view       document view
  * @param element    element for the prefix command
  * @param prefixText prefix command (e.g., "dd")
  */
 private static int processXEDIT(View view, Element element, String prefixText)
  {
   String command = command(prefixText);
   int count = count(prefixText);
   TableNode tableNode = TableNode.binarySearch(_xeditCommands, command);
   int commandId = (tableNode != null)? tableNode.id() : XEDIT_INVALID;
   switch (commandId)
    {
     case XEDIT_DUPLICATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         element.elementView(view).setPrefixText(null);
         view.document().resetUserActionElements();
         String text = element.text();
         text = '\n' + text;
         DocumentPosition.Preserve preserve = view.documentPosition().preserve();
         view.documentPosition().jump(element, element.end());
         while (count > 0)
          {
           view.insertText(text);
           count--;
          }
         preserve.restore();
         view.documentPosition().disposePreserve(preserve);
        }
       break;
      }
     case XEDIT_BLOCK_DUPLICATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           command = command(prefixText);
           if (command.equals("\"\""))
            {
             view.document().resetUserActionElements();
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             String text = "";
             do
              {
               if (!element.show())
                {
                 String elementText = element.text();
                 text += '\n' + elementText;
                }
               element = element.nextVisible(view);
              }
             while (element != endElement.next());
             DocumentPosition.Preserve preserve = view.documentPosition().preserve();
             view.documentPosition().jump(endElement, endElement.end());
             while (count > 0)
              {
               view.insertText(text);
               count--;
              }
             preserve.restore();
             view.documentPosition().disposePreserve(preserve);
             break;
            }
          }
        }
       break;
      }
     case XEDIT_SHIFT_LEFT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, -count, true);
        }
       break;
      }
     case XEDIT_BLOCK_SHIFT_LEFT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, -count, command, true);
      }
     case XEDIT_SHIFT_RIGHT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, count, true);
        }
       break;
      }
     case XEDIT_BLOCK_SHIFT_RIGHT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, count, command, true);
      }
     case XEDIT_CURRENT:
      {
       if (count == -1)
        {
         view.screen().setCursorRow(1);
         view.documentPosition().jump(element, 1);
         element.elementView(view).setPrefixText(null);
        }
       break;
      }
     case XEDIT_SHIFT_LEFT:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, -count, false);
        }
       break;
      }
     case XEDIT_BLOCK_SHIFT_LEFT:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, -count, command, false);
      }
     case XEDIT_SHIFT_RIGHT:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, count, false);
        }
       break;
      }
     case XEDIT_BLOCK_SHIFT_RIGHT:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, count, command, false);
      }
     case XEDIT_ADD:
      {
       return insert(view, element, count, null);
      }
     case XEDIT_DELETE:
      {
       if (view.changeAllowed())
        {
         if (count == -1)
          {
           count = 1;
          }
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         while (count > 0 && element != null)
          {
           Element nextElement = element.nextVisible(view);
           view.deleteElement(element);
           element = nextElement;
           count--;
          }
         return PROCESS_RESTART;
        }
       break;
      }
     case XEDIT_BLOCK_DELETE:
      {
       if (count == -1 && view.changeAllowed())
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           count = count(prefixText);
           command = command(prefixText);
           if (count == -1 && command.equals("dd"))
            {
             view.document().resetUserActionElements();
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             endElement = endElement.nextVisible(view);
             do
              {
               Element nextElement = element.nextVisible(view);
               view.deleteElement(element);
               element = nextElement;
              }
             while (element != endElement);
             return PROCESS_RESTART;
            }
          }
        }
       break;
      }
     case XEDIT_FOLLOWING:
      {
       if (count == -1)
        {
         return targetXEDIT(view, element, true);
        }
       break;
      }
     case XEDIT_INSERT:
      {
       return insert(view, element, count, null);
      }
     case XEDIT_PREVIOUS:
      {
       if (count == -1)
        {
         return targetXEDIT(view, element, false);
        }
       break;
      }
     case XEDIT_SHOW:
      {
       if (count == -1)
        {
         return show(view, element);
        }
       else
        {
         return showFirst(view, element, count);
        }
      }
     case XEDIT_SHOW_ALL:
      {
       if (count == -1)
        {
         return show(view, element);
        }
       break;
      }
     case XEDIT_SHOW_FIRST:
      {
       return showFirst(view, element, count);
      }
     case XEDIT_SHOW_LAST:
      {
       return showLast(view, element, count);
      }
     case XEDIT_EXCLUDE:
      {
       if (count == -1)
        {
         count = 1;
        }
       Element endElement = element;
       while (count > 1)
        {
         endElement = endElement.nextVisible(view);
         count--;
        }
       element.elementView(view).setPrefixText(null);
       exclude(view, element, endElement);
       break;
      }
     case XEDIT_EXCLUDE_ALL:
      {
       if (count == -1)
        {
         element.elementView(view).setPrefixText(null);
         exclude(view,
                 view.document().elementList().first(),
                 view.document().elementList().last());
        }
       break;
      }
     case XEDIT_BLOCK_EXCLUDE:
      {
       if (count == -1)
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           count = count(prefixText);
           command = command(prefixText);
           if (count == -1 && command.equals("xx"))
            {
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             exclude(view, element, endElement);
             break;
            }
          }
        }
       break;
      }
     default:
      {
       break;
      }
    }
   return PROCESS_CONTINUE;
  }

 /**
  * Process an XEDIT target command - f, p:
  * find its best-matching command (c[n], m[n], cc, mm), process, clear both.
  *
  * @param after true = "f", false = "p"
  *
  * @return PROCESS_QUIT     doc's prefix commands incorrect, stop processing;
  *         PROCESS_RESTART  target command processed & cleared, restart
  *                          processing the doc's prefix area;
  *         PROCESS_CONTINUE not a processable target command this one, just
  *                          continue with the doc's prefix commands
  */
 private static int targetXEDIT(View view, Element targetElement, boolean after)
  {
   if (!view.changeAllowed())
    {
     view.documentPosition().jump(targetElement, 1);
     view.setInPrefix(true);
     return PROCESS_QUIT;
    }

   /*============================*/
   /*  1.- establish sourceText  */
   /*============================*/
   DocumentPosition.Preserve preserve = view.documentPosition().preserve();
   view.documentPosition().jump(targetElement, after? targetElement.end() : 1);
   view.document().resetUserActionElements();
   String sourceText = null;
   int sourceCount = 0;
   for (Element element = firstPrefix(view);
        element != null && sourceText == null;
        element = nextPrefix(view, element))
    {
     String prefixText = element.elementView(view).prefixText();
     String command = command(prefixText);
     int count = count(prefixText);

     /*------------------*/
     /*  a.- c[n], m[n]  */
     /*------------------*/
     // -as- 8/99 didn't handle count, redone based on targetSEU()'s!?
     if (command.equals("c") || command.equals("m"))
      {
       targetElement.elementView(view).setPrefixText(null); // clear target (f/p)
       element.elementView(view).setPrefixText(null);       //  & command (c/m)
       boolean move = command.equals("m");
       if (count == -1)
        {
         count = 1;
        }
       sourceText = "";
       boolean first = true;
       while (count > 0 && element != null)
        {
         if (!element.show())
          {
           sourceCount++;
           String text = element.text();
           if (!first)
            {
             sourceText += '\n';
            }
           first = false;
           sourceText += text;
          }
         Element nextElement = element.nextVisible(view);
         // moving - remove the original text
         if (move)
          {
           if (element == targetElement)
            {
             if (element.next() != null)
              {
               targetElement = element.next();
               after = false;
              }
             else
              {
               targetElement = element.prev();
               after = true;
              }
            }
           view.deleteElement(element);
          }

         element = nextElement;
         count--;
        }//end "while"
       break;
      }

     /*--------------*/
     /*  b.- cc, mm  */
     /*--------------*/
     else if (count == -1 && (command.equals("cc") || command.equals("mm")))
      {
       Element startElement = element;
       boolean move = command.equals("mm");
       Element endElement = null;
       for (element = nextPrefix(view, element);
            element != null && endElement == null;
            element = nextPrefix(view, element))
        {
         prefixText = element.elementView(view).prefixText();
         command = command(prefixText);
         count = count(prefixText);
         if (count == -1 &&
             ((move && command.equals("mm") || (!move && command.equals("cc")))))
          {
           endElement = element;
          }
        }
       if (endElement == null)
        {
         view.documentPosition().disposePreserve(preserve);
         view.documentPosition().jump(startElement, 1);
         view.setInPrefix(true);
         return PROCESS_QUIT;
        }
       targetElement.elementView(view).setPrefixText(null);
       startElement.elementView(view).setPrefixText(null);
       endElement.elementView(view).setPrefixText(null);
       sourceText = "";
       boolean first = true;
       element = startElement;
       endElement = endElement.nextVisible(view);
       do
        {
         if (!element.show())
          {
           String text = element.text();
           if (!first)
            {
             sourceText += '\n';
            }
           first = false;
           sourceText += text;
          }
         Element nextElement = element.nextVisible(view);
         if (move)
          {
           if (element == targetElement)
            {
             if (element.next() != null)
              {
               targetElement = element.next();
               after = false;
              }
             else
              {
               targetElement = element.prev();
               after = true;
              }
            }
           view.deleteElement(element);
          }
         element = nextElement;
        }
       while (element != endElement);
       break;
      }
    }//end "for"

   /*====================================*/
   /*  2.- process sourceText at target  */
   /*====================================*/
   if (sourceText != null)
    {
     if (after)
      {
       view.documentPosition().end();
       view.insertText('\n' + sourceText);
      }
     else
      {
       view.documentPosition().home();
       view.insertText(sourceText + '\n');
       after = true;
      }
    }
   preserve.restore();
   view.documentPosition().disposePreserve(preserve);

   if (sourceText == null)  //*as* no command for target, leave it 'hanging'...
    {
     return PROCESS_CONTINUE;
    }

   return PROCESS_RESTART;
  }

 /**
  * Do one ISPF prefix command.
  *
  * @param view       document view
  * @param element    element for the prefix command
  * @param prefixText prefix command (e.g., "dd")
  */
 private static int processISPF(View view, Element element, String prefixText)
  {
   String command = command(prefixText);
   int count = count(prefixText);
   TableNode tableNode = TableNode.binarySearch(_ispfCommands, command);
   int commandId = (tableNode != null)? tableNode.id() : ISPF_INVALID;
   switch (commandId)
    {
     case ISPF_SHIFT_LEFT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, -count, true);
        }
       break;
      }
     case ISPF_BLOCK_SHIFT_LEFT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, -count, command, true);
      }
     case ISPF_SHIFT_RIGHT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, count, true);
        }
       break;
      }
     case ISPF_BLOCK_SHIFT_RIGHT_TRUNCATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, count, command, true);
      }
     case ISPF_CURRENT:
      {
       if (count == -1)
        {
         view.screen().setCursorRow(1);
         view.documentPosition().jump(element, 1);
         element.elementView(view).setPrefixText(null);
        }
       break;
      }
     case ISPF_SHIFT_LEFT:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, -count, false);
        }
       break;
      }
     case ISPF_BLOCK_SHIFT_LEFT:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, -count, command, false);
      }
     case ISPF_SHIFT_RIGHT:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         view.shift(element, count, false);
        }
      }
     case ISPF_BLOCK_SHIFT_RIGHT:
      {
       if (count == -1)
        {
         count = 1;
        }
       return blockShift(view, element, count, command, false);
      }
     case ISPF_AFTER:
     case ISPF_BEFORE:
      {
       if (count == -1)
        {
         return targetISPF(view, element, command, count);
        }
       break;
      }
     case ISPF_DELETE:
      {
       if (view.changeAllowed())
        {
         if (count == -1)
          {
           count = 1;
          }
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         while (count > 0 && element != null)
          {
           Element nextElement = element.nextVisible(view);
           view.deleteElement(element);
           element = nextElement;
           count--;
          }
         return PROCESS_RESTART;
        }
       break;
      }
     case ISPF_BLOCK_DELETE:
      {
       if (count == -1 && view.changeAllowed())
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           count = count(prefixText);
           command = command(prefixText);
           if (count == -1 && command.equals("dd"))
            {
             view.document().resetUserActionElements();
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             endElement = endElement.nextVisible(view);
             do
              {
               Element nextElement = element.nextVisible(view);
               view.deleteElement(element);
               element = nextElement;
              }
             while (element != endElement);
             return PROCESS_RESTART;
            }
          }
        }
       break;
      }
     case ISPF_SHOW_FIRST:
      {
       return showFirst(view, element, count);
      }
     case ISPF_INSERT:
      {
       return insert(view, element, count, null);
      }
     case ISPF_SHOW_LAST:
      {
       return showLast(view, element, count);
      }
     case ISPF_LOWER_CASE:
      {
       if (view.changeAllowed())
        {
         if (count == -1)
          {
           count = 1;
          }
         element.elementView(view).setPrefixText(null);
         view.document().resetUserActionElements();
         while (count > 0 && element != null)
          {
           view.changeCase(element, false);
           element = element.nextVisible(view);
           count--;
          }
        }
       break;
      }
     case ISPF_BLOCK_LOWER_CASE:
      {
       if (count == -1 && view.changeAllowed())
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           count = count(prefixText);
           command = command(prefixText);
           if (count == -1 && command.equals("lcc"))
            {
             view.document().resetUserActionElements();
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             endElement = endElement.nextVisible(view);
             do
              {
               view.changeCase(element, false);
               element = element.nextVisible(view);
              }
             while (element != endElement);
             break;
            }
          }
        }
       break;
      }
     case ISPF_OVERLAY:
     case ISPF_BLOCK_OVERLAY:
      {
       return targetISPF(view, element, command, count);
      }
     case ISPF_DUPLICATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         element.elementView(view).setPrefixText(null);
         view.document().resetUserActionElements();
         String text = element.text();
         text = '\n' + text;
         DocumentPosition.Preserve preserve = view.documentPosition().preserve();
         view.documentPosition().jump(element, element.end());
         while (count > 0)
          {
           view.insertText(text);
           count--;
          }
         preserve.restore();
         view.documentPosition().disposePreserve(preserve);
        }
       break;
      }
     case ISPF_BLOCK_DUPLICATE:
      {
       if (count == -1)
        {
         count = 1;
        }
       if (view.changeAllowed())
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           command = command(prefixText);
           if (command.equals("rr"))
            {
             view.document().resetUserActionElements();
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             String text = "";
             do
              {
               if (!element.show())
                {
                 String elementText = element.text();
                 text += '\n' + elementText;
                }
               element = element.nextVisible(view);
              }
             while (element != endElement.next());
             DocumentPosition.Preserve preserve = view.documentPosition().preserve();
             view.documentPosition().jump(endElement, endElement.end());
             while (count > 0)
              {
               view.insertText(text);
               count--;
              }
             preserve.restore();
             view.documentPosition().disposePreserve(preserve);
             break;
            }
          }
        }
       break;
      }
     case ISPF_SHOW:
      {
       if (count == -1)
        {
         return show(view, element);
        }
       break;
      }
     case ISPF_UPPER_CASE:
      {
       if (view.changeAllowed())
        {
         if (count == -1)
          {
           count = 1;
          }
         element.elementView(view).setPrefixText(null);
         view.document().resetUserActionElements();
         while (count > 0 && element != null)
          {
           view.changeCase(element, true);
           element = element.nextVisible(view);
           count--;
          }
         return PROCESS_CONTINUE;
        }
       break;
      }
     case ISPF_BLOCK_UPPER_CASE:
      {
       if (count == -1 && view.changeAllowed())
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           count = count(prefixText);
           command = command(prefixText);
           if (count == -1 && command.equals("ucc"))
            {
             view.document().resetUserActionElements();
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             endElement = endElement.nextVisible(view);
             do
              {
               view.changeCase(element, true);
               element = element.nextVisible(view);
              }
             while (element != endElement);
             break;
            }
          }
        }
       break;
      }
     case ISPF_EXCLUDE:
      {
       if (count == -1)
        {
         count = 1;
        }
       Element endElement = element;
       while (count > 1)
        {
         endElement = endElement.nextVisible(view);
         count--;
        }
       element.elementView(view).setPrefixText(null);
       exclude(view, element, endElement);
       break;
      }
     case ISPF_BLOCK_EXCLUDE:
      {
       if (count == -1)
        {
         for (Element endElement = nextPrefix(view, element);
              endElement != null;
              endElement = nextPrefix(view, endElement))
          {
           prefixText = endElement.elementView(view).prefixText();
           count = count(prefixText);
           command = command(prefixText);
           if (count == -1 && command.equals("xx"))
            {
             element.elementView(view).setPrefixText(null);
             endElement.elementView(view).setPrefixText(null);
             exclude(view, element, endElement);
             break;
            }
          }
        }
       break;
      }
     default:
      {
       break;
      }
    }

   return PROCESS_CONTINUE;
  }

 /**
  * Process an ISPF target command - a, b, o, oo:
  * find its best-matching command (c[n], m[n], cc, mm), process, clear both.
  *
  * @param targetCommand "a", "b", "o", "oo"
  *
  * @return PROCESS_QUIT     doc's prefix commands incorrect, stop processing;
  *         PROCESS_RESTART  target command processed & cleared, restart
  *                          processing the doc's prefix area;
  *         PROCESS_CONTINUE not a processable target command this one, just
  *                          continue with the doc's prefix commands
  */
 private static int targetISPF(View view,
                               Element targetElement, String targetCommand, int targetCount)
  {
   if (targetCount != -1)
    {
     return PROCESS_CONTINUE;
    }

   if (!view.changeAllowed())
    {
     view.documentPosition().jump(targetElement, 1);
     view.setInPrefix(true);
     return PROCESS_QUIT;
    }

   /*==================================*/
   /*  1.- establish endTargetElement  */
   /*==================================*/
   Element endTargetElement = null;
   if (targetCommand.equals("oo"))
    {
     for (endTargetElement = nextPrefix(view, targetElement);
          endTargetElement != null;
          endTargetElement = nextPrefix(view, endTargetElement))
      {
       String prefixText = endTargetElement.elementView(view).prefixText();
       int count = count(prefixText);
       String command = command(prefixText);
       if (count == -1 && command.equals("oo"))
        {
         break;
        }
      }
     if (endTargetElement == null)
      {
       return PROCESS_CONTINUE;
      }
    }
   else if (targetCommand.equals("o"))
    {
     endTargetElement = targetElement;
    }

   /*============================*/
   /*  2.- establish sourceText  */
   /*============================*/
   boolean after = targetCommand.equals("a");
   boolean overlay = targetCommand.equals("oo") || targetCommand.equals("o");
   DocumentPosition.Preserve preserve = view.documentPosition().preserve();
   view.documentPosition().jump(targetElement, after? targetElement.end() : 1);
   view.document().resetUserActionElements();
   String sourceText = null;
   int sourceCount = 0;
   for (Element element = firstPrefix(view);
        element != null && sourceText == null;
        element = nextPrefix(view, element))
    {
     String prefixText = element.elementView(view).prefixText();
     String command = command(prefixText);
     int count = count(prefixText);
     /*------------------*/
     /*  a.- c[n], m[n]  */
     /*------------------*/
     // -as- 8/99 c, m didn't handle count, made identical to targetSEU()'s!?
     if (command.equals("c") || command.equals("m"))
      {
       targetElement.elementView(view).setPrefixText(null);
       if (targetCommand.equals("oo"))
        {
         endTargetElement.elementView(view).setPrefixText(null);
        }
       if (command.equals("c") || command.equals("m"))
        {
         element.elementView(view).setPrefixText(null);
        }
       boolean move = command.equals("m");
       if (count == -1)
        {
         count = 1;
        }
       sourceText = "";
       boolean first = true;
       while (count > 0 && element != null)
        {
         if (!element.show())
          {
           sourceCount++;
           String text = element.text();
           if (!first)
            {
             sourceText += '\n';
            }
           first = false;
           sourceText += text;
          }
         Element nextElement = element.nextVisible(view);
         // moving - remove the original text
         if (move)
          {
           if (element == endTargetElement)
            {
             if (endTargetElement == targetElement)
              {
               endTargetElement = null;
               overlay = false;
               after = true;
              }
             else
              {
               endTargetElement = element.prevVisible(view);
              }
            }
           if (element == targetElement)
            {
             if (overlay)
              {
               targetElement = element.nextVisible(view);
              }
             else
              {
               if (element.next() != null)
                {
                 targetElement = element.next();
                 after = false;
                }
               else
                {
                 targetElement = element.prev();
                 after = true;
                }
              }
            }
           view.deleteElement(element);
          }

         element = nextElement;
         count--;
        }//end "while"
       break;
      }

     /*--------------*/
     /*  b.- cc, mm  */
     /*--------------*/
     else if (count == -1 && (command.equals("cc") || command.equals("mm")))
      {
       Element startElement = element;
       boolean move = command.equals("mm");
       Element endElement = null;
       for (element = nextPrefix(view, element);
            element != null && endElement == null;
            element = nextPrefix(view, element))
        {
         prefixText = element.elementView(view).prefixText();
         command = command(prefixText);
         count = count(prefixText);
         if (count == -1 &&
             ((move && command.equals("mm") || (!move && command.equals("cc")))))
          {
           endElement = element;
          }
        }
       if (endElement == null)
        {
         view.documentPosition().disposePreserve(preserve);
         view.documentPosition().jump(startElement, 1);
         view.setInPrefix(true);
         return PROCESS_QUIT;
        }
       targetElement.elementView(view).setPrefixText(null);
       if (targetCommand.equals("oo"))
        {
         endTargetElement.elementView(view).setPrefixText(null);
        }
       startElement.elementView(view).setPrefixText(null);
       endElement.elementView(view).setPrefixText(null);
       sourceText = "";
       boolean first = true;
       element = startElement;
       endElement = endElement.nextVisible(view);
       do
        {
         if (!element.show())
          {
           sourceCount++;
           String text = element.text();
           if (!first)
            {
             sourceText += '\n';
            }
           first = false;
           sourceText += text;
          }
         Element nextElement = element.nextVisible(view);
         if (move)
          {
           if (element == endTargetElement)
            {
             if (endTargetElement == targetElement)
              {
               endTargetElement = null;
               overlay = false;
               after = true;
              }
             else
              {
               endTargetElement = element.prevVisible(view);
              }
            }
           if (element == targetElement)
            {
             if (overlay)
              {
               targetElement = element.nextVisible(view);
              }
             else
              {
               if (element.next() != null)
                {
                 targetElement = element.next();
                 after = false;
                }
               else
                {
                 targetElement = element.prev();
                 after = true;
                }
              }
            }
           view.deleteElement(element);
          }
         element = nextElement;
        }
       while (element != endElement);
       break;
      }
    }//end "for"

   /*====================================*/
   /*  3.- process sourceText at target  */
   /*====================================*/
   if (sourceText != null)
    {
     if (overlay)
      {
       int overlayCount = 0;
       Element stopElement = endTargetElement.nextVisible(view);
       for (Element element = targetElement;
            element != stopElement;
            element = element.nextVisible(view))
        {
         if (!element.show())
          {
           overlayCount++;
          }
        }

       view.documentPosition().jump(endTargetElement, endTargetElement.end());
       while (overlayCount < sourceCount)
        {
         Element newElement = new Element(view.document());
         newElement.elementView(view).setForceVisible(true);
         view.insertElement(newElement);
         endTargetElement = newElement;
         overlayCount++;
        }
       if (targetElement.show())
        {
         targetElement = targetElement.nextVisibleNonShow(view);
        }
       view.documentPosition().jump(targetElement, 1);
       view.overlayElements(sourceText, true);
       stopElement = endTargetElement.nextVisible(view);
       for (Element element = targetElement;
            element != stopElement;
            element = element.nextVisible(view))
        {
         element.elementView(view).setForceVisible(false);
        }
      }
     else
      {
       if (after)
        {
         view.documentPosition().end();
         view.insertText('\n' + sourceText);
        }
       else
        {
         view.documentPosition().home();
         view.insertText(sourceText + '\n');
         after = true;
        }
      }
    }
   preserve.restore();
   view.documentPosition().disposePreserve(preserve);

   if (sourceText == null)  //*as* no command for target, leave it 'hanging'...
    {
     return PROCESS_CONTINUE;
    }

   return PROCESS_RESTART;
  }

 /**
  * Retrieve the count of a prefix command.
  * @return count, or -1 for none
  */
 private static int count(String prefixText)
  {
   String number = "";
   prefixText = prefixText.trim();
   boolean digitAtStart = true;
   while (prefixText.length() > 0)
    {
     char c = prefixText.charAt(0);
     if (Character.isDigit(c))
      {
       break;
      }
     digitAtStart = false;
     prefixText = prefixText.substring(1);
    }

   while (prefixText.length() > 0)
    {
     char c = prefixText.charAt(0);
     if (!Character.isDigit(c))
      {
       break;
      }
     number += c;
     prefixText = prefixText.substring(1);
    }

   if (number.length() > 0 && (digitAtStart || prefixText.length() == 0))
    {
     try
      {
       return Integer.parseInt(number);
      }
     catch(NumberFormatException e) {}
    }

   return -1;
  }

 /**
  * Retrieve the prefix command.
  */
 private static String command(String prefixText)
  {
   String command = "";
   String number = "";
   prefixText = prefixText.trim();
   boolean digitAtStart = true;
   while (prefixText.length() > 0)
    {
     char c = prefixText.charAt(0);
     if (Character.isDigit(c))
      {
       break;
      }
     digitAtStart = false;
     command += c;
     prefixText = prefixText.substring(1);
    }

   while (prefixText.length() > 0)
    {
     char c = prefixText.charAt(0);
     if (!Character.isDigit(c))
      {
       break;
      }
     number += c;
     prefixText = prefixText.substring(1);
    }

   if (!digitAtStart && prefixText.length() != 0)
    {
     command += number;
    }

   command += prefixText;
   command = command.trim().toLowerCase();

   return command;
  }

 private static Element firstPrefix(View view)
  {
   Element element = view.document().elementList().firstVisible(view);
   if (element != null)
    {
     String prefixText = element.elementView(view).prefixText();
     if (prefixText == null || prefixText.length() == 0)
      {
       element = nextPrefix(view, element);
      }
    }

   return element;
  }

 private static Element nextPrefix(View view, Element element)
  {
   for (element = element.nextVisible(view);
        element != null;
        element = element.nextVisible(view))
    {
     String prefixText = element.elementView(view).prefixText();
     if (prefixText != null && prefixText.length() > 0)
      {
       return element;
      }
    }

   return null;
  }

 /**
  * Generate a new prefix mark name.
  */
 private static String nextMarkName(View view)
  {
   for (int i = 0; ; i++)
    {
     String markName = PREFIX_MARK_NAME + String.valueOf(i);
     if (view.markList().find(markName) == null)
      {
       return markName;
      }
    }
  }

 /**
  * Exclude (don't show) element1 [ - element2] in the specified view.
  *
  * This range of elements is set a mark with the excluded attribute;  this mark
  * is also set as excluded header, so it will display a show line indicating
  * the number of elements excluded.
  *
  * Any adjacent exclude blocks are collapsed into one block.
  */
 private static void exclude(View view, Element element1, Element element2)
  {
   /*--------------------------------------------------------------*/
   /*  add any current exclude block preceding element1..element2  */
   /*--------------------------------------------------------------*/
   if (element1 != null && element1.prev() != null)
    {
     // go through the list of marks of the preceding element in this view
     for (ElementView.MarkNode markNode = element1.prev().elementView(view)._firstMarkNode;
          markNode != null;
          markNode = markNode._next)
      {
       MarkList.Mark mark = markNode.mark();
       // if it has an excluded mark & it's a prefix-command mark, add block in
       if (mark.excluded() && mark.name().startsWith(PREFIX_MARK_NAME))
        {
         element1 = mark.element1();
         // clear mark for the current exclude block
         mark.clear();
        }
      }
    }

   /*-----------------------------------------------------------*/
   /*  add any current exclude block inside element1..element2  */
   /*-----------------------------------------------------------*/
   Element nextElement = null;
   for (Element element = element1;
        element != null && element != element2.next();
        element = nextElement)
    {
     nextElement = element.next();
     // check if this element is the header (show) element of an excluded mark
     MarkList.Mark mark = view.markList().headerMark(element);
     // if it is, and the excluded mark is a prefix-command mark, include block
     if (mark != null && mark.name().startsWith(PREFIX_MARK_NAME))
      {
       if (element1 == element) // curr exclude block at start of element1..element2
        {
         element1 = nextElement;
        }
       nextElement = element.next();
       // expand range to cover the entire current exclude block
       ElementList elementList = view.document().elementList();
       if (elementList.ordinalOf(element2) < elementList.ordinalOf(mark.element2()))
        {
         element2 = mark.element2();
        }
       // clear mark for current exclude block
       mark.clear();
      }
    }

   /*--------------------------------------------------------------*/
   /*  add any current exclude block following element1..element2  */
   /*--------------------------------------------------------------*/
   if (element2 != null && element2.next() != null)
    {
     MarkList.Mark mark = view.markList().headerMark(element2.next());
     if (mark != null && mark.name().startsWith(PREFIX_MARK_NAME))
      {
       element2 = mark.element2();
       // clear mark for current exclude block
       mark.clear();
      }
    }

   if (element1 != null && element2 != null)
    {
     // create a non-sticky element mark for element1 [ - element2]
     MarkList.Mark mark = view.markList().set(nextMarkName(view), element1, element2, false);
     // set it as excluded
     mark.setExcluded(true);
     // the mark should have a header element when it is excluded:  a show
     // element that replaces the elements associated with the mark when the
     // mark is excluded, and indicating the number of excluded lines
     mark.setExcludedHeader(true);
    }
  }

 private static int insert(View view, Element element, int count, String text)
  {
   if (view.changeAllowed())
    {
     if (count == -1)
      {
       count = 1;
      }

     view.document().resetUserActionElements();
     element.elementView(view).setPrefixText(null);
     DocumentPosition.Preserve preserve = view.documentPosition().preserve();
     view.documentPosition().jump(element, 1);
     while (count > 0)
      {
       Element newElement = new Element(view.document(), text);
       view.insertElement(newElement);
       count--;
      }

     preserve.restore();
     view.documentPosition().disposePreserve(preserve);
     return PROCESS_CONTINUE;
    }

   else
    {
     view.documentPosition().jump(element, 1);
     view.setInPrefix(true);
     return PROCESS_QUIT;
    }
  }

 private static int blockShift(View view, Element element, int count, String command, boolean truncate)
  {
   if (view.changeAllowed())
    {
     for (Element endElement = nextPrefix(view, element);
          endElement != null;
          endElement = nextPrefix(view, endElement))
      {
       String prefixText = endElement.elementView(view).prefixText();
       if (command.equals(command(prefixText)))
        {
         view.document().resetUserActionElements();
         element.elementView(view).setPrefixText(null);
         endElement.elementView(view).setPrefixText(null);
         endElement = endElement.nextVisible(view);
         do
          {
           view.shift(element, count, truncate);
           element = element.nextVisible(view);
          }
         while (element != endElement);
         break;
        }
      }
    }

   return PROCESS_CONTINUE;
  }

 private static int showFirst(View view, Element element, int count)
  {
   MarkList.Mark mark = view.markList().headerMark(element);
   if (mark != null && mark.name().startsWith(PREFIX_MARK_NAME))
    {
     if (count == -1)
      {
       count = 1;
      }

     element = mark.element1();
     Element element2 = mark.element2();
     while (count > 0 && element != element2.next())
      {
       if (!element.show())
        {
         count--;
        }
       element = element.next();
      }

     if (element != element2.next())
      {
       mark.clear();
       exclude(view, element, element2);
      }
     else
      {
       mark.clear();
      }
    }

   return PROCESS_CONTINUE;
  }

 private static int showLast(View view, Element element, int count)
  {
   MarkList.Mark mark = view.markList().headerMark(element);
   if (mark != null && mark.name().startsWith(PREFIX_MARK_NAME))
    {
     if (count == -1)
      {
       count = 1;
      }

     Element element1 = mark.element1();
     element = mark.element2();
     while (count > 0 && element != element1.prev())
      {
       if (!element.show())
        {
         count--;
        }
       element = element.prev();
      }

     if (element != element1.prev())
      {
       mark.clear();
       exclude(view, element1, element);
      }
     else
      {
       mark.clear();
      }
    }

   return PROCESS_CONTINUE;
  }

 /**
  * If the specified element is an excluded block header, show all the lines in
  * the excluded block.
  */
 private static int show(View view, Element element)
  {
   // check if this element is the header (show) element of an excluded mark
   MarkList.Mark mark = view.markList().headerMark(element);
   // if it is, and the excluded mark is a prefix-command mark, delete the mark
   if (mark != null && mark.name().startsWith(PREFIX_MARK_NAME))
    {
     mark.clear();
    }

   return PROCESS_CONTINUE;
  }
}