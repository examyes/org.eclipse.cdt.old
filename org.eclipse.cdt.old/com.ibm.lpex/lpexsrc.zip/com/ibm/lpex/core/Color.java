//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Color - LPEX wrapper for the development platform's Color class.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.graphics.Device;


//-as- In order not to create Colors (and their underlying native resources)
//     unnecessarily, we could use here org.eclipse.swt.graphics.RGB, and only
//     instantiate a real org.eclipse.swt.graphics.Color when needed!?...


/**
 * LPEX wrapper for org.eclipse.swt.graphics.Color.
 */
final class Color
{
   private org.eclipse.swt.graphics.Color _color;


   /**
    * Return a new Color for the specified device (Display / Printer).
    *
    * @param device the device on which to allocate the color
    * @param red    the red component of the color
    * @param green  the green component of the color
    * @param blue   the blue component of the color
    */
   Color(Device device, int r, int g, int b)
   {
      _color = new org.eclipse.swt.graphics.Color(device, r, g, b);
   }

   /**
    * Return a new Color for the specified device (Display / Printer).
    *
    * @param device the device on which to allocate the color
    * @param color  the base color to use for the new Color object
    */
   Color(Device device, Color color)
   {
      this(device, color.getRed(), color.getGreen(), color.getBlue());
   }

   /**
    * Return a new Color.
    *
    * The Device of the SWT Color created is <code>null</code>, which seems okay
    * for display colors.
    */
   Color(int r, int g, int b) //*as* retire this method!?
   {
      this(null, r, g, b);
   }

   int getRed()
   {
      return _color.getRed();
   }

   int getGreen()
   {
      return _color.getGreen();
   }

   int getBlue()
   {
      return _color.getBlue();
   }

   boolean isWhite()
   {
      return getRed()==255 && getGreen()==255 && getBlue()==255;
   }

   /**
    * Compares this <code>Color</code> object to the specified
    * <code>object</code>.
    *
    * @param object the <code>Object</code> to compare.
    *
    * @return <code>true</code> = the objects are the same,
    *         <code>false</code> otherwise.
    */
   public boolean equals(Object object)
   {
      return (object == this) ||
              ((object instanceof Color) && _color.equals(((Color)object)._color));
   }

   /**
    * Dispose the native color object.
    * An SWT Color is an OS resource that must be disposed when no longer
    * required.
    */
   public void dispose()
   {
      _color.dispose();
   }

   /**
    * Color's finalize:  dispose the native color object.
    */
   protected void finalize() throws Throwable
   {
      if (!_color.isDisposed())
         _color.dispose();
      super.finalize();
   }

   /**
    * Return the underlying development-platform color object.
    * This is needed because we cannot directly extend
    * final swt.graphics.Color...
    */
   org.eclipse.swt.graphics.Color getColor()
   {
      return _color;
   }
}