//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// RowHeightParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class RowHeightParameter extends ParameterIntegerQuery
{
 private static RowHeightParameter _parameter;

 static RowHeightParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new RowHeightParameter();
   }
  return _parameter;
 }

 private RowHeightParameter()
 {
  super(PARAMETER_ROW_HEIGHT);
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return view != null && view.screen().textFontMetrics() != null;
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    TextFontMetrics textFontMetrics = view.screen().textFontMetrics();
    if (textFontMetrics != null)
     {
      return textFontMetrics.textHeight();
     }
   }
  return 0;
 }
}