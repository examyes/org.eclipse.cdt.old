//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LoadCommand - handles the load command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>load</b> command.
 */
final class LoadCommand
{
 static boolean doCommand(View view, String parameters)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    return CommandHandler.invalidParameter(view, st.nextToken(), "load");
   }

  if (view != null)
   {
    view.document().load(view);
   }

  return true;
 }
}