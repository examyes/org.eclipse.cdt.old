//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ShowParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ShowParameter extends ParameterQuery
{
 private static ShowParameter _parameter;

 static ShowParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ShowParameter();
   }
  return _parameter;
 }

 private ShowParameter()
 {
  super(PARAMETER_SHOW);
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    if (element != null)
     {
      if (element.show())
       {
        return element.elementView(view).show()? "on" : "other";
       }
      return "off";
     }
   }

  return null;
 }
}