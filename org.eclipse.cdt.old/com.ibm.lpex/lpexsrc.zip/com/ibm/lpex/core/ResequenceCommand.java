//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ResequenceCommand - handles the resequence command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>resequence</b> command.
 * It reorders the numeric part of the currently-loaded document section's
 * sequence numbers into unique ascending numbers according to the number of
 * lines in the complete document.
 */
final class ResequenceCommand
{
 static boolean doCommand(View view, String parameters)
 {
  int start = 100;
  int increment = 100;

  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    try
     {
      start = Integer.parseInt(token);
      if (start < 1)
       {
        return CommandHandler.invalidParameter(view, token, "resequence");
       }

      increment = start;
      if (st.hasMoreTokens())
       {
        token = st.nextToken();
        increment = Integer.parseInt(token);
        if (increment < 1)
         {
          return CommandHandler.invalidParameter(view, token, "resequence");
         }
       }

      if (st.hasMoreTokens())
       {
        return CommandHandler.invalidParameter(view, st.nextToken(), "resequence");
       }
     }
    catch(NumberFormatException e)
     {
      return CommandHandler.invalidParameter(view, token, "resequence");
     }
   }

  // command format is correct, now if we have a view do it
  if (view != null)
   {
    if (!view.document().elementList().resequence(start, increment))
     {
      view.setLpexMessageText(LpexConstants.MSG_RESEQUENCECOMMAND_OVERFLOW);
     }
   }
  return true;
 }
}