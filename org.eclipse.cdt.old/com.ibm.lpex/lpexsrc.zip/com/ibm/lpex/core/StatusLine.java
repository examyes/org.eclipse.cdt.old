//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// StatusLine - the status line.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;


/**
 * This class manages the status line of an LpexWindow.
 * There is one instance of this class per instance of LpexWindow.
 */
final class StatusLine extends Composite implements LpexConstants
 {
  static final int
   INPUT_MODE_INSERT  = 0,
   INPUT_MODE_REPLACE = 1,
   INPUT_MODE_COMMAND = 2;

  private Field _fields[];
  private final int
   ROW_FIELD_INDEX        = 0,
   COLUMN_FIELD_INDEX     = 1,
   INPUT_MODE_FIELD_INDEX = 2,
   CHANGES_FIELD_INDEX    = 3,
   BROWSE_FIELD_INDEX     = 4,
   PAD_FIELD_INDEX        = 5,
   NUMBER_OF_FIELDS       = 6;


  /**
   * Construct the status line for an LpexWindow.
   */
  StatusLine(LpexWindow lpexWindow)
   {
    super(lpexWindow, SWT.NO_BACKGROUND | SWT.NO_FOCUS ); // shouldn't get focus

    addPaintListener(new PaintListener()
     {
      public void paintControl(PaintEvent e)
       {
        // swt: e.x,y,widht,height are the invalidated rectangle
        paintComponent(e.gc, e.x, e.width);
       }
     });

    // awt: validate() - Validates this container and all of its subcomponents.
    //      AWT uses validate to cause a container to lay out its subcomponents
    //      again after the components it contains have been added to or
    //      modified.
    // validate();

    _fields = new Field[NUMBER_OF_FIELDS];
    _fields[ROW_FIELD_INDEX]        = new RowField();
    _fields[COLUMN_FIELD_INDEX]     = new ColumnField();
    _fields[INPUT_MODE_FIELD_INDEX] = new InputModeField();
    _fields[CHANGES_FIELD_INDEX]    = new ChangesField();
    _fields[BROWSE_FIELD_INDEX]     = new BrowseField();
    _fields[PAD_FIELD_INDEX]        = new PadField();
   }

  void paintComponent(GC g, int x, int width)
   {
    // swt: see setFont(), we've already set our font for the entire
    // Control, so paintComponent()'s GC comes ready set to it...
    // g.setFont(_font.getFont());

    for (int i = 0; i < NUMBER_OF_FIELDS; i++)
     {
      // mark field as invalid if located within the invalidated area to paint
      _fields[i].invalidate(x, width);
      // paint the field if marked as invalid
      _fields[i].paint(g);
     }
   }

  /**
   * Retrieve SWT's preferred size of the component.
   */
  public Point computeSize(int wHint, int hHint, boolean changed)
   {
    int height = 0;
    int width  = 0;
    if (_textFontMetrics != null)
     {
      height = _textFontMetrics.textHeight();
      width  = _textFontMetrics.spaceWidth() * 40;
     }
    return new Point(width, height);
   }

  private Font _font;
  private TextFontMetrics _textFontMetrics;
  private StyleAttributes _styleAttributes;

  void invalidateStatus()
   {
    for (int i = 0; i < NUMBER_OF_FIELDS; i++)
     {
      _fields[i].invalidate();
     }
   }

  RowField rowField()
   {
    return (RowField)_fields[ROW_FIELD_INDEX];
   }

  ColumnField columnField()
   {
    return (ColumnField)_fields[COLUMN_FIELD_INDEX];
   }

  InputModeField inputModeField()
   {
    return (InputModeField)_fields[INPUT_MODE_FIELD_INDEX];
   }

  ChangesField changesField()
   {
    return (ChangesField)_fields[CHANGES_FIELD_INDEX];
   }

  BrowseField browseField()
   {
    return (BrowseField)_fields[BROWSE_FIELD_INDEX];
   }

  PadField padField()
   {
    return (PadField)_fields[PAD_FIELD_INDEX];
   }

  boolean setFont(Font font, TextFontMetrics textFontMetrics)
   {
    if (_font == null || !(_font.equals(font)))
     {
      _font = font;
      _textFontMetrics = textFontMetrics;

      // swt: set font as the Control's, so paintComponent()'s GC comes
      // ready set to it and we don't have to re-set it
      setFont(_font.getFont());

      rowField().newFont();
      columnField().newFont();
      inputModeField().newFont();
      changesField().newFont();
      browseField().newFont();
      padField().invalidate();
      return true;
     }
    return false;
   }

  void setStyleAttributes(StyleAttributes styleAttributes)
   {
    if (_styleAttributes == null || !(_styleAttributes.equals(styleAttributes)))
     {
      _styleAttributes = styleAttributes;

      // swt: set foreground & background as the Control's, so paintComponent()'s
      // GC comes ready set to them and we don't have to re-set them
      setBackground(_styleAttributes.backgroundColor().getColor());
      setForeground(_styleAttributes.foregroundColor().getColor());

      invalidateStatus();
     }
   }

  void updateStatus()
   {
    int height = getSize().y;
    if (height != 0)
     {
      for (int i = 0; i < NUMBER_OF_FIELDS; i++)
       {
        if (!_fields[i].valid())
         {
          redraw(_fields[i].start(), 0, _fields[i].width(), height, false);
         }
       }
     }
   }

  abstract class Field
   {
    protected boolean _valid;
    protected String  _text;
    protected int     _textOffset;

    boolean valid()
     {
      return _valid;
     }

    void invalidate()
     {
      _valid = false;
     }

    void invalidate(int x, int width)
     {
      int x1 = start();
      int x2 = start() + width();
      if (x1 <= x + width && x2 >= x)
       {
        _valid = false;
       }
     }

    abstract int width();
    abstract int start();

    int end()
     {
      return start() + width();
     }

    /**
     * Paint the status line's field.
     */
    void paint(GC g)
     {
      if (!_valid)
       {
        if (width() > 0 && _styleAttributes != null)
         {
          int height = getSize().y;

          // swt: see setStyleAttributes(), we've already set our background for
          // the entire Control, so paintComponent()'s GC comes ready set to it...
          // g.setBackground(_styleAttributes.backgroundColor().getColor());

          g.fillRectangle(start(), 0, width(), height);

          if (_text != null)
           {
            // swt: see setStyleAttributes(), we've already set our foreground for
            // the entire Control, so paintComponent()'s GC comes ready set to it...
            // g.setForeground(_styleAttributes.foregroundColor().getColor());

            // further constrain invalidated area with a clipping rect for the field
            g.setClipping(start(), 0, width(), height);
            g.drawString(_text, start() + _textOffset, 0 /*awt: _textFontMetrics.maxAscent()*/,
                         true); // already filled background, draw transparently
            if (_styleAttributes.underline())
             {
              g.drawLine(start() + _textOffset,
                         height - 1,
                         start() + _textOffset + _textFontMetrics.stringWidth(_text),
                         height - 1);
             }
            // remove our further-constraining clipping rectangle
            g.setClipping((Rectangle)null);
           }
          ///**/awt: g.setClip(originalClip);
         }
        _valid = true;
       }
     }
   }

  class RowField extends Field
   {
    int _width;
    int _row;

    void newFont()
     {
      if (_textFontMetrics != null)
       {
        String maxText = LpexResources.message(MSG_STATUS_ROW, 999999);
        _width = _textFontMetrics.stringWidth(maxText) + 2 * _textFontMetrics.spaceWidth();
        _textOffset = _textFontMetrics.spaceWidth();
       }
      else
       {
        _width = 0;
       }
      _valid = false;
     }

    void setRow(int row)
     {
      if (_row != row)
       {
        _row = row;
        _text = (row > 0)? LpexResources.message(MSG_STATUS_ROW, _row) : null;
        _valid = false;
       }
     }

    int start()
     {
      return 0;
     }

    int width()
     {
      return _width;
     }
   }

  class ColumnField extends Field
   {
    private int _width;
    private int _column;

    void newFont()
     {
      if (_textFontMetrics != null)
       {
        String maxText = LpexResources.message(MSG_STATUS_COLUMN, 9999);
        _width = _textFontMetrics.stringWidth(maxText) + 2 * _textFontMetrics.spaceWidth();
        _textOffset = _textFontMetrics.spaceWidth();
       }
      else
       {
        _width = 0;
       }
      _valid = false;
     }

    void setColumn(int column)
     {
      if (_column != column)
       {
        _column = column;
        _text = (_column > 0)? LpexResources.message(MSG_STATUS_COLUMN, _column) : null;
        _valid = false;
       }
     }

    int start()
     {
      return rowField().end();
     }

    int width()
     {
      return _width;
     }
   }

  private static String _insertModeText;
  private static String _replaceModeText;
  private static String _commandModeText;

  class InputModeField extends Field
   {
    private int _width;
    private int _inputMode = INPUT_MODE_INSERT;

    InputModeField()
     {
      if (_insertModeText == null)
       {
        _insertModeText = LpexResources.message(MSG_STATUS_INSERT);
        _text = _insertModeText;
       }
      if (_replaceModeText == null)
       {
        _replaceModeText = LpexResources.message(MSG_STATUS_REPLACE);
       }
      if (_commandModeText == null)
       {
        _commandModeText = LpexResources.message(MSG_STATUS_COMMAND);
       }
     }

    void newFont()
     {
      if (_textFontMetrics != null)
       {
        int insertModeLength = _textFontMetrics.stringWidth(_insertModeText);
        int replaceModeLength = _textFontMetrics.stringWidth(_replaceModeText);
        int commandModeLength = _textFontMetrics.stringWidth(_commandModeText);
        _width = (insertModeLength > replaceModeLength)? insertModeLength : replaceModeLength;
        if (commandModeLength > _width)
         {
          _width = commandModeLength;
         }
        _width += 2 * _textFontMetrics.spaceWidth();
        _textOffset = _textFontMetrics.spaceWidth();
       }
      else
       {
        _width = 0;
       }
      _valid = false;
     }

    void setInputMode(int inputMode)
     {
      if (_inputMode != inputMode)
       {
        _inputMode = inputMode;
        switch (_inputMode)
         {
          case INPUT_MODE_INSERT:
           {
            _text = _insertModeText;
            break;
           }
          case INPUT_MODE_REPLACE:
           {
            _text = _replaceModeText;
            break;
           }
          case INPUT_MODE_COMMAND:
           {
            _text = _commandModeText;
            break;
           }
          default:
           {
            break;
           }
         }
        _valid = false;
       }
     }

    int start()
     {
      return columnField().end();
     }

    int width()
     {
      return _width;
     }
   }

  class ChangesField extends Field
   {
    private int _width;
    private int _changes;

    void newFont()
     {
      if (_textFontMetrics != null)
       {
        String maxText = LpexResources.message(MSG_STATUS_NCHANGES, 9999);
        _width = _textFontMetrics.stringWidth(maxText) + 2 * _textFontMetrics.spaceWidth();
        _textOffset = _textFontMetrics.spaceWidth();
       }
      else
       {
        _width = 0;
       }
      if (_changes != 0)
       {
        _valid = false;
       }
     }

    void setChanges(int changes)
     {
      if (_changes != changes)
       {
        _changes = changes;
        if (_changes == 0)
         {
          _text = null;
         }
        else if (_changes == 1)
         {
          _text = LpexResources.message(MSG_STATUS_1CHANGE);
         }
        else
         {
          _text = LpexResources.message(MSG_STATUS_NCHANGES, _changes);
         }
        _valid = false;
       }
     }

    int start()
     {
      return inputModeField().end();
     }

    int width()
     {
      return _width;
     }
   }

  private static String _browseText;

  class BrowseField extends Field
   {
    private int _width;
    private boolean _browseMode;

    BrowseField()
     {
      if (_browseText == null)
       {
        _browseText = LpexResources.message(MSG_STATUS_BROWSE);
       }
     }

    void newFont()
     {
      if (_textFontMetrics != null)
       {
        _width = _textFontMetrics.stringWidth(_browseText) + 2 * _textFontMetrics.spaceWidth();
        _textOffset = _textFontMetrics.spaceWidth();
       }
      else
       {
        _width = 0;
       }
      if (_browseMode)
       {
        _valid = false;
       }
     }

    void setBrowseMode(boolean browseMode)
     {
      if (_browseMode != browseMode)
       {
        _browseMode = browseMode;
        _text = _browseMode? _browseText : null;
        _valid = false;
       }
     }

    int start()
     {
      return changesField().end();
     }

    int width()
     {
      return _width;
     }
   }

  class PadField extends Field
   {
    void newFont()
     {
     }

    int start()
     {
      return browseField().end();
     }

    int width()
     {
      int width = getSize().x;
      int start = start();
      if (start < width)
       {
        return width - start;
       }
      return 0;
     }
   }
}