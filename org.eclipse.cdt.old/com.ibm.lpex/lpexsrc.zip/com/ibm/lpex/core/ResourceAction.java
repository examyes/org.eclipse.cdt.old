//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexResourceAction - base resource action.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * *** WORK IN PROGRESS ***
 *
 * Base class for a resource action.
 * It is an LpexAction that can provide the application with information needed
 * by the resource this action is linked to, such as the description text and
 * the icon for an action linked to a popup menu item.
 *
 * Currently, as an example, LpexActions added to the <b>popup</b> parameter by
 * an application using the LPEX widget have no means to provide this information.
 * The class will be enabled and built-up as needed by LPEX-based applications
 * (such as Eclipse plugins).
 *
 * @see LpexAction
 */
/*public*/ abstract class /*Lpex*/ResourceAction implements LpexAction
{
 /**
  * Return the action's description.
  * The default implementation of this method returns {@link #getToolTipText}.
  */
 public String getDescription()
 {
  return getToolTipText();
 }

 /**
  * Return the tool tip text for this action.
  * The default implementation of this method returns null.
  */
 public String getToolTipText()
 {
  return null;
 }

 //public abstract String getHelpId();
 //get [development-platform independent] image object();
}