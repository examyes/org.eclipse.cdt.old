//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexConstants interface - public LPEX constants.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * The interface LpexConstants contains public editor constants.
 */
public interface LpexConstants
 {
  public static final String
   /**
    * LPEX driver specification version.
    */
   LPEX_VERSION = "1.3.5";

  public static final int
   /**
    * LPEX development platform: Java 2 SDK AWT/Swing.
    */
   PLATFORM_AWT = 0,
   /**
    * LPEX development platform: Eclipse Platform SWT.
    */
   PLATFORM_SWT = 1;

  static final String
   PLATFORM_SWT_KEY = "swt.";   // extra in SWT-specific *.properties keys

  /**
   * Flag indicating the type of change for incremental parse.
   * @see com.ibm.lpex.core.LpexView#parsePending
   */
  public static final int
   PARSE_PENDING_CHANGE_MASK            = 1,
   PARSE_PENDING_NEXT_DELETED_MASK      = 1 << 1,
   PARSE_PENDING_PREV_DELETED_MASK      = 1 << 2,
   PARSE_PENDING_NEXT_SHOW_DELETED_MASK = 1 << 3,
   PARSE_PENDING_PREV_SHOW_DELETED_MASK = 1 << 4;

  /**
   * Id for an undefined LPEX action.
   */
  public static final int
   ACTION_INVALID                      =  0;

  // several action ids for compatibility with IBM Eclipse Platform's
  // actions defined in ITextOperationTarget and ISourceViewer
  static final int
   ACTION_ECLIPSE_UNDO                  =   1, // equivalent to ACTION_UNDO
   ACTION_ECLIPSE_REDO                  =   2, // equivalent to ACTION_REDO
   ACTION_ECLIPSE_CUT                   =   3, // equivalent to ACTION_CUT
   ACTION_ECLIPSE_COPY                  =   4, // equivalent to ACTION_COPY
   ACTION_ECLIPSE_PASTE                 =   5, // equivalent to ACTION_PASTE
   ACTION_ECLIPSE_DELETE                =   6, // equivalent to ACTION_DELETE
   ACTION_ECLIPSE_SELECT_ALL            =   7, // equivalent to ACTION_BLOCK_MARK_ALL
   ACTION_ECLIPSE_SHIFT_RIGHT           =   8,
   ACTION_ECLIPSE_SHIFT_LEFT            =   9,
   ACTION_ECLIPSE_PRINT                 =  10, // equivalent to ACTION_PRINT
   ACTION_ECLIPSE_PREFIX                =  11,
   ACTION_ECLIPSE_STRIP_PREFIX          =  12;
   //CONTENTASSIST_PROPOSAL             =  13
   //CONTENTASSIST_CONTEXT_INFORMATION  =  14
   //FORMAT                             =  15
   //INFORMATION                        =  16

  /**
   * LPEX built-in action id.
   * This id will most probably change in future LPEX releases.
   *
   * @see LpexView#actionId(String)
   */
  public static final int
   ACTION_APPEND_TO_ACTION_ARGUMENT     =  30,
   ACTION_BACK_SPACE                    =  31,
   ACTION_BLOCK_COPY                    =  32,
   ACTION_BLOCK_DELETE                  =  33,
   ACTION_BLOCK_FILL                    =  34,
   ACTION_BLOCK_LOWER_CASE              =  35,
   ACTION_BLOCK_MARK_ALL                =  36,
   ACTION_BLOCK_MARK_BOTTOM             =  37,
   ACTION_BLOCK_MARK_CHARACTER          =  38,
   ACTION_BLOCK_MARK_DOWN               =  39,
   ACTION_BLOCK_MARK_ELEMENT            =  40,
   ACTION_BLOCK_MARK_ELEMENT_AT_MOUSE   =  41,
   ACTION_BLOCK_MARK_END                =  42,
   ACTION_BLOCK_MARK_HOME               =  43,
   ACTION_BLOCK_MARK_LEFT               =  44,
   ACTION_BLOCK_MARK_NEXT_WORD          =  45,
   ACTION_BLOCK_MARK_PAGE_DOWN          =  46,
   ACTION_BLOCK_MARK_PAGE_LEFT          =  47,
   ACTION_BLOCK_MARK_PAGE_RIGHT         =  48,
   ACTION_BLOCK_MARK_PAGE_UP            =  49,
   ACTION_BLOCK_MARK_PREV_WORD          =  50,
   ACTION_BLOCK_MARK_RECTANGLE          =  51,
   ACTION_BLOCK_MARK_RECTANGLE_AT_MOUSE =  52,
   ACTION_BLOCK_MARK_RIGHT              =  53,
   ACTION_BLOCK_MARK_TO_MOUSE           =  54,
   ACTION_BLOCK_MARK_TOP                =  55,
   ACTION_BLOCK_MARK_UP                 =  56,
   ACTION_BLOCK_MARK_WORD               =  57,
   ACTION_BLOCK_MARK_WORD_AT_MOUSE      =  58,
   ACTION_BLOCK_MOVE                    =  59,
   ACTION_BLOCK_OVERLAY                 =  60,
   ACTION_BLOCK_SHIFT_LEFT              =  61,
   ACTION_BLOCK_SHIFT_RIGHT             =  62,
   ACTION_BLOCK_UNMARK                  =  63,
   ACTION_BLOCK_UPPER_CASE              =  64,
   ACTION_BOTTOM                        =  65,
   ACTION_CAPITALIZE_WORD               =  66,
   ACTION_CLEAR_PREFIX                  =  67,
   ACTION_COMMAND_LINE                  =  68,
   ACTION_COMPARE                       =  69,
   ACTION_COMPARE_CLEAR                 =  70,
   ACTION_COMPARE_NEXT                  =  71,
   ACTION_COMPARE_PREVIOUS              =  72,
   ACTION_COMPARE_REFRESH               =  73,
   ACTION_COPY                          =  74,
   ACTION_CURSOR_TO_MOUSE               =  75,
   ACTION_CUT                           =  76,
   ACTION_DELETE                        =  77,
   ACTION_DELETE_BLANK_LINES            =  78,
   ACTION_DELETE_LINE                   =  79,
   ACTION_DELETE_NEXT_WORD              =  80,
   ACTION_DELETE_PREV_WORD              =  81,
   ACTION_DELETE_TO_LINE_START          =  82,
   ACTION_DELETE_WHITE_SPACE            =  83,
   ACTION_DOWN                          =  84,
   ACTION_DUPLICATE_LINE                =  85,
   ACTION_END                           =  86,
   ACTION_EXCLUDE_SELECTION             =  87,
   ACTION_EXEC_COMMAND                  =  88,
   ACTION_EXPAND_HIDE_AT_MOUSE          =  89,
   ACTION_FILTER_SELECTION              =  90,
   ACTION_FIND                          =  91,
   ACTION_FIND_AND_REPLACE              =  92,
   ACTION_FIND_AND_REPLACE_NEXT         =  93,
   ACTION_FIND_AND_REPLACE_UP           =  94,
   ACTION_FIND_BLOCK_END                =  95,
   ACTION_FIND_BLOCK_START              =  96,
   ACTION_FIND_LAST_CHANGE              =  97,
   ACTION_FIND_MARK                     =  98,
   ACTION_FIND_NEXT                     =  99,
   ACTION_FIND_QUICK_MARK               = 100,
   ACTION_FIND_SELECTION                = 101,
   ACTION_FIND_UP                       = 102,
   ACTION_GET                           = 103,
   ACTION_HELP                          = 104,
   ACTION_HEX_EDIT_LINE                 = 105,
   ACTION_HOME                          = 106,
   ACTION_INDENT_TEXT                   = 107,
   ACTION_INSERT_FILE_NAME              = 108,
   ACTION_INSERT_LEFT_BRACE             = 109,
   ACTION_INSERT_NOT                    = 110,
   ACTION_INSERT_RIGHT_BRACE            = 111,
   ACTION_INSERT_TAB                    = 112,
   ACTION_INSERT_TO_TAB                 = 113,
   ACTION_JOIN                          = 114,
   ACTION_KEY_RECORDER_PLAY             = 115,
   ACTION_KEY_RECORDER_START            = 116,
   ACTION_KEY_RECORDER_STOP             = 117,
   ACTION_KILL_LINE                     = 118,
   ACTION_KILL_REGION                   = 119,
   ACTION_LEFT                          = 120,
   ACTION_LOCATE_LINE                   = 121,
   ACTION_LOWER_CASE_REGION             = 122,
   ACTION_LOWER_CASE_WORD               = 123,
   ACTION_NAME_MARK                     = 124,
   ACTION_NEW_LINE                      = 125,
   ACTION_NEXT_TAB_STOP                 = 126,
   ACTION_NEXT_WORD                     = 127,
   ACTION_NULL_ACTION                   = 128,
   ACTION_ONE_SPACE                     = 129,
   ACTION_OPEN_LINE                     = 130,
   ACTION_PAGE_DOWN                     = 131,
   ACTION_PAGE_LEFT                     = 132,
   ACTION_PAGE_RIGHT                    = 133,
   ACTION_PAGE_UP                       = 134,
   ACTION_PASTE                         = 135,
   ACTION_POPUP_AT_CURSOR               = 136,
   ACTION_POPUP_AT_MOUSE                = 137,
   ACTION_PREFERENCES                   = 138,
   ACTION_PREFIX_BACK_SPACE             = 139,
   ACTION_PREFIX_DELETE                 = 140,
   ACTION_PREFIX_END                    = 141,
   ACTION_PREFIX_HOME                   = 142,
   ACTION_PREFIX_LEFT                   = 143,
   ACTION_PREFIX_RIGHT                  = 144,
   ACTION_PREFIX_TRUNCATE               = 145,
   ACTION_PREV_TAB_STOP                 = 146,
   ACTION_PREV_WORD                     = 147,
   ACTION_PRINT                         = 148,
   ACTION_PROCESS_PREFIX                = 149,
   ACTION_REDO                          = 150,
   ACTION_RELOAD                        = 151,
   ACTION_RENAME                        = 152,
   ACTION_RIGHT                         = 153,
   ACTION_SAVE                          = 154,
   ACTION_SAVE_AS                       = 155,
   ACTION_SAVE_TO_WRITER                = 156,
   ACTION_SCROLL_BOTTOM                 = 157,
   ACTION_SCROLL_CENTER                 = 158,
   ACTION_SCROLL_TOP                    = 159,
   ACTION_SET_ACTION_ARGUMENT           = 160,
   ACTION_SET_PARSER                    = 161,
   ACTION_SET_QUICK_MARK                = 162,
   ACTION_SET_QUICK_MARK_ALL            = 163,
   ACTION_SET_QUICK_MARK_WORD           = 164,
   ACTION_SHOW_ALL                      = 165,
   ACTION_SPLIT                         = 166,
   ACTION_SPLIT_AND_SHIFT               = 167,
   ACTION_SPLIT_LINE                    = 168,
   ACTION_TEXT_WINDOW                   = 169,
   ACTION_TOGGLE_CASE_SENSITIVE         = 170,
   ACTION_TOGGLE_INSERT                 = 171,
   ACTION_TOGGLE_KEY_RECORDING          = 172,
   ACTION_TOGGLE_REGULAR_EXPRESSION     = 173,
   ACTION_TOP                           = 174,
   ACTION_TRANSPOSE_CHARACTERS          = 175,
   ACTION_TRANSPOSE_LINES               = 176,
   ACTION_TRANSPOSE_WORDS               = 177,
   ACTION_TRUNCATE                      = 178,
   ACTION_UNDO                          = 179,
   ACTION_UP                            = 180,
   ACTION_UPPER_CASE_REGION             = 181,
   ACTION_UPPER_CASE_WORD               = 182,
   ACTION_WINDOW_BOTTOM                 = 183,
   ACTION_WINDOW_TOP                    = 184,
   ACTION_WORD_END                      = 185,
   ACTION_WORD_START                    = 186,
   ACTION_YANK                          = 187,
   ACTION_YANK_PREVIOUS                 = 188;

  /**
   * First id assigned to user-defined actions.
   */
  public static final int
   ACTION_USER                          = 200;

  /**
   * Key for NLS string / message.
   */
  public static final String
   MSG_UNTITLED_DOCUMENT                = "untitledDocument",

   MSG_UNDO_NOMORECHANGES               = "undo.noMoreChanges",
   MSG_UNDO_NORECORDEDCHANGES           = "undo.noRecordedChanges",
   MSG_UNDO_DOCUMENTATORIGINALSTATE     = "undo.documentAtOriginalState",
   MSG_UNDO_1CHANGEUNDONE               = "undo.1ChangeUndone",
   MSG_UNDO_NCHANGESUNDONE              = "undo.nChangesUndone",
   MSG_REDO_NOREDOABLECHANGES           = "redo.noRedoableChanges",
   MSG_REDO_ALLCHANGESREDONE            = "redo.allChangesRedone",
   MSG_REDO_1CHANGEUNDONE               = "redo.1ChangeUndone",
   MSG_REDO_NCHANGESUNDONE              = "redo.nChangesUndone",

   MSG_STATUS_ROW                       = "status.row",
   MSG_STATUS_COLUMN                    = "status.column",
   MSG_STATUS_INSERT                    = "status.insert",
   MSG_STATUS_REPLACE                   = "status.replace",
   MSG_STATUS_COMMAND                   = "status.command",
   MSG_STATUS_1CHANGE                   = "status.1change",
   MSG_STATUS_NCHANGES                  = "status.nchanges",
   MSG_STATUS_BROWSE                    = "status.browse",

   MSG_POPUP_CUT                        = "popup.cut",
   MSG_POPUP_COPY                       = "popup.copy",
   MSG_POPUP_PASTE                      = "popup.paste",
   MSG_POPUP_FINDSELECTION              = "popup.findSelection",
   MSG_POPUP_BLOCKMARKLINE              = "popup.blockMarkLine",
   MSG_POPUP_BLOCKMARKCHARACTER         = "popup.blockMarkCharacter",
   MSG_POPUP_BLOCKMARKRECTANGLE         = "popup.blockMarkRectangle",
   MSG_POPUP_BLOCKMARKALL               = "popup.blockMarkAll",
   MSG_POPUP_BLOCKUNMARK                = "popup.blockUnmark",
   MSG_POPUP_BLOCKCOPY                  = "popup.blockCopy",
   MSG_POPUP_BLOCKOVERLAY               = "popup.blockOverlay",
   MSG_POPUP_BLOCKMOVE                  = "popup.blockMove",
   MSG_POPUP_BLOCKDELETE                = "popup.blockDelete",
   MSG_POPUP_FILTERSELECTION            = "popup.filterSelection",
   MSG_POPUP_EXCLUDESELECTION           = "popup.excludeSelection",
   MSG_POPUP_FILTERVIEW                 = "popup.filterView",
   MSG_POPUP_SHOWALL                    = "popup.showAll",
   MSG_POPUP_ERRORS                     = "popup.errors",

   MSG_COMMAND_INVALID                  = "command.invalid",
   MSG_COMMAND_NOPARAMETERS             = "command.noParameters",
   MSG_COMMAND_INVALIDPARAMETER         = "command.invalidParameter",
   MSG_COMMAND_INCOMPLETE               = "command.incomplete",
   MSG_COMMAND_INVALID_QUOTED_PARAMETER = "command.invalidQuotedParameter",
   MSG_COMMAND_INTEGERMISSING           = "command.integerMissing",
   MSG_COMMAND_USER_COMMANDS_INVALID    = "command.userCommandsInvalid",

   MSG_FINDTEXTCOMMAND_NOFINDTEXT       = "findTextCommand.noFindText",
   MSG_FINDTEXTCOMMAND_INVALIDPATTERN   = "findTextCommand.invalidPattern",
   MSG_FINDTEXTCOMMAND_COLUMNSMISSING   = "findTextCommand.columnsMissing",
   MSG_FINDTEXTCOMMAND_ONLYOCCURRENCE   = "findTextCommand.onlyOccurrence",
   MSG_FINDTEXTCOMMAND_WRAPPED          = "findTextCommand.wrapped",
   MSG_FINDTEXTCOMMAND_NOTFOUND         = "findTextCommand.notFound",

   MSG_ACTION_KEYINVALID                = "action.keyInvalid",
   MSG_ACTION_MOUSEEVENTINVALID         = "action.mouseEventInvalid",
   MSG_ACTION_INVALID                   = "action.invalid",
   MSG_ACTION_USERACTIONSINVALID        = "action.userActionsInvalid",
   MSG_ACTION_KEYACTIONSINVALID         = "action.keyActionsInvalid",
   MSG_ACTION_MOUSEACTIONSINVALID       = "action.mouseActionsInvalid",
   MSG_ACTION_INCOMPLETE                = "action.incomplete",
   MSG_ACTION_CONTROL                   = "action.control",
   MSG_ACTION_ALT                       = "action.alt",
   MSG_ACTION_SHIFT                     = "action.shift",
   MSG_ACTION_META                      = "action.meta",

   MSG_FILE_CREATED                     = "file.created",
   MSG_FILE_NOT_FOUND                   = "file.notFound",
   MSG_FILE_ERROR_READING               = "file.errorReading",
   MSG_FILE_ERROR_WRITING               = "file.errorWriting",
   MSG_FILE_SAVE_NONAME                 = "file.saveNoName",
   MSG_FILE_SAVE_TRUNCATION             = "file.saveTruncation",

   MSG_FILEDIALOG_COMPARE               = "fileDialog.compare",
   MSG_FILEDIALOG_GET                   = "fileDialog.get",
   MSG_FILEDIALOG_SAVEAS                = "fileDialog.saveAs",

   MSG_LOCATECOMMAND_ELEMENTNOTFOUND        = "locateCommand.elementNotFound",
   MSG_LOCATECOMMAND_LINENOTFOUND           = "locateCommand.lineNotFound",
   MSG_LOCATECOMMAND_MARKNOTFOUND           = "locateCommand.markNotFound",
   MSG_LOCATECOMMAND_NOSEQUENCETEXT         = "locateCommand.noSequenceText",
   MSG_LOCATECOMMAND_SEQUENCENUMBERNOTFOUND = "locateCommand.sequenceNumberNotFound",
   MSG_LOCATECOMMAND_SEQUENCETEXTNOTFOUND   = "locateCommand.sequenceTextNotFound",

   MSG_PRINTCOMMAND_FONTMISSING             = "printCommand.fontMissing",

   MSG_CLASS_NOTFOUND                       = "class.notFound",
   MSG_CLASS_INVALID                        = "class.invalid",
   MSG_ENCODING_INVALID                     = "encoding.invalid",

   // command line buttons and fields
   MSG_COMMANDLINE_FIND                         = "commandLine.find",
   MSG_COMMANDLINE_NEXT                         = "commandLine.next",
   MSG_COMMANDLINE_PREV                         = "commandLine.prev",
   MSG_COMMANDLINE_ALL                          = "commandLine.all",
   MSG_COMMANDLINE_REPLACE                      = "commandLine.replace",
   MSG_COMMANDLINE_REPLACE_NEXT                 = "commandLine.replaceNext",
   MSG_COMMANDLINE_REPLACE_ALL                  = "commandLine.replaceAll",
   MSG_COMMANDLINE_CASE_SENSITIVE               = "commandLine.caseSensitive",
   MSG_COMMANDLINE_REGULAR_EXPRESSION           = "commandLine.regularExpression",
   MSG_COMMANDLINE_WRAP                         = "commandLine.wrap",
   MSG_COMMANDLINE_SELECT_FOUND_TEXT            = "commandLine.selectFoundText",
   MSG_COMMANDLINE_RESTRICT_SEARCH_TO_SELECTION = "commandLine.restrictSearchToSelection",
   MSG_COMMANDLINE_RESTRICT_SEARCH_TO_COLUMNS   = "commandLine.restrictSearchToColumns",
   MSG_COMMANDLINE_START_COLUMN                 = "commandLine.startColumn",
   MSG_COMMANDLINE_END_COLUMN                   = "commandLine.endColumn",
   MSG_COMMANDLINE_NAME_MARK                    = "commandLine.nameMark",
   MSG_COMMANDLINE_FIND_MARK                    = "commandLine.findMark",
   MSG_COMMANDLINE_FILL_CHARACTER               = "commandLine.fillCharacter",
   MSG_COMMANDLINE_FILE_NAME                    = "commandLine.fileName",
   MSG_COMMANDLINE_LINE_NUMBER                  = "commandLine.lineNumber",
   MSG_COMMANDLINE_SEQUENCE_NUMBER              = "commandLine.sequenceNumber",
   MSG_COMMANDLINE_SET_PARSER                   = "commandLine.setParser",

   MSG_MARK_1_LINE_EXCLUDED                     = "mark.1LineExcluded",
   MSG_MARK_N_LINES_EXCLUDED                    = "mark.nLinesExcluded",
   MSG_MARK_QUICK_MARK_SET                      = "mark.quickMarkSet",

   MSG_SEQUENCENUMBERS_RESEQUENCED              = "sequenceNumbers.resequenced",
   MSG_SEQUENCENUMBERS_OVERFLOW                 = "sequenceNumbers.overflow",
   MSG_SEQUENCENUMBERS_TOOBIG                   = "sequenceNumbers.tooBig",
   MSG_SEQUENCENUMBERS_OUTOFORDER               = "sequenceNumbers.outOfOrder",
   MSG_SEQUENCENUMBERS_SHOWELEMENT              = "sequenceNumbers.showElement",
   MSG_RESEQUENCECOMMAND_OVERFLOW               = "resequenceCommand.overflow",

   MSG_TEXTLIMIT_OVERFLOW                       = "textLimit.overflow",
   MSG_USERPROFILE_INVALID                      = "userProfile.invalid",
   MSG_CLASSNAME_INVALID                        = "className.invalid",

   MSG_COMPARE_NOMISMATCHES                     = "compare.noMismatches",
   MSG_COMPARE_MISMATCHES                       = "compare.mismatches",
   MSG_COMPARE_NOMOREMISMATCHES                 = "compare.noMoreMismatches",
   MSG_COMPARE_FILENOTFOUND                     = "compare.fileNotFound",

   MSG_VI_QUITUNSAVEDCHANGES                    = "vi.quitUnsavedChanges",
   MSG_VI_EDITUNSAVEDCHANGES                    = "vi.editUnsavedChanges",

   // Preferences dialogs
   MSG_PREFERENCES_TITLE                                = "preferences.title",
   MSG_PREFERENCES_OK                                   = "preferences.ok",
   MSG_PREFERENCES_CANCEL                               = "preferences.cancel",
   MSG_PREFERENCES_CHANGE                               = "preferences.change",
   MSG_PREFERENCES_HELP                                 = "preferences.help",
   MSG_PREFERENCES_APPLY                                = "preferences.apply",
   MSG_PREFERENCES_RESET                                = "preferences.reset",
   MSG_PREFERENCES_DEFAULT                              = "preferences.default",
   MSG_PREFERENCES_SET                                  = "preferences.set",
   MSG_PREFERENCES_DELETE                               = "preferences.delete",
   MSG_PREFERENCES_ROOT_TITLE                           = "preferences.rootTitle",
   MSG_PREFERENCES_ROOT_DESCRIPTION                     = "preferences.rootDescription",
   MSG_PREFERENCES_ROOT_EDITOR_PROFILE                  = "preferences.rootEditorProfile",
   MSG_PREFERENCES_ROOT_NO_PARSER                       = "preferences.rootNoParser",
   MSG_PREFERENCES_APPEARANCE_TITLE                     = "preferences.appearanceTitle",
   MSG_PREFERENCES_APPEARANCE_DESCRIPTION               = "preferences.appearanceDescription",
   MSG_PREFERENCES_FONT_TITLE                           = "preferences.fontTitle",
   MSG_PREFERENCES_FONT_DESCRIPTION                     = "preferences.fontDescription",
   MSG_PREFERENCES_FONT_NAME                            = "preferences.fontName",
   MSG_PREFERENCES_FONT_STYLE                           = "preferences.fontStyle",
   MSG_PREFERENCES_FONT_BOLD                            = "preferences.fontBold",
   MSG_PREFERENCES_FONT_ITALIC                          = "preferences.fontItalic",
   MSG_PREFERENCES_FONT_SIZE                            = "preferences.fontSize",
   MSG_PREFERENCES_FONT_SAMPLE                          = "preferences.fontSample",
   MSG_PREFERENCES_COMPARE_TITLE                        = "preferences.compareTitle",
   MSG_PREFERENCES_COMPARE_DESCRIPTION                  = "preferences.compareDescription",
   MSG_PREFERENCES_COMPARE_IGNORECASE                   = "preferences.compareIgnoreCase",
   MSG_PREFERENCES_COMPARE_IGNORELEADINGBLANKS          = "preferences.compareIgnoreLeadingBlanks",
   MSG_PREFERENCES_COMPARE_IGNORETRAILINGBLANKS         = "preferences.compareIgnoreTrailingBlanks",
   MSG_PREFERENCES_COMPARE_IGNOREALLBLANKS              = "preferences.compareIgnoreAllBlanks",
   MSG_PREFERENCES_CONTROLS_TITLE                       = "preferences.controlsTitle",
   MSG_PREFERENCES_CONTROLS_DESCRIPTION                 = "preferences.controlsDescription",
   MSG_PREFERENCES_CONTROLS_STATUSLINE                  = "preferences.controlsStatusLine",
   MSG_PREFERENCES_CONTROLS_FORMATLINE                  = "preferences.controlsFormatLine",
   MSG_PREFERENCES_CONTROLS_MESSAGELINE                 = "preferences.controlsMessageLine",
   MSG_PREFERENCES_CONTROLS_COMMANDLINE                 = "preferences.controlsCommandLine",
   MSG_PREFERENCES_CONTROLS_PREFIXAREA                  = "preferences.controlsPrefixArea",
   MSG_PREFERENCES_CONTROLS_HIDESEQUENCENUMBERS         = "preferences.controlsHideSequenceNumbers",
   MSG_PREFERENCES_CONTROLS_EXPANDHIDE                  = "preferences.controlsExpandHide",
   MSG_PREFERENCES_PARSERS_TITLE                        = "preferences.parsersTitle",
   MSG_PREFERENCES_PARSERS_DESCRIPTION                  = "preferences.parsersDescription",
   MSG_PREFERENCES_PARSERS_TABLENAME                    = "preferences.parsersTableName",
   MSG_PREFERENCES_PARSERS_TABLECLASSNAME               = "preferences.parsersTableClassName",
   MSG_PREFERENCES_PARSERS_NAME                         = "preferences.parsersName",
   MSG_PREFERENCES_PARSERS_CLASSNAME                    = "preferences.parsersClassName",
   MSG_PREFERENCES_TABS_TITLE                           = "preferences.tabsTitle",
   MSG_PREFERENCES_TABS_DESCRIPTION                     = "preferences.tabsDescription",
   MSG_PREFERENCES_TABS_TAB_STOPS                       = "preferences.tabsTabStops",
   MSG_PREFERENCES_TABS_TAB_INCREMENT                   = "preferences.tabsTabIncrement",
   MSG_PREFERENCES_TABS_EXPAND_TABS                     = "preferences.tabsExpandTabs",
   MSG_PREFERENCES_BLOCK_TITLE                          = "preferences.blockTitle",
   MSG_PREFERENCES_BLOCK_DESCRIPTION                    = "preferences.blockDescription",
   MSG_PREFERENCES_BLOCK_DEFAULT_TYPE                   = "preferences.blockDefaultType",
   MSG_PREFERENCES_FIND_TEXT_TITLE                      = "preferences.findTextTitle",
   MSG_PREFERENCES_FIND_TEXT_DESCRIPTION                = "preferences.findTextDescription",
   MSG_PREFERENCES_FIND_TEXT_ASIS                       = "preferences.findTextAsis",
   MSG_PREFERENCES_FIND_TEXT_BLOCK                      = "preferences.findTextBlock",
   MSG_PREFERENCES_FIND_TEXT_COLUMNS                    = "preferences.findTextColumns",
   MSG_PREFERENCES_FIND_TEXT_EMPHASIS                   = "preferences.findTextEmphasis",
   MSG_PREFERENCES_FIND_TEXT_END_COLUMN                 = "preferences.findTextEndColumn",
   MSG_PREFERENCES_FIND_TEXT_FIND_TEXT                  = "preferences.findTextFindText",
   MSG_PREFERENCES_FIND_TEXT_MARK                       = "preferences.findTextMark",
   MSG_PREFERENCES_FIND_TEXT_REGULAR_EXPRESSION         = "preferences.findTextRegularExpression",
   MSG_PREFERENCES_FIND_TEXT_REPLACE_TEXT               = "preferences.findTextReplaceText",
   MSG_PREFERENCES_FIND_TEXT_START_COLUMN               = "preferences.findTextStartColumn",
   MSG_PREFERENCES_FIND_TEXT_WRAP                       = "preferences.findTextWrap",
   MSG_PREFERENCES_PRINT_TITLE                          = "preferences.printTitle",
   MSG_PREFERENCES_PRINT_DESCRIPTION                    = "preferences.printDescription",
   MSG_PREFERENCES_PRINT_BOTTOM_MARGIN                  = "preferences.printBottomMargin",
   MSG_PREFERENCES_PRINT_LEFT_MARGIN                    = "preferences.printLeftMargin",
   MSG_PREFERENCES_PRINT_LINE_NUMBERS                   = "preferences.printLineNumbers",
   MSG_PREFERENCES_PRINT_RIGHT_MARGIN                   = "preferences.printRightMargin",
   MSG_PREFERENCES_PRINT_TOKENIZED                      = "preferences.printTokenized",
   MSG_PREFERENCES_PRINT_TOP_MARGIN                     = "preferences.printTopMargin",
   MSG_PREFERENCES_PRINT_FONT_TITLE                     = "preferences.printFontTitle",
   MSG_PREFERENCES_PRINT_FONT_DESCRIPTION               = "preferences.printFontDescription",
   MSG_PREFERENCES_PRINT_FONT_SCREEN                    = "preferences.printFontScreen",
   MSG_PREFERENCES_SAVE_TITLE                           = "preferences.saveTitle",
   MSG_PREFERENCES_SAVE_DESCRIPTION                     = "preferences.saveDescription",
   MSG_PREFERENCES_SAVE_TEXT_LIMIT                      = "preferences.saveTextLimit",
   MSG_PREFERENCES_SAVE_TRIM                            = "preferences.saveTrim",
   MSG_PREFERENCES_PARSER_ASSOCIATIONS_TITLE            = "preferences.parserAssociationsTitle",
   MSG_PREFERENCES_PARSER_ASSOCIATIONS_DESCRIPTION      = "preferences.parserAssociationsDescription",
   MSG_PREFERENCES_PARSER_ASSOCIATIONS_TABLEEXTENSION   = "preferences.parserAssociationsTableExtension",
   MSG_PREFERENCES_PARSER_ASSOCIATIONS_TABLEPARSER      = "preferences.parserAssociationsTableParser",
   MSG_PREFERENCES_PARSER_ASSOCIATIONS_EXTENSION        = "preferences.parserAssociationsExtension",
   MSG_PREFERENCES_PARSER_ASSOCIATIONS_PARSER           = "preferences.parserAssociationsParser",
   MSG_PREFERENCES_SEQUENCE_NUMBERS_TITLE               = "preferences.sequenceNumbersTitle",
   MSG_PREFERENCES_SEQUENCE_NUMBERS_DESCRIPTION         = "preferences.sequenceNumbersDescription",
   MSG_PREFERENCES_SEQUENCE_NUMBERS_COLUMN              = "preferences.sequenceNumbersNumColumn",
   MSG_PREFERENCES_SEQUENCE_NUMBERS_WIDTH               = "preferences.sequenceNumbersNumWidth",
   MSG_PREFERENCES_SEQUENCE_TEXT_COLUMN                 = "preferences.sequenceNumbersTextColumn",
   MSG_PREFERENCES_SEQUENCE_TEXT_WIDTH                  = "preferences.sequenceNumbersTextWidth",
   MSG_PREFERENCES_USER_ACTIONS_TITLE                   = "preferences.userActionsTitle",
   MSG_PREFERENCES_USER_ACTIONS_DESCRIPTION             = "preferences.userActionsDescription",
   MSG_PREFERENCES_USER_ACTIONS_TABLE_NAME              = "preferences.userActionsTableName",
   MSG_PREFERENCES_USER_ACTIONS_TABLE_CLASS_NAME        = "preferences.userActionsTableClassName",
   MSG_PREFERENCES_USER_ACTIONS_NAME                    = "preferences.userActionsName",
   MSG_PREFERENCES_USER_ACTIONS_CLASS_NAME              = "preferences.userActionsClassName",
   MSG_PREFERENCES_USER_COMMANDS_TITLE                  = "preferences.userCommandsTitle",
   MSG_PREFERENCES_USER_COMMANDS_DESCRIPTION            = "preferences.userCommandsDescription",
   MSG_PREFERENCES_USER_COMMANDS_TABLE_NAME             = "preferences.userCommandsTableName",
   MSG_PREFERENCES_USER_COMMANDS_TABLE_CLASS_NAME       = "preferences.userCommandsTableClassName",
   MSG_PREFERENCES_USER_COMMANDS_NAME                   = "preferences.userCommandsName",
   MSG_PREFERENCES_USER_COMMANDS_CLASS_NAME             = "preferences.userCommandsClassName",
   MSG_PREFERENCES_USER_PROFILE_TITLE                   = "preferences.userProfileTitle",
   MSG_PREFERENCES_USER_PROFILE_DESCRIPTION             = "preferences.userProfileDescription",
   MSG_PREFERENCES_USER_PROFILE_CLASS_NAME              = "preferences.userProfileClassName",
   MSG_PREFERENCES_POPUP_TITLE                          = "preferences.popupTitle",
   MSG_PREFERENCES_POPUP_DESCRIPTION                    = "preferences.popupDescription",
   MSG_PREFERENCES_POPUP_TEXT                           = "preferences.popupText",
   MSG_PREFERENCES_POPUP_ACTION                         = "preferences.popupAction",
   MSG_PREFERENCES_POPUP_MENU_ITEM                      = "preferences.popupMenuItem",
   MSG_PREFERENCES_POPUP_SUBMENU                        = "preferences.popupSubmenu",
   MSG_PREFERENCES_POPUP_SEPARATOR                      = "preferences.popupSeparator",
   MSG_PREFERENCES_POPUP_ADD_AFTER                      = "preferences.popupAddAfter",
   MSG_PREFERENCES_POPUP_ADD_AS_CHILD                   = "preferences.popupAddAsChild",
   MSG_PREFERENCES_USER_KEY_ACTIONS_TITLE               = "preferences.userKeyActionsTitle",
   MSG_PREFERENCES_USER_KEY_ACTIONS_DESCRIPTION         = "preferences.userKeyActionsDescription",
   MSG_PREFERENCES_USER_KEY_ACTIONS_TABLE_KEY           = "preferences.userKeyActionsTableKey",
   MSG_PREFERENCES_USER_KEY_ACTIONS_TABLE_ACTION        = "preferences.userKeyActionsTableAction",
   MSG_PREFERENCES_USER_KEY_ACTIONS_KEY                 = "preferences.userKeyActionsKey",
   MSG_PREFERENCES_USER_KEY_ACTIONS_ACTION              = "preferences.userKeyActionsAction",
   MSG_PREFERENCES_USER_MOUSE_ACTIONS_TITLE             = "preferences.userMouseActionsTitle",
   MSG_PREFERENCES_USER_MOUSE_ACTIONS_DESCRIPTION       = "preferences.userMouseActionsDescription",
   MSG_PREFERENCES_USER_MOUSE_ACTIONS_TABLE_MOUSE_EVENT = "preferences.userMouseActionsTableMouseEvent",
   MSG_PREFERENCES_USER_MOUSE_ACTIONS_TABLE_ACTION      = "preferences.userMouseActionsTableAction",
   MSG_PREFERENCES_USER_MOUSE_ACTIONS_MOUSE_EVENT       = "preferences.userMouseActionsMouseEvent",
   MSG_PREFERENCES_USER_MOUSE_ACTIONS_ACTION            = "preferences.userMouseActionsAction",
   MSG_PREFERENCES_PALETTE_TITLE                        = "preferences.paletteTitle",
   MSG_PREFERENCES_PALETTE_DESCRIPTION                  = "preferences.paletteDescription",
   MSG_PREFERENCES_PALETTE_PALETTE                      = "preferences.palettePalette",
   MSG_PREFERENCES_VIEW_ROOT_DESCRIPTION                = "preferences.viewRootDescription",
   MSG_PREFERENCES_VIEW_ROOT_NAME                       = "preferences.viewRootName",
   MSG_PREFERENCES_VIEW_PARSER_TITLE                    = "preferences.viewParserTitle",
   MSG_PREFERENCES_VIEW_PARSER_DESCRIPTION              = "preferences.viewParserDescription",
   MSG_PREFERENCES_VIEW_PARSER_PARSER                   = "preferences.viewParserParser",
   MSG_PREFERENCES_VIEW_SOURCE_ENCODING_TITLE           = "preferences.viewSourceEncodingTitle",
   MSG_PREFERENCES_VIEW_SOURCE_ENCODING_DESCRIPTION     = "preferences.viewSourceEncodingDescription",
   MSG_PREFERENCES_VIEW_SOURCE_ENCODING_SOURCE_ENCODING = "preferences.viewSourceEncodingSourceEncoding",

   MSG_PREFERENCES_INCORRECT_VALUE                      = "preferences.incorrectValue",

   // Accessibility strings
   MSG_ACCESSIBLE_DESC_STATUSLINE                       = "accessible.descStatusLine",
   MSG_ACCESSIBLE_DESC_STATUSROW                        = "accessible.descStatusRow",
   MSG_ACCESSIBLE_DESC_STATUSCOLUMN                     = "accessible.descStatusColumn",
   MSG_ACCESSIBLE_DESC_STATUSCHANGES                    = "accessible.descStatusChanges",
   MSG_ACCESSIBLE_DESC_STATUSINPUT                      = "accessible.descStatusInput",
   MSG_ACCESSIBLE_DESC_STATUSBROWSE                     = "accessible.descStatusBrowse",
   MSG_ACCESSIBLE_DESC_FORMATLINE                       = "accessible.descFormatLine",
   MSG_ACCESSIBLE_DESC_MESSAGELINE                      = "accessible.descMessageLine",
   MSG_ACCESSIBLE_DESC_COMMANDLINE                      = "accessible.descCommandLine",
   MSG_ACCESSIBLE_DESC_COMMANDENTRY                     = "accessible.descCommandEntry",
   MSG_ACCESSIBLE_DESC_TEXT                             = "accessible.descText",
   MSG_ACCESSIBLE_ROLE_STATUSLINE                       = "accessible.roleStatusLine",
   MSG_ACCESSIBLE_ROLE_FORMATLINE                       = "accessible.roleFormatLine",
   MSG_ACCESSIBLE_ROLE_MESSAGELINE                      = "accessible.roleMessageLine",
   MSG_ACCESSIBLE_ROLE_COMMANDLINE                      = "accessible.roleCommandLine";

  /**
   * LPEX parameter name.
   */
  public static final String
   PARAMETER_ACTION_ARGUMENT           = "actionArgument",
   PARAMETER_ACTION_CLASS              = "actionClass.",
   PARAMETER_ACTION_KEY                = "actionKey.",
   PARAMETER_ACTION_KEY_TEXT           = "actionKeyText.",
   PARAMETER_ACTION_REPEAT             = "actionRepeat",
   PARAMETER_ACTIONS                   = "actions",
   PARAMETER_AUTO_CHECK                = "autoCheck",
   PARAMETER_BASE_PROFILE              = "baseProfile",
   PARAMETER_BEEP                      = "beep",
   PARAMETER_BLOCK                     = "block.",
   PARAMETER_CHANGES                   = "changes",
   PARAMETER_CLASS                     = "class.",
   PARAMETER_CLASSES                   = "classes",
   PARAMETER_COMMAND_CLASS             = "commandClass.",
   PARAMETER_COMMAND_LINE              = "commandLine",
   PARAMETER_COMMANDS                  = "commands",
   PARAMETER_COMPARE                   = "compare.",
   PARAMETER_CURRENT                   = "current.",
   PARAMETER_CURRENT_KEY               = "currentKey",
   PARAMETER_CURSOR_BLINK              = "cursorBlink",
   PARAMETER_CURSOR_ROW                = "cursorRow",
   PARAMETER_DEFAULT                   = "default.",
   PARAMETER_DEFAULT_PROFILE           = "defaultProfile",
   PARAMETER_DIRTY                     = "dirty",
   PARAMETER_DISPLAY_POSITION          = "displayPosition",
   PARAMETER_DOCUMENT_ID               = "documentId",
   PARAMETER_ELEMENT                   = "element",
   PARAMETER_ELEMENT_CLASSES           = "elementClasses",
   PARAMETER_ELEMENTS                  = "elements",
   PARAMETER_EMPHASIS_LENGTH           = "emphasisLength",
   PARAMETER_EXCLUDED_CLASSES          = "excludedClasses",
   PARAMETER_EXPAND_HIDE               = "expandHide",
   PARAMETER_EXPAND_HIDE_AREA_WIDTH    = "expandHideAreaWidth",
   PARAMETER_EXPAND_TABS               = "expandTabs",
   PARAMETER_EXPANDED                  = "expanded",
   PARAMETER_FIELDS                    = "fields",
   PARAMETER_FIND_TEXT                 = "findText.",
   PARAMETER_FONT                      = "font",
   PARAMETER_FORCE_ALL_VISIBLE         = "forceAllVisible",
   PARAMETER_FORCE_VISIBLE             = "forceVisible",
   PARAMETER_FORMAT_LINE               = "formatLine",
   PARAMETER_FORMAT_LINE_TEXT          = "formatLineText",
   PARAMETER_HEADER_MARK               = "headerMark",
   PARAMETER_HELP                      = "help.",
   PARAMETER_HEX                       = "hex",
   PARAMETER_HIDE_SEQUENCE_NUMBERS     = "hideSequenceNumbers",
   PARAMETER_IN_PREFIX                 = "inPrefix",
   PARAMETER_INCLUDED_CLASSES          = "includedClasses",
   PARAMETER_INSERT_MODE               = "insertMode",
   PARAMETER_INSTALL                   = "install.",
   PARAMETER_INSTALL_PROFILE           = "installProfile",
   PARAMETER_KEY_ACTION                = "keyAction.",
   PARAMETER_KEYS                      = "keys",
   PARAMETER_LENGTH                    = "length",
   PARAMETER_LINE                      = "line",
   PARAMETER_LINES                     = "lines",
   PARAMETER_MAINTAIN_SEQUENCE_NUMBERS = "maintainSequenceNumbers",
   PARAMETER_MARK                      = "mark.",
   PARAMETER_MARK_EXCLUDED             = "markExcluded.",
   PARAMETER_MARK_EXCLUDED_HEADER      = "markExcludedHeader.",
   PARAMETER_MARK_HIGHLIGHT            = "markHighlight.",
   PARAMETER_MARK_ID                   = "markId.",
   PARAMETER_MARK_INCLUDED             = "markIncluded.",
   PARAMETER_MARK_PROTECT              = "markProtect.",
   PARAMETER_MARK_STYLE                = "markStyle.",
   PARAMETER_MESSAGE_LINE              = "messageLine",
   PARAMETER_MESSAGE_TEXT              = "messageText",
   PARAMETER_MOUSE_ACTION              = "mouseAction.",
   PARAMETER_MOUSE_EVENTS              = "mouseEvents",
   PARAMETER_NAME                      = "name",
   PARAMETER_PALETTE                   = "palette",
   PARAMETER_PARSER                    = "parser",
   PARAMETER_PIXEL_POSITION            = "pixelPosition",
   PARAMETER_POPUP                     = "popup",
   PARAMETER_POSITION                  = "position",
   PARAMETER_PREFIX_AREA               = "prefixArea",
   PARAMETER_PREFIX_AREA_TEXT          = "prefixAreaText",
   PARAMETER_PREFIX_AREA_WIDTH         = "prefixAreaWidth",
   PARAMETER_PREFIX_POSITION           = "prefixPosition",
   PARAMETER_PREFIX_PROTECT            = "prefixProtect",
   PARAMETER_PREFIX_TEXT               = "prefixText",
   PARAMETER_PRINT                     = "print.",
   PARAMETER_READONLY                  = "readonly",
   PARAMETER_RECORDING                 = "recording",
   PARAMETER_REPEAT                    = "repeat",
   PARAMETER_ROW_HEIGHT                = "rowHeight",
   PARAMETER_ROWS                      = "rows",
   PARAMETER_SAVE                      = "save.",
   PARAMETER_SCROLL                    = "scroll",
   PARAMETER_SEQUENCE_DEFAULT_TEXT     = "sequenceDefaultText",
   PARAMETER_SEQUENCE_NUMBER           = "sequenceNumber",
   PARAMETER_SEQUENCE_NUMBERS          = "sequenceNumbers",
   PARAMETER_SEQUENCE_NUMBERS_FORMAT   = "sequenceNumbersFormat",
   PARAMETER_SEQUENCE_TEXT             = "sequenceText",
   PARAMETER_SHIFT_IN_CHARACTER        = "shiftInCharacter",
   PARAMETER_SHIFT_OUT_CHARACTER       = "shiftOutCharacter",
   PARAMETER_SHOW                      = "show",
   PARAMETER_SHOW_SOSI                 = "showSosi",
   PARAMETER_SOURCE_ENCODING           = "sourceEncoding",
   PARAMETER_STATUS                    = "status",
   PARAMETER_STATUS_LINE               = "statusLine",
   PARAMETER_STYLE                     = "style",
   PARAMETER_STYLE_ATTRIBUTES          = "styleAttributes.",
   PARAMETER_SYSTEM_PROPERTY           = "systemProperty.",
   PARAMETER_TABS                      = "tabs",
   PARAMETER_TEXT                      = "text",
   PARAMETER_TEXT_AREA_WIDTH           = "textAreaWidth",
   PARAMETER_TEXT_WIDTH                = "textWidth",
   PARAMETER_TOP_EXPANDED              = "topExpanded",
   PARAMETER_UPDATE_PROFILE            = "updateProfile.",
   PARAMETER_USE_SOURCE_COLUMNS        = "useSourceColumns",
   PARAMETER_VERSION                   = "version",
   PARAMETER_VISIBLE                   = "visible";

  /**
   * LPEX <b>block.___</b> parameter.
   */
  public static final String
   BLOCK_PARAMETER_BOTTOM_ELEMENT  = "bottomElement",
   BLOCK_PARAMETER_BOTTOM_POSITION = "bottomPosition",
   BLOCK_PARAMETER_DEFAULT_TYPE    = "defaultType",
   BLOCK_PARAMETER_ELEMENT_TEXT    = "elementText",
   BLOCK_PARAMETER_IN_VIEW         = "inView",
   BLOCK_PARAMETER_TEXT            = "text",
   BLOCK_PARAMETER_TOP_ELEMENT     = "topElement",
   BLOCK_PARAMETER_TOP_POSITION    = "topPosition",
   BLOCK_PARAMETER_TYPE            = "type";

  /**
   * LPEX <b>compare.___</b> parameter.
   */
  public static final String
   COMPARE_PARAMETER_IGNOREALLBLANKS      = "ignoreAllBlanks",
   COMPARE_PARAMETER_IGNORECASE           = "ignoreCase",
   COMPARE_PARAMETER_IGNORELEADINGBLANKS  = "ignoreLeadingBlanks",
   COMPARE_PARAMETER_IGNORETRAILINGBLANKS = "ignoreTrailingBlanks";

  /**
   * LPEX <b>findText.___</b> parameter.
   */
  public static final String
   FIND_TEXT_PARAMETER_ASIS               = "asis",
   FIND_TEXT_PARAMETER_BLOCK              = "block",
   FIND_TEXT_PARAMETER_COLUMNS            = "columns",
   FIND_TEXT_PARAMETER_EMPHASIS           = "emphasis",
   FIND_TEXT_PARAMETER_END_COLUMN         = "endColumn",
   FIND_TEXT_PARAMETER_FIND_TEXT          = "findText",
   FIND_TEXT_PARAMETER_MARK               = "mark",
   FIND_TEXT_PARAMETER_REGULAR_EXPRESSION = "regularExpression",
   FIND_TEXT_PARAMETER_REPLACE_TEXT       = "replaceText",
   FIND_TEXT_PARAMETER_START_COLUMN       = "startColumn",
   FIND_TEXT_PARAMETER_WRAP               = "wrap";

  /**
   * LPEX <b>print.___</b> parameter.
   */
  public static final String
   PRINT_PARAMETER_BOTTOM_MARGIN = "bottomMargin",
   PRINT_PARAMETER_FONT          = "font",
   PRINT_PARAMETER_LEFT_MARGIN   = "leftMargin",
   PRINT_PARAMETER_LINE_NUMBERS  = "lineNumbers",
   PRINT_PARAMETER_RIGHT_MARGIN  = "rightMargin",
   PRINT_PARAMETER_TOKENIZED     = "tokenized",
   PRINT_PARAMETER_TOP_MARGIN    = "topMargin";

  /**
   * LPEX <b>save.___</b> parameter.
   */
  public static final String
   SAVE_PARAMETER_TEXT_LIMIT = "textLimit",
   SAVE_PARAMETER_TRIM       = "trim";

  /**
   * LPEX <b>updateProfile.___</b> parameter.
   */
  public static final String
   UPDATE_PROFILE_PARAMETER_BASE_PROFILE       = "baseProfile",
   UPDATE_PROFILE_PARAMETER_EXTENSIONS         = "extensions",
   UPDATE_PROFILE_PARAMETER_NO_PARSER          = "noParser",
   UPDATE_PROFILE_PARAMETER_PALETTE            = "palette",
   UPDATE_PROFILE_PARAMETER_PALETTE_ATTRIBUTES = "paletteAttributes.",
   UPDATE_PROFILE_PARAMETER_PALETTES           = "palettes",
   UPDATE_PROFILE_PARAMETER_PARSER             = "parser",
   UPDATE_PROFILE_PARAMETER_PARSER_ASSOCIATION = "parserAssociation.",
   UPDATE_PROFILE_PARAMETER_PARSER_CLASS       = "parserClass.",
   UPDATE_PROFILE_PARAMETER_PARSERS            = "parsers",
   UPDATE_PROFILE_PARAMETER_STRICT_EXTENSION   = "strictExtension",
   UPDATE_PROFILE_PARAMETER_USER_ACTIONS       = "userActions",
   UPDATE_PROFILE_PARAMETER_USER_COMMANDS      = "userCommands",
   UPDATE_PROFILE_PARAMETER_USER_KEY_ACTIONS   = "userKeyActions",
   UPDATE_PROFILE_PARAMETER_USER_MOUSE_ACTIONS = "userMouseActions",
   UPDATE_PROFILE_PARAMETER_USER_PROFILE       = "userProfile";

  /**
   * Internal value for the LPEX <b>status</b> parameter.
   */
  public static final String
   STATUS_FINDTEXT_INVALIDPATTERN = "findText.invalidPattern",
   STATUS_FINDTEXT_NOTFOUND       = "findText.notFound",
   STATUS_FINDTEXT_ONLYOCCURRENCE = "findText.onlyOccurrence",
   STATUS_FINDTEXT_READONLY       = "findText.readOnly",
   STATUS_FINDTEXT_WRAPPED        = "findText.wrapped",
   STATUS_LOCATE_NOSEQUENCETEXT   = "locate.noSequenceText",
   STATUS_LOCATE_NOTFOUND         = "locate.notFound",
   STATUS_LOCATE_WRAPPED          = "locate.wrapped",
   STATUS_SAVE_CANCELLED          = "save.cancelled",
   STATUS_SAVE_FAILED             = "save.failed",
   STATUS_FILE_ERRORREADING       = "file.errorReading",
   STATUS_FILE_NOTFOUND           = "file.notFound";

  /**
   * Help constant.
   */
  public static final String
   MSG_HELP_OPEN                  = "help.status.open",
   MSG_HELP_ERROR                 = "help.status.error",

   HELP_PARAMETER_CONFIGURATION   = "configuration",
   HELP_PARAMETER_HOMEPAGE        = "homepage",
   HELP_PARAMETER_LOCATION        = "location",
   HELP_DEFAULT_PROPERTIES_FILE   = "contextHelp.properties",
   HELP_COMMAND_MAP               = "HelpCommand.properties",
   HELP_PREFERENCE_PANELS         = "preferencesHelp.properties",
   HELP_COMPARE_PANEL             = "compare.panel",
   HELP_BLOCK_PANEL               = "block.panel",
   HELP_CONTROLS_PANEL            = "controls.panel",
   HELP_FINDTEXT_PANEL            = "findtext.panel",
   HELP_FONT_PANEL                = "font.panel",
   HELP_PALETTE_PANEL             = "palette.panel",
   HELP_PARSERASSOCIATIONS_PANEL  = "parserassociations.panel",
   HELP_PARSERS_PANEL             = "parsers.panel",
   HELP_POPUP_PANEL               = "popup.panel",
   HELP_PRINTFONT_PANEL           = "printfont.panel",
   HELP_PRINT_PANEL               = "print.panel",
   HELP_ROOT_PANEL                = "root.panel",
   HELP_SAVE_PANEL                = "save.panel",
   HELP_SEQUENCENUMBERS_PANEL     = "sequencenumbers.panel",
   HELP_TABS_PANEL                = "tabs.panel",
   HELP_USERACTIONS_PANEL         = "useractions.panel",
   HELP_USERCOMMANDS_PANEL        = "usercommands.panel",
   HELP_USERKEYACTIONS_PANEL      = "userkeyactions.panel",
   HELP_USERMOUSEACTIONS_PANEL    = "usermouseactions.panel",
   HELP_USERPROFILE_PANEL         = "userprofile.panel",
   HELP_VIEWPARSER_PANEL          = "viewparser.panel",
   HELP_VIEWROOT_PANEL            = "viewroot.panel",
   HELP_VIEWSAVE_PANEL            = "viewsave.panel",
   HELP_VIEWSEQUENCENUMBERS_PANEL = "viewsequencenumbers.panel",
   HELP_VIEWSOURCEENCODING_PANEL  = "viewsourceencoding.panel",
   HELP_HEXEDITLINE_DIALOG        = "hexeditline.panel";

  /**
   * Name of a file that maps document-parser tokens to help panels.
   */
  public static final String
   HELP_CCPP                      = "ccppHelp.properties",
   HELP_COBOL                     = "cobolHelp.properties",
   HELP_JAVA                      = "javaHelp.properties",
   HELP_JCL                       = "jclHelp.properties",
   HELP_HLASM                     = "hlasmHelp.properties",
   HELP_PLI                       = "pliHelp.properties",
   HELP_SQL                       = "sqlHelp.properties";
 }