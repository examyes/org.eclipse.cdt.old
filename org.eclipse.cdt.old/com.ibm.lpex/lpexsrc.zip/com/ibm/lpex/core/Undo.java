//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Undo - handles the record/undo/redo of text changes in a Document.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import com.ibm.lpex.core.List.Node;

/**
 * This class is used to record/undo/redo text changes in a Document.
 */
final class Undo
{
 private Document _document;
 private List     _undoableChanges;
 private UndoableChange _currentChange;
 private UndoableChange _currentUndo;
 private boolean _recording = true;
 private boolean _undoing;
 private int     _changes;
 private boolean _lastChangeWasYank;


 Undo(Document document)
  {
   _document = document;
   clear();
  }

 void clear()
  {
   _undoableChanges = new List();
   _currentChange = null;
   _currentUndo = null;
   _undoing = false;
   _changes = 0;
   _lastChangeWasYank = false;
  }

 private void prepareForRecord(View view)
  {
   prepareForRecord(view, view.documentPosition().element(),
                    view.documentPosition().position());
  }

 private void prepareForRecord(View view, Element element, int position)
  {
   if (_currentUndo != null)
    {
     // something has been undone, create a new undoable change for the undo
     new UndoableChange(view, _currentUndo);
     _currentUndo = null;
    }

   // if we still don't have a current change, create one
   if (_currentChange == null)
    {
     _currentChange = new UndoableChange(view, null);
    }

   int userActionId = view.actionHandler().userActionId();
   _lastChangeWasYank = userActionId == LpexConstants.ACTION_YANK ||
                        userActionId == LpexConstants.ACTION_YANK_PREVIOUS;
  }

 private void verifyViChange(Document document)
  {
   for (View view = document._firstView; view != null; view = view._next)
    {
     if (view.vi())
      {
       view.viHandler().verifyChange();
      }
    }
  }

 void recordInsert(View view, Element element)
  {
   if (!element.show())
    {
     verifyViChange(view.document());
    }
   if (recording() && !_undoing && !element.show())
    {
     _document.resetUserActionElements();
     prepareForRecord(view);
     _currentChange.recordInsert(element);
    }
  }

 void recordChange(View view, Element element)
  {
   recordChange(view, element, 1);
  }

 void recordChange(View view, Element element, int position)
  {
   if (!element.show())
    {
     verifyViChange(view.document());
    }

   if (recording() && !_undoing && !element.show())
    {
     _document.verifyUserActionElements(element);
     prepareForRecord(view, element, position);
     _currentChange.recordChange(element);
     recordPosition(element, position);
    }
  }

 void recordDelete(View view, Element element)
  {
   if (!element.show())
    {
     verifyViChange(view.document());
    }

   if (recording() && !_undoing && !element.show())
    {
     _document.resetUserActionElements();
     prepareForRecord(view);
     if (_currentChange != null)
      {
       _currentChange.recordDelete(element);
      }
    }
   else
    {
     for (UndoableChange undoableChange = (UndoableChange) _undoableChanges.first();
          undoableChange != null;
          undoableChange = (UndoableChange) undoableChange.next())
      {
       undoableChange.unrecordedDelete(view, element);
      }
    }
  }

 void recordPosition(View view)
  {
   recordPosition(view.documentPosition().element(),
                  view.documentPosition().position());
  }

 void recordPosition(Element element, int position)
  {
   if (recording() && !_undoing && _currentChange != null)
    {
     _currentChange.recordPosition(element, position);
    }
  }

 void check(View view)
  {
   verifyViChange(view.document());
   if (_currentChange != null && _currentUndo == null)
    {
     _currentChange.check(view);
     if (_changes < 0)
      {
       _changes = - _changes;
      }
     _changes++;
     _currentChange = null;
    }

   _document.resetUserActionElements();
  }

 void resetChanges(View view)
  {
   check(view);
   _changes = 0;
  }

 void undo(View view)
  {
   undo(view, 1, false, false);
  }

 void undo(View view, int count)
  {
   undo(view, count, false, false);
  }

 void undo(View view, int count, boolean quiet, boolean discard)
  {
   _lastChangeWasYank = false;
   check(view);

   if (count > 0)
    {
     UndoableChange newCurrentUndo;

     if (_currentUndo != null)
      {
       if (_currentUndo.next() == null)
        {
         if (!quiet)
          {
           view.setLpexMessageText(LpexConstants.MSG_UNDO_NOMORECHANGES);
          }
         return;
        }
       newCurrentUndo = (UndoableChange)_currentUndo.next();
      }
     else if (_undoableChanges.first() != null)
      {
       newCurrentUndo = (UndoableChange) _undoableChanges.first();
      }
     else
      {
       if (!quiet)
        {
         view.setLpexMessageText(LpexConstants.MSG_UNDO_NORECORDEDCHANGES);
        }
       return;
      }

     while (count > 0 && newCurrentUndo != null)
      {
       _undoing = true;
       newCurrentUndo.undo(view);
       _undoing = false;
       count--;
       _currentUndo = newCurrentUndo;
       newCurrentUndo = (UndoableChange)newCurrentUndo.next();
       if (discard)
        {
         _undoableChanges.remove(_currentUndo);
         _currentUndo = null;
        }
      }

     if (!quiet)
      {
       // count the number of changes that are undone
       int i = 0;
       for (Node curr = _currentUndo; curr != null; curr = curr.prev())
        {
         i++;
        }

       if (newCurrentUndo == null)
        {
         view.setLpexMessageText(LpexConstants.MSG_UNDO_DOCUMENTATORIGINALSTATE);
        }
       else if (i == 1)
        {
         view.setLpexMessageText(LpexConstants.MSG_UNDO_1CHANGEUNDONE);
        }
       else
        {
         view.setLpexMessageText(LpexConstants.MSG_UNDO_NCHANGESUNDONE, i);
        }
      }
    }
  }

 void redo(View view)
  {
   redo(view, 1, false);
  }

 void redo(View view, int count)
  {
   redo(view, count, false);
  }

 void redo(View view, int count, boolean quiet)
  {
   _lastChangeWasYank = false;
   check(view);
   if (count > 0)
    {
     if (_currentUndo == null)
      {
       if (!quiet)
        {
         view.setLpexMessageText(LpexConstants.MSG_REDO_NOREDOABLECHANGES);
        }
       return;
      }

     while (count > 0 && _currentUndo != null)
      {
       _undoing = true;
       _currentUndo.redo(view);
       _undoing = false;
       count--;
       _currentUndo = (UndoableChange)_currentUndo.prev();
      }

     if (!quiet)
      {
       // count the number of changes that are undone
       int i = 0;
       for (Node curr = _currentUndo; curr != null; curr = curr.prev())
        {
         i++;
        }

       if (i == 0)
        {
         view.setLpexMessageText(LpexConstants.MSG_REDO_ALLCHANGESREDONE);
        }
       else if (i == 1)
        {
         view.setLpexMessageText(LpexConstants.MSG_REDO_1CHANGEUNDONE);
        }
       else
        {
         view.setLpexMessageText(LpexConstants.MSG_REDO_NCHANGESUNDONE, i);
        }
      }
    }
  }

 boolean redoAvailable()
  {
   return _currentUndo != null;
  }

 boolean undoAvailable()
  {
   if (!recording())
    {
     return false;
    }

   if (_currentUndo != null)
    {
     return _currentUndo.next() != null;
    }

   return _undoableChanges.first() != null;
  }

 void setRecording(boolean recording)
  {
   _recording = recording;
  }

 boolean recording()
  {
   return _recording;
  }

 boolean dirty()
  {
   return _currentChange != null && _currentUndo == null;
  }

 int changes()
  {
   return Math.abs(_changes);
  }

 boolean jumpAvailable()
  {
   return _currentUndo != null || _undoableChanges.first() != null;
  }

 void jump(View view)
  {
   if (_currentUndo != null)
    {
     _currentUndo.jump(view);
     return;
    }

   if (_undoableChanges.first() != null)
    {
     ((UndoableChange)(_undoableChanges.first())).jump(view);
    }
  }

 void setDefaults(View view)
  {
   for (UndoableChange undoableChange = (UndoableChange)_undoableChanges.first();
        undoableChange != null;
        undoableChange = (UndoableChange)undoableChange.next())
    {
     undoableChange.setDefaults(view);
    }
  }

 void disposeView(View view)
  {
   for (UndoableChange undoableChange = (UndoableChange)_undoableChanges.first();
        undoableChange != null;
        undoableChange = (UndoableChange)undoableChange.next())
    {
     undoableChange.disposeView(view);
    }
  }

 void expandAll(View view, boolean expanded)
  {
   for (UndoableChange undoableChange = (UndoableChange)_undoableChanges.first();
        undoableChange != null;
        undoableChange = (UndoableChange)undoableChange.next())
    {
     undoableChange.expandAll(view, expanded);
    }
  }

 boolean lastChangeWasYank()
  {
   return _lastChangeWasYank;
  }


 /**
  * Represents one undoable change.
  */
 private final class UndoableChange extends ListNode
  {
   List           _recordedInserts;
   List           _recordedDeletes;
   List           _recordedChanges;

   boolean        _undone;

   int            _startPosition;
   Element        _startElement;
   int            _endPosition;
   Element        _endElement;

   UndoableChange _undoableChange;


   UndoableChange(View view, UndoableChange undoableChange)
    {
     _startPosition = view.documentPosition().position();
     _startElement = view.documentPosition().element();
     _undoableChange = undoableChange;
     _undoableChanges.addAfter(null, this);
    }

   void undo(View view)
    {
     if (_undone)
      {
       return; // already undone... error
      }

     // first restore all of the deleted elements
     if (_recordedDeletes != null)
      {
       for (RecordedDelete recordedDelete = (RecordedDelete) _recordedDeletes.first();
            recordedDelete != null;
            recordedDelete = (RecordedDelete) recordedDelete.next())
        {
         recordedDelete.undelete(view);
        }
      }

     // now restore changed elements
     if (_recordedChanges != null)
      {
       for (RecordedChange recordedChange = (RecordedChange)_recordedChanges.first();
            recordedChange != null;
            recordedChange = (RecordedChange)recordedChange.next())
        {
         recordedChange.restore(view);
        }
      }

     // now delete all of the inserted elements
     if (_recordedInserts != null)
      {
       for (RecordedInsert recordedInsert = (RecordedInsert)_recordedInserts.first();
            recordedInsert != null;
            recordedInsert = (RecordedInsert)recordedInsert.next())
        {
         recordedInsert.uninsert(view);
        }
      }

     // move from the saved undoable change until we get to "this"
     if (_undoableChange != null)
      {
       for (UndoableChange current = _undoableChange;
            current != null && current != this;
            current = (UndoableChange)current.prev())
        {
         current.redo(view);
        }
      }

     _undone = true;
     if (_undoableChange == null)
      {
       _changes--;
      }

     jump(view);
    }

   void redo(View view)
    {
     if (!_undone)
      {
       return; // not undone... error
      }

     if (_undoableChange != null)
      {
       // move from the next undoable change to the saved undoable change
       for (UndoableChange current = (UndoableChange)next();
            current != null;
            current = (UndoableChange)current.next())
        {
         current.undo(view);
         if (current == _undoableChange)
            break;
        }
      }

     // first reinsert all of the uninserted elements
     if (_recordedInserts != null)
      {
       for (RecordedInsert recordedInsert = (RecordedInsert)_recordedInserts.last();
            recordedInsert != null;
            recordedInsert = (RecordedInsert)recordedInsert.prev())
        {
         recordedInsert.reinsert(view);
        }
      }

     // now restore changed elements
     if (_recordedChanges != null)
      {
       for (RecordedChange recordedChange = (RecordedChange)_recordedChanges.last();
            recordedChange != null;
            recordedChange = (RecordedChange)recordedChange.prev())
        {
         recordedChange.restore(view);
        }
      }

     // next redelete all of the undeleted elements
     if (_recordedDeletes != null)
      {
       for (RecordedDelete recordedDelete = (RecordedDelete)_recordedDeletes.last();
            recordedDelete != null;
            recordedDelete = (RecordedDelete)recordedDelete.prev())
        {
         recordedDelete.redelete(view);
        }
      }

     _undone = false;
     if (_undoableChange == null)
      {
       _changes++;
      }

     jump(view);
    }

   void recordInsert(Element element)
    {
     new RecordedInsert(element);
    }

   void recordDelete(Element element)
    {
     new RecordedDelete(element);
    }

   void recordChange(Element element)
    {
     // if this element was already recorded, then do nothing
     if (!element.recorded())
      {
       new RecordedChange(element);
      }
    }

   void recordPosition(Element element, int position)
    {
     _endElement = element;
     _endPosition = position;
    }

   void check(View view)
    {
     if (_recordedChanges != null)
      {
       for (RecordedChange recordedChange = (RecordedChange)_recordedChanges.first();
            recordedChange != null;
            recordedChange = (RecordedChange)recordedChange.next())
        {
         recordedChange.element().setRecorded(false);
        }
      }

     if (_recordedInserts != null)
      {
       for (RecordedInsert recordedInsert = (RecordedInsert)_recordedInserts.first();
            recordedInsert != null;
            recordedInsert = (RecordedInsert)recordedInsert.next())
        {
         recordedInsert.element().setRecorded(false);
        }
      }
    }

   void unrecordedDelete(View view, Element element)
    {
     if (_startElement == element)
      {
       _startElement = null;
      }

     if (_endElement == element)
      {
       _endElement = null;
      }

     if (element.recordedNext())
      {
       // a deleted element was recorded with this element as its previous element

       // search our list of recorded deletes and ensure the the element being
       // deleted isn't the "prev" element for any of these deletes
       if (_recordedDeletes != null)
        {
         for (RecordedDelete recordedDelete = (RecordedDelete)_recordedDeletes.last();
              recordedDelete != null;
              recordedDelete = (RecordedDelete)recordedDelete.prev())
          {
           recordedDelete.unrecordedDelete(element);
          }
        }

       // search our list of recorded inserts and ensure that the element being
       // deleted isn't the "prev" element for any uninserted elements
       if (_recordedInserts != null)
        {
         for (RecordedInsert recordedInsert = (RecordedInsert)_recordedInserts.first();
              recordedInsert != null;
              recordedInsert = (RecordedInsert)recordedInsert.next())
          {
           recordedInsert.unrecordedDelete(element);
          }
        }
      }

     if (element.recordedChange())
      {
       // there is at least one recorded change
       if (_recordedChanges != null)
        {
         RecordedChange recordedChange;
         for (recordedChange = (RecordedChange)_recordedChanges.first();
              recordedChange != null && recordedChange.element() != element;
              recordedChange = (RecordedChange) recordedChange.next()) {;}
         if (recordedChange != null)
          {
           _recordedChanges.remove(recordedChange);
          }
        }
      }

     if (element.recordedInsert())
      {
       // this element has a recorded insert
       if (_recordedInserts != null)
        {
         RecordedInsert recordedInsert;
         for (recordedInsert = (RecordedInsert)_recordedInserts.first();
              recordedInsert != null && recordedInsert.element() != element;
              recordedInsert = (RecordedInsert)recordedInsert.next()) {;}

         if (recordedInsert != null)
          {
           _recordedInserts.remove(recordedInsert);
          }

         element.setRecordedInsert(false); // there can be only one
        }
      }

     if (element.recordedDelete())
      {
       // this element has a recorded delete (but may have been undeleted)
       if (_recordedDeletes != null)
        {
         RecordedDelete recordedDelete;
         for (recordedDelete = (RecordedDelete) _recordedDeletes.first();
              recordedDelete != null && recordedDelete.element() != element;
              recordedDelete = (RecordedDelete)recordedDelete.next()) {;}

         if (recordedDelete != null)
          {
           _recordedDeletes.remove(recordedDelete);
          }
        }
      }
    }

   void setDefaults(View view)
    {
     // go through the deleted elements
     if (_recordedDeletes != null)
      {
       for (RecordedDelete deleted = (RecordedDelete)_recordedDeletes.first();
            deleted != null;
            deleted = (RecordedDelete)deleted.next())
        {
         if (!deleted.undeleted())
          {
           deleted.element().setDefaults(view);
          }
        }
      }

     // go through inserted elements
     if (_recordedInserts != null)
      {
       for (RecordedInsert inserted = (RecordedInsert)_recordedInserts.first();
            inserted != null;
            inserted = (RecordedInsert)inserted.next())
        {
         if (inserted.uninserted())
          {
           inserted.element().setDefaults(view);
          }
        }
      }
    }

   void disposeView(View view)
    {
     // go through the deleted elements
     if (_recordedDeletes != null)
      {
       for (RecordedDelete deleted = (RecordedDelete)_recordedDeletes.first();
            deleted != null;
            deleted = (RecordedDelete)deleted.next())
        {
         if (!deleted.undeleted())
          {
           deleted.element().disposeView(view);
          }
        }
      }

     // go through inserted elements
     if (_recordedInserts != null)
      {
       for (RecordedInsert inserted = (RecordedInsert)_recordedInserts.first();
            inserted != null;
            inserted = (RecordedInsert)inserted.next())
        {
         if (inserted.uninserted())
          {
           inserted.element().disposeView(view);
          }
        }
      }
    }

   void expandAll(View view, boolean expanded)
    {
     // go through the deleted elements
     if (_recordedDeletes != null)
      {
       for (RecordedDelete deleted = (RecordedDelete)_recordedDeletes.first();
            deleted != null;
            deleted = (RecordedDelete)deleted.next())
        {
         if (!deleted.undeleted())
          {
           deleted.element().elementView(view).setExpanded(expanded);
          }
        }
      }

     // go through inserted elements
     if (_recordedInserts != null)
      {
       for (RecordedInsert inserted = (RecordedInsert)_recordedInserts.first();
            inserted != null;
            inserted = (RecordedInsert)inserted.next())
        {
         if (inserted.uninserted())
          {
           inserted.element().elementView(view).setExpanded(expanded);
          }
        }
      }
    }

   void jump(View view)
    {
     if (!_undone)
      {
       if (_undoableChange  != null &&
           _recordedInserts == null &&
           _recordedDeletes == null &&
           _recordedChanges == null)
        {
         _undoableChange.jump(view);
        }
       else if (_endElement != null)
        {
         view.documentPosition().jump(_endElement, _endPosition);
        }
      }

     else
      {
       if (_undoableChange != null)
        {
         ((UndoableChange)next()).jump(view);
        }
       else if (_startElement != null)
        {
         view.documentPosition().jump(_startElement, _startPosition);
        }
      }
    }


   /**
    * Base class for an undo record.
    */
   private abstract class RecordedElement extends ListNode
   {
    private Element _element;

    protected RecordedElement(Element element)
    {
     _element = element;
    }

    Element element()
    {
     return _element;
    }
   }


   /**
    * Record for an INSERTED element.
    */
   private final class RecordedInsert extends RecordedElement
   {
    private boolean _uninserted;
    private Element _prevElement;

    RecordedInsert(Element element)
    {
     super(element);
     if (_recordedInserts == null)
      {
       _recordedInserts = new List();
      }
     _recordedInserts.addAfter(null, this);
     _uninserted = false;
     element().setRecorded(true);
     element().setRecordedInsert(true);
    }

    void uninsert(View view)
    {
     if (!_uninserted)
      {
       _prevElement = element().prev();
       _document.elementList().remove(view, element());
       _uninserted = true;

       if (_prevElement != null)
        {
         _prevElement.setRecordedNext(true);
        }
      }
    }

    void reinsert(View view)
    {
     if (_uninserted)
      {
       _document.elementList().addAfter(view, _prevElement, element(), true);
       _uninserted = false;
       _prevElement = null;
      }
    }

    boolean uninserted()
    {
     return _uninserted;
    }

    void unrecordedDelete(Element element)
    {
     if (_uninserted && element == _prevElement)
      {
       _prevElement = element.prev();

       if (_recordedInserts != null)
        {
         for (RecordedInsert recordedInsert = (RecordedInsert) _recordedInserts.last();
              recordedInsert != this && recordedInsert != null;
              recordedInsert = (RecordedInsert) recordedInsert.prev())
          {
           if (_prevElement == recordedInsert._prevElement)
            {
             _prevElement = recordedInsert.element();
            }
          }
        }

       if (_prevElement != null)
        {
         _prevElement.setRecordedNext(true);
        }
      }
    }
   }


   /**
    * Record for a DELETED element.
    */
   private final class RecordedDelete extends RecordedElement
   {
    private boolean _undeleted;
    private Element _prevElement;

    RecordedDelete(Element element)
    {
     super(element);
     if (_recordedDeletes == null)
      {
       _recordedDeletes = new List();
      }

     _recordedDeletes.addAfter(null, this);
     _undeleted = false;
     element.setRecordedDelete(true);

     _prevElement = element.prev();
     if (_prevElement != null)
      {
       _prevElement.setRecordedNext(true);
      }
    }

    void undelete(View view)
    {
     if (!_undeleted)
      {
       _document.elementList().addAfter(view, _prevElement, element(), true);
       _prevElement = null;
       _undeleted = true;
      }
    }

    void redelete(View view)
    {
     if (_undeleted)
      {
       _prevElement = element().prev();
       _document.elementList().remove(view, element());
       _undeleted = false;

       if (_prevElement != null)
        {
         _prevElement.setRecordedNext(true);
        }
      }
    }

    boolean undeleted()
    {
     return _undeleted;
    }

    void unrecordedDelete(Element element)
    {
     if (!_undeleted && element == _prevElement)
      {
       _prevElement = element.prev();
       if (_recordedDeletes != null)
        {
         for (RecordedDelete recordedDelete = (RecordedDelete) _recordedDeletes.first();
              recordedDelete != this && recordedDelete != null;
              recordedDelete = (RecordedDelete) recordedDelete.next())
          {
           if (_prevElement == recordedDelete._prevElement)
            {
             _prevElement = recordedDelete.element();
            }
          }
        }

       if (_prevElement != null)
        {
         _prevElement.setRecordedNext(true);
        }
      }
    }
   }


   /**
    * Record for a CHANGED element.
    */
   private final class RecordedChange extends RecordedElement
   {
    String _savedText;
    String _savedSequenceText;

    RecordedChange(Element element)
    {
     super(element);
     if (_recordedChanges == null)
      {
       _recordedChanges = new List();
      }

     _recordedChanges.addAfter(null, this);
     _savedText = element.text();
     _savedSequenceText = element.sequenceText();
     element.setRecorded(true);
     element.setRecordedChange(true);
    }

    void restore(View view)
    {
     String text = element().text();
     String sequenceText = element().sequenceText();

     element().setText(view, _savedText);
     element().setSequenceText(_savedSequenceText);
     // the recorded change may be replace(s) / insert(s) / a combo of these -
     // for now, notify of an entire-element replacement, which conveniently
     // includes the sequence numbers (currently there is no way to find more
     // fine detail reliably on the change...)
     _document.elementReplaced(view, element());

     _savedText = text;
     _savedSequenceText = sequenceText;
    }

    void setDefaults(View view) {} //*as* needed? extends anything??
   }
  }
}