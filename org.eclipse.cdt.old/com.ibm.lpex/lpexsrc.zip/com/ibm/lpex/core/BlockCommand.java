//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// BlockCommand - handles the block command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>block</b> command.
 * It handles blocks inside the document section that is currently loaded in
 * the editor.
 */
final class BlockCommand
{
 // internal block.xxx parameter ids
 private static final int
  BOTTOM_ELEMENT  = 1,
  BOTTOM_POSITION = 2,
  DEFAULT_TYPE    = 3,
  ELEMENT_TEXT    = 4,
  IN_VIEW         = 5,
  TEXT            = 6,
  TOP_ELEMENT     = 7,
  TOP_POSITION    = 8,
  TYPE            = 9;

 // NB The block parameters must be in alphabetical order for binary search.
 private static TableNode[] _parameters =
  {
   new TableNode(LpexConstants.BLOCK_PARAMETER_BOTTOM_ELEMENT,  BOTTOM_ELEMENT),
   new TableNode(LpexConstants.BLOCK_PARAMETER_BOTTOM_POSITION, BOTTOM_POSITION),
   new TableNode(LpexConstants.BLOCK_PARAMETER_DEFAULT_TYPE,    DEFAULT_TYPE),
   new TableNode(LpexConstants.BLOCK_PARAMETER_ELEMENT_TEXT,    ELEMENT_TEXT),
   new TableNode(LpexConstants.BLOCK_PARAMETER_IN_VIEW,         IN_VIEW),
   new TableNode(LpexConstants.BLOCK_PARAMETER_TEXT,            TEXT),
   new TableNode(LpexConstants.BLOCK_PARAMETER_TOP_ELEMENT,     TOP_ELEMENT),
   new TableNode(LpexConstants.BLOCK_PARAMETER_TOP_POSITION,    TOP_POSITION),
   new TableNode(LpexConstants.BLOCK_PARAMETER_TYPE,            TYPE)
  };


 /**
  * Retrieve the Parameter object handling the particular
  * <b>block.xxx</b> parameter.
  */
 static Parameter getParameter(String parameter)
  {
   TableNode p = TableNode.binarySearch(_parameters, Parameters.getParameterString(parameter));
   if (p != null)
    {
     switch (p.id())
      {
       case BOTTOM_ELEMENT:
        {
         return BottomElementParameter.getParameter();
        }
       case BOTTOM_POSITION:
        {
         return BottomPositionParameter.getParameter();
        }
       case DEFAULT_TYPE:
        {
         return DefaultTypeParameter.getParameter();
        }
       case ELEMENT_TEXT:
        {
         return ElementTextParameter.getParameter();
        }
       case IN_VIEW:
        {
         return InViewParameter.getParameter();
        }
       case TEXT:
        {
         return TextParameter.getParameter();
        }
       case TOP_ELEMENT:
        {
         return TopElementParameter.getParameter();
        }
       case TOP_POSITION:
        {
         return TopPositionParameter.getParameter();
        }
       case TYPE:
        {
         return TypeParameter.getParameter();
        }
       default:
        {
         break;
        }
      }
    }

   return null;
  }


 final static class BottomElementParameter extends ParameterIntegerQuery
  {
   private static BottomElementParameter _parameter;

   static BottomElementParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new BottomElementParameter();
      }
     return _parameter;
    }

   private BottomElementParameter()
    {
     super(PARAMETER_BLOCK + BLOCK_PARAMETER_BOTTOM_ELEMENT);
    }

   boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     return true;
    }

   int value(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     view = Block.view();
     if (view != null)
      {
       Element element = Block.bottomElement();
       if (element != null)
        {
         return view.document().elementList().ordinalOf(element) +
                // bump up by number of lines before loaded document section
                view.document().linesBeforeStart();
        }
      }
     return 0;
    }
  }


 final static class BottomPositionParameter extends ParameterIntegerQuery
  {
   private static BottomPositionParameter _parameter;

   static BottomPositionParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new BottomPositionParameter();
      }
     return _parameter;
    }

   private BottomPositionParameter()
    {
     super(PARAMETER_BLOCK + BLOCK_PARAMETER_BOTTOM_POSITION);
    }

   boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     return true;
    }

   int value(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     return (Block.view() != null)? Block.bottomPosition() : 0;
    }
  }


 final static class DefaultTypeParameter extends ParameterDefault
  {
   private static DefaultTypeParameter _parameter;

   private int _installValue;
   private boolean _installValueLoaded;
   private int _defaultValue;
   private boolean _defaultValueLoaded;

   static DefaultTypeParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new DefaultTypeParameter();
      }
     return _parameter;
    }

   private DefaultTypeParameter()
    {
     super(PARAMETER_BLOCK + BLOCK_PARAMETER_DEFAULT_TYPE);
     Install.addProfileChangedListener(new Install.ProfileChangedListener()
      {
       public void profileChanged()
        {
         _installValueLoaded = false;
        }
      });

     Profile.addProfileChangedListener(new Profile.ProfileChangedListener()
      {
       public void profileChanged()
        {
         _defaultValueLoaded = false;
        }
      });
    }

   String name(String qualifier)
    {
     return name();
    }

   int installValue()
    {
     if (!_installValueLoaded)
      {
       String value = Install.getString("install." + name());
       if (value == null)
        {
         _installValue = Block.STREAM;
        }
       else
        {
         if (value.equals("character"))
          {
           _installValue = Block.CHARACTER;
          }
         else if (value.equals("element"))
          {
           _installValue = Block.ELEMENT;
          }
         else if (value.equals("rectangle"))
          {
           _installValue = Block.RECTANGLE;
          }
         else
          {
           _installValue = Block.STREAM;
          }
        }
       _installValueLoaded = true;
      }

     return _installValue;
    }

   int defaultValue()
    {
     if (!_defaultValueLoaded)
      {
       String value = Profile.getString("default." + name());
       if (value == null)
        {
         _defaultValue = Block.NONE;
        }
       else
        {
         if (value.equals("character"))
          {
           _defaultValue = Block.CHARACTER;
          }
         else if (value.equals("element"))
          {
           _defaultValue = Block.ELEMENT;
          }
         else if (value.equals("rectangle"))
          {
           _defaultValue = Block.RECTANGLE;
          }
         else
          {
           _defaultValue = Block.STREAM;
          }
        }
       _defaultValueLoaded = true;
      }

     return _defaultValue;
    }

   int currentValue(View view)
    {
     int value = value(view);
     if (value == Block.NONE)
      {
       value = defaultValue();
       if (value == Block.NONE)
        {
         value = installValue();
        }
      }
     return value;
    }

   boolean set(View view, String qualifier, String parameters)
    {
     int value = Block.NONE;
     LpexStringTokenizer st = new LpexStringTokenizer(parameters);
     if (st.hasMoreTokens())
      {
       String token = st.nextToken();
       if (token.equals("stream"))
        {
         value = Block.STREAM;
        }
       else if (token.equals("character"))
        {
         value = Block.CHARACTER;
        }
       else if (token.equals("element"))
        {
         value = Block.ELEMENT;
        }
       else if (token.equals("rectangle"))
        {
         value = Block.RECTANGLE;
        }
       else if (token.equals("default"))
        {
         value = Block.NONE;
        }
       else
        {
         return CommandHandler.invalidParameter(view, token, "set " + name());
        }

       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name());
        }
      }
     return setValue(view, value);
    }

   boolean setValue(View view, int value)
    {
     if (view != null)
      {
       view.blockCommandSettings()._defaultType = value;
      }
     return true;
    }

   boolean setDefault(View view, String qualifier, String parameters)
    {
     int value = Block.NONE;
     String token = null;
     LpexStringTokenizer st = new LpexStringTokenizer(parameters);
     if (st.hasMoreTokens())
      {
       token = st.nextToken();
       if (token.equals("stream"))
        {
         value = Block.STREAM;
        }
       else if (token.equals("character"))
        {
         value = Block.CHARACTER;
        }
       else if (token.equals("element"))
        {
         value = Block.ELEMENT;
        }
       else if (token.equals("rectangle"))
        {
         value = Block.RECTANGLE;
        }
       else if (token.equals("install"))
        {
         value = Block.NONE;
        }
       else
        {
         return CommandHandler.invalidParameter(view, token, "set default." + name());
        }

       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "set default." + name());
        }
      }

     _defaultValue = value;
     _defaultValueLoaded = true;
     if (_defaultValue != Block.NONE)
      {
       Profile.putString("default." + this.name(), token);
      }
     else
      {
       Profile.remove("default." + this.name());
      }
     return true;
    }

   String query(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     if (view != null)
      {
       int value = value(view);
       return (value == Block.NONE)? "default" : getTypeName(value);
      }

     return null;
    }

   int value(View view)
    {
     return (view != null)? view.blockCommandSettings()._defaultType : Block.NONE;
    }

   String queryInstall(String qualifier)
    {
     return getTypeName(installValue());
    }

   String queryDefault(String qualifier)
    {
     int value = defaultValue();
     return (value == Block.NONE)? "install" : getTypeName(value);
    }

   String queryCurrent(View view, String qualifier)
    {
     return getTypeName(currentValue(view));
    }

   static String getTypeName(int type)
    {
     switch (type)
      {
       case Block.STREAM:
        {
         return "stream";
        }
       case Block.CHARACTER:
        {
         return "character";
        }
       case Block.ELEMENT:
        {
         return "element";
        }
       case Block.RECTANGLE:
        {
         return "rectangle";
        }
      }
     return null;
    }
  }


 // block.elementText parameter - not documented!? *as*
 final static class ElementTextParameter extends ParameterQuery
  {
   private static ElementTextParameter _parameter;

   static ElementTextParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new ElementTextParameter();
      }
     return _parameter;
    }

   private ElementTextParameter()
    {
     super(PARAMETER_BLOCK + BLOCK_PARAMETER_ELEMENT_TEXT);
    }

   String query(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     if (view != null && documentLocation != null)
      {
       Element element = view.document().elementList().elementAt(documentLocation.element);
       if (element != null && Block.partOfBlock(view, element))
        {
         int length = Block.selectedTextLength(view, element);
         if (length > 0)
          {
           int start = Block.selectedTextStart(view, element);
           int end = Block.selectedTextEnd(view, element);
           String elementText = element.text();
           int elementTextLength = elementText.length();
           if (start == 1 && end == elementTextLength)
            {
             return elementText;
            }

           StringBuffer buffer = new StringBuffer(length);
           for (int i = start; i <= end; i++)
            {
             char c;
             if (i <= elementTextLength)
              {
               c = elementText.charAt(i - 1);
              }
             else
              {
               c = ' ';
              }
             buffer.append(c);
            }

           return buffer.toString();
          }
         return "";
        }
      }

     return null;
    }
  }


 final static class InViewParameter extends ParameterOnOffQuery
  {
   private static InViewParameter _parameter;

   static InViewParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new InViewParameter();
      }
     return _parameter;
    }

   private InViewParameter()
    {
     super(PARAMETER_BLOCK + BLOCK_PARAMETER_IN_VIEW);
    }

   boolean value(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     return Block.view() == view;
    }
  }


 final static class TextParameter extends ParameterQuery
  {
   private static TextParameter _parameter;

   static TextParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new TextParameter();
      }
     return _parameter;
    }

   private TextParameter()
    {
     super(PARAMETER_BLOCK + BLOCK_PARAMETER_TEXT);
    }

   String query(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     return Block.selectedText();
    }
  }


 final static class TopElementParameter extends ParameterIntegerQuery
  {
   private static TopElementParameter _parameter;

   static TopElementParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new TopElementParameter();
      }
     return _parameter;
    }

   private TopElementParameter()
    {
     super(PARAMETER_BLOCK + BLOCK_PARAMETER_TOP_ELEMENT);
    }

   boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     return true;
    }

   int value(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     view = Block.view();
     if (view != null)
      {
       Element element = Block.topElement();
       if (element != null)
        {
         return view.document().elementList().ordinalOf(element) +
                // bump up by number of lines before loaded document section
                view.document().linesBeforeStart();
        }
      }
     return 0;
    }
  }


 final static class TopPositionParameter extends ParameterIntegerQuery
  {
   private static TopPositionParameter _parameter;

   static TopPositionParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new TopPositionParameter();
      }
     return _parameter;
    }

   private TopPositionParameter()
    {
     super(PARAMETER_BLOCK + BLOCK_PARAMETER_TOP_POSITION);
    }

   boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     return true;
    }

   int value(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     return (Block.view() != null)? Block.topPosition() : 0;
    }
  }


 final static class TypeParameter extends ParameterQuery
  {
   private static TypeParameter _parameter;

   static TypeParameter getParameter()
    {
     if (_parameter == null)
      {
       _parameter = new TypeParameter();
      }
     return _parameter;
    }

   private TypeParameter()
    {
     super(PARAMETER_BLOCK + BLOCK_PARAMETER_TYPE);
    }

   String query(View view, LpexDocumentLocation documentLocation, String qualifier)
    {
     switch (Block.type())
      {
       case Block.STREAM:
        {
         return "stream";
        }
       case Block.CHARACTER:
        {
         return "character";
        }
       case Block.ELEMENT:
        {
         return "element";
        }
       case Block.RECTANGLE:
        {
         return "rectangle";
        }
      }
     return "none";
    }
  }


 static boolean doCommand(View view, String parameters)
  {
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.countTokens() == 0)
    {
     return CommandHandler.noParameters(view, "block");
    }

   String token = st.nextToken();
   if (token.equals("clear"))
    {
     return clear(view, st);
    }
   if (token.equals("copy"))
    {
     return copy(view, st);
    }
   if (token.equals("delete"))
    {
     return delete(view, st);
    }
   if (token.equals("fill"))
    {
     return fill(view, st);
    }
   if (token.equals("find"))
    {
     return find(view, st);
    }
   if (token.equals("lowerCase"))
    {
     return lowerCase(view, st);
    }
   if (token.equals("move"))
    {
     return move(view, st);
    }
   if (token.equals("overlay"))
    {
     return overlay(view, st);
    }
   if (token.equals("set"))
    {
     return set(view, st);
    }
   if (token.equals("shift"))
    {
     return shift(view, st);
    }
   if (token.equals("upperCase"))
    {
     return upperCase(view, st);
    }

   return CommandHandler.invalidParameter(view, token, "block");
  }

 static private boolean clear(View view, LpexStringTokenizer st)
  {
   if (st.hasMoreTokens())
    {
     return CommandHandler.invalidParameter(view, st.nextToken(), "block clear");
    }

   Block.clear();
   return true;
  }

 static private boolean copy(View view, LpexStringTokenizer st)
  {
   if (st.hasMoreTokens())
    {
     return CommandHandler.invalidParameter(view, st.nextToken(), "block copy");
    }

   if (view != null)
    {
     Block.copy(view);
    }
   return true;
  }

 static private boolean delete(View view, LpexStringTokenizer st)
  {
   if (st.hasMoreTokens())
    {
     return CommandHandler.invalidParameter(view, st.nextToken(), "block delete");
    }

   Block.delete();
   return true;
  }

 static private boolean move(View view, LpexStringTokenizer st)
  {
   if (st.hasMoreTokens())
    {
     return CommandHandler.invalidParameter(view, st.nextToken(), "block move");
    }

   if (view != null)
    {
     Block.move(view);
    }
   return true;
  }

 /**
  * Fill the block with one or more characters:
  *   <code>block fill <i>abc</i></code>.
  */
 static private boolean fill(View view, LpexStringTokenizer st)
  {
   String token = " ";
   if (st.hasMoreTokens())
    {
     token = st.remainingText();
     if (LpexStringTokenizer.isValidQuotedString(token))
      {
       token = LpexStringTokenizer.removeQuotes(token);
      }
     if (token.length() == 0)
      {
       token = " ";
      }
    }

   Block.fill(token);
   return true;
  }

 static private boolean find(View view, LpexStringTokenizer st)
  {
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("end"))
      {
       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "block find end");
        }

       if (Block.view() != null)
        {
         Block.view().documentPosition().blockBottom();
         return true;
        }
      }
     else
      {
       return CommandHandler.invalidParameter(view, token, "block find");
      }
    }

   if (Block.view() != null)
    {
     Block.view().documentPosition().blockTop();
    }

   return true;
  }

 static private boolean lowerCase(View view, LpexStringTokenizer st)
  {
   if (st.hasMoreTokens())
    {
     return CommandHandler.invalidParameter(view, st.nextToken(), "block lowerCase");
    }

   Block.lowerCase();
   return true;
  }

 static private boolean upperCase(View view, LpexStringTokenizer st)
  {
   if (st.hasMoreTokens())
    {
     return CommandHandler.invalidParameter(view, st.nextToken(), "block upperCase");
    }

   Block.upperCase();
   return true;
  }

 static private boolean overlay(View view, LpexStringTokenizer st)
  {
   boolean transparent = false;
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("transparent"))
      {
       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "block overlay transparent");
        }
       transparent = true;
      }
     else
      {
       return CommandHandler.invalidParameter(view, token, "block overlay");
      }
    }

   if (view != null)
    {
     Block.overlay(view, transparent);
    }
   return true;
  }

 static private boolean set(View view, LpexStringTokenizer st)
  {
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     String type = token;
     int blockType = Block.NONE;

     if (type.equals("stream"))
      {
       blockType = Block.STREAM;
      }
     else if (type.equals("character"))
      {
       blockType = Block.CHARACTER;
      }
     else if (type.equals("element"))
      {
       blockType = Block.ELEMENT;
      }
     else if (type.equals("rectangle"))
      {
       blockType = Block.RECTANGLE;
      }
     else
      {
       return CommandHandler.invalidParameter(view, token, "block set");
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "block set " + type);
      }

     if (view != null)
      {
       Block.set(blockType, view);
      }
     return true;
    }

   if (view != null)
    {
     Block.set(view);
    }
   return true;
  }

 static private boolean shift(View view, LpexStringTokenizer st)
  {
   boolean right = true;
   int count = 1;
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     String direction = token;
     if (direction.equals("left"))
      {
       right = false;
       token = null;
      }
     else if (direction.equals("right"))
      {
       token = null;
      }

     if (token == null && st.hasMoreTokens())
      {
       token = st.nextToken();
      }

     if (token != null)
      {
       try
        {
         count = Integer.parseInt(token);
        }
       catch(NumberFormatException e)
        {
         return CommandHandler.invalidParameter(view, token, "block shift");
        }
      }

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "block shift");
      }
    }

   if (!right)
    {
     count = -count;
    }

   Block.shift(count);
   return true;
  }


 final static class Settings
  {
   int _defaultType = Block.NONE;
  }
}