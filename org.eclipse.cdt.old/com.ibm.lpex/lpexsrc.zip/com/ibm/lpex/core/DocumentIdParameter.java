//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DocumentIdParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class DocumentIdParameter extends ParameterIntegerQuery
{
 private static DocumentIdParameter _parameter;

 static DocumentIdParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new DocumentIdParameter();
   }
  return _parameter;
 }

 private DocumentIdParameter()
 {
  super(PARAMETER_DOCUMENT_ID);
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.document().id() : 0;
 }
}