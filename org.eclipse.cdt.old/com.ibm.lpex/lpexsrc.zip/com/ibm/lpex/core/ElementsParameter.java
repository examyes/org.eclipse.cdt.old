//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ElementsParameter - handles the elements parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>elements</b> parameter.
 * This parameter is query only.
 * It returns the total number of elements in the entire document.
 */
final class ElementsParameter extends ParameterIntegerQuery
{
 private static ElementsParameter _parameter;

 static ElementsParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ElementsParameter();
   }
  return _parameter;
 }

 private ElementsParameter()
 {
  super(PARAMETER_ELEMENTS);
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  Document document = view.document();
  return (view == null)? 0 : document.elementList().count() +
                             // add number of lines before & after loaded document section
                             document.linesBeforeStart() + document.linesAfterEnd();
 }
}