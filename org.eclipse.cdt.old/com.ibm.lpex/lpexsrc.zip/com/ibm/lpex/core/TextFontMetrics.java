//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// TextFontMetrics - optimize FontMetrics for the TextWindow.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;

/**
 * FontMetrics for the Screen's TextWindow.
 */
final class TextFontMetrics
{
 private Screen _screen;
 private FontMetrics _fontMetrics;
 private int _maxAscent;
 private int _textHeight;
 private int _spaceWidth;
 private int _charWidths[];  // cached widths for the first 256 chars

 TextFontMetrics(Screen screen)
  {
   _screen = screen;

   GC g = null;
   TextWindow textWindow = _screen.textWindow();
   if (textWindow != null) {
      g = new GC(textWindow);
      g.setFont(_screen.currentFont().getFont());
      _fontMetrics = g.getFontMetrics();
      }

   if (_fontMetrics != null)
    {
     _maxAscent  = _fontMetrics.getAscent();
     _textHeight = _maxAscent + _fontMetrics.getDescent() + _fontMetrics.getLeading();

     //System.out.println("\n\n averageCharWidth="+_fontMetrics.getAverageCharWidth());
     _charWidths = new int[256];
     StringBuffer buffer = new StringBuffer();
     buffer.append(' ');
     for (char ch = 0; ch < 256; ch++)
      {
       buffer.setCharAt(0, ch);
       _charWidths[ch] = g.stringExtent(buffer.toString()).x;
       //System.out.print(_charWidths[ch]+" "+g.getCharWidth(ch)+'/'+g.getAdvanceWidth(ch)+'\t');
      }

     _spaceWidth = _charWidths[' '];

     //*as* bug in Linux Eclipse R0.9:  0 stringExtent()s for MBCS fonts, and
     //     GC.getAdvanceWidth() and GC.getCharWidth() both hang Eclipse...
     if (_spaceWidth == 0)
      {
       _spaceWidth = _fontMetrics.getAverageCharWidth();
      }
    }
   else // use some defaults
    {
     _maxAscent  = 9;
     _textHeight = 16;
     _spaceWidth = 8;
     _charWidths = null;
    }

   if (g != null)
    {
     g.dispose();
    }
  }

 int maxAscent()
  {
   return _maxAscent;
  }

 int textHeight()
  {
   return _textHeight;
  }

 int spaceWidth()
  {
   return _spaceWidth;
  }

 int substringWidth(String s, int beginIndex, int endIndex)
  {
   int width = 0;
   int len   = s.length();
   if (endIndex > len)
    {
     endIndex = len;
    }
   for (int i = beginIndex; i < endIndex; i++)
    {
     char c = s.charAt(i);
     width += charWidth(c);
    }
   return width;
  }

 public int stringWidth(String s)
  {
   return (s != null)? substringWidth(s, 0, s.length()) : 0;
  }

 int substringWidth(char s[], int beginIndex, int endIndex)
  {
   int width = 0;
   int len   = s.length;
   if (endIndex > len)
    {
     endIndex = len;
    }
   for (int i = beginIndex; i < endIndex; i++)
    {
     char c = s[i];
     width += charWidth(c);
    }
   return width;
  }

 public int stringWidth(char s[], int len)
  {
   return substringWidth(s, 0, len);
  }

 public int charWidth(char c)
  {
   int charWidth = _spaceWidth;  // default to return if nothing better

   if (_fontMetrics != null)
    {
     if (c <= '\u00ff' && _charWidths[c] != 0)
      {
       charWidth = _charWidths[c];
      }
     else
      {
       TextWindow textWindow = _screen.textWindow();
       if (textWindow != null)
        {
         GC g = new GC(textWindow);
         g.setFont(_screen.currentFont().getFont());
         StringBuffer buffer = new StringBuffer();
         buffer.append(c);
         charWidth = g.stringExtent(buffer.toString()).x;
         if (c <= '\u00ff')
          {
           _charWidths[c] = charWidth;
          }
         g.dispose();
        }
      }
    }

   return charWidth;
  }
}