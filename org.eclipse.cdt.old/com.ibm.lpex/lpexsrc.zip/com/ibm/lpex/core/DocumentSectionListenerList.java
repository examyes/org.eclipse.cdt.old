//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DocumentSectionListenerList - handles a document's list of
// LpexDocumentSectionListeners.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages the LpexDocumentSectionListeners for a document.
 * There is up to one instance of this class created for each Document.
 */
final class DocumentSectionListenerList extends List
{
 /**
  * Constructor.
  */
 DocumentSectionListenerList(Document document) {}

 /**
  * Add an LpexDocumentSectionListener.  A listener is only registered once,
  * additional calls are without effect.
  */
 void addListener(LpexDocumentSectionListener listener)
 {
  if (find(listener) == null)
   {
    addAfter(null, new ListenerNode(listener));
   }
 }

 /**
  * Remove an LpexDocumentSectionListener, if registered.
  */
 void removeListener(LpexDocumentSectionListener listener)
 {
  if (listener != null)
   {
    ListenerNode node = find(listener);
    if (node != null)
     {
      remove(node);
     }
   }
 }

 /**
  * Send an <i>addLines</i> request to all the registered
  * LpexDocumentSectionListeners, until a listener indicates it has added the
  * requested lines to the currently-loaded document section.
  */
 void addLines(LpexView lpexView, int lineNeeded)
 {
  boolean done = false;

  beginScanning();
  for (ListenerNode node = (ListenerNode)first();
       node != null && !done;
       node = (ListenerNode)node.next())
   {
    done = node.listener().addLines(lpexView, lineNeeded);
   }
  endScanning();
 }

 /**
  * Find a registered LpexDocumentSectionListener for this Document.
  */
 ListenerNode find(LpexDocumentSectionListener listener)
 {
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    if (node.listener() == listener)
     {
      return node;
     }
   }
  return null;
 }


 private static class ListenerNode extends ListNode
 {
  private LpexDocumentSectionListener _listener;

  ListenerNode(LpexDocumentSectionListener listener)
  {
   _listener = listener;
  }

  LpexDocumentSectionListener listener()
  {
   return _listener;
  }
 }
}