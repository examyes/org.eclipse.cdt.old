//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SourceEncodingParameter - handles the sourceEncoding parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>sourceEncoding</b> parameter.
 * The Parameter class it extends provides the framework for handling
 * parameters in LPEX (setting install values, commands SET and QUERY, etc.).
 */
final class SourceEncodingParameter extends ParameterWordDefault
{
   /**
    * The singleton SourceEncodingParameter (static _parameter) object handle
    * (by occasionally delegating to Document) sourceEncoding for all the
    * documents (note that all its methods have a View argument passed in).
    *
    * The actual value of a view's sourceEncoding is stored in the Document
    * (_sourceEncoding, initialized to Parameter.DEFAULT).
    */
   private static SourceEncodingParameter _parameter;

   static SourceEncodingParameter getParameter()
   {
      if (_parameter == null)
         _parameter = new SourceEncodingParameter();
      return _parameter;
   }

   /**
    * Private constructor - SourceEncodingParameter is not instantiated directly,
    * but via a first call to SourceEncodingParameter.getParameter().
    */
   private SourceEncodingParameter()
   {
      // construct a Parameter.WordDefault with the _name
      // PARAMETER_SOURCE_ENCODING, and a _hardCodedValue = "native" (for a
      // default to the native encoding).
      super(PARAMETER_SOURCE_ENCODING, "native");
   }

   /**
    * Set the sourceEncoding parameter for this view's document.
    *
    * @param value null / "null" = default to the native character encoding,
    *              "native" = set to the native character encoding,
    *              else = a specific character encoding
    */
   boolean setValue(View view, String value)
   {
      if (view != null) {
         if (value == null || value.equals("null"))
            value = null;

         String oldValue = queryCurrent(view, null);
         if (!view.nls().setSourceEncoding(value)) {
            CommandHandler.invalidParameter(view, value, "set " + name());
            return false; // encoding not supported
            }

         if (!oldValue.equals(queryCurrent(view, null)))
            currentValueChanged(view);
         }

      return true;
   }

   /**
    * Handle the notification of a change in the actual character encoding value
    * of the document's sourceEncoding parameter, by delegating it to the
    * Document.sourceEncodingChanged().
    */
   void currentValueChanged(View view)
   {
      view.document().sourceEncodingChanged();
   }

   /**
    * Retrieve the document's sourceEncoding parameter value.
    *
    * @return <code>null</code> = DEFAULT,
    *         or else = a specific source encoding.
    */
   String value(View view)
   {
      return (view != null)? view.document()._sourceEncoding : null;
   }

   /**
    * Retrieve the effective current value of the sourceEncoding setting for
    * this view's document.  Also used in here to check actual value changes.
    * Overrides super's null / "null" stuff - we like "native"!
    */
   String queryCurrent(View view, String qualifier)
   {
      String cur = super.queryCurrent(view, qualifier);
      if (cur == null)
         cur = "native";

      if (cur.equals("native")) // _hardCodedValue?
         cur = LpexNls.getNativeEncoding();

      return cur;
   }

   /**
    * Override super's null / "null" stuff - we'd rather see "native"!
    */
   String queryDefault(String qualifier)
   {
      String dft = super.queryDefault(qualifier);
      return (dft == null)? "native" : dft;
   }

   //-as- Parameter.WordDefault assumes scope = view, so it iterates through
   // all the views of all documents to check & call currentValueChanged()...
   // May want to separate that code so that we can override here & skip this
   // all-the-views part - we're document scoped!
}