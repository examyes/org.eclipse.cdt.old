//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterOnOffOnly - base class for managing simple on/off parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Base, abstract class for managing simple on/off parameters (without install,
 * default, and current settings).
 * To implement on/off parameters with install, default, and current values,
 * use ParameterOnOffDefault.
 */
abstract class ParameterOnOffOnly extends ParameterOnOffQuery
{
 ParameterOnOffOnly(String name)
  {
   super(name);
  }

 boolean isQueryOnly(String qualifier)
  {
   return false;
  }

 boolean set(View view, String qualifier, String parameters)
  {
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (!st.hasMoreTokens())
    {
     return CommandHandler.incomplete(view, "set " + name(qualifier));
    }

   String token = st.nextToken();
   boolean value;
   if (token.equals("on"))
    {
     value = true;
    }
   else if (token.equals("off"))
    {
     value = false;
    }
   else
    {
     return CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
    }

   if (st.hasMoreTokens())
    {
     return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name(qualifier));
    }

   return setValue(view, qualifier, value);
  }

 abstract boolean setValue(View view, String qualifier, boolean value);
}