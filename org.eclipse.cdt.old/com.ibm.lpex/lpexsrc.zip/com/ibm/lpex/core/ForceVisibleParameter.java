//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ForceVisibleParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ForceVisibleParameter extends ParameterOnOffOnly
{
 private static ForceVisibleParameter _parameter;

 static ForceVisibleParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ForceVisibleParameter();
   }
  return _parameter;
 }

 private ForceVisibleParameter()
 {
  super(PARAMETER_FORCE_VISIBLE);
 }

 boolean setValue(View view, String qualifier, boolean value)
 {
  if (view != null)
   {
    Element element = view.documentPosition().element();
    if (element != null)
     {
      element.elementView(view).setForceVisible(value);
     }
   }

  return true;
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return view != null && documentLocation != null &&
         view.document().elementList().elementAt(documentLocation.element) != null;
 }

 boolean value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null && documentLocation != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    if (element != null)
     {
      return element.elementView(view).forceVisible();
     }
   }

  return false;
 }
}