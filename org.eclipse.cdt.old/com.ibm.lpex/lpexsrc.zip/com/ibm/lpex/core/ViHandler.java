//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ViHandler - vi baseProfile key handler (cf. ActionHandler).
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the vi <b>baseProfile</b>.
 * It handles keyboard actions when the vi profile is active.
 * There is up to one instance of this class per document view.
 */
final class ViHandler
{
 static final int
  MODE_COMMAND                      =  0,
  MODE_INSERT                       =  1,
  MODE_REPLACE_CHARACTER            =  2,
  MODE_DELETE                       =  3,
  MODE_YANK                         =  4,
  MODE_REDRAW                       =  5,
  MODE_CHANGE                       =  6,
  MODE_REPLACE                      =  7,
  MODE_BUFFER                       =  8,
  MODE_FIND_CHARACTER               =  9,
  MODE_REVERSE_FIND_CHARACTER       = 10,
  MODE_FIND_BEFORE_CHARACTER        = 11,
  MODE_REVERSE_FIND_AFTER_CHARACTER = 12,
  MODE_Z                            = 13,
  MODE_MARK                         = 14,
  MODE_TO                           = 15,
  MODE_TO_FIRST_NON_WHITESPACE      = 16,
  MODE_BUFFER_COMMAND               = 17,
  MODE_INDENT                       = 18,
  MODE_UNINDENT                     = 19;

 private View      _view;
 private int       _mode;
 private int       _count;
 private String    _insertString;
 private char      _findCharacterCommand;
 private char      _findCharacter;
 private String    _buffers[] = new String[35];
 private int       _currentBuffer;
 private boolean   _appendToBuffer;
 private String    _findCommand;
 private String    _substituteCommand;
 private boolean   _nextCharacterIsQuoted;
 private String    _lastChangeCommand;
 private int       _lastChangeCount;
 private int       _lastChangeBuffer;
 private boolean   _viChange;
 private Element   _element;
 private int       _position;
 private Element   _savedElement;
 private String    _savedText;
 private KeyedList _abbreviations = new KeyedList();
 private int       _currentBufferCommand;
 private boolean   _ignoreCount;


 /**
  * Create a new vi key handler, initialize it to command mode.
  */
 ViHandler(View view)
  {
   _view = view;
   setCommandMode();
  }

 void verifyMode()
  {
   if (_mode != MODE_COMMAND)
    {
     TextWindow textWindow = null;
     if (_view.window() != null)
      {
       textWindow = (TextWindow) _view.window().textWindow();
      }
     if (textWindow == null || !textWindow.focusGained())
      {
       setCommandMode();
      }
     else if ((_mode == MODE_REPLACE || _mode == MODE_INSERT) &&
              (_view.documentPosition().element() != _element ||
               _view.documentPosition().position() != _position))
      {
       setCommandMode();
      }
    }

   if (_savedElement != _view.documentPosition().element())
    {
     _savedElement = null;
     _savedText = null;
    }
  }

 void verifyChange()
  {
   if (!_viChange && (_mode == MODE_INSERT || _mode == MODE_REPLACE))
    {
     setCommandMode();
    }
  }

 int mode()
  {
   return _mode;
  }

 void setCommandMode()
  {
   _mode = MODE_COMMAND;
   _count = 0;
   _currentBuffer = 0;
   _appendToBuffer = false;
   _nextCharacterIsQuoted = false;
   _element = null;
   _position = 0;
   _ignoreCount = false;
   _view.document().undo().check(_view);
  }

 private void setInsertMode()
  {
   _mode = MODE_INSERT;
   _insertString = "";
   _element = _view.documentPosition().element();
   _position = _view.documentPosition().position();
  }

 private void setDeleteMode()
  {
   _mode = MODE_DELETE;
  }

 private void setReplaceCharacterMode()
  {
   _mode = MODE_REPLACE_CHARACTER;
  }

 private void setYankMode()
  {
   _mode = MODE_YANK;
  }

 private void setChangeMode()
  {
   _mode = MODE_CHANGE;
  }

 private void setRedrawMode()
  {
   _mode = MODE_REDRAW;
  }

 private void setReplaceMode()
  {
   _mode = MODE_REPLACE;
   _insertString = "";
   _element = _view.documentPosition().element();
   _position = _view.documentPosition().position();
  }

 private void setBufferMode()
  {
   _mode = MODE_BUFFER;
  }

 private void setFindCharacterMode()
  {
   _mode = MODE_FIND_CHARACTER;
  }

 private void setReverseFindCharacterMode()
  {
   _mode = MODE_REVERSE_FIND_CHARACTER;
  }

 private void setFindBeforeCharacterMode()
  {
   _mode = MODE_FIND_BEFORE_CHARACTER;
  }

 private void setReverseFindAfterCharacterMode()
  {
   _mode = MODE_REVERSE_FIND_AFTER_CHARACTER;
  }

 private void setZMode()
  {
   _mode = MODE_Z;
  }

 private void setMarkMode()
  {
   _mode = MODE_MARK;
  }

 private void setToMode()
  {
   _mode = MODE_TO;
  }

 private void setToFirstNonWhitespaceMode()
  {
   _mode = MODE_TO_FIRST_NON_WHITESPACE;
  }

 private void setBufferCommandMode()
  {
   _mode = MODE_BUFFER_COMMAND;
  }

 private void setIndentMode()
  {
   _mode = MODE_INDENT;
  }

 private void setUnindentMode()
  {
   _mode = MODE_UNINDENT;
  }

 /**
  * Process a vi character.
  * Called by doKeyEvent() in ActionHandler, and by repeatLastChange() in here.
  */
 void processCharacter(char c)
  {
   switch (_mode)
    {
     case MODE_COMMAND:
      {
       if (_count == 0 && c >= '1' && c <= '9')
        {
         _count = c - '0';
        }
       else if (_count != 0 && c >= '0' && c <= '9')
        {
         _count *= 10;
         _count += c - '0';
        }
       else
        {
         processCommandCharacter(c);
        }
       break;
      }
     case MODE_INSERT:
      {
       processInputCharacter(c);
       break;
      }
     case MODE_REPLACE_CHARACTER:
      {
       processReplaceCharacter(c);
       break;
      }
     case MODE_DELETE:
      {
       processDeleteCharacter(c);
       break;
      }
     case MODE_CHANGE:
      {
       processChangeCharacter(c);
       break;
      }
     case MODE_FIND_CHARACTER:
      {
       processFindCharacter(c);
       break;
      }
     case MODE_REVERSE_FIND_CHARACTER:
      {
       processReverseFindCharacter(c);
       break;
      }
     case MODE_FIND_BEFORE_CHARACTER:
      {
       processFindBeforeCharacter(c);
       break;
      }
     case MODE_REVERSE_FIND_AFTER_CHARACTER:
      {
       processReverseFindAfterCharacter(c);
       break;
      }
     case MODE_YANK:
      {
       processYankCharacter(c);
       break;
      }
     case MODE_REDRAW:
      {
       processRedrawCharacter(c);
       break;
      }
     case MODE_REPLACE:
      {
       processInputCharacter(c);
       break;
      }
     case MODE_BUFFER:
      {
       processBufferCharacter(c);
       break;
      }
     case MODE_Z:
      {
       processZCharacter(c);
       break;
      }
     case MODE_MARK:
      {
       processMarkCharacter(c);
       break;
      }
     case MODE_TO:
      {
       processToCharacter(c);
       break;
      }
     case MODE_TO_FIRST_NON_WHITESPACE:
      {
       processToFirstNonWhitespaceCharacter(c);
       break;
      }
     case MODE_BUFFER_COMMAND:
      {
       processBufferCommandCharacter(c);
       break;
      }
     case MODE_INDENT:
      {
       processIndentCharacter(c);
       break;
      }
     case MODE_UNINDENT:
      {
       processUnindentCharacter(c);
       break;
      }
     default:
      {
       setCommandMode();
       break;
      }
    }
  }

 private void processCommandCharacter(char c)
  {
   switch (c)
    {
     case '"':
      {
       setBufferMode();
       break;
      }
     case '$':
      {
       endOfLine();
       break;
      }
     case '%':
      {
       matchingParenthesisOrBrace();
       break;
      }
     case '&':
      {
       repeatSubstitute();
       break;
      }
     case '\'':
      {
       setToFirstNonWhitespaceMode();
       break;
      }
     case '+':
      {
       firstNonWhitespaceOnNextLine();
       break;
      }
     case ',':
      {
       reverseRepeatFindCharacter();
       break;
      }
     case '-':
      {
       firstNonWhitespaceOnPreviousLine();
       break;
      }
     case '`':
      {
       setToMode();
       break;
      }
     case '.':
      {
       repeatLastChange();
       break;
      }
     case '/':
      {
       exCommand(c);
       break;
      }
     case ':':
      {
       exCommand(c);
       break;
      }
     case ';':
      {
       repeatFindCharacter();
       break;
      }
     case '<':
      {
       startChangeCommand(c);
       setUnindentMode();
       break;
      }
     case '>':
      {
       startChangeCommand(c);
       setIndentMode();
       break;
      }
     case '?':
      {
       exCommand(c);
       break;
      }
     case '@':
      {
       setBufferCommandMode();
       break;
      }
     case '^':
      {
       firstNonWhitespace();
       break;
      }
     case '_':
      {
       firstNonWhitespaceOnNextLineMinus1();
       break;
      }
     case '|':
      {
       column();
       break;
      }
     case '~':
      {
       startChangeCommand(c);
       toggleCharacterCase();
       break;
      }
     case '0':
      {
       startOfLine();
       break;
      }
     case 'a':
      {
       insertAfter();
       break;
      }
     case 'A':
      {
       insertAtEndOfLine();
       break;
      }
     case 'b':
      {
       startOfWord();
       break;
      }
     case 'B':
      {
       startOfWord();
       break;
      }
     case 'c':
      {
       startChangeCommand(c);
       setChangeMode();
       break;
      }
     case 'C':
      {
       startChangeCommand(c);
       changeToLineEnd();
       break;
      }
     case 'd':
      {
       startChangeCommand(c);
       setDeleteMode();
       break;
      }
     case 'D':
      {
       startChangeCommand(c);
       deleteToLineEnd();
       break;
      }
     case 'e':
      {
       endOfWord();
       break;
      }
     case 'E':
      {
       endOfWord();
       break;
      }
     case 'f':
      {
       setFindCharacterMode();
       break;
      }
     case 'F':
      {
       setReverseFindCharacterMode();
       break;
      }
     case 'G':
      {
       goToLine();
       break;
      }
     case 'h':
      {
       left();
       break;
      }
     case 'H':
      {
       firstNonWhitespaceAtScreenTop();
       break;
      }
     case 'i':
      {
       startChangeCommand(c);
       setInsertMode();
       break;
      }
     case 'I':
      {
       startChangeCommand(c);
       insertAtStartOfLine();
       break;
      }
     case 'j':
      {
       down();
       break;
      }
     case 'J':
      {
       startChangeCommand(c);
       join();
       break;
      }
     case 'k':
      {
       up();
       break;
      }
     case 'l':
      {
       right();
       break;
      }
     case 'L':
      {
       firstNonWhitespaceAtScreenBottom();
       break;
      }
     case 'm':
      {
       setMarkMode();
       break;
      }
     case 'M':
      {
       firstNonWhitespaceAtScreenMiddle();
       break;
      }
     case 'n':
      {
       repeatFind();
       break;
      }
     case 'N':
      {
       reverseRepeatFind();
       break;
      }
     case 'o':
      {
       startChangeCommand(c);
       insertNewLine();
       break;
      }
     case 'O':
      {
       startChangeCommand(c);
       insertNewLineBefore();
       break;
      }
     case 'p':
      {
       startChangeCommand(c);
       pasteAfter();
       break;
      }
     case 'P':
      {
       startChangeCommand(c);
       paste();
       break;
      }
     case 'r':
      {
       startChangeCommand(c);
       setReplaceCharacterMode();
       break;
      }
     case 'R':
      {
       startChangeCommand(c);
       setReplaceMode();
       break;
      }
     case 's':
      {
       startChangeCommand(c);
       substitute();
       break;
      }
     case 'S':
      {
       startChangeCommand(c);
       changeLine();
       break;
      }
     case 't':
      {
       setFindBeforeCharacterMode();
       break;
      }
     case 'T':
      {
       setReverseFindAfterCharacterMode();
       break;
      }
     case 'u':
      {
       undo();
       break;
      }
     case 'U':
      {
       undoLine();
       break;
      }
     case 'w':
      {
       nextWord();
       break;
      }
     case 'W':
      {
       nextWord();
       break;
      }
     case 'x':
      {
       startChangeCommand(c);
       deleteCharacter();
       break;
      }
     case 'X':
      {
       startChangeCommand(c);
       deleteCharacterBefore();
       break;
      }
     case 'y':
      {
       setYankMode();
       break;
      }
     case 'Y':
      {
       yankLine();
       break;
      }
     case 'z':
      {
       setRedrawMode();
       break;
      }
     case 'Z':
      {
       setZMode();
       break;
      }
     case 2:  // ^B
      {
       scrollPageBackward();
       break;
      }
     case 4:  // ^D
      {
       scrollForwardHalfScreen();
       break;
      }
     case 5:  // ^E
      {
       scrollForward();
       break;
      }
     case 6:  // ^F
      {
       scrollPageForward();
       break;
      }
     case 8:  // ^H
      {
       left();
       break;
      }
     case 10: // ^J
      {
       down();
       break;
      }
     case 13: // ^M
      {
       firstNonWhitespaceOnNextLine();
       break;
      }
     case 14: // ^N
      {
       down();
       break;
      }
     case 16: // ^P
      {
       up();
       break;
      }
     case 21: // ^U
      {
       scrollBackwardHalfScreen();
       break;
      }
     case 25: // ^Y
      {
       scrollBackward();
       break;
      }
     default:
      {
       BeepParameter.getParameter().setValue(true);
       setCommandMode();
       break;
      }
    }
  }

 private void processInputCharacter(char c)
  {
   _lastChangeCommand += c;
   if (!_nextCharacterIsQuoted && c == 27) // ^[ (Esc)
    {
     expandAbbreviation();
     if (!_ignoreCount)
      {
       if (_count == 0)
        {
         _count = 1;
        }
       for (int i = 1; i < _count; i++)
        {
         _viChange = true;
         _view.insertText(_insertString);
         _viChange = false;
        }
      }
     setCommandMode();
     _view.documentPosition().left();
    }

   else if (!_nextCharacterIsQuoted && c == 8) // ^H
    {
     if (_insertString.length() > 0)
      {
       _viChange = true;
       _view.actionHandler().doDefaultAction(LpexConstants.ACTION_BACK_SPACE);
       _viChange = false;
       _insertString = _insertString.substring(0, _insertString.length() - 1);
       _element = _view.documentPosition().element();
       _position = _view.documentPosition().position();
      }
     else
      {
       BeepParameter.getParameter().setValue(true);
      }
    }

   else if (!_nextCharacterIsQuoted && c == 22) // ^V
    {
     _nextCharacterIsQuoted = true;
    }

   else if (!_nextCharacterIsQuoted && c == 23) // ^W
    {
     int backSpaces = 0;
     int i = _insertString.length() - 1;
     while (i >= 0)
      {
       c = _insertString.charAt(i);
       if (c == ' ')
        {
         i--;
        }
       else
        {
         break;
        }
      }
     while (i >= 0)
      {
       c = _insertString.charAt(i);
       if (c == ' ' || c == '\n')
        {
         break;
        }
       if (backSpaces == 0)
        {
         backSpaces = _insertString.length() - i;
        }
       else
        {
         backSpaces++;
        }
       i--;
      }
     if (backSpaces > 0)
      {
       _viChange = true;
       _view.documentPosition().left(backSpaces);
       _view.deleteText(_view.documentPosition().element(),
                        _view.documentPosition().position(), backSpaces);
       _viChange = false;
       _insertString = _insertString.substring(0, _insertString.length() - backSpaces);
       _element = _view.documentPosition().element();
       _position = _view.documentPosition().position();
      }
     else
      {
       BeepParameter.getParameter().setValue(true);
      }
    }

   else
    {
     if (c == '\r')
      {
       c = '\n';
      }
     if (!_nextCharacterIsQuoted &&
         (c == ' ' || c == '\n' || c == '\t'))
      {
       expandAbbreviation();
      }
     _nextCharacterIsQuoted = false;
     _viChange = true;
     if (_mode == MODE_INSERT)
      {
       _view.insertText(String.valueOf(c));
      }
     else
      {
       _view.replaceText(String.valueOf(c));
      }
     _viChange = false;
     _insertString += c;
     _element = _view.documentPosition().element();
     _position = _view.documentPosition().position();
    }
  }

 private void processReplaceCharacter(char c)
  {
   _lastChangeCommand += c;
   if (_count == 0)
    {
     _count = 1;
    }

   for (int i = 0; i < _count; i++)
    {
     _view.replaceText(String.valueOf(c));
    }

   setCommandMode();
  }

 private void processDeleteCharacter(char c)
  {
   _lastChangeCommand += c;
   switch (c)
    {
     case '^':
      {
       deleteToLineStart();
       break;
      }
     case '$':
      {
       deleteToLineEnd();
       break;
      }
     case 'd':
      {
       deleteLine();
       break;
      }
     case 'w':
      {
       deleteToWordEnd();
       break;
      }
     default:
      {
       BeepParameter.getParameter().setValue(true);
       setCommandMode();
       break;
      }
    }
  }

 private void processChangeCharacter(char c)
  {
   _lastChangeCommand += c;
   switch (c)
    {
     case '^':
      {
       deleteToLineStart();
       setInsertMode();
       break;
      }
     case '$':
      {
       deleteToLineEnd();
       setInsertMode();
       break;
      }
     case 'c':
      {
       changeLine();
       break;
      }
     case 'w':
      {
       deleteToWordEnd();
       _ignoreCount = true;
       setInsertMode();
       break;
      }
     default:
      {
       BeepParameter.getParameter().setValue(true);
       setCommandMode();
       break;
      }
    }
  }

 private void processFindCharacter(char c)
  {
   _findCharacterCommand = 'f';
   _findCharacter = c;
   findCharacter();
  }

 private void processReverseFindCharacter(char c)
  {
   _findCharacterCommand = 'F';
   _findCharacter = c;
   reverseFindCharacter();
  }

 private void processFindBeforeCharacter(char c)
  {
   _findCharacterCommand = 't';
   _findCharacter = c;
   findCharacter();
  }

 private void processReverseFindAfterCharacter(char c)
  {
   _findCharacterCommand = 'T';
   _findCharacter = c;
   reverseFindCharacter();
  }

 private void processYankCharacter(char c)
  {
   switch (c)
    {
     case '^':
      {
       yankToLineStart();
       break;
      }
     case '$':
      {
       yankToLineEnd();
       break;
      }
     case 'w':
      {
       yankToWordEnd();
       break;
      }
     case 'y':
      {
       yankLine();
       break;
      }
     default:
      {
       BeepParameter.getParameter().setValue(true);
       setCommandMode();
       break;
      }
    }
  }

 private void processRedrawCharacter(char c)
  {
   switch (c)
    {
     case 13: // ^M
      {
       scrollTop();
       break;
      }
     case '.':
      {
       scrollCenter();
       break;
      }
     case '-':
      {
       scrollBottom();
       break;
      }
     default:
      {
       BeepParameter.getParameter().setValue(true);
       setCommandMode();
       break;
      }
    }
  }

 private void processBufferCharacter(char c)
  {
   if (c >= 'a' && c <= 'z')
    {
     _currentBuffer = 9 + c - 'a';
     _appendToBuffer = false;
     _mode = MODE_COMMAND;
    }
   else if (c >= 'A' && c < 'Z')
    {
     _currentBuffer = 9 + c - 'A';
     _appendToBuffer = true;
     _mode = MODE_COMMAND;
    }
   else if (c >= '1' && c <= '9')
    {
     _currentBuffer = c - '1';
     _appendToBuffer = false;
     _mode = MODE_COMMAND;
    }
   else
    {
     setCommandMode();
    }
  }

 private void processZCharacter(char c)
  {
   if (c == 'Z')
    {
     CommandHandler._status = null;
     Undo undo = _view.document().undo();
     if (undo.dirty() || undo.changes() != 0)
      {
       _view.commandHandler().doCommand("save");
      }
     if (CommandHandler._status == null)
      {
       _view.commandHandler().doCommand("quit");
      }
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
    }

   setCommandMode();
  }

 private void processMarkCharacter(char c)
  {
   if (c >= 'a' && c <= 'z')
    {
     SetCommand.doCommand(_view, "mark." + c);
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
    }

   setCommandMode();
  }

 private void processToCharacter(char c)
  {
   if (c >= 'a' && c <= 'z')
    {
     beforeJump();
     LocateCommand.doCommand(_view, "mark " + c);
    }
   else if (c == '`')
    {
     SetCommand.doCommand(_view, "mark.@OLD");
     LocateCommand.doCommand(_view, "mark @QUICK");
     SetCommand.doCommand(_view, "mark.@NEW");
     LocateCommand.doCommand(_view, "mark @OLD");
     SetCommand.doCommand(_view, "mark.@QUICK");
     LocateCommand.doCommand(_view, "mark @NEW");
     SetCommand.doCommand(_view, "mark.@OLD clear");
     SetCommand.doCommand(_view, "mark.@NEW clear");
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
    }

   setCommandMode();
  }

 private void processToFirstNonWhitespaceCharacter(char c)
  {
   if (c >= 'a' && c <= 'z')
    {
     beforeJump();
     LocateCommand.doCommand(_view, "mark " + c);
     if (CommandHandler._status == null)
      {
       _view.documentPosition().home();
      }
    }
   else if (c == '\'')
    {
     SetCommand.doCommand(_view, "mark.@OLD");
     LocateCommand.doCommand(_view, "mark @QUICK");
     SetCommand.doCommand(_view, "mark.@NEW");
     LocateCommand.doCommand(_view, "mark @OLD");
     SetCommand.doCommand(_view, "mark.@QUICK");
     LocateCommand.doCommand(_view, "mark @NEW");
     SetCommand.doCommand(_view, "mark.@OLD clear");
     SetCommand.doCommand(_view, "mark.@NEW clear");
     if (CommandHandler._status == null)
      {
       _view.documentPosition().home();
      }
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
    }

   setCommandMode();
  }

 private void processBufferCommandCharacter(char c)
  {
   String command = null;
   if (c >= 'a' && c <= 'z')
    {
     _currentBufferCommand = 9 + c - 'a';
     command = _buffers[_currentBufferCommand];
    }
   else if (c == '@')
    {
     if (_currentBufferCommand != 0)
      {
       command = _buffers[_currentBufferCommand];
      }
    }

   if (command != null && command.length() > 0)
    {
     if (command.charAt(0) == '\n')
      {
       command = command.substring(1);
      }
     doCommand(command);
    }

   setCommandMode();
  }

 private void processIndentCharacter(char c)
  {
   _lastChangeCommand += c;
   if (c == '>')
    {
     if (_count == 0)
      {
       _count = 1;
      }
     Element element = _view.documentPosition().element();
     for (int i = 0; i < _count; i++)
      {
       if (element != null && !element.show())
        {
         _view.insertText(element, 1, "\t");
         element = element.nextVisibleNonShow(_view);
        }
      }
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
    }

   setCommandMode();
  }

 private void processUnindentCharacter(char c)
  {
   _lastChangeCommand += c;
   if (c == '<')
    {
     if (_count == 0)
      {
       _count = 1;
      }
     Element element = _view.documentPosition().element();
     for (int i = 0; i < _count; i++)
      {
       if (element != null && !element.show())
        {
         String text = element.text();
         if (text.length() > 0 && text.charAt(0) == '\t')
          {
           _view.deleteText(element, 1, 1);
          }
         element = element.nextVisibleNonShow(_view);
        }
      }
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
    }

   setCommandMode();
  }

 void doCommand(String commandString)
  {
   if (commandString != null && commandString.length() > 0)
    {
     if (commandString.charAt(0) == ':')
      {
       Command command = new Command(commandString);
       boolean badCommand = false;
       if (command.isCommand("lpex", 2))
        {
         if (command.skipOptionalCharacter(' '))
          {
           _view.commandHandler().doCommand(command.remainingText());
          }
         else
          {
           badCommand = true;
          }
        }
       else if (command.isCommand("quit", 1))
        {
         boolean exclamationMark = command.skipCharacter('!');
         if (!command.noRemainingText())
          {
           badCommand = true;
          }
         else
          {
           if (!exclamationMark)
            {
             Undo undo = _view.document().undo();
             if (undo.dirty() || undo.changes() != 0)
              {
               _view.setLpexMessageText(LpexConstants.MSG_VI_QUITUNSAVEDCHANGES);
               return;
              }
            }
           _view.commandHandler().doCommand("quit");
          }
        }
       else if (command.isCommand("wq", 2))
        {
         if (command.noRemainingText())
          {
           CommandHandler._status = null;
           Undo undo = _view.document().undo();
           if (undo.dirty() || undo.changes() != 0)
            {
             _view.commandHandler().doCommand("save");
            }
           if (CommandHandler._status == null)
            {
             _view.commandHandler().doCommand("quit");
            }
          }
         else
          {
           badCommand = true;
          }
        }
       else if (command.isCommand("w", 1))
        {
         boolean exclamationMark = command.skipCharacter('!');
         if (!command.skipOptionalCharacter(' '))
          {
           badCommand = true;
          }
         else
          {
           if (command.noRemainingText())
            {
             if (!exclamationMark)
              {
               Undo undo = _view.document().undo();
               if (undo.dirty() || undo.changes() != 0)
                {
                 _view.commandHandler().doCommand("save");
                }
              }
             else
              {
               _view.commandHandler().doCommand("save");
              }
            }
           else
            {
             _view.commandHandler().doCommand("save " + command.remainingText());
            }
          }
        }
       else if (command.isCommand("edit", 1))
        {
         boolean exclamationMark = command.skipCharacter('!');
         if (!command.skipOptionalCharacter(' '))
          {
           badCommand = true;
          }
         else
          {
           Undo undo = _view.document().undo();
           if (!exclamationMark && (undo.dirty() || undo.changes() != 0))
            {
             _view.setLpexMessageText(LpexConstants.MSG_VI_EDITUNSAVEDCHANGES);
            }
           else
            {
             if (!command.noRemainingText())
              {
               _view.document().setName(command.remainingText());
              }
             LoadCommand.doCommand(_view, "");
            }
          }
        }
       else if (command.isCommand("abbreviate", 2))
        {
         if (!command.skipOptionalCharacter(' '))
          {
           badCommand = true;
          }
         else
          {
           String abbreviation = command.nextToken();
           _abbreviations.set(abbreviation, command.remainingText());
          }
        }
       else if (command.isCommand("unabbreviate", 3))
        {
         if (!command.skipOptionalCharacter(' '))
          {
           badCommand = true;
          }
         else
          {
           String abbreviation = command.nextToken();
           if (command.noRemainingText())
            {
             _abbreviations.set(abbreviation, null);
            }
           else
            {
             badCommand = true;
            }
          }
        }
       else if (command.isCommand("substitute", 1))
        {
         if (!command.skipCharacter('/'))
          {
           badCommand = true;
          }
         else
          {
           String findText = command.nextToken('/');
           if (findText.length() == 0 || !command.skipCharacter('/'))
            {
             badCommand = true;
            }
           else
            {
             String replaceText = command.nextToken('/');
             boolean confirm = false;
             boolean global = false;
             if (command.skipCharacter('/'))
              {
               String options = command.nextToken();
               for (int i = 0; i < options.length(); i++)
                {
                 char c = options.charAt(i);
                 if (c == 'g')
                  {
                   global = true;
                  }
                 else if (c == 'c')
                  {
                   confirm = true;
                  }
                 else
                  {
                   badCommand = true;
                  }
                }
              }
             if (!badCommand)
              {
               _substituteCommand = commandString;
               String options = "asis ";
               if (global)
                {
                 options += "all ";
                }
               FindTextCommand.doCommand(_view, options + "replaceWith " +
                                         LpexStringTokenizer.addQuotes(replaceText) + " " +
                                         LpexStringTokenizer.addQuotes(findText));
              }
            }
          }
        }
       if (badCommand)
        {
         _view.setLpexMessageText(LpexConstants.MSG_COMMAND_INVALID, commandString);
        }
      }
     else if (commandString.charAt(0) == '/')
      {
       beforeJump();
       _findCommand = commandString;
       FindTextCommand.doCommand(_view, "asis " +
                       LpexStringTokenizer.addQuotes(commandString.substring(1)));
      }
     else if (commandString.charAt(0) == '?')
      {
       beforeJump();
       _findCommand = commandString;
       FindTextCommand.doCommand(_view, "up asis " +
                       LpexStringTokenizer.addQuotes(commandString.substring(1)));
      }
     else
      {
       _view.setLpexMessageText(LpexConstants.MSG_COMMAND_INVALID, commandString);
      }
    }
  }

 private void insertAfter()
  {
   _view.documentPosition().right();
   setInsertMode();
  }

 private void insertAtEndOfLine()
  {
   _view.documentPosition().end();
   setInsertMode();
  }

 private void left()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   _view.documentPosition().left(_count);
   setCommandMode();
  }

 private void insertAtStartOfLine()
  {
   _view.documentPosition().home();
   setInsertMode();
  }

 private void down()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   _view.documentPosition().down(_count);
   setCommandMode();
  }

 private void up()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   _view.documentPosition().up(_count);
   setCommandMode();
  }

 private void right()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   _view.documentPosition().right(_count);
   setCommandMode();
  }

 private void insertNewLine()
  {
   Element element = new Element(_view.document());
   _view.insertElement(element);
   setInsertMode();
  }

 private void insertNewLineBefore()
  {
   Element element = new Element(_view.document());
   _view.insertElementBefore(element);
   setInsertMode();
  }

 private void undo()
  {
   Undo undo = _view.document().undo();
   if (undo.redoAvailable())
    {
     undo.redo(_view);
    }
   else
    {
     undo.undo(_view);
    }

   _savedElement = null;
   _savedText = null;
   setCommandMode();
  }

 private void undoLine()
  {
   if (_savedElement != null &&
       _savedElement == _view.documentPosition().element())
    {
     _view.overlayElements(_savedText);
     _view.documentPosition().home();
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
    }
  }

 private void deleteCharacter()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   String deletedText = _view.deleteText(_count);
   storeInBuffer(deletedText);
   setCommandMode();
  }

 private void deleteCharacterBefore()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   int position = _view.documentPosition().position();
   if (_count <= position - 1)
    {
     _view.documentPosition().left(_count);
     String deletedText = _view.deleteText(_count);
     storeInBuffer(deletedText);
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
    }
   setCommandMode();
  }

 private void pasteAfter()
  {
   if (_buffers[_currentBuffer] != null && _buffers[_currentBuffer].length() > 0)
    {
     if (_buffers[_currentBuffer].charAt(0) == '\n')
      {
       // original documentation has an optional count for the p command!? *as*
       Element element = new Element(_view.document());
       _view.insertElement(element);
       _view.insertText(_buffers[_currentBuffer].substring(1));
      }
     else
      {
       _view.documentPosition().right();
       // original documentation has an optional count for the p command!? *as*
       _view.insertText(_buffers[_currentBuffer]);
      _view.documentPosition().left();
      }

     setCommandMode();
    }
  }

 private void paste()
  {
   if (_buffers[_currentBuffer] != null && _buffers[_currentBuffer].length() > 0)
    {
     if (_buffers[_currentBuffer].charAt(0) == '\n')
      {
       // original documentation has an optional count for the P command!? *as*
       Element element = new Element(_view.document());
       _view.insertElementBefore(element);
       _view.insertText(_buffers[_currentBuffer].substring(1));
      }
     else
      {
       // original documentation has an optional count for the P command!? *as*
       _view.insertText(_buffers[_currentBuffer]);
      _view.documentPosition().left();
      }

     setCommandMode();
    }
  }

 private void changeToLineEnd()
  {
   int position = _view.documentPosition().position();
   Element element = _view.documentPosition().element();
   if (element != null && !element.show())
    {
     String text = element.text();
     if (text.length() >= position)
      {
       String deletedText = _view.deleteText(element, position,
                                             text.length() - position + 1);
       storeInBuffer(deletedText);
      }
    }

   setInsertMode();
  }

 private void deleteToLineStart()
  {
   int position = _view.documentPosition().position();
   Element element = _view.documentPosition().element();
   if (element != null && !element.show())
    {
     String deletedText = _view.deleteText(element, 1, position - 1);
     storeInBuffer(deletedText);
    }

   setCommandMode();
  }

 private void deleteToLineEnd()
  {
   int position = _view.documentPosition().position();
   Element element = _view.documentPosition().element();
   if (element != null && !element.show())
    {
     String text = element.text();
     if (text.length() >= position)
      {
       String deletedText = _view.deleteText(element, position,
                                             text.length() - position + 1);
       storeInBuffer(deletedText);
      }
    }

   setCommandMode();
  }

 private void deleteToWordEnd()
  {
   int position = _view.documentPosition().position();
   Element element = _view.documentPosition().element();
   if (element != null && !element.show())
    {
     if (_count == 0)
      {
       _count = 1;
      }
     String deletedText = "";
     for (int i = 0; i < _count; i++)
      {
       int wordEndPosition = ElementList.nextWordEnd(element, position);
       if (wordEndPosition == 0)
        {
         wordEndPosition = position;
        }
       deletedText += _view.deleteText(element, position,
                                       wordEndPosition - position + 2);
      }
     storeInBuffer(deletedText);
    }

   setCommandMode();
  }

 private void deleteLine()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   int lastOrdinal = 0;
   String deletedText = "";
   ElementList elementList = _view.document().elementList();
   for (int i = 0; i < _count; i++)
    {
     Element element = _view.documentPosition().element();
     if (element != null)
      {
       int ordinal = elementList.ordinalOf(element);
       if (ordinal >= lastOrdinal &&
           !_view.markList().protect(element) &&
           (element.show() || _view.changeAllowed()))
        {
         deletedText += "\n" + element.text();
         _view.deleteElement(element);
        }
       else
        {
         break;
        }
       lastOrdinal = ordinal;
      }
    }

   storeInBuffer(deletedText);
   setCommandMode();
  }

 private void changeLine()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   int lastOrdinal = 0;
   String deletedText = "";
   ElementList elementList = _view.document().elementList();
   for (int i = 0; i < _count - 1; i++)
    {
     Element element = _view.documentPosition().element();
     if (element != null)
      {
       int ordinal = elementList.ordinalOf(element);
       if (ordinal >= lastOrdinal &&
           !_view.markList().protect(element) &&
           (element.show() || _view.changeAllowed()))
        {
         deletedText += "\n" + element.text();
         _view.deleteElement(element);
        }
       else
        {
         break;
        }
       lastOrdinal = ordinal;
      }
    }

   Element element = _view.documentPosition().element();
   if (element != null)
    {
     if (_count > 1)
      {
       deletedText += "\n";
      }
     if (element.show())
      {
       deletedText += element.text();
       element = new Element(_view.document());
       _view.insertElement(element);
       _view.deleteElement(element);
      }
     else
      {
       deletedText += _view.deleteText(element, 1, element.text().length());
       _view.documentPosition().home();
      }
    }
   else
    {
     element = new Element(_view.document());
     _view.insertElement(element);
    }

   storeInBuffer(deletedText);
   _ignoreCount = true;
   setInsertMode();
  }

 private void yankToLineStart()
  {
   int position = _view.documentPosition().position();
   Element element = _view.documentPosition().element();
   if (element != null)
    {
     String text = element.text();
     if (position > text.length())
      {
       position = text.length();
      }
     if (position > 0)
      {
       storeInBuffer(text.substring(0, position));
      }
    }

   setCommandMode();
  }

 private void yankToLineEnd()
  {
   int position = _view.documentPosition().position();
   Element element = _view.documentPosition().element();
   if (element != null)
    {
     String text = element.text();
     if (text.length() >= position)
      {
       storeInBuffer(text.substring(position - 1));
      }
    }

   setCommandMode();
  }

 private void yankToWordEnd()
  {
   int position = _view.documentPosition().position();
   Element element = _view.documentPosition().element();
   if (element != null)
    {
     String text = element.text();
     if (text.length() >= position)
      {
       int wordEndPosition = ElementList.nextWordEnd(element, position);
       if (wordEndPosition == 0)
        {
         wordEndPosition = position;
        }
       else
        {
         wordEndPosition++;
        }
       if (wordEndPosition > text.length())
        {
         wordEndPosition = text.length();
        }
       storeInBuffer(text.substring(position - 1, wordEndPosition));
      }
    }

   setCommandMode();
  }

 private void yankLine()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   String yankedText = "";
   Element element = _view.documentPosition().element();
   for (int i = 0; i < _count && element != null; i++)
    {
     yankedText += "\n" + element.text();
     element = element.nextVisible(_view);
    }

   storeInBuffer(yankedText);
   setCommandMode();
  }

 private void scrollPageBackward()
  {
   if (_count == 0)
    {
     _count = 1;
    }
   for (int i = 0; i < _count; i++)
    {
     _view.documentPosition().pageUp();
    }

   setCommandMode();
  }

 private void scrollPageForward()
  {
   if (_count == 0)
    {
     _count = 1;
    }
   for (int i = 0; i < _count; i++)
    {
     _view.documentPosition().pageDown();
    }

   setCommandMode();
  }

 private void scrollBackwardHalfScreen()
  {
   if (_count == 0)
    {
     _count = _view.screen().rows() / 2;
    }

   scrollBackward();
  }

 private void scrollForwardHalfScreen()
  {
   if (_count == 0)
    {
     _count = _view.screen().rows() / 2;
    }

   scrollForward();
  }

 private void scrollBackward()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   _view.documentPosition().scrollUp(_count);
   setCommandMode();
  }

 private void scrollForward()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   _view.documentPosition().scrollDown(_count);
   setCommandMode();
  }

 private void endOfLine()
  {
   _view.documentPosition().end();
   setCommandMode();
  }

 private void startOfLine()
  {
   _view.documentPosition().home();
   setCommandMode();
  }

 private void firstNonWhitespace()
  {
   Element element = _view.documentPosition().element();
   if (element != null)
    {
     String text = element.text();
     int position = 1;
     while (text.length() >= position &&
            Character.isWhitespace(text.charAt(position - 1)))
      {
       position++;
      }
     _view.documentPosition().jump(element, position);
    }

   setCommandMode();
  }

 private void matchingParenthesisOrBrace()
  {
   Element element = _view.documentPosition().element();
   if (element != null)
    {
     String text = element.text();
     int position = _view.documentPosition().position();
     int savePosition = position;
     char matchChar = 0;
     while (position <= text.length())
      {
       char c = text.charAt(position - 1);
       if (c == '{' || c == '[' || c == '(' || c == ')' || c == ']' || c == '}')
        {
         matchChar = c;
         break;
        }
       position++;
      }

     if (matchChar != 0)
      {
       switch (matchChar)
        {
         case '{':
          {
           matchChar = '}';
           break;
          }
         case '(':
          {
           matchChar = ')';
           break;
          }
         case '[':
          {
           matchChar = ']';
           break;
          }
         case '}':
          {
           matchChar = '{';
           break;
          }
         case ')':
          {
           matchChar = '(';
           break;
          }
         case ']':
          {
           matchChar = '[';
           break;
          }
        }

       String direction = "";
       if (matchChar == '{' || matchChar == '(' || matchChar == '[')
        {
         direction = "up ";
        }
       _view.documentPosition().jump(element, position);
       FindTextCommand.doCommand(_view, direction + "noWrap " + matchChar);
       if (CommandHandler._status != null)
        {
         _view.documentPosition().jump(element, savePosition);
        }
      }
     else
      {
       BeepParameter.getParameter().setValue(true);
      }
    }

   setCommandMode();
  }

 private void column()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   Element element = _view.documentPosition().element();
   if (element != null)
    {
     _view.documentPosition().jump(element, _count);
    }

   setCommandMode();
  }

 private void firstNonWhitespaceOnNextLine()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   _view.documentPosition().down(_count);
   firstNonWhitespace();
  }

 private void firstNonWhitespaceOnNextLineMinus1()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   _count--;
   if (_count > 0)
    {
     _view.documentPosition().down(_count);
    }

   firstNonWhitespace();
  }

 private void firstNonWhitespaceOnPreviousLine()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   _view.documentPosition().up(_count);
   firstNonWhitespace();
  }

 private void startOfWord()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   for (int i = 0; i < _count; i++)
    {
     _view.documentPosition().prevWord();
    }

   setCommandMode();
  }

 private void endOfWord()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   for (int i = 0; i < _count; i++)
    {
     _view.documentPosition().nextWordEnd();
    }

   setCommandMode();
  }

 private void goToLine()
  {
   beforeJump();
   if (_count == 0 || _count > _view.document().elementList().nonShowCount())
    {
     _view.documentPosition().bottom();
    }
   else
    {
     Element element = _view.document().elementList().nonShowElementAt(_count);
     if (element != null)
      {
       _view.documentPosition().jump(element, 1);
      }
    }

   firstNonWhitespace();
  }

 private void firstNonWhitespaceAtScreenTop()
  {
   _view.documentPosition().windowTop();
   for (int i = 1; i < _count; i++)
    {
     _view.documentPosition().down();
    }

   firstNonWhitespace();
  }

 private void firstNonWhitespaceAtScreenMiddle()
  {
   _view.documentPosition().windowMiddle();
   firstNonWhitespace();
  }

 private void firstNonWhitespaceAtScreenBottom()
  {
   _view.documentPosition().windowBottom();
   for (int i = 1; i < _count; i++)
    {
     _view.documentPosition().up();
    }

   firstNonWhitespace();
  }

 private void nextWord()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   for (int i = 0; i < _count; i++)
    {
     _view.documentPosition().nextWord();
    }

   setCommandMode();
  }

 private void scrollTop()
  {
   if (_count != 0)
    {
     if (_count > _view.document().elementList().nonShowCount())
      {
       _view.documentPosition().bottom();
      }
     else
      {
       Element element = _view.document().elementList().nonShowElementAt(_count);
       if (element != null)
        {
         _view.documentPosition().jump(element, 1);
        }
      }
    }

   _view.screen().setCursorRow(1);
   setCommandMode();
  }

 private void scrollCenter()
  {
   if (_count != 0)
    {
     if (_count > _view.document().elementList().nonShowCount())
      {
       _view.documentPosition().bottom();
      }
     else
      {
       Element element = _view.document().elementList().nonShowElementAt(_count);
       if (element != null)
        {
         _view.documentPosition().jump(element, 1);
        }
      }
    }

   _view.screen().setCursorRow((_view.screen().rows() + 1) / 2);
   setCommandMode();
  }

 private void scrollBottom()
  {
   if (_count != 0)
    {
     if (_count > _view.document().elementList().nonShowCount())
      {
       _view.documentPosition().bottom();
      }
     else
      {
       Element element = _view.document().elementList().nonShowElementAt(_count);
       if (element != null)
        {
         _view.documentPosition().jump(element, 1);
        }
      }
    }

   _view.screen().setCursorRow(_view.screen().rows());
   setCommandMode();
  }

 private void substitute()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   String deletedText = _view.deleteText(_count);
   storeInBuffer(deletedText);
   _ignoreCount = true;
   setInsertMode();
  }

 private void findCharacter()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   int position = _view.documentPosition().position(); //@ww - removed +1
   Element element = _view.documentPosition().element();
   String text = element.text();
   boolean found = false;

   for (int i = 0; i < _count; i++)
    {
     found = false;
     ++position; //@ww - add 1 to move past the previous find (1st time compensates for removal of +1 above)

     while (position <= text.length())
      {
       if (text.charAt(position - 1) == _findCharacter)
        {
         found = true;
         break;
        }
       position++;
      }
    }

   if (found)
    {
     if (_findCharacterCommand == 't' || _findCharacterCommand == 'T')
      {
       position--;
      }
     _view.documentPosition().jump(element, position);
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
    }

   setCommandMode();
  }

 private void reverseFindCharacter()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   int position = _view.documentPosition().position();    //@ww - removed -1
   Element element = _view.documentPosition().element();
   String text = element.text();
   if (position > text.length())
    {
     position = text.length();
    }

   boolean found = false;
   for (int i = 0; i < _count; i++)
    {
     found = false;
     --position;   //@ww subtract 1 to move past previous find (1st time covers removal of -1 above)
     while (position > 0)
      {
       if (text.charAt(position - 1) == _findCharacter)
        {
         found = true;
         break;
        }
       position--;
      }
    }

   if (found)
    {
     if (_findCharacterCommand == 't' || _findCharacterCommand == 'T')
      {
       position++;  //@ww - change -- to ++ since in this direction, cursor should be after c
      }
     _view.documentPosition().jump(element, position);
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
    }

   setCommandMode();
  }

 private void repeatFindCharacter()
  {
   if (_findCharacterCommand == 'f' || _findCharacterCommand == 't')
    {
     findCharacter();
    }
   else if (_findCharacterCommand == 'F' || _findCharacterCommand == 'T')
    {
     reverseFindCharacter();
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
     setCommandMode();
    }
  }

 private void reverseRepeatFindCharacter()
  {
   if (_findCharacterCommand == 'f' || _findCharacterCommand == 't')
    {
     reverseFindCharacter();
    }
   else if (_findCharacterCommand == 'F' || _findCharacterCommand == 'T')
    {
     findCharacter();
    }
   else
    {
     BeepParameter.getParameter().setValue(true);
     setCommandMode();
    }
  }

 private void exCommand(char c)
  {
   if (_view.window() != null)
    {
     CommandLine commandLine = (CommandLine) _view.window().commandLine();
     commandLine.setMode(CommandLine.MODE_COMMANDS);
     commandLine.setForceVisible(true);
     _view.window().commandLineRequestFocus();
     commandLine.setCommandText(String.valueOf(c));
    }
  }

 private void toggleCharacterCase()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   for (int i = 0; i < _count; i++)
    {
     int position = _view.documentPosition().position();
     Element element = _view.documentPosition().element();
     String text = element.text();
     if (position <= text.length())
      {
       char c = text.charAt(position - 1);
       if (Character.isLowerCase(c))
        {
         _view.replaceText(String.valueOf(Character.toUpperCase(c)));
        }
       else if (Character.isUpperCase(c))
        {
         _view.replaceText(String.valueOf(Character.toLowerCase(c)));
        }
       else
        {
         _view.documentPosition().right();
        }
      }
     else
      {
       _view.documentPosition().right();
      }
    }

   setCommandMode();
  }

 private void join()
  {
   if (_count == 0)
    {
     _count = 1;
    }
   for (int i = 0; i < _count; i++)
    {
     Element element = _view.documentPosition().element();
     if (element != null && !element.show())
      {
       Element element2 = element.nextVisibleNonShow(_view);
       _view.joinElements(element, element2);
      }
    }

   setCommandMode();
  }

 private void repeatFind()
  {
   if (_count == 0)
    {
     _count = 1;
    }
   beforeJump();
   for (int i = 0; i < _count; i++)
    {
     doCommand(_findCommand);
    }

   setCommandMode();
  }

 private void repeatSubstitute()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   beforeJump();
   for (int i = 0; i < _count; i++)
    {
     doCommand(_substituteCommand);
    }

   setCommandMode();
  }

 private void reverseRepeatFind()
  {
   if (_count == 0)
    {
     _count = 1;
    }

   beforeJump();
   for (int i = 0; i < _count; i++)
    {
     if (_findCommand.charAt(0) == '?')
      {
       FindTextCommand.doCommand(_view, "asis " +
                                 LpexStringTokenizer.addQuotes(_findCommand.substring(1)));
      }
     else if (_findCommand.charAt(0) == '/')
      {
       FindTextCommand.doCommand(_view, "up asis " +
                                 LpexStringTokenizer.addQuotes(_findCommand.substring(1)));
      }
    }

   setCommandMode();
  }

 private void repeatLastChange()
  {
   if (_lastChangeCommand != null && _lastChangeCommand.length() > 0)
    {
     int saveLastChangeCount = _lastChangeCount;
     int saveLastChangeBuffer = _lastChangeBuffer;
     String saveLastChangeCommand = _lastChangeCommand;

     if (_count == 0)
      {
       _count = _lastChangeCount;
      }
     if (_currentBuffer == 0)
      {
       _currentBuffer = _lastChangeBuffer;
      }

     for (int i = 0; i < saveLastChangeCommand.length(); i++)
      {
       processCharacter(saveLastChangeCommand.charAt(i));
      }
     _lastChangeCount = saveLastChangeCount;
     _lastChangeBuffer = saveLastChangeBuffer;
     _lastChangeCommand = saveLastChangeCommand;
    }
  }

 private void storeInBuffer(String text)
  {
   if (text != null && text.length() != 0)
    {
     if (_currentBuffer >= 9)
      {
       if (_buffers[_currentBuffer] != null && _appendToBuffer)
        {
         _buffers[_currentBuffer] += text;
        }
       else
        {
         _buffers[_currentBuffer] = text;
        }
      }

     else
      {
       for (int i = 8; i > 0; i--)
        {
         _buffers[i] = _buffers[i-1];
        }
       _buffers[0] = text;
      }
    }
  }

 private void startChangeCommand(char c)
  {
   _lastChangeCount = _count;
   _lastChangeCommand = String.valueOf(c);
   _lastChangeBuffer = _currentBuffer;

   if (_savedElement != _view.documentPosition().element())
    {
     _savedElement = _view.documentPosition().element();
     if (_savedElement.show())
      {
       _savedElement = null;
      }
     _savedText = (_savedElement != null)? _savedElement.text() : null;
    }
  }

 /**
  * Set a quick mark before a jump.
  */
 private void beforeJump()
  {
   SetCommand.doCommand(_view, "mark.@QUICK");
  }

 private void expandAbbreviation()
  {
   if (_abbreviations.first() != null)
    {
     String lastWord = _insertString;
     for (int i = _insertString.length() - 1; i >= 0; i--)
      {
       char c = _insertString.charAt(i);
       if (c == ' ' || c == '\n' || c == '\t')
        {
         if (i < _insertString.length() - 1)
          {
           lastWord = _insertString.substring(i + 1);
          }
         else
          {
           lastWord = "";
          }
         break;
        }
      }

     if (lastWord.length() > 0)
      {
       String substitutionString = (String) _abbreviations.query(lastWord);
       if (substitutionString != null)
        {
         for (int i =0; i < lastWord.length(); i++)
          {
           processInputCharacter((char) 8);
          }
         for (int i = 0; i < substitutionString.length(); i++)
          {
           processInputCharacter(substitutionString.charAt(i));
          }
        }
      }
    }
  }


 private final static class Command
  {
   String _commandString;
   int _currentPosition = 0;
   int _x = 0;
   int _y = 0;

   Command(String commandString)
    {
     _commandString = commandString;
     if (_commandString.length() > 0 && _commandString.charAt(0) == ':')
      {
       _currentPosition++;
       String integer = "";
       while (_currentPosition < _commandString.length())
        {
         char c = _commandString.charAt(_currentPosition);
         if (c >= '0' && c <= '9')
          {
           integer += c;
           _currentPosition++;
          }
         else
          {
           break;
          }
        }

       if (integer.length() > 0)
        {
         _x = Integer.parseInt(integer);
        }

       if (_currentPosition < _commandString.length())
        {
         char c = _commandString.charAt(_currentPosition);
         if (c == ',')
          {
           _currentPosition++;
           integer = "";
           while (_currentPosition < _commandString.length())
            {
             c = _commandString.charAt(_currentPosition);
             if (c >= '0' && c <= '9')
              {
               integer += c;
               _currentPosition++;
              }
             else
              {
               break;
              }
            }

           if (integer.length() > 0)
            {
             _y = Integer.parseInt(integer);
            }
          }
        }
      }
    }

   boolean isCommand(String expectedCommand, int significantCharacters)
    {
     if (_commandString.length() >= significantCharacters)
      {
       int i, j;
       for (i = 0, j = _currentPosition; i < expectedCommand.length(); i++, j++)
        {
         if (j >= _commandString.length() ||
             _commandString.charAt(j) != expectedCommand.charAt(i))
          {
           if (i >= significantCharacters)
            {
             break;
            }
           return false;
          }
        }

       _currentPosition = j;
       return true;
      }
     return false;
    }

   boolean skipCharacter(char c)
    {
     if (_commandString.length() > _currentPosition &&
         _commandString.charAt(_currentPosition) == c)
      {
       _currentPosition++;
       return true;
      }

     return false;
    }

   boolean skipOptionalCharacter(char c)
    {
     if (_commandString.length() > _currentPosition)
      {
       return skipCharacter(c);
      }

     return true;
    }

   String remainingText()
    {
     if (_commandString.length() > _currentPosition)
      {
       return _commandString.substring(_currentPosition);
      }

     return "";
    }

   String nextToken(char c)
    {
     if (_commandString.length() > _currentPosition)
      {
       int endPosition = _currentPosition;
       while (_commandString.length() > endPosition &&
              _commandString.charAt(endPosition) != c)
        {
         endPosition++;
        }
       String token = _commandString.substring(_currentPosition, endPosition);
       _currentPosition = endPosition;
       return token;
      }

     return "";
    }

   String nextToken()
    {
     if (_commandString.length() > _currentPosition)
      {
       while (skipCharacter(' '));
       int endPosition = _currentPosition;
       while (_commandString.length() > endPosition &&
              _commandString.charAt(endPosition) != ' ')
        {
         endPosition++;
        }
       String token = _commandString.substring(_currentPosition, endPosition);
       _currentPosition = endPosition;
       skipCharacter(' ');
       return token;
      }

     return "";
    }

   boolean noRemainingText()
    {
     while (_currentPosition < _commandString.length() &&
            _commandString.charAt(_currentPosition) == ' ')
      {
       _currentPosition++;
      }

     return _commandString.length() <= _currentPosition;
    }
  }
}