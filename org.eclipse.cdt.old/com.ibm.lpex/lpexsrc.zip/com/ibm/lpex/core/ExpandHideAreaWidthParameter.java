//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ExpandHideAreaWidthParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ExpandHideAreaWidthParameter extends ParameterIntegerQuery
{
 private static ExpandHideAreaWidthParameter _parameter;

 static ExpandHideAreaWidthParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ExpandHideAreaWidthParameter();
   }
  return _parameter;
 }

 private ExpandHideAreaWidthParameter()
 {
  super(PARAMETER_EXPAND_HIDE_AREA_WIDTH);
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.screen().expandHideAreaWidth() : 0;
 }
}