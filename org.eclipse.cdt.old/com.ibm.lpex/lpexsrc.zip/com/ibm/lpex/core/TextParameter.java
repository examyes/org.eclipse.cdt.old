//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// TextParameter - handles the text parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>text</b> parameter.
 */
final class TextParameter extends Parameter
{
 private static TextParameter _parameter;

 static TextParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new TextParameter();
   }
  return _parameter;
 }

 private TextParameter()
 {
  super(LpexConstants.PARAMETER_TEXT);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  if (view != null)
   {
    Element element = view.documentPosition().element();
    if (element != null)
     {
      if (element.show())
       {
        element.setText(view, parameters); // set text of SHOW element
       }
      else
       {
        view.overlayElements(parameters);  // set text of regular element
       }
     }
   }
  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null && documentLocation != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    return (element != null)? element.text() : null;
   }

  return null;
 }
}