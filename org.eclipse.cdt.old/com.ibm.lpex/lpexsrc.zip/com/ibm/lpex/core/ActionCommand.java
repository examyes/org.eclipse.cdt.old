//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ActionCommand - handles the action command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>action</b> command.
 */
final class ActionCommand
{
 static boolean doCommand(View view, String parameters)
 {
  if (view != null)
   {
    LpexStringTokenizer st = new LpexStringTokenizer(parameters);
    if (!st.hasMoreTokens())
     {
      view.setLpexMessageText(LpexConstants.MSG_ACTION_INCOMPLETE);
     }
    else
     {
      int actionId = view.actionHandler().id(parameters);
      if (actionId == LpexConstants.ACTION_INVALID)
       {
        view.setLpexMessageText(LpexConstants.MSG_ACTION_INVALID, parameters);
       }
      else
       {
        view.actionHandler().doActionIfAvailable(actionId);
        return true;
       }
     }
   }

  return false;
 }
}