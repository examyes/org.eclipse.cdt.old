//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Utilities - various utilities implemented here in order to reduce
// development-platform dependency of other LPEX source code.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.jar.Attributes;

// basic Eclipse SWT support (SWT LPEX widget)
import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Widget;

// Eclipse workbench (LPEX Plugin) & others (e.g., non-public API BidiUtil)
import com.ibm.lpex.alef.LpexPlugin;
import org.eclipse.swt.internal.BidiUtil;


/**
 * This class implements various utilities which have dependency on a
 * particular development platform.
 * This implementation contains Eclipse Platform dependent classes.
 */
public final class LpexUtilities
{
   private static boolean _bidiChecked;
   private static boolean _isBidi;


   // class is not supposed to be instantiated
   private LpexUtilities() {}

   /**
    * Return the underlying development platform of this LPEX widget.
    *
    * @return <code>LpexConstants.PLATFORM_SWT</code> - Eclipse Platform (SWT)
    */
   public static int getPlatform()
   {
      return LpexConstants.PLATFORM_SWT;
   }

   /**
    * Issue a beep.
    */
   static void beep()
   {
      Display.getDefault().beep();
   }

   /**
    * Set copy/cut text into the clipboard.
    */
   static void setClipboardContents(final String text)
   {
      TextTransfer transfer = TextTransfer.getInstance();
      Clipboard clipboard = new Clipboard(Display.getDefault());
      clipboard.setContents(new String[] {text}, new Transfer[] {transfer});
      clipboard.dispose();
   }

   /**
    * Get the clipboard text, if any.
    * The SWT clipboard text may be line-delimited by CRLF ("\r\n"), CR ('\r'), LF ('\n').
    *
    * @return clipboard text, or <code>null</code>
    */
   static String getClipboardContents()
   {
      TextTransfer transfer = TextTransfer.getInstance();
      Clipboard clipboard = new Clipboard(Display.getDefault());
      String text = (String)clipboard.getContents(transfer);
      clipboard.dispose();
      return text;
   }

   /**
    * Select a file name through the File Dialog.  If the file dialog cannot be
    * displayed (there is no Shell associated with, or set in, the view),
    * <code>defaultFile</code> is returned.
    *
    * @param view        the LPEX View whose Shell is the parent of the dialog
    * @param title       the title of the dialog
    * @param saving      true = file save dialog, false = file load mode
    * @param defaultFile the default selected file for this file dialog window
    *
    * @return            the absolute pathname string of the selected file
    */
   static String fileDialog(View view, String title, boolean saving,
                            String defaultFile)
   {
      Shell frame = view.lpexView().frame();
      if (frame == null)
         return defaultFile;

      FileDialog fileDialog =
         new FileDialog(frame,
                        saving? SWT.SAVE : SWT.OPEN);
      fileDialog.setText(title);
      if (defaultFile != null)
         fileDialog.setFileName(defaultFile);

      String fileName = fileDialog.open();    // full pathname of selected file

      fileDialog = null;                      // enforce some garbage collection
      System.gc();
      return fileName;
   }

   /**
    * Return the LPEX version for the <b>version</b> parameter.
    * For example:  <code>Editor 1.3.0 (build Jun 3, 2001)</code>.
    */
   static String getVersion()
   {
      String version = null;
      String build = null;

      // try first a package in the LPEX .jar, if defined in the ClassLoader
      Package lpex = Package.getPackage("com.ibm.lpex.core");
      if (lpex != null) {
         version = lpex.getSpecificationVersion();
         build   = lpex.getImplementationVersion();
         }

      // try the Eclipse LPEX plugin .jar, in case we're running as such
      if (version == null || build == null) {
         try {
            Attributes attr = LpexPlugin.getLpexJar().getManifest().getMainAttributes();
            //-as- should get the version from the plugin.xml attribute?!
            version = attr.getValue(Attributes.Name.SPECIFICATION_VERSION);
            build = attr.getValue(Attributes.Name.IMPLEMENTATION_VERSION);
            }
         catch(Throwable x) {
            // NB Throwable, not just Exception - e.g., LpexPlugin class not there
            }
         }

      if (version == null)
         version = LpexConstants.LPEX_VERSION;
      String query = "Editor " + version;
      if (build != null)
         query += " (build " + build + ")";

      return query;
   }

   /**
    * Query whether an SWT Widget is usable.
    *
    * @param widget the Widget to check
    *
    * @return <code>false</code> if the widget is <code>null</code> or disposed
    */
   public static boolean okToUse(Widget widget)
   {
      return (widget != null && !widget.isDisposed());
   }

   /**
    * Debug method for LpexNls#nlsSimulator().
    * Set an IME input method (when one cannot be easily set via the
    * workstation's hotkey assigned for this purpose)...
    */
   static void setImeInputMethod(LpexView lpexView)
   {
      lpexView.window().getShell().setImeInputMode(SWT.DBCS | SWT.PHONETIC);
   }

   /**
    * Are we running in a bidirectional environment which we can handle?
    * This method checks whether the native encoding is bidi (Arabic, Hebrew,
    * etc.), and if we can handle it.  Eclipse R2.0 handles bidi functions on
    * the MS Windows platforms, through several <i>internal</i> functions
    * in org.eclipse.swt.internal#BidiUtil (i.e., not public API).
    *
    * @see LpexNls
    */
   static boolean isBidi()
   {
      if (!_bidiChecked) {
         _bidiChecked = true;
         String nativeEncoding = LpexNls.getNativeEncoding();
         // if LPEX considers it bidi...
         if (LpexNls.isBidiEncoding(nativeEncoding) && LpexNls.isValidEncoding(nativeEncoding)) {
            // ...and so does Eclipse (which gives us the bidi support), then it's bidi
            try {
               _isBidi = BidiUtil.isBidiPlatform();
               }
            catch(Throwable x) {
               // NB Throwable, not just Exception - e.g., BidiUtil class not available to us
               }
            }
         }

      return _isBidi;
   }
}