//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Utilities - various utilities implemented here in order to reduce
// development-platform dependency of other LPEX source code.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.jar.Attributes;

import com.ibm.lpex.alef.LpexPlugin;

import org.eclipse.swt.SWT;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Widget;


/**
 * This class implements various utilities which have dependency on a
 * particular development platform.
 * This implementation contains Eclipse Platform's
 * <code>org.eclipse.swt</code>-dependent classes.
 */
public final class LpexUtilities
{
   /**
    * Return the underlying development platform of this LPEX widget.
    *
    * @return <code>LpexConstants.PLATFORM_SWT</code> - Eclipse Platform SWT
    */
   public static int getPlatform()
   {
      return LpexConstants.PLATFORM_SWT;
   }

   /**
    * Issue a beep.
    */
   static void beep()
   {
      Display.getDefault().beep();
   }

   /**
    * Set copy/cut text into the clipboard.
    */
   static void setClipboardContents(final String text)
   {
      TextTransfer transfer = TextTransfer.getInstance();
      Clipboard clipboard = new Clipboard(Display.getDefault());
      clipboard.setContents(new String[] {text}, new Transfer[] {transfer});
      clipboard.dispose();
   }

   /**
    * Get the clipboard text, if any.
    */
   static String getClipboardContents()
   {
      TextTransfer transfer = TextTransfer.getInstance();
      Clipboard clipboard = new Clipboard(Display.getDefault());
      String text = (String)clipboard.getContents(transfer);
      clipboard.dispose();
      if (text == null)
         return null;

      // apres org.eclipse.swt.custom.StyledText.java/getModelDelimitedText():
      // replace various line delimiters with the '\n' that we dig;
      // possible line delimiters: cr ('\r'), lf ('\n'), cr/lf ("\r\n")
      int len = text.length();
      if (len == 0)
         return text;

      int crIndex = 0;
      int lfIndex = 0;
      int i = 0;

      StringBuffer convertedText = new StringBuffer(len);
      while (i < len) {
         if (crIndex != -1)
            crIndex = text.indexOf('\r', i);
         if (lfIndex != -1)
            lfIndex = text.indexOf('\n', i);
         if (lfIndex == -1 && crIndex == -1)
            break;                             // no more line breaks

         // cr occurs before lf OR no lf present
         if ((crIndex < lfIndex && crIndex != -1) || lfIndex == -1) {
            convertedText.append(text.substring(i, crIndex));
            if (lfIndex == crIndex + 1)   // cr/lf combination?
               i = lfIndex + 1;
            else
               i = crIndex + 1;
            }
         else { // lf occurs before cr
            convertedText.append(text.substring(i, lfIndex));
            i = lfIndex + 1;
            }
         convertedText.append('\n');
         }

      if (i < len)
         convertedText.append(text.substring(i));

      return convertedText.toString();
   }

   /**
    * Select a file name through the File Dialog.  If the file dialog cannot be
    * displayed (there is no Shell associated with, or set in, the view),
    * <code>defaultFile</code> is returned.
    *
    * @param view        the LPEX View whose Shell is the parent of the dialog
    * @param title       the title of the dialog
    * @param saving      true = file save dialog, false = file load mode
    * @param defaultFile the default selected file for this file dialog window
    *
    * @return            the absolute pathname string of the selected file
    */
   static String fileDialog(View view, String title, boolean saving,
                            String defaultFile)
   {
      Shell frame = view.lpexView().frame();
      if (frame == null)
         return defaultFile;

      FileDialog fileDialog =
         new FileDialog(frame,
                        saving? SWT.SAVE : SWT.OPEN);
      fileDialog.setText(title);
      if (defaultFile != null)
         fileDialog.setFileName(defaultFile);

      String fileName = fileDialog.open();    // full pathname of selected file

      fileDialog = null;                      // enforce some garbage collection
      System.gc();
      return fileName;
   }

   /**
    * Return the LPEX version for the <b>version</b> parameter.
    * For example:  <code>Editor 1.3.0 (build Jun 3, 2001)</code>.
    */
   static String getVersion()
   {
      String version = null;
      String build = null;

      // try first a package in the LPEX .jar, if defined in the ClassLoader
      Package lpex = Package.getPackage("com.ibm.lpex.core");
      if (lpex != null) {
         version = lpex.getSpecificationVersion();
         build   = lpex.getImplementationVersion();
         }

      // try the Eclipse LPEX plugin .jar, in case we're running as such
      if (version == null || build == null) {
         try {
            Attributes attr = LpexPlugin.getLpexJar().getManifest().getMainAttributes();
            //-as- should get the version from the plugin.xml attribute?!
            version = attr.getValue(Attributes.Name.SPECIFICATION_VERSION);
            build = attr.getValue(Attributes.Name.IMPLEMENTATION_VERSION);
            }
         catch(Throwable x) {
            // NB Throwable, not just Exception - e.g., LpexPlugin class not there
            }
         }

      if (version == null)
         version = LpexConstants.LPEX_VERSION;
      String query = "Editor " + version;
      if (build != null)
         query += " (build " + build + ")";

      return query;
   }

   /**
    * Query whether an SWT Widget is usable.
    *
    * @param widget the Widget to check
    *
    * @return <code>false</code> if the widget is <code>null</code> or disposed
    */
   public static boolean okToUse(Widget widget)
   {
      return (widget != null && !widget.isDisposed());
   }
}