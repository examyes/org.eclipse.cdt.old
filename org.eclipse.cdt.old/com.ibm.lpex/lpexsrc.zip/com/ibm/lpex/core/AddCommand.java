//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// AddCommand - handles the add command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>add</b> command.
 */
final class AddCommand
{
 static boolean doCommand(View view, String parameters)
 {
  int count = 1;
  boolean before = false;
  boolean show = false;

  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    if (token.equals("before"))
     {
      before = true;
      token = st.hasMoreTokens()? st.nextToken() : null;
     }

    if (token != null && token.equals("show"))
     {
      show = true;
      token = st.hasMoreTokens()? st.nextToken() : null;
     }

    if (token != null)
     {
      try
       {
        count = Integer.parseInt(token);
        if (count < 1)
         {
          return CommandHandler.invalidParameter(view, token, "add");
         }
        if (st.hasMoreTokens())
         {
          return CommandHandler.invalidParameter(view, st.nextToken(), "add");
         }
       }
      catch(NumberFormatException e)
       {
        return CommandHandler.invalidParameter(view, token, "add");
       }
     }
   }

  // the command format is correct - now, if we have a view, do it
  if (view != null)
   {
    for (int i = 0; i < count; i++)
     {
      Element element = show? new Element(view) : new Element(view.document());
      if (before)
       {
        view.insertElementBefore(element);
       }
      else
       {
        view.insertElement(element);
       }
     }
   }

  return true;
 }
}