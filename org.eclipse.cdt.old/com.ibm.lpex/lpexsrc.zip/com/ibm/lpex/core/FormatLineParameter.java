//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FormatLineParameter - the formatLine parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class FormatLineParameter extends ParameterOnOffDefault
{
   private static FormatLineParameter _parameter;

   static FormatLineParameter getParameter()
   {
      if (_parameter == null)
         _parameter = new FormatLineParameter();
      return _parameter;
   }

   private FormatLineParameter()
   {
      super(PARAMETER_FORMAT_LINE, true);
   }

   boolean setValue(View view, int value)
   {
      if (view != null)
         view.screen().setFormatLine(value);
      return true;
   }

   int value(View view)
   {
      return (view != null)? view.screen().formatLine() : Parameter.DEFAULT;
   }
}