//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Profile - manages the LPEX profile (persistent user settings),
// Profile.properties.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.util.Enumeration;
import java.util.Properties;

import com.ibm.lpex.util.LpexSysutil;


/**
 * This class is used to access the LPEX profile (persistent user settings),
 * <user_directory>\IBM\Editor\Profile.properties.
 */
final class Profile
{
 private static Properties _properties = new Properties();
 private static String _fileName;
 private static boolean _loaded;
 private static List _listeners = new List();


 static private void initFileName()
 {
  if (_fileName == null)
   {
    String home = LpexSysutil.getUserHomeDirectory();
    _fileName = home + File.separator + "Profile.properties";
   }
 }

 static String name()
 {
  if (_fileName == null)
   {
    initFileName();
   }
  return _fileName;
 }

 /**
  * Set a new name for the LPEX profile, and notify all ProfileChanged listeners
  * that the default parameter values have changed.
  */
 static void setName(String name)
 {
  if (name != null)
   {
    name = name.trim();
    if (name.length() == 0)
     {
      name = null;
     }
   }

  _fileName = name;
  _loaded = false;
  for (ListenerNode node = (ListenerNode)_listeners.first();
       node != null;
       node = (ListenerNode)node.next())
   {
    node.listener().profileChanged();
   }
 }

 static private void load()
 {
  if (!_loaded)
   {
    _loaded = true;
    initFileName();
    try
     {
      // Creating a new Properties object effectively blanks out any
      // previous settings.  If _fileName doesn't exist, then it will
      // be created the next time a default property is set.
      _properties = new Properties();
      FileInputStream fileInputStream = new FileInputStream(_fileName);
      _properties.load(fileInputStream);
      fileInputStream.close();
     }
    catch (Exception e) {}
   }
 }

 /**
  * Save Profile.properties in the user home directory.
  */
 static void save()
 {
  initFileName();
  try
   {
    // if _fileName can't be opened, the Profile won't be saved.
    FileOutputStream fileOutputStream = new FileOutputStream(_fileName);
    String version = LpexView.globalQuery("version");
    _properties.store(fileOutputStream,             // output stream
                      "LPEX profile - " + version); // header for property list
    fileOutputStream.close();
   }
  catch (Exception e) {}
 }

 static String getString(String key)
 {
  load();
  return _properties.getProperty(key);
 }

 static String getString(String key, String defaultValue)
 {
  load();
  return _properties.getProperty(key, defaultValue);
 }

 static int getInteger(String key, int defaultValue)
 {
  load();
  String value = _properties.getProperty(key);
  if (value != null)
   {
    try
     {
      return Integer.parseInt(value);
     }
    catch(NumberFormatException e) {}
   }

  return defaultValue;
 }

 static void putString(String key, String string)
 {
  load();
  if (string == null || string.length() == 0)
   {
    _properties.remove(key);
   }
  else
   {
    _properties.put(key, string);
   }
  save();
 }

 static void putInteger(String key, int integer)
 {
  load();
  _properties.put(key, String.valueOf(integer));
  save();
 }

 static void remove(String key)
 {
  load();
  _properties.remove(key);
  save();
 }

 static String getKeys()
 {
  load();
  StringBuffer keys = new StringBuffer(400);
  boolean first = true;
  Enumeration propertyNames = _properties.propertyNames();
  while (propertyNames.hasMoreElements())
   {
    if (!first)
     {
      keys.append(' ');
     }
    first = false;
    keys.append(propertyNames.nextElement());
   }

  return keys.toString();
 }

 static Properties properties()
 {
  load();
  return _properties;
 }

 // If the profile is changed, all listeners will be notified so that
 // they can take appropriate action (e.g., re-set default parameter values).
 static void addProfileChangedListener(ProfileChangedListener listener)
 {
  _listeners.addAfter(null, new ListenerNode(listener));
 }

 static void removeListener(ProfileChangedListener listener)
 {
  for (ListenerNode node = (ListenerNode) _listeners.first();
       node != null;
       node = (ListenerNode) node.next())
   {
    if (node.listener() == listener)
     {
      _listeners.remove(node);
      break;
     }
   }
 }

 /**
  * Entry point to delete the profile.
  * Can be used to clear outdated settings, or when uninstalling the editor.
  * Usage:
  *   java com.ibm.lpex.core.Profile delete
  */
 public static void main(String args[])
 {
  if (args.length == 1 && args[0].equals("delete"))
  //-as- to add option deleteAll to remove all settings in IBM\Editor directory?!
   {
    File profile = new File(name());
    profile.delete();
   }
 }


 interface ProfileChangedListener
 {
  void profileChanged();
 }


 private static class ListenerNode extends ListNode
 {
  private ProfileChangedListener _listener;

  ListenerNode(ProfileChangedListener listener)
  {
   _listener = listener;
  }

  ProfileChangedListener listener()
  {
   return _listener;
  }
 }
}