//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterOnOffDefault - base class for on/off parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Base, abstract class for on/off parameters with install, default, and
 * current settings.
 */
abstract class ParameterOnOffDefault extends ParameterDefault
{
 private boolean _hardCodedValue;
 private boolean _installValue;
 private boolean _installValueLoaded;
 private int     _defaultValue;
 private boolean _defaultValueLoaded;


 ParameterOnOffDefault(String name, boolean hardCodedValue)
 {
  super(name);
  _hardCodedValue = hardCodedValue;
  Install.addProfileChangedListener(new Install.ProfileChangedListener()
   {
    public void profileChanged()
     {
      _installValueLoaded = false;
      if (defaultValue() == INSTALL)
       {
        for (Document document = Document._firstDocument; document != null; document = document._next)
         {
          for (View view = document._firstView; view != null; view = view._next)
           {
            if (value(view) == DEFAULT)
             {
              currentValueChanged(view);
             }
           }
         }
       }
     }
   });

  Profile.addProfileChangedListener(new Profile.ProfileChangedListener()
   {
    public void profileChanged()
     {
      _defaultValueLoaded = false;
      for (Document document = Document._firstDocument; document != null; document = document._next)
       {
        for (View view = document._firstView; view != null; view = view._next)
         {
          if (value(view) == DEFAULT)
           {
            currentValueChanged(view);
           }
         }
       }
     }
   });
 }

 boolean installValue()
 {
  if (!_installValueLoaded)
   {
    String value = Install.getString(PARAMETER_INSTALL + name());
    if (value == null)
     {
      _installValue = _hardCodedValue;
     }
    else
     {
      _installValue = value.equals("on")? true : false;
     }
    _installValueLoaded = true;
   }

  return _installValue;
 }

 int defaultValue()
 {
  if (!_defaultValueLoaded)
   {
    String value = Profile.getString(PARAMETER_DEFAULT + name());
    if (value == null)
     {
      _defaultValue = INSTALL;
     }
    else
     {
      _defaultValue = value.equals("on")? ON : OFF;
     }
    _defaultValueLoaded = true;
   }

  return _defaultValue;
 }

 boolean setDefaultValue(int value)
 {
  if (!_defaultValueLoaded || value != _defaultValue)
   {
    _defaultValue = value;
    _defaultValueLoaded = true;
    if (_defaultValue != INSTALL)
     {
      Profile.putString(PARAMETER_DEFAULT + name(), (_defaultValue == ON)? "on" : "off");
     }
    else
     {
      Profile.remove(PARAMETER_DEFAULT + name());
     }

    for (Document document = Document._firstDocument; document != null; document = document._next)
     {
      for (View view = document._firstView; view != null; view = view._next)
       {
        if (value(view) == DEFAULT)
         {
          currentValueChanged(view);
         }
       }
     }
   }

  return true;
 }

 boolean currentValue(View view)
 {
  int value = value(view);
  if (value == DEFAULT)
   {
    value = defaultValue();
    if (value == INSTALL)
     {
      return installValue();
     }
    return (value == ON)? true : false;
   }

  return (value == ON)? true : false;
 }

 boolean set(View view, String qualifier, String parameters)
 {
  int value = DEFAULT;
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    if (token.equals("on"))
     {
      value = ON;
     }
    else if (token.equals("off"))
     {
      value = OFF;
     }
    else if (token.equals("default"))
     {
      value = DEFAULT;
     }
    else
     {
      return CommandHandler.invalidParameter(view, token, "set " + name());
     }

    if (st.hasMoreTokens())
     {
      return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name());
     }
   }

  return setValue(view, value);
 }

 abstract boolean setValue(View view, int value);

 boolean setDefault(View view, String qualifier, String parameters)
 {
  int value = INSTALL;
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    if (token.equals("on"))
     {
      value = ON;
     }
    else if (token.equals("off"))
     {
      value = OFF;
     }
    else if (token.equals("install"))
     {
      value = INSTALL;
     }
    else
     {
      return CommandHandler.invalidParameter(view, token, "set " + PARAMETER_DEFAULT + name());
     }

    if (st.hasMoreTokens())
     {
      return CommandHandler.invalidParameter(view, st.nextToken(), "set " + PARAMETER_DEFAULT + name());
     }
   }

  return setDefaultValue(value);
 }

 void currentValueChanged(View view) {}

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    int value = value(view);
    return (value == ON)?  "on" :
           ((value == OFF)? "off" : "default");
   }

  return null;
 }

 abstract int value(View view);

 String queryInstall(String qualifier)
 {
  return installValue()? "on" : "off";
 }

 String queryDefault(String qualifier)
 {
  int value = defaultValue();
  return (value == ON)?  "on" :
         ((value == OFF)? "off" : "install");
 }

 String queryCurrent(View view, String qualifier)
 {
  return currentValue(view)? "on" : "off";
 }
}