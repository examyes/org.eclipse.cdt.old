//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Font - LPEX wrapper for the development platform's Font class.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;


//-as- In order not to create Fonts (and their underlying native resources)
//     unnecessarily, we could use here org.eclipse.swt.graphics.FontData, and
//     only instantiate a real org.eclipse.swt.graphics.Font when needed!?...



import java.util.StringTokenizer;

// SWT - minimal package needed by the LPEX widget
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.widgets.Display;

// more Eclipse packages (for the LPEX plugin)
import org.eclipse.jface.resource.JFaceResources;


/**
 * LPEX wrapper for org.eclipse.swt.graphics.Font.
 * <pre>
 *           OS native font
 *                 ^
 *                 |
 *   org.eclipse.swt.graphics.Font
 *                 ^
 *                 |
 *      com.ibm.lpex.core.Font </pre>
 *
 * <p>Note:  currently there is no conversion between the height used by
 * SWT LPEX's Font and FontData, and AWT/Swing LPEX's use of size:
 * SWT LPEX uses height throughout, AWT/Swing LPEX uses size throughout,
 * and there is no real need for conversion betweeen the two.
 */
final class Font
{
   private org.eclipse.swt.graphics.Font _font;
   private String  _name;
   private int     _style;
   private int     _height;
   private boolean _shouldDispose;


   /**
    * Construct a new Font for the specified device (Display / Printer) with
    * the given name, style, and height.
    * The underlying native font object will be disposed when this Font object
    * is.
    *
    * @param name the face name of the font, which may include the foundry
    *             (e.g., "adobe-courier")
    * @param height the height of the font in points
    * @param style a bitwise combination of SWT.NORMAL, SWT.ITALIC, and SWT.BOLD
    */
   Font(Device device, String name, int style, int height)
   {
      _name = name;
      _style = style;
      _height = height;
      _font = new org.eclipse.swt.graphics.Font(device, _name, _height, _style);
      _shouldDispose = true;
   }

   /**
    * Construct a new Font for the specified device (Display / Printer) with
    * the given font data.
    * The underlying native font object will be disposed when this Font object
    * is.
    *
    * @param fontData Eclipse FontData object
    */
   Font(Device device, FontData fontData)
   {
      _font = new org.eclipse.swt.graphics.Font(device, fontData);
      _name = fontData.getName();
      _style = fontData.getStyle();
      _height = fontData.getHeight();
      _shouldDispose = true;
   }

   /**
    * Wrapper a Font around an existing org.eclipse.swt.graphics.Font object.
    * The underlying native font object will not be disposed, when this Font
    * object is discarded, in method finalize().
    */
   Font(org.eclipse.swt.graphics.Font font)
   {
      _font = font;

      // get name, style, and height from the first FontData returned
      // (*as* on AIX must handle font sets!? - see Linux version of StyledText#writeHeader()!?)
		FontData[] fontData = _font.getFontData();
      _name = fontData[0].getName();
      _style = fontData[0].getStyle();
      _height = fontData[0].getHeight();
   }

   /**
    * Retrieve the font name.
    */
   String getName()
   {
      return _name;
   }

   /**
    * Retrieve the font height.
    */
   int getSize()
   {
      return _height;
   }

   /**
    * Retrieve the font style.
    */
   int getStyle()
   {
      return _style;
   }

   /**
    * Returns a new Font, described by <code>fontNameString</code>, for the
    * particular device.
    *
    * If fontNameString is <code>null</code>, the JFace text font is returned
    * for a <code>Display</code> device or, failing that (e.g., if the LPEX
    * widget is running outside Eclipse), a new courier regular
    * <code>Font</code> is returned.
    *
    * If the font style is not specified, regular is assumed.  If the font
    * height is not specified, 9 is assumed.
    *
    * @param device the device to create the font on
    * @param fontNameString the "name-style-height" string representation
    *         of the font, e.g., "adobe-courier-regular-12"
    */
   static Font decodeFont(Device device, String fontNameString)
   {
      try {
         if (fontNameString == null) {
            if (device == null || device instanceof Display)
               return new Font(JFaceResources.getTextFont());
            }
         else {
            StringTokenizer st = new StringTokenizer(fontNameString, "-");
            String name = st.nextToken().trim();
            int style = SWT.NORMAL;
            int height = 9;

            boolean styleFound = false;
            while (st.hasMoreElements()) {
               String token = st.nextToken().trim();
               if (styleFound) { // after style, can only have height
                  try {
                     height = Integer.parseInt(token);
                     }
                  catch (NumberFormatException x) {}
                  }
               else if (token.equals("bolditalic") || token.equals("bold italic")) {
                  styleFound = true;
                  style = SWT.BOLD | SWT.ITALIC;
                  }
               else if (token.equals("bold")) {
                  styleFound = true;
                  style = SWT.BOLD;
                  }
               else if (token.equals("italic")) {
                  styleFound = true;
                  style = SWT.ITALIC;
                  }
               else if (token.equals("regular")) {
                  styleFound = true;
                  }
               else {
                  try {
                     height = Integer.parseInt(token);
                     styleFound = true; // no style expected after height
                     }
                  catch (NumberFormatException x) {
                     name += '-' + token;
                     }
                  }
               }//end "while"

            return new Font(device, name, style, height);
            }
         }
      catch (Throwable x) {}  // no access to JFaceResources / bad fontNameString

      if ("motif".equals(SWT.getPlatform()))                        // "motif"
         return new Font(device, "adobe-courier", SWT.NORMAL, 12);
      return new Font(device, "Courier New", SWT.NORMAL, 9);        // "win32"
   }

   /**
    * Returns a new Font, described by <code>fontNameString</code>.
    * The Device of the SWT Font created is <code>null</code>, which seems okay
    * for display fonts.
    *
    * @see #decodeFont(Device,String)
    */
   static Font decodeFont(String fontNameString)
   {
      // Display display = Display.getCurrent();
      // if (display == null)
      //  display = Display.getDefault();
      return decodeFont(null /*display*/, fontNameString);
   }

   /**
    * Returns a new Font, described by <code>fontDataString</code>, for the
    * particular device.
    *
    * @param device the device to create the font on
    * @param fontDataString a FontData.toString()
    */
   static Font decodeFontData(Device device, String fontDataString)
   {
      FontData fontData = new FontData(fontDataString);
      return new Font(device, fontData);
   }

   /**
    * Returns a new Font, described by <code>fontDataString</code>.
    * The Device of the SWT Font created is <code>null</code>, which seems okay
    * for display fonts.
    *
    * @see #decodeFontData(Device,String)
    */
   static Font decodeFontData(String fontDataString)
   {
      // Display display = Display.getCurrent();
      // if (display == null)
      //  display = Display.getDefault();
      return decodeFontData(null /*display*/, fontDataString);
   }

   static String nameString(Font font)
   {
      if (font != null) {
         StringBuffer fontName = new StringBuffer(48);
         fontName.append(font.getName());
         int style = font.getStyle();
         if ((style & (SWT.BOLD | SWT.ITALIC)) == (SWT.BOLD | SWT.ITALIC))
            fontName.append("-bold italic");
         else if ((style & SWT.BOLD) != 0)
            fontName.append("-bold");
         else if ((style & SWT.ITALIC) != 0)
            fontName.append("-italic");
         else
            fontName.append("-regular");
         fontName.append('-');
         fontName.append(font.getSize());
         return fontName.toString();
         }
      return null;
   }

   static String fontDataString(Font font)
   {
      if (font != null)
         return font.getFont().getFontData()[0].toString();
      return null;
   }

    /**
     * Compares this <code>Font</code> object to the specified
     * <code>object</code>.
     * @param object the <code>Object</code> to compare.
     * @return <code>true</code> = the objects are the same,
     *         <code>false</code> otherwise.
     */
   public boolean equals(Object object)
   {
      return (object == this) ||
              ((object instanceof Font) && _font.equals(((Font)object)._font));
   }

   /**
    * Dispose the underlying native font object.
    * An org.eclipse.swt.graphics.Font is an OS resource that must be
    * disposed when no longer required;  therefore, you must dispose of
    * com.ibm.lpex.core.Fonts that you created with <code>new Font()</code>,
    * <code>decodeFont()</code>, and <code>decodeFontData()</code>.
    */
   public void dispose()
   {
      if (_shouldDispose)
         _font.dispose();
   }

   /**
    * Font's finalize: dispose the native font object.
    */
   protected void finalize() throws Throwable
   {
      if (_shouldDispose)
         _font.dispose();
      super.finalize();
   }

   /**
    * Return the underlying development-platform font object.
    * This method is needed because we cannot directly extend
    * final swt.graphics.Font...
    */
   org.eclipse.swt.graphics.Font getFont()
   {
      return _font;
   }

   public String toString()
   {
      return nameString(this);
   }
}