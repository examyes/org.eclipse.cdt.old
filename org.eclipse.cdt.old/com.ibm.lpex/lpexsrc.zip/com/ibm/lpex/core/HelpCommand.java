//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// HelpCommand - help support, N/A.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.Properties;


/**
 * Help support for the SWT LPEX widget.
 * Not currently available.
 */
final public class HelpCommand
{
 /**
  * Return the singleton which handles the requested <b>help.___</b> parameter.
  * No <b>help.___</b> parameters are defined.
  */
 static Parameter getParameter(String parameter)
 {
  return null;
 }

 /**
  * Execute the <b>help [<i>LpexCommandName</i>]</b> command.
  * Not available.
  */
 static boolean doCommand(View view, String parameters)
 {
  view.setLpexMessageText("command.notAvailable", "help");
  return true;
 }

 /**
  * Display the requested HTML help panel.
  * Not available.
  */
 public static boolean displayURL(String url, View view)
 {
  return true;
 }

 /**
  * Display the HTML help panel for the specified key (an LPEX command name)
  * in the help command map.
  * Not available.
  */
 public static boolean displayHelp(String key)
 {
  return displayURL("", null);
 }

 /**
  * Load the requested help map.
  * This is a <b>keys - HTML help panels</b> properties file.
  * Not available.
  */
 public static Properties loadHelpMap(String fileName)
 {
  return null;
 }
}