//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// HelpCommand - implements the help command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.Properties;
import java.io.FileInputStream;
import java.io.File;

import com.ibm.help.VisualAgeHelp;


/**
 * This class implements the <b>help</b> command.
 */
final public class HelpCommand
{
 private static boolean    properties_loaded;
 private static Properties helpPages;
 private static String     lastURL = "";

 static final int
  CONFIGURATION = 1,
  HOMEPAGE      = 2,
  LOCATION      = 3;

 private static TableNode[] _parameters =
  {
   new TableNode(LpexConstants.HELP_PARAMETER_CONFIGURATION, CONFIGURATION),
   new TableNode(LpexConstants.HELP_PARAMETER_HOMEPAGE,      HOMEPAGE),
   new TableNode(LpexConstants.HELP_PARAMETER_LOCATION,      LOCATION),
  };


 static Parameter getParameter(String parameter)
  {
   TableNode p = TableNode.binarySearch(_parameters, Parameters.getParameterString(parameter));
   if (p != null)
    {
     switch (p.id())
      {
       case CONFIGURATION:
        {
         return ConfigurationParameter.getParameter();
        }
       case LOCATION:
        {
         return LocationParameter.getParameter();
        }
       case HOMEPAGE:
        {
         return HomePageParameter.getParameter();
        }
       default:
        {
         break;
        }
      }
    }

   return null;
  }

 static boolean doCommand(View view, String parameters)
  {
   boolean success = false;
   loadProperties();

   //*as* for now, just ignore in Eclipse...
   if (LpexUtilities.getPlatform() == LpexConstants.PLATFORM_SWT)
    {
     view.setLpexMessageText("command.notAvailable", "help");
     return true;
    }

   // Try to find a help page for the command given.
   // The entire command string will be used for the key.  If it is not
   // found, then the last parameter is used.  If this isn't found then
   // the last parameter is removed from the command string and the remaining
   // command string is used for the key, starting the above process over again.
   // This continues until a key is found or all parameters of the command
   // string have been checked.
   String helpPage = null;
   int index = -1;
   String commandString = parameters.replace(' ', '.');

   while ((helpPage == null) && (commandString != null))
    {
     helpPage = helpPages.getProperty("help." + commandString);
     if (helpPage == null)
      {
       index = commandString.lastIndexOf('.');
       if (index >= 0)
        {
         helpPage = helpPages.getProperty("help" + commandString.substring(index));
         commandString = commandString.substring(0,index);
        }
       else
        {
         commandString = null;
        }
      }
    }

   if (helpPage == null)
    {
     helpPage = helpPages.getProperty("help");
    }

   success = displayURL(helpPage, view);
   return success;
  }

 private static boolean isSamePDF(String urlName)
  {
   if (urlName != null)
    {
     int lastLen = lastURL.length();
     int pdfKeyLoc = urlName.lastIndexOf('#');

     // ensure it's a pdf file so we can reduce the number of "extra" page loads
     if (pdfKeyLoc >= 3 && urlName.substring(pdfKeyLoc-3,pdfKeyLoc).equals("pdf"))
      {
       if (pdfKeyLoc >= lastLen && urlName.substring(0,pdfKeyLoc).equals(lastURL))
        {
         return true;
        }
       lastURL = urlName.substring(0,pdfKeyLoc);
      }
     else
      {
       lastURL = urlName;
      }
    }
   return false;
  }

 public static boolean displayURL(String urlName, View view)
  {
   //*as* for now, just ignore in Eclipse...
   if (LpexUtilities.getPlatform() == LpexConstants.PLATFORM_SWT)
    {
     return true;
    }

   boolean success = false;
   if (urlName == null)
    {
     urlName = HomePageParameter.getParameter().query(null,null,null);
    }
   String cfgLocation = ConfigurationParameter.getParameter().query(null,null,null);

   // make sure the file exists so that displayHelp won't throw a NullPointerException
   if (cfgLocation != null)
    {
     File checkExistence = new File(cfgLocation);
     if (checkExistence.exists() != true)
      {
       cfgLocation = null;
      }
    }

   if (cfgLocation != null && urlName != null)
    {
     if (isSamePDF(urlName))
      {
       VisualAgeHelp.displayHelp(cfgLocation, VisualAgeHelp.OPENINSTANCE, 0);

       // if things are slow enough that the fake page is seen, it might as well
       // be the homepage, rather than an error message
       String fakeURL = HomePageParameter.getParameter().query(null,null,null);
       if (fakeURL == null)
        {
         fakeURL = "blank.htm";
        }
       VisualAgeHelp.displayHelp(fakeURL);

       // without this pause, sometimes only the fake URL is shown
       try
        {
         java.lang.Thread.sleep(200);
        }
       catch(java.lang.InterruptedException e) {}
      }

     VisualAgeHelp.displayHelp(cfgLocation, VisualAgeHelp.OPENINSTANCE, 0);
     VisualAgeHelp.displayHelp(urlName);
     success = true;
    }

   if (view != null)
    {
     if (success)
      {
       view.setLpexMessageText(LpexConstants.MSG_HELP_OPEN);
      }
     else
      {
       view.setLpexMessageText(LpexConstants.MSG_HELP_ERROR);
      }
    }

   return success;
  }

 /**
  * Display the help page for the specified key.
  */
 public static boolean displayHelp(String key)
  {
   String helpPage = null;
   loadProperties();
   if (helpPages != null)
    {
     helpPage = helpPages.getProperty(key);
    }

   return displayURL(helpPage, null);
  }

 public static Properties loadHelpMap(String fileName)
  {
   Properties helpProperties = new Properties();
   try
    {
     // try using arg as a full path name - ignore classpath
     helpProperties.load(new FileInputStream(LocationParameter.getParameter().query(null,null,null) + fileName));
    }
   catch (Exception e)
    {
     try
      {
       //Load the properties file - if found on the classpath
       helpProperties.load(ClassLoader.getSystemResourceAsStream(fileName));
      }
     catch (Exception e2) {}
     }
   return helpProperties;
  }

 private static void loadProperties()
  {
   if (!properties_loaded)
    {
     helpPages = loadHelpMap(LpexConstants.HELP_COMMAND_MAP);

     // whether the load succeeded or not, there's no point in trying
     // again until LPEX is restarted
     properties_loaded = true;
    }
  }


 final static class ConfigurationParameter extends ParameterWordOnly
 {
  private static ConfigurationParameter _parameter;
  private String configuration;

  static ConfigurationParameter getParameter()
  {
   if (_parameter == null)
    {
     _parameter = new ConfigurationParameter();
    }
   return _parameter;
  }

  private ConfigurationParameter()
  {
   super(PARAMETER_HELP + HELP_PARAMETER_CONFIGURATION);
  }

  String name(String qualifier)
  {
   return name();
  }

  boolean setValue(View view, String qualifier, String value)
  {
   // strip off surrounding quotes
   if (value.startsWith("\"") && value.endsWith("\""))
    {
     value = value.substring(1,value.length()-1);
    }

   configuration = value;
   return true;
  }

  String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   return configuration;
  }
 }


 final static class LocationParameter extends ParameterWordOnly
 {
  private static LocationParameter _parameter;
  private String location;

  static LocationParameter getParameter()
  {
   if (_parameter == null)
    {
     _parameter = new LocationParameter();
    }
   return _parameter;
  }

  private LocationParameter()
  {
   super(PARAMETER_HELP + HELP_PARAMETER_LOCATION);
  }

  String name(String qualifier)
  {
   return name();
  }

  boolean setValue(View view, String qualifier, String value)
  {
   // strip off surrounding quotes
   if (value.startsWith("\"") && value.endsWith("\""))
    {
     value = value.substring(1,value.length()-1);
    }
   location = value;
   return true;
  }

  String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   return location;
  }
 }

 final static class HomePageParameter extends ParameterWordOnly
 {
  private static HomePageParameter _parameter;
  private String homepage;

  static HomePageParameter getParameter()
  {
   if (_parameter == null)
    {
     _parameter = new HomePageParameter();
    }
   return _parameter;
  }

  private HomePageParameter()
  {
   super(PARAMETER_HELP + HELP_PARAMETER_HOMEPAGE);
  }

  String name(String qualifier)
  {
   return name();
  }

  boolean setValue(View view, String qualifier, String value)
  {
   homepage = value;
   return true;
  }

  String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   return homepage;
  }
 }
}