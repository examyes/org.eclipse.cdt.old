//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CommandHandler - handle the editor commands for a document view.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;


/**
 * This class handles the default editor (built-in) commands and
 * the user-defined commands for a document view.
 * There is one instance of this class for every View.
 *
 * <p>In addition to the named built-in commands, LPEX also supports 'short'
 * locate text (e.g., /text) and locate line number (e.g., 100) commands.
 */
final class CommandHandler implements LpexConstants
{
 static  String _status; // set by outsiders...
 private View _view;
 private CommandList _commandList;

 // internal indexes for the built-in LPEX commands
 private static final int
  COMMAND_INVALID        =  0,
  COMMAND_ACTION         =  1,
  COMMAND_ADD            =  2,
  COMMAND_BLOCK          =  3,
  COMMAND_COMPARE        =  4,
  COMMAND_DELETE         =  5,
  COMMAND_DELETE_TEXT    =  6,
  COMMAND_EXPAND_ALL     =  7,
  COMMAND_FIND_TEXT      =  8,
  COMMAND_GET            =  9,
  COMMAND_INPUT          = 10,
  COMMAND_INSERT         = 11,
  COMMAND_INSERT_SHOW    = 12,
  COMMAND_INSERT_TEXT    = 13,
  COMMAND_LOAD           = 14,
  COMMAND_LOCATE         = 15,
  COMMAND_PARSE          = 16,
  COMMAND_PRINT          = 17,
  COMMAND_PROCESS_PREFIX = 18,
  COMMAND_QUERY          = 19,
  COMMAND_REPLACE_TEXT   = 20,
  COMMAND_RESEQUENCE     = 21,
  COMMAND_SAVE           = 22,
  COMMAND_SAVE_AS_HTML   = 23,
  COMMAND_SCREEN_SHOW    = 24,
  COMMAND_SET            = 25,
  COMMAND_SORT           = 26,
  COMMAND_UNDO           = 27,
  COMMAND_UPDATE_PROFILE = 28,
  COMMAND_HELP           = 29,
  COMMAND_NLS_SIMULATOR  = 30;

 /**
  * Table of the LPEX built-in commands.
  * NB Parameters must be in alphabetical order for the binary search.
  */
 private static TableNode[] _commands =
  {
   new TableNode("action", COMMAND_ACTION),
   new TableNode("add", COMMAND_ADD),
   new TableNode("block", COMMAND_BLOCK),
   new TableNode("compare", COMMAND_COMPARE),
   new TableNode("delete", COMMAND_DELETE),
   new TableNode("deleteText", COMMAND_DELETE_TEXT),
   new TableNode("expandAll", COMMAND_EXPAND_ALL),
   new TableNode("findText", COMMAND_FIND_TEXT),
   new TableNode("get", COMMAND_GET),
   new TableNode("help", COMMAND_HELP),
   new TableNode("input", COMMAND_INPUT),
   new TableNode("insert", COMMAND_INSERT),
   new TableNode("insertShow", COMMAND_INSERT_SHOW),
   new TableNode("insertText", COMMAND_INSERT_TEXT),
   new TableNode("load", COMMAND_LOAD),
   new TableNode("locate", COMMAND_LOCATE),
   new TableNode("nlsSimulator", COMMAND_NLS_SIMULATOR),
   new TableNode("parse", COMMAND_PARSE),
   new TableNode("print", COMMAND_PRINT),
   new TableNode("processPrefix", COMMAND_PROCESS_PREFIX),
   new TableNode("query", COMMAND_QUERY),
   new TableNode("replaceText", COMMAND_REPLACE_TEXT),
   new TableNode("resequence", COMMAND_RESEQUENCE),
   new TableNode("save", COMMAND_SAVE),
   new TableNode("saveAsHtml", COMMAND_SAVE_AS_HTML),
   new TableNode("screenShow", COMMAND_SCREEN_SHOW),
   new TableNode("set", COMMAND_SET),
   new TableNode("sort", COMMAND_SORT),
   new TableNode("undo", COMMAND_UNDO),
   new TableNode("updateProfile", COMMAND_UPDATE_PROFILE),
  };


 /**
  * Construct the command handler for a view.
  */
 CommandHandler(View view)
 {
  _view = view;
  _commandList = new CommandList();
 }

 /**
  * Do our share of the <b>updateProfile</b> command.
  * Re-set the list of user-defined commands.
  */
 void updateProfile()
 {
  _commandList.clear();

  String userCommands = UpdateProfileCommand.UserCommandsParameter
                                            .getParameter().currentValue(_view);
  if (userCommands != null)
   {
    LpexStringTokenizer st = new LpexStringTokenizer(userCommands);
    while (st.hasMoreTokens())
     {
      String command = st.nextToken();
      if (st.hasMoreTokens())
       {
        defineCommand(command, st.nextToken());
       }
      else
       {
        _view.setLpexMessageText(MSG_COMMAND_USER_COMMANDS_INVALID, command);
       }
     }
   }
 }

 /**
  * Return a list of the user-defined commands in this view.
  */
 String commands()
 {
  _commandList.sort();

  StringBuffer commands = new StringBuffer(256);
  boolean first = true;
  for (Command command = (Command)_commandList.first();
       command != null;
       command = (Command)command.next())
   {
    if (!first)
     {
      commands.append(' ');
     }
    first = false;
    commands.append(command.commandString());
   }

  return commands.toString();
 }

 /**
  * Get the class name for a user-defined command.
  */
 String commandClass(String commandString)
 {
  Command command = _commandList.find(commandString);
  return (command != null)? command.lpexCommand().getClass().getName() : null;
 }

 boolean doCommand(LpexDocumentLocation documentLocation, String commandString)
 {
  boolean success;
  DocumentPosition.Preserve preserve = _view.documentPosition().preserve();

  Element element = _view.document().elementList().elementAt(documentLocation.element);
  boolean forceAllVisible = _view.forceAllVisible();
  _view.setForceAllVisible(true);
  _view.documentPosition().jump(element, documentLocation.position);

  success = doCommand(commandString);

  LpexDocumentLocation newDocumentLocation = _view.documentPosition().documentLocation();
  documentLocation.element = newDocumentLocation.element;
  documentLocation.position = newDocumentLocation.position;
  _view.setForceAllVisible(forceAllVisible);

  preserve.restore();
  _view.documentPosition().disposePreserve(preserve);

  return success;
 }

 /**
  * This method is called to perform a command.
  *
  * It first searches for the given commandString command name in the list of
  * user-defined commands for this view (either new commands, or overriding
  * built-in editor commands).
  * If none, it tries to execute a built-in editor command with this name.
  */
 boolean doCommand(String commandString)
 {
  // try the user-defined commands
  Command command = _commandList.find(commandString);
  if (command != null)
   {
    return command.lpexCommand().doCommand(_view.lpexView(),
                                           getParameters(commandString));
   }

  // try the built-in commands
  return doDefaultCommand(_view, commandString);
 }

 static boolean doDefaultCommand(View view, LpexDocumentLocation documentLocation,
                                 String commandString)
 {
  boolean success;
  DocumentPosition.Preserve preserve = view.documentPosition().preserve();

  Element element = (view != null)?
                    view.document().elementList().elementAt(documentLocation.element) : null;
  boolean forceAllVisible = false;
  if (view != null)
   {
    forceAllVisible = view.forceAllVisible();
    view.setForceAllVisible(true);
   }
  view.documentPosition().jump(element, documentLocation.position);

  success = doDefaultCommand(view, commandString);

  LpexDocumentLocation newDocumentLocation = view.documentPosition().documentLocation();
  documentLocation.element = newDocumentLocation.element;
  documentLocation.position = newDocumentLocation.position;
  if (view != null)
   {
    view.setForceAllVisible(forceAllVisible);
   }

  preserve.restore();
  view.documentPosition().disposePreserve(preserve);

  return success;
 }

 static boolean doDefaultCommand(String commandString)
 {
  return doDefaultCommand(null, commandString);
 }

 /**
  * This method is called to run a built-in command (either explicitly, or if
  * no action has been defined for a command) in this view.
  */
 static boolean doDefaultCommand(View view, String commandString)
 {
  if (commandString != null && commandString.length() > 0)
   {
    String command    = getCommand(commandString);
    String parameters = getParameters(commandString);

    switch (id(command))
     {
      case COMMAND_ACTION:
       {
        return ActionCommand.doCommand(view, parameters);
       }
      case COMMAND_ADD:
       {
        return AddCommand.doCommand(view, parameters);
       }
      case COMMAND_BLOCK:
       {
        return BlockCommand.doCommand(view, parameters);
       }
      case COMMAND_COMPARE:
       {
        return CompareCommand.doCommand(view, parameters);
       }
      case COMMAND_DELETE:
       {
        return DeleteCommand.doCommand(view, parameters);
       }
      case COMMAND_DELETE_TEXT:
       {
        return DeleteTextCommand.doCommand(view, parameters);
       }
      case COMMAND_EXPAND_ALL:
       {
        return ExpandAllCommand.doCommand(view, parameters);
       }
      case COMMAND_FIND_TEXT:
       {
        return FindTextCommand.doCommand(view, parameters);
       }
      case COMMAND_GET:
       {
        return GetCommand.doCommand(view, parameters);
       }
      case COMMAND_HELP:
       {
        return HelpCommand.doCommand(view, parameters);
       }
      case COMMAND_INPUT:
       {
        return InputCommand.doCommand(view, parameters);
       }
      case COMMAND_INSERT:
       {
        return InsertCommand.doCommand(view, parameters);
       }
      case COMMAND_INSERT_SHOW:
       {
        return InsertShowCommand.doCommand(view, parameters);
       }
      case COMMAND_INSERT_TEXT:
       {
        return InsertTextCommand.doCommand(view, parameters);
       }
      case COMMAND_LOAD:
       {
        return LoadCommand.doCommand(view, parameters);
       }
      case COMMAND_LOCATE:
       {
        return LocateCommand.doCommand(view, parameters);
       }
      case COMMAND_NLS_SIMULATOR:
       {
        return view.nls().nlsSimulator(parameters);
       }
      case COMMAND_PARSE:
       {
        return ParseCommand.doCommand(view, parameters);
       }
      case COMMAND_PRINT:
       {
        return PrintCommand.doCommand(view, parameters);
       }
      case COMMAND_PROCESS_PREFIX:
       {
        return ProcessPrefixCommand.doCommand(view, parameters);
       }
      case COMMAND_QUERY:
       {
        return QueryCommand.doCommand(view, parameters);
       }
      case COMMAND_REPLACE_TEXT:
       {
        return ReplaceTextCommand.doCommand(view, parameters);
       }
      case COMMAND_RESEQUENCE:
       {
        return ResequenceCommand.doCommand(view, parameters);
       }
      case COMMAND_SAVE:
       {
        return SaveCommand.doCommand(view, parameters);
       }
      case COMMAND_SAVE_AS_HTML:
       {
        return SaveAsHtmlCommand.doCommand(view, parameters);
       }
      case COMMAND_SCREEN_SHOW:
       {
        return ScreenShowCommand.doCommand(view, parameters);
       }
      case COMMAND_SET:
       {
        return SetCommand.doCommand(view, parameters);
       }
      case COMMAND_SORT:
       {
        return SortCommand.doCommand(view, parameters);
       }
      case COMMAND_UNDO:
       {
        return UndoCommand.doCommand(view, parameters);
       }
      case COMMAND_UPDATE_PROFILE:
       {
        return UpdateProfileCommand.doCommand(view, parameters);
       }

      default:
       {
        // try a 'locate line number' command
        if (lineNumber(command, parameters))
         {
          return LocateCommand.doCommand(view, "emphasis line " + command);
         }
        // try a 'short' command
        if (shortCommand(command, parameters))
         {
          return doShortCommand(view, command, parameters);
         }
        // try an implicit query command
        if (queryCommand(command, parameters))
         {
          return QueryCommand.doCommand(view, command);
         }
        // try an implicit set command
        if (setCommand(command, parameters))
         {
          return SetCommand.doCommand(view, command + " " + parameters);
         }
        // give up...
        if (view != null)
         {
          view.setLpexMessageText(MSG_COMMAND_INVALID, command);
         }
        return false;
       }
     }
   }

  return false;
 }

 /**
  * Extract the command-name part from commandString.
  *
  * @see #getParameters
  */
 static String getCommand(String commandString)
 {
  String command = commandString;

  // strip leading blanks
  while (command.startsWith(" "))
   {
    command = command.substring(1);
   }

  if (command.length() > 0)
   {
    /*----------------------------------------------------*/
    /*  1.- command=<letter>|<digit>.. up to first blank  */
    /*----------------------------------------------------*/
    if (Character.isLetterOrDigit(command.charAt(0)))
     {
      int i = command.indexOf(' ');
      if (i != -1)
       {
        command = command.substring(0, i);
       }
     }

    /*----------------------------------------------------------------------------*/
    /*  2.- command=?? up to first <letter>|<digit> (unless a find-text 'short')  */
    /*----------------------------------------------------------------------------*/
    else
     {
      // in order to allow e.g., '/' to be followed by <non-letter>|<non-digit>
      // as text to find (without it becoming part of the command string), look
      // first for the 'short' find-text commands & take the rest as parameters
      int len = 1;
      if (command.startsWith("/") || command.startsWith("'"))
       {
       }
      else if (command.startsWith("-/") || command.startsWith("-'"))
       {
        len = 2;
       }
      else
       {
        while (len < command.length() &&
               !Character.isLetterOrDigit(command.charAt(len)))
         {
          len++;
         }
       }
      command = command.substring(0, len);
     }
   }

  return command;
 }

 /**
  * Extract the parameter(s) part from commandString.
  *
  * @see #getCommand
  */
 static String getParameters(String commandString)
 {
  String parameters = commandString;

  // strip leading blanks
  while (parameters.startsWith(" "))
   {
    parameters = parameters.substring(1);
   }

  /*-------------------------------------------------------*/
  /*  1.- no parameters (not much of a command either...)  */
  /*-------------------------------------------------------*/
  if (parameters.length() == 0)
   {
    parameters = "";
   }

  /*------------------------------------------------------------*/
  /*  2.- command=<letter>|<digit>..; parameters=after a blank  */
  /*------------------------------------------------------------*/
  else if (Character.isLetterOrDigit(parameters.charAt(0)))
   {
    int i = parameters.indexOf(' ');
    if (i != -1)
     {
      parameters = parameters.substring(i + 1);
     }
    else
     {
      parameters = "";
     }
   }

  /*------------------------------------------------------------------------------*/
  /*  3.- command=??; parameters=<letter>|<digit>.. or after a find-text 'short'  */
  /*------------------------------------------------------------------------------*/
  else
   {
    int parametersIndex = 1;       // command would take at least 1st character
    if (parameters.startsWith("/") || parameters.startsWith("'"))
     {
     }
    else if (parameters.startsWith("-/") || parameters.startsWith("-'"))
     {
      parametersIndex = 2;
     }
    else
     {
      while (parametersIndex < parameters.length() &&
             !Character.isLetterOrDigit(parameters.charAt(parametersIndex)))
       {
        parametersIndex++;
       }
     }
    parameters = parameters.substring(parametersIndex);
   }

  return parameters;
 }

 private static int id(String commandString)
 {
  commandString = commandString.trim();
  TableNode tableNode = TableNode.binarySearch(_commands, commandString);
  return (tableNode != null)? tableNode.id() : COMMAND_INVALID;
 }

 /**
  * Query whether the commandString is just an integer, with no parameters.
  * If it is, it will be run as a "locate line number" command.
  */
 private static boolean lineNumber(String commandString, String parameters)
 {
  if (parameters.trim().length() == 0)
   {
    try
     {
      int lineNumber = Integer.parseInt(commandString);
      return true;
     }
    catch(NumberFormatException e) {}
   }

  return false;
 }

 /**
  * Check whether the commandString is a 'short' command.
  */
 private static boolean shortCommand(String commandString, String parameters)
 {
  if (commandString.equals("/")  ||
      commandString.equals("-/") ||
      commandString.equals("'")  ||
      commandString.equals("-'"))
   {
    return true;
   }

  if (commandString.equals(":"))
   {
    return lineNumber(parameters, "");
   }

  return false;
 }

 /**
  * Carry out a 'short' command.
  * Find's parameters are not stored for a subsequent e.g., 'find next'.
  */
 private static boolean doShortCommand(View view,
                                       String commandString, String parameters)
 {
  if (commandString.equals(":"))
   {
    return LocateCommand.doCommand(view, "emphasis line " + parameters);
   }

  // ensure a correctly quoted string for the text to find
  String text = LpexStringTokenizer.addQuotes(parameters);

  if (commandString.equals("/"))
   {
    return FindTextCommand.doCommand(view, text);
   }
  if (commandString.equals("-/"))
   {
    return FindTextCommand.doCommand(view, "up " + text);
   }
  if (commandString.equals("'"))
   {
    return FindTextCommand.doCommand(view, "asis " + text);
   }
  if (commandString.equals("-'"))
   {
    return FindTextCommand.doCommand(view, "up asis " + text);
   }

  return false;
 }

 /**
  * Check whether commandString is an implicit query command.
  */
 private static boolean queryCommand(String commandString, String parameters)
 {
  if (parameters.trim().length() == 0)
   {
    if (Parameters.getParameter(commandString) != null)
     {
      return true;
     }
   }

  return false;
 }

 /**
  * Check whether commandString is an implicit set command.
  */
 private static boolean setCommand(String commandString, String parameters)
 {
  Parameter parameter = Parameters.getParameter(commandString);
  if (parameter != null)
   {
    String qualifier = Parameters.getQualifierString(commandString);
    return !parameter.isQueryOnly(qualifier);
   }

  return false;
 }

 /**
  * This method assigns a (new) LpexCommand to the specified command string.
  *
  * @return the old LpexCommand for this commandString, if any
  */
 LpexCommand defineCommand(String commandString, LpexCommand lpexCommand)
 {
  LpexCommand oldLpexCommand = null;

  Command command = _commandList.find(commandString);
  if (command != null)
   {
    oldLpexCommand = command.lpexCommand();
    _commandList.remove(command);
   }

  if (lpexCommand != null)
   {
    command = new Command(commandString, lpexCommand);
    _commandList.addAfter(null, command);
   }

  return oldLpexCommand;
 }

 /**
  * This method assigns a command, implemented by the class named, to the
  * specified command string.
  */
 LpexCommand defineCommand(String commandString, String className)
 {
  LpexCommand lpexCommand = null;

  if (className != null && className.length() > 0)
   {
    Class commandClass = null;
    try
     {
      commandClass = Class.forName(className);
     }
    catch(ClassNotFoundException e) {}

    // if couldn't load, try any of the alternative class loaders
    if (commandClass == null)
     {
      commandClass = View.alternativeLoadClass(className);
     }

    if (commandClass == null)
     {
      _view.setLpexMessageText(MSG_CLASS_NOTFOUND, className);
      return null;
     }

    // the command class must be implement the LpexCommand interface
    if (!LpexCommand.class.isAssignableFrom(commandClass))
     {
      _view.setLpexMessageText(MSG_CLASS_INVALID, className, "LpexCommand");
      return null;
     }

    try
     {
      Constructor commandConstructor = commandClass.getConstructor(null);
      lpexCommand = (LpexCommand)commandConstructor.newInstance(null);
     }
    catch(InvocationTargetException e)
     {
      e.getTargetException().printStackTrace();
      return null;
     }
    catch(Exception e)
     {
      _view.setLpexMessageText(MSG_CLASS_INVALID, className, "LpexCommand");
      return null;
     }
   }

  // now assign this (new) LpexCommand class to the command string
  return defineCommand(commandString, lpexCommand);
 }

 /**
  * This method returns the LpexCommand that is assigned to the specified
  * command string.
  */
 LpexCommand command(String commandString)
 {
  Command command = _commandList.find(commandString);
  return (command != null)? command.lpexCommand() : null;
 }

 /**
  * Called to display a no-parameter error message during the processing
  * of a command.
  *
  * For convenience, this method returns <code>false</code>, the return code
  * normally used when processing incorrectly-formatted commands (missing or
  * incorrect parameters).
  */
 static boolean noParameters(View view, String command)
 {
  if (view != null)
   {
    view.setLpexMessageText(MSG_COMMAND_NOPARAMETERS, command);
   }
  return false;
 }

 /**
  * Called to display an incorrect-parameter error message during the processing
  * of a command.
  *
  * For convenience, this method returns <code>false</code>, the return code
  * normally used when processing incorrectly-formatted commands (missing or
  * incorrect parameters).
  */
 static boolean invalidParameter(View view, String parameter, String command)
 {
  if (view != null)
   {
    view.setLpexMessageText(MSG_COMMAND_INVALIDPARAMETER, parameter, command);
   }
  return false;
 }

 /**
  * Called to display a missing-parameter error message during the processing
  * of a command.
  *
  * For convenience, this method returns <code>false</code>, the return code
  * normally used when processing incorrectly-formatted commands (missing or
  * incorrect parameters).
  */
 static boolean incomplete(View view, String command)
 {
  if (view != null)
   {
    view.setLpexMessageText(MSG_COMMAND_INCOMPLETE, command);
   }
  return false;
 }

 /**
  * Called to display an incorrectly-quoted-parameter error message during the
  * processing of a command.
  *
  * For convenience, this method returns <code>false</code>, the return code
  * normally used when processing incorrectly-formatted commands (missing or
  * incorrect parameters).
  */
 static boolean invalidQuotedParameter(View view, String parameter, String command)
 {
  if (view != null)
   {
    view.setLpexMessageText(MSG_COMMAND_INVALID_QUOTED_PARAMETER, parameter, command);
   }
  return false;
 }

 /**
  * Called to display a missing-parameter error message during the processing
  * of a command.
  *
  * For convenience, this method returns <code>false</code>, the return code
  * normally used when processing incorrectly-formatted commands (missing or
  * incorrect parameters).
  */
 static boolean integerMissing(View view, String parameter, String command)
 {
  if (view != null)
   {
    view.setLpexMessageText(MSG_COMMAND_INTEGERMISSING, parameter, command);
   }
  return false;
 }
}


/**
 * This class manages a list of commands.
 */
final class CommandList extends List
{
 /**
  * Locate the command assigned to the specifed command string.
  */
 Command find(String commandString)
 {
  commandString = CommandHandler.getCommand(commandString);
  for (Node current = first(); current != null; current = current.next())
   {
    if (((Command)current).equals(commandString))
     {
      return (Command)current;
     }
   }
  return null;
 }

 /**
  * Sort the commands in this list by their command string.
  */
 void sort()
 {
  boolean swap;
  do
   {
    swap = false;
    for (Command command = (Command)first();
         command != null;
         command = (Command)command.next())
     {
      Command next = (Command)command.next();
      if (next != null)
       {
        if (command.commandString().compareTo(next.commandString()) > 0)
         {
          remove(command);
          addAfter(next, command);
          command = next;
          swap = true;
         }
       }
     }
   } while (swap);
 }
}


/**
 * This class manages a command.
 */
final class Command extends ListNode
{
 private String      _commandString;
 private LpexCommand _lpexCommand;


 // Construct a command action instance.
 Command(String commandString, LpexCommand lpexCommand)
 {
  _commandString = commandString;
  _lpexCommand   = lpexCommand;
 }

 String commandString()
 {
  return _commandString;
 }

 // Retrieve the LpexCommand for this command.
 LpexCommand lpexCommand()
 {
  return _lpexCommand;
 }

 // Determine if the command is for the command string.
 boolean equals(String commandString)
 {
  return _commandString.equals(commandString);
 }
}