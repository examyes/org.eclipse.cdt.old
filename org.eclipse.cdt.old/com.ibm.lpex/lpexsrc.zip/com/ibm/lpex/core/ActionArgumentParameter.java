//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ActionArgumentParameter - handles the actionArgument parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>actionArgument</b> parameter.
 */
final class ActionArgumentParameter extends Parameter
{
 private static ActionArgumentParameter _parameter;

 static ActionArgumentParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ActionArgumentParameter();
   }
  return _parameter;
 }

 private ActionArgumentParameter()
 {
  super(LpexConstants.PARAMETER_ACTION_ARGUMENT);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  if (view != null)
   {
    view.actionHandler().setArgument(parameters);
   }
  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.actionHandler().argument() : null;
 }
}