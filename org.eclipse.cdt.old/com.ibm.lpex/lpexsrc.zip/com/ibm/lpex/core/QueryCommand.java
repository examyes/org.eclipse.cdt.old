//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// QueryCommand - handles the query command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>query</b> command.
 */
final class QueryCommand
{
 /**
  * Handle
  *   query <parm>
  * issued from the LPEX command line.
  */
 static boolean doCommand(View view, String parameters)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (!st.hasMoreTokens())
   {
    return CommandHandler.noParameters(view, "query");
   }

  String token = st.nextToken();
  Parameter parameter = Parameters.getParameter(token);
  if (parameter == null)
   {
    return CommandHandler.invalidParameter(view, token, "query");
   }

  if (st.hasMoreTokens())
   {
    return CommandHandler.invalidParameter(view, st.nextToken(), "query");
   }

  if (view != null)
   {
    String qualifier = Parameters.getQualifierString(token);
    String queryString = parameter.query(view, view.documentPosition().documentLocation(),
                                         qualifier);
    view.screen().setMessageText(parameters.trim() + " " + queryString);
   }

  return true;
 }

 /**
  * Handle
  *   lpexView.query("<parm>");
  * invoked from the LpexView API.
  */
 static String query(String parameterString, View view, LpexDocumentLocation documentLocation)
 {
  Parameter parameter = Parameters.getParameter(parameterString);
  if (parameter != null)
   {
    String qualifier = Parameters.getQualifierString(parameterString);
    return parameter.query(view, documentLocation, qualifier);
   }

  return null; // no such parameter
 }
}