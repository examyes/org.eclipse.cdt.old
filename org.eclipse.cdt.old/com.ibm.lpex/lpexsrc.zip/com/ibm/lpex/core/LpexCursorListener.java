//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexCursorListener - defines a listener to the document view's cursor.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Interface LpexCursorListener can be implemented to listen to cursor (caret)
 * events in the edit window of a document view.
 *
 * <p>Create a listener object using this class, and then register it with a
 * document view using the view's <code>addLpexCursorListener()</code> method.
 * When an event occurs, the <code>elementChanged()</code> method in the
 * listener object is invoked.
 * Example:
 * <pre>
 *   myLpexView.addLpexCursorListener(new LpexCursorListener() {
 *      // cursor moved to another element
 *      public void elementChanged(LpexView lpexView) {
 *         updateFormatLine(lpexView);
 *         }
 *      }); </pre>
 *
 * @see com.ibm.lpex.core.LpexView#addLpexCursorListener
 * @see com.ibm.lpex.core.LpexView#removeLpexCursorListener
 */
public interface LpexCursorListener
{
 /**
  * This method is invoked when the element on which the cursor is located
  * has changed since the last notification or since the listener was added.
  * It is invoked just before the screen is displayed.
  *
  * The LPEX screen is rebuilt and displayed after every user action.  It is
  * also rebuilt and displayed when the <b>screenShow</b> editor command
  * is issued.
  */
 public void elementChanged(LpexView lpexView);
}