//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LineParameter - handles the line parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>line</b> parameter.
 * This parameter is query only.
 * It returns the line number of the current element in the entire document.
 */
final class LineParameter extends ParameterIntegerQuery
{
 private static LineParameter _parameter;

 static LineParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new LineParameter();
   }
  return _parameter;
 }

 private LineParameter()
 {
  super(PARAMETER_LINE);
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return view != null && documentLocation != null &&
         view.document().elementList().elementAt(documentLocation.element) != null;
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null && documentLocation != null)
   {
    Document document = view.document();
    Element element = document.elementList().elementAt(documentLocation.element);
    if (element != null)
     {
      return document.elementList().nonShowOrdinalOf(element) +
             // bump up by number of lines before the loaded document section
             document.linesBeforeStart();
     }
   }

  return 0;
 }
}