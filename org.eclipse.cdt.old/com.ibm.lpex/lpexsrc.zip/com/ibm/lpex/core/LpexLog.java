//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexLog - log critical error messages.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Date;

import com.ibm.lpex.util.LpexSysutil;


/**
 * Facility to log critical LPEX errors.
 */
public final class LpexLog
{
   private static String _name;

   static String name()
   {
      if (_name != null)
         return _name;

      return LpexSysutil.getUserHomeDirectory() +  // user home directory
             File.separator + "Editor.log";        // log file name
   }

   /**
    * Set the name of the editor log file.
    * The default editor log file is "Editor.log", located in the editor user
    * home directory.
    *
    * @param name full-path name of the editor log file
    */
   public static void setName(String name)
   {
      if (name != null) {
         name = name.trim();
         if (name.length() == 0)
            name = null;
         }

      _name = name;
   }

   /**
    * Log a trace/error message.
    */
   public static void log(String problem)
   {
      try {
         // create the log file in append mode
         PrintWriter log = new PrintWriter(new FileOutputStream(name(), true));

         // log the message
         if (problem != null)
            log.println(new Date() + " " + problem);
         log.flush();
         log.close();
         }
      catch (Exception x) {  // really bad news
         System.err.println(new Date() +
                            " Unrecoverable error while writing to the editor log:");
         System.err.println(problem);
         }
   }

   /**
    * Log a Throwable (an Exception or an Error).
    */
   public static void log(Throwable e)
   {
      //if (LpexUtilities.getPlatform() == LpexConstants.PLATFORM_SWT) {
      // if inside the LPEX plugin, use plugin's ILog!? *as*
      // }

      try {
         // create the log file in append mode
         PrintWriter log = new PrintWriter(new FileOutputStream(name(), true));

         // log the exception
         if (e.getMessage() != null)
            log.println(new Date() + " " + e.getMessage());
         e.printStackTrace(log);
         log.flush();
         log.close();
         }
      catch (Exception x) {  // really bad news
         System.err.println(new Date() +
                            " Unrecoverable error while writing to the editor log:");
         e.printStackTrace();
         }
   }
}