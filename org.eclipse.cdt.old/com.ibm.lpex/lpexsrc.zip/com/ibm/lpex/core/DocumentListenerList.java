//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DocumentListenerList - handles a document's list of LpexDocumentListeners.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages the LpexDocumentListeners for a document.
 * There is up to one instance of this class created for each Document.
 */
final class DocumentListenerList extends List
{
 /**
  * Constructor.
  */
 DocumentListenerList(Document document) {}

 /**
  * Add an LpexDocumentListener.  A listener is only registered once,
  * additional calls are without effect.
  */
 void addListener(LpexDocumentListener listener)
 {
  if (find(listener) == null)
   {
    addAfter(null, new ListenerNode(listener));
   }
 }

 /**
  * Remove an LpexDocumentListener, if registered.
  */
 void removeListener(LpexDocumentListener listener)
 {
  if (listener != null)
   {
    ListenerNode node = find(listener);
    if (node != null)
     {
      remove(node);
     }
   }
 }

 /**
  * Send a <i>documentChanged</i> notification to all registered
  * LpexDocumentListeners.
  */
 void documentChanged(LpexView lpexView, int type, int line, int position, int len)
 {
  //beginScanning();
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    //if (!node.removePending())
    node.listener().documentChanged(lpexView, type, line, position, len);
   }
  //endScanning();
 }

 /**
  * Find a registered LpexDocumentListener for this Document.
  */
 ListenerNode find(LpexDocumentListener listener)
 {
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    if (node.listener() == listener)
     {
      return node;
     }
   }
  return null;
 }


 private static class ListenerNode extends ListNode
 {
  private LpexDocumentListener _listener;

  ListenerNode(LpexDocumentListener listener)
  {
   _listener = listener;
  }

  LpexDocumentListener listener()
  {
   return _listener;
  }
 }
}