//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Parameter - base class for all editor parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Base, abstract class for all the editor parameters.
 *
 * <pre>
 * Parameter
 *    DefaultParameter                 "default."
 *
 *    ParameterDefault
 *       ParameterCharacterDefault
 *       ParameterFontDefault
 *       ParameterIntegerDefault
 *       ParameterOnOffDefault
 *       ParameterStringDefault
 *       ParameterWordDefault
 *       ParameterWordsDefault
 *
 *       ParameterQualifiedWordDefault
 *
 *    ParameterQuery
 *       InstallParameter              "install."
 *       CurrentParameter              "current."
 *
 *       ParameterCharacterQuery
 *          ParameterCharacterOnly
 *       ParameterIntegerQuery
 *          ParameterIntegerOnly
 *       ParameterOnOffQuery
 *          ParameterOnOffOnly
 *
 *       ParameterQualifierList
 *
 *    ParameterWordOnly </pre>
 */
abstract class Parameter implements LpexConstants
{
 static final int
  OFF     = 0,
  ON      = 1,
  DEFAULT = 2,
  INSTALL = 3;

 private String _name;


 Parameter(String name)
 {
  _name = name;
 }

 String name()
 {
  return _name;
 }

 String name(String qualifier)
 {
  return (qualifier != null)? _name + qualifier : _name;
 }

 /**
  * Returns <code>true</code> if this parameter is query only (cannot be set).
  */
 boolean isQueryOnly(String qualifier)
 {
  return false;
 }

 /**
  * Called by InstallParameter to check whether this parameter supports a
  *   <b>query install.xxx</b>
  * setting.
  */
 boolean hasInstallSetting()
 {
  return false;
 }

 /**
  * Called by DefaultParameter to check whether this parameter supports a
  *   <b>set/query default.xxx</b>
  * setting.
  */
 boolean hasDefaultSetting()
 {
  return false;
 }

 /**
  * Called by CurrentParameter to check whether this parameter supports a
  *   <b>query current.xxx</b>
  * setting.
  */
 boolean hasCurrentSetting()
 {
  return false;
 }

 abstract boolean set(View view, String qualifier, String parameters);

 /**
  * Called by DefaultParameter to
  *  <b>set default.xxx</b>.
  */
 boolean setDefault(View view, String qualifier, String parameters)
 {
  return false;
 }

 abstract String query(View view, LpexDocumentLocation documentLocation, String qualifier);

 /**
  * Called by InstallParameter to
  *   <b>query install.xxx</b>.
  */
 String queryInstall(String qualifier)
 {
  return null;
 }

 /**
  * Called by DefaultParameter to
  *   <b>query default.xxx</b>.
  */
 String queryDefault(String qualifier)
 {
  return null;
 }

 /**
  * Called by CurrentParameter to
  *   <b>query current.xxx</b>.
  */
 String queryCurrent(View view, String qualifier)
 {
  return null;
 }
}