//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexWindow - manages an LPEX window.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.EventListener;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Layout;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.widgets.TypedListener;
import org.eclipse.swt.widgets.Widget;


/**
 * The class LpexWindow can be used to manage an LPEX window.
 * LpexWindow is an SWT Composite consisting of the text window (the edit area),
 * a status line, a format line (horizontal ruler), a message line, a command
 * line, and several separator lines in between the various components.
 *
 * @see com.ibm.lpex.core.LpexView
 */
public class LpexWindow extends Composite
{
 // the document view currently associated with this window
 LpexView _lpexView;

 // LpexWindow components
 private StatusLine  _statusLine;
 private Separator   _separator0;
 private FormatLine  _formatLine;
 private Separator   _separator1;
 private TextWindow  _textWindow;
 private Separator   _separator2;
 private MessageLine _messageLine;
 private CommandLine _commandLine;

 Widget _lastFocusWidget; // TextWindow / a CommandLine entry field or button


 // internal event type for LpexKeyListeners registration and notifying
 static final int
  VERIFY_KEY_PRESSED_EVENT = 4000;

 // number of LpexKeyListeners currently registered (for optimization purposes)
 int _keyListeners;


 /**
  * Construct a window for displaying an LPEX view.
  */
 public LpexWindow(Composite parent)
  {
   this(parent, 0);
  }

 /**
  * Construct a window for displaying an LPEX view.
  * SWT styles (such as SWT.BORDER) may be passed in, to be used in building
  * this Composite.
  */
 public LpexWindow(Composite parent, int swtStyles)
  {
   super(parent, swtStyles | SWT.NO_BACKGROUND);

   _textWindow = new TextWindow(this);

   _statusLine = new StatusLine(this);
   _statusLine.setVisible(false);

   _separator0 = new Separator(this);

   _formatLine = new FormatLine(this);
   _formatLine.setVisible(false);

   _separator1 = new Separator(this);

   _textWindow.getVerticalBar().setVisible(false);
   _textWindow.getHorizontalBar().setVisible(false);

   _separator2 = new Separator(this);

   _messageLine = new MessageLine(this);
   _messageLine.setVisible(false);

   _commandLine = new CommandLine(this);
   _commandLine.setVisible(false);

   setLayout(createLayoutManager());
  }

 /**
  * Retrieve the status line.
  */
 public Composite statusLine()
  {
   return _statusLine;
  }

 /**
  * Retrieve the 1st separator line.
  */
 public Composite separator0()
  {
   return _separator0;
  }

 /**
  * Retrieve the format line.
  */
 public Composite formatLine()
  {
   return _formatLine;
  }

 /**
  * Retrieve the 2nd separator line.
  */
 public Composite separator1()
  {
   return _separator1;
  }

 /**
  * Retrieve the client portion of the LPEX window (the edit area).
  */
 public Composite textWindow()
  {
   return _textWindow;
  }

 /**
  * Retrieve the horizontal scrollbar.
  * The horizontal scrollbar is a widget of the text window, and does not
  * participate as a separate control in the LpexWindow layout.
  */
 public ScrollBar horizontalScrollBar()
  {
   return _textWindow.getHorizontalBar();
  }

 /**
  * Retrieve the vertical scrollbar.
  * The vertical scrollbar is a widget of the text window, and does not
  * participate as a separate control in the LpexWindow layout.
  */
 public ScrollBar verticalScrollBar()
  {
   return _textWindow.getVerticalBar();
  }

 /**
  * Retrieve the 3rd separator line.
  */
 public Composite separator2()
  {
   return _separator2;
  }

 /**
  * Retrieve the message line.
  */
 public Composite messageLine()
  {
   return _messageLine;
  }

 /**
  * Retrieve the command line.
  */
 public Composite commandLine()
  {
   return _commandLine;
  }

 /**
  * Development-platform independent (awt/swt) convenience method used inside
  * com.ibm.lpex.core for view().window().commandLine().requestFocus() - which
  * method in awt overrides JComponent's requestFocus(), the equivalent of
  * swt Composite's setFocus().
  */
 void commandLineRequestFocus()
  {
   _commandLine.requestFocus();
  }

 /**
  * Development-platform independent (awt/swt) convenience method used inside
  * com.ibm.lpex.core for awt view().window().textWindow().requestFocus(), and
  * swt view().window().textWindow().setFocus().
  */
 void textWindowRequestFocus()
  {
   _textWindow.setFocus();
  }

 /**
  * Create the layout manager for the LPEX window, an LpexWindowLayout.
  */
 protected Layout createLayoutManager()
  {
   return new LpexWindowLayout();
  }

 /**
  * Retrieve the document view currently associated with this window.
  */
 public LpexView view()
  {
   return _lpexView;
  }

 /**
  * Set the focus on this LpexWindow.
  * Override Composite.setFocus().
  */
 public boolean setFocus()
  {
   // As of Eclipse driver 0.043:  the desktop part gets a setFocus()
   // request whenever any of its components gets input focus - see
   // com.ibm.lpex.alef.LpexAbstractTextEditor#setFocus() calling this
   // LpexWindow.setFocus();  if we process this setFocus() when the
   // user had clicked on the command line (and, consequently, it has
   // the keyboard input focus), we end up with some sort of focus in
   // both the TextWindow *and* the command line...
   if (_commandLine.inputFocusWidget() != null)
    {
     return true;
    }

   // As of Eclipse driver 0.128:  the desktop part now gets the setFocus()
   // request *before* e.g., the command-line widget gets its setFocus()...
   // E.g., if we are in live-find mode in the LPEX window (Ctrl+F), then go to
   // the Eclipse Navigator window, and then mouse click on the "Next" pushbutton
   // in the live find, _commandLine.inputFocusWidget() is still null, so in here
   // we carry on with the super.setFocus() ==> the TextWindow() gets focus and
   // 1.- terminates the live find, and only then does the "Next" pushbutton
   // (invisible by now as it is...) receive its setFocus(), and 2.- the cursor
   // is not in the TextWindow any longer.  I.e., twice as bad...
   //
   // THEREFORE, we now keep track of which widget (if any) had focus last in
   // the LPEX window (a command-line widget or the TextWindow), and give *it*
   // focus in here.  Minor issue:  in the above scenario (live find), if the
   // user clicks on a *new* button / entry field, the old one will first get
   // a short-lived focus...
   if (_lastFocusWidget != null && !_lastFocusWidget.isDisposed())
       // && _lastFocusWidget instanceof Control)
    {
     return ((Control)_lastFocusWidget).setFocus();
    }

   // Before Eclipse driver 0.043:  method Composite.setFocus() was overridden
   // here so that we could ignore setFocus() requests sent to this LpexWindow
   // as a result of, and while processing, FocusListener focusGained()
   // notifications issued by this LpexWindow itself (resulting from any of
   // our child components gaining focus).
   // if (_ignoreSetFocus) return false;

   return super.setFocus();
  }

// // Before Eclipse driver 0.043:  this method is invoked by any component
// // inside this LpexWindow that gains focus.  It sends focusGained()
// // notifications to all the FocusListeners registered with this LpexWindow.
// // The LpexWindow Composite (the mother of all other Composites in the LPEX
// // widget - edit area, command line, live-find entry fields, etc.) does
// // not register a focus event (and neither mouse, nor other events) when
// // one of its component Composites gets the focus...  Therefore, we have to
// // register focus listeners on all component Composites -- or at least on those
// // for which we must have the viewer contributions activated --, and generate
// // an LpexWindow Focus event when focus is gained by any of them.
// // During the processing of this call, LpexWindow does not process
// // setFocus() requests it receives.  This allows an Eclipse Platform visual
// // part pane to give an LpexTextViewer-based workbench viewer the focus when
// // activate()-ed by this notification.  E.g., this scenario is thus prevented:
// // the LPEX command line gets focus via mouse click -> registered FocusListener
// // focusGained() notification -> Eclipse workbench -> activate()s this viewer
// // and its contributions + calls setFocus() on LpexWindow -> gives the focus
// // to our TextWindow (away from the command line!).
// // @see #setFocus
// private boolean _ignoreSetFocus;
// void notifyFocusGained() {
//  _ignoreSetFocus = true;
//  // * LpexWindow.addFocusListener(FocusListener listener):
//  //   swt.widgets.Control.addFocusListener(listener) ->
//  //   addListener(SWT.FocusIn, new TypedListener(listener)) and
//  //   addListener(SWT.FocusOut, new TypedListener(listener))
//  // * here:
//  //   swt.widgets.Widget.notifyListeners(type, event) ->
//  //   its swt.widgets.EventTable.sendEvent() ->
//  //   swt.widgets.TypedListener.handleEvent() ->
//  //   SWT.FocusIn: FocusListener.focusGained(new FocusEvent(event))
//  notifyListeners(SWT.FocusIn, new Event());
//  _ignoreSetFocus = false;
//  }
// // This method is invoked by any component inside this LpexWindow that loses
// // focus.  It sends focusLost() notifications to any FocusListeners registered
// // with this LpexWindow.
// void notifyFocusLost() {
//  notifyListeners(SWT.FocusOut, new Event());
//  }

 /**
  * Add an LPEX key listener.  A verifyKeyPressed(event) notification is sent by
  * LPEX when a key is pressed.  LPEX ignores the key press if the listener
  * consumes the key by setting the <code>doit</code> field of the event to
  * <code>false</code>.
  *
  * @param listener the listener to add
  *
  * @see LpexKeyListener
  * @see #removeLpexKeyListener
  */
 public void addLpexKeyListener(LpexKeyListener listener)
 {
  if (listener != null)
   {
    // add to the widget's EventTable a VERIFY_KEY_PRESSED_EVENT-LpexTypedListener
    // for user's EventListener listener
    LpexTypedListener typedListener = new LpexTypedListener(listener);
    addListener(VERIFY_KEY_PRESSED_EVENT, typedListener);
    _keyListeners++;
   }
 }

 /**
  * Remove the specified LPEX key listener.
  *
  * @param listener the listener to remove
  *
  * @see #addLpexKeyListener
  */
 public void removeLpexKeyListener(LpexKeyListener listener)
  {
   if (listener != null)
    {
     // remove the LpexTypedListener we added for user's EventListener listener
     removeListener(VERIFY_KEY_PRESSED_EVENT, listener);
     if (_keyListeners > 0)
      {
       _keyListeners--;
      }
    }
  }

 /**
  * The LpexView is dissociated from this LpexWindow (which is possibly being
  * disposed).
  * Set all its children invisible, repaint.
  */
 void dissociate()
  {
   CommandLine commandLine = (CommandLine)commandLine();
   commandLine.setInput(null, null, null, null);
   if (!commandLine.isDisposed())
      commandLine.setVisible(false);
   if (!statusLine().isDisposed())
      statusLine().setVisible(false);
   if (!formatLine().isDisposed())
      formatLine().setVisible(false);
   if (!messageLine().isDisposed())
      messageLine().setVisible(false);
   if (!textWindow().isDisposed()) {
      horizontalScrollBar().setVisible(false);
      verticalScrollBar().setVisible(false);
      textWindow().redraw();
      }
  }
}

/**
 * Extend SWT's TypedListener to handle LpexKeyListener events.
 */
class LpexTypedListener extends TypedListener
{
 LpexTypedListener(EventListener listener)
  {
   super(listener);
  }

 public void handleEvent(Event e)
  {
   if (e.type == LpexWindow.VERIFY_KEY_PRESSED_EVENT)
    {
     ((LpexKeyListener)eventListener).verifyKeyPressed(e);
    }
   else
    {
     super.handleEvent(e);
    }
  }
}