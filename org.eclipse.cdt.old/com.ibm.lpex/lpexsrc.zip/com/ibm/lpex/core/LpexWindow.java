//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexWindow - manages an LPEX window.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Layout;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.widgets.Widget;


/**
 * The class LpexWindow can be used to manage an LPEX window.
 * LpexWindow is an SWT Composite consisting of the text window (the edit area),
 * a status line, a format line (horizontal ruler), a message line, a command
 * line, and several separator lines in between the various components.
 *
 * @see com.ibm.lpex.core.LpexView
 */
public class LpexWindow extends Composite
{
 // the document view currently associated with this window
 LpexView _lpexView;

 // LpexWindow components
 private StatusLine  _statusLine;
 private Separator   _separator0;
 private FormatLine  _formatLine;
 private Separator   _separator1;
 private TextWindow  _textWindow;
 private Separator   _separator2;
 private MessageLine _messageLine;
 private CommandLine _commandLine;

 Widget _lastFocusWidget; // TextWindow / a CommandLine entry field or button


 /**
  * Construct a window for displaying an LPEX view.
  */
 public LpexWindow(Composite parent)
  {
   this(parent, 0);
  }

 /**
  * Construct a window for displaying an LPEX view.
  * SWT styles (such as SWT.BORDER) may be passed in, to be used in building
  * this Composite.
  */
 public LpexWindow(Composite parent, int swtStyles)
  {
   super(parent, swtStyles | SWT.NO_BACKGROUND);

   _textWindow = new TextWindow(this);

   _statusLine = new StatusLine(this);
   _statusLine.setVisible(false);

   _separator0 = new Separator(this);

   _formatLine = new FormatLine(this);
   _formatLine.setVisible(false);

   _separator1 = new Separator(this);

   _textWindow.getVerticalBar().setVisible(false);
   _textWindow.getHorizontalBar().setVisible(false);

   _separator2 = new Separator(this);

   _messageLine = new MessageLine(this);
   _messageLine.setVisible(false);

   _commandLine = new CommandLine(this);
   _commandLine.setVisible(false);

   setLayout(createLayoutManager());
  }

 /**
  * Retrieve the status line.
  */
 public Composite statusLine()
  {
   return _statusLine;
  }

 /**
  * Retrieve the 1st separator line.
  */
 public Composite separator0()
  {
   return _separator0;
  }

 /**
  * Retrieve the format line.
  */
 public Composite formatLine()
  {
   return _formatLine;
  }

 /**
  * Retrieve the 2nd separator line.
  */
 public Composite separator1()
  {
   return _separator1;
  }

 /**
  * Retrieve the client portion of the LPEX window (the edit area).
  */
 public Composite textWindow()
  {
   return _textWindow;
  }

 /**
  * Retrieve the horizontal scrollbar.
  * The horizontal scrollbar is a widget of the text window, and does not
  * participate as a separate control in the LpexWindow layout.
  */
 public ScrollBar horizontalScrollBar()
  {
   return _textWindow.getHorizontalBar();
  }

 /**
  * Retrieve the vertical scrollbar.
  * The vertical scrollbar is a widget of the text window, and does not
  * participate as a separate control in the LpexWindow layout.
  */
 public ScrollBar verticalScrollBar()
  {
   return _textWindow.getVerticalBar();
  }

 /**
  * Retrieve the 3rd separator line.
  */
 public Composite separator2()
  {
   return _separator2;
  }

 /**
  * Retrieve the message line.
  */
 public Composite messageLine()
  {
   return _messageLine;
  }

 /**
  * Retrieve the command line.
  */
 public Composite commandLine()
  {
   return _commandLine;
  }

 /**
  * Development-platform independent (awt/swt) convenience method used inside
  * com.ibm.lpex.core for view().window().commandLine().requestFocus() - which
  * method in awt overrides JComponent's requestFocus(), the equivalent of
  * swt Composite's setFocus().
  */
 void commandLineRequestFocus()
  {
   _commandLine.requestFocus();
  }

 /**
  * Development-platform independent (awt/swt) convenience method used inside
  * com.ibm.lpex.core for awt view().window().textWindow().requestFocus(), and
  * swt view().window().textWindow().setFocus().
  */
 void textWindowRequestFocus()
  {
   _textWindow.setFocus();
  }

 /**
  * Create the layout manager for the LPEX window, an LpexWindowLayout.
  */
 protected Layout createLayoutManager()
  {
   return new LpexWindowLayout();
  }

 /**
  * Retrieve the document view currently associated with this window.
  */
 public LpexView view()
  {
   return _lpexView;
  }

 /**
  * Set the focus on this LpexWindow.
  * Override Composite.setFocus().
  */
 public boolean setFocus()
  {
   // As of Eclipse driver 0.043:  the desktop part gets a setFocus()
   // request whenever any of its components gets input focus - see
   // com.ibm.lpex.alef.LpexAbstractTextEditor#setFocus() calling this
   // LpexWindow.setFocus();  if we process this setFocus() when the
   // user had clicked on the command line (and, consequently, it has
   // the keyboard input focus), we end up with some sort of focus in
   // both the TextWindow *and* the command line...
   if (_commandLine.inputFocusWidget() != null)
    {
     return true;
    }

   // As of Eclipse driver 0.128:  the desktop part now gets the setFocus()
   // request *before* e.g., the command-line widget gets its setFocus()...
   // E.g., if we are in live-find mode in the LPEX window (Ctrl+F), then go to
   // the Eclipse Navigator window, and then mouse click on the "Next" pushbutton
   // in the live find, _commandLine.inputFocusWidget() is still null, so in here
   // we carry on with the super.setFocus() ==> the TextWindow() gets focus and
   // 1.- terminates the live find, and only then does the "Next" pushbutton
   // (invisible by now as it is...) receive its setFocus(), and 2.- the cursor
   // is not in the TextWindow any longer.  I.e., twice as bad...
   //
   // THEREFORE, we now keep track of which widget (if any) had focus last in
   // the LPEX window (a command-line widget or the TextWindow), and give *it*
   // focus in here.  Minor issue:  in the above scenario (live find), if the
   // user clicks on a *new* button / entry field, the old one will first get
   // a short-lived focus...
   if (_lastFocusWidget != null && !_lastFocusWidget.isDisposed())
       // && _lastFocusWidget instanceof Control)
    {
     return ((Control)_lastFocusWidget).setFocus();
    }

   return super.setFocus();
  }

 /**
  * The LpexView is dissociated from this LpexWindow (which is possibly being
  * disposed).
  * Set all its children invisible, repaint.
  */
 void dissociate()
  {
   CommandLine commandLine = (CommandLine)commandLine();
   commandLine.setInput(null, null, null, null);
   if (!commandLine.isDisposed())
      commandLine.setVisible(false);
   if (!statusLine().isDisposed())
      statusLine().setVisible(false);
   if (!formatLine().isDisposed())
      formatLine().setVisible(false);
   if (!messageLine().isDisposed())
      messageLine().setVisible(false);
   if (!textWindow().isDisposed()) {
      horizontalScrollBar().setVisible(false);
      verticalScrollBar().setVisible(false);
      textWindow().redraw();
      }
  }
}