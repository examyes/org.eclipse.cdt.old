//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexMarkListener - listener to mark events.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Interface LpexMarkListener can be implemented to listen to mark events.
 * Marks are defined with the <b>set mark</b> editor command.
 *
 * @see LpexView#addLpexMarkListener
 * @see LpexView#removeLpexMarkListener(int,LpexMarkListener)
 * @see LpexView#removeLpexMarkListener(LpexMarkListener)
 */
public interface LpexMarkListener
{
 /**
  * This method is invoked when the text associated with a mark
  * has been changed.
  */
 public void markChanged(LpexView lpexView, int markId);

 /**
  * This method is invoked when all of the text associated with a mark
  * has been deleted.
  */
 public void markDeleted(LpexView lpexView, int markId);
}