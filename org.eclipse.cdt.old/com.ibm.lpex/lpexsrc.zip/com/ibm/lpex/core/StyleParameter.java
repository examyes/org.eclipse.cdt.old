//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// StyleParameter - handles the style parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>style</b> parameter.
 */
final class StyleParameter extends Parameter
{
 private static StyleParameter _parameter;

 static StyleParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new StyleParameter();
   }
  return _parameter;
 }

 private StyleParameter()
 {
  super(LpexConstants.PARAMETER_STYLE);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  if (view != null)
   {
    Element element = view.documentPosition().element();
    if (element != null)
     {
      element.elementView(view).setStyle(parameters);
     }
   }

  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    if (element != null)
     {
      return element.elementView(view).style();
     }
   }

  return null;
 }
}