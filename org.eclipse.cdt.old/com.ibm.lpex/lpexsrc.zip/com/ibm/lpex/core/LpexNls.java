//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexNls - national language support.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.Locale;
import java.util.StringTokenizer;


/**
 * This class provides the LPEX national language support (NLS) functions,
 * specifically DBCS/MBCS-related functions.  Some bidirectional functions
 * will also be added gradually, for LPEX's internal use.
 * There is one instance of this class for each document view.
 *
 * <p>The NLS functions attempt to ease the handling by users of files
 * originating on and/or targeted for a host system, in a manner similar to
 * their handling in that particular environment (e.g., S/390 files being edited
 * with a S/390 editor):  emulation of SO/SI control characters, awareness of
 * the text's actual positions and columns (byte-determined), etc.
 *
 * <p>The current implementation, while attempting to be generic, focuses on
 * Windows as the workstation and S/390 (zSeries) as the host system.  For these,
 * each byte in the character encoding takes up one display column on the screen
 * (1-byte SBCS character = 1 display column, 2-byte DBCS character = 2-column
 * display width, SO and SI controls = 1 display column each).
 *
 * <p>For EUC character encodings, LpexNls may not provide adequate emulation
 * of their source edit environments.  The byte-length of characters differs
 * from their display-column width, so you may have to use native code (JNI),
 * e.g., the *mb* C library functions, for display-width calculations (as only
 * byte-length information is currently obtainable in Java);  these calculations
 * affect tab expansions.
 *
 * <p>Terminology: <pre>
 *   Unicode  - LPEX, like any Java program, uses Unicode characters internally
 *   encoding - a Java-defined character encoding, e.g., "Cp1252" (Windows
 *              Latin-1)
 *
 *   native   - the default character encoding of the platform (host operating
 *              system) that LPEX runs on, according to the default locale.
 *              Usually a workstation: Windows, Linux, OS/2, etc. - some ASCII
 *              character encoding;  if a mainframe/midi: S/390 / AS/400 - an
 *              EBCDIC character encoding.  This encoding is obtained from the
 *              "file.encoding" Java system property:
 *                 String nativeEncoding = System.getProperty("file.encoding");
 *
 *              Here are a number of <b>assumptions</b> behind the current LPEX
 *              implementation:
 *              Files are usually stored in an encoding that is same as the
 *              default encoding of the host operating system.  For example, on
 *              the Japanese Linux, files are typically stored in EUC-JP.
 *              When files whose encoding is same as the host operating system
 *              (native encoding) are read/written, classes java.io.Reader and
 *              java.io.Writer are used.  These classes are smart enough to
 *              perform code conversion into Unicode when reading the file into
 *              the Java context (loading a document into LPEX), and from Unicode
 *              when writing the files (saving the document back to the file).
 *
 *              Therefore, this is <b>not</b> currently supported:
 *              In a heterogeneous platform environment, one may have to perform
 *              character code conversion of the files.  If the encoding of the
 *              host operating system is different from the encoding of the file
 *              we want to load into LPEX, one must explicitly specify the
 *              encoding of the file and LPEX must then perform the character
 *              code conversion on loading the file in, and similarly whan saving
 *              the document.
 *              Consequently, Internet character encodings are not supported either.
 *              (Additionally, for Internet encodings, the surrounding escape
 *              sequences are not currently handled in the code anyway - their
 *              processing should be in a manner quite similar to the handling of
 *              SO/SI controls in EBCDIC DBCS).
 *
 *   source   - source platform default character encoding:  the file being
 *              edited may originate from and/or be targeted for a remote
 *              system (i.e., different from the platform that LPEX runs on).
 *              Setting the source encoding information in the editor, allows
 *              LPEX to emulate features of the file's original editing
 *              environment (e.g., display SO/SI controls, etc.).
 *
 *   DBCS     - double-byte character set
 *   MBCS     - multi-byte character set
 *   SO       - Shift-out control character
 *   SI       - Shift-in control character
 *              Only EBCDIC DBCS encodings use SO/SI control characters.
 *              LPEX can display emulation SO/SI characters in order to
 *              present the user an image of the file similar to the one seen
 *              in its source natural habitat (e.g., a S/390 file being edited
 *              with a S/390 editor). </pre>
 *
 * Here is a scenario for editing a host file with LPEX: <pre>
 *   ----------------------------                   ----------------------------
 *   | Windows 2000 workstation |                   | OS/390 mainframe         |
 *   | IBM Java 2 SDK 1.3.0     |                   |                          |
 *   |                          |                   |                          |
 *   | Native encoding: MS 932  |                   | Source encoding: CP 939  |
 *   |  (PC DBCS)               |                   |  (EBCDIC DBCS + SO/SIs)  |
 *   |                          |                   |                          |
 *   |                          |                   | 1.host file XXX          |
 *   |                          |  2.file-transfer  |                          |
 *   |                          |    utility:       |                          |
 *   |                          |    S/390 -> PC    |                          |
 *   |                          |<===================                          |
 *   | 3.local file xxx         |                   |                          |
 *   |                          |                   |                          |
 *   | 4.LPEX loads file        |                   |                          |
 *   |   from workstation:      |                   |                          |
 *   |   "MS932" -> Unicode     |                   |                          |
 *   |                          |                   |                          |
 *   |  [5.set SourceEncoding   |                   |                          |
 *   |     "Cp939" for          |                   |                          |
 *   |     emulation purposes]  |                   |                          |
 *   |                          |                   |                          |
 *   |   6.LPEX handles         |                   |                          |
 *   |     the editing of       |                   |                          |
 *   |     document xxx         |                   |                          |
 *   |     (all in Unicode)     |                   |                          |
 *   |                          |                   |                          |
 *   | 7.LPEX saves file        |                   |                          |
 *   |   to workstation:        |                   |                          |
 *   |   Unicode -> "MS932"     |                   |                          |
 *   |                          |                   |                          |
 *   | 8.local file xxx'        |                   |                          |
 *   |                          |  9.file-transfer  |                          |
 *   |                          |    utility:       |                          |
 *   |                          |    PC -> S/390    |                          |
 *   |                          ===================>|                          |
 *   |                          |                   | 10.host file XXX'        |
 *   |                          |                   |                          |
 *   ----------------------------                   ---------------------------- </pre>
 *
 * <p>Note:  the Java character-encoding converters remove SO/SIs during the
 * EBCDIC DBCS to Unicode conversion, and insert SO/SIs in the Unicode to
 * EBCDIC DBCS conversion;  if the Unicode String includes emulation SO/SIs
 * (Unicode SO/SI values <code>'&#92;u000e'</code> and <code>'&#92;u000f'</code>),
 * these will be kept in the converted EBCDIC.
 */
public class LpexNls
{
   /**
    * Emulated SO/SI control characters for the display.
    */
   char SO, SI;

   /**
    * SO/SI control characters in EBCDIC DBCS encodings.
    */
   private static final byte
      EBCDIC_SO = 0x0e,
      EBCDIC_SI = 0x0f;


   /*******************************************************/
   /* Asian character encodings.                          */
   /*                                                     */
   /* LEGEND:                                             */
   /*   S-Chinese  = Simplified Chinese (China)           */
   /*   T-Chinese  = Traditional Chinese (Taiwan)         */
   /*   PRC        = People's Republic of China           */
   /*   Sun        = Sun JDK (JDK1.1 as default)          */
   /*   IBM        = IBM JDK (JDK1.1 as default) addition */
   /*   JDK1.2     = added in JDK1.2.2                    */
   /*   CP         = code page                            */
   /*                                                     */
   /* - Updated 3/2001 (from DTCO and Sun JDK1.3 docs);   */
   /*   some IBM-JDK-only encodings are now in Sun too.   */
   /*******************************************************/

   /*=============*/
   /*  DBCS/MBCS  */
   /*=============*/
   private static final String mbcsEncodings[] = {

      /*-------------------*/
      /* PC - DBCS: aD1D2b */
      /*-------------------*/

      "Cp942",      // Sun        Japan SJIS-78, superset of Cp932
      "SJIS",       // Sun        Japan Shift-JIS
      "Cp942C",     // Sun        Japan SJIS-78 syntax (variant of Cp942)  CP 942
      "Cp943",      // Sun        IBM OS/2 Japan SJIS-90, superset Cp932 & Shift-JIS
      "Cp943C",     // Sun        Japan SJIS-90 syntax (variant of Cp943)  CP 943
      "MS932",      // Sun        Japan Windows                            CP 932
      "MS932DB",    // ???        Japan Windows

      "Cp949",      // Sun        PC Korea (KS)
      "Cp949C",     // Sun        Korea (KS) (variant of Cp949)        CP 949
      "MS949",      // Sun        Korea Windows                        CP 949
      "Cp1363",     // IBM JDK1.2 Korea KS extended                    CP 1363
      "Cp1363C",    // IBM JDK1.2 Korea
      // Korean national standard KSC5601-1992:
      "Johab",      // Sun        Korea
      "ksc5601-1992", // alias for Johab??
      "ksc5601_1992", //    -- " --
      "ms1361",       //    -- " --

      "Cp1381",     // Sun        IBM OS/2, DOS S-Chinese GB (PRC)     CP 1381
      "GBK",        // Sun        S-Chinese GBK
      "MS936",      // Sun        S-Chinese Windows                    CP 936
      "Cp1386",     // IBM JDK1.2 S-Chinese GBK                        CP 1386

      "Big5",       // Sun        T-Chinese Big 5
      "Cp948",      // Sun        OS/2 T-Chinese SAA, superset of 938  CP 948
      "Cp950",      // Sun        PC T-Chinese (Hong Kong, Taiwan)     CP 950

      "MS950",      // Sun        T-Chinese Windows                    CP 950
      "Cp1370",     // IBM JDK1.2 T-Chinese with Euro                  CP 1370

//    "Cp874",      // Sun        Thai
//    "MS874",      // Sun        Windows Thai
//    "TIS620"      // Sun        Thai TIS620  = "PC" encoding???

      /*-------------------------------------------*/
      /* EUC (Extended Unix Code) - MBCS: aD1D2D3b */
      /*-------------------------------------------*/

      "Cp33722",    // Sun        IBM-eucJp - Japan (superset of 5050)
      "EUC_JP",     // Sun        Japan JIS X 0201, 0208, 0212
      "Cp33722C",   //     JDK1.2 Japan syntax                         CP 954

      "Cp970",      // Sun        AIX Korea                            CP 970
      "EUC_KR",     // Sun        Korea KS C 5601

      "Cp1383",     // Sun        IBM AIX S-Chinese (PRC)              CP 1383
      "EUC_CN",     // Sun        S-Chinese GB2312
      "GB18030",    // IBM JKD1.2 S-Chinese

      "Cp964",      // Sun        AIX T-Chinese                        CP 964
      "EUC_TW",     // Sun        T-Chinese CNS11643 (Plane 1-3)

      /*-------------------------------------------------*/
      /* EBCDIC DBCS with SO/SI controls: a<SO>D1D2<SI>b */
      /*-------------------------------------------------*/

      // see separate sosiEncodings table below...

      /*---------------------------------------------------------------*/
      /* others (Internet, etc.): a<3-byteESC_SEQ>D1D2<3-byteESC_SEQ>b */
      /*---------------------------------------------------------------*/

      "ISO2022JP",     // Sun    Japan JIS X 0201, 0208, 0212 in ISO 2022 form
      "JIS0201",       // Sun    Japan JIS X 0201
      "JIS0208",       // Sun    Japan JIS X 0208
      "JIS0212",       // Sun    Japan JIS X 0212

//    "JISAutoDetect", // Sun    detects and converts from Shift-JIS, EUC-Jp, ISO 2022 JP
//                     //          conversion to Unicode only

      "ISO2022KR",     // Sun    Korea ISO 2022 KR

      "ISO2022CN"      // Sun    S-Chinese ISO 2022 CN
//    "ISO2022CN_CNS", // Sun    T-Chinese CNS 11643 in ISO-2022-CN form,
//                     //          conversion from Unicode only
//    "ISO2022CN_GB"   // Sun    S-Chinese GB 2312 in ISO-2022-CN form,
//                     //          conversion from Unicode only

      // -as- what with pure DBCS-host (e.g., CCSID 300), where *all* the
      //      characters are two bytes each (no SO/SIs)??
      // -as- what with UTF character encodings?  Is any editor handling them
      //      directly (i.e., should we include them here)??
      };

   /*=====================================================*/
   /*  DBCS with SO/SI controls (EBCDIC): a<SO>D1D2<SI>b  */
   /*=====================================================*/
   private static final String sosiEncodings[] = {
      "Cp930",     //        Japan Katakana-Kanji mixed with 4370 UDC, superset of 5026  CP 930
      "Cp939",     //        Japan Latin-Kanji mixed with 4370 UDC, superset of 5035     CP 939
      "Cp1390",    // JDK1.2 Japan Katakana Euro                       CP 1390
      "Cp1399",    // JDK1.2 Japan Latin with Euro                     CP 1399

      "Cp933",     //        Korea mixed with 1880 UDC, superset of 5029                 CP 933
      "Cp1364",    // JDK1.2 Korea KS extended                         CP 1364

      "Cp935",     //        S-Chinese Host mixed with 1880 UDC, superset of 5031        CP 935
      "Cp1388",    // JDK1.2 S-Chinese GBK                             CP 1388

      "Cp937",     //        T-Chinese Host mixed with 6204 UDC, superset of 5033        CP 937
      "Cp1371"     // JDK1.2 T-Chinese with Euro                       CP 1371
      };

   // Typical non-DBCS EBCDIC encodings:
   // Cp037 (U.S.), presumably Cp1140 (variant of Cp037 with Euro character),
   // Cp500 (Latin 1 - EBCDIC 500V1), presumably Cp1148 (variant of Cp500 with Euro char),
   // Cp1047 (Open Edition).


   /*******************************************************/
   /* Bidirectional character encodings                   */
   /* (Arabic and Hebrew).                                */
   /*                                                     */
   /* LEGEND:                                             */
   /*   CP         = code page                            */
   /*                                                     */
   /* - Updated 11/2001 from Sun JDK 1.3 docs             */
   /*******************************************************/

   private static final String bidiEncodings[] = {
      /*==========*/
      /*  Arabic  */
      /*==========*/
      "Cp420",       // IBM Arabic
      "Cp864",       // PC Arabic
      "Cp1046",      // IBM Arabic - Windows
      "Cp1256",      // Windows Arabic (the only one used by Eclipse for Windows)
      "ISO8859_6",   // ISO 8859-6, Latin/Arabic alphabet
      "MacArabic",   // Macintosh Arabic
      // add Afghan, Farsi, Pashto, Persian, Sindhi, Urdu!?...

      /*==========*/
      /*  Hebrew  */
      /*==========*/
      "Cp424",       // IBM Hebrew
      "Cp856",       // IBM Hebrew
      "Cp862",       // PC Hebrew
      "Cp1255",      // Windows Hebrew (the only one used by Eclipse for Windows)
      "ISO8859_8",   // ISO 8859-8, Latin/Hebrew alphabet
      "MacHebrew"    // Macintosh Hebrew
      };

   /**
    * Additional 'patch' encodings set in the LPEX profile (persistent user
    * settings) [-as- entered via the editor commands "setMbcs/Sosi/BidiEncodings"].
    * @see #isMbcsEncoding
    * @see #isSosiEncoding
    * @see #isBidiEncoding
    */
   private static String _moreMbcsEncodings, _moreSosiEncodings, _moreBidiEncodings;

   private static Locale _initialLocale;

   /**
    * Native encoding.
    * This is the default character encoding of the platform LPEX runs on.
    * It is specified by the <code>file.encoding</code> Java system property.
    */
   private static String  _nativeEncoding;

   /**
    * Is the native character encoding DBCS/MBCS.
    */
   private static boolean _nativeMbcs;

   /**
    * Is the native character encoding EBCDIC DBCS.
    */
   private static boolean _nativeSosi;

   /**
    * Is the native character encoding bidi.
    *
    * The bidi support in LPEX is minimal, and consists of only performing bidi
    * functions when the native encoding is bidi (i.e., we are running on an
    * Arabic/Hebrew machine), rather than being a "good" Unicode application
    * and perform bidi on any text string that includes bidi characters, like
    * java.text.Bidi#requiresBidi() provides.
    * This support is deemed sufficient for a programmer's text widget!?
    *
    * !!!!!!!!!! NOTE: BIDI SUPPORT IS NOT YET IMPLEMENTED AT ALL..... !!!!!!!!!!
    *
    */
   private static boolean _nativeBidi;

   private LpexView _lpexView;
   private View _view;


   /**
    * Initialization.
    */
   static
   {
      _initialLocale = Locale.getDefault();           // remember initial locale
      setNativeEncoding(null);       // initialize native encoding to platform's
   }


   /**
    * Constructor for the LpexNls class.
    */
   LpexNls(LpexView lpexView)
   {
      _lpexView = lpexView;
      _view = lpexView._view;
      setSO(0);
      setSI(0);

      //-as- profile "back-door" to allow setting additional char encodings
      // (must also change initialization order in View.java's constructor)
      //LpexCommand lpexCommand = new LpexCommand() {   // "setMbcsEncodings"
      // public boolean doCommand (LpexView view, String params)
      //  { Profile.putString("mbcsEncodings", params); return true; }
      // };
      //_lpexView.defineCommand("setMbcsEncodings", lpexCommand);
      //lpexCommand = new LpexCommand() {               // "setSosiEncodings"
      // public boolean doCommand (LpexView view, String params)
      //  { Profile.putString("sosiEncodings", params); return true; }
      // };
      //_lpexView.defineCommand("setSosiEncodings", lpexCommand);
      //lpexCommand = new LpexCommand() {               // "setBidiEncodings"
      // public boolean doCommand (LpexView view, String params)
      //  { Profile.putString("bidiEncodings", params); return true; }
      // };
      //_lpexView.defineCommand("setBidiEncodings", lpexCommand);
   }

   char                   currentShiftOutCharacter()
   {
      return ShiftOutCharacterParameter.getParameter().currentValue(_view);
   }

   char                   currentShiftInCharacter()
   {
      return ShiftInCharacterParameter.getParameter().currentValue(_view);
   }

   /**
    * Set the value of the emulated Shift-out character displayed when the
    * view's current showSosi setting is <code>on</code>.
    *
    * @param newSO 0 = restore the Shift-out value to its default
    *                  (SBCS space, see ShiftOutCharacterParameter.java);
    *                  // used to be: (<code>'&#92;u000e'</code>);
    *              else, the new Unicode value
    */
   boolean                setSO(int newSO)
   {
      // don't allow Tab, DBCS char (will confuse our tab expansions, etc.)
      if (newSO != 0 && (newSO == '\t' || sourceWidth((char)newSO) != 1))
         return false;

      SO = (char)newSO;
      return true;
   }

   /**
    * Set the value of the emulated Shift-in character displayed when the
    * view's current showSosi setting is <code>on</code>.
    *
    * @param newSI 0 = restore the Shift-in value to default
    *                  (SBCS space, see ShiftInCharacterParameter.java);
    *                  // used to be: (<code>'&#92;u000f'</code>);
    *              else, the new Unicode value
    */
   boolean                setSI(int newSI)
   {
      // don't allow Tab, DBCS char (will confuse our tab expansions, etc.)
      if (newSI != 0 && (newSI == '\t' || sourceWidth((char)newSI) != 1))
         return false;

      SI = (char)newSI;
      return true;
   }

   /**
    * Validate a character encoding.
    *
    * @param encoding character encoding to validate
    *
    * @return true  = the character encoding is valid and supported by the
    *                 active Java run environment, or
    *         false = the encoding is null or not supported
    */
   public static boolean  isValidEncoding(String encoding)
   {
      if (encoding == null) // not really needed, could just let
         return false;      // .getBytes throw its null exception...

      try {
         (new String()).getBytes(encoding);
         return true;
         }
      catch(java.io.UnsupportedEncodingException e) {}

      return false;
   }

   /**
    * Determine if a character encoding is DBCS/MBCS - i.e., if some Unicode
    * characters will convert into <i>n</i>-byte characters in this encoding.
    *
    * The given encoding is checked against internal tables of DBCS/MBCS
    * character encodings.
    */
   public static boolean  isMbcsEncoding(String encoding)
   {
      if (encoding == null)
         return false;

      // 1.- take a look at the mbcsEncodings table
      for (int i = 0;  i < mbcsEncodings.length; i++)
         if (encoding.equals(mbcsEncodings[i]))
            return true;

      // 2.- take a look at 'patched-in' encodings in the user profile
      if (_moreMbcsEncodings == null) {
         _moreMbcsEncodings = Profile.getString("mbcsEncodings");
         if (_moreMbcsEncodings == null)
            _moreMbcsEncodings = "";
         }

      StringTokenizer st = new StringTokenizer(_moreMbcsEncodings);
      while (st.hasMoreTokens())
         if (encoding.equals(st.nextToken()))
            return true; //return isValidEncoding(encoding);

      // 3.- take a look at the sosiEncodings table
      return isSosiEncoding(encoding);
   }

   /**
    * Determine if a character encoding uses SO/SI control characters - i.e.,
    * if it is an EBCDIC DBCS character encoding.
    *
    * The given encoding is checked against an internal table of EBCDIC DBCS
    * character encodings.
    */
   public static boolean  isSosiEncoding(String encoding)
   {
      if (encoding == null)
         return false;

      // 1.- take a look at the sosiEncodings table
      for (int i = 0;  i < sosiEncodings.length; i++)
         if (encoding.equals(sosiEncodings[i]))
            return true;

      // 2.- take a look at 'patched-in' encodings in the user profile
      if (_moreSosiEncodings == null) {
         _moreSosiEncodings = Profile.getString("sosiEncodings");
         if (_moreSosiEncodings == null)
            _moreSosiEncodings = "";
         }

      StringTokenizer st = new StringTokenizer(_moreSosiEncodings);
      while (st.hasMoreTokens())
         if (encoding.equals(st.nextToken()))
            return true; //return isValidEncoding(encoding);

      return false;
   }

   /**
    * Determine if a character encoding is bidirectional.
    *
    * The given encoding is checked against an internal table of bidi
    * character encodings.
    */
   public static boolean  isBidiEncoding(String encoding)
   {
      if (encoding == null)
         return false;

      // 1.- take a look at the bidiEncodings table
      for (int i = 0;  i < bidiEncodings.length; i++)
         if (encoding.equals(bidiEncodings[i]))
            return true;

      // 2.- take a look at 'patched-in' encodings in the user profile
      if (_moreBidiEncodings == null) {
         _moreBidiEncodings = Profile.getString("bidiEncodings");
         if (_moreBidiEncodings == null)
            _moreBidiEncodings = "";
         }

      StringTokenizer st = new StringTokenizer(_moreBidiEncodings);
      while (st.hasMoreTokens())
         if (encoding.equals(st.nextToken()))
            return true; //return isValidEncoding(encoding);

      return false;
   }

   /**
    * Set the native encoding.  If <code>encoding</code> is <code>null</code>,
    * the native encoding is set to the platform's default as defined by the
    * <code>file.encoding</code> Java system property.
    *
    * @param encoding native encoding
    *
    * @return true = native encoding set, or
    *         false = the specified encoding is not supported
    */
   private static boolean setNativeEncoding(String encoding)
   {
      if (encoding == null)
        encoding = System.getProperty("file.encoding");
      else if (!isValidEncoding(encoding))
         return false;

      _nativeEncoding = encoding;
      _nativeMbcs = isMbcsEncoding(encoding);
      _nativeSosi = isSosiEncoding(encoding);
      _nativeBidi = isBidiEncoding(encoding);

      // notify all docs with sourceEncoding == native that encoding changed
      // (yes, should check that a doc's sourceEncoding actually changed!?...)
      for (Document document = Document._firstDocument;
           document != null;
           document = document._next)
         document.sourceEncodingChanged();

      return true;
   }

   /**
    * Retrieve the native character encoding.
    * @return the native encoding
    */
   public static String   getNativeEncoding()
   {
      return _nativeEncoding;
   }

   /**
    * Set the document source encoding.
    * If <code>encoding</code> is the default <code>null</code>, the source
    * encoding is set to the native character encoding;  an alias of
    * <code>"native"</code> can also be used to set the document's encoding to
    * the native encoding.
    *
    * @param  encoding  source encoding
    * @return true = source encoding set,
    *         false = specified encoding is not supported
    */
   boolean                setSourceEncoding(String encoding)
   {
      Document doc = _view.document();
      if (encoding == null) {                    // 1.- default = platform's
         doc._sourceEncoding = null;
         doc._sourceMbcs = _nativeMbcs;
         doc._sourceSosi = _nativeSosi;
         }

      else if (encoding.equals("native")) {      // 2.- set to platform's
         doc._sourceEncoding = _nativeEncoding;
         doc._sourceMbcs = _nativeMbcs;
         doc._sourceSosi = _nativeSosi;
         }

      else if (!isValidEncoding(encoding)) {     // 3.- unsupported, keep as is.
         return false;
         }

      else {                                     // 4.- set a new encoding
         doc._sourceEncoding = encoding;
         doc._sourceMbcs = isMbcsEncoding(encoding);
         doc._sourceSosi = isSosiEncoding(encoding);
         }

      // ensure SO & SI are still SBCS in new encoding - otherwise default them
      if (doc._sourceSosi && (sourceWidth(currentShiftOutCharacter()) != 1 ||
                              sourceWidth(currentShiftInCharacter()) != 1)) {
         setSO(0);
         setSI(0);
         }

      return true;
   }

   /**
    * Retrieve the document's source character encoding.
    * This is the character encoding of the origin / target platform of an edit
    * file.
    *
    * <p>In the current implementation, the source character encoding either
    * defaults to the <code>file.encoding</code> Java system property), or was
    * explicitly set for files brought over from a host system.
    *
    * @return the source encoding
    */
   // <p>The source character encoding is either obtained through
   // <code>InputStreamReader.getEncoding()</code> (which usually defaults to
   // the <code>file.encoding</code> system property), or is explicitly set for
   // files brought over from a host system.
   public String          getSourceEncoding()
   {
      return getSourceEncoding(_view.document());
   }

   /**
    * @see #getSourceEncoding
    */
   static String          getSourceEncoding(Document doc)
   {
      String sourceEncoding = doc._sourceEncoding;
      return (sourceEncoding == null)? _nativeEncoding : sourceEncoding;
   }

   /**
    * Query whether the source character encoding of the document is DBCS/MBCS.
    */
   public boolean         isSourceMbcs()
   {
      return _view.document()._sourceMbcs;
   }

   /**
    * Query whether the source character encoding of the document is DBCS/MBCS.
    */
   static boolean         isSourceMbcs(Document doc)
   {
      return doc._sourceMbcs;
   }

   /**
    * Query whether the source character encoding of the document is EBCDIC DBCS.
    */
   public boolean         isSourceSosi()
   {
      return _view.document()._sourceSosi;
   }

   /**
    * Query whether the source character encoding of the document is EBCDIC DBCS.
    */
   static boolean         isSourceSosi(Document doc)
   {
      return doc._sourceSosi;
   }

   /**
    * Query the current setting of <b>useSourceColumns</b> for the view.
    */
   boolean                useSourceColumns()
   {
      return UseSourceColumnsParameter.getParameter().currentValue(_view);
   }

   /**
    * Query whether the view's document is effectively using source columns.
    * The method returns <code>true</code> when the source encoding is DBCS/MBCS
    * and the current <b>useSourceColumns</b> parameter is <code>on</code>.
    */
   public boolean         usingSourceColumns()
   {
      return (isSourceMbcs() &&
              UseSourceColumnsParameter.getParameter().currentValue(_view));
   }

   /**
    * @see #usingSourceColumns
    */
   static boolean         usingSourceColumns(Document doc)
   {
      return (doc._sourceMbcs &&
              UseSourceColumnsParameter.getParameter().currentValue(doc));
   }

   /**
    * Query whether the view is displaying emulation SO/SI controls.
    * The method returns <code>true</code> when the source encoding of the
    * document is EBCDIC DBCS and the current <b>showSosi</b> parameter is
    * <code>on</code>.
    */
   public boolean         displayingSosi()
   {
      return (isSourceSosi() &&
              ShowSosiParameter.getParameter().currentValue(_view));
   }

   /**
    * Simulate NLS environments.  For development purposes only, use with
    * extreme care!  This is not a full simulation.  It alters the default
    * locale for the entire LPEX session, and modifies the native encoding
    * setting.
    */
   boolean                nlsSimulator(String parameters)
   {
      boolean setDefault = false, query = false,
              setJapan = false, setHost = false;

      if (parameters.trim().length() == 0)
         setDefault = true;
      else {
         StringTokenizer st = new StringTokenizer(parameters);
         while (st.hasMoreTokens()) {
            String t = st.nextToken();
            if (t.equalsIgnoreCase("query"))
               query = true;
            else if (t.equalsIgnoreCase("default")) {
               setDefault = true;
               setJapan = false;
               }
            else if (t.equalsIgnoreCase("japan")) {
               setJapan = true;
               setDefault = false;
               }
            else if (t.equalsIgnoreCase("host") || t.equals("390"))
               setHost = true;
            }
         }

      if (setDefault) {
         Locale.setDefault(_initialLocale);
         _lpexView.doDefaultCommand("set shiftOutCharacter 0x0000");
         _lpexView.doDefaultCommand("set shiftInCharacter 0x0000");
         setNativeEncoding(null);
         _lpexView.doDefaultCommand("set sourceEncoding"); // restore
         }

      else if (setJapan) {
         // Japanese - native Windows platform, optionally S/390 files
         Locale.setDefault(Locale.JAPAN);

         if (!setNativeEncoding("MS932")) // only on IBM's JDK
            setNativeEncoding ("SJIS");   // default on Sun's JDK

         if (setHost) { // EBCDIC DBCS
            _lpexView.doDefaultCommand("set sourceEncoding Cp939");
            // SO/SI on a Windows English US 437:  '>>' '<<'
            _lpexView.doDefaultCommand("set shiftOutCharacter 0x00bb");
            _lpexView.doDefaultCommand("set shiftInCharacter 0x00ab");
            }
         else         // restore to the native encoding
            _lpexView.doDefaultCommand("set sourceEncoding");
         // should also load/save files according to new encodings... -as-
         }

      if (query) {
         System.out.println("\n NLS SIM defaultLocale="+Locale.getDefault()+
                                    ", nativeEncoding="+getNativeEncoding()+
                                    ", sourceEncoding="+getSourceEncoding());
         if (isSourceSosi())
            System.out.println("         SO=0x"+Integer.toHexString(currentShiftOutCharacter())+
                                      ", SI=0x"+Integer.toHexString(currentShiftInCharacter()));
         }

      // display may be affected, must reset cached info (diplay text, width, etc.):
      for (Element element = _view.document().elementList().first();
           element != null;
           element = element.next()) {
         // if (element.tabs()) || all other current caching conditions *as*  element.hasSosis()
         // {
                // must do it for *all* views of the document!! *as*
                element.elementView(_view).resetDisplayText();
         // }
         }
      // update current display for all views of document! *as*

      return true;
   }

   /**
    * Get the byte-length of a Unicode String <code>s</code> in
    * the specified character <code>encoding</code>.
    * If the encoding is not DBCS/MBCS, this method returns
    * <code>s.length()</code>.  For EBCDIC DBCS encodings,
    * the length returned includes the SO/SI control characters.
    */
   public static int      encodingLength(String s, String encoding)
   {
      if (s == null)
         return 0;

      if (isMbcsEncoding(encoding)) {
         try {
            int l = s.getBytes(encoding).length;
            // -as- for 1 char JDKs 1.1.7[B] give <SO><D1><D2> w/o <SI>?!
            if (l == 3 && s.length() == 1 && isSosiEncoding(encoding))
               l = 4;
            return l;
            }
         catch(java.io.UnsupportedEncodingException e) {}
         }

      return s.length();
   }

   /**
    * Get the byte-length for one Unicode character <code>c</code> converted
    * to the specified character <code>encoding</code>.  If the encoding is not
    * DBCS/MBCS, this method returns <code>1</code>;  for an EBCDIC DBCS
    * character it returns <code>2</code> (i.e., for the two-byte character
    * itself, without the SO/SI controls).
    *
    * @return 1 if encoding is not a DBCS/MBCS encoding,
    *           or if <code>c</code> converts to a single-byte character;
    *         2 if the encoding character is double-byte;
    *         <i>n</i> if the encoding character is multi-byte.
    */
   public static int      encodingLength(char c, String encoding)
   {
      if (isMbcsEncoding(encoding)) {
         try {
            int l = (new Character(c)).toString().getBytes(encoding).length;
            return (l > 2 && isSosiEncoding(encoding))? 2 : l; // drop SO/SI
            }
         catch(java.io.UnsupportedEncodingException e) {}
         }

      return 1;
   }

   /**
    * Get the byte-length of a Unicode String <code>s</code> in
    * the native character encoding.
    * If the native encoding is not DBCS/MBCS, this method returns
    * <code>s.length()</code>.  For EBCDIC DBCS native encodings,
    * the length returned includes the SO/SI control characters.
    */
   static int             nativeLength(String s)
   {
      if (s == null)
         return 0;

      int l = (_nativeMbcs)? s.getBytes().length : s.length();

      // -as- for 1 char JDKs 1.1.7[B] give <SO><D1><D2> w/o <SI>?!
      if (l == 3 && s.length() == 1 && _nativeSosi)
         l = 4;

      return l;
   }

   /**
    * Get the byte-length for one Unicode character <code>c</code> converted
    * to the native character encoding.  If the native encoding is not
    * DBCS/MBCS, this method returns <code>1</code>;  for an EBCDIC DBCS
    * character it returns <code>2</code> (i.e., for the two-byte character
    * itself, without the SO/SI controls).
    *
    * @return 1 if native encoding is not a DBCS/MBCS encoding,
    *           or if <code>c</code> converts to a single-byte character;
    *         2 if the native character is double-byte;
    *         <i>n</i> if the native character is multi-byte.
    */
   static int             nativeLength(char c)
   {
      if (_nativeMbcs) {
         int l = (new Character(c)).toString().getBytes().length;

         // -as- for 1 char JDKs 1.1.7[B] give <SO><D1><D2> w/o <SI>?!
         //return (l==4 && _nativeSosi)? 2 : l;
         return (l > 2 && _nativeSosi)? 2 : l; // drop SO/SI
         }

      return 1;
   }

   /**
    * Get the display-column width for one Unicode character <code>c</code>
    * converted to the native character encoding.
    *
    * <p>Currently, this method effectively calls
    * <code>encodingLength(c, nativeEncoding)</code>.
    * This may not be appropriate for certain character encodings (such as EUC).
    *
    * @see #encodingLength(char,String)
    */
   public static int      nativeWidth(char c)
   {
      return nativeLength(c);
   }

   /**
    * Get the byte-length of a Unicode String <code>s</code> in
    * the source character encoding.
    * If the source encoding is not DBCS/MBCS, this method returns
    * <code>s.length()</code>.  For EBCDIC DBCS source encodings,
    * the length returned includes the SO/SI control characters.
    */
   int                    sourceLength(String s)
   {
      return sourceLength(s, _view.document());
   }

   /**
    * @see sourceLength(String)
    */
   static int             sourceLength(String s, Document doc)
   {
      if (s == null)
         return 0;

      if (isSourceMbcs(doc)) {
         try {
            //byte[] ebcdic = null;
            //try { ebcdic = s.getBytes(getSourceEncoding(doc)); }
            //catch(Exception e) {}
            //System.out.println("");
            //for (int i = 0; ebcdic != null && i < ebcdic.length; i++)
            //   System.out.print(" "+ebcdic[i]);

            int l = s.getBytes(getSourceEncoding(doc)).length;

            // -as- for 1 char JDKs 1.1.7[B] give <SO><D1><D2> w/o <SI>?!
            if (l == 3 && s.length() == 1 && isSourceSosi(doc))
               l = 4;

            return l;
            }
         catch(java.io.UnsupportedEncodingException e) {}
         }

      return s.length();
   }

   /**
    * Get the byte-length for one Unicode character <code>c</code> converted
    * to the source character encoding.  If the source encoding is not
    * DBCS/MBCS, this method returns <code>1</code>;  for an EBCDIC DBCS
    * character it returns <code>2</code> (i.e., for the two-byte character
    * itself, without the SO/SI controls).
    *
    * @return 1 if source is not a DBCS/MBCS encoding,
    *           or if <code>c</code> converts to a single-byte character;
    *         2 if the source character is double-byte;
    *         <i>n</i> if the source character is multi-byte.
    */
   public int             sourceLength(char c)
   {
      return sourceLength(c, _view.document());
   }

   /**
    * @see #sourceLength(char)
    */
   static int             sourceLength(char c, Document doc)
   {
      if (isSourceMbcs(doc)) {
         try {
            int l = (new Character(c)).toString().getBytes(getSourceEncoding(doc)).length;

            // -as- for 1 char JDKs 1.1.7[B] give <SO><D1><D2> w/o <SI>?!
            //return (l==4 && isSourceSosi())? 2 : l;
            return (l > 2 && isSourceSosi(doc))? 2 : l; // drop SO/SI
            }
         catch(java.io.UnsupportedEncodingException e) {}
         }

      return 1;
   }

   /**
    * Get the display-column width for one Unicode character <code>c</code>
    * converted to the source character encoding.
    *
    * <p>Currently, this method effectively calls
    * <code>encodingLength(c, sourceEncoding)</code>.
    * This may not be appropriate for certain character encodings (such as EUC).
    *
    * @see #encodingLength(char,String)
    */
   public int             sourceWidth(char c)
   {
      return sourceLength(c);
   }

   /**
    * Return the character encoding for Unicode String <code>s</code>.
    * This is a workaround for the JDK 1.1.n bug in String.getBytes(encoding)
    * which for the conversion of a one-character-long String to an EBCDIC DBCS
    * encoding only returns &lt;SO&gt;&lt;D1&gt;&lt;D2&gt; (i.e., without the
    * &lt;SI&gt;).
    *
    * @param s Unicode String
    */
   public static byte[]   getBytes(String s, String encoding) throws java.io.UnsupportedEncodingException
   {
      byte[] ebcdic;
      try {
         ebcdic = s.getBytes(encoding);
         }
      catch(java.io.UnsupportedEncodingException e) {
         throw e;
         }

      if (ebcdic.length == 3 && s.length() == 1 && isSosiEncoding(encoding)) {
         byte [] fixedEbcdic = { EBCDIC_SO, ebcdic[1], ebcdic[2], EBCDIC_SI };
         return fixedEbcdic;
         }

      return ebcdic;
   }

   /**
    * Return the SO/SI source character encoding for String <code>s</code>.
    * This is a workaround for the JDK 1.1.n bug in String.getBytes(encoding)
    * which for the conversion of a one-character-long String to an EBCDIC DBCS
    * encoding only returns &lt;SO&gt;&lt;D1&gt;&lt;D2&gt; (i.e., without the
    * &lt;SI&gt;).
    *
    * @param s Unicode String
    * @see #getBytes
    * @see #getBytesSource(String,Document)
    */
   private byte[]         getBytesSource(String s) throws java.io.UnsupportedEncodingException
   {
      return getBytesSource(s, _view.document());
   }

   /**
    * @see #getBytes
    * @see #getBytesSource(String)
    */
   private static byte[]  getBytesSource(String s, Document doc) throws java.io.UnsupportedEncodingException
   {
      byte[] ebcdic;
      try {
         ebcdic = s.getBytes(getSourceEncoding(doc));
         }
      catch(java.io.UnsupportedEncodingException e) {
         throw e;
         }

      if (ebcdic.length == 3 && s.length() == 1 && isSourceSosi(doc)) {
         byte [] fixedEbcdic = { EBCDIC_SO, ebcdic[1], ebcdic[2], EBCDIC_SI };
         return fixedEbcdic;
         }

      return ebcdic;
   }

   /**
    * Return the character index into the SO/SI-emulation Unicode String
    * which corresponds to the character <code>index</code> into the Unicode
    * String <code>s</code>.
    * If the source encoding is not EBCDIC DBCS, this method returns
    * <code>index</code> unchanged.
    * The index returned is positioned away from any SO/SI control character.
    *
    * <pre>
    *  abDcd  -->  ab<SO>D<SI>cd
    *    _=              _    =      </pre>
    *
    * @param s     Unicode String
    * @param index ZERO-based index into <code>s</code>
    *
    * @return ZERO-based index into <code>s</code> with added emulation SO/SIs
    */
   int                    emulationCharIndex(String s, int index)
   {
      if (!isSourceSosi() || index < 0 || s == null)
         return index;

      int k = 0, i = 0, j = 0;

      /*---------------------------------------------------*/
      /*  s                                 s + SO/SIs     */
      /*  Unicode      EBCDIC DBCS          Unicode SO/SI  */
      /*  abDcd   -->  ab<SO>D1D2<SI>cd --> ab<SO>D<SI>cd  */
      /*    _=               _       =            _    =   */
      /*  k            i                    j              */
      /*  index                             return         */
      /*---------------------------------------------------*/
      byte[] ebcdic;
      try {
         ebcdic = getBytesSource(s); // s.getBytes(getSourceEncoding());
         }
      catch(Exception e) {
         return index;
         }

      boolean dbcs = false;
      while (i < ebcdic.length) {
         if (ebcdic[i] == EBCDIC_SO) {       // SO
            dbcs = true;
            i++;  j++;
            if (k == index)
               return j;
            }
         else if (ebcdic[i] == EBCDIC_SI) {  // SI
            dbcs = false;
            i++;  j++;
            if (k == index)
               return j;
            }
         else {                              // SBCS / DBCS
            if (k == index)
               return j;
            if (dbcs)
               i++;
            k++;  i++;  j++;
            }
         }

      // index beyond the end of the string
      return j + (index - k);
   }

   /**
    * Return the index into the SO/SI-emulation Unicode String
    * which corresponds to the <code>index</code> into the Unicode
    * String <code>s</code>.
    * If the source encoding is not EBCDIC DBCS, this method returns
    * <code>index</code> unchanged.
    *
    * <pre>
    *  abDcd  -->  ab<SO>D<SI>cd
    *    _=          _    =          </pre>
    *
    * @param s     Unicode String
    * @param index ZERO-based index into <code>s</code>
    *
    * @return ZERO-based index into <code>s</code> with added emulation SO/SIs
    * @see #emulationCharIndex
    */
   int                    emulationIndex(String s, int index)
   {
      if (!isSourceSosi() || index < 0 || s == null)
         return index;

      int k = 0, i = 0, j = 0;

      /*---------------------------------------------------*/
      /*  s                                 s + SO/SIs     */
      /*  Unicode      EBCDIC DBCS          Unicode SO/SI  */
      /*  abDcd   -->  ab<SO>D1D2<SI>cd --> ab<SO>D<SI>cd  */
      /*    _=           _       =            _    =       */
      /*  k            i                    j              */
      /*  index                             return         */
      /*---------------------------------------------------*/
      byte[] ebcdic;
      try {
         ebcdic = getBytesSource(s); // s.getBytes(getSourceEncoding());
         }
      catch(Exception e) {
         return index;
         }

      boolean dbcs = false;
      for (; i < ebcdic.length; i++, j++) {
         if (k == index)
            return j;
         if (ebcdic[i] == EBCDIC_SO)        // SO
            dbcs = true;
         else if (ebcdic[i] == EBCDIC_SI)   // SI
            dbcs = false;
         else {                             // SBCS / DBCS
            if (dbcs)
               i++;
            k++;
            }
         }

      // index beyond the end of the string
      return j + (index - k);
   }

   /**
    * Return the index into the Unicode String <code>s</code> which corresponds
    * to the <code>index</code> into its SO/SI-emulation Unicode String.
    * If the source encoding is not EBCDIC DBCS, this method returns
    * <code>index</code> unchanged.
    *
    * <pre>
    *  ab<SO>D<SI>cd  -->  abDcd
    *    _    =              _=      </pre>
    *
    * @param s     Unicode String
    * @param index ZERO-based emulation index
    *
    * @return ZERO-based index into <code>s</code>
    * @see #emulationIndex
    * @see #emulationCharIndex
    */
   int                    indexFromEmulationIndex(String s, int index)
   {
      if (!isSourceSosi() || index < 0 || s == null)
         return index;

      int k = 0, i = 0, j = 0;

      /*---------------------------------------------------*/
      /*  s                                 s + SO/SIs     */
      /*  Unicode      EBCDIC DBCS          Unicode SO/SI  */
      /*  abDcd   -->  ab<SO>D1D2<SI>cd     ab<SO>D<SI>cd  */
      /*    _=           _       =            _    =       */
      /*  k            i                    j              */
      /*  return                            index          */
      /*---------------------------------------------------*/
      byte[] ebcdic;
      try {
         ebcdic = getBytesSource(s); // s.getBytes(getSourceEncoding());
         }
      catch(Exception e) {
         return index;
         }

      boolean dbcs = false;
      for (; i < ebcdic.length; i++, j++) {
         if (j == index)
            return k;
         if (ebcdic[i] == EBCDIC_SO)        // SO
            dbcs = true;
         else if (ebcdic[i] == EBCDIC_SI)   // SI
            dbcs = false;
         else {                             // SBCS / DBCS
            if (dbcs)
               i++;
            k++;
            }
         }

      // index beyond the end of the string
      return k + (index - j);
   }

   /**
    * Return the character index into the encoded string (i.e., as
    * converted from Unicode <code>s</code> using the character
    * <code>encoding</code>), which corresponds to the <code>index</code> into
    * text String <code>s</code>.
    * If the encoding is not DBCS/MBCS, this method returns
    * <code>index</code> unchanged.
    * If the encoding is EBCDIC DBCS, the index returned is
    * positioned away from a SO/SI control character.
    *
    * @param s Unicode String
    * @param index ZERO-based index into <code>s</code>
    * @param encoding character encoding
    *
    * @return ZERO-based index into encoded string
    */
   public static int      encodingCharIndex(String s, int index, String encoding)
   {
      if (!isMbcsEncoding(encoding) || index < 0 || s == null)
         return index;

      /*--------------------------------------------*/
      /*                s                           */
      /*                Unicode     EBCDIC DBCS     */
      /*  EBCDIC DBCS:  abDcd   --> ab<SO>DD<SI>cd  */
      /*                  _=              _     =   */
      /*                i           j               */
      /*                index       return          */
      /*--------------------------------------------*/
      if (isSosiEncoding(encoding)) {
         int i = 0, j = 0;
         byte[] ebcdic;
         try {
            ebcdic = getBytes(s, encoding); // s.getBytes(encoding);
            }
         catch(Exception e) {
            return index;
            }

         boolean dbcs = false;
         while (j < ebcdic.length) {
            if (ebcdic[j] == EBCDIC_SO) {       // SO
               dbcs = true;
               j++;
               if (i == index)
                  return j;
               }
            else if (ebcdic[j] == EBCDIC_SI) {  // SI
               dbcs = false;
               j++;
               if (i == index)
                  return j;
               }
            else {                              // SBCS / DBCS
               if (i == index)
                  return j;
               if (dbcs)
                  j++;
               i++;
               j++;
               }
            }

         // index beyond the end of the string
         return j + (index - i);
         }

      /*----------------------------------*/
      /*             s                    */
      /*             Unicode     MBCS     */
      /*  DBCS/MBCS: abDcd   --> abDDDcd  */
      /*               _=          _  =   */
      /*             index       return   */
      /*----------------------------------*/
      if (index < s.length())
         return encodingLength(s.substring(0, index), encoding);

      return encodingLength(s, encoding) + index - s.length();
   }

   /**
    * Return the character index into the encoded string (i.e., as
    * converted from Unicode <code>s</code> using the character
    * <code>encoding</code>), which corresponds to the <code>index</code> into
    * text String <code>s</code>.
    * If the encoding is not DBCS/MBCS, this method returns
    * <code>index</code> unchanged.
    *
    * @param s Unicode String
    * @param index ZERO-based index into <code>s</code>
    * @param encoding character encoding
    *
    * @return ZERO-based index into encoded string
    * @see #encodingCharIndex
    */
   static int             encodingIndex(String s, int index, String encoding)
   {
      if (!isMbcsEncoding(encoding) || index < 0 || s == null)
         return index;

      /*--------------------------------------------*/
      /*                s                           */
      /*                Unicode     EBCDIC DBCS     */
      /*  EBCDIC DBCS:  abDcd   --> ab<SO>DD<SI>cd  */
      /*                  _=          _     =       */
      /*                i           j               */
      /*                index       return          */
      /*--------------------------------------------*/
      if (isSosiEncoding(encoding)) {
         int i = 0, j = 0;
         byte[] ebcdic;
         try {
            ebcdic = getBytes(s, encoding); // s.getBytes(encoding);
            }
         catch(Exception e) {
            return index;
            }

         boolean dbcs = false;
         for (; j < ebcdic.length; j++) {
            if (i == index)
               return j;
            if (ebcdic[j] == EBCDIC_SO)       // SO
               dbcs = true;
            else if (ebcdic[j] == EBCDIC_SI)  // SI
               dbcs = false;
            else {                            // SBCS / DBCS
               if (dbcs)
                  j++;
               i++;
               }
            }

         // index beyond the end of the string
         return j + (index - i);
         }

      /*----------------------------------*/
      /*             s                    */
      /*             Unicode     MBCS     */
      /*  DBCS/MBCS: abDcd   --> abDDDcd  */
      /*               _=          _  =   */
      /*             index       return   */
      /*----------------------------------*/
      if (index < s.length())
         return encodingLength(s.substring(0, index), encoding);

      return encodingLength(s, encoding) + index - s.length();
   }

   /**
    * Return the character index into the source string (i.e., as
    * converted from Unicode <code>s</code> using the source character
    * encoding), which corresponds to the <code>index</code> into text
    * String <code>s</code>.
    * If the source encoding is not DBCS/MBCS, this method returns
    * <code>index</code> unchanged.
    * If the source encoding is EBCDIC DBCS, the index returned is
    * positioned away from a SO/SI control character.
    *
    * @param s Unicode String
    * @param index ZERO-based index into <code>s</code>
    *
    * @return ZERO-based index into source string
    */
   int                    sourceCharIndex(String s, int index)
   {
      if (!isSourceMbcs() || index < 0 || s == null)
         return index;

      /*--------------------------------------------*/
      /*                s                           */
      /*                Unicode     EBCDIC DBCS     */
      /*  EBCDIC DBCS:  abDcd   --> ab<SO>DD<SI>cd  */
      /*                  _=              _     =   */
      /*                i           j               */
      /*                index       return          */
      /*--------------------------------------------*/
      if (isSourceSosi()) {
         int i = 0, j = 0;
         byte[] ebcdic;
         try {
            ebcdic = getBytesSource(s); // s.getBytes(getSourceEncoding());
            }
         catch(Exception e) {
            return index;
            }

         boolean dbcs = false;
         while (j < ebcdic.length) {
            if (ebcdic[j] == EBCDIC_SO) {       // SO
               dbcs = true;
               j++;
               if (i == index)
                  return j;
               }
            else if (ebcdic[j] == EBCDIC_SI) {  // SI
               dbcs = false;
               j++;
               if (i == index)
                  return j;
               }
            else {                              // SBCS / DBCS
               if (i == index)
                  return j;
               if (dbcs)
                  j++;
               i++;
               j++;
               }
            }

         // index beyond the end of the string
         return j + (index - i);
         }

      /*----------------------------------*/
      /*             s                    */
      /*             Unicode     MBCS     */
      /*  DBCS/MBCS: abDcd   --> abDDDcd  */
      /*               _=          _  =   */
      /*             index       return   */
      /*----------------------------------*/
      if (index < s.length())
         return sourceLength(s.substring(0, index));

      return sourceLength(s) + index - s.length();
   }

   /**
    * Return the index into text String <code>s</code> which corresponds to the
    * <code>index</code> into its encoding string (i.e., as converted using the
    * specified character <code>encoding</code>).
    * If the encoding is not DBCS/MBCS, this method returns
    * <code>index</code> unchanged.
    *
    * @param s Unicode String
    * @param index ZERO-based index into the encoding string of <code>s</code>
    *
    * @return ZERO-based index into <code>s</code>
    */
   public static int      indexFromEncodingIndex(String s, int index, String encoding)
   {
      if (!isMbcsEncoding(encoding) || index < 0 || s == null)
         return index;

      int i = 0, j = 0;

      /*--------------------------------------------*/
      /*                s                           */
      /*                Unicode     EBCDIC DBCS     */
      /*  EBCDIC DBCS:  abDcd   <-- ab<SO>DD<SI>cd  */
      /*                  _=           _  __=   =   */
      /*                i           j               */
      /*                return      index           */
      /*--------------------------------------------*/
      if (isSosiEncoding(encoding)) {
         byte[] ebcdic;
         try {
            ebcdic = getBytes(s, encoding); // s.getBytes(encoding);
            }
         catch(Exception e) {
            return index;
            }

         boolean dbcs = false;
         while (j < ebcdic.length) {
            if (ebcdic[j] == EBCDIC_SO) {       // SO
               if (j >= index)
                  return i;
               dbcs = true;
               j++;
               }
            else if (ebcdic[j] == EBCDIC_SI) {  // SI
               if (j >= index)
                  return i;
               dbcs = false;
               j++;
               }
            else {                              // SBCS / DBCS
               if (dbcs)
                  j++;
               if (j >= index)
                  return i;
               i++;
               j++;
               }
            }

         // index beyond the end of the string
         return i + (index - j);
         }

      /*----------------------------------*/
      /*             s                    */
      /*             Unicode     MBCS     */
      /*  DBCS/MBCS: abDcd   <-- abDDDcd  */
      /*               _=          ___=   */
      /*             i           j        */
      /*             return      index    */
      /*----------------------------------*/
      while (i < s.length()) {
         if (j == index)
            return i;
         j += encodingLength(s.charAt(i), encoding);
         if (j > index)
            return i;
         i++;
         }

      // index beyond the end of the string
      return i + (index - j);
   }

   /**
    * Return the index into text String <code>s</code> which corresponds to the
    * <code>index</code> into its source string (i.e., as converted using the
    * source character encoding).
    * If the source encoding is not DBCS/MBCS, this method returns
    * <code>index</code> unchanged.
    *
    * @param s Unicode String
    * @param index ZERO-based index into the source string of <code>s</code>
    *
    * @return ZERO-based index into <code>s</code>
    */
   int                    indexFromSourceIndex(String s, int index)
   {
      if (!isSourceMbcs() || index < 0 || s == null)
         return index;

      int i = 0, j = 0;

      /*--------------------------------------------*/
      /*                s                           */
      /*                Unicode     EBCDIC DBCS     */
      /*  EBCDIC DBCS:  abDcd   <-- ab<SO>DD<SI>cd  */
      /*                  _=           _  __=   =   */
      /*                i           j               */
      /*                return      index           */
      /*--------------------------------------------*/
      if (isSourceSosi()) {
         byte[] ebcdic;
         try {
            ebcdic = getBytesSource(s); // s.getBytes(getSourceEncoding());
            }
         catch(Exception e) {
            return index;
            }

         boolean dbcs = false;
         while (j < ebcdic.length) {
            if (ebcdic[j] == EBCDIC_SO) {       // SO
               if (j >= index)
                  return i;
               dbcs = true;
               j++;
               }
            else if (ebcdic[j] == EBCDIC_SI) {  // SI
               if (j >= index)
                  return i;
               dbcs = false;
               j++;
               }
            else {                              // SBCS / DBCS
               if (dbcs)
                  j++;
               if (j >= index)
                  return i;
               i++;
               j++;
               }
            }

         // index beyond the end of the string
         return i + (index - j);
         }

      /*----------------------------------*/
      /*             s                    */
      /*             Unicode     MBCS     */
      /*  DBCS/MBCS: abDcd   <-- abDDDcd  */
      /*               _=          ___=   */
      /*             i           j        */
      /*             return      index    */
      /*----------------------------------*/
      while (i < s.length()) {
         if (j == index)
            return i;
         j += sourceLength(s.charAt(i));
         if (j > index)
            return i;
         i++;
         }

      // index beyond the end of the string
      return i + (index - j);
   }

   /**
    * Return the column in the source character encoding which corresponds
    * to <code>index</code> in the display String <code>displayText</code>.
    * This method uses the current view's showSosi setting.  It assumes
    * any emulation SO/SIs in <code>displayText</code> are SBCS characters.
    */
   int                    sourceColumnFromDisplayIndex(String displayText, int index)
   {
      if (!isSourceMbcs() || index < 0 || displayText == null)
         return index;

      // SO/SI, showSosi = off:  if there are expanded Tabs in the line, the
      // host will expand completely differently (if the host can expand tabs,
      // that is)...  BUT, is there any better calculation for source columns
      // relative to what LPEX displays?!...
      if (isSourceSosi() && !_view.currentShowSosi())
         return sourceCharIndex(displayText, index);

      int i = 0, col = 0;
      while (i < displayText.length()) {
         if (i == index)
            return col;
         col += sourceWidth(displayText.charAt(i));
         i++;
         }

      // index beyond the end of the string
      return col + (index - i);
   }

   /**
    * Return the display column which corresponds
    * to <code>index</code> into the display String <code>displayText</code>.
    * This method assumes any emulation SO/SIs in <code>displayText</code> are
    * SBCS characters.
    */
   int                    columnFromDisplayIndex(String displayText, int index)
   {
      if (!isSourceMbcs() || index < 0 || displayText == null)
         return index;

      int i = 0, col = 0;
      while (i < displayText.length()) {
         if (i == index)
            return col;
         col += sourceWidth(displayText.charAt(i));
         i++;
         }

      // index beyond the end of the string
      return col + (index - i);
   }

   /**
    * Return the index into the display String <code>displayText</code>
    * which corresponds to the display <code>column</code>.
    * This method assumes any emulation SO/SIs in <code>displayText</code> are
    * SBCS characters.
    */
   int                    displayIndexFromColumn(String displayText, int column)
   {
      if (!isSourceMbcs() || column < 0 || displayText == null)
         return column;

      /*--------------------------*/
      /*                  > AABB  */
      /*         column   0 1234  */
      /*                          */
      /*                  > A B   */
      /*  return index    0 1 2   */
      /*--------------------------*/
      int i = 0, col = 0;
      while (i < displayText.length()) {
         if (col >= column)
            return i;
         col += sourceWidth(displayText.charAt(i));
         if (col > column)
            return i;
         i++;
         }

      // column beyond displayText
      return i + (column - col);
   }


// /**
//  * Return the character index into the source string (i.e., the String
//  * in the source character encoding), which corresponds to the
//  * <code>index</code> into String <code>s</code> with added emulation SO/SIs.
//  * If the source encoding is not EBCDIC DBCS, this method returns
//  * <code>index</code> unchanged.
//  * The index returned is positioned away from a SO/SI control character.
//  *
//  * Used to display the Column on the status line in useSourceColumns.
//  *
//  * @param s Unicode String
//  * @param index ZERO-based index into <code>s</code> with added emulation SO/SIs
//  * @return ZERO-based index into the source string
//  */
// public int             sourceCharIndexFromEmulationIndex (String s, int index)
// {
//    if (!isSourceSosi() || index < 0 || s == null)
//       return index;
//    int i = 0, j = 0;
//    /*--------------------------------------------------*/
//    /*  s            s + SO/SI                          */
//    /*  Unicode      Unicode SO/SI      EBCDIC DBCS     */
//    /*  abDcd    ==  ab<SO>D<SI>cd  --> ab<SO>DD<SI>cd  */
//    /*    _=               _    =             _     =   */
//    /*               j                  i               */
//    /*               index              return          */
//    /*--------------------------------------------------*/
//    byte[] ebcdic;
//    try {
//       ebcdic = getBytesSource(s); // s.getBytes(getSourceEncoding());
//       }
//    catch(Exception e) {
//       return index;
//       }
//    boolean dbcs = false;
//    while (i < ebcdic.length) {
//       if (ebcdic[i] == EBCDIC_SO) {      // SO
//          dbcs = true;
//          i++;  j++;
//          if (j == index)
//             return i;
//          }
//       else if (ebcdic[i] == EBCDIC_SI) { // SI
//          dbcs = false;
//          i++;  j++;
//          if (j == index)
//             return i;
//          }
//       else {                             // SBCS / DBCS
//          if (j == index)
//             return i;
//          if (dbcs)
//             i++;
//          i++;  j++;
//          }
//       }
//    // index beyond the end of the string
//    return i + (index - j);
// }

   /**
    * Truncate String <code>s</code> so that it fits within <code>textLimit</code>
    * bytes when converted to its source encoding.
    * Called e.g., for text-limit operations when the useSourceColumns setting
    * is <code>on</code>.
    *
    * @param s Unicode String
    * @param textLimit maximum number of bytes in the source string
    *
    * @return length of the text String <code>s</code>, optionally truncated so
    *         that it fits <code>textLimit</code> bytes in its source encoding
    */
   public int             sourceTruncate(String s, int textLimit)
   {
      return sourceTruncate(s, textLimit, _view.document());
   }

   /**
    * @see #sourceTruncate(String, int)
    */
   static int             sourceTruncate(String s, int textLimit, Document doc)
   {
      if (s == null || s.length() == 0 || textLimit <= 0)
         return 0;

      int i = 0;   // Unicode index/length
      int len = 0; // source-encoding (byte) index/length
      /*---------------------*/
      /*  1.- non-DBCS/MBCS  */
      /*---------------------*/
      if (!isSourceMbcs(doc)) {
         len = s.length();
         return (len > textLimit)? textLimit : len;
         }

      /*--------------------------*/
      /*  2.- SO/SIs EBCDIC DBCS  */
      /*--------------------------*/
      if (isSourceSosi(doc)) {
         byte[] ebcdic;
         try {
            ebcdic = getBytesSource(s, doc); // s.getBytes(getSourceEncoding(doc));
            }
         catch(java.io.UnsupportedEncodingException e) {     // bad encoding!?!?
            len = s.length();
            return (len > textLimit)? textLimit : len;
            }

         // fast skip SBCSs
         while (len < ebcdic.length && ebcdic[len] != EBCDIC_SO) {
            if (len >= textLimit)
               return len;
            len++;
            }
         if (len == ebcdic.length)
            return len;          // end of string (no SO/SIs), OK for textLimit.

         boolean dbcs = false;
         i = len;
         for (; len < ebcdic.length; len++) {
            if (ebcdic[len] == EBCDIC_SO) {       // SO
               if (textLimit < len+4)             // - room for at least a >DD<?
                  return i;
               dbcs = true;
               }
            else if (ebcdic[len] == EBCDIC_SI)    // SI
               dbcs = false;
            else if (dbcs) {                      // DBCS
               if (textLimit < len+3)             // - room for another DD<?
                  return i;
               len++;
               i++;
               }
            else {                                // SBCS
               if (textLimit <= len)
                  return i;
               i++;
               }
            }
         return i;
         }

      /*-----------------*/
      /*  3.- DBCS/MBCS  */
      /*-----------------*/
      len = 0;
      while (i < s.length()) {
         len += sourceLength(s.charAt(i), doc);
         if (len > textLimit)
            return i;
         i++;
         }

      return i;
   }

   /**
    * Add emulation SO/SIs to a Unicode String <code>s</code> originating from,
    * or targeted for, an EBCDIC DBCS character source encoding.  If the source
    * encoding is not EBCDIC DBCS, the original String is returned unchanged.
    *
    * @param s Unicode String
    */
   public String          addSourceSosi(String s)
   {
      if (s == null || s.length() == 0 || !isSourceSosi())
         return s;

      byte[] ebcdic;
      try {
         ebcdic = getBytesSource(s); // s.getBytes(getSourceEncoding());
         }
      catch(java.io.UnsupportedEncodingException e) {
         return s;                                    // encoding not supported.
         }

      int i = 0;
      // fast skip SBCSs
      while (i < ebcdic.length && ebcdic[i] != EBCDIC_SO) { i++; }
      if (i == ebcdic.length)
         return s;                                   // same string, no SO/SIs.

      char shiftOut = currentShiftOutCharacter();
      char shiftIn  = currentShiftInCharacter();
      int charIndex = i;
      boolean dbcs = false;
      StringBuffer sb = new StringBuffer(s);
      for (; i < ebcdic.length; i++, charIndex++) {
         if (ebcdic[i] == EBCDIC_SO) {               // SO
            sb.insert(charIndex, shiftOut);
            dbcs = true;
            }
         else if (ebcdic[i] == EBCDIC_SI) {          // SI
            sb.insert(charIndex, shiftIn);
            dbcs = false;
            }
         else if (dbcs)                              // SBCS / DBCS
            i++;
         }

      return sb.toString();
   }

   /**
    * Add emulation SO/SIs to a Unicode DisplayString <code>s</code> originating
    * from, or targeted for, an EBCDIC DBCS character source encoding.
    * If the source encoding is not EBCDIC DBCS, DisplayString is not changed.
    * The (ONE-based) s.sequenceNumbersPosition is updated if SO/SIs inserted
    * here push the sequence-numbers area to the right.
    *
    * @param s Unicode DisplayString, modified upon return
    */
   void                   addSourceSosi(DisplayString s)
   {
      if (s.text.length() == 0 || !isSourceSosi())
         return;

      byte[] ebcdic;
      try {
         ebcdic = getBytesSource(s.text); // s.text.getBytes(getSourceEncoding());
         }
      catch(java.io.UnsupportedEncodingException e) {
         return;                                      // encoding not supported.
         }

      int i = 0;
      // fast skip SBCSs
      while (i < ebcdic.length && ebcdic[i] != EBCDIC_SO) { i++; }
      if (i == ebcdic.length)
         return;                                      // same string, no SO/SIs.

      char shiftOut = currentShiftOutCharacter();
      char shiftIn  = currentShiftInCharacter();
      int charIndex = i;
      boolean dbcs = false;
      StringBuffer sb = new StringBuffer(s.text);
      for (; i < ebcdic.length; i++) {
         if (ebcdic[i] == EBCDIC_SO) {                // SO
            sb.insert(charIndex, shiftOut);
            dbcs = true;
            charIndex++;
            if (charIndex <= s.sequenceNumbersPosition)
               s.sequenceNumbersPosition++;           //  seq-nums area pushed
            }
         else if (ebcdic[i] == EBCDIC_SI) {           // SI
            sb.insert(charIndex, shiftIn);
            dbcs = false;
            charIndex++;
            if (charIndex <= s.sequenceNumbersPosition)
               s.sequenceNumbersPosition++;           //  seq-nums area pushed
            }
         else if (dbcs) {                             // SBCS / DBCS
            i++;
            charIndex++;
            }
         }

      s.text = sb.toString();
   }

   /**
    * Adjust a style String to its associated text String to which emulation
    * SO/SIs were added.  The SO/SI control characters will be assigned the style
    * of their applicable character:  the style of the following character for
    * SO, that of the previous character for SI.
    *
    * @param s style String
    * @param t text String (before emulation SO/SIs added)
    *
    * @see #addSourceSosi
    */
   public String          addSosiStyle(String s, String t)
   {
      if (s == null || t == null || !isSourceSosi())
         return s;

      byte[] ebcdic;
      try {
         ebcdic = getBytesSource(t); // t.getBytes(getSourceEncoding());
         }
      catch(java.io.UnsupportedEncodingException e) {
         return s;                                    // encoding not supported.
         }

      int i = 0;
      // fast skip SBCSs
      while (i < ebcdic.length && ebcdic[i] != EBCDIC_SO) { i++; }
      if (i == ebcdic.length)
         return s;                              // same style string, no SO/SIs.

      int charIndex = i;
      boolean dbcs = false;
      StringBuffer sb = new StringBuffer(s);

      try {    // try & don't die when the style string shorter than its text...
         for (; i < ebcdic.length; i++, charIndex++) {
            if (ebcdic[i] == EBCDIC_SO) {                // SO
               sb.insert(charIndex, sb.charAt(charIndex));
               dbcs = true;
               }
            else if (ebcdic[i] == EBCDIC_SI) {           // SI
               sb.insert(charIndex, sb.charAt(charIndex-1));
               dbcs = false;
               }
            else if (dbcs)                               // SBCS / DBCS
               i++;
            }
         }
      catch (Exception e) {}

      return sb.toString();
   }
}