//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CommandLine - the LPEX command line.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Layout;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;


final class CommandLine extends Composite implements KeyListener,
                                                     SelectionListener,
                                                     ModifyListener,
                                                     FocusListener,
                                                     LpexConstants
 {
  static final int
   MODE_COMMANDS         = 0,       // command line for entering commands
   MODE_FIND             = 1,       // line for "find" action
   MODE_FIND_AND_REPLACE = 2,       // line for "findAndReplace" action
   MODE_FIND_MARK        = 3,       // line for "findMark" action
   MODE_INPUT            = 4,       // line for "input" command
   MODE_SET_PARSER       = 5;       // line for "setParser" action
  private static final int MODES = 6;
  private static String _labelTextIds[] =
   {
    null,                           // MODE_COMMANDS
    MSG_COMMANDLINE_FIND,           // MODE_FIND
    MSG_COMMANDLINE_FIND,           // MODE_FIND_AND_REPLACE
    MSG_COMMANDLINE_FIND_MARK,      // MODE_FIND_MARK
    null,                           // MODE_INPUT
    MSG_COMMANDLINE_SET_PARSER,     // MODE_SET_PARSER
   };

  private Widget _inputFocusWidget; // any of our fields has key input focus?

  // an Event reused for notifying FocusListeners
  private Event _focusEvent = new Event();

  private LpexWindow   _lpexWindow;
  private boolean      _forceVisible;
  private int          _mode;
  private String       _savedText[];
  private View         _inputView;
  private String       _inputLabelText;
  private String       _inputCommand;
  private boolean      _ignoreItemStateChanged;
  private String       _parsers;

  private Label        _label;
  private int          _labelBorder = 5;
  private CommandEntry _commandEntry;

  private Composite    _findButtonsBox;
  private Button       _findNextButton;
  private Button       _findPrevButton;
  private Button       _findAllButton;

  private Composite    _replaceBox;
  private Label        _replaceLabel;
  private Text         _replaceEntry;
  private Button       _replaceNextButton;
  private Button       _replaceAllButton;

  private Button       _caseSensitiveCheckBox;
  private Button       _regularExpressionCheckBox;
  private Button       _wrapCheckBox;
  private Button       _selectFoundTextCheckBox;
  private Button       _blockCheckBox;
  private Button       _columnsCheckBox;
  private Text         _startColumnTextField;
  private Text         _endColumnTextField;
  private Composite    _findOptionsScrollPane;

  private static CommandStringList _commandList;
  private static CommandStringList _findList;


  private static CommandStringList commandList()
   {
    if (_commandList == null)
     {
      _commandList = new CommandStringList();
     }
    return _commandList;
   }

  private static CommandStringList findList()
   {
    if (_findList == null)
     {
      _findList = new CommandStringList();
     }
    return _findList;
   }

  /**
   * Constructor.
   */
  CommandLine(LpexWindow lpexWindow)
   {
    super(lpexWindow, 0);
    _lpexWindow = lpexWindow;

    setLayout(new CommandLineLayout());

    _mode = MODE_COMMANDS;
    _savedText = new String[MODES];
   }

  /**
   * Return the command line field with keyboard input focus, if any.
   *
   * <p>This is needed as of Eclipse driver 0.043, where the desktop part gets
   * a setFocus() request whenever any of its components gets input focus -
   * see com.ibm.lpex.alef.LpexAbstractTextEditor#setFocus();  if we process
   * this setFocus() when the user had clicked on the command line (and,
   * consequently, it has the keyboard input focus), we end up with some sort
   * of focus in both the TextWindow <b>and</b> the command line...
   *
   * <b>Also, Eclipse desktop actions (such as cut/copy/paste) received when on
   * the command line must be redirected to it.
   */
  Widget inputFocusWidget()
   {
    return _inputFocusWidget;
   }

// public boolean isFocusCycleRoot() {
//  return (_mode == MODE_FIND || _mode == MODE_FIND_AND_REPLACE);
// }

  /**
   * Label for the command entry line.
   */
  private Label label()
   {
    if (_label == null)
     {
      _label = new Label(this, SWT.NONE);
     }
    return _label;
   }

  private CommandEntry commandEntry()
   {
    if (_commandEntry == null)
     {
      _commandEntry = new CommandEntry();

      // swt: make the tab traversal on Shift+Tab key press go back to
      // "End column" (see org.eclipse.swt.widgets.Control#translateTraversal())
      _commandEntry.getControl().addListener(SWT.Traverse, new Listener()
       {
        public void handleEvent(Event event)
         {
          if (event.detail == SWT.TRAVERSE_TAB_PREVIOUS &&
              _endColumnTextField != null && _endColumnTextField.isVisible())
           {
            _endColumnTextField.setFocus();
            event.doit = false;
           }
         }
       });
     }
    return _commandEntry;
   }

  /**
   * Create a pushbutton.
   */
  private Button createButton(Composite parent, String msgId)
   {
    Button button = new Button(parent, SWT.PUSH | SWT.CENTER); // type+alignment
    button.setText(LpexResources.message(msgId));
    button.addKeyListener(this);       // if e.g., "Esc" while focus on a button
    button.addSelectionListener(this); // awt: addActionListener(this)
    button.addFocusListener(this);
    return button;
   }

  /**
   * Create the find pushbuttons box to the right of the Find entry field:
   *   Find |___________________|  "Next"  "Previous"  "All"
   */
  private Composite findButtonsBox()
   {
    if (_findButtonsBox == null)
     {
      _findButtonsBox = new Composite(this, SWT.NONE);

      GridLayout gridLayout = new GridLayout();
      _labelBorder = gridLayout.marginWidth;
      _findButtonsBox.setLayout(gridLayout);
      gridLayout.numColumns = 3;
      gridLayout.marginHeight = 1;
      _findButtonsBox.setLayoutData(new GridData(GridData.FILL_HORIZONTAL | // grab & align fill
                                                 GridData.VERTICAL_ALIGN_FILL));
      _findNextButton = createButton(_findButtonsBox, MSG_COMMANDLINE_NEXT);
      _findPrevButton = createButton(_findButtonsBox, MSG_COMMANDLINE_PREV);
      _findAllButton  = createButton(_findButtonsBox, MSG_COMMANDLINE_ALL);
     }
    return _findButtonsBox;
   }

  private Text replaceEntry()
   {
    if (_replaceEntry == null)
     {
      replaceBox();
     }
    return _replaceEntry;
   }

  /**
   * Create the replace box - the Replace label, entry field, and pushbuttons:
   *   Replace |___________________|  "Replace"  "Replace All"
   */
  private Composite replaceBox()
   {
    if (_replaceBox == null)
     {
      _replaceBox = new Composite(this, SWT.NONE);

      GridLayout gridLayout = new GridLayout();
      _replaceBox.setLayout(gridLayout);
      gridLayout.numColumns = 4;
      gridLayout.marginHeight = 0;
      _replaceBox.setLayoutData(new GridData(GridData.FILL_HORIZONTAL |
                                             GridData.VERTICAL_ALIGN_FILL));

      /*-------------------*/
      /*  "Replace" label  */
      /*-------------------*/
      _replaceLabel = new Label(_replaceBox, SWT.NONE);
      _replaceLabel.setText(LpexResources.message(MSG_COMMANDLINE_REPLACE));

      //DEBUG: test how layout handles a larger-than-life "Replace" label
      //_replaceLabel.setFont(new org.eclipse.swt.graphics.Font(getDisplay(),"Courier New",24,SWT.NORMAL));

      /*------------------------------------------------------------------*/
      /*  replace text - use an editable, one-line, bordered Text widget  */
      /*------------------------------------------------------------------*/
      _replaceEntry = new Text(_replaceBox, SWT.SINGLE | SWT.BORDER);
      _replaceEntry.addKeyListener(this);
      _replaceEntry.addFocusListener(this);
      // ensure it fills up all space between label and buttons
      _replaceEntry.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

      /*---------------*/
      /*  pushbuttons  */
      /*---------------*/
      _replaceNextButton = createButton(_replaceBox, MSG_COMMANDLINE_REPLACE_NEXT);
      _replaceAllButton = createButton(_replaceBox, MSG_COMMANDLINE_REPLACE_ALL);
     }
    return _replaceBox;
   }

  /**
   * Create a checkbox.
   */
  private Button createCheckBox(Composite parent, String msgId)
   {
    Button checkBox = new Button(parent, SWT.CHECK | SWT.CENTER); // type+alignment
    checkBox.setText(LpexResources.message(msgId));
    checkBox.addKeyListener(this);       // if e.g., "Esc" while focus on a checkbox
    checkBox.addFocusListener(this);
    checkBox.addSelectionListener(this); // awt: addItemListener(this)
    return checkBox;
   }

  private Button caseSensitiveCheckBox()
   {
    if (_caseSensitiveCheckBox == null)
     {
      findOptionsScrollPane();
     }
    return _caseSensitiveCheckBox;
   }

  private Button regularExpressionCheckBox()
   {
    if (_regularExpressionCheckBox == null)
     {
      findOptionsScrollPane();
     }
    return _regularExpressionCheckBox;
   }

  private Button wrapCheckBox()
   {
    if (_wrapCheckBox == null)
     {
      findOptionsScrollPane();
     }
    return _wrapCheckBox;
   }

  private Button selectFoundTextCheckBox()
   {
    if (_selectFoundTextCheckBox == null)
     {
      findOptionsScrollPane();
     }
    return _selectFoundTextCheckBox;
   }

  private Button blockCheckBox()
   {
    if (_blockCheckBox == null)
     {
      findOptionsScrollPane();
     }
    return _blockCheckBox;
   }

  private Button columnsCheckBox()
   {
    if (_columnsCheckBox == null)
     {
      findOptionsScrollPane();
     }
    return _columnsCheckBox;
   }

  private Text startColumnTextField()
   {
    if (_startColumnTextField == null)
     {
      findOptionsScrollPane();
     }
    return _startColumnTextField;
   }

  private Text endColumnTextField()
   {
    if (_endColumnTextField == null)
     {
      findOptionsScrollPane();
     }
    return _endColumnTextField;
   }

  /**
   * Create the find-options pane:
   *   "Case sensitive"  "Regex"  "Wrap"  "Select"  "Restrict to selection"
   *   "Restrict to columns"  "Start column"  "End column"
   */
  private Composite findOptionsScrollPane()
   {
    if (_findOptionsScrollPane == null)
     {
      _findOptionsScrollPane = new Group(this, SWT.NONE);
      GridLayout gridLayout = new GridLayout();
      _findOptionsScrollPane.setLayout(gridLayout);
      gridLayout.marginHeight = 0;
      gridLayout.verticalSpacing = 0;
      _findOptionsScrollPane.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING));

      // 1st box in panel, containing find-option checkboxes
      Composite box = new Composite(_findOptionsScrollPane, SWT.NONE);
      GridLayout gridLayout1 = new GridLayout();
      box.setLayout(gridLayout1);
      gridLayout1.numColumns = 5;
      gridLayout1.marginHeight = 0;
      gridLayout1.marginWidth = 0;
      box.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING |
                                     GridData.VERTICAL_ALIGN_FILL));

      _caseSensitiveCheckBox = createCheckBox(box, MSG_COMMANDLINE_CASE_SENSITIVE);
      _regularExpressionCheckBox = createCheckBox(box, MSG_COMMANDLINE_REGULAR_EXPRESSION);
      _wrapCheckBox = createCheckBox(box, MSG_COMMANDLINE_WRAP);
      _selectFoundTextCheckBox = createCheckBox(box, MSG_COMMANDLINE_SELECT_FOUND_TEXT);
      _blockCheckBox = createCheckBox(box, MSG_COMMANDLINE_RESTRICT_SEARCH_TO_SELECTION);

      // 2nd box in panel, containing more find-option fields
      Composite box1 = new Composite(_findOptionsScrollPane, SWT.NONE);
      GridLayout gridLayout2 = new GridLayout();
      box1.setLayout(gridLayout2);
      gridLayout2.numColumns = 5;
      gridLayout2.marginHeight = 0;
      gridLayout2.marginWidth = 0;
      box1.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_BEGINNING |
                                      GridData.VERTICAL_ALIGN_FILL));

      _columnsCheckBox = createCheckBox(box1, MSG_COMMANDLINE_RESTRICT_SEARCH_TO_COLUMNS);

      Label label1 = new Label(box1, SWT.NONE);
      label1.setText(LpexResources.message(MSG_COMMANDLINE_START_COLUMN));
      _startColumnTextField = new Text(box1, SWT.SINGLE | SWT.BORDER);
      _startColumnTextField.setTextLimit(3);

      // establish width of 3 digits for the start & end column fields
      GC gc = new GC(_startColumnTextField);
      int widthHint = 3 * gc.textExtent("9").x;
      gc.dispose();

      GridData gd = new GridData();
      gd.widthHint = widthHint;
      _startColumnTextField.setLayoutData(gd);
      _startColumnTextField.addKeyListener(this);
      _startColumnTextField.addModifyListener(this);
      _startColumnTextField.addFocusListener(this);

      Label label2 = new Label(box1, SWT.NONE);
      label2.setText(LpexResources.message(MSG_COMMANDLINE_END_COLUMN));
      _endColumnTextField = new Text(box1, SWT.SINGLE | SWT.BORDER);
      _endColumnTextField.setTextLimit(3);
      gd = new GridData();
      gd.widthHint = widthHint;
      _endColumnTextField.setLayoutData(gd);
      _endColumnTextField.addKeyListener(this);
      _endColumnTextField.addModifyListener(this);
      _endColumnTextField.addFocusListener(this);

      // swt: make the tab traversal on Tab key press go back to the Find entry
      // field (see org.eclipse.swt.widgets.Control#translateTraversal())
      _endColumnTextField.addListener(SWT.Traverse, new Listener()
       {
        public void handleEvent(Event event)
         {
          if (event.detail == SWT.TRAVERSE_TAB_NEXT)
           {
            commandEntry().requestFocus();
            event.doit = false;
           }
         }
       });
     }
    return _findOptionsScrollPane;
   }

  boolean forceVisible()
   {
    return _forceVisible;
   }

  void setForceVisible(boolean forceVisible)
   {
    _forceVisible = forceVisible;

    // AWT: it's enough for the CommandEntry() field to be set visible on the
    // next Screen refresh, whenever commandLine.forceVisible() indicates true,
    // and then do a re-layout()
    // SWT: the command line's CommandEntry()'s Text widget won't take focus
    // (upon being called through view.window.commandLineRequestFocus()), UNLESS
    // it is already visible - so we must do it now!  The ViHandler, for example
    // (see exCommand(char)), forces it visible & tries to give it focus
    if (forceVisible && !isVisible())
     {
      setVisible(true);
      _lpexWindow.layout();
      }
   }

  int getMode()
   {
    return _mode;
   }

  void setMode(int mode)
   {
    if (mode >= MODES || mode < 0)
     {
      return;
     }

    if (_inputView == null && mode == MODE_INPUT)
     {
      mode = MODE_COMMANDS;
     }

    if ((mode == MODE_FIND || mode == MODE_FIND_AND_REPLACE) &&
        _lpexWindow.view() != null)
     {
      View view = _lpexWindow.view()._view;
      view.preserveFindPosition();
     }

    // a new command-line mode is being set
    if (mode != _mode)
     {
      String text = commandEntry().getText();
      if (_mode == MODE_FIND || _mode == MODE_FIND_AND_REPLACE)
       {
        if (text != null && text.length() > 0 && findList()._current == null)
         {
          findList().add(text);
          findList()._current = (CommandString)findList().first();
         }
       }
      else
       {
        _savedText[_mode] = text;
       }

      _mode = mode;

      String labelText = "";
      if (mode == MODE_INPUT)
       {
        if (_inputLabelText != null)
         {
          labelText = _inputLabelText;
         }
       }
      else
       {
        String labelTextId = _labelTextIds[mode];
        if (labelTextId != null)
         {
          labelText = LpexResources.message(labelTextId);
         }
       }

      label().setText(labelText);
      if (_savedText[mode] != null)
       {
        commandEntry().changeText(_savedText[mode]);
        _savedText[mode] = null;
       }
      else
       {
        if (mode == MODE_FIND || mode == MODE_FIND_AND_REPLACE)
         {
          setFindOptions();
         }
        else
         {
          commandEntry().changeText("");
         }
       }

      if (mode == MODE_SET_PARSER)
       {
        _parsers = null;
        if (_lpexWindow.view() != null)
         {
          View view = _lpexWindow.view()._view;
          String parser = view.parsePendingList().parser();
          if (parser != null && parser.length() > 0)
           {
            commandEntry().changeText(parser);
           }
         }
       }

      commandEntry().selectAll();

      //awt: revalidate();
      layout();
      _lpexWindow.layout();
     }
   }

  void setInput(View view, String labelText, String text, String command)
   {
    _inputView = view;
    _inputLabelText = labelText;
    _savedText[MODE_INPUT] = text;
    _inputCommand = command;

    if (_mode == MODE_INPUT)
     {
      if (_inputView == null)
       {
        setMode(MODE_COMMANDS);
       }
      else
       {
        label().setText((_inputLabelText != null)? _inputLabelText : "");
        commandEntry().changeText(text);
        _savedText[MODE_INPUT] = null;
       }

      //awt: revalidate();
      layout();
      _lpexWindow.layout();
     }
   }

  void setCommandText(String commandText)
   {
    if (_mode == MODE_COMMANDS)
     {
      if (commandText == null)
       {
        commandText = "";
       }
      commandEntry().changeText(commandText);
      commandEntry().select(commandText.length(), commandText.length());
     }
    else
     {
      _savedText[MODE_COMMANDS] = commandText;
     }
   }

  public void requestFocus()
   {
    commandEntry().requestFocus();
   }

  // KeyListener - hooked to most fields in the command line
  // Notifications: keyPressed(), keyReleased()

  public void keyPressed(KeyEvent e)
   {
      // "Esc" when inside any command line field returns us to the edit window
    if (e.character == SWT.ESC)
     {
      _lpexWindow.textWindowRequestFocus();
      //e.consume();
     }
    else
     {
      if (_lpexWindow.view() != null)
       {
        // give the view's action handler a chance to process it for those
        // actions that are defined in the scope of the command line
        _lpexWindow.view()._view.actionHandler().doKeyEvent(e);
       }
     }
   }

  public void keyReleased(KeyEvent e) {}

  /**
   * Set the find-options buttons, checkboxes, and text fields.
   * Called when mode == MODE_FIND or MODE_FIND_AND_REPLACE.
   */
  private void setFindOptions()
   {
    View view = _lpexWindow.view()._view;

    boolean asis              = FindTextCommand.asisParameter().currentValue(view);
    boolean regularExpression = FindTextCommand.regularExpressionParameter().currentValue(view);
    boolean wrap              = FindTextCommand.wrapParameter().currentValue(view);
    boolean mark              = FindTextCommand.markParameter().currentValue(view);
    boolean block             = FindTextCommand.blockParameter().currentValue(view);
    boolean columns           = FindTextCommand.columnsParameter().currentValue(view);
    int     startColumn       = FindTextCommand.startColumnParameter().currentValue(view);
    int     endColumn         = FindTextCommand.endColumnParameter().currentValue(view);
    String  replaceText       = FindTextCommand.replaceTextParameter().currentValue(view);
    String  findText          = FindTextCommand.findTextParameter().currentValue(view);

    // NB ensure the find buttons and then the replace box are created
    // before others - so they are also Tab-traversed in this order
    findButtonsBox();
    replaceBox();

    _ignoreItemStateChanged = true;
    caseSensitiveCheckBox().setSelection(asis);
    regularExpressionCheckBox().setSelection(regularExpression);
    wrapCheckBox().setSelection(wrap);
    selectFoundTextCheckBox().setSelection(mark);
    blockCheckBox().setSelection(block);
    columnsCheckBox().setSelection(columns);
    startColumnTextField().setText(String.valueOf(startColumn));
    endColumnTextField().setText(String.valueOf(endColumn));
    _ignoreItemStateChanged = false;

    if (_mode == MODE_FIND_AND_REPLACE)
     {
      replaceEntry().setText((replaceText != null)? replaceText : "");
     }
    commandEntry().changeText(findText);
   }

  private boolean setFindText()
   {
    String findText = commandEntry().getText();
    if (findText.length() > 0)
     {
      View view = _lpexWindow.view()._view;
      FindTextCommand.FindTextParameter findTextParameter = FindTextCommand.findTextParameter();
      if (view == null || findTextParameter.value(view) == null)
       {
        findTextParameter.setDefaultValue(findText);
       }
      else
       {
        findTextParameter.setValue(view, findText);
       }

      boolean asis = caseSensitiveCheckBox().getSelection();
      FindTextCommand.AsisParameter asisParameter = FindTextCommand.asisParameter();
      if (view == null || asisParameter.value(view) == Parameter.DEFAULT)
       {
        asisParameter.setDefaultValue(asis? Parameter.ON : Parameter.OFF);
       }
      else
       {
        asisParameter.setValue(view, asis? Parameter.ON : Parameter.OFF);
       }

      boolean regularExpression = regularExpressionCheckBox().getSelection();
      FindTextCommand.RegularExpressionParameter regularExpressionParameter = FindTextCommand.regularExpressionParameter();
      if (view == null || regularExpressionParameter.value(view) == Parameter.DEFAULT)
       {
        regularExpressionParameter.setDefaultValue(regularExpression? Parameter.ON : Parameter.OFF);
       }
      else
       {
        regularExpressionParameter.setValue(view, regularExpression? Parameter.ON : Parameter.OFF);
       }

      boolean wrap = wrapCheckBox().getSelection();
      FindTextCommand.WrapParameter wrapParameter = FindTextCommand.wrapParameter();
      if (view == null || wrapParameter.value(view) == Parameter.DEFAULT)
       {
        wrapParameter.setDefaultValue(wrap? Parameter.ON : Parameter.OFF);
       }
      else
       {
        wrapParameter.setValue(view, wrap? Parameter.ON : Parameter.OFF);
       }

      boolean mark = selectFoundTextCheckBox().getSelection();
      FindTextCommand.MarkParameter markParameter = FindTextCommand.markParameter();
      if (view == null || markParameter.value(view) == Parameter.DEFAULT)
       {
        markParameter.setDefaultValue(mark? Parameter.ON : Parameter.OFF);
       }
      else
       {
        markParameter.setValue(view, mark? Parameter.ON : Parameter.OFF);
       }

      boolean block = blockCheckBox().getSelection();
      FindTextCommand.BlockParameter blockParameter = FindTextCommand.blockParameter();
      if (view == null || blockParameter.value(view) == Parameter.DEFAULT)
       {
        blockParameter.setDefaultValue(block? Parameter.ON : Parameter.OFF);
       }
      else
       {
        blockParameter.setValue(view, block? Parameter.ON : Parameter.OFF);
       }

      boolean columns = columnsCheckBox().getSelection();
      FindTextCommand.ColumnsParameter columnsParameter = FindTextCommand.columnsParameter();
      if (view == null || columnsParameter.value(view) == Parameter.DEFAULT)
       {
        columnsParameter.setDefaultValue(columns? Parameter.ON : Parameter.OFF);
       }
      else
       {
        columnsParameter.setValue(view, columns? Parameter.ON : Parameter.OFF);
       }

      int startColumn = 1;
      try
       {
        startColumn = Integer.parseInt(startColumnTextField().getText());
       }
      catch(NumberFormatException e) {}
      FindTextCommand.StartColumnParameter startColumnParameter = FindTextCommand.startColumnParameter();
      if (startColumnParameter.useDefaultValue(view))
       {
        startColumnParameter.setDefaultValue(startColumn, false);
       }
      else
       {
        startColumnParameter.setValue(view, startColumn, false);
       }

      int endColumn = 80;
      try
       {
        endColumn = Integer.parseInt(endColumnTextField().getText());
       }
      catch(NumberFormatException e) {}
      FindTextCommand.EndColumnParameter endColumnParameter = FindTextCommand.endColumnParameter();
      if (endColumnParameter.useDefaultValue(view))
       {
        endColumnParameter.setDefaultValue(endColumn, false);
       }
      else
       {
        endColumnParameter.setValue(view, endColumn, false);
       }

      if (_mode == MODE_FIND_AND_REPLACE)
       {
        String replaceText = replaceEntry().getText();
        FindTextCommand.ReplaceTextParameter replaceTextParameter =
           FindTextCommand.replaceTextParameter();
        if (view == null || replaceTextParameter.value(view) == null)
         {
          replaceTextParameter.setDefaultValue(replaceText);
         }
        else
         {
          replaceTextParameter.setValue(view, replaceText);
         }
       }
      return true;
     }

    return false;
   }

  private void findText(String findCommand)
   {
    View view = _lpexWindow.view()._view;
    if (view != null && setFindText())
     {
      view.beginUserAction();

      FindTextCommand.doCommand(view, findCommand);
      if (findList()._current == null)
       {
        findList().add(commandEntry().getText());
        findList()._current = (CommandString)findList().first();
       }
      view.preserveFindPosition();

      view.endUserAction();
      Document.screenShow();
     }
   }

  private void liveFindText()
   {
    View view = _lpexWindow.view()._view;
    if (view != null)
     {
      view.beginUserAction();
      view.restoreFindPosition();
      if (setFindText())
       {
        FindTextCommand.doCommand(view, "checkStart noBeep");
       }
      else
       {
        view.documentPosition().setEmphasisLength(0);
       }
      view.endUserAction();
      Document.screenShow();
     }
   }

  /**
   * SelectionListener - which we registered for the buttons & checkboxes.
   */
  public void widgetDefaultSelected(SelectionEvent e)
   {
    actionPerformed(e);
   }
  public void widgetSelected(SelectionEvent e)
   {
    actionPerformed(e);
   }

  private void actionPerformed(SelectionEvent e)
   {
    // 1.- see if one of the buttons was pushed
    if (e.widget == _findNextButton)
     {
      findText("");
     }
    else if (e.widget == _findPrevButton)
     {
      findText("up");
     }
    else if (e.widget == _findAllButton)
     {
      findText("all");
     }
    else if (e.widget == _replaceNextButton)
     {
      findText("checkStart replace");
     }
    else if (e.widget == _replaceAllButton)
     {
      findText("replace all");
     }

    // 2.- otherwise, one of the checkboxes was selected
    else if (!_ignoreItemStateChanged)
     {
      liveFindText();
     }
   }

  /**
   * ModifyListener - which we registered for the start & end column
   * restrict-search fields.
   */
  public void modifyText(ModifyEvent e)
   {
    if (!_ignoreItemStateChanged && columnsCheckBox().getSelection())
     {
      liveFindText();
     }
   }

  /*
   * FocusListener for the commandline fields.
   *
   * <p>As of Eclipse driver 0.043, the desktop part gets a setFocus()
   * request whenever any of its components gets input focus - see
   * com.ibm.lpex.alef.LpexAbstractTextEditor#setFocus();  if we process
   * this setFocus() when the user clicked on the command line (and,
   * consequently, it has the keyboard input focus), we end up with some sort
   * of focus in both the TextWindow *and* the command line...
   *
   * <p>Also, Eclipse desktop actions (such as cut/copy/paste) received when
   * on the command line must be redirected to it, so we must keep track of the
   * active control inside the command line.  The enable state of these
   * actions must also be updated when the command line receives focus and, in
   * general, one should be able to register a working FocusListener on the
   * command line Composite...
   *
   * <p>Prior to Eclipse driver 0.043, we had to generate LpexWindow FocusListener
   * events for any Control inside the CommandLine, in order for the LpexWindow
   * (as parent of these controls, and as the desktop part's Composite) to announce
   * it gained focus and, consequently, the desktop part to be activated (i.e.,
   * activate all the LPEX editor actions/menus/etc. contributions, including the
   * Delete action in lieu of the "Delete" key which was consumed by the desktop).
   */
  public void focusGained(FocusEvent e)
   {
    _inputFocusWidget = e.widget;

    // keep track of last widget with focus (see LpexWindow)
    _lpexWindow._lastFocusWidget = _inputFocusWidget;

    //_lpexWindow.notifyFocusGained(); //to inform LpexWindow FocusListeners

    // inform CommandLine FocusListeners
    notifyListeners(SWT.FocusIn, _focusEvent);
   }

  public void focusLost(FocusEvent e)
   {
    _inputFocusWidget = null;
    //_lpexWindow.notifyFocusLost(); //to inform LpexWindow FocusListeners

    // inform CommandLine FocusListeners
    notifyListeners(SWT.FocusOut, _focusEvent);
   }


  /**
   * Layout manager for the CommandLine.
   * swt: Layout is an abstract class to *extend*, unlike awt's LayoutManager
   * interface *implemented* by the CommandLine...
   */
  final class CommandLineLayout extends Layout
   {
    /**
     * Compute the size of the CommandLine.
     */
    protected Point computeSize(Composite parent,
                                int wHint, int hHint, boolean flushCache)
     {
      Point labelPreferredSize = label().computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);
      Point commandEntryPreferredSize = commandEntry().computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);
      int height = (labelPreferredSize.y > commandEntryPreferredSize.y)?
                    labelPreferredSize.y : commandEntryPreferredSize.y;
      int width = labelPreferredSize.x + _labelBorder*2 +
                  commandEntryPreferredSize.x;

      if (_mode == MODE_FIND || _mode == MODE_FIND_AND_REPLACE)
       {
        Point buttonsPreferredSize = findButtonsBox().computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);
        if (buttonsPreferredSize.y > height)
         {
          height = buttonsPreferredSize.y;
         }
        width += buttonsPreferredSize.x;
        Point findOptionsScrollPanePreferredSize = findOptionsScrollPane().computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);
        height += findOptionsScrollPanePreferredSize.y;
        if (findOptionsScrollPanePreferredSize.x > width)
         {
          width = findOptionsScrollPanePreferredSize.x;
         }

        if (_mode == MODE_FIND_AND_REPLACE)
         {
          Point replaceBoxPreferredSize =
             replaceBox().computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);
          height += replaceBoxPreferredSize.y;
          if (replaceBoxPreferredSize.x > width)
           {
            width = replaceBoxPreferredSize.x;
           }
         }
       }

      return new Point(width, height);
     }

    /**
     * Layout the children of the CommandLine composite.
     * awt: public void layoutContainer(Container parent)
     */
    protected void layout(Composite parent, boolean flushCache)
     {
      Point labelSize = label().computeSize(SWT.DEFAULT,SWT.DEFAULT);
      int labelBorder = _labelBorder;

      // awt: labelSize = 0,0 if != MODE_FIND, but in swt: = 64,14
      if (label().getText().length() == 0)
       {
        labelSize.x = 0;
        labelBorder = 0;
       }

      int commandEntryHeight = commandEntry().computeSize(SWT.DEFAULT,SWT.DEFAULT).y;
      Rectangle parentRect = parent.getClientArea();
      int commandRowHeight = (labelSize.y > commandEntryHeight)?
                              labelSize.y : commandEntryHeight;
      int replaceRowHeight = 0;
      int findOptionsRowHeight = 0;
      int findButtonsWidth;

      if (_mode == MODE_FIND || _mode == MODE_FIND_AND_REPLACE)
       {
        Point findButtonsSize = findButtonsBox().computeSize(SWT.DEFAULT,SWT.DEFAULT);
        if (commandRowHeight < findButtonsSize.y)
         {
          commandRowHeight = findButtonsSize.y;
         }
        findButtonsWidth = findButtonsSize.x;
        findButtonsBox().setVisible(true);

        if (_mode == MODE_FIND_AND_REPLACE) // find and replace
         {
          replaceRowHeight = replaceBox().computeSize(SWT.DEFAULT,SWT.DEFAULT).y;
          replaceBox().setVisible(true);
         }
        else // just find
         {
          if (_replaceBox != null)
           {
            _replaceBox.setVisible(false);
           }
         }

        findOptionsRowHeight = findOptionsScrollPane().computeSize(SWT.DEFAULT,SWT.DEFAULT).y;
        findOptionsScrollPane().setVisible(true);
       }
      else
       {
        findButtonsWidth = 0;
        if (_findButtonsBox != null)
         {
          _findButtonsBox.setVisible(false);
         }
        if (_replaceBox != null)
         {
          _replaceBox.setVisible(false);
         }
        if (_findOptionsScrollPane != null)
         {
          _findOptionsScrollPane.setVisible(false);
         }
       }

      int commandEntryWidth = parentRect.width -
                              labelBorder*2 - labelSize.x -
                              findButtonsWidth;
      label().setBounds(labelBorder,
                        (commandRowHeight - labelSize.y) / 2,
                        labelSize.x,
                        commandRowHeight);
      commandEntry().setBounds(labelBorder*2 + labelSize.x,
                               (commandRowHeight - commandEntryHeight) / 2,
                               commandEntryWidth,
                               commandEntryHeight);
      if (_findButtonsBox != null)
       {
        _findButtonsBox.setBounds(labelBorder*2 + labelSize.x + commandEntryWidth,
                                  0,
                                  findButtonsWidth,
                                  commandRowHeight);
       }

      if (_replaceBox != null)
       {
        _replaceBox.setBounds(0,
                              commandRowHeight,
                              parentRect.width,
                              replaceRowHeight);
       }
      if (_findOptionsScrollPane != null)
       {
        _findOptionsScrollPane.setBounds(0,
                                         commandRowHeight + replaceRowHeight,
                                         parentRect.width,
                                         findOptionsRowHeight);
       }
     }
   }


  /**
   * AWT: extends JTextField
   * SWT: Text is a final class, so "we have" one rather than "we are" one...
   */
  final class CommandEntry implements KeyListener, ModifyListener
  {
   private Text _text;

   CommandEntry()
    {
     // use an editable, one-line, bordered Text widget
     _text = new Text(CommandLine.this, SWT.SINGLE | SWT.BORDER);

     _text.addKeyListener(this);
     _text.addKeyListener(CommandLine.this);

     _text.addModifyListener(this);
     _text.addFocusListener(CommandLine.this);
    }

   // retrieve the underlying Control
   Control getControl()
    {
     return _text;
    }

   String getText()
    {
     return _text.getText();
    }

   void setText(String t)
    {
     _text.setText((t != null)? t : "");
    }

   void select(int start, int end)
    {
     _text.setSelection(start, end);
    }

   void selectAll()
    {
     _text.selectAll();
    }

   void requestFocus()
    {
     _text.setFocus();
    }

   Point computeSize(int wHint, int hHint, boolean changed)
    {
     return _text.computeSize(wHint, hHint, changed);
    }

   Point computeSize(int wHint, int hHint)
    {
     return _text.computeSize(wHint, hHint);
    }

   void setBounds(int x, int y, int width, int height)
    {
     _text.setBounds(x, y, width, height);
    }

   //awt: public void keyTyped(KeyEvent e) {}

   public void keyPressed(KeyEvent e)
    {
     /*=============*/
     /*  Enter key  */
     /*=============*/
     if (e.character == SWT.CR)
      {
       if (_mode == MODE_FIND || _mode == MODE_FIND_AND_REPLACE)
        {
         findText("");
        }

       else if (_lpexWindow.view() != null)
        {
         View view = _lpexWindow.view()._view;
         String commandString = getText();
         if (commandString.length() > 0)
          {
           view.beginUserAction();
           switch (_mode)
            {
             case MODE_COMMANDS:
              {
               if (view.vi())
                {
                 view.viHandler().doCommand(commandString);
                 changeText("");
                 _lpexWindow.textWindowRequestFocus();
                }
               else if (view.commandHandler().doCommand(commandString))
                {
                 if (commandList()._current == null)
                  {
                   commandList().add(commandString);
                  }
                 if (_mode == MODE_COMMANDS)
                  {
                   changeText("");
                  }
                }
               else
                {
                 selectAll();
                }
               break;
              }

             case MODE_FIND_MARK:
              {
               LocateCommand.doCommand(view, "emphasis mark " + commandString);
               if (CommandHandler._status == null)
                {
                 _lpexWindow.textWindowRequestFocus();
                }
               else
                {
                 selectAll();
                }
               break;
              }

             case MODE_SET_PARSER:
              {
               UpdateProfileCommand.ParserParameter p =
                  UpdateProfileCommand.ParserParameter.getParameter();
               p.setValue(view, commandString);
               UpdateProfileCommand.doCommand(view, "");
               _lpexWindow.textWindowRequestFocus();
               break;
              }

             case MODE_INPUT:
              {
               if (_inputView == null ||
                   (_inputView.commandHandler().doCommand(_inputCommand + commandString) &&
                    CommandHandler._status == null))
                {
                 _lpexWindow.textWindowRequestFocus();
                }
               else
                {
                 selectAll();
                }
               break;
              }
            }
           view.endUserAction();
           Document.screenShow();
          }

         else if (_mode == MODE_SET_PARSER)
          {
           UpdateProfileCommand.ParserParameter p =
              UpdateProfileCommand.ParserParameter.getParameter();
           p.setValue(view, "");
           UpdateProfileCommand.doCommand(view, "");
           _lpexWindow.textWindowRequestFocus();
          }
        }
       //e.consume();
      }

     /*========================*/
     /*  Up / Down arrow keys  */
     /*========================*/
     else if (e.keyCode == SWT.ARROW_UP ||  //awt: KeyEvent.VK_UP
              e.keyCode == SWT.ARROW_DOWN)  //awt: KeyEvent.VK_DOWN
      {
       if (_lpexWindow.view() != null)
        {
         View view = _lpexWindow.view()._view;
         if ((_mode == MODE_COMMANDS && !view.vi()) ||
             _mode == MODE_FIND || _mode == MODE_FIND_AND_REPLACE)
          {
           CommandStringList list =
              (_mode == MODE_COMMANDS)? commandList() : findList();
           String text = getText();
           if (_mode == MODE_FIND || _mode == MODE_FIND_AND_REPLACE)
            {
             if (text != null && text.length() > 0 && findList()._current == null)
              {
               findList().add(text);
               findList()._current = (CommandString)findList().first();
              }
            }
           if (e.keyCode == SWT.ARROW_UP)
            {
             String commandString = getText();
             if (list._current == null)
              {
               list._current = (CommandString)list.first();
              }
             else if (commandString.equals(list._current.commandString()) &&
                      list._current.next() != null)
              {
               list._current = (CommandString)list._current.next();
              }
            }
           else
            {
             if (list._current != null && list._current.prev() != null)
              {
               list._current = (CommandString)list._current.prev();
              }
            }
           if (list._current != null)
            {
             changeText(list._current.commandString());
             selectAll();
            }
          }

         else if (_mode == MODE_FIND_MARK)
          {
           String markName = getText();
           MarkList.Mark mark = null;
           if (markName.length() > 0)
            {
             mark = view.markList().find(markName);
            }
           if (e.keyCode == SWT.ARROW_UP)
            {
             if (mark == null)
              {
               mark = view.markList().firstNamed();
              }
             else
              {
               mark = view.markList().nextNamed(mark);
              }
            }
           else
            {
             if (mark != null)
              {
               mark = view.markList().prevNamed(mark);
              }
            }
           if (mark != null)
            {
             changeText(mark.name());
            }
          }

         else if (_mode == MODE_SET_PARSER)
          {
           String parserName = getText();
           if (_parsers == null)
            {
             UpdateProfileCommand.ParsersParameter p =
                UpdateProfileCommand.ParsersParameter.getParameter();
             _parsers = p.queryCurrent(view, null);
            }
           if (_parsers != null)
            {
             LpexStringTokenizer st = new LpexStringTokenizer(_parsers);
             String previousParser = null;
             String nextParser = null;
             while (st.hasMoreTokens())
              {
               String parser = st.nextToken();
               if (parser.equals(parserName))
                {
                 if (st.hasMoreTokens())
                  {
                   nextParser = st.nextToken();
                  }
                 break;
                }
               previousParser = parser;
              }
             if (e.keyCode == SWT.ARROW_UP)
              {
               parserName = previousParser;
              }
             else
              {
               parserName = nextParser;
              }
             if (parserName != null)
              {
               changeText(parserName);
               selectAll();
              }
            }
          }
        }
       //e.consume();
      }
    }

   public void keyReleased(KeyEvent e) {}

   /**
    * ModifyListener - which we registered for the command entry text field.
    */
   public void modifyText(ModifyEvent e)
    {
     textChanged();
    }

   private void textChanged()
    {
     if (_lpexWindow.view() != null)
      {
       if (_mode == MODE_COMMANDS ||
           _mode == MODE_FIND || _mode == MODE_FIND_AND_REPLACE)
        {
         String text = getText();
         CommandStringList list = (_mode == MODE_COMMANDS)? commandList() : findList();
         if (text.length() > 0 && list._current != null &&
             !list._current.commandString().equals(getText()))
          {
           list._current = null;
          }
         if (_mode == MODE_FIND || _mode == MODE_FIND_AND_REPLACE)
          {
           liveFindText();
          }
        }
      }
    }

   private void changeText(String newText)
    {
     _text.removeModifyListener(this);
     setText((newText != null)? newText : "");
     _text.addModifyListener(this);
     textChanged();
    }
  }
 }


final class CommandString extends ListNode
{
 private String _commandString;

 CommandString(String commandString)
  {
   _commandString = commandString;
  }

 String commandString()
  {
   return _commandString;
  }
}


final class CommandStringList extends List
{
 CommandString _current;
 private final static int MAXIMUM_COMMANDS = 100;
 private int _count;

 void add(String string)
  {
   while (_count > MAXIMUM_COMMANDS)
    {
     if (last() == _current)
      {
       _current = null;
      }

     remove(last());
     _count--;
    }

   _count++;
   addAfter(null, new CommandString(string));
  }
}