//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// InsertCommand - handle the insert command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>insert</b> command.
 */
final class InsertCommand
{
 static boolean doCommand(View view, String parameters)
 {
  if (view != null)
   {
    Element element = new Element(view.document(), parameters);
    view.insertElement(element);
   }
  return true;
 }
}