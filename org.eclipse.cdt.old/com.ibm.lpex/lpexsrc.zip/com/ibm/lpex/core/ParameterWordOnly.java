//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterWordOnly - base class for managing simple word parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Base, abstract class for managing simple word parameters (without install,
 * default, and current settings).
 * To implement word parameters with install, default, and current values,
 * use ParameterWordDefault.
 */
abstract class ParameterWordOnly extends Parameter
{
 ParameterWordOnly(String name)
 {
  super(name);
 }

 /**
  * Accepts up to one parameter, and passes it on to method setValue().
  */
 boolean set(View view, String qualifier, String parameters)
 {
  String value = null;

  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    value = st.nextToken();
    if (st.hasMoreTokens())
     {
      return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name(qualifier));
     }
   }

  return setValue(view, qualifier, value);
 }

 abstract boolean setValue(View view, String qualifier, String value);
}