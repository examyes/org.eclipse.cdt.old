//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexCommonParser - abstract class for document parsers.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.Properties;
import java.util.ResourceBundle;


// NOTE:
// Parsers shipped with the editor keep their message resources in the editor's
// Resources.properties.  This simplifies the NL translation process.
// Class LpexResources is used to access these messages.


/**
 * LpexCommonParser is a base, abstract class for document parsers.
 * It adds several services to the regular LpexParser interface, simplifying
 * document-parser development, and provides methods for a common look-and-feel
 * to the parsers extending it.
 * Certain methods in the LpexParser interface are not used by parsers extending
 * LpexCommonParser.
 *
 * <p>A document parser based on LpexCommonParser will be defined such:
 * <pre>
 *    public class <i>MyLpexParser</i> extends LpexCommonParser </pre></p>
 *
 * A  parser is associated with one particular view of a document.  Different
 * views of the same document may be handled by different parsers.  The parser
 * must have a constructor whose parameter is the view of the document.  This
 * constructor must first call the constructor of its superclass
 * (LpexCommonParser), as shown below:
 * <pre>
 *    public <i>MyLpexParser</i>(LpexView lpexView)
 *    {
 *       super(lpexView); // this sets LpexCommonParser's protected variable <b>view</b>
 *       // rest of <i>MyLpexParser</i>'s constructor code...
 *    } </pre>
 *
 * Editor actions modified by parsers extending LpexCommonParser:
 * <ul>
 *   <li><b>blockMarkWord</b> to select a token
 *   <li><b>indentText</b> to indent the text on the current line
 *   <li><b>newLine, openLine, splitLine</b> to indent the cursor (current
 *       document location) in the new element.
 * </ul>
 *
 * Actions and assigned keys added by LpexCommonParser parsers:
 * <ul>
 *   <li><b>match</b> (Ctrl+M) to match parentheses, braces, square brackets,
 *       and angle brackets
 *   <li><b>proto</b> (Ctrl+R) to expand templates defined in the parser
 *       properties.
 * </ul>
 *
 * Keys already defined (e.g., by the active base profile) to an action
 * different from <b>nullAction</b> are not redefined in here.
 */
public abstract class LpexCommonParser implements LpexParser, LpexConstants
{
   // default help mapping file
   private static Properties helpPages;
   private static boolean properties_loaded;

   /**
    * The view with which this document parser is associated.
    * @see #lpexView
    */
   protected LpexView view;

   // embedded-messages handling
   private ParserMessage _messages;
   private ParserMessage _lastMessage;
   private DeleteRange   _deleteRanges;
   private boolean       _errorMessages;
   private long          _classMessage;

   private boolean _autoIndent;

   private boolean _TRACING;


   /**
    * Common element class reserved for error messages.  Error and informational
    * messages displayed (as show elements) in the edit view will be assigned
    * this element class.
    *
    * <p>It is defined as <code>"Message"</code>.  The parser should not define
    * an element class with this name.</p>
    */
   public static final String CLASS_MESSAGE = "Message";

   /**
    * Common style reserved for parser messages.
    * Defined as <code>'M'</code>.  The parser should not define this style for
    * tokens.
    */
   public static final char STYLE_MESSAGE = 'M';

   /**
    * @see #getLanguage
    */
   public static final String
      LANGUAGE_CCPP    = "CPP",     // C and C++
      LANGUAGE_CICS    = "CICS",    // Customer Information Control System
      LANGUAGE_CL      = "CL",      // Control Language (OS/400)
      LANGUAGE_COBOL   = "COBOL",   // Common Business Oriented Language
      LANGUAGE_DDS     = "DDS",     // Data Description Specifications
      LANGUAGE_FORTRAN = "Fortran", // Formula Translation
      LANGUAGE_HLASM   = "HLASM",   // High Level Assembler
      LANGUAGE_HTML    = "HTML",    // Hypertext Markup Language
      LANGUAGE_JAVA    = "Java",    // Java
      LANGUAGE_JCL     = "JCL",     // Job Control Language
      LANGUAGE_PLI     = "PLI",     // Programming Language I
      LANGUAGE_REXX    = "REXX",    // Restructured Extended Executor Language
      LANGUAGE_RPG     = "RPG",     // Report Program Generator
      LANGUAGE_SQL     = "SQL",     // Structured Query Language
      LANGUAGE_XMI     = "XMI",     // XML Metadata Interchange
      LANGUAGE_XML     = "XML",     // eXtensible Markup Language
      LANGUAGE_XSL     = "XSL";     // eXtensible Stylesheet Language

   /**
    * Key for action <b>proto</b> in an empty document.
    * Defined as <code>"proto.%EMPTY%"</code>.
    * @see #proto
    */
   public static final String PROTOKEY_EMPTY = "proto.%EMPTY%";

   /**
    * Common background color.  Defined as <code>"255 255 255"</code> (white).
    * A document parser should normally define its style attributes with this
    * background color (like the <code>ATTRIBUTES_xxx</code> defined in here),
    * and use LpexPaletteAttributes to convert them to the active palette.
    *
    * @see #setStyle
    * @see LpexPaletteAttributes
    */
   public static final String BACKGROUND_COLOR = "255 255 255";
   /**
    * Common default style attributes.
    * @see #setStyle
    */
   public static final String ATTRIBUTES_DEFAULT = "0 0 0 255 255 255";
   /**
    * Style attributes for comment/remark tokens.
    * @see #setStyle
    */
   public static final String ATTRIBUTES_COMMENT = "0 128 128 255 255 255";
   /**
    * Style attributes for errors.
    * @see #setStyle
    */
   public static final String ATTRIBUTES_ERROR = "255 255 255 255 0 0";
   /**
    * Style attributes for language keywords.
    * @see #setStyle
    */
   public static final String ATTRIBUTES_KEYWORD = "0 0 255 255 255 255";
   /**
    * Additional style attributes for language keywords.
    * Can be user, for example, for language-extension keywords.
    * @see #setStyle
    */
   public static final String ATTRIBUTES_KEYWORD1 = "0 0 200 255 255 255";
   /**
    * Style attributes for library-related tokens.
    * These attributes are used for tokens related to a library or some other
    * base language-support to a common colour and font emphasis.  This style
    * is used by the C/C++ document parser for C library functions;  it could
    * also be used, as an example, by the Java document parser for classes
    * provided in the <code>java.lang</code> package.
    * @see #setStyle
    */
   public static final String ATTRIBUTES_LIBRARY = "0 0 128 255 255 255";
   /**
    * Style attributes for numerals.
    * Other numeric constants, such as hexadecimal strings in REXX, and
    * character literals in Java and C/C++, also use this style.
    * @see #setStyle
    */
   public static final String ATTRIBUTES_NUMERAL = "128 0 0 255 255 255";
   /**
    * Style attributes for quoted strings.
    * These attributes are used for string literals in the C/C++ and Java
    * document parsers.
    * @see #setStyle
    */
   public static final String ATTRIBUTES_STRING = "128 0 128 255 255 255";
   /**
    * Style attributes for compiler directives.
    * These attributes are used by the C/C++ document parser for C preprocessor
    * directives such as "#include".
    * @see #setStyle
    */
   public static final String ATTRIBUTES_DIRECTIVE = "0 0 255 255 255 255 underline";
   /**
    * Style attributes for text which does not constitute part of the source
    * proper.
    * These attributes are used by the JCL document parser for the "//" statement
    * prefix, and by the PL/I document parser for text located outside the margins.
    * @see #setStyle
    */
   public static final String ATTRIBUTES_NONSOURCE = "192 192 192 255 255 255";

   /**
    * Successful return code from a lexer's token processing.
    */
   public static final int LEXER_RC_OK = 0x00000000;
   /**
    * EOF flag in the return code from a lexer's token processing.
    * This flag indicates that EOF was returned by the active character input
    * stream.  Flag LEXER_RC_MORE may indicate that the lexer is asking
    * for more input to complete a parse unit.
    * @see #LEXER_RC_MORE
    */
   public static final int LEXER_RC_EOF = 0x00000001;
   /**
    * Return code from a lexer's token processing indicating the end
    * of its job.  For example, this flag will be returned by the SQL lexer
    * processing embedded-SQL statements in Java, at the end of the SQL
    * executable clause.  The host document parser must switch to the host
    * language's lexer (the Java lexer in this example).
    */
   public static final int LEXER_RC_END = 0x00000002;
   /**
    * More-input flag in the return code from a lexer's token processing.
    * This flag indicates that the lexer is asking for more input to complete
    * a parse unit.
    * This flag must be raised when EOF is encountered, to inform the host
    * document parser know that the parse range must be extended if possible.
    * @see #LEXER_RC_EOF
    */
   public static final int LEXER_RC_MORE = 0x00000004;


   /**
    * Total parse.  Parse the entire document.
    */
   public abstract void parseAll ();

   /**
    * Incremental parse.  Parse change(s) to a document.
    *
    * @param element the element whose committed change triggered the parse,
    *                or the element that precedes / follows a deleted block.
    *                The parser may identify other neighbouring elements that
    *                will have to be reparsed as a unit.
    */
   public abstract void parseElement (int element);


   /**
    * LpexCommonParser constructor.
    * This must be called first in the constructor of the document parser that
    * extends LpexCommonParser, for example:
    * <pre>
    *    public <i>MyLpexParser</i>(LpexView lpexView) {
    *       <b>super(lpexView);</b>
    *       // rest of <i>MyLpexParser</i>'s constructor code...
    *    } </pre>
    * It sets protected variable <code>view</code> to the LpexView associated
    * with this parser, and initializes support for the common services
    * provided.
    *
    * @param lpexView the document view associated with this parser
    * @see #view
    */
   protected LpexCommonParser(LpexView lpexView)
   {
      view = lpexView;

      /*--------------------------------*/
      /*  set up message-related stuff  */
      /*--------------------------------*/
      String background = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert("255 0 255 255 255 255",
                                                        BACKGROUND_COLOR,
                                                        background);
      StyleAttributes styleAttributes = StyleAttributes.getStyleAttributes(attributes);
      view._view.styleAttributesList().set(STYLE_MESSAGE, styleAttributes);
      _classMessage = view.registerClass(CLASS_MESSAGE);

      /*----------------------------------------------------------------*/
      /*  establish whether to display error messages & do auto indent  */
      /*----------------------------------------------------------------*/
      String temp = getProperty("errorMessages");
      _errorMessages = temp == null || !temp.equals("off");
      temp = getProperty("autoIndent");
      _autoIndent = temp == null || !temp.equals("off");

      /*----------------------------------------------------------------------------*/
      /*  redefine actions blockMarkWord, newLine, openLine, splitLine, indentText  */
      /*----------------------------------------------------------------------------*/
      view.defineAction("blockMarkWord", new LpexAction() {     // "blockMarkWord"
         public void doAction(LpexView view)
         { blockMarkWord(); }

         public boolean available(LpexView view)
         { return view.defaultActionAvailable(ACTION_BLOCK_MARK_WORD); }
         });

      view.defineAction("newLine", new LpexAction() {           // "newLine"
         public void doAction(LpexView view)
         { newLine(); }

         public boolean available(LpexView view)
         { return view.defaultActionAvailable(ACTION_NEW_LINE); }
         });

      view.defineAction("openLine", new LpexAction() {          // "openLine"
         public void doAction(LpexView view)
         { openLine(); }

         public boolean available(LpexView view)
         { return view.defaultActionAvailable(ACTION_OPEN_LINE); }
         });

      view.defineAction("splitLine", new LpexAction() {         // "splitLine"
         public void doAction(LpexView view)
         { splitLine(); }

         public boolean available(LpexView view)
         { return view.defaultActionAvailable(ACTION_SPLIT_LINE); }
         });

      view.defineAction("indentText", new LpexAction() {        // "indentText"
         public void doAction(LpexView view)
         { int currentPosition = view.queryInt("displayPosition");
           if (currentPosition > 0) {
              int currentElement = view.currentElement();
              indentText(currentElement, textIndent(currentElement));
              view.doDefaultCommand("set displayPosition " + currentPosition);
              }
         }

         public boolean available(LpexView view)
         { return true; }
         });


      /*------------------------*/
      /*  define other actions  */
      /*------------------------*/
      LpexAction lpexAction = new LpexAction() {                // "proto"
         public void doAction(LpexView view)
         { proto(); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("proto", lpexAction);

      if (!view.keyAssigned("c-r.t"))
         view._view.actionHandler().defineKeyAction("c-r.t", "proto");
      if (!view.keyAssigned("c-r.c"))
         view._view.actionHandler().defineKeyAction("c-r.c", "proto");

      lpexAction = new LpexAction() {                           // "match"
         public void doAction(LpexView view)
         { match(); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("match", lpexAction);

      if (!view.keyAssigned("c-m.t"))
         view._view.actionHandler().defineKeyAction("c-m.t", "match");
      if (!view.keyAssigned("c-m.c"))
         view._view.actionHandler().defineKeyAction("c-m.c", "match");

      // define debug action "TRACING" - toggle tracing
      view.defineAction("TRACING", new LpexAction() {           // "TRACING"
         public void doAction(LpexView view)
         { _TRACING = !_TRACING; }

         public boolean available(LpexView view)
         { return true; }
         });

      /*---------------------------*/
      /*  insert popup View items  */
      /*---------------------------*/
      String viewItems   = getPopupViewItems();
      String parserItems = getPopupParserItems();
      if (viewItems != null || parserItems != null) {
         String popup = PopupParameter.getParameter().currentValue(view._view);
         if (popup == null)
            popup = "";
         StringBuffer buffer = new StringBuffer(popup);

         if (viewItems != null) {
            int i = popup.indexOf(MSG_POPUP_EXCLUDESELECTION); // location on popup
            if (i < 0)
               i = popup.length();
            buffer.insert(i, " endSubmenu ");
            buffer.insert(i, viewItems);
            buffer.insert(i, ' ');
            buffer.insert(i, MSG_POPUP_FILTERVIEW);
            buffer.insert(i, " beginSubmenu ");
            }

         if (parserItems != null) {
            buffer.append(" separator ");                   // at end of popup
            buffer.append(parserItems);
            }

         view._view.setPopup(buffer.toString());
         }
   }

   /**
    * Return the document view with which this parser is associated.
    */
   public final LpexView lpexView()
   {
      return view;
   }

   /**
    * N/A - Method in the LpexParser interface;  a document parser extending
    * LpexCommonParser only implements, if needed, <b>terminateParser()</b>.
    *
    * @see #terminateParser
    */
   public final void    resetParser()
   {
      if (_TRACING)
         System.out.println("LpexCommonParser#resetParser()");

      terminateParser();

      _messages = null;     // in case the garbage collector is confused/slow...
      _lastMessage = null;
      _deleteRanges = null;
   }

   /**
    * N/A - Method in the LpexParser interface;  a document parser extending
    * LpexCommonParser only implements <b>parseAll()</b>.
    *
    * @see #parseAll
    */
   public final void    totalParse()
   {
      if (_TRACING)
         System.out.println("LpexCommonParser#totalParse()");

      parseAll();
      displayMessages();
   }

   /**
    * N/A - Method in the LpexParser interface;  a document parser extending
    * LpexCommonParser only implements <b>parseElement()</b>.
    *
    * @see #parseElement
    */
   public final void    parse(int element)
   {
      if (_TRACING)
         System.out.println("LpexCommonParser#parse("+element+")");
      if (element == 0)
         return;
      parseElement(element);
      displayMessages();
   }

   /**
    * Retrieve the name of the HTML help panel that the parser identifies
    * as appropriate for the currently selected token.
    */
   public String        getHelpPage()
   {
      String helpPage = null;
      if (_TRACING)
         System.out.println("LpexCommonParser#getHelpPage()");
      loadProperties();
      if (helpPages != null) {
         String token = getToken(view.documentLocation());
         if (token != null)
            helpPage = helpPages.getProperty(token);
         }
      return helpPage;
   }

   static private void  loadProperties()
   {
      if (!properties_loaded) {
         helpPages = HelpCommand.loadHelpMap(HELP_DEFAULT_PROPERTIES_FILE);
         // whether the load succeeded or not, there is no point
         // in trying again until the editor is restarted...
         properties_loaded = true;
         }
   }

   /**
    * Retrieve a string identifying the language or file type supported by the
    * parser.  This string is used by getProperty() and setProperty() as a
    * prefix to retrieve/set parser properties in LPEX's profile, as a prefix
    * for parser messages in LPEX's resources, and can be used by a command
    * (such as a code navigator) to identify the language handled by the parser.
    *
    * <p>The document parser extending LpexCommonParser may override this method
    * to return the language it supports.  Strings for the most common programming
    * languages are defined in LpexCommonParser.
    * The implementation of this method provided by the LpexCommonParser class
    * returns <code>null</code>.</p>
    *
    * @see #getProperty
    * @see #setProperty
    * @see #LANGUAGE_CCPP
    * @see #LANGUAGE_CICS
    * @see #LANGUAGE_CL
    * @see #LANGUAGE_COBOL
    * @see #LANGUAGE_DDS
    * @see #LANGUAGE_FORTRAN
    * @see #LANGUAGE_HLASM
    * @see #LANGUAGE_HTML
    * @see #LANGUAGE_JAVA
    * @see #LANGUAGE_JCL
    * @see #LANGUAGE_PLI
    * @see #LANGUAGE_REXX
    * @see #LANGUAGE_RPG
    * @see #LANGUAGE_SQL
    * @see #LANGUAGE_XMI
    * @see #LANGUAGE_XML
    * @see #LANGUAGE_XSL
    */
   public String        getLanguage()
   {
      return null;
   }

   /**
    * Retrieve a string identifying the language segment at the specified
    * location.  In mixed-content documents, this may differ from the main
    * language of the document.
    * This string may be used by utilities that must behave according to the
    * active language segment, such as a code-assist presenter.
    *
    * <p>The document parser extending LpexCommonParser may override this method
    * to return the particular language segment.  Strings for the most common
    * programming languages are defined in LpexCommonParser.
    * The implementation of this method provided by the LpexCommonParser class
    * returns {@link #getLanguage()}.</p>
    *
    * @see #getLanguage
    */
   public String        getLanguage(LpexDocumentLocation loc)
   {
      return getLanguage();
   }

   /**
    * Get the parser's profile.
    * A document parser may, as part of its package, define a profile to hold
    * its default properties.  For example, the Java document parser holds its
    * default settings in Profile.properties, which is instantiated like this:
    * <pre>
    *    private static ResourceBundle resource =
    *       ResourceBundle.getBundle("com.ibm.lpex.java.Profile"); </pre>
    *
    * The document parser extending LpexCommonParser should override this method
    * to return its own resource bundle.  The implementation of this method
    * provided by the LpexCommonParser class does nothing, except return null.
    *
    * @see #getProperty
    */
   public ResourceBundle getProfile()
   {
      return null;
   }

   /**
    * Retrieve a parser property.  Default properties defined in the parser
    * profile are those common to LpexCommonParser parsers:
    * <b>tokenHighlight</b>, <b>autoIndent</b>, and <b>errorMessages</b>, and
    * parser-specific properties, such as keyword expansions for the
    * <b>proto</b> action.
    *
    * <p>The implementation of this method provided by the LpexCommonParser
    * class searches the key (prefixed with the parser's language) in the LPEX
    * read/write profile.  If not found, it searches in the parser's (default)
    * properties profile, if any.  If the property is not found, it returns
    * <code>null</code>.</p>
    *
    * @param key property name, e.g., "proto.doc" for the expansion of
    *            keyword "doc" with the <b>proto</b> action
    * @see #getLanguage
    * @see #getProfile
    */
   public String        getProperty(String key)
   {
      String lang = getLanguage();                   // look it up in LPEX first
      if (lang != null) {
         String property = Profile.getString(lang + '.' + key);
         if (property != null)
            return property;
         }

      ResourceBundle profile = getProfile();         //  & in parser's profile
      if (profile != null) {
         try {
            return profile.getString(key);
            }
         catch (Exception e) {}
         }
      return null;
   }

   /**
    * Set/update/restore a parser property.
    *
    * <p>The implementation of this method provided by the LpexCommonParser class
    * sets the key (prefixed with the parser's language) and the property in
    * the editor (read/write) profile.</p>
    *
    * @param key property name, e.g., "proto.doc" for the expansion of
    *            keyword "doc"
    * @param string property value;  if <code>null</code> or an empty string,
    *               the key is removed, and the parser's default property value,
    *               if any, will be returned by a subsequent getProperty()
    * @see #getLanguage
    * @see #getProperty
    */
   public void          setProperty(String key, String string)
   {
      String lang = getLanguage();                   // look it up in LPEX first
      if (lang != null)
         Profile.putString(lang + '.' + key, string);
   }

   /**
    * Retrieve parser's items for the popup "Filter view" submenu.
    * The document parser extending LpexCommonParser should override this method
    * to return its own filtered-view menu items and associated actions.
    *
    * <p>For example, the Java document parser returns a string which
    * consists of three menu items (defined here by their keys in LPEX's
    * Resources.properties) and their corresponding action names:
    * <pre>
    *    "Java.popup.methods methods " +
    *    "Java.popup.outline outline " +
    *    MSG_POPUP_ERRORS + " errors" </pre></p>
    *
    * <p>The implementation of this method provided by the LpexCommonParser
    * class does nothing, except return null.</p>
    *
    * @see #getPopupParserItems
    */
   public String        getPopupViewItems()
   {
      return null;
   }

   /**
    * Retrieve parser's items for the popup menu.
    * A document parser extending LpexCommonParser may override this method
    * to return its own specific menu items and associated actions.
    *
    * <p>For example, the Java document parser returns a string which consists
    * of two menu items (defined here by imbedded strings) and their
    * corresponding action names:
    * <pre>
    *    "\"Document\" doc " +
    *    "\"Trace\" trace" </pre></p>
    *
    * <p>The implementation of this method provided by the LpexCommonParser
    * class does nothing, except return null.</p>
    *
    * @see #getPopupViewItems
    */
   public String        getPopupParserItems()
   {
      return null;
   }

   /**
    * Remove all of the parser specifics from the document view.
    * Note that classes, style attributes, commands, and actions are already
    * automatically removed by the editor.
    *
    * <p>The document parser extending LpexCommonParser may override this method
    * to do any additional cleanups.  For example, it should remove any listeners
    * that it has added.
    * The implementation of this method provided by the LpexCommonParser class
    * does nothing.</p>
    */
   public void          terminateParser() {}

   /**
    * Define parser's style attributes.
    *
    * <p>The document parser extending LpexCommonParser may override this method
    * to set the display attributes of its styles for token highlighting,
    * or to clear them (<code>ATTRIBUTES_DEFAULT</code>) when token highlighting
    * is off.
    *
    * During initialization, the parser calls this method with
    * <code>true</code>, unless the parser property <b>tokenHighlight</b> is
    * <code>off</code>;  subsequent changes for the view
    * should be effected through an explicit call to this method.</p>
    *
    * <p>The implementation of this method provided by the LpexCommonParser
    * class does nothing.</p>
    *
    * @param colours <code>true</code> = token highlighting,
    *                <code>false</code> = no token highlighting
    * @see #setStyle
    */
   public void          setStyleAttributes(boolean colours) {}

   /**
    * Specify whether the parser should display imbedded error messages.
    * When the document parser is initialized, if the property <b>errorMessages</b>
    * is <code>off</code> imbedded errors from the parser are not displayed;
    * subsequent changes in a particular view should be effected through an
    * explicit call to this method.
    *
    * @param display <code>true</code> = display imbedded error messages
    * @see #addMessage(int,String)
    * @see #addMessage(int,String,long)
    * @see #addMessage(int,String,long,char)
    */
   public void          setErrorMessages(boolean display)
   {
      _errorMessages = display;
   }

   /**
    * Enable or disable automatic indenting.
    * When the document parser is initialized, automatic indenting is enabled
    * unless the parser property <b>autoIndent</b> is set to <code>off</code>;
    * subsequent changes in the view must be effected through an explicit
    * call to this method.
    *
    * @param indent <code>true</code> = enable automatic indenting
    *
    * @see #cursorIndent
    * @see #textIndent
    * @see #getAutoIndent
    */
   public void          setAutoIndent(boolean indent)
   {
      _autoIndent = indent;
   }

   /**
    * Retrieve the status of automatic indenting.
    *
    * @return  <code>true</code> = automatic indenting is enabled,
    *          <code>false</code> = automatic indenting is disabled
    *
    * @see #cursorIndent
    * @see #textIndent
    * @see #setAutoIndent
    */
   public boolean       getAutoIndent()
   {
      return _autoIndent;
   }

   /**
    * Match tokens.  Implements the <b>match</b> action.
    */
   private void         match()
   {
      view.doDefaultCommand("parse");                   // ensure file is parsed
      LpexDocumentLocation loc = view.documentLocation(); // get cursor location

      LpexDocumentLocation match = matchToken(loc);     // try parser constructs
      if (match == null)
         match = LpexMatch.match(view, loc, true);      // then try parentheses

      if (match != null &&                              // select matched area
          (match.element != loc.element || match.position != loc.position)) {
         view.doDefaultCommand("block clear");
         view.doDefaultCommand(loc, "block set character");
         view.doDefaultCommand(match, "block set character");
         }
   }

   /**
    * Expand a prototype word at the current document location (cursor) as per
    * the template defined in the active document parser.
    * The cursor is set to the position of the first '?' encountered in the
    * expansion, if any.
    *
    * <p>The expansion string is obtained through a call to getProperty(),
    * with the prototype word found at the cursor (and delimited by white space
    * or token-delimiter characters), prefixed by <code>"proto."</code>, as the
    * key argument.
    * For example, if the cursor is located on the word "if" in a Java-language
    * document, the value for key <code>"proto.if"</code> in the JavaParser
    * properties is used for the expansion.
    * If any argument substitution is needed in the expansion string, it should
    * be carried out by the parser extending LpexCommonParser.</p>
    *
    * <p>When the document is empty, key PROTOKEY_EMPTY is used, if an
    * expansion for it is defined, to set up an initial text to serve as the
    * basic structure for the document.</p>
    *
    * @see #getProperty
    * @see #PROTOKEY_EMPTY
    * @see #isTokenDelimiter
    */
   public void          proto()
   {
      if (view._view.readonly())
         return;                       // readonly doc, cannot expand.

      LpexDocumentLocation loc = view.documentLocation();
      if (view.show(loc.element))
         return;                       // we are on a SHOW line, expand nothing.


      String key;                      // proto key to look for
      boolean keyInDoc;                // key is in the document / else dummy key
      int s, e;                        // key-in-document start & end offsets
      String text = view.elementText(loc.element);

      /*-------------------------------------------*/
      /*  (a) empty document - use PROTOKEY_EMPTY  */
      /*-------------------------------------------*/
      if (view.elements() == 1 && text.trim().length() == 0) {
         key = PROTOKEY_EMPTY;
         keyInDoc = false;
         s = e = 0;
         }

      /*----------------------------------------------*/
      /*  (b) use word at/around cursor as proto key  */
      /*----------------------------------------------*/
      else {
         if (text.length() == 0)
            return;                      // on an empty line, nothing to expand.

         s = loc.position - 1;
         if (s >= text.length())         // if beyond the end of text
            s = text.length() - 1;       //  move back for the search
         e = s;
         // back once if cursor just after a keyword [inserted] before token delimiter
         if (s >= 0 && isTokenDelimiter(text.charAt(s)))
            s--;
         while (s >= 0 && (text.charAt(s)==' ' || text.charAt(s)=='\t'))
            s--;                         // go back over white space

         if (s < 0) {                    // no word at left, search right
            s = e;
            while (s < text.length() && (text.charAt(s)==' ' || text.charAt(s)=='\t'))
               s++;
            if (s >= text.length())
               return;                   // no word anywhere on the line.
            e = s;
            }
         else {
            e = s + 1;
            while (s >= 0 && text.charAt(s)!=' ' && text.charAt(s)!='\t' &&
                   !isTokenDelimiter(text.charAt(s))) // go left, to start of the word
               s--;
            s++;
            }

         while (e < text.length() && text.charAt(e)!=' ' && text.charAt(e)!='\t' &&
                !isTokenDelimiter(text.charAt(e)))    // go right, to end of the word
            e++;

         key = "proto." + text.substring(s, e);
         keyInDoc = true;
         }

      /*------------------------------------------*/
      /*  check if key is a recognized prototype  */
      /*------------------------------------------*/
      String p = getProperty(key);           // key defined in the parser?
      if (p == null || p.length() == 0)
         p = Profile.getString(key);         // anything defined in LPEX itself?
      if (p == null || p.length() == 0)
         return;                             // word is not a defined prototype.

      /*--------------------*/
      /*  insert expansion  */
      /*--------------------*/
      // after first line, should use indentText() for the following lines! *as*
      boolean origLine = true;            // working on original prototype line?
      int j = -1;                                  // cursor not yet positioned
      loc.position = ++s;                          // ONE-based start of keyword

      view.doDefaultCommand("undo check");         // take a checkpoint first
      if (keyInDoc)                                // delete the key in document
         view.doDefaultCommand(loc, "deleteText " + text.length());

      // original line may have TABs, get *display* column pos for the next ones
      int s1 = view.queryInt("displayPosition", loc);

      for (int i = p.indexOf("\n"); ; i = p.indexOf("\n")) { // insert expansion
         String pp = p.substring(0, (i==-1)? p.length() : i);
         loc.position = origLine? s : s1;
         // found first '?' in the expansion segment
         if (j == -1  && (j=pp.indexOf('?')) != -1) {
            pp = pp.substring(0,j) + (view._view.insertMode()? "":" ") +
                 pp.substring(j+1);
            view.doDefaultCommand(loc, "insertText " + pp);
            // position the cursor on ex-'?'
            view.jump(loc.element, j + (origLine? s : s1));
            }
         else
            view.doDefaultCommand(loc, "insertText " + pp);
         if (i == -1)
            break;
         view.doDefaultCommand(loc, "insert");           // insert a new element
         p = p.substring(i + 1);
         origLine = false;
         }

      if (e < text.length())      // join back any text following prototype word
         view.doDefaultCommand(loc, "insertText "+text.substring(e));
   }

   /**
    * Get the token at a certain document location.
    * This method can be used for language-sensitive help (LSH).
    *
    * <p>Returns <code>null</code> if the document location is beyond the
    * element text, is on white space, or <code>loc</code> is incorrect.
    * Token search is restricted to one element.  Styles are assumed to be
    * set correctly (i.e., no parse is pending for this element).</p>
    *
    * <p>A token is a string of a consistent style, and delimited by the
    * boundaries of the text element, white space, and characters defined by
    * isTokenDelimiter().</p>
    *
    * <p>If a block has been selected and the location (cursor) points to the
    * start or end of this block, then the selected text will be returned as the
    * token.  This overrides the normal definition of a token stated above.</p>
    *
    * @param loc document location
    * @see #isTokenDelimiter
    */
   public String        getToken(LpexDocumentLocation loc)
   {
      if (loc == null)
         return null;

      // verify that the block is in the current view
      if ((Block.view() != null) && (Block.view().lpexView() == view)) {
         // if the position is at the start or end then it is assumed
         // that the text was just selected;  the selection is deemed
         // intentional for the purpose for which a token is necessary,
         // so it should be used as the token
         if (loc.position == Block.bottomPosition() ||
             loc.position == Block.topPosition())
            return Block.selectedText();
         }

      LpexDocumentLocation s = tokenBegin(loc);
      if (s == null)
         return null;

      LpexDocumentLocation e = tokenEnd(loc);
      return view.elementText(loc.element).substring(s.position-1, e.position);
   }

   /**
    * Overrides the default editor action <b>blockMarkWord</b>.
    * It (re)sets the block over the token at the current document location.
    */
   protected void       blockMarkWord()
   {
      view.doDefaultCommand("block clear");
      LpexDocumentLocation loc = view.documentLocation();
      LpexDocumentLocation s = tokenBegin(loc);
      if (s == null)
         return;
      LpexDocumentLocation e = tokenEnd(loc);

      String type = view.query("current.block.defaultType");
      if (type.equals("element"))
         type = "stream";
      if (type.equals("stream"))
         e.position++;

      view.jump(e);
      view.doDefaultCommand(s, "block set " + type);
      view.doDefaultCommand("block set");
   }

   /**
    * Get the start of a token at a certain document location.
    * Returns <code>null</code> if the document location is beyond the element
    * text, is on white space, or <code>loc</code> is incorrect.
    *
    * <p>Token search is restricted to one element.  Styles are assumed to be
    * set correctly (i.e., no parse is pending for this element).</p>
    *
    * @param loc document location
    * @see #tokenEnd
    * @see #getToken
    */
   protected LpexDocumentLocation tokenBegin(LpexDocumentLocation loc)
   {
      if (loc == null)
         return null;
      String text = view.elementText(loc.element);
      if (text == null)
         return null;
      int s = loc.position - 1;
      if (s >= text.length() || text.charAt(s) == ' ' || text.charAt(s) == '\t')
         return null;                           // beyond text / on white space.
      if (isTokenDelimiter(text.charAt(s)))
         return new LpexDocumentLocation(loc);  // token = delimiter.
         // don't "return loc;" directly, our caller does just an assignment!

      String style = view.elementStyle(loc.element);
      char tokenStyle = (style.length() > s)? style.charAt(s) : '!';

      while (--s >= 0) {
         char ch = text.charAt(s);
         if (ch == ' ' || ch == '\t' || isTokenDelimiter(ch) ||
             (tokenStyle != ((style.length() > s)? style.charAt(s) : '!')))
            break;
         }

      return new LpexDocumentLocation(loc.element, s+2);
   }

   /**
    * Get the end of a token at a certain document location.
    * Returns <code>null</code> if the document location is beyond the element
    * text, is white space, or <code>loc</code> is incorrect.
    * Token search is restricted to one element.  Styles are assumed to be
    * set correctly (i.e., no parse is pending for this element).
    *
    * @param loc document location
    * @see #tokenBegin
    * @see #getToken
    */
   protected LpexDocumentLocation tokenEnd(LpexDocumentLocation loc)
   {
      if (loc == null)
         return null;
      String text = view.elementText(loc.element);
      if (text == null)
         return null;
      int s = loc.position - 1;
      if (s >= text.length() || text.charAt(s) == ' ' || text.charAt(s) == '\t')
         return null;                           // beyond text / on white space.
      if (isTokenDelimiter(text.charAt(s)))
         return new LpexDocumentLocation(loc);  // token = delimiter.

      String style = view.elementStyle(loc.element);
      char tokenStyle = (style.length() > s)? style.charAt(s) : '!';

      int e = s + 1;
      for (; e < text.length(); e++) {
         char ch = text.charAt(e);
         if (ch == ' ' || ch == '\t' || isTokenDelimiter(ch) ||
             (tokenStyle != ((style.length() > e)? style.charAt(e) : '!')))
            break;
         }

      return new LpexDocumentLocation(loc.element, e);
   }

   /**
    * Match the token found at a certain document location.
    * A document parser extending LpexCommonParser may override this method
    * to return a matching token to the one found at <code>loc</code>, such
    * as the "end" token matching a "do".
    * This is used by the <b>match</b> action, with <code>loc</code> being
    * the current document location.
    *
    * <p>If no matching token is returned by this method, LpexCommonParser
    * tries to match any parenthesis, brace, square bracket, or angle bracket
    * found at <code>loc</code>.  A successful match will result in the
    * character-selection of the text bounded by the two tokens.</p>
    *
    * <p>The implementation of this method provided by the LpexCommonParser
    * class does nothing, except return <code>null</code>.</p>
    *
    * @param loc document location
    */
   protected LpexDocumentLocation matchToken(LpexDocumentLocation loc)
   {
      return null;
   }

   /**
    * Query whether the specified character is a token delimiter.
    * While a punctuation character, for example, will have a style different
    * from the token adjacent to it, this method is used to identify one token
    * inside a string of tokens of the same style which may appear in the source
    * without any other separators, e.g.,
    * <pre>
    *   ... (name<b>());</b> </pre>
    * in a Java-language source.
    *
    * This method is also used to identify the keyword to expand for the
    * <b>proto</b> action.
    *
    * <p>The implementation of this method provided by the LpexCommonParser
    * class returns <code>false</code>.  The parser should override this to
    * return its particular token delimiters.</p>
    *
    * @see #getToken
    */
   public boolean       isTokenDelimiter(char ch)
   {
      return false;
   }

   /**
    * Get the indent display column of the cursor in the element.
    * LpexCommonParser redefines the editor actions <b>newLine</b> and
    * <b>openLine</b>, which are the default actions of Shift+Enter and
    * Ctrl+Enter.  In newLine, after the cursor was moved to the next visible
    * element in the view, if any, this method is called to set its optimal
    * column.  In openLine, the cursor on the new empty element is positioned
    * on the column returned by this method.
    *
    * <p>The implementation of this method provided by the LpexCommonParser
    * class returns the display column of the beginning of text in this element,
    * if any, or otherwise the column corresponding to the beginning of text in
    * the preceding non-blank element, if any, or otherwise column 1;
    * 1 is also returned if automatic indentation is disabled.
    * Show elements are ignored.</p>
    *
    * <p>A document parser may override this method, to return a value
    * appropriate to its auto-indentation scheme.</p>
    *
    * @param element the element for cursor indentation
    * @return optimal display cursor column
    * @see #setAutoIndent
    */
   public int           cursorIndent(int element)
   {
      // (a) no auto indent - return column 1
      if (!_autoIndent)
         return 1;

      // (b) blank element - get indent of any non-blank element above it
      String p = view.elementText(element);       // get element's text
      if (p == null || (p.trim()).length() == 0) {
         for (;;) {
            if (--element < 1)
               return 1;                          // no non-blank element found.

            if (!view.show(element)) {            // ignore show lines
               p = view.elementText(element);
               if ((p.trim()).length() > 0)
                  break; // found nonblank line - fall through below...
               }
            }
         }

      // (c) element has text - skip to the first non-blank
      int i;
      for (i = 0;  p.charAt(i) == ' ' || p.charAt(i) == '\t';  i++) {}

      // text cursor column -> display cursor column
      return view.queryInt("displayPosition",
                           new LpexDocumentLocation(element, i+1));
   }

   /**
    * Get the indent display column for the text in the specified element.
    * LpexCommonParser redefines the action <b>splitLine</b>, which is the
    * default action of the Enter key.  In splitLine, after a new element was
    * created for the split text, this method is called to obtain the optimal
    * column for positioning its text and cursor;  if the new element is empty,
    * cursorIndent() is called instead, to just position the cursor.
    *
    * <p>The implementation of this method provided by the LpexCommonParser
    * class returns the display column corresponding to the beginning of text
    * in the preceding non-blank element, if any, or otherwise column 1.
    * Show elements are ignored.</p>
    *
    * <p>A document parser may override this method, to return a value
    * appropriate to its auto-indentation scheme.</p>
    *
    * @param element the element for text indentation
    * @return optimal display column for text and cursor
    * @see #setAutoIndent
    */
   public int           textIndent(int element)
   {
      // *as* a parser might want to indent in term of TABs!!

      String p;                                   // an element's text
      for (;;) {
         if (--element < 1)
            return 1;                             // no non-blank element found.

         if (!view.show(element)) {               // ignore show lines
            p = view.elementText(element);
            if ((p.trim()).length() > 0)          // found non-blank line
               break; // fall through below...
            }
         }//end "for"

      int i;
      for (i = 0;  p.charAt(i) == ' ' || p.charAt(i) == '\t';  i++) {}

      // text cursor column -> display cursor column
      return view.queryInt("displayPosition", new LpexDocumentLocation(element, i+1));
   }

   /**
    * Overrides the default editor action <b>newLine</b>.  It positions the
    * cursor (current document location) in the new element to the display
    * column returned by cursorIndent().
    *
    * @see #cursorIndent
    */
   protected void       newLine()
   {
      int ep0 = view.currentElement();            // get the current element
      view.doDefaultAction(ACTION_NEW_LINE);      // try default "newLine"

      int ep = view.currentElement();             // get the new current element
      // if cursor moved down indeed, set it to indent *display* column
      if (ep != ep0)
         view.doDefaultCommand("set displayPosition " + cursorIndent(ep));
   }

   /**
    * Overrides the default editor action <b>openLine</b>.  It positions the
    * cursor (current document location) in the new element to the display
    * column returned by cursorIndent().
    *
    * @see #cursorIndent
    */
   protected void       openLine()
   {
      view.doDefaultAction(ACTION_OPEN_LINE);     // do default "openLine"
      int ep = view.currentElement();             // get the new current element
      view.jump(ep, cursorIndent(ep));            // set cursor to indent value
   }

   /**
    * Overrides the default editor action <b>splitLine</b>.  It positions the
    * text and the cursor (current document location) in the new element to the
    * display column returned by textIndent(), or 1 if automatic indenting is off.
    *
    * <p>An incremental parse is triggered in here to ensure text tokenization
    * is current.</p>
    *
    * @see #textIndent
    */
   protected void       splitLine()
   {
      int ep0 = view.currentElement();            // original current element
      view.doDefaultAction(ACTION_SPLIT_LINE);    // do default "splitLine"
      view.doDefaultCommand("parse");             // ensure file is parsed
      int ep  = view.currentElement();            // the new current element

      // When view-filtering (e.g., Ctrl+G) is in effect, the cursor may slide,
      // after a splitLine, over to a further-away visible section on the screen
      // (as the new element with the 2nd part of the split text is invisible
      // until parsed!) (e.g., the next method signature) - don't AI in those
      // situations!?  Try to force the cursor back to ep0+1 if visible:    -as-
      //     view.doDefaultCommand("parse");
      //     String vis=view.query("visible",new LpexDocumentLocation(ep0+1,1));
      // Hmmmm, after adding just the view.doDefaultCommand("parse") above, the
      // cursor is now placed correctly (when applicable), on the 2nd portion
      // of the split text, so there is no need to force it back!?...

      // 1.- cursor is visible & on the next (visible) element: do a simple AI
      if (ep - ep0 == 1) {
         if ((view.elementText(ep).trim()).length() == 0) {
            // blank element - just set the cursor, to indent *display* column
            view.doDefaultCommand("set displayPosition " + cursorIndent(ep));
            return;
            }
         // (re)position text & cursor to indent value
         view.jump(ep, indentText(ep));
         }

      // 2.- next element (2nd half of split) not visible
      // (ep==0 when no visible cursor at all after split, e.g., .pli, Ctrl+G,
      // split " chimes: proc" w cursor on p, 'p' now < left margin == no proc)
      else {
         ep = ep0 + 1;
         if (ep <= view.elements() &&
             // don't bother with blank line, REparse won't make it more visible
             view.elementText(ep).trim().length() != 0) {
            // just reposition text, REparse file (good if margins, e.g., PL/I)
            int indent = indentText(ep);
            view.doDefaultCommand("parse");
            // reposition cursor too, only if ep has now become visible again
            if (view.queryOn("visible", new LpexDocumentLocation(ep,1)))
               view.jump(ep, indent);
            }
         }
   }

   /**
    * Position the text of an element to the correct indent value.
    * If automatic indenting is off, the indent value is 1.
    *
    * @param element the element for text indentation
    * @return the indentation value used
    *
    * @see #getAutoIndent
    * @see #textIndent
    */
   public int           indentText(int element)
   {
      return indentText(element, (_autoIndent? textIndent(element) : 1));
   }

   /**
    * Position the text of an element to the specified indent value.
    *
    * @param element the element for text indentation
    * @param indent indentation value
    * @return the indentation value used
    * @see #indentText
    */
   public int           indentText(int element, int indent)
   {
      String p = view.elementText(element);       // get element's text
      int i = 0;
      while (i < p.length() && (p.charAt(i)==' ' || p.charAt(i)=='\t')) { i++; }
      if (indent != i+1) {                        // if not already there,
         if (i > 0)                               //   position text to indent
            p = p.substring(i);

         StringBuffer indentString = new StringBuffer();
         for (i = indent; i > 1; i--)
            indentString.append(' ');
         indentString.append(p);
         view.setElementText(element, indentString.toString());
         }

      return indent;
   }

   /**
    * Utility method to return a style string for a <code>len</code>-long token.
    *
    * @param style style character for the token
    * @param len token length
    */
   public String        styleString(char style, int len)
   {
      // can't reuse, 'shared' is set by toString(), but never cleared...
      // private StringBuffer _styleStringBuffer = new StringBuffer(120);
      // _styleStringBuffer.setLength(0);
      // for (; len > 0; len--)
      //  _styleStringBuffer.append(style);
      // return _styleStringBuffer.toString();

      if (len <= 0)
         return "";
      StringBuffer styleStringBuffer = new StringBuffer(len);
      for (; len > 0; len--)
         styleStringBuffer.append(style);
      return styleStringBuffer.toString();
   }

   /**
    * Set the styles used by the parser for a token or set of tokens to a common
    * colour and font emphasis.
    *
    * <p>For example, the style attributes for comments are set like this in the
    * Java parser:
    * <pre>
    *   String toBackground = LpexPaletteAttributes.background(view);
    *   String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
    *                                                     BACKGROUND_COLOR,
    *                                                     toBackground);
    *   setStyle("c", attributes); </pre></p>
    *
    * @param styles     a string of all the style characters to set
    * @param attributes attributes for the editor command
    *                   <b>set styleAttributes.<i>styleCharacter</i></b>
    *                   e.g., "0 128 128 255 255 255 underline"
    *
    * @see #ATTRIBUTES_DEFAULT
    * @see #ATTRIBUTES_COMMENT
    * @see #ATTRIBUTES_ERROR
    * @see #ATTRIBUTES_KEYWORD
    * @see #ATTRIBUTES_KEYWORD1
    * @see #ATTRIBUTES_LIBRARY
    * @see #ATTRIBUTES_NUMERAL
    * @see #ATTRIBUTES_STRING
    * @see #ATTRIBUTES_DIRECTIVE
    * @see #ATTRIBUTES_NONSOURCE
    *
    * @see #setStyleAttributes
    * @see LpexPaletteAttributes
    */
   public final void    setStyle(String styles, String attributes)
   {
      if (styles != null) {
         StyleAttributes styleAttributes = StyleAttributes.getStyleAttributes(attributes);
         for (int i = styles.length();  i > 0;) {
            view._view.styleAttributesList().set(styles.charAt(--i), styleAttributes);
            }
         }
   }

   /**
    * Display a parser error or informational message for an element.
    * The error message is assigned the default CLASS_MESSAGE element class,
    * and is set the default STYLE_MESSAGE style character.
    *
    * @see #CLASS_MESSAGE
    * @see #STYLE_MESSAGE
    * @see #addMessage(int,String,long)
    * @see #addMessage(int,String,long,char)
    */
   public final void    addMessage(int element, String text)
   {
      addMessage(element, text, _classMessage, STYLE_MESSAGE);
   }

   /**
    * Display a parser error or informational message for an element.
    * The error message is assigned the specified element class,
    * and is set the default STYLE_MESSAGE style character.
    *
    * <p>A document-parser error is usually set with {@link #addMessage(int,String)},
    * the error message being assigned the default CLASS_MESSAGE element class.
    * This method may be used to customize the error messages, or to allow
    * one to manage the separate addition and removal of error messages from
    * different sources (for example, a lexer, a grammar parser, and a
    * compiler).</p>
    *
    * @see #STYLE_MESSAGE
    * @see #addMessage(int,String)
    * @see #addMessage(int,String,long,char)
    */
   public final void    addMessage(int element, String text, long messageClass)
   {
      addMessage(element, text, messageClass, STYLE_MESSAGE);
   }

   /**
    * Display an embedded parser error or informational message for an element,
    * with the specified element class and style character.
    * Embedded messages are set using <b>show</b> lines (text elements which are
    * displayed in the text view, but not saved with the document).
    *
    * <p>No imbedded messages are displayed if this feature is disabled.
    * Parser error messages are assigned the CLASS_MESSAGE element class,
    * and are set the STYLE_MESSAGE style character.</p>
    *
    * <p>A document-parser error is usually set with {@link #addMessage(int,String)},
    * the error message being assigned the default CLASS_MESSAGE element class,
    * and set the default STYLE_MESSAGE style character.
    * This method may be used to customize the error messages, or to allow
    * one to manage the separate addition and removal of error messages from
    * different sources (for example, a lexer, a grammar parser, and a
    * compiler).</p>
    *
    * <p>The messages to be inserted during a parse action are stacked.
    * The actual insertion of the show-line messages will be carried out
    * at the end of the current parse action.  Several messages for one
    * line will be displayed in the order they were added.</p>
    *
    * <p>The text of the message be obtained from a locale-sensitive
    * resource.</p>
    *
    * @param element the element number this message pertains to
    * @param text the message text
    * @param messageClass registered class bit-mask for this message
    * @param messageStyle registered style character for this message
    *
    * @see #setErrorMessages
    * @see #removeMessages
    * @see #CLASS_MESSAGE
    * @see #STYLE_MESSAGE
    * @see #addMessage(int,String)
    * @see #addMessage(int,String,long)
    */
   public final void    addMessage(int element, String text,
                                   long messageClass, char messageStyle)
   {
      if (!_errorMessages || text == null)
         return;

      //if (_TRACING)
      // System.out.println("LpexCommonParser#addMessage("+element+")");

      ParserMessage prevMessage = null;
      for (ParserMessage m = _messages; m != null; prevMessage = m, m = m._next) {
         if (element >= m._element)
            break;
         }

      ParserMessage newMessage = new ParserMessage(element, text, messageClass, messageStyle);
      if (prevMessage == null) {
         newMessage._next = _messages;
         _messages = newMessage;
         }
      else {
         newMessage._next = prevMessage._next;
         prevMessage._next = newMessage;
         }

      if (newMessage._next == null)
         _lastMessage = newMessage;
   }

   /**
    * Remove this parser's default messages for a given range of elements.
    *
    * @see #removeMessages(int,int,long)
    * @see #addMessage(int,String)
    * @see #addMessage(int,String,long)
    * @see #addMessage(int,String,long,char)
    */
   public final void    removeMessages(int fromElement, int toElement)
   {
      removeMessages(fromElement, toElement, _classMessage);
   }

   /**
    * Remove this parser's embedded messages of the given element class(es),
    * for the given range of elements.
    *
    * <p>A parser normally adds error and informational embedded messages with
    * {@link #addMessage(int,String)}, and removes them with
    * {@link #removeMessages(int,int)}.  Both these methods handle default
    * messages.
    * The methods that allow specifying the element class assigned to
    * the message may be used to customize these error messages, or to allow
    * one to manage the separate addition and removal of error messages from
    * different sources (for example, a lexer, a grammar parser, and a
    * compiler).</p>
    *
    * <p>If using both qualified and default addMessage() calls, then in order
    * to remove the messages of all types in a range, you can use:
    * <pre>
    *   removeMessages(fromElement, toElement,
    *                  lpexView().classMask(CLASS_MESSAGE) | <i>myMessageClassesBitMask</i>); </pre></p>
    *
    * <p>The actual removal of embedded error messages will be carried out at
    * the end of the current parse action.  Calls to this method during the
    * course of one parse action may extend a range already set.
    * <b>Note that a range is assumed to be continuous.</b></p>
    *
    * @param fromElement first text element in the range
    * @param toElement last text element for which this parser's messages
    *                  should be removed
    * @param messageClass message class(es) bit-mask
    *
    * @see #removeMessages(int,int)
    * @see #addMessage(int,String)
    * @see #addMessage(int,String,long)
    * @see #addMessage(int,String,long,char)
    */
   public final void    removeMessages(int fromElement, int toElement, long messageClass)
   {
      //if (_TRACING)
      // System.out.println("LpexCommonParser#removeMessages("+fromElement+"-"+toElement+")");

      // add all last text-element's messages to the range of messages to consider
      while ((toElement < view.elements()) &&
             view.show(toElement+1)) {
         toElement++;
         }

      // find & expand / create & set DeleteRanges for all the message class(es)
      DeleteRange dr;
      long mask = 1;
      for (int i = 0; i < 64; i++) {
         if ((messageClass & mask) != 0) {
            // ensure we have a delete range for this class of messages
            for (dr = _deleteRanges; dr != null; dr = dr._next) {
               if (dr._messageClass == messageClass)
                  break;
               }
            if (dr == null) {
               dr = new DeleteRange(messageClass);
               dr._next = _deleteRanges;
               _deleteRanges = dr;
               }
            dr.extend(fromElement, toElement);
            }
         mask <<= 1;
         }
   }

   /**
    * The actual removal and insertion of the parser messages
    * for one parse action.
    */
   private void         displayMessages()
   {
      /*=========================================================*/
      /*  establish the {from..to} range of elements to process  */
      /*=========================================================*/
      int from = 0, to = 0;

      // 1.- any messages added?
      if (_messages != null) {
         from = _lastMessage._element;
         to = _messages._element;
         }

      // 2.- any messages of any class type to remove?
      for (DeleteRange dr = _deleteRanges; dr != null; dr = dr._next) {
         if (from == 0 || dr._from < from)
            from = dr._from;
         if (dr._to > to)
            to = dr._to;
         }

      if (from == 0)
         return; // nothing to process.

      if (to > view.elements())
         to = view.elements();

      /*=======================================================================*/
      /*  go through range {end to start}, remove old messages & add new ones  */
      /*=======================================================================*/
      ParserMessage m = _messages;             // current message
      int lm = (m != null)? m._element : 0;    // next line with message(s)
      ElementList elementList = view._view.document().elementList();
      DocumentPosition.Preserve preserve = view._view.documentPosition().preserve();
      boolean forceAllVisible = view._view.forceAllVisible();
      view._view.setForceAllVisible(true);

      for (int i = to; i >= from; i--) {
         Element e = elementList.elementAt(i);

         /*---------------------------------------------*/
         /*  1.- show line: is it a message to delete?  */
         /*---------------------------------------------*/
         if (e.show()) {
            // delete if it belongs to a pending removeMessages() request
            if (deletableMessage(i, e))
               view._view.deleteElement(e);
            }

         /*------------------------------------------------*/
         /*  2.- text line: any messages to embed for it?  */
         /*------------------------------------------------*/
         else {
            while (i == lm) {
               view._view.documentPosition().jump(e, 1);
               Element msgElement = new Element(view._view); // create a show element
               msgElement.setText(view._view, m._text);
               view._view.insertElement(msgElement);
               ElementView msgElementView = msgElement.elementView(view._view);
               msgElementView.setStyle(styleString(m._messageStyle, m._text.length()));
               msgElementView.setClasses(m._messageClass);
               m = m._next;
               lm = (m != null)? m._element : 0;
               }
            }
         }//end "for"

      view._view.setForceAllVisible(forceAllVisible);
      preserve.restore();
      view._view.documentPosition().disposePreserve(preserve);

      /*============================================================*/
      /*  clear message removals / additions for next parse action  */
      /*============================================================*/
      _messages = null;
      _lastMessage = null;
      _deleteRanges = null;
   }

   /**
    * Determine whether the given show element should be deleted, according to the
    * pending removeMessages() requests for this parse action.
    */
   private boolean deletableMessage(int elementOrdinal, Element element)
   {
      ElementView elementView = element.elementView(view._view);

      // is it a show line embedded in *our* view?
      if (elementView.show()) {
         // is it in any pending DeleteRange, and has the right message-class set?
         for (DeleteRange dr = _deleteRanges; dr != null; dr = dr._next) {
            if (elementOrdinal >= dr._from && elementOrdinal <= dr._to &&
                (dr._messageClass & elementView.classes()) != 0)
               return true;
            }
         }

      return false;
   }


   /**
    * ParserMessage allows easy handling of a text message for an element.
    */
   private static final class ParserMessage
   {
      ParserMessage _next;
      int _element;
      String _text;
      long _messageClass;
      char _messageStyle;

      ParserMessage(int element, String text, long messageClass, char messageStyle)
      {
         _element = element;
         _text = text;
         _messageClass = messageClass;
         _messageStyle = messageStyle;
      }
   }


   /**
    * DeleteRange allows easy handling of removal ranges for a specific
    * element-class type of messages, requested for a parse action.
    */
   private static final class DeleteRange
   {
      DeleteRange _next;
      long _messageClass;
      int _from;
      int _to;

      DeleteRange(long messageClass)
      {
         _messageClass = messageClass;
      }

      void extend(int fromElement, int toElement)
      {
         if (_from == 0 || fromElement < _from)
            _from = fromElement;
         if (toElement > _to)
            _to = toElement;
      }
   }
}