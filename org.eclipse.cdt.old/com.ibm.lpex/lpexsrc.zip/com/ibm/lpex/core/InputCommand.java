//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// InputCommand - handle the input command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>input</b> command.
 */
final class InputCommand
{
 static boolean doCommand(View view, String parameters)
 {
  String labelText = "";
  String text = "";
  String command = null;

  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (!st.hasMoreTokens())
   {
    return CommandHandler.noParameters(view, "input");
   }

  String token = st.nextToken();
  if (LpexStringTokenizer.isInvalidQuotedString(token))
   {
    return CommandHandler.invalidQuotedParameter(view, token, "input");
   }
  token = LpexStringTokenizer.removeQuotes(token);

  if (!st.hasMoreTokens())
   {
    command = token;
   }
  else
   {
    labelText = token;
    token = st.nextToken();
    if (LpexStringTokenizer.isInvalidQuotedString(token))
     {
      return CommandHandler.invalidQuotedParameter(view, token, "input");
     }
    token = LpexStringTokenizer.removeQuotes(token);

    if (!st.hasMoreTokens())
     {
      command = token;
     }
    else
     {
      text = token;
      token = st.nextToken();
      if (LpexStringTokenizer.isInvalidQuotedString(token))
       {
        return CommandHandler.invalidQuotedParameter(view, token, "input");
       }

      command = LpexStringTokenizer.removeQuotes(token);
      if (st.hasMoreTokens())
       {
        return CommandHandler.invalidParameter(view, st.nextToken(), "input");
       }
     }
   }

  // command format is correct, now if we have a view do it
  if (view != null)
   {
    if (view.window() != null)
     {
      CommandLine commandLine = (CommandLine) view.window().commandLine();
      commandLine.setForceVisible(true);
      commandLine.setInput(view, labelText, text, command);
      commandLine.setMode(CommandLine.MODE_INPUT);
      view.window().commandLineRequestFocus();
     }
   }

  return true;
 }
}