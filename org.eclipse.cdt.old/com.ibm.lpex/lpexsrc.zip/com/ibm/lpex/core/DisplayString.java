//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DisplayString - information for the display of an element.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Information for the display of one element.
 */
final class DisplayString
{
   // the display text
   String text;

   // position in text of the sequence-numbers area (may be pushed off by
   // expanded tabs and SO/SIs in the preceding text);  it is only set
   // when sequence numbers are set and hideSequenceNumbers is "off"
   int sequenceNumbersPosition;

   DisplayString() {}

   DisplayString(String text)
   {
      this.text = text;
   }
}