//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SaveCommand - handles the save command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.io.Writer;


/**
 * This class implements the <b>save</b> command.
 * It saves the document section that is currently loaded in the editor.
 * It does not trigger a request for extending this document section.
 * To save the entire document, the user should extend this command to
 * first load the complete document in.
 */
final class SaveCommand
{
 // internal save.xxx parameter ids
 static final int
  INVALID    = 0,
  TEXT_LIMIT = 1,
  TRIM       = 2;

 // NB The save parameters must be in alphabetical order for the binary search.
 private static TableNode[] _parameters =
  {
   new TableNode(LpexConstants.SAVE_PARAMETER_TEXT_LIMIT, TEXT_LIMIT),
   new TableNode(LpexConstants.SAVE_PARAMETER_TRIM,       TRIM),
  };


 /**
  * Retrieve the Parameter object handling the particular <b>save.xxx</b>
  * parameter.
  */
 static Parameter getParameter(String parameter)
  {
   TableNode p = TableNode.binarySearch(_parameters, Parameters.getParameterString(parameter));
   if (p != null)
    {
     switch (p.id())
      {
       case TEXT_LIMIT:
        {
         return TextLimitParameter.getParameter();
        }
       case TRIM:
        {
         return TrimParameter.getParameter();
        }
       default:
        {
         break;
        }
      }
    }
   return null;
  }


 /**
  * The <b>save.textLimit</b> parameter.
  */
 final static class TextLimitParameter extends ParameterIntegerDefault
 {
  private static TextLimitParameter _parameter;
  static TextLimitParameter getParameter()
   {
    if (_parameter == null)
     {
      _parameter = new TextLimitParameter();
     }
    return _parameter;
   }

  private TextLimitParameter()
   {
    super(PARAMETER_SAVE + SAVE_PARAMETER_TEXT_LIMIT, 0);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value, boolean useDefaultValue)
   {
    if (view != null)
     {
      Settings settings = view.document().saveCommandSettings();
      settings._textLimit = value;
      settings._useDefaultTextLimit = useDefaultValue;
      currentValueChanged(view);
     }
    return true;
   }

  void currentValueChanged(View view)
   {
    if (view != null)
     {
      view.document().elementList().setTextLimit(view, currentValue(view));
     }
   }

  boolean useDefaultValue(View view)
   {
    return (view != null)? view.document().saveCommandSettings()._useDefaultTextLimit : true;
   }

  int value(View view)
   {
    return (view != null)? view.document().saveCommandSettings()._textLimit : 0;
   }
 }


 /**
  * The <b>save.trim</b> parameter.
  */
 final static class TrimParameter extends ParameterOnOffDefault
 {
  private static TrimParameter _parameter;
  static TrimParameter getParameter()
   {
    if (_parameter == null)
     {
      _parameter = new TrimParameter();
     }
    return _parameter;
   }

  private TrimParameter()
   {
    super(PARAMETER_SAVE + SAVE_PARAMETER_TRIM, true);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.document().saveCommandSettings()._trim = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.document().saveCommandSettings()._trim : Parameter.DEFAULT;
   }
 }


 static boolean doCommand(View view, String parameters)
  {
   return doCommand(view, null, parameters);
  }

 static boolean doCommand(View view, Writer writer, String parameters)
  {
   String fileName = null;
   boolean trim = TrimParameter.getParameter().currentValue(view);
   int textLimit = TextLimitParameter.getParameter().currentValue(view);
   boolean prompt = false;
   boolean visible = false;

   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   while (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("prompt"))            // for save, save as
      {
       prompt = true;
      }
     else if (token.equals("visible"))      // for save, save as
      {
       visible = true;
      }
     else if (token.equals("trim"))         // only applies to save
      {
       trim = true;
      }
     else if (token.equals("noTrim"))       // only applies to save
      {
       trim = false;
      }
     else if (token.equals("textLimit"))    // only applies to save
      {
       if (st.hasMoreTokens())
        {
         token = st.nextToken();
         try
          {
           textLimit = Integer.parseInt(token);
          }
         catch(NumberFormatException e)
          {
           return CommandHandler.invalidParameter(view, token, "save");
          }
        }
       else
        {
         return CommandHandler.integerMissing(view, "textLimit", "save");
        }
      }
     else
      {
       if (LpexStringTokenizer.isInvalidQuotedString(token))
        {
         return CommandHandler.invalidQuotedParameter(view, token, "save");
        }
       fileName = LpexStringTokenizer.trimQuotes(token);

       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "save");
        }
       break;
      }
    }

   if (view != null)
    {
     CommandHandler._status = null;
     if (fileName == null || fileName.length() == 0)
      {
       fileName = view.document().name();
      }

     if (prompt || fileName == null)
      {
       fileName = LpexUtilities.fileDialog(view,
                                LpexResources.message(LpexConstants.MSG_FILEDIALOG_SAVEAS),
                                true,
                                fileName);
      }

     if (fileName != null)
      {
       view.save(writer, fileName, visible, trim, textLimit);
      }
     else
      {
       CommandHandler._status = LpexConstants.STATUS_SAVE_CANCELLED;
      }
    }

   return true;
  }


 final static class Settings
 {
  int     _trim = Parameter.DEFAULT;
  int     _textLimit;
  boolean _useDefaultTextLimit = true;
 }
}