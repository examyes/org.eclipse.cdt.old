//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// TextWindow - manage the text area (child of LpexWindow).
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.MouseTrackListener;

import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Caret;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;


/**
 * This class manages the text area of an LpexWindow.
 * There is one instance of this class per instance of LpexWindow.
 */
final class TextWindow extends Canvas
{
 private LpexWindow      _lpexWindow;
 private Runnable        _cursorBlinkTimer;
 private int             _cursorBlinkTimerStarts = -1; // initially inactive
 private boolean         _cursorBlinkTimerStopped;
 private Runnable        _dragTimer;
 private int             _dragTimerStarts = -1;        // initially inactive
 private Rectangle       _bottomRect;
 private boolean         _bottomValid;
 private StyleAttributes _bottomStyleAttributes;

 private Cursor          _textCursor;
 private Cursor          _arrowCursor;

 private Line            _topLine;
 private Line            _cachedLines;
 private SubLine         _cachedSubLines;

 // awt: don't process half-baked KEY-TYPEDs (e.g., whose prev KEY_PRESSEDs
 //      were in the command window, such as the CR from an "open" command,
 //      and created this TextWindow in the first place)
 // private boolean _keyPressedConsumed = true;

 private boolean    _doKeyEventActive;

 private Cursor     _cursor;
 private boolean    _focusGained;
 private int        _lastPointX, _lastPointY; // last point of mouse activity
 private MouseEvent _lastDragEvent;
 private boolean    _cursorVisible;           // toggles continuously for the blinking cursor

 private Display    _display;
 private static boolean _displayTabAsSpace;   // Windows2000 Eclipse workaround

 // cursor-blink & mouse-drag timer interval (milliseconds)
 private static final int
  CURSORBLINKTIMER_INTERVAL = 530,
  DRAGTIMER_INTERVAL        = 40;

 // we need a Caret for repositioning the IME window (Input Method Editor for
 // DBCS machines), over which an Eclipse application doesn't have direct control.
 // As we paint & blink our own cursor, we use this Caret for IME-positioning
 // purposes only.  Therefore, it will be mostly kept invisible, and only made
 // temporarily visible in order to have it actually reposition the IME window
 // (see Eclipse bug 8931)...
 private Caret _caret;
 private int _imeX, _imeY;


 /**
  * Construct the text window (edit area) for an LpexWindow.
  */
 TextWindow(LpexWindow lpexWindow)
  {
   super(lpexWindow, SWT.H_SCROLL | SWT.V_SCROLL | SWT.NO_BACKGROUND |
                     // Screen adds us a ControlListener, with ControlResized() et al...
                     SWT.NO_REDRAW_RESIZE);

   _display = getDisplay();
   _textCursor  = new Cursor(_display, SWT.CURSOR_IBEAM);
   _arrowCursor = new Cursor(_display, SWT.CURSOR_ARROW);

   // Windows2000 Eclipse:  GC.drawString() doesn't draw TAB chars (no blob,
   // no nothin'), so we replace '\t's to ' 's in TextWindow.TextWindowString#set.
   // See also adjustment (TAB width = SPACE width) in TextFontMetrics.
   _displayTabAsSpace = "win32".equals(SWT.getPlatform());

   addFocusListener(new FocusListener()
    {
     public void focusGained(FocusEvent e)
      {
       _focusGained = true;

       // keep track of last widget with focus (see LpexWindow)
       _lpexWindow._lastFocusWidget = TextWindow.this;

       //awt: don't process half-baked KEY-TYPEDs (e.g., whose prev KEY_PRESSEDs
       //     were in the command window & brought us here in the first place)
       //awt: _keyPressedConsumed = true;
       setCursorVisible(true);  // start cursor-blink timer
       CommandLine commandLine = (CommandLine) _lpexWindow.commandLine();
       commandLine.setMode(CommandLine.MODE_COMMANDS);
       commandLine.setForceVisible(false);
       Document.screenShow();
      }

     public void focusLost(FocusEvent e)
      {
       _focusGained = false;
       setCursorVisible(false); // stop cursor-blink timer

       // update the IME window font
       setImeFont();

       // 1/2002: Noticed one case (Windows XP) MOUSE_RELEASED not received
       // (or rather EclipseR2.0's MouseEvent.stateMask keeps a button pressed?),
       // and we're dragging forever?!  But this, while not harming, cannot help
       // much either: any mouse move is still a drag if button appears pressed!?
       //setLastDragEvent(null);

       Document.screenShow();
      }
    });

   addListener(SWT.Paint, new Listener()
    {
     public void handleEvent(Event e)
      {
       // DEBUG: paint only every 10th paint request to demonstrate
       // SWT is erasing the TextWindow in between...
       // private int paintCount = 0;
       // if (++paintCount % 10 == 0)

       // SWT: e.x, y, width, height are the invalidated area to repaint
       paintComponent(new LpexGC(e.gc), e.x, e.y, e.width, e.height);
      }
    });

   addMouseListener(new MouseListener()
    {
     public void mouseDoubleClick(MouseEvent e)
      {
       doMouseEvent(e, ActionHandler.MOUSE_EVENT_DOUBLECLICKED);
      }
     public void mouseDown(MouseEvent e)
      {
       doMouseEvent(e, ActionHandler.MOUSE_EVENT_PRESSED);
      }
     public void mouseUp(MouseEvent e)
      {
       doMouseEvent(e, ActionHandler.MOUSE_EVENT_RELEASED);
      }
    });

   addMouseTrackListener(new MouseTrackListener()
    {
     public void mouseEnter(MouseEvent e)
      {
       doMouseEvent(e, ActionHandler.MOUSE_EVENT_ENTERED);
      }
     public void mouseExit(MouseEvent e)
      {
       doMouseEvent(e, ActionHandler.MOUSE_EVENT_EXITED);
      }
     //awt: N/A
     public void mouseHover(MouseEvent e)
      {
       doMouseEvent(e, ActionHandler.MOUSE_EVENT_HOVER);
      }
    });

   addMouseMoveListener(new MouseMoveListener()
    {
     //awt: mouseDragged, Moved
     public void mouseMove(MouseEvent e)
      {
       if ((e.stateMask & (SWT.BUTTON1 | SWT.BUTTON2 | SWT.BUTTON3)) != 0)
          doMouseEvent(e, ActionHandler.MOUSE_EVENT_DRAGGED);
       else
          doMouseEvent(e, ActionHandler.MOUSE_EVENT_MOVED);
      }
    });

   // awt: enableEvents(AWTEvent.KEY_EVENT_MASK);
   addKeyListener(new KeyListener()
    {
     public void keyPressed(KeyEvent e)
      {
       processKeyEvent(e);
      }
     public void keyReleased(KeyEvent e) {}
    });

   // swt: disable the automatic tab traversal on [Shift+]Tab key press, and the
   // similar SWT/Eclipse processing for the Enter, Esc, and arrow keys - we
   // want all the keys;  see org.eclipse.swt.widgets.Control#translateTraversal()
   addListener(SWT.Traverse, new Listener()
    {
     public void handleEvent(Event event) { event.doit = false; }
    });

   // swt: listen to the widget being disposed
   addListener(SWT.Dispose, new Listener()
    {
     public void handleEvent(Event event)
      {
       handleDispose();
      }
    });

   // Create a timer that will notify its listeners every ~1/2 second.
   // The poor man's restartable & repeatable cursor-blink timer - as Eclipse
   // only provides Display.timerExec(), without stop() / restart() / etc., add
   // a counter to keep track of stop/restarts and ignore ticks for previously
   // set timer (re)starts:
   // _cursorBlinkTimerStarts: -1 = inactive
   //                           0 = running
   //                          >0 = restarted
   _cursorBlinkTimer = new Runnable() // timerExec() interval-expiration tick
    {
     public void run()
      {
       // 1.- timer was stopped (this is just a queued-up old tick) / restarted
       if (_cursorBlinkTimerStopped || _cursorBlinkTimerStarts > 0)
        {
         // ignore this old tick, count down / wait for the latest tick
         _cursorBlinkTimerStarts--;
        }
       // 2.- timer is running
       else if (_cursorBlinkTimerStarts == 0)
        {
         toggleCursor(false);          //  toggle cursor (if we have focus)
         _display.timerExec(CURSORBLINKTIMER_INTERVAL, this); // repeat
        }
      }
    };

   // The _lastDragEvent & associated timer code is in place so that you can drag
   // the mouse off the bottom (or top) of the window and continue to drag down in
   // the file without having to wiggle the mouse to generate more drag events.
   // _dragTimerStarts: -1 = inactive
   //                    0 = running
   //                   >0 = restarted
   _dragTimer = new Runnable()
    {
     public void run()
      {
       // 1.- timer was restarted
       if (_dragTimerStarts > 0)
        {
         _dragTimerStarts--;          //  ignore this old tick, wait for latest
         return;
        }
       // 2.- timer is running
       else
        {
         _dragTimerStarts = -1;       //  inactive for now (timer is not repeatable)
         if (_lastDragEvent != null)  //  if autoscrolling still going on
          {
           doMouseEvent(_lastDragEvent, ActionHandler.MOUSE_EVENT_DRAGGED);
          }
        }
      }
    };

   _lpexWindow = lpexWindow;
   setCursor(_textCursor);

   // create a Caret for repositioning the IME window on DBCS machines
   // if (LpexNls.isMbcsEncoding(LpexNls.getNativeEncoding()))
   _caret = new Caret(this, SWT.NULL);
   _caret.setVisible(false);
  }

 /**
  * Reposition the IME window.
  */
 void setImeLocation(int x, int y)
  {
   if (/*_caret!=null&&*/ (_imeX != x || _imeY != y))
    {
     _imeX = x;
     _imeY = y;
     _caret.setLocation(_imeX, _imeY);
     _caret.setVisible(true);  // make it actually reposition the IME window
     _caret.setVisible(false); // hide it, we don't want two blinkin' cursors...
    }
  }

 /**
  * Re-set the IME window font.
  */
 void setImeFont()
  {
   View view = view();
   if (_caret != null && view != null)
    {
     _caret.setFont(view.screen().currentFont().getFont());
    }
  }

 /**
  * Free SWT underlying native resources.
  */
 private void handleDispose()
  {
   _textCursor.dispose();
   _arrowCursor.dispose();
  }

 /**
  * Retrieve SWT's preferred size of the component.
  */
 public Point computeSize(int wHint, int hHint, boolean changed)
  {
   int height = 0;
   int width  = 0;
   View view = view();
   if (view != null)
    {
     TextFontMetrics textFontMetrics = view.screen().textFontMetrics();
     if (textFontMetrics != null)
      {
       height = textFontMetrics.textHeight() * 20;
       width  = textFontMetrics.spaceWidth() * 40;
      }
    }
   return new Point(width, height);
  }

 // reuse an Event for all the keys received for notifying LpexKeyListeners
 private Event _lpexKeyEvent = new Event();
 // awt: - java.awt.event.InputEvent:
 //        The root event class for all component-level input events.  Input
 //        events are delivered to listeners before they are processed normally
 //        by the source where they originated.  This allows listeners and
 //        component subclasses to "consume" the event so that the source will
 //        not process them in their default manner.  For example, consuming
 //        mousePressed events on a Button component will prevent the Button
 //        from being activated.
 //      - see also java.awt.event.KeyEvent documentation.
 //      - we're processing KEY_PRESSED and KEY_TYPED events (there is no
 //        value for us in the KEY_RELEASEDs)
 // swt: - there is no built-in mechanism to consume events
 //      - we're only processing KEY_PRESSEDs (there are no KEY_TYPEDs, and
 //        there is no value for us in the KEY_RELEASEDs)
 void processKeyEvent(KeyEvent e)
  {
   // DEBUG DEBUG
   // String result = "* KeyEvent: keyChar=";
   // if (e.character >= 32 && e.character != 127)
   //    result += e.character;
   // else
   //    result += " ";
   // result += " (0x" + Integer.toHexString(e.character).toUpperCase() + ")";
   // result += ", keyCode=0x" + Integer.toHexString(e.keyCode).toUpperCase();
   // result += ", stateMask=";
   // if (e.stateMask == 0)
   //    result += "<none>";
   // else {
   //    if ((e.stateMask & SWT.ALT) != 0)     result += "Alt ";
   //    if ((e.stateMask & SWT.CONTROL) != 0) result += "Ctrl ";
   //    if ((e.stateMask & SWT.SHIFT) != 0)   result += "Shift ";
   //
   //    // mouse BUTTON1 may be received for some keys when entered via mouse
   //    // selection on the Start -> Programs -> Accessories -> Accesibility ->
   //    // "On-Screen Keyboard" utility:
   //    if ((e.stateMask & SWT.BUTTON1) != 0) result += "BUTTON1 ";
   //
   //    int otherMask = e.stateMask & ~(SWT.ALT | SWT.CONTROL | SWT.SHIFT | SWT.BUTTON1);
   //    if (otherMask != 0)
   //       result += "<others>: " + Integer.toHexString(otherMask).toUpperCase();
   //    }
   // System.out.println(result);
   // DEBUG DEBUG

   // awt: if (!_doKeyEventActive &&
   //          (e.getID() == KeyEvent.KEY_PRESSED ||
   //          (e.getID() == KeyEvent.KEY_TYPED && !_keyPressedConsumed)))
   // swt: there are no KEY_TYPED events, so we'll rely on KEY_PRESSEDs only...
   if (!_doKeyEventActive)
    {
     View view = view();
     if (view != null)
      {
       // if an LpexKeyListener was registered with us, verify that the key that
       // was entered should be processed by us too - must do it the Eclipse way,
       // there is no AWT-like listener just e.consume()ing key events...
       if (view.lpexView().keyListenerList() != null)
        {
         _lpexKeyEvent.character = e.character;
         _lpexKeyEvent.keyCode   = e.keyCode;
         _lpexKeyEvent.stateMask = e.stateMask;
         _lpexKeyEvent.doit = true;

         view.lpexView().triggerKeyListeners(_lpexKeyEvent);
         if (!_lpexKeyEvent.doit)
          {
           return; // listener fully processed this key already.
          }
        }

       _doKeyEventActive = true;
       // clear mouse BUTTON1 from the key's stateMask (see DEBUG notes above),
       // or else we won't find keys like that in our keyAction lists
       e.stateMask &= ~SWT.BUTTON1;
       view.actionHandler().doKeyEvent(e);
       _doKeyEventActive = false;
      }
    }

   // awt: if a KEY_PRESSED was handled, ignore its subsequent KEY_TYPED:
   // _keyPressedConsumed = (e.getID()==KeyEvent.KEY_PRESSED) && e.isConsumed();
   // if (!e.isConsumed())
   //  {
   //   super.processKeyEvent(e);
   //  }
  }

 public void setCursor(Cursor cursor)
  {
   if (_cursor != cursor)
    {
     super.setCursor(cursor);
     _cursor = cursor;
    }
  }

 View view()
  {
   return (_lpexWindow.view() != null)? _lpexWindow.view()._view : null;
  }

 // reuse a clipBounds rectangle (there are no nested paintComponent() calls...)
 private Rectangle _clipBounds = new Rectangle(0,0,0,0);
 private void paintComponent(LpexGC g, int x, int y, int width, int height)
  {
   // System.out.println("*TextWindow paint x="+x+" y="+y+" width="+width+" height="+height);

   // awt: getClipBounds() - Returns the bounding rectangle of the current
   //      clipping area. This method refers to the user clip, which is
   //      independent of the clipping associated with device bounds and window
   //      visibility.  If no clip has previously been set, or if the clip has
   //      been cleared using setClip(null), this method returns null.
   //      The coordinates in the rectangle are relative to the coordinate system
   //      origin of this graphics context.
   //      Returns:
   //        the bounding rectangle of the current clipping area, or
   //        null if no clip is set.
   // Rectangle clipBounds = g.getClipBounds();
   // swt: use PaintEvent's x, y, width, height
   _clipBounds.x = x;
   _clipBounds.y = y;
   _clipBounds.width = width;
   _clipBounds.height = height;

   // update our own records of what has to be painted f(clipBounds)...
   invalidateText(_clipBounds);
   invalidateBottom(_clipBounds);

   // ...and go and paint
   if (view() != null)
    {
     for (Line line = _topLine; line != null; line = line._next)
      {
       line.paint(g);
      }
    }
   paintBottom(g);
  }

 boolean focusGained()
  {
   return _focusGained;
  }

 /**
  * @param e a MouseEvent from one of our mouse listeners, or
  *          _lastDragEvent when the drag timer ticked
  */
 private void doMouseEvent(MouseEvent e, int eID)
  {
   int newPointX = e.x;  //awt: e.getPoint();
   int newPointY = e.y;

   // awt: if (e.getID() == MouseEvent.MOUSE_PRESSED) . . .
   // swt: no event.id, so we use our own ids defined in ActionHandler...
   if (eID == ActionHandler.MOUSE_EVENT_PRESSED)
    {
     // awt: e.getComponent().requestFocus(); //set focus on originator of event
     setFocus();
    }

   if (eID == ActionHandler.MOUSE_EVENT_DRAGGED)
    {
     setCursor(_textCursor);
     Rectangle size = getClientArea();
     if (newPointX < 0 || newPointX > size.width ||
         newPointY < 0 || newPointY > size.height)
      {
       setLastDragEvent(e);    // mouse pointer is [still] outside text window
      }
     else
      {
       setLastDragEvent(null); // mouse is now inside the text window...
      }
    }
   // stop the automatic dragging if another mouse event occurred (except, of
   // course, a hover indication:  we ARE hovering outside the edit window here)
   else if (eID != ActionHandler.MOUSE_EVENT_HOVER)
    {
     setLastDragEvent(null);
    }

   View view = this.view();
   if (view != null)
    {
     // set arrow / ibeam cursor pointer, depending on where the mouse moved to
     if (eID == ActionHandler.MOUSE_EVENT_MOVED)
      {
       if (newPointX < view.screen().expandHideAreaWidth())
        {
         setCursor(_arrowCursor);
        }
       else
        {
         setCursor(_textCursor);
        }
      }

     // disregard tiny mouse drags inside the window
     if (eID == ActionHandler.MOUSE_EVENT_DRAGGED)
      {
       if (_lastDragEvent == null)
        {
         if (Math.abs(_lastPointX - newPointX) <
               (view.screen().textFontMetrics().spaceWidth() / 2) &&
             Math.abs(_lastPointY - newPointY) <
               (view.screen().textFontMetrics().textHeight() / 2))
          {
           return;
          }
        }
      }

     view.actionHandler().doMouseEvent(e, eID);
    }

   _lastPointX = newPointX;
   _lastPointY = newPointY;
  }

 private void setLastDragEvent(MouseEvent e)
  {
   _lastDragEvent = e;
   if (e != null)                                      // continue autoscrolling
    {
     // start / restart drag timer
     _dragTimerStarts++;          // inactive -> running / running -> restarted
     _display.timerExec(DRAGTIMER_INTERVAL, _dragTimer);
    }
  }

 /**
  * Start / stop the cursor-blink timer.
  * Called, for example, with visible <code>true</code> when this
  * TextWindow gains focus, and <code>false</code> when it loses the focus.
  */
 void setCursorVisible(boolean visible)
  {
   if (visible)
    {
     startCursorBlinkTimer();
    }
   else
    {
     stopCursorBlinkTimer();
    }
  }

 // start / restart the cursor-blink timer
 private void startCursorBlinkTimer()
  {
    _cursorBlinkTimerStopped = false;
    _cursorBlinkTimerStarts++;    // inactive -> running / running -> restarted
    _display.timerExec(CURSORBLINKTIMER_INTERVAL, _cursorBlinkTimer);
  }

 // stop the cursor-blink timer
 private void stopCursorBlinkTimer()
  {
    _cursorBlinkTimerStopped = true;
    // if now timer is re-started before any the queued restart ticks expire, we
    // will ignore all queued-up ticks that are still in _cursorBlinkTimerStarts
  }

 /**
  * Toggle the cursor if this text window has the focus.
  * @param updatingText true = being called from updateText(), don't call it again
  */
 private void toggleCursor(boolean updatingText)
  {
   if (!focusGained())
    {
     return;
    }

   // if no blinking & cursor already visible - keep it like this.
   if (view() != null && view().currentCursorBlink() == false &&
       _cursorVisible == true)
    {
     return;
    }

   _cursorVisible = !_cursorVisible;

   if (view() != null)
    {
     for (Line line = _topLine; line != null; line = line._next)
      {
       line.invalidateCursor();
      }
     if (!updatingText)
      {
       updateText(false);
      }
    }
  }

 private Line getNewLine()
  {
   if (_cachedLines == null)
    {
     return new Line();
    }
   Line line = _cachedLines;
   _cachedLines = line._next;
   line._next = null;
   return line;
  }

 /**
  * Ensure we have exactly the number of Lines as the screen rows.
  */
 void setLines(int rows)
  {
   Line currentLine = _topLine;
   Line lastLine = null;
   for (int i = 0; i < rows; i++)
    {
     if (currentLine == null)
      {
       currentLine = getNewLine();
       if (lastLine == null)
        {
         _topLine = currentLine;
        }
       else
        {
         lastLine._next = currentLine;
        }
      }
     lastLine = currentLine;
     currentLine = currentLine._next;
    }

   if (lastLine != null)
    {
     lastLine._next = null;
    }
   else
    {
     _topLine = null;
    }

   // set free any extra Lines we had beforehand
   while (currentLine != null)
    {
     Line next = currentLine._next;
     currentLine.reset();
     currentLine._next = _cachedLines;
     _cachedLines = currentLine;
     currentLine = next;
    }

   //int count = 0;
   //for (Line line = _topLine; line != null; line = line._next) { count++; }
  }

 Line line(int row)
  {
   int i = 1;
   for (Line line = _topLine; line != null; line = line._next)
    {
     if (i == row)
      {
       return line;
      }
     i++;
    }
   return null;
  }

 /**
  * Invalidate the section of the Lines inside the invalidRect.
  */
 private void invalidateText(Rectangle invalidRect)
  {
   for (Line line = _topLine; line != null; line = line._next)
    {
     if (line.intersects(invalidRect))
      {
       line.invalidate(invalidRect.x, invalidRect.width);
      }
    }
  }

 /**
  * Completely invalidate all the Lines -
  * reset them & free them back into the available cache.
  */
 void invalidateText()
  {
   while (_topLine != null)
    {
     Line temp = _topLine;
     _topLine = _topLine._next;
     temp.reset();
     temp._next = _cachedLines;
     _cachedLines = temp;
    }
  }

 private void invalidateBottom(Rectangle invalidRect)
  {
   if (_bottomRect != null && _bottomRect.intersects(invalidRect))
    {
     invalidateBottom();
    }
  }

 private void invalidateBottom()
  {
   _bottomValid = false;
  }

 void setBottomHeight(int height)
  {
   if (height > 0)
    {
     Rectangle size = getClientArea();
     if (_bottomRect == null)
      {
       _bottomRect = new Rectangle(0, size.height - height, size.width, height);
       invalidateBottom();
      }
     else
      {
       if (_bottomRect.y != (size.height - height) ||
           _bottomRect.width != size.width ||
           _bottomRect.height != height)
        {
         _bottomRect.y = size.height - height;
         _bottomRect.width = size.width;
         _bottomRect.height = height;
         invalidateBottom();
        }
      }
    }
   else
    {
     if (_bottomRect != null)
      {
       _bottomRect.height = 0;
      }
    }
  }

 void setBottomStyleAttributes(StyleAttributes bottomStyleAttributes)
  {
   if (_bottomStyleAttributes == null ||
       !_bottomStyleAttributes.equals(bottomStyleAttributes))
    {
     _bottomStyleAttributes = bottomStyleAttributes;
     invalidateBottom();
    }
  }

 /**
  * Initiate a redraw() if we've changed the contents of the bottom
  * partial-row area.
  */
 void updateBottom()
  {
   if (!_bottomValid && _bottomRect != null && _bottomRect.height != 0)
    {
     redraw(_bottomRect.x, _bottomRect.y, _bottomRect.width, _bottomRect.height, false);
    }
  }

 private void paintBottom(LpexGC g)
  {
   if (!_bottomValid && _bottomRect != null &&
       _bottomStyleAttributes != null && _bottomRect.height > 0)
    {
     g.setBackground(_bottomStyleAttributes.backgroundColor());
     g.gc.fillRectangle(_bottomRect.x, _bottomRect.y, _bottomRect.width, _bottomRect.height);
     _bottomValid = true;
    }
  }

// boolean textValid()
// {
//  for (Line line=_topLine; line!=null; line=line._next)
//   { if (!line.valid()) { return false; } }
//  return true;
// }

 /**
  * Invalidate text area.
  * @param forceCursor false = called from toggleCursor(), don't call it again!
  */
 void updateText(boolean forceCursor)
  {
   if (forceCursor)
    {
     if (_cursorBlinkTimerStarts >= 0) // if timer already running
      {
       // restart timer, canceling any pending firings and causing it
       // to fire with its initial delay - when we're updating the display
       // we want the cursor to show (e.g., when cursoring up/down the screen,
       // or keeping the mouse pressed on a scrollbar arrow, we want to see the
       // [moving] cursor all the time...)
       startCursorBlinkTimer();
       if (!_cursorVisible)
        {
         toggleCursor(true); // indicate we're already doing the updateText()!
        }
      }
    }

   if (view() != null)
    {
     for (Line line = _topLine; line != null; line = line._next)
      {
       line.update();
      }
    }
  }

 /**
  * A line in the text window.  The text of one Line may be divided into
  * several SubLines (one for each token) for the drawing.
  *
  * <p>Basically "extends Rectangle", but SWT's Rectangle is rather final,
  * so that was dropped in the AWT/Swing version too...
  */
 final class Line
  {
   Line _next;

   private int              x, y, width, height;
   private TextWindowString _text;
   private TextWindowString _prefixText;
   private TextWindowString _expandHideText;
   private int              _styledTextWidth; // max(text-width, styles-width) in pixels
   private int              _prefixWidth;
   private int              _expandHideWidth;

   private StyleAttributes  _textStyleAttributes[];
   private int              _textStyleAttributesLength;
   private StyleAttributes  _defaultStyleAttributes;
   private StyleAttributes  _prefixStyleAttributes;
   private StyleAttributes  _expandHideStyleAttributes;
   private StyleAttributes  _selectionStyleAttributes;
   private StyleAttributes  _emphasisStyleAttributes;

   private Font             _font;
   private TextFontMetrics  _textFontMetrics;
   private int              _textPosition;
   private boolean          _hasCursor;
   private int              _cursorPosition;
   private int              _cursorWidth;
   private boolean          _hasPrefixCursor;
   private int              _prefixCursorPosition;
   private int              _prefixCursorWidth;

   private boolean          _hasBlock;
   private int              _blockPosition;
   private int              _blockWidth;
   private boolean          _hasElementBlock;

   private int              _emphasisWidth;
   private int              _scroll;
   private int              _prefixScroll;
   private int              _invalidPosition;
   private int              _invalidWidth;

   private SubLine          _topSubLine;      // list of text segments to draw
   private boolean          _subLinesValid;


   // Line() { x = y = width = height = 0; }

   boolean intersects(Rectangle r)
    {
     return !((r.x + r.width <= x) || (r.y + r.height <= y) ||
              (r.x >= x + width)   || (r.y >= y + height));
    }

   void reset()
    {
     x = y = width = height = 0;

     if (_text != null)
      {
       _text._length = 0;
      }
     if (_prefixText != null)
      {
       _prefixText._length = 0;
      }
     if (_expandHideText != null)
      {
       _expandHideText._length = 0;
      }

     _styledTextWidth = 0;
     _prefixWidth = 0;
     _expandHideWidth = 0;
     _textStyleAttributesLength = 0;
     _defaultStyleAttributes = null;
     _prefixStyleAttributes = null;
     _expandHideStyleAttributes = null;
     _selectionStyleAttributes = null;
     _emphasisStyleAttributes = null;
     _font = null;
     _textFontMetrics = null;
     _textPosition = 0;
     _hasCursor = false;
     _cursorPosition = 0;
     _cursorWidth = 0;
     _hasPrefixCursor = false;
     _prefixCursorPosition = 0;
     _prefixCursorWidth = 0;
     _hasBlock = false;
     _blockPosition = 0;
     _blockWidth = 0;
     _hasElementBlock = false;
     _emphasisWidth = 0;
     _scroll = 0;
     _prefixScroll = 0;

     _invalidWidth = 0;                // 0 == valid line
     _invalidPosition = 0;

     clearSubLines();                  // clear out the list of segments to draw
    }

   /**
    * Restore all this Line's sublines to the availables list.
    */
   void clearSubLines()
    {
     // go through all, one by one...
     while (_topSubLine != null)
      {
       // remove from list
       SubLine temp = _topSubLine;
       _topSubLine = _topSubLine._next;
       // reset its info
       temp.reset();
       // put back into cache store
       temp._next = _cachedSubLines;
       _cachedSubLines = temp;
      }
     _subLinesValid = false;
    }

   /**
    * Sets width & height, invalidates the entire line if size changed.
    */
   void setSize(int width, int height)
    {
     if (width == this.width && height == this.height)
      {
       return;
      }

     //*as* if same height, invalidate only delta width if > 0 (& OK for italics)??!
     this.width  = width;
     this.height = height;
     invalidate(0, width);
    }

   /**
    * Set this line's y (inside the TextWindow), which is also the position for
    * painting the text.
    */
   void setY(int y)
    {
     if (y != this.y)
      {
       this.y = y;
       _textPosition = y; // SWT: we got rid of unneeded setTextPosition()...
       invalidate(0, width);
      }
    }

   /**
    * Re-set the text of the line.
    */
   void setText(String text)
    {
     if (_text == null)
      {
       if (text == null || text.length() == 0)
        {
         return;
        }
       _text = new TextWindowString(text.length(), 100);
      }

     if (_text.set(text)) // if a different text
      {
       clearSubLines();

       int newStyledTextWidth = (_text._length != 0)?
                                _textFontMetrics.stringWidth(_text._string, _text._length) : 0;

       // if current styles longer than the new text, enlarge the line's section
       // to invalidate by these current extra styles (just in case they stay
       // the same) which are set over trailing blanks
       if (_textStyleAttributesLength > _text._length)
        {
         newStyledTextWidth += _textFontMetrics.spaceWidth() *
                               (_textStyleAttributesLength - _text._length);
        }

       int invalidateWidth = Math.max(_styledTextWidth, newStyledTextWidth);
       _styledTextWidth = newStyledTextWidth;

       invalidate(_expandHideWidth + _prefixWidth - _scroll, invalidateWidth);
      }
    }

   void setPrefixText(String prefixText)
    {
     if (_prefixText == null)
      {
       if (prefixText == null || prefixText.length() == 0)
        {
         return;
        }
       _prefixText = new TextWindowString(0, 6);
      }

     //*as* don't call if _prefixWidth is 0!?
     if (_prefixText.set(prefixText))
      {
       invalidate(_expandHideWidth, _prefixWidth);
      }
    }

   void setExpandHideText(String expandHideText)
    {
     if (_expandHideText == null)
      {
       if (expandHideText == null || expandHideText.length() == 0)
        {
         return;
        }
       _expandHideText = new TextWindowString(0, 1);
      }
     if (_expandHideText.set(expandHideText))
      {
       invalidate(0, _expandHideWidth);
      }
    }

   void setPrefixWidth(int prefixWidth)
    {
     if (_prefixWidth != prefixWidth)
      {
       _prefixWidth = prefixWidth;
       invalidate(_expandHideWidth, width);
      }
    }

   void setExpandHideWidth(int expandHideWidth)
    {
     if (_expandHideWidth != expandHideWidth)
      {
       _expandHideWidth = expandHideWidth;
       invalidate(0, width);
      }
    }

   void setTextStyleAttributesLength(int textStyleAttributesLength)
    {
     if (_textStyleAttributesLength != textStyleAttributesLength)
      {
       _textStyleAttributesLength = textStyleAttributesLength;
       clearSubLines();

       // if new styles longer than the new text, enlarge the line's section to
       // be invalidated by the extra styles which are being set over blanks
       // (if text style attributes length is *shorter* than before, then
       // _styledTextWidth will stay longer than necessary for a while)
       if (_textStyleAttributesLength > _text._length)
        {
         _styledTextWidth += _textFontMetrics.spaceWidth() *
                             (_textStyleAttributesLength - _text._length);
        }
       invalidate(_expandHideWidth + _prefixWidth - _scroll, _styledTextWidth);

       if (_textStyleAttributesLength > 0 &&
           (_textStyleAttributes == null ||
            _textStyleAttributesLength > _textStyleAttributes.length))
        {
         _textStyleAttributes = new StyleAttributes[_textStyleAttributesLength + 100];
        }
      }
    }

   void setTextStyleAttributes(String style, StyleAttributesList styleAttributesList)
    {
     // 1.- find first that invalidates the line, if any
     int i;
     for (i = 0; i < _textStyleAttributesLength; i++)
      {
       StyleAttributes textStyleAttributes = styleAttributesList.find(style.charAt(i));
       if (_textStyleAttributes[i] == null ||
           !_textStyleAttributes[i].equals(textStyleAttributes))
        {
         _textStyleAttributes[i] = textStyleAttributes;
         clearSubLines();

         invalidate(_expandHideWidth + _prefixWidth - _scroll, _styledTextWidth);
         break;
        }
      }

     // 2.- set the rest faster...
     for (++i; i < _textStyleAttributesLength; i++)
      {
       _textStyleAttributes[i] = styleAttributesList.find(style.charAt(i));
      }
    }

   void setDefaultStyleAttributes(StyleAttributes defaultStyleAttributes)
    {
     if (_defaultStyleAttributes == null ||
         !_defaultStyleAttributes.equals(defaultStyleAttributes))
      {
       _defaultStyleAttributes = defaultStyleAttributes;
       clearSubLines();
       invalidate(_expandHideWidth + _prefixWidth, width);
      }
    }

   void setPrefixStyleAttributes(StyleAttributes prefixStyleAttributes)
    {
     if (_prefixStyleAttributes == null ||
         !_prefixStyleAttributes.equals(prefixStyleAttributes))
      {
       _prefixStyleAttributes = prefixStyleAttributes;
       invalidate(_expandHideWidth, _prefixWidth);
      }
    }

   void setExpandHideStyleAttributes(StyleAttributes expandHideStyleAttributes)
    {
     if (_expandHideStyleAttributes == null ||
         !_expandHideStyleAttributes.equals(expandHideStyleAttributes))
      {
       _expandHideStyleAttributes = expandHideStyleAttributes;
       invalidate(0, _expandHideWidth);
      }
    }

   void setSelectionStyleAttributes(StyleAttributes selectionStyleAttributes)
    {
     if (_selectionStyleAttributes == null ||
         !_selectionStyleAttributes.equals(selectionStyleAttributes))
      {
       _selectionStyleAttributes = selectionStyleAttributes;
       if (_hasBlock && !_hasElementBlock)
        {
         invalidate(_expandHideWidth + _prefixWidth + _blockPosition - _scroll,
                    _blockWidth);
        }
       else // no current selection / element selection: invalidate entire line
        {
         invalidate(_expandHideWidth + _prefixWidth, width);
        }
      }
    }

   void setEmphasisStyleAttributes(StyleAttributes emphasisStyleAttributes)
    {
     if (_emphasisStyleAttributes == null ||
         !_emphasisStyleAttributes.equals(emphasisStyleAttributes))
      {
       _emphasisStyleAttributes = emphasisStyleAttributes;
       if (_emphasisWidth > 0)
        {
         invalidate(_expandHideWidth + _prefixWidth + _cursorPosition - _scroll,
                    _emphasisWidth);
        }
      }
    }

   void setFont(Font font, TextFontMetrics textFontMetrics)
    {
     if (_font == null || !(_font.equals(font)))
      {
       _font = font;
       _textFontMetrics = textFontMetrics;
       clearSubLines();
       invalidate(0, width);
      }
    }

   // /**
   //  * Set this line's y (inside the TextWindow) for drawing the text.
   //  * Unlike AWT where we draw from the baseline, this is not needed - see setY().
   //  */
   // void setTextPosition(int textPosition)
   //  {
   //   if (_textPosition != textPosition)
   //    {
   //     _textPosition = textPosition;
   //     invalidate(0, width);
   //    }
   //  }

   void setHasCursor(boolean hasCursor)
    {
     if (_hasCursor != hasCursor)
      {
       _hasCursor = hasCursor;
       invalidate(_expandHideWidth + _prefixWidth + _cursorPosition - _scroll,
                  _cursorWidth);
      }

     if (_hasCursor)
      {
       if (!_cursorVisible)
        {
         setCursorVisible(true);                     // start cursor-blink timer
         invalidate(_expandHideWidth + _prefixWidth + _cursorPosition - _scroll,
                    _cursorWidth);
        }
      }
    }

   void setHasPrefixCursor(boolean hasPrefixCursor)
    {
     if (_hasPrefixCursor != hasPrefixCursor)
      {
       _hasPrefixCursor = hasPrefixCursor;
       invalidate(_expandHideWidth + _prefixCursorPosition - _prefixScroll,
                  _prefixCursorWidth);
      }

     if (_hasPrefixCursor)
      {
       if (!_cursorVisible)
        {
         setCursorVisible(true);                     // start cursor-blink timer
         invalidate(_expandHideWidth + _prefixCursorPosition - _prefixScroll,
                    _prefixCursorWidth);
        }
      }
    }

   void setCursorPosition(int cursorPosition)
    {
     if (_cursorPosition != cursorPosition)
      {
       if (_hasCursor)
        {
         invalidate(_expandHideWidth + _prefixWidth + cursorPosition - _scroll,
                    _cursorWidth);  // new cursor position
         invalidate(_expandHideWidth + _prefixWidth + _cursorPosition - _scroll,
                    _cursorWidth);  // old cursor position
        }

       if (_emphasisWidth > 0)
        {
         invalidate(_expandHideWidth + _prefixWidth + cursorPosition - _scroll,
                    _emphasisWidth);
         invalidate(_expandHideWidth + _prefixWidth + _cursorPosition - _scroll,
                    _emphasisWidth);
        }

       _cursorPosition = cursorPosition;
      }
    }

   void setCursorWidth(int cursorWidth)
    {
     if (_cursorWidth != cursorWidth)
      {
       if (_hasCursor)
        {
         invalidate(_expandHideWidth + _prefixWidth + _cursorPosition - _scroll,
                    cursorWidth);   // new cursor width
         invalidate(_expandHideWidth + _prefixWidth + _cursorPosition - _scroll,
                    _cursorWidth);  // old cursor width
        }

       _cursorWidth = cursorWidth;
      }
    }

   void setPrefixCursorPosition(int prefixCursorPosition)
    {
     if (_prefixCursorPosition != prefixCursorPosition)
      {
       if (_hasPrefixCursor)
        {
         invalidate(_expandHideWidth + prefixCursorPosition - _prefixScroll,
                    _prefixCursorWidth);
         invalidate(_expandHideWidth + _prefixCursorPosition - _prefixScroll,
                    _prefixCursorWidth);
        }
       _prefixCursorPosition = prefixCursorPosition;
      }
    }

   void setPrefixCursorWidth(int prefixCursorWidth)
    {
     if (_prefixCursorWidth != prefixCursorWidth)
      {
       if (_hasPrefixCursor)
        {
         invalidate(_expandHideWidth + _prefixCursorPosition - _prefixScroll,
                    prefixCursorWidth);
         invalidate(_expandHideWidth + _prefixCursorPosition - _prefixScroll,
                    _prefixCursorWidth);
        }
       _prefixCursorWidth = prefixCursorWidth;
      }
    }

   void invalidateCursor()
    {
     if (_hasCursor)
      {
       invalidate(_expandHideWidth + _prefixWidth + _cursorPosition - _scroll,
                  _cursorWidth);
      }
     if (_hasPrefixCursor)
      {
       invalidate(_expandHideWidth + _prefixCursorPosition - _prefixScroll,
                  _prefixCursorWidth);
      }
    }

   void setHasBlock(boolean hasBlock)
    {
     if (_hasBlock != hasBlock)
      {
       _hasBlock = hasBlock;
       if (!_hasElementBlock)
        {
         invalidate(_expandHideWidth + _prefixWidth + _blockPosition - _scroll,
                    _blockWidth);
        }
      }
    }

   /**
    * Re-set the block selection information for this line.
    */
   void setBlock(int blockPosition, int blockWidth)
    {
     if (_blockPosition != blockPosition || _blockWidth != blockWidth)
      {
       // 1.- line previously had a selection != element
       if (_hasBlock && !_hasElementBlock)
        {
         // (a) new selection starts at same point like previous one
         if (_blockPosition == blockPosition)
          {
           if (blockWidth > _blockWidth)
            {
             invalidate(_expandHideWidth + _prefixWidth + _blockPosition - _scroll + _blockWidth,
                        blockWidth - _blockWidth);
            }
           else
            {
             invalidate(_expandHideWidth + _prefixWidth + blockPosition - _scroll + blockWidth,
                        _blockWidth - blockWidth);
            }
          }

         // (b) new & previous selections end at the same point
         else if (_blockPosition + _blockWidth == blockPosition + blockWidth)
          {
           if (blockPosition < _blockPosition)
            {
             invalidate(_expandHideWidth + _prefixWidth + blockPosition - _scroll,
                        _blockPosition - blockPosition);
            }
           else
            {
             invalidate(_expandHideWidth + _prefixWidth + _blockPosition - _scroll,
                        blockPosition - _blockPosition);
            }
          }

         // (c) all other cases: invalidate both current & previous selections
         else
          {
           invalidate(_expandHideWidth + _prefixWidth + blockPosition - _scroll,
                      blockWidth);
           invalidate(_expandHideWidth + _prefixWidth + _blockPosition - _scroll,
                      _blockWidth);
          }
        }
       // no invalidation needed for the other cases:
       //  if had/has element block, see setHasElementBlock();
       //  if didn't have a block, ...

       // 2.- set line's new block selection info
       _blockPosition = blockPosition;
       _blockWidth = blockWidth;
      }
    }

   void setHasElementBlock(boolean hasElementBlock)
    {
     if (_hasElementBlock != hasElementBlock)
      {
       _hasElementBlock = hasElementBlock;
       invalidate(_expandHideWidth + _prefixWidth, width);
      }
    }

   void setEmphasisWidth(int emphasisWidth)
    {
     if (_emphasisWidth != emphasisWidth)
      {
       invalidate(_expandHideWidth + _prefixWidth + _cursorPosition - _scroll,
                  (_emphasisWidth > emphasisWidth)? _emphasisWidth : emphasisWidth);
       _emphasisWidth = emphasisWidth;
       invalidate(_expandHideWidth + _prefixWidth, width);
      }
    }

   void setScroll(int scroll)
    {
     if (_scroll != scroll)
      {
       _scroll = scroll;
       invalidate(_expandHideWidth + _prefixWidth, width);
      }
    }

   void setPrefixScroll(int prefixScroll)
    {
     if (_prefixScroll != prefixScroll)
      {
       _prefixScroll = prefixScroll;
       invalidate(_expandHideWidth, _prefixWidth);
      }
    }

   /**
    * Paint a rectangle in a certain style, with an optional [partial] text
    * of the line.
    * The setClipping() was done beforehand.
    */
   private void drawString(LpexGC g, StyleAttributes styleAttributes,
                           int rectX, int rectWidth, int textX,
                           TextWindowString text)
    {
     drawString(g, styleAttributes,
                rectX, rectWidth, textX,
                (text != null)? text._string : null,  // entire line's text[]
                0,                                    // index in text[]
                (text != null)? text._length : 0);    //  & length
    }

   /**
    * Paint a rectangle in a certain style, with an optional [partial] text
    * from a subline.
    * The setClipping() was done beforehand.
    */
   private void drawString(LpexGC g, StyleAttributes styleAttributes,
                           int rectX, int rectWidth, int textX,
                           char text[], int index, int len)
    {
     g.setBackground(styleAttributes.backgroundColor());
     g.gc.fillRectangle(rectX, y, rectWidth, height);
     g.setForeground(styleAttributes.foregroundColor());

     if (len > 0)
      {
       //-as- to verify - take this x.cpp file:
       //     1 2 3 4 5 6 7 8    9
       //     a b c d e f g h i
       //     #              define
       //     a 1 b 2 c 3 d 4 // abc
       //     int long short
       //with a rectangular block from 3,7 to 5,17 - there seem to be
       //unnecessary repaints going on (unless they are different clippings -
       //one paint for text, a repaint for selection, and one for cursor)?!
       //System.out.println(" drawing " + new String(text, index, len));

       //awt: g.drawChars(text, index, len, textX, _textPosition);
       g.gc.drawString(new String(text, index, len), // string
                       textX,                        // x
                       _textPosition,                // y
                       // already filled background, draw transparently...
                       true);
       if (styleAttributes.outline())
        {
         int w = _textFontMetrics.substringWidth(text, index, index + len);
         g.gc.drawRoundRectangle(textX, y, w /*-1*/, height - 1,
                                 _textFontMetrics.spaceWidth() / 3,
                                 _textFontMetrics.spaceWidth() / 3);
        }
      }

     if (styleAttributes.underline())
      {
       g.gc.drawLine(rectX, y + height - 1, rectX + rectWidth, y + height - 1);
      }
    }

   // setClipping() was done beforehand...
   private void drawExpandHide(LpexGC g)
    {
     drawString(g, _expandHideStyleAttributes,
                x,
                _expandHideWidth,
                0,
                _expandHideText);
    }

   // setClipping() was done beforehand...
   private void drawPrefix(LpexGC g)
    {
     drawString(g, _prefixStyleAttributes,
                x + _expandHideWidth,
                _prefixWidth,
                _expandHideWidth - _prefixScroll,
                _prefixText);
    }

   // setClipping() was done beforehand...
   private void drawSelectedPrefixText(LpexGC g)
    {
     drawString(g, _selectionStyleAttributes,
                x + _expandHideWidth,
                _prefixWidth,
                _expandHideWidth - _prefixScroll,
                _prefixText);
    }

   /**
    * Draw the text with the selection style attributes.
    * The setClipping() was done beforehand.
    */
   private void drawSelectedText(LpexGC g)
    {
     drawString(g, _selectionStyleAttributes,
                x + _expandHideWidth + _prefixWidth,
                width - _prefixWidth - _expandHideWidth,
                _expandHideWidth + _prefixWidth - _scroll,
                _text);
    }

   // setClipping() was done beforehand...
   private void drawEmphasis(LpexGC g)
    {
     drawString(g, _emphasisStyleAttributes,
                x + _expandHideWidth + _prefixWidth,
                width - _prefixWidth - _expandHideWidth,
                _expandHideWidth + _prefixWidth - _scroll,
                _text);
    }

   /**
    * Retrieve a subline from the availables cache, or create a new one if
    * cache exhausted.
    */
   private SubLine getNewSubLine()
    {
     if (_cachedSubLines == null)
      {
       return new SubLine();
      }
     SubLine subLine = _cachedSubLines;
     _cachedSubLines = subLine._next;
     subLine._next = null;
     return subLine;
    }

   /**
    * Set up the sublines (segments) to draw for this line.
    */
   void validateSubLines()
    {
     if (_subLinesValid)
      {
       return;
      }

     int textLength = (_text != null)? _text._length : 0;
     int length = (_textStyleAttributesLength > textLength)?
                   _textStyleAttributesLength : textLength;
     SubLine lastSubLine = null;

     /*======================================================================*/
     /*  go on until the longer of line's text / styles string exhausted...  */
     /*======================================================================*/
     int i = 0; // ZERO-based index into line's text and/or styles arrays
     while (i < length)
      {
       /*----------------------------------------------------------------------*/
       /*  establish a segment of uniform style & bidi direction for painting  */
       /*----------------------------------------------------------------------*/
       StyleAttributes styleAttributes = (i < _textStyleAttributesLength)?
                                         _textStyleAttributes[i] : null;
       if (styleAttributes == null)
        {
         styleAttributes = _defaultStyleAttributes;
        }

       int subTextLength = 1;
       int nextIndex = i + 1;
       while (nextIndex < length)
        {
         StyleAttributes styleAttributesNext = (nextIndex < _textStyleAttributesLength)?
                                               _textStyleAttributes[nextIndex] : null;
         if (styleAttributesNext == null)
          {
           styleAttributesNext = _defaultStyleAttributes;
          }

         // 1.- if this character's style differs from the next, time to call it a subline
         if (!styleAttributes.equals(styleAttributesNext))
          {
           // optimize number of sublines generated - ignore foreground-color
           // difference if we are dealing with spaces inside the text
           if (nextIndex > textLength || _text._string[nextIndex] != ' ' ||
               !styleAttributes.equalsInPainting(styleAttributesNext))
            {
             break;
            }
          }

         // 2.- also a subline if change in the bidi presentation direction (RTL <-> LTR)
         //*as* ...

         subTextLength++;
         nextIndex++;
        }

       /*-----------------------------------------*/
       /*  set up a new text segment for drawing  */
       /*-----------------------------------------*/
       SubLine subLine = getNewSubLine();
       int left;
       if (lastSubLine != null)
        {
         lastSubLine._next = subLine;
         left = lastSubLine.right();
        }
       else
        {
         _topSubLine = subLine;
         left = 0;
        }

       lastSubLine = subLine;
       subLine.set(this, left, i, subTextLength, styleAttributes);

       i += subTextLength;
      }

     _subLinesValid = true;
    }

   /**
    * Paint the invalidated region of the line from startClip for
    * clipWidth, by drawing all its sublines (segments) inside this region.
    */
   private void drawText(LpexGC g, int startClip, int clipWidth)
    {
     // 1.- set up the sublines (segments) to draw for this line
     validateSubLines();

     // 2.- paint the sublines
     SubLine lastSubLine = null;
     for (SubLine subLine = _topSubLine;
          subLine != null;
          subLine = subLine._next)
      {
       subLine.draw(g, startClip, clipWidth);
       lastSubLine = subLine;
      }

     // 3.- paint any leftover space
     int padRectangleStart = startClip > (_expandHideWidth + _prefixWidth)?
                             startClip : (_expandHideWidth + _prefixWidth);
     if (lastSubLine != null)
      {
       int textEnd = _expandHideWidth + _prefixWidth + lastSubLine.right() - _scroll;
       if (textEnd > padRectangleStart)
        {
         padRectangleStart = textEnd;
        }
      }

     if (padRectangleStart <= startClip + clipWidth)
      {
       g.setBackground(_defaultStyleAttributes.backgroundColor());
       g.gc.fillRectangle(padRectangleStart, y,
                          startClip + clipWidth - padRectangleStart, height);
      }
    }

   /**
    * Paint the invalidated section of the line.
    */
   private void paint(LpexGC g)
    {
     if (!valid())
      {
       boolean reverseCursor = !_hasElementBlock;
       g.setFont(_font);

       // make access to SWT's GC easier
       GC gc = g.gc;

       // awt: getClip() - Gets the current clipping area.  This method returns the
       //      user clip, which is independent of the clipping associated
       //      with device bounds and window visibility.  If no clip has previously
       //      been set, or if the clip has been cleared using setClip(null), this
       //      method returns null.
       // Shape originalClip = g.getClip();
       Rectangle originalClip = gc.getClipping(); // save current clip

       /*==============================*/
       /*  paint the expand/hide area  */
       /*==============================*/
       if (_expandHideWidth > 0 &&
           _expandHideWidth >= _invalidPosition)
        {
         // AWT: clipRect() - *Intersects the current clip* with the specified
         //       rectangle.  The resulting clipping area is the intersection of
         //       the current clipping area and the specified rectangle. If there
         //       is no current clipping area, either because the clip has never
         //       been set, or the clip has been cleared using setClip(null), the
         //       specified rectangle becomes the new clip.  This method sets the
         //       user clip, which is independent of the clipping associated with
         //       device bounds and window visibility.  This method can only be
         //       used to make the current clip smaller.  To set the current clip
         //       larger, use any of the setClip methods.  Rendering operations
         //       have no effect outside of the clipping area.
         //      setClip() - *Sets* the current clip to the rectangle specified
         //       by the given coordinates.
         //
         // SWT: setClipping() - *Sets* the area of the receiver which can be
         //       changed by drawing operations to the rectangular area specified
         //       by the argument.
         gc.setClipping(_invalidPosition, y,
                        _expandHideWidth - _invalidPosition, height);
         drawExpandHide(g);

         // adjust validation info to start with prefix area
         _invalidWidth -= _expandHideWidth - _invalidPosition;
         if (_invalidWidth < 0)
          {
           _invalidWidth = 0;
          }
         _invalidPosition = _expandHideWidth;
        }

       /*=========================*/
       /*  paint the prefix area  */
       /*=========================*/
       int marginWidth = _expandHideWidth + _prefixWidth; // for convenience
       if (_prefixWidth > 0 && _invalidWidth > 0 &&
           marginWidth >= _invalidPosition)
        {
         gc.setClipping(_invalidPosition, y, marginWidth - _invalidPosition, height);
         drawPrefix(g);
         if (_cursorVisible && _hasPrefixCursor &&
             _expandHideWidth + _prefixCursorPosition - _prefixScroll <=
                _invalidPosition + _invalidWidth &&
             _expandHideWidth + _prefixCursorPosition - _prefixScroll + _prefixCursorWidth >=
                _invalidPosition)
          {
           //*as* AWT intersects (further constrains) here!
           gc.setClipping(_expandHideWidth + _prefixCursorPosition - _prefixScroll, y,
                          _prefixCursorWidth, height);
           drawSelectedPrefixText(g);
           setImeLocation(_expandHideWidth + _prefixCursorPosition - _prefixScroll, y);
          }

         // adjust validation info to start with text area
         _invalidWidth -= marginWidth - _invalidPosition;
         if (_invalidWidth < 0)
          {
           _invalidWidth = 0;
          }
         _invalidPosition = marginWidth;
        }

       /*==================*/
       /*  paint the text  */
       /*==================*/
       if (_invalidWidth > 0)
        {
         // set up a clipping rectangle for the invalid area of the text
         Rectangle invalidTextClip = new Rectangle(_invalidPosition, y, _invalidWidth, height);
         Rectangle partClip;

         /*---------------------------------------------------*/
         /*  (a) ELEMENT block: draw entire text as selected  */
         /*---------------------------------------------------*/
         if (_hasElementBlock)
          {
           gc.setClipping(invalidTextClip);
           drawSelectedText(g);
          }

         /*----------------------------------------------------------------------------*/
         /*  (b) no selection in clip region (invalid area): draw all as regular text  */
         /*----------------------------------------------------------------------------*/
         else if (!_hasBlock ||
                  _blockWidth == 0 ||
                  marginWidth + _blockPosition - _scroll > _invalidPosition + _invalidWidth ||
                  marginWidth + _blockPosition - _scroll + _blockWidth < _invalidPosition)
          {
           gc.setClipping(invalidTextClip);
           drawText(g, _invalidPosition, _invalidPosition + _invalidWidth);
          }

         /*---------------------------------------------------------*/
         /*  (c) invalid area has a mix of regular & selected text  */
         /*---------------------------------------------------------*/
         else
          {
           // 1.- draw any regular text up to the selection
           if (marginWidth + _blockPosition - _scroll > _invalidPosition)
            {
             // restrain text clip to the piece before selection
             partClip = invalidTextClip.intersection(
                new Rectangle(_invalidPosition,                       // x
                              y,                                      // y
                              marginWidth + _blockPosition - _scroll, // width
                              height));                               // height
             gc.setClipping(partClip);
             drawText(g, _invalidPosition,                      // clip start
                      marginWidth + _blockPosition - _scroll);  // clip width
            }

           // 2.- draw selection
           // restrain invalid-area text clip by the selection part, if needed
           if (marginWidth + _blockPosition - _scroll > _invalidPosition)
            {
             partClip = invalidTextClip.intersection(
                new Rectangle(marginWidth + _blockPosition - _scroll, // x
                              y,                                      // y
                              _blockWidth,                            // width
                              height));                               // height
             gc.setClipping(partClip);
            }
           else
            {
             gc.setClipping(invalidTextClip);
            }
           drawSelectedText(g);

           // 3.- draw any remaining regular text
           int remainingTextStart = marginWidth + _blockPosition - _scroll + _blockWidth;
           if (remainingTextStart < _invalidPosition + _invalidWidth)
            {
             // set clip to the remaining invalid text
             gc.setClipping(remainingTextStart,                                    // x
                            y,                                                     // y
                            _invalidPosition + _invalidWidth - remainingTextStart, // width
                            height);                                               // height
             drawText(g, remainingTextStart,                                  // clip start
                      _invalidPosition + _invalidWidth - remainingTextStart); // clip width
            }

           if (_cursorPosition >= _blockPosition &&
               _cursorPosition < _blockPosition + _blockWidth)
            {
             reverseCursor = false;
            }
          }

         /*======================*/
         /*  paint any emphasis  */
         /*======================*/
         if (_emphasisWidth > 0 &&
             marginWidth + _cursorPosition - _scroll <= _invalidPosition + _invalidWidth &&
             marginWidth + _cursorPosition - _scroll + _emphasisWidth >= _invalidPosition)
          {
           // constrain invalid-text clip by the emphasis section
           partClip = invalidTextClip.intersection(
              new Rectangle(marginWidth + _cursorPosition - _scroll, // x
                            y,                                       // y
                            _emphasisWidth,                          // width
                            height));                                // height
           gc.setClipping(partClip);
           drawEmphasis(g);
          }

         /*====================*/
         /*  paint any cursor  */
         /*====================*/
         if (_cursorVisible && _hasCursor &&
             marginWidth + _cursorPosition - _scroll <= _invalidPosition + _invalidWidth &&
             marginWidth + _cursorPosition - _scroll + _cursorWidth >= _invalidPosition)
          {
           // constrain invalid-text clip by the cursor section
           partClip = invalidTextClip.intersection(
              new Rectangle(marginWidth + _cursorPosition - _scroll,
                            y,
                            _cursorWidth,
                            height));
           gc.setClipping(partClip);
           if (reverseCursor)  // e.g., black on top of regular text
            {
             drawSelectedText(g);
            }
           else                // e.g., white inside a selection
            {
             drawText(g, marginWidth + _cursorPosition - _scroll, _cursorWidth);
            }
           setImeLocation(marginWidth + _cursorPosition - _scroll, y);
          }
        }

       gc.setClipping(originalClip); // remove any clip set in here
       validate();
      }
    }

   void invalidate(int invalidPosition, int invalidWidth)
    {
     if (invalidPosition < 0)
      {
       invalidWidth -= -invalidPosition;
       invalidPosition = 0;
      }

     if (invalidPosition + invalidWidth > width)
      {
       invalidWidth = width - invalidPosition;
      }

     if (invalidWidth > 0)
      {
       if (valid())
        {
         _invalidPosition = invalidPosition;
         _invalidWidth = invalidWidth;
        }
       else
        {
         if (invalidPosition < _invalidPosition)
          {
           _invalidWidth += _invalidPosition - invalidPosition;
           _invalidPosition = invalidPosition;
          }

         if (invalidPosition + invalidWidth > _invalidPosition + _invalidWidth)
          {
           _invalidWidth = invalidPosition + invalidWidth - _invalidPosition;
          }
        }
      }
    }

   void validate()
    {
     _invalidWidth = 0;
    }

   boolean valid()
    {
     return _invalidWidth == 0;
    }

   void update(/*Rectangle r*/)
    {
     if (!valid())
      {
       //if (r.width == 0) { // (a) first area to invalidate
       // r.x = _invalidPosition;
       // r.y = y;
       // r.width = _invalidWidth;
       // r.height = height;
       // }
       //else // (b) a new area to invalidate
       //  r.add(new Rectangle(_invalidPosition, y, _invalidWidth, height));

       // awt: repaint() - Adds the specified region to the dirty region list if
       //      the component is showing.  The component will be repainted after
       //      all of the currently pending events have been dispatched.
       // repaint(0, _invalidPosition, y, _invalidWidth, height);
       // swt: redraw() - This method damages an area within the widget or widget
       //      tree so that the next time a paint request is processed, the area
       //      in the widget or widget tree will be redrawn.
       redraw(_invalidPosition, y, _invalidWidth, height, false);
      }
    }

   TextFontMetrics textFontMetrics()
    {
     return _textFontMetrics;
    }

   TextWindowString text()
    {
     return _text;
    }

   int expandHideWidth()
    {
     return _expandHideWidth;
    }

   int prefixWidth()
    {
     return _prefixWidth;
    }

   int scroll()
    {
     return _scroll;
    }
  }


 /**
  * A segment of text to draw.  Each token (== one style for entire string) will
  * normally get its own SubLine for drawing.
  * The text of one Line (which represents one whole line in the TextWindow) may
  * therefore be divided into several SubLines (linked in a list).
  */
 final static class SubLine
 {
  SubLine _next;
  private Line _line;    // the text window Line this segment belongs to

  private int  _left;    // subline's start position inside the Line (in pixels)
  private int  _index;   // subline's char index inside the Line text (ZERO-based)
  private int  _length;  //  & number of actual characters to paint
  private int  _width;   // subline's established width (in pixels)
  private StyleAttributes _styleAttributes; // style attributes for the painting


  void set(Line line, int left, int index, int len, StyleAttributes styleAttributes)
  {
   _line = line;
   _left = left;
   _index = index;
   _styleAttributes = styleAttributes;

   TextWindowString text = line.text();
   int textLength = (text != null)? text._length : 0;

   // 1.- entire subline is inside the line's text
   if (index + len <= textLength)
    {
     _width = _line.textFontMetrics().substringWidth(text._string, index, index + len);
     _length = len;
    }

   // 2.- subline starts inside the line's text, ends beyond it
   else if (index < textLength)
    {
     _width = _line.textFontMetrics().substringWidth(text._string, index, textLength) +
              ((index + len - textLength) * _line.textFontMetrics().spaceWidth());
     _length = textLength - index;
    }

   // 3.- the subline is all spaces beyond the line's text
   else
    {
     _width = len * _line.textFontMetrics().spaceWidth();
     _length = 0;
    }
  }

  void reset()
  {
   _line = null;
   _left = 0;
   _index = 0;
   _length = 0;
   _width = 0;
   _styleAttributes = null;
  }

  int left()
  {
   return _left;
  }

  int right()
  {
   return _left + _width;
  }

  int width()
  {
   return _width;
  }

  void draw(LpexGC g, int startClip, int clipWidth)
  {
   int endClip = startClip + clipWidth;
   if (_line.expandHideWidth() + _line.prefixWidth() + right() - _line.scroll() >= startClip &&
       _line.expandHideWidth() + _line.prefixWidth() + _left - _line.scroll() <= endClip)
    {
     int x = _line.expandHideWidth() + _line.prefixWidth() + _left - _line.scroll();
     TextWindowString text = _line.text();
     _line.drawString(g, _styleAttributes,
                      x, _width, x,                         // rectX, rectWidth, textX
                      (text != null)? text._string : null,  // text[],
                      _index, _length);                     //  index, len in text[]
    }
  }
 }


 /**
  * Char-array representation of a TextWindow string.
  */
 final static class TextWindowString
 {
  char _string[];
  int  _length;
  int  _incrementSize;

  TextWindowString(int minimumLength, int incrementSize)
  {
   _string = new char[minimumLength + incrementSize];
   _incrementSize = incrementSize;
  }

  boolean set(String string)
  {
   boolean different = false;
   if (string == null)
    {
     _length = 0;
     different = true;
    }
   else if (_length != string.length())
    {
     _length = string.length();
     different = true;
    }

   if (_length > 0)
    {
     if (_length > _string.length)
      {
       different = true;
       _string = new char[_length + _incrementSize];
      }

     for (int i = 0; i < _length; i++)
      {
       char c = string.charAt(i);

       // Windows2000 Eclipse:  GC.drawString() doesn't draw TAB
       // characters (no blob, no nothin'), so let's replace '\t's to ' 's
       if (c == '\t' && _displayTabAsSpace)
        {
         c = ' ';
        }

       if (c != _string[i])
        {
         _string[i] = c;
         different = true;
        }
      }
    }

   return different;
  }
 }


 /**
  * Associate some more info to a paint operation's GC.  This way we can cut
  * down on unnecessary GC colour/font re-sets during the paint operation.
  */
 final static class LpexGC
 {
  GC gc; // SWT's graphic context
  private Color _background, _foreground;
  private Font  _font;

  LpexGC(GC g)
  {
   gc = g;
   //_background = LPEX-Color wrapper for initial gc.getBackground() swt-Color
   //_foreground = LPEX-Color wrapper for initial gc.getForeground() swt-Color
  }

  /**
   * Set GC's background color if not already set.
   */
  void setBackground(Color newBackground)
  {
   if (_background == null || !_background.equals(newBackground))
    {
     _background = newBackground;
     gc.setBackground(_background.getColor());
    }
  }

  /**
   * Set GC's foreground color if not already set.
   */
  void setForeground(Color newForeground)
  {
   if (_foreground == null || !_foreground.equals(newForeground))
    {
     _foreground = newForeground;
     gc.setForeground(_foreground.getColor());
    }
  }

  /**
   * Set GC's font if not already set.
   */
  void setFont(Font newFont)
  {
   if (_font == null || !_font.equals(newFont))
    {
     _font = newFont;
     gc.setFont(_font.getFont());
    }
  }
 }
}