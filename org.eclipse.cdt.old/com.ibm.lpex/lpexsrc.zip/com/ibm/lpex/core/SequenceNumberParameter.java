//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SequenceNumberParameter - handle the sequenceNumber parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>sequenceNumber</b> parameter.
 */
final class SequenceNumberParameter extends ParameterIntegerOnly
{
 private static SequenceNumberParameter _parameter;

 static SequenceNumberParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new SequenceNumberParameter();
   }
  return _parameter;
 }

 private SequenceNumberParameter()
 {
  super(PARAMETER_SEQUENCE_NUMBER);
 }

 boolean setValue(View view, String qualifier, int value)
 {
  if (value < 0)
   {
    return CommandHandler.invalidParameter(view, String.valueOf(value), "set " + name());
   }

  if (view != null)
   {
    Element element = view.documentPosition().element();
    if (element != null)
     {
      view.document().elementList().setSequenceNumber(view, element, value);
     }
   }

  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  String sequenceNumber = super.query(view, documentLocation, qualifier);
  if (sequenceNumber != null)      // (NB super.query checks isQueryAvailable())
   {
    int width = view.document().elementList().sequenceNumbersNumWidth();
    while (sequenceNumber.length() < width)
     {
      sequenceNumber = "0" + sequenceNumber;
     }
    if (sequenceNumber.length() > width)
     {
      sequenceNumber = sequenceNumber.substring(sequenceNumber.length() - width);
     }
   }

  return sequenceNumber;
 }

 boolean isQueryAvailable(View view, LpexDocumentLocation documentLocation,
                          String qualifier)
 {
  return view != null && documentLocation != null &&
         view.document().elementList().elementAt(documentLocation.element) != null;
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null && documentLocation != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    if (element != null)
     {
      return element.sequenceNumber();
     }
   }

  return 0;
 }
}