//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterQualifierList
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

abstract class ParameterQualifierList extends ParameterQuery
{
 String _root;

 ParameterQualifierList(String name, String root)
  {
   super(name);
   _root = root;
  }

 boolean hasInstallSetting()
  {
   return true;
  }

 boolean hasDefaultSetting()
  {
   return true;
  }

 boolean hasCurrentSetting()
  {
   return true;
  }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   if (view != null)
    {
     KeyedList keyedList = value(view);
     if (keyedList != null)
      {
       return keyedList.keyList();
      }
    }

   return null;
  }

 abstract KeyedList value(View view);

 String queryInstall(String qualifier)
  {
   return installValue().keyList();
  }

 KeyedList installValue()
  {
   KeyedList keyedList = new KeyedList();
   String installRoot = PARAMETER_INSTALL + _root;
   int installRootLength = installRoot.length();

   LpexStringTokenizer st = new LpexStringTokenizer(Install.getKeys());
   while (st.hasMoreTokens())
    {
     String key = st.nextToken();
     if (key.startsWith(installRoot))
      {
       String value = Install.getString(key);
       key = key.substring(installRootLength);
       keyedList.set(key, value);
      }
    }

   return keyedList;
  }

 String queryDefault(String qualifier)
  {
   return defaultValue().keyList();
  }

 KeyedList defaultValue()
  {
   KeyedList keyedList = new KeyedList();
   String defaultRoot = PARAMETER_DEFAULT + _root;
   int defaultRootLength = defaultRoot.length();

   LpexStringTokenizer st = new LpexStringTokenizer(Profile.getKeys());
   while (st.hasMoreTokens())
    {
     String key = st.nextToken();
     if (key.startsWith(defaultRoot))
      {
       String value = Profile.getString(key);
       key = key.substring(defaultRootLength);
       keyedList.set(key, value);
      }
    }

   return keyedList;
  }

 String queryCurrent(View view, String qualifier)
  {
   return currentValue(view).keyList();
  }

 KeyedList currentValue(View view)
  {
   KeyedList mergedKeyedList = new KeyedList();
   KeyedList keyedList = installValue();

   LpexStringTokenizer st = new LpexStringTokenizer(keyedList.keyList());
   while (st.hasMoreTokens())
    {
     String key = st.nextToken();
     Object value = keyedList.query(key);
     mergedKeyedList.set(key, value);
    }

   keyedList = defaultValue();
   st = new LpexStringTokenizer(keyedList.keyList());
   while (st.hasMoreTokens())
    {
     String key = st.nextToken();
     Object value = keyedList.query(key);
     if ("null".equals(value))
      {
       value = null;
      }
     mergedKeyedList.set(key, value);
    }

   if (view != null)
    {
     keyedList = value(view);
     if (keyedList != null)
      {
       st = new LpexStringTokenizer(keyedList.keyList());
       while (st.hasMoreTokens())
        {
         String key = st.nextToken();
         Object value = keyedList.query(key);
         if ("null".equals(value))
          {
           value = null;
          }
         mergedKeyedList.set(key, value);
        }
      }
    }

   return mergedKeyedList;
  }
}