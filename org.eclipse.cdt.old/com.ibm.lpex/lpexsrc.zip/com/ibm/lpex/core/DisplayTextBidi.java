//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DisplayTextBidi - bidi information for the display of an element.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Bidi information for the display text of one element in one view.
 * There is up to one instance of this class for each instance of ElementView.
 */
final class DisplayTextBidi
{
   private ElementView _elementView;

   DisplayTextBidi(ElementView elementView)
   {
      _elementView = elementView;
   }

   /**
    * ElementView's _displayText was re-set / changed:  invalidate any bidi
    * information cached in here.
    */
   void reset()
   {
      //*as* *as* *as*
   }
}