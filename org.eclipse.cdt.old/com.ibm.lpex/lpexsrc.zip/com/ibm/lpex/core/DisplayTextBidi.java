//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DisplayTextBidi - bidi information for the display of an element.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.internal.BidiUtil;


/**
 * Bidi information for the display text of one element in one view.
 * There is up to one instance of this class for each instance of ElementView.
 *
 * <p>This class should be instantiated, and its methods called, <b>only</b>
 * when LpexUtilities#isBidi() returns true.
 * This is the Eclipse R2.0 version, which includes bidirectional support
 * on MS Windows when the local machine is bidi.
 * See also org.eclipse.swt.custom.StyledTextBidi.
 *
 * <p>LPEX is programming editor (see "Guidelines for a Logical Bidi User
 * Interface", Matitiahu Allouche, matial@il.ibm.com - Globalization Center
 * of Competency, Bidirectional Scripts) - a text application used to write
 * a formal language (such as a programming language or HTML) where most
 * syntactic elements of the language (keywords, identifiers) are in English,
 * while character values and comments may be in any language.  Its bidi
 * support is, therefore, kept a minimum.
 */
final class DisplayTextBidi
{
   private ElementView _elementView;

   /*---------------------------------*/
   /* bidi order & render information */
   /*---------------------------------*/
   // the glyphs in visual order as they will be rendered on screen,
   // null if not (yet) established
   private char[] glyphBuffer;

   // stored as:     city TELAVIV center            logical    iL              order[]
   //                      -
   // rendered as:   city VIVALET center            visual     iV=order[iL]    dx[]
   //                          -

   // stored as:     ligatures ARABIC XXYY shaped   logical                    order[]
   //                                 -
   // rendered as:   ligatures YX CIBARA shaped     visual     glyphBuffer[]   dx[]
   //                           -

   //*as* MUST ALSO INVALIDATE ON displayStyle CHANGES - defines segments which must be
   // rendered separately - changing a line from all-comments to tokenized code may
   // change the rendering order of bidi text (see old LPEX / Eclipse if they do this)

   private int[] bidiSegments;    // bidi text segments, each segment will be rendered separately
   private int[] renderPositions; // x position at which chars of the line are rendered, in visual order
   private int[] order;           // reordering indices in logical order:
                                  //  iV=order[iL] (iV=visual index, iL=logical index),
                                  // if no char in a line needs reordering, all iV and iL are the same
   private int[] dx;              // distance between char cells, in visual order:
                                  //  renderPositions[iV + 1] = renderPositions[iV] + dx[iV]
   private byte[] classBuffer;    // char types in logical order, see BidiUtil for possible types


   /**
    * Construct a DisplayTextBidi for one ElementView.
    */
   DisplayTextBidi(ElementView elementView)
   {
      _elementView = elementView;
   }

   /**
    * ElementView's _displayText was re-set / changed:  invalidate any bidi
    * information cached in here.
    */
   void reset()
   {
      glyphBuffer = null;
   }

   /**
    * Return the visual pixel position in the displayText for the logical
    * <code>displayPosition</code> in it (accumulated glyph widths up to that point).
    *
    * @param position ONE-based position in the logical display text
    */
   int pixelPosition(int displayPosition)
   {
      int iL = displayPosition - 1; // ZERO-based iL
      if (iL < 0)
         return 0;

      validateBidiInfo();

      int pixelPosition = 0;

      String text = _elementView.displayText();
      /*-------------------------------*/
      /*  (a) inside the display text  */
      /*-------------------------------*/
      if (text.length() > iL) {
         int iV = order[iL];
         for (int i = 0;  i < iV; i++)
            pixelPosition += dx[i];
         //System.out.println("\niL="+displayPosition+", iV="+iV+", pixelPosition="+pixelPosition);
         }

      /*-----------------------------------*/
      /*  (b) at / beyond end of the text  */
      /*-----------------------------------*/
      else {
         TextFontMetrics textFontMetrics = _elementView.view().screen().textFontMetrics();
         pixelPosition = width() +
            textFontMetrics.spaceWidth() * (iL - text.length());
         //System.out.println("\niL="+displayPosition+", pixelPosition="+pixelPosition);
         }

      return pixelPosition;
   }

   /**
    * Returns the visual display offset of the character at the specified
    * visual pixel position located inside the text.
    *
    * @param pixelPosition in the display text
    */
   private int getVisualOffset(int pixelPosition)
   {
      // ASSUME validateBidiInfo();

      int lineLength = _elementView.displayText().length();
      int low = -1;
      int high = lineLength;

      while (high - low > 1) {
         int offset = (high + low) / 2;
         int visualX = renderPositions[offset];

         // visualX + dx is the start of the next character;  restrict right/high
         // search boundary only if pixelPosition is before the next character
         if (pixelPosition < visualX + dx[offset]) {
            high = offset;
            }
         else if (high == lineLength && high - offset == 1) {
            // requested pixelPosition is past end of line
            high = -1;
            }
         else {
            low = offset;
            }
         }

      return high;
   }

   /**
    * Returns the logical offset of the character at the specified
    * visual offset in the display text.
    *
    * @param visualOffset ZERO-based visual offset
    * @return the ZERO-based logical offset of the character
    */
   private int logicalOffset(int visualOffset)
   {
      // ASSUME validateBidiInfo();

      int logicalOffset = 0;
      int len = _elementView.displayText().length();
      while (logicalOffset < len && order[logicalOffset] != visualOffset)
         logicalOffset++;

      return logicalOffset;
   }

   /**
    * Return the position in the logical display text of the character at the
    * given pixel position located inside the display text.
    */
   int displayPosition(int pixelPosition)
   {
      validateBidiInfo();

      //if (_elementView.displayText().length() == 0)
      // return 0;
      //if (pixelPosition >= renderPositions[renderPositions.length - 1] + dx[dx.length - 1])
      // // return when pixelPosition is past the end of the line
      // return -1;

      int visualOffset = getVisualOffset(pixelPosition);
      return logicalOffset(visualOffset) + 1;
   }

   /**
    * Return the width in pixels of the display text.
    */
   int width()
   {
      validateBidiInfo();

      //-as- assuming the current allocation, re renderPositions.length & dx.length
      return renderPositions[renderPositions.length - 1] + dx[dx.length - 1];
   }

   /**
    * Return the width in pixels of the character rendered at the specified
    * position in displayPosition.
    */
   int charWidth(int displayPosition)
   {
      displayPosition--; // ZERO-base logical index
      //if (displayPosition >= _elementView.displayText().length())
      // return _elementView.view().screen().textFontMetrics().spaceWidth();

      validateBidiInfo();

      return dx[order[displayPosition]];
   }

   /**
    * Return the direction of the character at the specified position in
    * displayText.  Used for rendering and cursor positioning, where local
    * numbers (e.g., national Arabic, or Hindi, numbers) are considered LTR.
    *
    * @param displayPosition ONE-based position in the logical display text
    * @return true = the character at the specified index is in a RTL
    *                codepage (Hebrew, Arabic), OR
    *         false = the character at the specified index is in a LTR / Latin
    *                 codepage
    */
   boolean isRightToLeft(int displayPosition)
   {
      validateBidiInfo();

      String text = _elementView.displayText();
      if (--displayPosition >= text.length())
         return false;

      return classBuffer[displayPosition] == BidiUtil.CLASS_ARABIC ||
             classBuffer[displayPosition] == BidiUtil.CLASS_HEBREW;
   }

   /**
    * Ensure the bidi information we have is valid for this ElementView.
    */
   private void validateBidiInfo()
   {
      if (glyphBuffer != null)
         return;

      String displayText = _elementView.displayText();

      GC g = null;
      Screen screen = _elementView.view().screen();
      TextWindow textWindow = screen.textWindow();
      if (textWindow != null) {
         g = new GC(textWindow);
         g.setFont(screen.currentFont().getFont());
         }

      if (g != null) {
         int len = displayText.length();
         //*as* use any previous arrays if available & smaller/equal!
         renderPositions = new int[len];
         order = new int[len];
         classBuffer = new byte[len];
         dx = new int[len];

         //*as* tokens - the text segments that should be treated as if they
         // had a different direction than the surrounding text
         int[] offsets = new int[] {0, len};

         if (len == 0) {
            glyphBuffer = new char[0];
            }
         else {
            glyphBuffer = BidiUtil.getRenderInfo(
               g,
               displayText,
               order,
               classBuffer,
               dx,
               0,           // flags
               offsets);

            renderPositions[0] = 0;
            for (int i = 0; i < len - 1; i++)
               renderPositions[i + 1] = renderPositions[i] + dx[i];
            }

         g.dispose();
         }
      //System.out.println(toString());
   }

   /**
    * Display the DisplayTextBidi internal state, used in debugging.
    */
   public String toString()
   {
      if (glyphBuffer == null)
         return "DisplayTextBidi { " + _elementView.displayText() + " }";

      StringBuffer buf = new StringBuffer();
      buf.append("DisplayTextBidi {\"" + _elementView.displayText() + "\"\n order  ");

      // order
      for (int i = 0; i < order.length; i++) {
         if (i != 0)
            buf.append(",");
         buf.append(order[i]);
         }

      // render positions
      buf.append("\n render ");
      for (int i = 0; i < renderPositions.length; i++) {
         if (i != 0)
         buf.append(",");
         buf.append(renderPositions[i]);
         }

      // dx
      buf.append("\n dx     ");
      for (int i = 0; i < dx.length; i++) {
         if (i != 0)
            buf.append(",");
         buf.append(dx[i]);
         }

      // character class
      buf.append("\n class  ");
      for (int i = 0; i < classBuffer.length; i++) {
         if (i != 0)
            buf.append(",");
         buf.append(classBuffer[i]);
         }

      // glyphs
      buf.append("\n glyphs ");
      buf.append(glyphBuffer);
      buf.append("}");
      return buf.toString();
   }
}