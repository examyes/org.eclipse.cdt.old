//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ShiftOutCharacterParameter - handles the shiftOutCharacter parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>shiftOutCharacter</b> parameter.
 */
final class ShiftOutCharacterParameter extends ParameterCharacterDefault
{
 private static ShiftOutCharacterParameter _parameter;

 static ShiftOutCharacterParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ShiftOutCharacterParameter();
   }
  return _parameter;
 }

 private ShiftOutCharacterParameter()
 {
  super(PARAMETER_SHIFT_OUT_CHARACTER, ' '); // or '\u000e' or '[' or '>'
 }

 /**
  * Set the <b>shiftOutCharacter</b> parameter for this view.
  */
 boolean setValue(View view, String qualifier, char value)
 {
  if (view != null)
   {
    char oldValue = view.nls().currentShiftOutCharacter();
    if (!view.nls().setSO(value))
     {
      return CommandHandler.invalidParameter(view, String.valueOf(value), "set " + name());
     }
    if (oldValue != view.nls().currentShiftOutCharacter())
     {
      view.showSosiChanged(); // take a ride on this notification...
     }
   }

  return true;
 }

 void currentValueChanged(View view)
 {
  view.showSosiChanged(); // take a ride on this notification...
 }

 char value(View view)
 {
  return (view != null)? view.nls().SO : 0;
 }
}