//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CursorListenerList - handles a view's list of LpexCursorListeners.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages the LpexCursorListeners for a document view.
 * There is up to one instance of this class created for each View.
 */
final class CursorListenerList extends List
{
 private View _view;
 private Element _lastCursorElement;


 CursorListenerList(View view)
 {
  _view = view;
  _lastCursorElement = _view.documentPosition().element();
 }

 /**
  * Add an LpexCursorListener.  A listener is only registered once, additional
  * calls are without effect.
  */
 void addListener(LpexCursorListener listener)
 {
  if (find(listener) == null)
   {
    addAfter(null, new ListenerNode(listener));
   }
 }

 /**
  * Remove an LpexCursorListener, if registered.
  */
 void removeListener(LpexCursorListener listener)
 {
  if (listener != null)
   {
    ListenerNode node = find(listener);
    if (node != null)
     {
      remove(node);
     }
   }
 }

 /**
  * Send the <i>elementChanged</i> notification to all registered
  * LpexCursorListeners, if the element that the cursor is on changed
  * since the last notification.
  */
 void elementChanged()
 {
  Element currentCursorElement = _view.documentPosition().element();
  if (_lastCursorElement != currentCursorElement)
   {
    beginScanning();
    for (ListenerNode node = (ListenerNode)first();
         node != null;
         node = (ListenerNode)node.next())
     {
      node.listener().elementChanged(_view.lpexView());
     }
    endScanning();
    _lastCursorElement = currentCursorElement;
   }
 }

 /**
  * Find a registered LpexCursorListener for this View.
  */
 ListenerNode find(LpexCursorListener listener)
 {
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    if (node.listener() == listener)
     {
      return node;
     }
   }
  return null;
 }


 /**
  * Node for one LpexCursorListener in a CursorListenerList.
  */
 private static class ListenerNode extends ListNode
 {
  private LpexCursorListener _listener;

  ListenerNode(LpexCursorListener listener)
  {
   _listener = listener;
  }

  LpexCursorListener listener()
  {
   return _listener;
  }
 }
}