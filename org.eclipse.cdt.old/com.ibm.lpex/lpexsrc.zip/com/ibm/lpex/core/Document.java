//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Document - manage a document.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;


/**
 * This class manages an LPEX document.
 */
final class Document extends ListNode
{
 private static int _lastDocId;
 private int _id;

 private String _name;

 static Document _firstDocument;
 Document _next;

 // the list of Views on this Document
 View _firstView;

 // this Document's elements
 ElementList _elementList;

 // lines before & after the loaded document section
 private int _linesBeforeStart;
 private int _linesAfterEnd;

 private DocumentSectionListenerList  _documentSectionListenerList;
 private boolean _triggeringDocumentSectionListeners;

 // throw out the garbage from time to time
 private static int gcCounter;

 // Document's record/undo/redo handler
 private Undo _undo;

 private SequenceNumbersParameter.Settings _sequenceNumbersSettings;
 private SaveCommand.Settings _saveCommandSettings;

 // NLS info - current values in effect must be retrieved via LpexNls:
 // useSourceColumns PARAMETER - Unicode char columns / source [byte] columns
 private int _useSourceColumns = Parameter.DEFAULT;
 // sourceEncoding PARAMETER - encoding of origin / target doc file platform
 String _sourceEncoding;
 // is the source character encoding DBCS/MBCS?
 boolean _sourceMbcs;
 // is the source encoding EBCDIC DBCS (uses SO/SI controls)?
 boolean _sourceSosi;


 /**
  * Document constructor.
  */
 Document(String name, LpexView lpexView, boolean updateProfile)
  {
   _id = ++_lastDocId;

   // link ourselves into the Documents list
   _next = _firstDocument;
   _firstDocument = this;

   setName(name);
   View view = new View(lpexView, this, updateProfile);
   elementList().addAfter(view, null, new Element(this));
   view.nls().setSourceEncoding(null); // initial source encoding = native

   if (name() != null)
    {
     load(view);
    }

   if (updateProfile)
    {
     view.updateProfile();
    }
  }

 /**
  * Dispose of the document.
  */
 void dispose()
  {
   Document prevDocument = null;
   for (Document document = _firstDocument; document != null; document = document._next)
    {
     if (document == this)
      {
       if (prevDocument == null)
        {
         _firstDocument = _next;
        }
       else
        {
         prevDocument._next = _next;
        }
       break;
      }
     prevDocument = document;
    }
  }

 /**
  * Get a unique document id number.
  * Document numbers are not reused (recycled) during an edit session.
  */
 int id()
  {
   return _id;
  }

 /**
  * Set the document name.
  * An LpexViewListener may cancel this operation.
  */
 void setName(String name)
  {
   for (View view = _firstView; view != null; view = view._next)
    {
     if (view.listenerList().renaming())
      {
       return; // listener cancelled renaming...
      }
    }

   _name = name;

   for (View view = _firstView; view != null; view = view._next)
    {
     view.listenerList().renamed();
    }
  }

 /**
  * Retrieve the document name.
  */
 String name()
  {
   return _name;
  }

 /**
  * Load the document from the specified Reader.
  *
  * @param reader FileReader or StringReader
  * @return <code>true</code> if successful
  */
 boolean loadFromReader(View view, Reader reader)
  {
   for (View v = _firstView; v != null; v = v._next)
    {
     v.setReadonly(false);
     v.parsePendingList().setParsing(false);
    }

   undo().setRecording(false);
   undo().clear();

   ElementList elementList = elementList();

   // save sequence numbers setting & disable them temporarily
   int sequenceNumbersNumColumn  = elementList.sequenceNumbersNumColumn();
   int sequenceNumbersNumWidth   = elementList.sequenceNumbersNumWidth();
   int sequenceNumbersTextColumn = elementList.sequenceNumbersTextColumn();
   int sequenceNumbersTextWidth  = elementList.sequenceNumbersTextWidth();
   elementList.setSequenceNumbers(1, 0, 1, 0);

   elementList.clear();

   boolean success = true;
   if (reader != null)
    {
     try
      {
       Element lastElement = null;
       BufferedReader bufferedReader = new BufferedReader(reader);
       for (;;)
        {
         String elementText = bufferedReader.readLine();
         if (elementText == null)
          {
           break;
          }
         Element newElement = new Element(this, elementText);
         elementList.addAfter(view, lastElement, newElement);
         lastElement = newElement;
        }
       bufferedReader.close();
      }
     catch(IOException e)
      {
       success = false;
       if (reader instanceof FileReader)
        {
         view.setLpexMessageText(LpexConstants.MSG_FILE_ERROR_READING, name());
         CommandHandler._status = LpexConstants.STATUS_FILE_ERRORREADING; //?! *as*
        }
      }
    }

   if (elementList().count() == 0)
    {
     elementList.addAfter(view, null, new Element(this));
    }

   // restore sequence numbers setting
   elementList.setSequenceNumbers(sequenceNumbersNumColumn, sequenceNumbersNumWidth,
                                  sequenceNumbersTextColumn, sequenceNumbersTextWidth);

   resetUserActionElements();
   undo().setRecording(true);

   for (View v = _firstView; v != null; v = v._next)
    {
     if (v.updateProfileIssued())
      {
       v.updateProfile();
      }
    }

   return success;
  }

 /**
  * Load the document from the file defined by name().
  */
 void load(View view)
  {
   FileReader fileReader = null;
   if (name() != null)
    {
     try
      {
       fileReader = new FileReader(name());
      }
     catch(FileNotFoundException e)
      {
       view.setLpexMessageText(LpexConstants.MSG_FILE_CREATED, name());
       CommandHandler._status = LpexConstants.STATUS_FILE_NOTFOUND;
      }
    }

   loadFromReader(view, fileReader);
  }

 /**
  * Load the document with the given <code>text</code>.
  */
 void setText(View view, String text)
  {
   StringReader stringReader = null;
   if (text != null)
    {
     stringReader = new StringReader(text);
    }

   loadFromReader(view, stringReader);
  }

 /**
  * Store the entire document text in the given <code>writer</code>.
  */
 boolean saveToWriter(Writer writer)
  {
   try
    {
     BufferedWriter bufferedWriter = new BufferedWriter(writer);
     boolean first = true;
     for (Element element = elementList().first();
          element != null;
          element = element.next())
      {
       if (!element.show())
        {
         if (!first)
          {
           bufferedWriter.newLine();
          }
         String text = element.fullText();
         if (text != null)
          {
           int textLength = text.length();
           if (textLength != 0)
            {
             bufferedWriter.write(text, 0, textLength);
            }
          }
         first = false;
        }
      }
     bufferedWriter.close();
    }
   catch(IOException e)
    {
     return false;
    }

   return true;
  }

 /**
  * Retrieve the entire document text.
  */
 String text()
  {
   StringWriter stringWriter = new StringWriter();
   saveToWriter(stringWriter);
   return stringWriter.toString();
  }

 /**
  * Retrieve the list of elements for this Document.
  * If none yet, create it.
  */
 ElementList elementList()
  {
   if (_elementList == null)
    {
     _elementList = new ElementList(this);
    }
   return _elementList;
  }

 /**
  * Retrieve the record/undo/redo handler for this Document.
  * If none yet, create it.
  */
 Undo undo()
  {
   if (_undo == null)
    {
     _undo = new Undo(this);
    }
   return _undo;
  }

 /**
  * Reset the user action element of each view of this document.
  */
 void resetUserActionElements()
  {
   for (View view = _firstView; view != null; view = view._next)
    {
     view.resetUserActionElement();
    }
  }

 /**
  * Verify the user action element of each view of this document.
  */
 void verifyUserActionElements(Element element)
  {
   for (View view = _firstView; view != null; view = view._next)
    {
     view.verifyUserActionElement(element);
    }
  }

 void elementRemoved(Element element)
  {
   for (View view = _firstView; view != null; view = view._next)
    {
     view.elementRemoved(element);
    }
  }

 void elementInserted(Element element)
  {
   for (View view = _firstView; view != null; view = view._next)
    {
     view.elementInserted(element);
    }
  }

 void parse()
  {
   for (View view = _firstView; view != null; view = view._next)
    {
     view.parsePendingList().parse();
    }
  }

 void addParsePending(Element element, int type)
  {
   for (View view = _firstView; view != null; view = view._next)
    {
     view.parsePendingList().add(element, type);
    }
  }

 void setVisibleElementOrdinalsInvalid()
  {
   for (View view = _firstView; view != null; view = view._next)
    {
     view.setVisibleElementOrdinalsInvalid();
    }
  }

 /**
  * Refresh the screen for all the LPEX document views.
  */
 static void screenShow()
  {
   for (Document document = _firstDocument; document != null; document = document._next)
    {
     for (View view = document._firstView; view != null; view = view._next)
      {
       view.screen().show();
      }
    }

   if (BeepParameter.getParameter().value())
    {
     BeepParameter.getParameter().setValue(false);
     LpexUtilities.beep();
    }

   // ensure we call garbage collector occasionally - every 100 screenShow()s
   gcCounter++;
   if (gcCounter > 100)
    {
     System.gc();
     gcCounter = 0;
    }
  }

 SequenceNumbersParameter.Settings sequenceNumbersSettings()
  {
   if (_sequenceNumbersSettings == null)
    {
     _sequenceNumbersSettings = new SequenceNumbersParameter.Settings();
    }
   return _sequenceNumbersSettings;
  }

 SaveCommand.Settings saveCommandSettings()
  {
   if (_saveCommandSettings == null)
    {
     _saveCommandSettings = new SaveCommand.Settings();
    }
   return _saveCommandSettings;
  }

 int useSourceColumns()
  {
   return _useSourceColumns;
  }

 void setUseSourceColumns(int value)
  {
   _useSourceColumns = value;
  }

 // Document's useSourceColumns parameter toggled - affects Column on the status
 // line, sequence-numbers location, etc.
 //-as- OPTIMIZE?! (it's not changed often, if at all...)
 void useSourceColumnsChanged()
  {
   for (Element element = elementList().first();
        element != null;
        element = element.next())
    {
     for (View view = _firstView; view != null; view = view._next)
      {
       element.elementView(view).resetDisplayText();
      }
    }
  }

 // Document's sourceEncoding parameter changed - affects entire display, etc.
 //-as- OPTIMIZE?! (it's not changed often;  when it is, doc is normally empty)
 void sourceEncodingChanged()
  {
   for (Element element = elementList().first();
        element != null;
        element = element.next())
    {
     for (View view = _firstView; view != null; view = view._next)
      {
       element.elementView(view).resetDisplayText();
      }
    }
  }

 /**
  * Optionally create & return the list for LpexDocumentSectionListeners of
  * this document.
  */
 DocumentSectionListenerList documentSectionListenerList()
  {
   if (_documentSectionListenerList == null)
    {
     _documentSectionListenerList = new DocumentSectionListenerList(this);
    }
   return _documentSectionListenerList;
  }

 /**
  * Called to send notification requests to the document-section listeners
  * registered in this document, to expand the currently-loaded document section.
  */
 void triggerDocumentSectionListeners(LpexView lpexView, int neededLine)
  {
   // prevent recursion from listener's adjustments to the document section
   if (!_triggeringDocumentSectionListeners)
    {
     _triggeringDocumentSectionListeners = true;
     if (_documentSectionListenerList != null)
      {
       _documentSectionListenerList.addLines(lpexView, neededLine);
      }
     _triggeringDocumentSectionListeners = false;
    }
  }

 /**
  * Query whether an LpexDocumentSectionListener addLines() notification is
  * currently being processed.
  */
 boolean triggeringDocumentSectionListeners()
  {
   return _triggeringDocumentSectionListeners;
  }

 /**
  * [Re-]set information for the currently-loaded document section:  the number
  * of lines that were not loaded in the editor (number of lines before the
  * section, number of lines after).
  */
 void setLinesOutsideDocumentSection(int linesBeforeStart, int linesAfterEnd)
  {
   if (linesBeforeStart < 0)
    {
     linesBeforeStart = 0;
    }
   if (linesAfterEnd < 0)
    {
     linesAfterEnd = 0;
    }

   boolean changed = linesBeforeStart != _linesBeforeStart ||
                     linesAfterEnd != _linesAfterEnd;
   _linesBeforeStart = linesBeforeStart;
   _linesAfterEnd = linesAfterEnd;

   // may have to resequence the document
   if (changed)
    {
     if (elementList().sequenceNumbersNumWidth() > 0)
      {
       elementList().resequence();
      }
    }
  }

 int linesBeforeStart()
  {
   return _linesBeforeStart;
  }

 int linesAfterEnd()
  {
   return _linesAfterEnd;
  }

 /**
  * Retrieve the number of lines in the complete document.
  */
 int linesCount()
  {
   return linesBeforeStart() + elementList().nonShowCount() + linesAfterEnd();
  }
}