//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ElementClassesParameter - handles the elementClasses parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>elementClasses</b> parameter.
 */
final class ElementClassesParameter extends Parameter
{
 private static ElementClassesParameter _parameter;

 static ElementClassesParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ElementClassesParameter();
   }
  return _parameter;
 }

 private ElementClassesParameter()
 {
  super(LpexConstants.PARAMETER_ELEMENT_CLASSES);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  if (view != null)
   {
    long classes = 0;
    boolean ok = true; // this flag is used to work around a problem in the JIT

    LpexStringTokenizer st = new LpexStringTokenizer(parameters);
    while (ok && st.hasMoreTokens())
     {
      String token = st.nextToken();
      long mask = view.classes().mask(token);
      if (mask == 0)
       {
        CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
        ok = false;
       }
      classes |= mask;
     }

    if (!ok)
     {
      return false;
     }

    Element element = view.documentPosition().element();
    if (element != null)
     {
      element.elementView(view).setClasses(classes);
     }
   }

  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null && documentLocation != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    if (element != null)
     {
      return view.classes().names(element.elementView(view).classes());
     }
   }

  return null;
 }
}