//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexPaletteAttributes - mechanism for converting style attributes to a
// specified palette.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Class LpexPaletteAttributes provides a mechanism for converting
 * style attributes to a specified palette.
 */
public final class LpexPaletteAttributes
{
 private LpexPaletteAttributes() {}

 /**
  * Use this method to determine the background color of the default style
  * (parameter <b>styleAttributes.default</b>) that is used by the specified
  * document view.  The color is returned as a String of three integers
  * representing the red, green, and blue components of the background color.
  */
 public static String background(LpexView lpexView)
  {
   return StyleAttributes.background(lpexView._view);
  }

 /**
  * Use this method to convert a style attributes string from one background
  * color to another.
  *
  * <p>For example, the style attributes for comments are set like this in the
  * Java parser, to ensure correct color in the active palette:
  * <pre>
  *   String toBackground = LpexPaletteAttributes.background(view);
  *   String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
  *                                                     BACKGROUND_COLOR,
  *                                                     toBackground);
  *   setStyle("c", attributes); </pre>
  * This code assumes that the background color of the default style is
  * the background color of most token style attributes defined by the parser.
  */
 public static String convert(String styleAttributesString,
                              String fromBackground, String toBackground)
  {
   return StyleAttributes.convert(styleAttributesString, fromBackground, toBackground);
  }
}