//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Separator - separator line between the LpexWindow components.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;


/**
 * This class manages a separator line in an LpexWindow.
 */
final class Separator extends Composite
{
 private boolean _separatorValid;
 private Color _color;


 Separator(LpexWindow lpexWindow)
 {
  super(lpexWindow, SWT.NO_BACKGROUND);

  addPaintListener(new PaintListener()
   {
    public void paintControl(PaintEvent e)
     {
      paintComponent(e.gc);
     }
   });
 }

 public void paintComponent(GC g)
 {
  // SWT: see setColor(), we've already set our background for
  // the entire Control, so paintComponent()'s GC comes ready set to it...
  // if (_color != null)
  //  {
  //   g.setBackground(_color.getColor());

       Point size = getSize();
       g.fillRectangle(0, 0, size.x, size.y);
  //  }

  _separatorValid = true;
 }

 /**
  * Retrieve SWT's preferred size of the component.
  */
 public Point computeSize(int wHint, int hHint, boolean changed)
 {
  return new Point(0, 1);
 }

 void setColor(Color color)
 {
  if (_color == null || !(_color.equals(color)))
   {
    _color = color;

    // SWT: set background as the Control's, so paintComponent()'s
    // GC comes ready set to them and we don't have to re-set them
    setBackground(_color.getColor());

    _separatorValid = false;
   }
 }

 void updateSeparator()
 {
  if (!_separatorValid && getSize().y != 0)
   {
    redraw();
   }
 }
}