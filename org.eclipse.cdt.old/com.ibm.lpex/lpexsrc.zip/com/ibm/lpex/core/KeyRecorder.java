//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// KeyRecorder - handle keystroke recording.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages keystroke recording.
 */
final class KeyRecorder
{
 private static KeyRecorder _keyRecorder;
 private boolean _recording;
 private boolean _playing;
 private List _recordedActions;


 KeyRecorder()
  {
   _recordedActions = new List();
  }

 static KeyRecorder keyRecorder()
  {
   if (_keyRecorder == null)
    {
     _keyRecorder = new KeyRecorder();
    }
   return _keyRecorder;
  }

 boolean recording()
  {
   return _recording;
  }

 boolean anythingRecorded()
  {
   return _recordedActions.first() != null;
  }

 void setRecording(boolean recording)
  {
   _recording = recording;
  }

 void clear()
  {
   _recordedActions.clear();
  }

 void play(View view)
  {
   if (!_playing)
    {
     _playing = true;
     for (RecordedAction recordedAction = (RecordedAction) _recordedActions.first();
          recordedAction != null;
          recordedAction = (RecordedAction) recordedAction.next())
      {
       recordedAction.play(view);
      }
     _playing = false;
    }
  }

 void recordAction(int actionId, String actionArgument)
  {
   if (_recording)
    {
     _recordedActions.addBefore(null, new RecordedAction(actionId, actionArgument));
    }
  }

 void recordCharacter(boolean insertMode, char character)
  {
   if (_recording)
    {
     RecordedAction lastRecordedAction = (RecordedAction) _recordedActions.last();
     if (lastRecordedAction != null && !lastRecordedAction.action() &&
         lastRecordedAction.insertMode() == insertMode)
      {
       lastRecordedAction.appendCharacter(character);
      }
     else
      {
       _recordedActions.addBefore(null, new RecordedAction(insertMode, character));
      }
    }
  }


 final static class RecordedAction extends ListNode
  {
   boolean _action;
   int _actionId;
   boolean _insertMode;
   String _text;
   String _actionArgument;

   RecordedAction(int actionId, String actionArgument)
    {
     _action = true;
     _actionId = actionId;
     _actionArgument = actionArgument;
    }

   RecordedAction(boolean insertMode, char character)
    {
     _action = false;
     _insertMode = _insertMode;
     _text = String.valueOf(character);
    }

   boolean action()
    {
     return _action;
    }

   boolean insertMode()
    {
     return _insertMode;
    }

   void appendCharacter(char character)
    {
     _text += character;
    }

   void play(View view)
    {
     if (view != null)
      {
       if (_action)
        {
         view.actionHandler().setArgument(_actionArgument);
         view.actionHandler().doAction(_actionId);
         view.actionHandler().setArgument(null);
        }
       else
        {
         for (int i = 0; i < _text.length(); i++)
          {
           view.receiveCharacter(_insertMode, _text.charAt(i));
          }
        }
      }
    }
  }
}