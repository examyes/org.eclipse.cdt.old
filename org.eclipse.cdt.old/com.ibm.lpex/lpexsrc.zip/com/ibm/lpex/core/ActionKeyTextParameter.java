//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ActionKeyTextParameter - handles the actionKeyText parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>actionKeyText.</b> parameter.
 */
final class ActionKeyTextParameter extends ParameterQuery
{
 private static ActionKeyTextParameter _parameter;

 static ActionKeyTextParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ActionKeyTextParameter();
   }
  return _parameter;
 }

 private ActionKeyTextParameter()
 {
  super(PARAMETER_ACTION_KEY_TEXT);
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    int actionId = view.actionHandler().id(qualifier);
    if (actionId != ACTION_INVALID)
     {
      return view.actionHandler().keyText(actionId);
     }
   }
  return null;
 }
}