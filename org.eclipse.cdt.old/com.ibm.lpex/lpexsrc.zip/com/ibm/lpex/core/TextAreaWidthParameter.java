//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// TextAreaWidthParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class TextAreaWidthParameter extends ParameterIntegerQuery
{
 private static TextAreaWidthParameter _parameter;

 static TextAreaWidthParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new TextAreaWidthParameter();
   }
  return _parameter;
 }

 private TextAreaWidthParameter()
 {
  super(PARAMETER_TEXT_AREA_WIDTH);
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.screen().textAreaWidth() : 0;
 }
}