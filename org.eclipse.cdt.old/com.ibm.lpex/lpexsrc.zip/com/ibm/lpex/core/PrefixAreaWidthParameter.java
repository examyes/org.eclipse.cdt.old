//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// PrefixAreaWidthParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class PrefixAreaWidthParameter extends ParameterIntegerQuery
{
 private static PrefixAreaWidthParameter _parameter;

 static PrefixAreaWidthParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new PrefixAreaWidthParameter();
   }
  return _parameter;
 }

 private PrefixAreaWidthParameter()
 {
  super(PARAMETER_PREFIX_AREA_WIDTH);
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.screen().prefixAreaWidth() : 0;
 }
}