//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// MarkParameter - handles the mark parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>mark</b> parameter.
 * It handles the set and query commands for marks inside the document section
 * that is currently loaded in the editor.  It does not trigger a request for
 * extending this document section when the specified elements for setting
 * a mark are outside its boundaries.
 */
final class MarkParameter extends Parameter
{
 private static MarkParameter _parameter;

 static MarkParameter getParameter()
  {
   if (_parameter == null)
    {
     _parameter = new MarkParameter();
    }
   return _parameter;
  }

 private MarkParameter()
  {
   super(PARAMETER_MARK);
  }

 boolean set(View view, String qualifier, String parameters)
  {
   boolean sticky = false;
   boolean elementMark = false;

   int element1 = 0;
   int position1 = 0;
   if (view != null)
    {
     element1 = view.document().elementList().ordinalOf(view.documentPosition().element());
     position1 = view.documentPosition().position();
    }

   int element2 = element1;
   int position2 = position1;

   String token;
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     token = st.nextToken();
     if (token.equals("clear"))
      {
       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name(qualifier));
        }
       if (view != null)
        {
         MarkList.Mark mark = view.markList().find(qualifier);
         if (mark != null)
          {
           mark.clear();
          }
        }
       return true;
      }

     if (token.equals("sticky"))
      {
       sticky = true;
       token = st.hasMoreTokens()? st.nextToken() : null;
      }

     if (token != null && token.equals("element"))
      {
       elementMark = true;
       token = st.hasMoreTokens()? st.nextToken() : null;
      }

     // read in up to 4 integers passed in as mark parameters
     int integerParameters[] = new int[4];
     int count = 0;
     while (token != null && ((elementMark && count < 2) || (!elementMark && count < 4)))
      {
       try
        {
         integerParameters[count] = Integer.parseInt(token);
         count++;
        }
       catch(NumberFormatException e)
        {
         return CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
        }
       token = st.hasMoreTokens()? st.nextToken() : null;
      }

     if (token != null)
      {
       return CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
      }

     if (elementMark)
      {
       if (count > 0)
        {
         element1 = integerParameters[0] -
                    // adjust to inside currently-loaded document section
                    ((view != null)? view.document().linesBeforeStart() : 0);
        }
       if (count > 1)
        {
         element2 = integerParameters[1] -
                    // adjust to inside currently-loaded document section
                    ((view != null)? view.document().linesBeforeStart() : 0);
        }
       else
        {
         element2 = element1;
        }
      }
     else // character mark
      {
       if (count > 0)
        {
         element1 = integerParameters[0] -
                    // adjust to inside currently-loaded document section
                    ((view != null)? view.document().linesBeforeStart() : 0);
        }

       position1 = (count > 1)? integerParameters[1] : 1;

       if (count > 2)
        {
         element2 = integerParameters[2] -
                    // adjust to inside currently-loaded document section
                    ((view != null)? view.document().linesBeforeStart() : 0);
        }
       else
        {
         element2 = element1;
        }

       if (count > 3)
        {
         position2 = integerParameters[3];
        }
       else
        {
         position2 = (element1 == element2)? position1 : 1;
        }
      }
    }

   if (view != null)
    {
     if (element2 < element1)
      {
       int swap = element2;
       element2 = element1;
       element1 = swap;
       swap = position2;
       position2 = position1;
       position1 = swap;
      }
     else if (position2 < position1)
      {
       int swap = position2;
       position2 = position1;
       position1 = swap;
      }

     ElementList elementList = view.document().elementList();
     Element e1 = elementList.elementAt(element1);
     Element e2 = elementList.elementAt(element2);

     if (e1 != null && e2 != null)
      {
       if (elementMark)
        {
         view.markList().set(qualifier, e1, e2, sticky);
        }
       else
        {
         view.markList().set(qualifier, e1, position1, e2, position2, sticky);
        }
      }
    }
   return true;
  }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   if (view != null)
    {
     MarkList.Mark mark = view.markList().find(qualifier);
     if (mark != null)
      {
       return mark.query();
      }
    }

   return null;
  }
}