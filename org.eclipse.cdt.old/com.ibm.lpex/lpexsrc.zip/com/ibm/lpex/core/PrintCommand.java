//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// PrintCommand - print command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.printing.PrintDialog;
import org.eclipse.swt.printing.Printer;
import org.eclipse.swt.printing.PrinterData;


/**
 * This class implements the <b>print</b> command.
 * It prints the document section that is currently loaded in the editor.
 * It does not trigger a request for extending this document section.
 * To print the entire document, the user should extend this command to
 * first load the complete document in.
 */
final class PrintCommand
 {
  // internal print.xxx parameter ids
  static final int
   INVALID       = 0,
   BOTTOM_MARGIN = 1,
   FONT          = 2,
   LEFT_MARGIN   = 3,
   LINE_NUMBERS  = 4,
   RIGHT_MARGIN  = 5,
   TOKENIZED     = 6,
   TOP_MARGIN    = 7;

  // NB The print parameters must be in alphabetical order for the binary search.
  private static TableNode[] _parameters =
   {
    new TableNode(LpexConstants.PRINT_PARAMETER_BOTTOM_MARGIN, BOTTOM_MARGIN),
    new TableNode(LpexConstants.PRINT_PARAMETER_FONT,          FONT),
    new TableNode(LpexConstants.PRINT_PARAMETER_LEFT_MARGIN,   LEFT_MARGIN),
    new TableNode(LpexConstants.PRINT_PARAMETER_LINE_NUMBERS,  LINE_NUMBERS),
    new TableNode(LpexConstants.PRINT_PARAMETER_RIGHT_MARGIN,  RIGHT_MARGIN),
    new TableNode(LpexConstants.PRINT_PARAMETER_TOKENIZED,     TOKENIZED),
    new TableNode(LpexConstants.PRINT_PARAMETER_TOP_MARGIN,    TOP_MARGIN),
   };


  /**
   * Retrieve the Parameter object handling the particular <b>print.xxx</b>
   * parameter.
   */
  static Parameter getParameter(String parameter)
   {
    TableNode p = TableNode.binarySearch(_parameters, Parameters.getParameterString(parameter));
    if (p != null)
     {
      switch (p.id())
       {
        case BOTTOM_MARGIN:
         {
          return BottomMarginParameter.getParameter();
         }
        case FONT:
         {
          return FontParameter.getParameter();
         }
        case LEFT_MARGIN:
         {
          return LeftMarginParameter.getParameter();
         }
        case LINE_NUMBERS:
         {
          return LineNumbersParameter.getParameter();
         }
        case RIGHT_MARGIN:
         {
          return RightMarginParameter.getParameter();
         }
        case TOKENIZED:
         {
          return TokenizedParameter.getParameter();
         }
        case TOP_MARGIN:
         {
          return TopMarginParameter.getParameter();
         }
        default:
         {
          break;
         }
       }
     }
    return null;
   }


  /**
   * The <b>print.bottomMargin</b> parameter.
   */
  final static class BottomMarginParameter extends ParameterIntegerDefault
   {
    private static BottomMarginParameter _parameter;
    static BottomMarginParameter getParameter()
     {
      if (_parameter == null)
       {
        _parameter = new BottomMarginParameter();
       }
      return _parameter;
     }

    private BottomMarginParameter()
     {
      super(PARAMETER_PRINT + PRINT_PARAMETER_BOTTOM_MARGIN, 50);
     }

    String name(String qualifier)
     {
      return name();
     }

    boolean setValue(View view, int value, boolean useDefaultValue)
     {
      if (view != null)
       {
        Settings settings = view.printCommandSettings();
        settings._bottomMargin = value;
        settings._useDefaultBottomMargin = useDefaultValue;
       }
      return true;
     }

    boolean useDefaultValue(View view)
     {
      return (view != null)? view.printCommandSettings()._useDefaultBottomMargin : true;
     }

    int value(View view)
     {
      return (view != null)? view.printCommandSettings()._bottomMargin : 0;
     }
   }


  /**
   * The <b>print.font</b> parameter.
   */
  final static class FontParameter extends ParameterFontDefault
   {
    private static FontParameter _parameter;
    static FontParameter getParameter()
     {
      if (_parameter == null)
       {
        _parameter = new FontParameter();
       }
      return _parameter;
     }

    private boolean _useScreenFontAsDefault;

    private FontParameter()
     {
      super(PARAMETER_PRINT + PRINT_PARAMETER_FONT, null);
     }

    protected Font installValue()
     {
      if (!_installValueLoaded)
       {
        String value = Install.getString("install." + this.name());
        if ("screen".equals(value))
         {
          _installValue = null;
          _installValueLoaded = true;
         }
        else
         {
          super.installValue();
         }
       }
      return _installValue;
     }

    protected void loadDefaultValue()
     {
      if (!_defaultValueLoaded)
       {
        String value = Profile.getString("default." + this.name());
        if ("screen".equals(value))
         {
          _defaultValue = null;
          _useScreenFontAsDefault = true;
          _defaultValueLoaded = true;
         }
        else
         {
          super.loadDefaultValue();
          _useScreenFontAsDefault = false;
         }
       }
     }

    boolean useScreenFontAsDefault()
     {
      loadDefaultValue();
      return _useScreenFontAsDefault;
     }

    Font currentValue(View view)
     {
      Font value = null;
      if (view != null && useScreenFont(view))
       {
        value = view.screen().currentFont();
       }
      else
       {
        value = value(view);
        if (value == null)
         {
          if (view != null && useScreenFontAsDefault())
           {
            value = view.screen().currentFont();
           }
          else
           {
            value = defaultValue();
            if (value == null)
             {
              value = installValue();
              if (value == null)
               {
                value = view.screen().currentFont();
               }
             }
           }
         }
       }
      return value;
     }

    boolean set(View view, String qualifier, String parameters)
     {
      boolean useScreenFont = false;
      Font value = null;
      LpexStringTokenizer st = new LpexStringTokenizer(parameters);
      if (st.hasMoreTokens())
       {
        String token = st.nextToken();
        if (token.equals("screen"))
         {
          useScreenFont = true;
          if (st.hasMoreTokens())
           {
            return CommandHandler.invalidParameter(view, st.nextToken(), "set " + this.name());
           }
         }
       }

      if (!useScreenFont)
       {
        // correct qualifier (now e.g. "font", as it was extracted from "print.font")
        qualifier = Parameters.getQualifierString(qualifier);
        if (!super.set(view, qualifier, parameters))
         {
          return false;
         }
        value = value(view);
       }

      return setValue(view, value, useScreenFont);
     }

    boolean setValue(View view, Font value)
     {
      if (view != null)
       {
        view.printCommandSettings()._font = value;
       }
      return true;
     }

    boolean setValue(View view, Font value, boolean useScreenFont)
     {
      if (view != null)
       {
        view.printCommandSettings()._useScreenFont = useScreenFont;
        return setValue(view, value);
       }
      return true;
     }

    boolean setDefault(View view, String qualifier, String parameters)
     {
      boolean useScreenFont = false;
      Font value = null;
      LpexStringTokenizer st = new LpexStringTokenizer(parameters);
      if (st.hasMoreTokens())
       {
        String token = st.nextToken();
        if (token.equals("screen"))
         {
          useScreenFont = true;
          if (st.hasMoreTokens())
           {
            return CommandHandler.invalidParameter(view, st.nextToken(),
                                                   "set default." + this.name());
           }
         }
       }

      if (!useScreenFont)
       {
        // correct qualifier (now e.g. "font", as it was extracted from "print.font")
        qualifier = Parameters.getQualifierString(qualifier);
        if (!super.setDefault(view, qualifier, parameters))
         {
          return false;
         }
        _useScreenFontAsDefault = false;
       }
      else
       {
        _defaultValue = null;
        _useScreenFontAsDefault = true;
        _defaultValueLoaded = true;
        Profile.putString("default." + this.name(), "screen");
       }

      return true;
     }

    String query(View view, LpexDocumentLocation documentLocation, String qualifier)
     {
      if (view != null)
       {
        if (useScreenFont(view))
         {
          return "screen";
         }

        // correct qualifier (now e.g. "font", as it was extracted from "print.font")
        qualifier = Parameters.getQualifierString(qualifier);
        return super.query(view, documentLocation, qualifier);
       }

      return null;
     }

    boolean useScreenFont(View view)
     {
      return (view != null)? view.printCommandSettings()._useScreenFont : false;
     }

    Font value(View view)
     {
      return (view != null)? view.printCommandSettings()._font : null;
     }

    String queryInstall(String qualifier)
     {
      Font value = installValue();
      if (value == null)
       {
        return "screen";
       }

      // correct qualifier (now e.g. "font", as it was extracted from "print.font")
      qualifier = Parameters.getQualifierString(qualifier);
      return super.queryInstall(qualifier);
     }

    String queryDefault(String qualifier)
     {
      if (useScreenFontAsDefault())
       {
        return "screen";
       }

      // correct qualifier (now e.g. "font", as it was extracted from "print.font")
      qualifier = Parameters.getQualifierString(qualifier);
      return super.queryDefault(qualifier);
     }

    String queryCurrent(View view, String qualifier)
     {
      // correct qualifier (now e.g. "font", as it was extracted from "print.font")
      qualifier = Parameters.getQualifierString(qualifier);
      return super.queryCurrent(view, qualifier);
     }
   }


  /**
   * The <b>print.leftMargin</b> parameter.
   */
  final static class LeftMarginParameter extends ParameterIntegerDefault
   {
    private static LeftMarginParameter _parameter;
    static LeftMarginParameter getParameter()
     {
      if (_parameter == null)
       {
        _parameter = new LeftMarginParameter();
       }
      return _parameter;
     }

    private LeftMarginParameter()
     {
      super(PARAMETER_PRINT + PRINT_PARAMETER_LEFT_MARGIN, 50);
     }

    String name(String qualifier)
     {
      return name();
     }

    boolean setValue(View view, int value, boolean useDefaultValue)
     {
      if (view != null)
       {
        Settings settings = view.printCommandSettings();
        settings._leftMargin = value;
        settings._useDefaultLeftMargin = useDefaultValue;
       }
      return true;
     }

    boolean useDefaultValue(View view)
     {
      return (view != null)? view.printCommandSettings()._useDefaultLeftMargin : true;
     }

    int value(View view)
     {
      return (view != null)? view.printCommandSettings()._leftMargin : 0;
     }
   }


  /**
   * The <b>print.lineNumbers</b> parameter.
   */
  final static class LineNumbersParameter extends ParameterOnOffDefault
   {
    private static LineNumbersParameter _parameter;
    static LineNumbersParameter getParameter()
     {
      if (_parameter == null)
       {
        _parameter = new LineNumbersParameter();
       }
      return _parameter;
     }

    private LineNumbersParameter()
     {
      super(PARAMETER_PRINT + PRINT_PARAMETER_LINE_NUMBERS, false);
     }

    String name(String qualifier)
     {
      return name();
     }

    boolean setValue(View view, int value)
     {
      if (view != null)
       {
        view.printCommandSettings()._lineNumbers = value;
       }
      return true;
     }

    int value(View view)
     {
      return (view != null)? view.printCommandSettings()._lineNumbers : Parameter.DEFAULT;
     }
   }


  /**
   * The <b>print.rightMargin</b> parameter.
   */
  final static class RightMarginParameter extends ParameterIntegerDefault
   {
    private static RightMarginParameter _parameter;
    static RightMarginParameter getParameter()
     {
      if (_parameter == null)
       {
        _parameter = new RightMarginParameter();
       }
      return _parameter;
     }

    private RightMarginParameter()
     {
      super(PARAMETER_PRINT + PRINT_PARAMETER_RIGHT_MARGIN, 50);
     }

    String name(String qualifier)
     {
      return name();
     }

    boolean setValue(View view, int value, boolean useDefaultValue)
     {
      if (view != null)
       {
        Settings settings = view.printCommandSettings();
        settings._rightMargin = value;
        settings._useDefaultRightMargin = useDefaultValue;
       }
      return true;
     }

    boolean useDefaultValue(View view)
     {
      return (view != null)? view.printCommandSettings()._useDefaultRightMargin : true;
     }

    int value(View view)
     {
      return (view != null)? view.printCommandSettings()._rightMargin : 0;
     }
   }


  /**
   * The <b>print.tokenized</b> parameter.
   */
  final static class TokenizedParameter extends ParameterOnOffDefault
   {
    private static TokenizedParameter _parameter;
    static TokenizedParameter getParameter()
     {
      if (_parameter == null)
       {
        _parameter = new TokenizedParameter();
       }
      return _parameter;
     }

    private TokenizedParameter()
     {
      super(PARAMETER_PRINT + PRINT_PARAMETER_TOKENIZED, false);
     }

    String name(String qualifier)
     {
      return name();
     }

    boolean setValue(View view, int value)
     {
      if (view != null)
       {
        view.printCommandSettings()._tokenized = value;
       }
      return true;
     }

    int value(View view)
     {
      return (view != null)? view.printCommandSettings()._tokenized : Parameter.DEFAULT;
     }
   }


  /**
   * The <b>print.topMargin</b> parameter.
   */
  final static class TopMarginParameter extends ParameterIntegerDefault
   {
    private static TopMarginParameter _parameter;
    static TopMarginParameter getParameter()
     {
      if (_parameter == null)
       {
        _parameter = new TopMarginParameter();
       }
      return _parameter;
     }

    private TopMarginParameter()
     {
      super(PARAMETER_PRINT + PRINT_PARAMETER_TOP_MARGIN, 50);
     }

    String name(String qualifier)
     {
      return name();
     }

    boolean setValue(View view, int value, boolean useDefaultValue)
     {
      if (view != null)
       {
        Settings settings = view.printCommandSettings();
        settings._topMargin = value;
        settings._useDefaultTopMargin = useDefaultValue;
       }
      return true;
     }

    boolean useDefaultValue(View view)
     {
      return (view != null)? view.printCommandSettings()._useDefaultTopMargin : true;
     }

    int value(View view)
     {
      return (view != null)? view.printCommandSettings()._topMargin : 0;
     }
   }


  static boolean doCommand(View view, String parameters)
   {
    return (new LpexPrinter(view)).print(parameters);

    // org.eclipse.jface.text.TextViewer does it in a separate thread (but they
    // don't seem to freeze input to the text widget during the printing!?):
    // protected void print()
    //  {
    //   final PrintDialog dialog = new PrintDialog(fTextWidget.getShell(), SWT.NULL);
    //   final PrinterData data = dialog.open();
    //   if (data != null)
    //    {
    //     final Printer printer = new Printer(data);
    //     final Runnable styledTextPrinter = fTextWidget.print(printer);
    //     Thread printingThread = new Thread("Printing")
    //      {
    //       public void run()
    //        {
    //         styledTextPrinter.run();
    //         printer.dispose();
    //        }
    //      };
    //     printingThread.start();
    //    }
    //  }
   }


  private final static class LpexPrinter
   {
    View view;
    Printer printer;
    GC g;
    Color _background, _foreground; // current colors of the printer GC


    LpexPrinter(View view)
     {
      this.view = view;
     }

    boolean print(String parameters)
     {
      boolean block        = false;
      int     startElement = 1;
      int     endElement   = view.document().elementList().count();
      //boolean prompt     = false;
      boolean visible      = false;

      int     bottomMargin = BottomMarginParameter.getParameter().currentValue(view);
      Font    font         = FontParameter.getParameter().currentValue(view);
      int     leftMargin   = LeftMarginParameter.getParameter().currentValue(view);
      boolean lineNumbers  = LineNumbersParameter.getParameter().currentValue(view);
      int     rightMargin  = RightMarginParameter.getParameter().currentValue(view);
      boolean tokenized    = TokenizedParameter.getParameter().currentValue(view);
      int     topMargin    = TopMarginParameter.getParameter().currentValue(view);

      /*====================================================*/
      /*  get & validate the parameters for this print job  */
      /*====================================================*/
      LpexStringTokenizer st = new LpexStringTokenizer(parameters);
      while (st.hasMoreTokens())
       {
        String token = st.nextToken();
        if (token.equals("block"))
         {
          block = true;
         }

        else if (token.equals("bottomMargin"))
         {
          if (st.hasMoreTokens())
           {
            token = st.nextToken();
            try
             {
              bottomMargin = Integer.parseInt(token);
             }
            catch(NumberFormatException e)
             {
              return CommandHandler.invalidParameter(view, token, "print");
             }
           }
          else
           {
            return CommandHandler.integerMissing(view, "bottomMargin", "print");
           }
         }

        else if (token.equals("endElement"))
         {
          if (st.hasMoreTokens())
           {
            token = st.nextToken();
            try
             {
              endElement = Integer.parseInt(token);
             }
            catch(NumberFormatException e)
             {
              return CommandHandler.invalidParameter(view, token, "print");
             }
           }
          else
           {
            return CommandHandler.integerMissing(view, "endElement", "print");
           }
         }

        else if (token.equals("font"))
         {
          if (st.hasMoreTokens())
           {
            token = st.nextToken();
            if (token.equals("screen"))
             {
              if (view != null)
               {
                font = view.screen().currentFont();
               }
             }
            else
             {
              font = Font.decodeFont(token);
             }
           }
          else
           {
            if (view != null)
             {
              view.setLpexMessageText(LpexConstants.MSG_PRINTCOMMAND_FONTMISSING);
             }
            return false;
           }
         }

        else if (token.equals("leftMargin"))
         {
          if (st.hasMoreTokens())
           {
            token = st.nextToken();
            try
             {
              leftMargin = Integer.parseInt(token);
             }
            catch(NumberFormatException e)
             {
              return CommandHandler.invalidParameter(view, token, "print");
             }
           }
          else
           {
            return CommandHandler.integerMissing(view, "leftMargin", "print");
           }
         }

        else if (token.equals("lineNumbers"))
         {
          if (st.hasMoreTokens())
           {
            token = st.nextToken();
            if (token.equals("on"))
             {
              lineNumbers = true;
             }
            else if (token.equals("off"))
             {
              lineNumbers = false;
             }
            else
             {
              return CommandHandler.invalidParameter(view, token, "print");
             }
           }
          else
           {
            return CommandHandler.incomplete(view, "print");
           }
         }

        else if (token.equals("prompt"))
         {
          //prompt = true; // allow, was once documented...
         }

        else if (token.equals("rightMargin"))
         {
          if (st.hasMoreTokens())
           {
            token = st.nextToken();
            try
             {
              rightMargin = Integer.parseInt(token);
             }
            catch(NumberFormatException e)
             {
              return CommandHandler.invalidParameter(view, token, "print");
             }
           }
          else
           {
            return CommandHandler.integerMissing(view, "rightMargin", "print");
           }
         }

        else if (token.equals("startElement"))
         {
          if (st.hasMoreTokens())
           {
            token = st.nextToken();
            try
             {
              startElement = Integer.parseInt(token);
             }
            catch(NumberFormatException e)
             {
              return CommandHandler.invalidParameter(view, token, "print");
             }
           }
          else
           {
            return CommandHandler.integerMissing(view, "startElement", "print");
           }
         }

        else if (token.equals("tokenized"))
         {
          if (st.hasMoreTokens())
           {
            token = st.nextToken();
            if (token.equals("on"))
             {
              tokenized = true;
             }
            else if (token.equals("off"))
             {
              tokenized = false;
             }
            else
             {
              return CommandHandler.invalidParameter(view, token, "print");
             }
           }
          else
           {
            return CommandHandler.incomplete(view, "print");
           }
         }

        else if (token.equals("topMargin"))
         {
          if (st.hasMoreTokens())
           {
            token = st.nextToken();
            try
             {
              topMargin = Integer.parseInt(token);
             }
            catch(NumberFormatException e)
             {
              return CommandHandler.invalidParameter(view, token, "print");
             }
           }
          else
           {
            return CommandHandler.integerMissing(view, "topMargin", "print");
           }
         }

        else if (token.equals("visible"))
         {
          visible = true;
         }

        else
         {
          return CommandHandler.invalidParameter(view, token, "print");
         }
       }

      /*=====================*/
      /*  start a print job  */
      /*=====================*/
      if (view == null || view.lpexView().frame() == null)
       {
        return true;
       }

      PrintDialog printDialog = new PrintDialog(view.lpexView().frame());
      // set initial settings for the print dialog
      if (block)
         printDialog.setScope(PrinterData.SELECTION);
      PrinterData printerData = printDialog.open();
      if (printerData == null) // user cancelled the print job?
       {
        return true;
       }

      // get updated settings from the print dialog
//*as*block = (printDialog.getScope() & PrinterData.SELECTION) != 0; bug in Eclipse 0.107?!
      block = (printerData.scope & PrinterData.SELECTION) != 0;
      printer = new Printer(printerData);

      // start print job
      String name = view.document().name();
      if (name != null)
       {
        name = LpexStringTokenizer.addQuotes(name);
       }
      else
       {
        name = LpexResources.message(LpexConstants.MSG_UNTITLED_DOCUMENT, view.document().id());
       }
      if (!printer.startJob(name))
       {
        printer.dispose();
        return true;
       }

      /*===================*/
      /*  do the printing  */
      /*===================*/
      ElementList elementList = view.document().elementList();
      if (block && Block.view() == view)
       {
        Element topElement = Block.topElement();
        if (topElement != null)
         {
          int topElementNumber = elementList.ordinalOf(topElement);
          if (topElementNumber > startElement)
           {
            startElement = topElementNumber;
           }
         }
        Element bottomElement = Block.bottomElement();
        if (bottomElement != null)
         {
          int bottomElementNumber = elementList.ordinalOf(bottomElement);
          if (bottomElementNumber < endElement)
           {
            endElement = bottomElementNumber;
           }
         }
       }

      Element stopElement = elementList.elementAt(endElement);
      if (stopElement != null)
       {
        stopElement = stopElement.next();
       }

      // clientArea = the size of the printable area of a page, in pixels
      int pageHeight = printer.getClientArea().height; //*as* trim, etc.!?...
      int pageWidth  = printer.getClientArea().width;
      int x;
      int y = 0;
      int w;
      int lineNumberWidth = 0;
      int lineNumberPadWidth = 0;
      String text = null;

      Font printerFont = new Font(printer,
                                  font.getName(), font.getStyle(), font.getSize());

      Screen screen = view.screen();
      StyleAttributes defaultStyle = screen.styleAttributes(Screen.STYLE_DEFAULT);
      StyleAttributes lineNumberStyle = screen.styleAttributes(Screen.STYLE_PREFIX_AREA);
      StyleAttributesList styleAttributesList = view.styleAttributesList();

      /*-------------------------------------------*/
      /*  go through all the elements to print...  */
      /*-------------------------------------------*/
      g = new GC(printer);
      g.setFont(printerFont.getFont());
      int textHeight = g.getFontMetrics().getHeight();

      boolean startedPage = false;
      for (Element element = elementList.elementAt(startElement);
           element != stopElement;
           element = element.next())
       {
        if ((!visible && !element.show()) || element.visible(view))
         {
          do // until the text of one entire element is printed
           {
            // start a new page
            if (!startedPage)
             {
              printer.startPage();
              startedPage = true;
              y = topMargin;

              // establish width of the line-numbers area to fit longest
              if (lineNumbers && lineNumberWidth == 0)
               {
                for (Element e = elementList.elementAt(startElement);
                     e != stopElement;
                     e = e.next())
                 {
                  if ((!visible && !e.show()) || e.visible(view))
                   {
                    String lineNumberText = e.lineNumberText(6);
                    //AWT: w = fontMetrics.stringWidth(lineNumberText);
                    w = g.stringExtent(lineNumberText).x;
                    if (w > lineNumberWidth)
                     {
                      lineNumberWidth = w;
                     }
                   }
                 }
               }
             }

            // start at beginning of the line
            x = leftMargin;

            // print line numbers
            if (lineNumbers)
             {
              if (text == null) // don't print the line number for spill-over text
               {
                if (!tokenized)
                 {
                  g.drawString(element.lineNumberText(6), x, y /*awt: + maxAscent*/);
                 }
                else
                 {
                  String lineNumberText = element.lineNumberText(6);
                  drawTokenizedString(lineNumberStyle,
                                      x, lineNumberWidth, y, textHeight,
                                      lineNumberText);
                 }
               }
              x = leftMargin + lineNumberWidth;
              if (lineNumberPadWidth == 0)
               {
                lineNumberPadWidth = g.stringExtent(" ").x;
               }
              if (tokenized)
               {
                drawTokenizedString(defaultStyle,
                                    x, lineNumberPadWidth, y, textHeight,
                                    " ");
               }
              x += lineNumberPadWidth;
             }

            // print text
            if (text == null)
             {
              text = element.elementView(view).displayText();
             }
            if (text != null)
             {
              int l = text.length();
              while (l > 0)
               {
                w = g.stringExtent(text.substring(0, l)).x;
                if (x + w <= pageWidth - rightMargin)
                 {
                  break;
                 }
                l--;
               }
              String remainingText = null;   // text spillin' to next print line
              if (l > 0 && l < text.length())
               {
                remainingText = text.substring(l);
                text = text.substring(0, l);
               }

              if (!tokenized)
               {
                g.drawString(text, x, y);
               }
              else
               {
                int textLength = text.length();
                ElementView elementView = element.elementView(view);
                String style = (elementView != null)? elementView.displayStyle() : null;
                if (style == null)
                 {
                  style = "";
                 }
                int length = (style.length() > text.length())?
                              style.length() : text.length();
                int i = 0;
                // build up the text line from its token subtexts
                while (i < length)
                 {
                  StyleAttributes styleAttributes = null;
                  if (style.length() > i)
                   {
                    styleAttributes = styleAttributesList.find(style.charAt(i));
                   }
                  if (styleAttributes == null)
                   {
                    styleAttributes = defaultStyle;
                   }

                  // establish extent of a token
                  int subTextLength = 1;
                  while (i + subTextLength < length)
                   {
                    StyleAttributes styleAttributesNext = null;
                    if (style.length() > i + subTextLength)
                     {
                      styleAttributesNext = styleAttributesList.find(style.charAt(i + subTextLength));
                     }
                    if (styleAttributesNext == null)
                     {
                      styleAttributesNext = defaultStyle;
                     }
                    if (!styleAttributes.equals(styleAttributesNext))
                     {
                      break;
                     }
                    subTextLength++;
                   }
                  String subText;
                  if (i + subTextLength <= textLength)
                   {
                    subText = text.substring(i, i + subTextLength);
                   }
                  else
                   {
                    if (i < textLength)
                     {
                      subText = text.substring(i);
                     }
                    else
                     {
                      subText = "";
                     }
                    StringBuffer buffer = new StringBuffer(subText);
                    int originalLength = buffer.length();
                    buffer.setLength(length);
                    for (int j = originalLength; j < length; j++)
                     {
                      buffer.setCharAt(j, ' ');
                     }
                    subText = buffer.toString();
                   }
                  w = g.stringExtent(subText).x;
                  drawTokenizedString(styleAttributes,
                                      x, w, y, textHeight,
                                      subText);
                  i += subTextLength;
                  x += w;
                 }
               }
              text = remainingText;    // still to print text spillin' over edge
             }

            // finished a print line, go to next
            y += textHeight;

            // done with this page?
            if (y + textHeight > pageHeight - bottomMargin)
             {
              printer.endPage();
              startedPage = false;
             }
           } while (text != null);
         }
       }//end "for"

      /*=======================*/
      /*  finish up print job  */
      /*=======================*/
      g.dispose();
      printerFont.dispose();
      printer.endJob();
      printer.dispose();

      System.gc();
      return true;
     }

    private void drawTokenizedString(StyleAttributes styleAttributes,
                                     int rectX, int rectWidth, int rectY, int rectHeight,
                                     String text)
     {
      if (setBackground(styleAttributes))
       {
        g.fillRectangle(rectX, rectY, rectWidth, rectHeight);
       }

      setForeground(styleAttributes);
      g.drawString(text, rectX, rectY);
      if (styleAttributes.underline())
       {
        g.drawLine(rectX, rectY + rectHeight - 1, rectX + rectWidth, rectY + rectHeight - 1);
       }
     }

    // return true = background is not white
    private boolean setBackground(StyleAttributes styleAttributes)
     {
      if (_background == null ||
          !_background.equals(styleAttributes.backgroundColor()))
       {
        _background = styleAttributes.backgroundColor();
        g.setBackground((new Color(printer, _background)).getColor());
       }

      return !_background.isWhite();
     }

    private void setForeground(StyleAttributes styleAttributes)
     {
      if (_foreground == null ||
          !_foreground.equals(styleAttributes.foregroundColor()))
       {
        _foreground = styleAttributes.foregroundColor();
        g.setForeground((new Color(printer, _foreground)).getColor());
       }
     }
   }


  final static class Settings
   {
    int     _bottomMargin;
    boolean _useDefaultBottomMargin = true;

    Font    _font;
    boolean _useScreenFont;

    int     _leftMargin;
    boolean _useDefaultLeftMargin = true;

    int     _lineNumbers = Parameter.DEFAULT;

    int     _rightMargin;
    boolean _useDefaultRightMargin = true;

    int     _tokenized = Parameter.DEFAULT;

    int     _topMargin;
    boolean _useDefaultTopMargin = true;
   }
 }