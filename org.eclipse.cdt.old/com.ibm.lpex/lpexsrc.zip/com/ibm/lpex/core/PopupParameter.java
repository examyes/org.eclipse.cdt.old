//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// PopupParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class PopupParameter extends ParameterWordsDefault
{
 private static PopupParameter _parameter;

 static PopupParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new PopupParameter();
   }
  return _parameter;
 }

 private PopupParameter()
 {
  super(PARAMETER_POPUP, null);
 }

 boolean setValue(View view, String value)
 {
  if (view != null)
   {
    view.setPopup(value);
   }
  return true;
 }

 String value(View view)
 {
  return (view != null)? view.popup() : null;
 }
}