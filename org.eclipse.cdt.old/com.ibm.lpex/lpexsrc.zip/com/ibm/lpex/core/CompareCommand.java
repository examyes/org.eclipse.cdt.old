//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CompareCommand - the compare command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>compare</b> command.
 * It compares the document section that is currently loaded in the editor to
 * a specified file.  It does not trigger a request for extending this document
 * section.  To compare the entire document, the user should extend this
 * command to first load the complete document in.
 */
final class CompareCommand
{
 // internal compare.xxx parameter ids
 static final int
  INVALID              = 0,
  IGNOREALLBLANKS      = 1,
  IGNORECASE           = 2,
  IGNORELEADINGBLANKS  = 3,
  IGNORETRAILINGBLANKS = 4;

 // NB The compare parameters must be in alphabetical order for binary search.
 private static TableNode[] _parameters =
  {
   new TableNode(LpexConstants.COMPARE_PARAMETER_IGNOREALLBLANKS,      IGNOREALLBLANKS),
   new TableNode(LpexConstants.COMPARE_PARAMETER_IGNORECASE,           IGNORECASE),
   new TableNode(LpexConstants.COMPARE_PARAMETER_IGNORELEADINGBLANKS,  IGNORELEADINGBLANKS),
   new TableNode(LpexConstants.COMPARE_PARAMETER_IGNORETRAILINGBLANKS, IGNORETRAILINGBLANKS)
  };


 /**
  * Retrieve the Parameter object handling the particular <b>compare.xxx</b>
  * parameter.
  */
 static Parameter getParameter(String parameter)
  {
   TableNode p = TableNode.binarySearch(_parameters,
                                        Parameters.getParameterString(parameter));
   if (p != null)
    {
     switch (p.id())
      {
       case IGNORECASE:
        {
         return ignoreCaseParameter();
        }
       case IGNORELEADINGBLANKS:
        {
         return ignoreLeadingBlanksParameter();
        }
       case IGNORETRAILINGBLANKS:
        {
         return ignoreTrailingBlanksParameter();
        }
       case IGNOREALLBLANKS:
        {
         return ignoreAllBlanksParameter();
        }
       default:
        {
         break;
        }
      }
    }
   return null;
  }

 /**
  * Execute a compare command.
  *
  * @return <code>true</code> on success
  */
 static boolean doCommand(View view, String parameters)
  {
   boolean quotedFileName = false;   // true = a fileName in parameters, quoted
   boolean prompt = false;
   String fileName = null;

   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("clear"))
      {
       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "compare");
        }
       clear(view);
       return true;
      }

     if (token.equals("refresh"))
      {
       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "compare");
        }

       if (view != null)
        {
         fileName = view.fileLastComparedTo();
         if (fileName != null)
          {
           // re-compare, trying to keep the cursor roughly in place
           // COULD JUST compare(view,fileName,false); BUT NOT AS GOOD A JOB...
           int line = view.documentPosition().element().nonShowOrdinal();
           LpexDocumentLocation cursor = view.documentPosition().documentLocation();
           int cursorRow = view.screen().cursorRow();

           compare(view, fileName, false);

           view.documentPosition().jump(cursor);
           // if not on element for the same source line, adjust
           int newLine = view.document().elementList().nonShowOrdinalOf(view.documentPosition().element());
           if (newLine != line)
            {
             view.commandHandler().doCommand("locate line "+line);
             view.commandHandler().doCommand("set position "+cursor.position);
            }
           view.screen().setCursorRow(cursorRow);
           return true;
          }
        }

       return false;
      }

     if (token.equals("next"))
      {
       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "compare");
        }
       if (view != null)
        {
         nextMismatch(view);
         return true;
        }
       return false;
      }

     if (token.equals("previous"))
      {
       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "compare");
        }
       if (view != null)
        {
         previousMismatch(view);
         return true;
        }
       return false;
      }

     if (token.equals("prompt"))
      {
       prompt = true;
       if (st.hasMoreTokens())
        {
         token = st.nextToken();
        }
       else
        {
         token = null;
        }
      }

     if (LpexStringTokenizer.isInvalidQuotedString(token))
      {
       return CommandHandler.invalidQuotedParameter(view, token, "compare");
      }
     quotedFileName = (token != null && token.charAt(0) == '"');
     fileName = LpexStringTokenizer.trimQuotes(token);

     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "compare");
      }
    }

   if (view != null)
    {
     if (fileName == null || fileName.length() == 0)
      {
       fileName = view.fileLastComparedTo();
       if (fileName == null)
          fileName = view.document().name();
      }

     if (prompt)
      {
       fileName = LpexUtilities.fileDialog(view,
                                LpexResources.message(LpexConstants.MSG_FILEDIALOG_COMPARE),
                                false,
                                fileName);
      }

     if (fileName != null)
      {
       compare(view, fileName, true);
       // record fileName used as participant in this compare, for next use in
       // compare without a fileName parameter;  however, if it's a misspelled
       // option (e.g., typing "compare refress" -- NB unquoted! -- on the
       // command line), we shouldn't get stuck with this bad option as the
       // 'last fileName'...
       if (CommandHandler._status == null || quotedFileName)
        {
         view.setFileLastComparedTo(fileName);
        }
      }
    }

   return true;
  }


  /* NOTE: some information below refers the the C++LPEX implementation:
           two views side-by-side, colored 'bar chart' in between.

    Contrast two views by finding shared lines of data [and displaying the views
  with identical sections in the same colours].

    The two views are opened, the number of lines counted, arrays set up.  A hash
  code for each line is calculated from its contents, and lines that occur
  exactly once in each view are found - these are referred to as 'pins'.  Lines
  that are the same in the two views above or below pins are also counted as
  pins.  All other lines are treated as unique.

    A composite view is constructed, which is an attempt to show all the
  lines from both views in the most likely order.  Matching blocks of lines
  are kept together;  if two blocks of lines have swapped positions in the
  second view, the smaller one is shown twice, above and below the larger one.
  Unique lines are fitted in between the matched blocks in the order they come
  in the real views.

    The two views are displayed.  The text colour indicates which lines have
  been matched, and which are unique.  The background colour shows either which
  view the lines belong to (if they are unique or have been moved to a
  different position in the second view), or that they are matched and also
  not moved.

    A 'bar chart' of the two views is also displayed.

    The line tables consist of several arrays, each with one entry for every
  line in each view.

    (1) For each line in each view, a hash value is calculated.

        long               Element
        hashValues[]       elements[]
        .-----------.      .-----------.
    v   | line1hash |      | element1  |
    i   | line2hash |      | element2  |
    e   | ...       |      | ...       |
    w   |           |      |           |
    1   |           |      |           |
        |           |      |           |
        |- - - - - -|      |- - - - - -|
        |           |      |           |
    v   |           |      |           |
    i   |           |      |           |
    e   |           |      |           |
    w   |           |      |           |
    2   |           |      |           |
        '-----------'      '-----------'

    (2) The hash value of each line is used as an index for this line in the
  hash table.  The hash table is an array of subscripts for the line tables.
  If there is no subscript at that point in the hash table, the subscript of
  the current line is entered.

    int                int
    hashTable[]        linePairs[]
    .---------.        .---------.
    |         |   .--->|=========|
    |         |   |    |         |
    |         |   |    |         |
    |         |   |    |         |
    |=========|---'    |         |
    |         |        |         |
    |         |        |         |
    |         |        |         |
    |         |        |         |
    |         |        |         |
    |         |        |         |
    |         |        |         |
    |         |        |         |
    '---------'        |         |
                       '---------'

    If there is a subscript present, the hash value of that line (stored in
  pLineHash) is compared with that of the current line.  If they don't match,
  the program looks at the next entry in the hash table.

    However, if the hash values match, we found an identical line, so we change
  the entry in the hash table to point to the current line, and put the index of
  the identical line in the linePairs entry of the current line.  Thus a chain
  of identical lines will be built up.

    hashTable[]        linePairs[]
    .---------.        .---------.
    |         |        |=========|<------.
    |         |        |         |       |
    |         |        |         |       |
    |         |        |         |       |
    |=========|---.    |=========|<---. -'
    |         |   |    |         |    |
    |         |   |    |         |    |
    |         |   |    |         |    |
    |         |   |    |=========|<. -'
    |         |   |    |         | |
    |         |   |    |         | |
    |         |   |    |         | |
    |         |   |    |         | |
    '---------'   '--->|=========|-'
                       '---------'

    After this has been done for all the lines in the two views, we look at
  each entry in the hash table.  If an entry points to a pair of lines, one
  from each view, the linePairs entry for each line is given the other's
  index.  In any other case (no matching line, two matching lines in the same
  file, or more than two matching lines) the chain is broken up totally.

    hashTable[]        linePairs[]
    .---------.        .---------.
    |         |     .--|=========|<-.
    |=========|--.  |  |         |  |
    |         |  |  |  |         |  |
    |         |  |  |  |         |  |
    |         |  |  |  |         |  |
    |         |  '->'->|=========|--'
    |         |        |         |
    |         |        |         |
    |         |     .--|=========|<-.
    |         |     |  |         |  |
    |         |     |  |         |  |
    |         |     |  |         |  |
    |=========|--.  |  |         |  |
    '---------'  '->'->|=========|--'
                       '---------'

    Lines either side of these 'pins' which match each other (but have not
  already been made pins, because there were more than 2 of them) are then
  made into pins.
  */

 /**
  * Compare the current view to the specified file.
  *
  * @param jump true = set cursor to the first mismatch
  */
 static void compare(View view, String fileName, boolean jump)
  {
   /*---------------------------------------------------*/
   /*  create a view for the file we're comparing with  */
   /*---------------------------------------------------*/
   CommandHandler._status = null; //-as- not cleared by LpexView() if all OK!?
   LpexView lpexView2 = new LpexView(fileName, false);
   View view2 = lpexView2._view;

   if (CommandHandler._status != null)
    {
     if (CommandHandler._status.equals(LpexConstants.STATUS_FILE_NOTFOUND))
      {
       view.setLpexMessageText(LpexConstants.MSG_COMPARE_FILENOTFOUND);
      }
     else
      {
       view.screen().setMessageText(view2.screen().messageText());
      }
     lpexView2.dispose();
     return;
    }

   //-as- ignore the sequence numbers; assume the file we compare to (usually,
   // the original file on the disk) has the same settings as view1
   String sequenceNumbers = view.lpexView().query("current.sequenceNumbers");
   lpexView2.doCommand("set sequenceNumbers " + sequenceNumbers);

   clear(view); // clear any previous compare marks in the view

   int maxLineLength = maxLineLength(view);
   int maxLineLength2 = maxLineLength(view2);
   if (maxLineLength2 > maxLineLength)
    {
     maxLineLength = maxLineLength2;
    }

   /*-----------------------------------------*/
   /*  create random numbers for the hashing  */
   /*-----------------------------------------*/
   /*
   The hashing is done by setting up a table of pseudo-random numbers (the
   table is maxLineLength long, the maximum number of characters in a line in
   the current compare).  The ASCII value of each character is multiplied by the
   next random number in the sequence, and added to the hash value for the line.

   Mathematical diversion:
   The random values and the hash values are 32 bits long;  hopefully this will
   produce a distribution of hash values very close to perfect, in which case
   the chances of collision for N lines are given by:
     1 - (2^32 - 1)! / ((2^32 - N)! * (2^32)^(N - 1)
   (I think; my math is getting weak, but it tallies with the case given in a
   text book of the chances of a shared birthday in a room of 23 people being
   0.5).  This works out at 0.03 for N of 16384.

   The values for the pseudo-random sequence satisfy rules given in Knuth's
   "Art of Computer Programming" for R(N) = (R(N-1) * A + C) mod M, i.e.,
     1) C and M are relatively prime
     2) B = A - 1 is a multiple of every prime of M
     3) if M is a multiple of 4, B must be as well.

   Since M = 2^32, 2) is satisfied by satisfying 3), and 1) is satisfied by any
   odd number.  This should give a sequence which only repeats every M values.
   To avoid 0 turning up in the ones used, I have started the sequence at C,
   i.e., the value following 0.  Using B = 4 speeds up computation, and using
   a large C ensures that overflow will take place, which should help make the
   distribution of hash values even.

   Check out: is Java's hashing good enough to use instead??
   */
   long random[] = new long[maxLineLength + 1];
   random[0] = 0xABCDEF01L;
   for (int i = 1;  i < maxLineLength; i++)
    {
     random[i] = (random[i-1] * 5 + 0xABCDEF01L) & 0x00000000ffffffffL;
    }

   // consider all non-show elements in the two views
   int lines1 = view.document().elementList().nonShowCount();
   int lines2 = view2.document().elementList().nonShowCount();
   int totalLines = lines1 + lines2;
   int tableSize  = totalLines + 1;

   /*--------------------------------------------------------------------------*/
   /*  (1) set up hashValues[] and elements[] for lines in both compare views  */
   /*--------------------------------------------------------------------------*/
   long hashValues[]  = new long[tableSize];
   Element elements[] = new Element[tableSize];

   int index = getHashValues(view, hashValues, elements, 1, random, view);
   getHashValues(view2, hashValues, elements, index, random, view);

   /*-----------------------------------------------*/
   /*  allocate hashTable[] and linePairs[] arrays  */
   /*-----------------------------------------------*/
   int hashTable[] = new int[tableSize];  // index of line-table entries
   int linePairs[] = new int[tableSize];
   for (int i = 0; i < tableSize; i++)
    {
     hashTable[i] = 0;
    }

   /*--------------------------------------------------------------------*/
   /*  chain identical lines:  find lines with the same hash value, and  */
   /*  form them into a chain using the linePairs[] array as pointers    */
   /*--------------------------------------------------------------------*/
   for (int i = 1;  i <= totalLines;  i++)
    {
     // use the line's hash value to obtain its hash index
     long hashValue = hashValues[i];
     int hashIndex = (int)(hashValue % totalLines);  // index into hashTable[]
     if (hashIndex < 0)
      {
       hashIndex = -hashIndex;
      }

     // look for free place in the hash table
     int pair = hashTable[hashIndex];
     while (pair != 0 &&
            hashValues[pair] != hashValue)
      {
       hashIndex = hashIndex + 1;    // C++LPEX:
       if (hashIndex >= totalLines)  //  hashIndex = (hashIndex +1) % totalLines;
        {                            //
         hashIndex = 0;              //
        }                            //
       pair = hashTable[hashIndex];
      }

     // chain this line to any others with the same hash value
     linePairs[i] = pair;
     hashTable[hashIndex] = i;
    }

   /*-----------------------------------------------------*/
   /*  find unique pairs:  pair lines that occur exactly  */
   /*  once in each view, and break any other chains      */
   /*-----------------------------------------------------*/
   for (int hashIndex = 0;  hashIndex < totalLines;  hashIndex++)
    {
     int i = hashTable[hashIndex];

     // if there is such a line
     if (i != 0)
      {
       int pair = linePairs[i];
       if (pair != 0 &&
           linePairs[pair] == 0 &&
           i > lines1 &&
           pair <= lines1)    // 1.- one line in each view, so pair up
        {
         linePairs[pair] = i;
        }

       else                   // 2.- identical lines in same view, so break chain
        {
         while (i != 0)
          {
           pair = linePairs[i];
           linePairs[i] = 0;
           i = pair;
          }
        }
      }
    }

   /*---------------------------------------------------------------------*/
   /*  expand unique pairs:  pair up identical lines before or after      */
   /*  unique pairs;  these will be lines that have 2 or more duplicates  */
   /*---------------------------------------------------------------------*/
   for (int i = 0;  i <= lines1 + 1;  i++)
    {
     // pretend there are unique pairs before and after the files,
     // so the first and last lines will be paired if identical
     int pair;
     if (i == 0)
      {
       pair = lines1;
      }
     else if (i > lines1)
      {
       pair = totalLines + 1;
      }
     else
      {
       pair = linePairs[i];
      }

     if (pair != 0)
      {
       // move forwards looking for identical lines
       int j = 1;
       while (pair + j <= totalLines &&
              i + j <= lines1 &&
              hashValues[i + j] == hashValues[pair + j] &&
              linePairs[i + j] == 0 &&
              linePairs[pair + j] == 0)
        {
         linePairs[i + j] = pair + j;
         linePairs[pair + j] = i + j;
         j++;
        }

       // and move backwards
       j = -1;
       while (pair + j > lines1 &&
              i +j > 0 &&
              hashValues[i + j] == hashValues[pair + j] &&
              linePairs[i + j] == 0 &&
              linePairs[pair + j] == 0)
        {
         linePairs[i + j] = pair + j;
         linePairs[pair + j] = i + j;
         j--;
        }
      }
    }//end "for"

   pruneBlock(linePairs, 1, lines1, lines1 + 1, tableSize);

   /*--------------------*/
   /*  mark added lines  */
   /*--------------------*/
   MarkList.Mark firstMark = null;
   int addedBlocks = 0;
   for (int i = 1; i <= lines1; i++)
    {
     int pair = linePairs[i];
     if (pair == 0)
      {
       int startLine = i;
       int endLine = i;
       while (i < lines1 && linePairs[i + 1] == 0)
        {
         i++;
         endLine = i;
        }

       MarkList.Mark mark = new AddedLines(view, elements[startLine], elements[endLine]);
       addedBlocks++;
       if (addedBlocks == 1)
        {
         firstMark = mark;
        }
      }
    }

   /*----------------------*/
   /*  mark deleted lines  */
   /*----------------------*/
   int deletedBlocks = 0;
   DocumentPosition.Preserve preserve = view.documentPosition().preserve();
   int lastMatch = 0;
   for (int i = lines1 + 1; i < tableSize; i++)
    {
     int pair = linePairs[i];
     if (pair == 0)
      {
       Element element = new Element(view);
       element.setText(view, elements[i].text());
       if (lastMatch == 0)
        {
         Element firstElement = view.document().elementList().first();
         view.documentPosition().jump(firstElement, 1);
         view.insertElementBefore(element);
        }
       else
        {
         view.documentPosition().jump(elements[lastMatch], 1);
         view.insertElement(element);
        }

       Element endElement = element;
       while (i < tableSize - 1 && linePairs[i + 1] == 0)
        {
         i++;
         endElement = new Element(view);
         endElement.setText(view, elements[i].text());
         view.insertElement(endElement);
        }

       MarkList.Mark mark = new DeletedLines(view, element, endElement);
       deletedBlocks++;
       if (deletedBlocks == 1)
        {
         firstMark = mark;
        }
      }
     else
      {
       lastMatch = pair;
      }
    }

   /*-------------*/
   /*  finish up  */
   /*-------------*/
   preserve.restore();
   view.documentPosition().disposePreserve(preserve);

   lpexView2.dispose();

   if (jump == true && firstMark != null)
    {
     view.documentPosition().jump(firstMark.documentLocation());
     view.screen().setCursorRow(3);
    }

   if (addedBlocks == 0 && deletedBlocks == 0)
    {
     view.setLpexMessageText(LpexConstants.MSG_COMPARE_NOMISMATCHES);
    }
   else
    {
     view.setLpexMessageText(LpexConstants.MSG_COMPARE_MISMATCHES);
    }
  }

 /**
  * Move the cursor to the next mismatch in the view, after
  * the element that is currently under the cursor.
  */
 private static void nextMismatch(View view)
  {
   Element currentElement = view.documentPosition().element();
   if (currentElement != null)
    {
     MarkList.Mark currentMark = null;
     ElementView.MarkNode currentNode = currentElement.elementView(view)._firstMarkNode;
     while (currentNode != null && !(currentNode.mark() instanceof CompareMark))
      {
       currentNode = currentNode._next;
      }

     if (currentNode != null)
      {
       currentMark = currentNode.mark();
      }

     for (Element element = currentElement.next();
          element != null;
          element = element.next())
      {
       MarkList.Mark nextMark = null;
       ElementView.MarkNode markNode = element.elementView(view)._firstMarkNode;
       while (markNode != null && nextMark == null)
        {
         nextMark = markNode.mark();
         if (!(nextMark instanceof CompareMark) || nextMark == currentMark)
          {
           nextMark = null;
          }
         markNode = markNode._next;
        }

       // another condition is "nextMark instanceof CompareMark"
       // but this is true if nextMark isn't null, due to the
       // conditions of the preceding loop
       if (nextMark != null)
        {
         view.documentPosition().jump(element, 1);
         return;
        }
      }
    }

   view.setLpexMessageText(LpexConstants.MSG_COMPARE_NOMOREMISMATCHES);
   return;
  }

 /**
  * Move the cursor to the previous mismatch in the view, before
  * the element that is currently under the cursor.
  */
 private static void previousMismatch(View view)
  {
   Element currentElement = view.documentPosition().element();
   if (currentElement != null)
    {
     MarkList.Mark currentMark = null;
     ElementView.MarkNode currentNode = currentElement.elementView(view)._firstMarkNode;
     while (currentNode != null && !(currentNode.mark() instanceof CompareMark))
      {
       currentNode = currentNode._next;
      }

     if (currentNode != null)
      {
       currentMark = currentNode.mark();
      }

     for (Element element = currentElement.prev();
          element != null;
          element = element.prev())
      {
       MarkList.Mark prevMark = null;
       ElementView.MarkNode markNode = element.elementView(view)._firstMarkNode;
       while (markNode != null && prevMark == null)
        {
         prevMark = markNode.mark();
         if (!(prevMark instanceof CompareMark) || prevMark == currentMark)
          {
           prevMark = null;
          }
         markNode = markNode._next;
        }

       // another condition is "prevMark instanceof CompareMark"
       // but this is true if prevMark isn't null due to the
       // conditions of the preceding loop
       if (prevMark != null)
        {
         view.documentPosition().jump(prevMark.documentLocation());
         return;
        }
      }
    }

   view.setLpexMessageText(LpexConstants.MSG_COMPARE_NOMOREMISMATCHES);
   return;
  }

 /**
  * Get the maximum non-SHOW line length in this view.
  */
 private static int maxLineLength(View view)
  {
   int maxLineLength = 0;

   ElementList elementList = view.document().elementList();
   for (Element element = elementList.first();
        element != null;
        element = element.next())
    {
     if (!element.show())
      {
       //-as- ignore sequence numbers
       // int fullTextLength = elementList.fullTextLength(element);
       int textLength = element.length();

       if (textLength > maxLineLength)
        {
         maxLineLength = textLength;
        }
      }
    }

   return maxLineLength;
  }

 /**
  * Build up the hash values for the lines of one of the views participating
  * in the compare, and append them to the hashValues[] array.  The current
  * compare options are taken into consideration.  Also record all the elements
  * of the view in the elements[] array.  All non-show lines in the view are
  * used.
  *
  * Sets up: hashValues[index .. index + view's last element no.] := hashValue;
  *          elements[index .. index + view's last element no.]   := element;
  *
  * @return the next available index in these tables
  */
 private static int getHashValues(View view, long hashValues[], Element elements[],
                                  int index, long random[],
                                  View mainView) // to get current compare.xxx options
  {
   boolean ignoreCase = ignoreCaseParameter().currentValue(mainView);
   boolean ignoreLeadingBlanks = ignoreLeadingBlanksParameter().currentValue(mainView);
   boolean ignoreTrailingBlanks = ignoreTrailingBlanksParameter().currentValue(mainView);
   boolean ignoreAllBlanks = ignoreAllBlanksParameter().currentValue(mainView);

   // do it line-by-line...
   ElementList elementList = view.document().elementList();
   for (Element element = elementList.first();
        element != null;
        element = element.next())
    {
     if (!element.show())
      {
       //-as- don't include sequence numbers (although we currently have no way to
       // specify the sequence numbers for the file we compare to, assume the same!?)
       // String text = element.fullText();
       String text = element.text();

       /*--------------------------------------*/
       /*  adjust line's text for ignore case  */
       /*--------------------------------------*/
       if (ignoreCase)
        {
         text = text.toLowerCase();
        }

       /*-------------------------------------------------------------*/
       /*  adjust line's text for ignore leading/trailing/all blanks  */
       /*-------------------------------------------------------------*/
       //-as- should just parse text as it is & calculate hashValue as we go!?..
       if (ignoreLeadingBlanks || ignoreTrailingBlanks || ignoreAllBlanks)
        {
         int textLength = text.length();
         int start = 0;          // ZERO-based index of 1st char that counts
         int end = textLength-1; // ZERO-based index of last char that counts

         char currentChar;

         if (ignoreLeadingBlanks)
          {
           try
            {
             currentChar = text.charAt(start);
             while (currentChar == ' ' || currentChar == '\t')
              {
               ++start;
               currentChar = text.charAt(start);
              }
            }
           catch(java.lang.StringIndexOutOfBoundsException e)
            {
             start = textLength; // no non-blank characters in the element
            }
          }

         if (ignoreTrailingBlanks)
          {
           try
            {
             currentChar = text.charAt(end);
             while ((currentChar == ' ' || currentChar == '\t') && end >= start)
              {
               --end;
               currentChar = text.charAt(end);
              }
            }
           catch(java.lang.StringIndexOutOfBoundsException e)
            {
             end = -1; // no non-blank characters in the element
            }
          }

         if (ignoreAllBlanks)
          {
           StringBuffer strippedText = new StringBuffer(textLength);
           for (; start <= end; start++)
            {
             currentChar = text.charAt(start);
             if (currentChar != ' ' && currentChar != '\t')
              {
               strippedText.append(currentChar);
              }
            }
           text = strippedText.toString();
          }
         else // just ignoreLeadingBlanks and/or ignoreTrailingBlanks
          {
           text = (start <= end)? text.substring(start, end+1) : "";
          }
        }

       int len = text.length();

       /*------------------------------------*/
       /*  generate hash value for the line  */
       /*------------------------------------*/
       long hashValue = 0;
       for (int i = 0; i < len; i++)
        {
         hashValue += random[i] * text.charAt(i);
         hashValue &= 0x00000000ffffffffL;
        }

       hashValues[index] = hashValue;
       elements[index] = element;

       index++;
      }
    }

   return index;
  }

 private static void pruneBlock(int linePairs[], int topA, int bottomA,
                                int topB, int bottomB)
  {
   int maxBlockLength = 0;
   int maxBlockTop = 0;
   int maxBlockBottom = 0;
   int currentBlockLength = 0;
   int currentBlockTop = 0;
   int currentBlockBottom = 0;
   int lastPair = 0;

   for (int i = topA; i <= bottomA; i++)
    {
     int pair = linePairs[i];
     if (pair > bottomB || pair < topB)
      {
       linePairs[i] = 0;
       linePairs[pair] = 0;
       pair = 0;
      }

     if (currentBlockLength == 0)
      {
       if (pair != 0)
        {
         currentBlockLength = 1;
         currentBlockTop = i;
         currentBlockBottom = i;
        }
      }
     else
      {
       if (pair == 0 || pair != lastPair + 1)
        {
         if (currentBlockLength > maxBlockLength)
          {
           maxBlockLength = currentBlockLength;
           maxBlockTop = currentBlockTop;
           maxBlockBottom = currentBlockBottom;
          }
         currentBlockLength = 0;
        }
       else
        {
         currentBlockLength++;
         currentBlockBottom = i;
        }
      }

     lastPair = pair;
    }

   if (currentBlockLength > maxBlockLength)
    {
     maxBlockLength = currentBlockLength;
     maxBlockTop = currentBlockTop;
     maxBlockBottom = currentBlockBottom;
    }

   if (maxBlockLength > 0)
    {
     if (topA < maxBlockTop)
      {
       pruneBlock(linePairs, topA, maxBlockTop - 1,       // NB recursively!
                  topB, linePairs[maxBlockTop] - 1);
      }

     if (maxBlockBottom < bottomA)
      {
       pruneBlock(linePairs, maxBlockBottom + 1, bottomA, // NB recursively!
                  linePairs[maxBlockBottom] + 1, bottomB);
      }
    }
  }

 /**
  * Clear all the compare marks set up in the specified <code>view</code>.
  */
 static void clear(View view)
  {
   MarkList.MarkNode next = null;
   for (MarkList.MarkNode markNode = (MarkList.MarkNode)view.markList().first();
        markNode != null;
        markNode = next)
    {
     next = (MarkList.MarkNode)markNode.next();
     MarkList.Mark mark = markNode.mark();
     if (mark instanceof CompareMark)
      {
       mark.clear();
      }
    }
  }


 /**
  * Base compare mark.  Further extended by AddedLines and DeletedLines.
  */
 static class CompareMark extends MarkList.ElementMark
 {
  int _styleId;

  CompareMark(View view, Element element1, Element element2, int styleId)
   {
    view.markList().super(null, 0, element1, element2, false);
    setHighlight(true);
    _styleId = styleId;
   }

  StyleAttributes defaultStyleAttributes()
   {
    return view().screen().styleAttributes(_styleId);
   }
 }


 /**
  * Mark for added lines (lines not in the other view).
  */
 static final class AddedLines extends CompareMark
 {
  AddedLines(View view, Element element1, Element element2)
   {
    super(view, element1, element2, Screen.STYLE_ADDED_LINES);
   }
 }


 /**
  * Mark for deleted lines (lines still in the other view), protected from editing.
  */
 static final class DeletedLines extends CompareMark
 {
  DeletedLines(View view, Element element1, Element element2)
   {
    super(view, element1, element2, Screen.STYLE_DELETED_LINES);
    setProtect(true);
   }

  void clear()
   {
    Element element = _element1;
    Element elementEnd = (_element2 != null)? _element2.next() : null;
    super.clear();
    if (element != null)
     {
      while (element != elementEnd)
       {
        Element next = element.next();
        view().deleteElement(element);
        element = next;
       }
     }
   }
 }


 /**
  * Implements <b>compare.ignoreCase</b> parameter.
  */
 static final class IgnoreCaseParameter extends ParameterOnOffDefault
 {
  IgnoreCaseParameter()
   {
    super(PARAMETER_COMPARE + COMPARE_PARAMETER_IGNORECASE, false);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.compareCommandSettings()._ignoreCase = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.compareCommandSettings()._ignoreCase :
                           Parameter.DEFAULT;
   }
 }

 private static IgnoreCaseParameter _ignoreCaseParameter;
 static IgnoreCaseParameter ignoreCaseParameter()
  {
   if (_ignoreCaseParameter == null)
    {
     _ignoreCaseParameter = new IgnoreCaseParameter();
    }
   return _ignoreCaseParameter;
  }


 /**
  * Implements <b>compare.ignoreLeadingBlanks</b> parameter.
  */
 static final class IgnoreLeadingBlanksParameter extends ParameterOnOffDefault
 {
  IgnoreLeadingBlanksParameter()
   {
    super(PARAMETER_COMPARE + COMPARE_PARAMETER_IGNORELEADINGBLANKS, false);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.compareCommandSettings()._ignoreLeadingBlanks = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.compareCommandSettings()._ignoreLeadingBlanks :
                           Parameter.DEFAULT;
   }
 }

 private static IgnoreLeadingBlanksParameter _ignoreLeadingBlanksParameter;
 static IgnoreLeadingBlanksParameter ignoreLeadingBlanksParameter()
  {
   if (_ignoreLeadingBlanksParameter == null)
    {
     _ignoreLeadingBlanksParameter = new IgnoreLeadingBlanksParameter();
    }
   return _ignoreLeadingBlanksParameter;
  }


 /**
  * Implements <b>compare.ignoreTrailingBlanks</b> parameter.
  */
 static final class IgnoreTrailingBlanksParameter extends ParameterOnOffDefault
 {
  IgnoreTrailingBlanksParameter()
   {
    super(PARAMETER_COMPARE + COMPARE_PARAMETER_IGNORETRAILINGBLANKS, false);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.compareCommandSettings()._ignoreTrailingBlanks = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.compareCommandSettings()._ignoreTrailingBlanks :
                           Parameter.DEFAULT;
   }
 }

 private static IgnoreTrailingBlanksParameter _ignoreTrailingBlanksParameter;
 static IgnoreTrailingBlanksParameter ignoreTrailingBlanksParameter()
  {
   if (_ignoreTrailingBlanksParameter == null)
    {
     _ignoreTrailingBlanksParameter = new IgnoreTrailingBlanksParameter();
    }
   return _ignoreTrailingBlanksParameter;
  }


 /**
  * Implements <b>compare.ignoreAllBlanks</b> parameter.
  */
 static final class IgnoreAllBlanksParameter extends ParameterOnOffDefault
 {
  IgnoreAllBlanksParameter()
   {
    super(PARAMETER_COMPARE + COMPARE_PARAMETER_IGNOREALLBLANKS, false);
   }

  String name(String qualifier)
   {
    return name();
   }

  boolean setValue(View view, int value)
   {
    if (view != null)
     {
      view.compareCommandSettings()._ignoreAllBlanks = value;
     }
    return true;
   }

  int value(View view)
   {
    return (view != null)? view.compareCommandSettings()._ignoreAllBlanks :
                           Parameter.DEFAULT;
   }
 }

 private static IgnoreAllBlanksParameter _ignoreAllBlanksParameter;
 static IgnoreAllBlanksParameter ignoreAllBlanksParameter()
  {
   if (_ignoreAllBlanksParameter == null)
    {
     _ignoreAllBlanksParameter = new IgnoreAllBlanksParameter();
    }
   return _ignoreAllBlanksParameter;
  }


 final static class Settings
 {
  int _ignoreCase           = Parameter.DEFAULT;
  int _ignoreLeadingBlanks  = Parameter.DEFAULT;
  int _ignoreTrailingBlanks = Parameter.DEFAULT;
  int _ignoreAllBlanks      = Parameter.DEFAULT;
 }
}