//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexView - this class can be used to manage an LPEX document view.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.io.Reader;
import java.io.Writer;

import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Widget;


/**
 * The class LpexView can be used to manage an LPEX document view.
 * It essentially provides all the editor programming support.
 * Creating an instance of this class creates a document view.
 *
 * @see LpexWindow
 */
public class LpexView
{
 View _view;
 private String _defaultHelpPage;
 private Shell _frame;

 private KeyListenerList _keyListenerList; // SWT


 /**
  * This constructor can be used to create a document from the specified file
  * name, indicating whether the <b>updateProfile</b> command should be called.
  *
  * <p>If you specify <code>true</code> for updateProfile, then the
  * <b>updateProfile</b> command will be called with the default settings.
  * If you specify <code>false</code>, then <b>updateProfile</b> will not be
  * called;  you can then change the updateProfile settings and issue
  * the <b>updateProfile</b> command later.</p>
  */
 public LpexView(String fileName, boolean updateProfile)
 {
  new Document(fileName, this, updateProfile);
 }

 /**
  * This constructor can be used to create a document from the specified
  * file name.
  *
  * <p>The <b>updateProfile</b> command will be called, with the default
  * settings.</p>
  */
 public LpexView(String fileName)
 {
  this(fileName, true);
 }

 /**
  * This constructor can be used to create an untitled document.
  *
  * <p>The <b>updateProfile</b> command will be called, with the default
  * settings.</p>
  */
 public LpexView()
 {
  this((String)null, true);
 }

 /**
  * This constructor can be used to create an untitled document, indicating
  * whether the <b>updateProfile</b> command should be called.
  *
  * <p>If you specify <code>true</code> for updateProfile, then the
  * <b>updateProfile</b> command will be called with the default settings.
  * If you specify <code>false</code>, then <b>updateProfile</b> will not be
  * called;  you can then change the updateProfile settings and issue
  * the <b>updateProfile</b> command later.</p>
  */
 public LpexView(boolean updateProfile)
 {
  this((String)null, updateProfile);
 }

 /**
  * This constructor can be used to create a new document view from the
  * specified document view.
  *
  * <p>The <b>updateProfile</b> command will be called, with the default
  * settings.</p>
  */
 public LpexView(LpexView lpexView)
 {
  new View(this, lpexView._view.document(), true);
 }

 /**
  * This constructor can be used to create a new document view from the
  * specified document view, indicating whether the <b>updateProfile</b>
  * command should be called.
  *
  * <p>If you specify <code>true</code> for updateProfile, then the
  * <b>updateProfile</b> command will be called with the default settings.
  * If you specify <code>false</code>, then <b>updateProfile</b> will not be
  * called;  you can then change the updateProfile settings and issue
  * the <b>updateProfile</b> command later.</p>
  */
 public LpexView(LpexView lpexView, boolean updateProfile)
 {
  new View(this, lpexView._view.document(), updateProfile);
 }

 /**
  * This method disposes the view.
  */
 public void dispose()
 {
  _view.dispose();
  System.gc();
 }

 /**
  * Use this method to associate an LPEX window with this document view.
  */
 public void setWindow(LpexWindow lpexWindow)
 {
  _view.setWindow(lpexWindow);
 }

 /**
  * Retrieve the LPEX window currently associated with this view.
  */
 public LpexWindow window()
 {
  return _view.window();
 }

 /**
  * Retrieve the NLS object associated with this LpexView.
  * The National Language Support functions in LPEX are accessible via this
  * object.
  *
  * @see LpexNls
  */
 public LpexNls nls()
 {
  return _view.nls();
 }

 /**
  * Set the entire text of the document (or document section).
  *
  * @see #text
  */
 public void setText(String text)
 {
  _view.document().setText(_view, text);
 }

 /**
  * Retrieve the entire text of the document (or document section currently
  * loaded in the editor).
  *
  * @see #setText
  * @see #save(Writer)
  */
 public String text()
 {
  return _view.document().text();
 }

 /**
  * Load the entire text of the document (or document section) from the
  * specified Reader.
  *
  * @return <code>true</code> if the text was loaded successfully
  */
 public boolean load(Reader reader)
 {
  return _view.document().loadFromReader(_view, reader);
 }

 /**
  * Save the entire text of the document (or document section currently
  * loaded in the ditor) to the specified Writer.
  *
  * @return <code>true</code> if the text was saved successfully
  * @see #text
  */
 public boolean save(Writer writer)
 {
  return _view.document().saveToWriter(writer);
 }

 /**
  * Set the <code>Writer</code> object for the <b>saveToWriter</b> action.
  * The <b>saveToWriter</b> action will then run the <b>save</b> command to
  * the specified Writer, rather than to the document's file.  The <b>save</b>
  * command makes use of certain settings, such as <b>save.textLimit</b>, to
  * determine what text is actually saved.
  *
  * <p>Example of using <b>saveToWriter</b> with an OutputStreamWriter:
  * <pre>
  *   ByteArrayOutputStream bytes = new ByteArrayOutputStream();
  *   OutputStreamWriter writer = new OutputStreamWriter(bytes);
  *   lpexView.setSaveWriter(writer);
  *   lpexView.triggerAction(lpexView.actionId("saveToWriter"));
  *   lpexView.setSaveWriter(null); </pre></p>
  *
  * <p>Example of using <b>saveToWriter</b> to save to a String:
  * <pre>
  *   StringWriter writer = new StringWriter();
  *   lpexView.setSaveWriter(writer);
  *   lpexView.doAction(lpexView.actionId("saveToWriter"));
  *   lpexView.setSaveWriter(null);
  *   String savedDocument = writer.toString(); </pre></p>
  */
 public void setSaveWriter(Writer writer)
 {
  _view.setSaveWriter(writer);
 }

 /**
  * Set the line separator for the <b>save</b>, <b>saveAs</b>, and
  * <b>saveToWriter</b> actions.
  *
  * Example:
  * <pre>
  *   lpexView.setSaveLineSeparator("\r\n"); // use Windows-style CR LF </pre>
  *
  * If not set, the platform's default line separator is used.
  */
 public void setSaveLineSeparator(String eol)
 {
  _view.setSaveLineSeparator(eol);
 }

 /**
  * Define a user command.
  *
  * @see LpexCommand
  */
 public LpexCommand defineCommand(String commandString, LpexCommand lpexCommand)
 {
  return _view.commandHandler().defineCommand(commandString, lpexCommand);
 }

 /**
  * Retrieve the specified user-defined command.
  * Example:
  * <pre>
  *   LpexCommand myInsertTextCommand = lpexView.command("myInsertText"); </pre>
  */
 public LpexCommand command(String commandString)
 {
  return _view.commandHandler().command(commandString);
 }

 /**
  * Perform the default editor command for the specified command string.
  * Example:
  * <pre>
  *   lpexView.doDefaultCommand("insertText xyz"); </pre>
  *
  * @return <code>true</code> if the command string is valid, or
  *         <code>false</code> if the command string is not valid
  */
 public boolean doDefaultCommand(String commandString)
 {
  return CommandHandler.doDefaultCommand(_view, commandString);
 }

 /**
  * Perform the default editor command for the specified command string.
  * If the command requires a document location, then the specified document
  * (or document section) location will be used.  If the command changes the
  * view's document location, then the specified document location will be
  * updated;  the view's actual current (cursor) document location will not be
  * affected, to the extent that its underlying text is not affected.
  *
  * @param documentLocation a document location (element, position) in the
  *           document section currently loaded in the editor
  *
  * @return <code>true</code> if the command string is valid, or
  *         <code>false</code> if the command string is not valid
  */
 public boolean doDefaultCommand(LpexDocumentLocation documentLocation,
                                 String commandString)
 {
  return CommandHandler.doDefaultCommand(_view, documentLocation, commandString);
 }

 /**
  * Perform the specified command.
  *
  * @return <code>true</code> if the command string is valid, or
  *         <code>false</code> if the command string is not valid
  */
 public boolean doCommand(String commandString)
 {
  return _view.commandHandler().doCommand(commandString);
 }

 /**
  * Perform the specified command.
  * The command should be a globally-scoped command, i.e., one that does not
  * require a document view.
  * Example:
  * <pre>
  *   LpexView.doGlobalCommand("updateProfile all"); </pre>
  *
  * @return <code>true</code> if the command string is valid, or
  *         <code>false</code> if the command string is not valid
  */
 public static boolean doGlobalCommand(String commandString)
 {
  return CommandHandler.doDefaultCommand(commandString);
 }

 /**
  * Perform the specified command at the specified document (or document
  * section) location.  If the command requires a document location, then the
  * specified document (or document section) location will be used.  If the
  * command changes the view's document location, then the given document
  * location will be updated;  the view's actual current (cursor) document
  * location will not be affected, to the extent that its underlying text is
  * not affected.
  *
  * @param documentLocation a document location (element, position) in the
  *           document section currently loaded in the editor
  *
  * @return <code>true</code> if the command string is valid, or
  *         <code>false</code> if the command string is not valid
  */
 public boolean doCommand(LpexDocumentLocation documentLocation, String commandString)
 {
  return _view.commandHandler().doCommand(documentLocation, commandString);
 }

 /**
  * Define a user action.
  *
  * @return previous user-defined action for this <code>actionString</code>, if any
  * @see LpexAction
  */
 public LpexAction defineAction(String actionString, LpexAction lpexAction)
 {
  return _view.actionHandler().defineAction(actionString, lpexAction);
 }

 /**
  * Retrieve the id of the specified default or user-defined action.
  *
  * @return 0 if the action is not defined
  */
 public int actionId(String actionString)
 {
  return _view.actionHandler().id(actionString);
 }

 /**
  * Retrieve the specified user-defined action.
  */
 public LpexAction action(String actionString)
 {
  return _view.actionHandler().action(actionString);
 }

 /**
  * Perform the default editor action for the specified action id.
  *
  * @param actionId id of a default editor action
  */
 public void doDefaultAction(int actionId)
 {
  _view.actionHandler().doDefaultAction(actionId);
 }

 /**
  * Check whether the specified default editor action is available.
  *
  * @param actionId id of a default editor action
  */
 public boolean defaultActionAvailable(int actionId)
 {
  return _view.actionHandler().defaultActionAvailable(actionId);
 }

 /**
  * Perform the specified action.  Use this method instead of triggerAction()
  * if you are implementing your own command or action.  No screen refresh
  * will be done after the action has completed.
  *
  * <p>Note that the LPEX built-in action ids defined in LpexConstants (e.g.,
  * LpexConstants.ACTION_BLOCK_COPY) may change between releases.
  * In order to isolate your code from dependency on a certain LPEX release,
  * you should first query, and eventually cache, the id of a built-in action
  * before using it, for example:
  * <pre>
  *   int blockCopyId = lpexView.actionId("blockCopy");
  *   lpexView.triggerAction(blockCopyId); </pre></p>
  *
  * @param actionId id of a default or user-defined editor action
  *
  * @see #triggerAction
  * @see #actionId
  */
 public void doAction(int actionId)
 {
  _view.actionHandler().doAction(actionId);
 }

 /**
  * Check whether the specified action is available.
  *
  * @param actionId id of a default or user-defined editor action
  */
 public boolean actionAvailable(int actionId)
 {
  return _view.actionHandler().actionAvailable(actionId);
 }

 /**
  * Get the primary key associated with the specified action.
  *
  * @param actionId id of a default or user-defined editor action
  *
  * @return primary key definition, e.g., "a-pageDown.t"
  * @see #actionKeyText
  */
 public String actionKey(int actionId)
 {
  return _view.actionHandler().keyString(actionId);
 }

 /**
  * Get a translated text version of the primary key for the specified action.
  *
  * @param actionId id of a default or user-defined editor action
  *
  * @return primary key, e.g., "Alt+Page down"
  * @see #actionKey
  */
 public String actionKeyText(int actionId)
 {
  return _view.actionHandler().keyText(actionId);
 }

 /**
  * Return the key text of the primary key for the specified action, suitable
  * for an Eclipse action text accelerator, e.g., Ctrl+Space.
  * See org.eclipse.jface.action.Action#findModifier() and #findKeyCode().
  *
  * <p><b>NOTE:  In Eclipse R2.0, an action accelerator can probably be better
  * set via its tag, so this method will be soon removed!!</b></p>
  *
  * @param actionId id of a default or user-defined editor action
  *
  * @return primary key, e.g., "Alt+Page_Down"
  * @see #actionKey
  */
 public String eclipseActionKeyText(int actionId)
 {
  return _view.actionHandler().eclipseKeyText(actionId);
 }

 /**
  * Check whether the specified key is associated with an action.
  * A key associated with action <b>nullAction</b> is considered unassigned.
  * This method allows to associate actions to keys without overriding previous
  * assignments.
  *
  * For example,
  * <pre>
  *   keyAssigned("c-o.t"); </pre>
  * will return <code>true</code> if an action was defined and associated with
  * Ctrl+O in the text area.
  */
 public boolean keyAssigned(String keyString)
 {
  String temp = _view.actionHandler().keyActionString(keyString);
  return (temp != null && !temp.equals("nullAction"));
 }

 /**
  * Perform the specified action.  Use this method instead of doAction() if
  * you are processing anything other than your own action or command (e.g., a
  * listener notification, a menu or toolbar action, etc.).  This method ensures
  * that the screen will be refreshed.
  *
  * <p>Note that the LPEX built-in action ids defined in LpexConstants (e.g.,
  * LpexConstants.ACTION_BLOCK_COPY) may change between releases.
  * In order to isolate your code from dependency on a certain LPEX release,
  * you should first query, and eventually cache, the id of a built-in action
  * before using it, for example:
  * <pre>
  *   int blockCopyId = lpexView.actionId("blockCopy");
  *   lpexView.triggerAction(blockCopyId); </pre></p>
  *
  * @param actionId id of a default or user-defined editor action
  *
  * @see #doAction
  * @see #actionId
  */
 public void triggerAction(int actionId)
 {
  _view.actionHandler().triggerAction(actionId);
 }

 /**
  * Retrieve the number of elements in the document (or section of the document
  * that is currently loaded in the editor).
  *
  * Elements include show lines and non-show lines.  Show lines are not saved
  * when the document is saved.
  *
  * <p>Note: the <b>elements</b> editor parameter always returns the number of
  * elements in the <i>complete</i> document.</p>
  */
 public int elements()
 {
  return _view.document().elementList().count();
 }

 /**
  * Move the cursor to the specified position in the document (or section of the
  * document that is currently loaded in the editor).
  *
  * <p>Note: the <b>locate</b> editor command always applies to elements or
  * lines in the <i>complete</i> document.</p>
  *
  * @param element an element in the document section currently
  *                loaded in the editor
  *
  * @see #jump(LpexDocumentLocation)
  */
 public void jump(int element, int position)
 {
  _view.documentPosition()
       .jump(_view.document().elementList().elementAt(element), position);
 }

 /**
  * Move the cursor to the specified position in the document (or section of
  * the document that is currently loaded in the editor).
  *
  * <p>Note: the <b>locate</b> editor command always applies to elements or
  * lines in the <i>complete</i> document.</p>
  *
  * @param documentLocation a document location (element, position) in the
  *           document section currently loaded in the editor
  *
  * @see #jump(int,int)
  */
 public void jump(LpexDocumentLocation documentLocation)
 {
  _view.documentPosition().jump(documentLocation);
 }

 /**
  * Get the current document parser for this view.
  */
 public LpexParser parser()
 {
  return _view.parsePendingList().lpexParser();
 }

 /**
  * Query the parse-pending state of the specified element.
  *
  * @return one or more of these flags:
  *         LpexConstants.PARSE_PENDING_CHANGE_MASK,
  *         LpexConstants.PARSE_PENDING_NEXT_DELETED_MASK,
  *         LpexConstants.PARSE_PENDING_PREV_DELETED_MASK,
  *         LpexConstants.PARSE_PENDING_NEXT_SHOW_DELETED_MASK,
  *         LpexConstants.PARSE_PENDING_PREV_SHOW_DELETED_MASK
  */
 public int parsePending(int element)
 {
  Element e = _view.document().elementList().elementAt(element);
  ParsePending parsePending = _view.parsePendingList().find(e);
  return (parsePending != null)? parsePending.type() : 0;
 }

 /**
  * Remove the specified element from the parse-pending list.
  * This view's document parser will not be called for this element until
  * after a subsequent change.
  */
 public void elementParsed(int element)
 {
  Element e = _view.document().elementList().elementAt(element);
  ParsePending parsePending = _view.parsePendingList().find(e);
  if (parsePending != null)
   {
    _view.parsePendingList().remove(parsePending);
   }
 }

 /**
  * Get the text of an element in the document (or document section currently
  * loaded in the editor).
  * If there is no such element, <code>null</code> is returned.
  * If the element has no text, an empty String is returned.
  *
  * <p>Note: the <b>text</b> editor parameter applies to the current
  * element.</p>
  *
  * @param element an element in the document section currently
  *                loaded in the editor
  */
 public String elementText(int element)
 {
  Element e = _view.document().elementList().elementAt(element);
  return (e != null)? e.text() : null;
 }

 /**
  * Set the text for an element in the document (or document section that is
  * currently loaded in the editor).
  *
  * <p>Note: the <b>text</b> editor parameter applies to the current
  * element.</p>
  *
  * @param element an element in the document section currently
  *                loaded in the editor
  * @param text the text to set
  */
 public void setElementText(int element, String text)
 {
  CommandHandler.doDefaultCommand(_view, new LpexDocumentLocation(element, 1),
                                  "set text " + text);
 }

 /**
  * Get the <b>show</b> setting for an element in the document (or document
  * section that is currently loaded in the editor).
  *
  * <p>Note: the <b>show</b> editor parameter applies to the current
  * element.</p>
  *
  * @param element an element in the document section currently
  *                loaded in the editor
  */
 public boolean show(int element)
 {
  Element e = _view.document().elementList().elementAt(element);
  return (e != null)? e.show() : false;
 }

 /**
  * Determine if the specified element in the document (or document section that
  * is currently loaded in the editor) is a <b>show</b> line for another document
  * view.
  *
  * @param element an element in the document section currently
  *                loaded in the editor
  */
 public boolean otherShow(int element)
 {
  Element e = _view.document().elementList().elementAt(element);
  return (e != null)? (e.show() && !e.elementView(_view).show()) : false;
 }

 /**
  * Get the style string for an element in the document (or document section
  * currently loaded in the editor).
  * If there is no such element, <code>null</code> is returned.
  * If the element has no style string set, an empty String is returned.
  *
  * <p>Note: the <b>style</b> editor parameter applies to the current
  * element.</p>
  *
  * @param element an element in the section of the document that
  *                is currently loaded in the editor
  */
 public String elementStyle(int element)
 {
  Element e = _view.document().elementList().elementAt(element);
  return (e != null)? e.elementView(_view).style() : null;
 }

 /**
  * Set the style string for an element in the document (or section of the
  * document that is currently loaded in the editor).
  *
  * <p>Note: the <b>style</b> editor parameter applies to the current
  * element.</p>
  *
  * @param element an element in the document section currently
  *                loaded in the editor
  * @param style the style string to set
  */
 public void setElementStyle(int element, String style)
 {
  Element e = _view.document().elementList().elementAt(element);
  if (e != null)
   {
    e.elementView(_view).setStyle(style);
   }
 }

 /**
  * Retrieve the bit-mask of the element classes set in an element of the
  * document (or document section that is currently loaded in the editor).
  *
  * <p>Note: the <b>elementClasses</b> editor parameter applies to the
  * current element.</p>
  *
  * @param element an element in the document section currently
  *                loaded in the editor
  */
 public long elementClasses(int element)
 {
  Element e = _view.document().elementList().elementAt(element);
  return (e != null)? e.elementView(_view).classes() & Classes.USER : 0;
 }

 /**
  * Set the element classes bit-mask in an element of the document (or document
  * section that is currently loaded in the editor).
  *
  * <p>Note: the <b>elementClasses</b> editor parameter applies to the
  * current element.</p>
  *
  * @param element an element in the document section currently
  *                loaded in the editor
  * @param classes bit-mask of the element class(es) to set
  */
 public void setElementClasses(int element, long classes)
 {
  Element e = _view.document().elementList().elementAt(element);
  if (e != null)
   {
    e.elementView(_view).setClasses(classes);
   }
 }

 /**
  * Register the specified element class.
  *
  * @return the allocated bit-mask of this element class
  */
 public long registerClass(String name)
 {
  return _view.classes().register(name);
 }

 /**
  * Get the bit-mask allocated for the registered element class(es) named.
  */
 public long classMask(String names)
 {
  return _view.classes().mask(names);
 }

 /**
  * Get the ordinal number of the current (cursor) element in the document (or
  * section of the document that is currently loaded in the editor).
  * If there is no current element (no elements are visible in the document),
  * this method returns 0.
  *
  * Elements include show lines and non-show lines.  Show lines are not saved
  * when the document is saved.
  *
  * <p>Note: the <b>element</b> editor parameter returns the ordinal number
  * of the (current) element in the <i>complete</i> document.</p>
  *
  * @see #lineOfElement
  * @see #currentPosition
  * @see #documentLocation()
  */
 public int currentElement()
 {
  return _view.document().elementList().ordinalOf(_view.documentPosition().element());
 }

 /**
  * Convenience method to retrieve the current (cursor) position within the
  * current (cursor) element.
  * An equivalent command to query the <b>position</b> parameter is:
  * <pre>
  *   lpexView.queryInt("position"); </pre>
  *
  * @see #currentElement
  * @see #documentLocation()
  */
 public int currentPosition()
 {
  return _view.documentPosition().position();
 }

 /**
  * Get the view's current (cursor) location in the document (or section of the
  * document that is currently loaded in the editor).
  * If no elements are currently visible, the returned
  * LpexDocumentLocation.element will be 0.
  *
  * <p>Note: the <b>element</b> editor parameter returns the ordinal number of
  * the (current) element in the <i>complete</i> document.</p>
  *
  * @see #currentElement
  * @see #currentPosition
  */
 public LpexDocumentLocation documentLocation()
 {
  return _view.documentPosition().documentLocation();
 }

 /**
  * Get the location in the document (or section of the document that is
  * currently loaded in the editor) which corresponds to the given
  * Unicode-character offset in its underlying file (section).
  * If the specified offset is beyond the end of the document (section),
  * the location returned will be the end of the document (section).
  *
  * @param charOffset ZERO-based character offset from the start of the file
  * @param eolLength  length of file's line delimiter, e.g., 2 for CRLF ("\r\n")
  *
  * @see #charOffset
  */
 public LpexDocumentLocation documentLocation(int charOffset, int eolLength)
 {
  //*as* optimize by maintaining a currentOffset in Element!?...
  ElementList elementList = _view.document().elementList();
  Element lastTextElement = null;
  int currentOffset = 0;
  for (Element e = elementList.first(); e != null; e = e.next())
   {
    if (!e.show())
     {
      if (currentOffset + e.length() >= charOffset)
       {
        int position = charOffset - currentOffset + 1;
        if (position < 1) // if charOffset inside eol sequence
           position = 1;
        return new LpexDocumentLocation(elementList.ordinalOf(e), position);
       }
      lastTextElement = e;
      currentOffset += e.length() + eolLength;
     }
   }

  if (lastTextElement == null)
   {
    return new LpexDocumentLocation(1, 1);
   }

  return new LpexDocumentLocation(elementList.ordinalOf(lastTextElement),
                                  lastTextElement.length() + 1);
 }

 /**
  * Get a document (or document section) location's Unicode-character offset in
  * its underlying file (section).
  * If the specified location is beyond the end of the document (section),
  * the offset returned will be for the end of the document (section).
  *
  * @param documentLocation a location (element, position) in the document
  *        section currently loaded in the editor
  * @param eolLength length of file's line delimiter, e.g., 2 for CRLF ("\r\n")
  * @return ZERO-based character offset from the start of the file
  *
  * @see #documentLocation(int,int)
  */
 public int charOffset(LpexDocumentLocation documentLocation, int eolLength)
 {
  //*as* optimize by maintaining currentOffset in Element!?...
  Element element = _view.document().elementList().elementAt(documentLocation.element);
  int currentOffset = 0;
  for (Element e = _view.document().elementList().first(); e != null; e = e.next())
   {
    if (e == element)
     {
      return e.show()? currentOffset : currentOffset + documentLocation.position - 1;
     }
    if (!e.show())
     {
      currentOffset += e.length() + eolLength;
     }
   }

  return 0;
 }

 /**
  * Query an editor parameter.
  */
 public String query(String parameter)
 {
  return QueryCommand.query(parameter, _view,
                            _view.documentPosition().documentLocation());
 }

 /**
  * Convenience method to query an editor integer parameter.
  * Shortcut for
  * <pre>
  *   String value = query(parameter);
  *   return (value != null)? Integer.parseInt(value) : -1; </pre>
  *
  * Note that if the underlying query returns <code>null</code>,
  * this method returns -1.
  *
  * @see #query(String)
  */
 public int queryInt(String parameter)
 {
  String value = query(parameter);
  return (value != null)? Integer.parseInt(value) : -1;
 }

 /**
  * Convenience method to query an editor on/off parameter.
  * Shortcut for
  * <pre>
  *   String value = query(parameter);
  *   return value != null && value.equals("on"); </pre>
  *
  * @return <code>true</code> for a valid LPEX parameter whose value is "on"
  *
  * @see #query(String)
  */
 public boolean queryOn(String parameter)
 {
  String value = query(parameter);
  return value != null && value.equals("on");
 }

 /**
  * Query an editor parameter.
  * If the parameter requires a document location, then the specified
  * document (or document section) location will be used rather than the view's
  * actual current document (or document section) location.
  *
  * @param documentLocation a document location (element, position) in the
  *           document section currently loaded in the editor
  */
 public String query(String parameter, LpexDocumentLocation documentLocation)
 {
  return QueryCommand.query(parameter, _view, documentLocation);
 }

 /**
  * Convenience method to query an editor integer parameter.
  * Shortcut for
  * <pre>
  *   String value = query(parameter, documentLocation);
  *   return (value != null)? Integer.parseInt(value) : -1; </pre>
  *
  * Note that if the underlying query returns <code>null</code>,
  * this method returns -1.
  *
  * @param documentLocation a document location (element, position) in the
  *           document section currently loaded in the editor
  *
  * @see #query(String,LpexDocumentLocation)
  */
 public int queryInt(String parameter, LpexDocumentLocation documentLocation)
 {
  String value = query(parameter, documentLocation);
  return (value != null)? Integer.parseInt(value) : -1;
 }

 /**
  * Convenience method to query an editor on/off parameter.
  * Shortcut for
  * <pre>
  *   String value = query(parameter, documentLocation);
  *   return value != null && value.equals("on"); </pre>
  *
  * @param documentLocation a document location (element, position) in the
  *           document section currently loaded in the editor
  * @return <code>true</code> for a valid LPEX parameter whose value is "on"
  *
  * @see #query(String,LpexDocumentLocation)
  */
 public boolean queryOn(String parameter, LpexDocumentLocation documentLocation)
 {
  String value = query(parameter, documentLocation);
  return value != null && value.equals("on");
 }

 /**
  * Return the element in the document (or that section of the document that is
  * currently loaded in the editor) which is displayed on the given screen row.
  * Screen rows are 1 .. n, where n if specified by the <b>rows</b> parameter.
  *
  * Elements include show lines and non-show lines.  Show lines are not saved
  * when the document is saved.
  *
  * @return 0 if the row doesn't display a visible element
  */
 public int elementOfRow(int row)
 {
  return _view.document().elementList().ordinalOf(_view.screen().element(row));
 }

 /**
  * Retrieve the element for the specified line.  Both the specified line
  * and the returned element are defined inside the document section that
  * is currently loaded in the editor.
  *
  * Elements include show lines and non-show lines.  Show lines are not saved
  * when the document is saved.
  *
  * <p>Note: the <b>element</b> editor parameter returns the ordinal number of
  * the (current) element in the <i>complete</i> document.</p>
  *
  * @return 0 if the line doesn't exist in the document (or currently loaded
  *           section of it)
  *
  * @see #lineOfElement
  */
 public int elementOfLine(int line)
 {
  Element e = _view.document().elementList().nonShowElementAt(line);
  return (e != null)? _view.document().elementList().ordinalOf(e) : 0;
 }

 /**
  * Retrieve the line for the specified element.  Both the specified element and
  * the returned line are defined inside the document section that is currently
  * loaded in the editor.
  *
  * Elements include show lines and non-show lines.  Show lines are not saved
  * when the document is saved.
  *
  * <p>If the element is a <b>show</b> element, the first document line above it
  * is returned.  If the element does not exist, or if there is no document line
  * corresponding to the given element (e.g., one or more <b>show</b> elements
  * at the top of the document), this method returns 0.</p>
  *
  * <p>Note: the <b>line</b> editor parameter returns the ordinal number of
  * the (current) line in the <i>complete</i> document.</p>
  *
  * @see #currentElement
  * @see #elementOfLine
  */
 public int lineOfElement(int element)
 {
  Element e = _view.document().elementList().elementAt(element);
  return (e != null)? _view.document().elementList().nonShowOrdinalOf(e) : 0;
 }

 /**
  * Return the name of the deleted mark with the id specified.
  * Can be used during the processing of LpexMarkListener markDeleted()
  * notifications.
  */
 public String deletedMarkName(int markId)
 {
  return _view.markList().deletedMarkName(markId);
 }

 /**
  * Return the command line widget with the input focus, if any.
  * This information is not available from the FocusEvent notifications of a
  * FocusListener on the command line, as these events' widget field is set
  * to the command-line Composite.
  */
 public Widget commandLineFocusWidget()
 {
  LpexWindow lpexWindow = _view.window();
  return (lpexWindow != null)? ((CommandLine)lpexWindow.commandLine()).inputFocusWidget() : null;
 }

 /**
  * Query a global editor parameter.
  * The parameter should be a globally-scoped parameter, i.e., one that does not
  * require a document view.
  * Example:
  * <pre>
  *   LpexView.globalQuery("version"); </pre>
  */
 public static String globalQuery(String parameter)
 {
  return QueryCommand.query(parameter, null, null);
 }

 /**
  * Set the number of lines in the complete document outside the boundaries of
  * the currently-loaded document section.
  *
  * @see LpexDocumentSectionListener
  */
 public void setLinesOutsideDocumentSection(int linesBeforeStart, int linesAfterEnd)
 {
  _view.document().setLinesOutsideDocumentSection(linesBeforeStart, linesAfterEnd);
 }

 /**
  * Return the number of lines in the document prior to the currently-loaded
  * document section.
  * Normally, the complete document is loaded in the editor, and this method will
  * return 0.
  *
  * @see LpexDocumentSectionListener
  */
 public int linesBeforeStart()
 {
  return _view.document().linesBeforeStart();
 }

 /**
  * Return the number of lines in the document following the currently-loaded
  * document section.
  * Normally, the complete document is loaded in the editor, and this method will
  * return 0.
  *
  * @see LpexDocumentSectionListener
  */
 public int linesAfterEnd()
 {
  return _view.document().linesAfterEnd();
 }

 /**
  * Add a view listener to this editor view.
  * A listener is only registered once, subsequent calls to add the same
  * listener have no effect.
  *
  * @see LpexViewListener
  * @see #removeLpexViewListener
  */
 public void addLpexViewListener(LpexViewListener viewListener)
 {
  _view.listenerList().addListener(viewListener);
 }

 /**
  * Remove a view listener from this editor view.
  * Removes the specified listener if it is registered with this view.
  */
 public void removeLpexViewListener(LpexViewListener viewListener)
 {
  _view.listenerList().removeListener(viewListener);
 }

 /**
  * Add a cursor listener to this editor view.
  * A listener is only registered once, subsequent calls to add the same
  * listener have no effect.
  *
  * @see LpexCursorListener
  * @see #removeLpexCursorListener
  */
 public void addLpexCursorListener(LpexCursorListener cursorListener)
 {
  _view.cursorListenerList().addListener(cursorListener);
 }

 /**
  * Remove a cursor listener from this editor view.
  * Removes the specified listener if it is registered with this view.
  */
 public void removeLpexCursorListener(LpexCursorListener cursorListener)
 {
  _view.cursorListenerList().removeListener(cursorListener);
 }

 /**
  * Add a mark listener to the specified mark.
  *
  * @see LpexMarkListener
  * @see #removeLpexMarkListener(int,LpexMarkListener)
  * @see #removeLpexMarkListener(LpexMarkListener)
  */
 public void addLpexMarkListener(int markId, LpexMarkListener markListener)
 {
  MarkList.Mark mark = _view.markList().find(markId);
  if (mark != null)
   {
    mark.addListener(markListener);
   }
 }

 /**
  * Remove a mark listener from the specified mark.
  */
 public void removeLpexMarkListener(int markId, LpexMarkListener markListener)
 {
  MarkList.Mark mark = _view.markList().find(markId);
  if (mark != null)
   {
    mark.removeListener(markListener);
   }
 }

 /**
  * Remove a mark listener from all the marks in this document view for
  * which it is registered.
  */
 public void removeLpexMarkListener(LpexMarkListener markListener)
 {
  _view.markList().removeListener(markListener);
 }

 /**
  * Add a document-section listener to the editor document of this view.
  * A listener is only registered once, subsequent calls to add the same
  * listener have no effect.
  *
  * @see LpexDocumentSectionListener
  * @see #removeLpexDocumentSectionListener
  */
 public void addLpexDocumentSectionListener(LpexDocumentSectionListener sectionListener)
 {
  _view.document().documentSectionListenerList().addListener(sectionListener);
 }

 /**
  * Remove a document-section listener from the editor document of this view.
  * Removes the specified listener if it is registered with this view's document.
  */
 public void removeLpexDocumentSectionListener(LpexDocumentSectionListener sectionListener)
 {
  _view.document().documentSectionListenerList().removeListener(sectionListener);
 }

 /**
  * Add an LPEX key listener to this editor view.  A keyPressed(Event)
  * notification is sent by LPEX when a key is pressed.  LPEX ignores the
  * key press if the listener consumes the key by setting the <code>doit</code>
  * field of the event to <code>false</code>.
  *
  * A listener is only registered once, subsequent calls to add the same
  * listener have no effect.
  *
  * @see LpexKeyListener
  * @see #removeLpexKeyListener
  */
 public void addLpexKeyListener(LpexKeyListener keyListener)
 {
  if (keyListener != null)
   {
    if (_keyListenerList == null)
     {
      _keyListenerList = new KeyListenerList();
     }

    _keyListenerList.addListener(keyListener);
   }
 }

 /**
  * Remove the specified LPEX key listener from this editor view.
  * Removes the specified listener if it is registered with this view.
  *
  * @see #addLpexKeyListener
  */
 public void removeLpexKeyListener(LpexKeyListener keyListener)
 {
  if (_keyListenerList != null)
   {
    boolean noMoreListeners = _keyListenerList.removeListener(keyListener);
    if (noMoreListeners)
     {
      _keyListenerList = null;
     }
   }
 }

 KeyListenerList keyListenerList()
 {
  return _keyListenerList;
 }

 /**
  * Called by the TextWindow to send key-pressed notifications to
  * registered LpexKeyListeners.
  */
 void triggerKeyListeners(Event event)
 {
  if (_keyListenerList != null)
   {
    _keyListenerList.keyPressed(event);
   }
 }

 /**
  * Set the Shell that should be used when dialogs are displayed.
  */
 public void setFrame(Shell frame)
 {
  _frame = frame;
 }

 /**
  * Retrieve the Shell that is used when dialogs are displayed.
  * This is the Shell of the LpexWindow associated with this view or, if none,
  * the Shell previously set with setFrame().
  */
 public Shell frame()
 {
  LpexWindow container = _view.window();       // get view's LpexWindow, if any
  if (container != null)
   {
    return container.getShell();
   }
  return _frame;
 }

 /**
  * Set an alternate class loader to be used by this view.
  * This method is needed e.g., on the Eclipse platform, where the LPEX plugin
  * cannot load a class outside its own runtime library, and consequently cannot
  * process commands such as <b>set updateProfile.parserClass</b> for a parser
  * shipped by another plugin.
  * This class loader is only used when a class cannot be loaded by the current
  * LPEX loader.
  */
 public void setClassLoader(ClassLoader classLoader)
 {
  _view.setClassLoader(classLoader);
 }

 /**
  * Set a new font in the view.
  * The font passed in is an SWT Font.
  */
 public void setFont(org.eclipse.swt.graphics.Font swtFont)
 {
  Font font = new Font(swtFont);            // wrapper LPEX's Font around swt's
  _view.screen().setFont(font);
 }

 /**
  * Retrieve the font in the view.
  * The font returned is an SWT Font.
  */
 public org.eclipse.swt.graphics.Font getFont()
 {
  return _view.screen().font().getFont();
 }

// // For faster processing of the "Delete" action received in lieu of an
// // Delete/Del key event (see ActionHandler processing ACTION_TEXTPART_DELETE)
// import org.eclipse.swt.SWT;
// import org.eclipse.swt.widgets.Event;
// import org.eclipse.swt.events.KeyEvent;
// private KeyEvent _keyEvent = new KeyEvent(new Event());
// public void pressDeleteKey() {
//  if (_view.window() != null) {
//   TextWindow textWindow = (TextWindow)_view.window().textWindow();
//   if (textWindow.isFocusControl()) {
//    _keyEvent.widget = textWindow;
//    _keyEvent.character = SWT.DEL;
//    //_keyEvent.keyCode = 0;
//    //_keyEvent.stateMask = 0;
//    textWindow.processKeyEvent(_keyEvent);
//    }
//   else
//    ((CommandLine)_view.window().commandLine()).deleteKey();
//   }
//  }

 // -as- These are currently handled in com.ibm.lpex.alef.LpexAbstractTextEditor,
 // due to the support provided by Eclipse for this...
 //
 // /**
 //  * The specified menu will be populated with the editor actions indicated
 //  * by the menuDefinition string.  The menuDefinition string should have the same
 //  * syntax as the popup parameter.
 //  *
 //  * @return <code>true</code> if successful, or
 //  *         <code>false</code> if not successful
 //  */
 // public boolean populateMenu(Menu menu, String menuDefinition)
 //  {
 //   return _view.actionHandler().populateMenu(menu, menuDefinition);
 //  }
 //
 // /**
 //  * The specified popup menu will be populated with the editor actions indicated
 //  * by the menuDefinition string.  The menuDefinition string should have the same
 //  * syntax as the popup parameter.
 //  *
 //  * @return <code>true</code> if successful, or
 //  *         <code>false</code> if not successful
 //  */
 // public boolean populatePopupMenu(Menu popupMenu, String menuDefinition)
 //  {
 //   return _view.actionHandler().populatePopupMenu(popupMenu, menuDefinition);
 //  }

 /**
  * Set the default URL to load for this view when language-sensitive help is
  * not available.
  */
 public void setDefaultHelp(String URL)
 {
  _defaultHelpPage = URL;
 }

 /**
  * Retrieve the default help URL for this view.  The default help URL is loaded
  * when language-sensitive help is not available.
  */
 public String defaultHelp()
 {
  return _defaultHelpPage;
 }
}