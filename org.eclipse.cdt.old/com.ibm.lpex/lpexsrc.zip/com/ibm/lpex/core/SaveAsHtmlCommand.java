//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SaveAsHtmlCommand - handles the saveAsHtml command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.io.Writer;


/**
 * This class implements the <b>saveAsHtml</b> command.
 * It saves the document section that is currently loaded in the editor
 * as an HTML file.  It does not trigger a request for extending this document
 * section.  To save the entire document, the user should extend this command
 * to first load the complete document in.
 */
final class SaveAsHtmlCommand
{
 static boolean doCommand(View view, String parameters)
  {
   return doCommand(view, null, parameters);
  }

 static boolean doCommand(View view, Writer writer, String parameters)
  {
   String fileName = null;
   boolean prompt = false;
   boolean visible = false;
   boolean block = false;
   boolean lineNumbers = false;

   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   while (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (token.equals("prompt"))
      {
       prompt = true;
      }
     else if (token.equals("visible"))
      {
       visible = true;
      }
     else if (token.equals("block"))
      {
       block = true;
      }
     else if (token.equals("lineNumbers"))
      {
       lineNumbers = true;
      }
     else
      {
       if (LpexStringTokenizer.isInvalidQuotedString(token))
        {
         return CommandHandler.invalidQuotedParameter(view, token, "saveAsHtml");
        }
       fileName = LpexStringTokenizer.trimQuotes(token);

       if (st.hasMoreTokens())
        {
         return CommandHandler.invalidParameter(view, st.nextToken(), "saveAsHtml");
        }
       break;
      }
    }

   // command format is correct, if there is a view do it
   if (view != null)
    {
     boolean addHtmlSuffix = false;     // if a file name given, that's it
     CommandHandler._status = null;
     if (fileName == null || fileName.length() == 0)
      {
       fileName = view.document().name();
       addHtmlSuffix = true;            // name not given, based on doc name...
      }

     if (prompt || fileName == null)
      {
       fileName = LpexUtilities.fileDialog(view,
                                LpexResources.message(LpexConstants.MSG_FILEDIALOG_SAVEAS),
                                true,
                                fileName);
       addHtmlSuffix = false;           // we prompted user for a file name...
      }

     if (fileName != null)
      {
       if (addHtmlSuffix)
        {
         fileName += ".html";
        }
       view.saveAsHtml(fileName, visible, block, lineNumbers);
      }
     else
      {
       CommandHandler._status = LpexConstants.STATUS_SAVE_CANCELLED;
      }
    }

   return true;
  }
}