//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Install - access the LPEX install profile.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.io.FileInputStream;
import java.io.File;
import java.util.Enumeration;
import java.util.Properties;


/**
 * This class is used to access the LPEX install profile.
 */
final class Install
{
 private static Properties _properties;
 private static String _name;
 private static String _fileName;
 private static boolean _loaded;
 private static List _listeners = new List();


 static String name()
 {
  if (_name != null)
   {
    return _name;                        // (a) name pre-set
   }

  if (LpexUtilities.getPlatform() == LpexConstants.PLATFORM_AWT)
   {
    return "com.ibm.lpex.core.Install";  // (b) default in AWT/Swing LPEX
   }

  return "Install";                      // (c) default in SWT/Eclipse LPEX
 }

 static void setName(String name)
 {
  if (name != null)
   {
    name = name.trim();
    if (name.length() == 0)
     {
      name = null;
     }
   }

  _name = name;
  _loaded = false;
  for (ListenerNode node = (ListenerNode)_listeners.first();
       node != null;
       node = (ListenerNode)node.next())
   {
    node.listener().profileChanged();
   }
 }

 static private void load()
 {
  if (!_loaded)
   {
    _properties = new Properties();

    /*-----------------------*/
    /*  Java AWT/Swing LPEX  */
    /*-----------------------*/
    if (LpexUtilities.getPlatform() == LpexConstants.PLATFORM_AWT)
     {
      String fileName = name().replace('.', '/') + ".properties";
      try
       {
        // ClassLoader.getSystemResourceAsStream() - open for reading,
        // a resource of the specified name from the search path used
        // to load classes.
        // The search order is described in the documentation for
        // getSystemResource(String).
        _properties.load(ClassLoader.getSystemResourceAsStream(fileName));
       }
      catch (Exception e)
       {
        // LpexLog.log("Could not read Install profile.");
       }
     }

    /*--------------------*/
    /*  Eclipse SWT LPEX  */
    /*--------------------*/
    else
     {
      String fileName = name() + ".properties";
      try
       {
        // Class.getResourceAsStream() - find a resource with a given name.
        // This method returns null if no resource with this name is found.
        // The rules for searching resources associated with a given class
        // are implemented by the defining class loader of the class.
        // This method delegates the call to its class loader, after making
        // these changes to the resource name:  if the resource name starts
        // with "/", it is unchanged;  otherwise, the package name is
        // prepended to the resource name after converting "." to "/".  If
        // this object was loaded by the bootstrap loader, the call is?
        // delegated to ClassLoader.getSystemResourceAsStream.
        _properties.load(Install.class.getResourceAsStream(fileName));
       }
      catch (Exception e)
       {
        // LpexLog.log("Could not read Install profile.");
       }
     }

    _loaded = true;
   }
 }

 static String getString(String key)
 {
  load();
  return _properties.getProperty(key);
 }

 static String getString(String key, String defaultValue)
 {
  load();
  return _properties.getProperty(key, defaultValue);
 }

 static int getInteger(String key, int defaultValue)
 {
  load();
  String value = _properties.getProperty(key);
  if (value != null)
   {
    try
     {
      return Integer.parseInt(value);
     }
    catch(NumberFormatException e) {}
   }

  return defaultValue;
 }

 static String getKeys()
 {
  load();
  StringBuffer keys = new StringBuffer(5300);
  boolean first = true;
  Enumeration propertyNames = _properties.propertyNames();
  while (propertyNames.hasMoreElements())
   {
    if (!first)
     {
      keys.append(' ');
     }
    first = false;
    keys.append(propertyNames.nextElement());
   }

  return keys.toString();
 }

 static void addProfileChangedListener(ProfileChangedListener listener)
 {
  _listeners.addAfter(null, new ListenerNode(listener));
 }

 static void removeListener(ProfileChangedListener listener)
 {
  for (ListenerNode node = (ListenerNode)_listeners.first();
       node != null;
       node = (ListenerNode)node.next())
   {
    if (node.listener() == listener)
     {
      _listeners.remove(node);
      break;
     }
   }
 }


 interface ProfileChangedListener
 {
  void profileChanged();
 }


 private static class ListenerNode extends ListNode
 {
  private ProfileChangedListener _listener;

  ListenerNode(ProfileChangedListener listener)
  {
   _listener = listener;
  }

  ProfileChangedListener listener()
  {
   return _listener;
  }
 }
}