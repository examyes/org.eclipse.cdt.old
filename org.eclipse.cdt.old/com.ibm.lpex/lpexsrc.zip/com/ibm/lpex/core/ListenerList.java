//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ListenerList - handles a view's list of LpexViewListeners.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages the LpexViewListeners for a document view.
 * There is one instance of this class created for each View.
 */
final class ListenerList extends List
{
 private View _view;
 private boolean _readonlyChangeAttempted;


 ListenerList(View view)
 {
  _view = view;
 }

 /**
  * Add an LpexViewListener.  A listener is only registered once, additional
  * calls are without effect.
  */
 void addListener(LpexViewListener listener)
 {
  if (find(listener) == null)
   {
    addAfter(null, new ListenerNode(listener));
   }
 }

 /**
  * Remove an LpexViewListener, if registered.
  */
 void removeListener(LpexViewListener listener)
 {
  if (listener != null)
   {
    ListenerNode node = find(listener);
    if (node != null)
     {
      remove(node);
     }
   }
 }

 /**
  * Send the <i>showing</i> notification to all registered LpexViewListeners.
  */
 void showing()
 {
  beginScanning();
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    node.listener().showing(_view.lpexView());
   }
  endScanning();
 }

 /**
  * Send the <i>shown</i> notification to all registered LpexViewListeners.
  */
 void shown()
 {
  beginScanning();
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    node.listener().shown(_view.lpexView());
   }
  endScanning();
 }

 /**
  * Send the <i>saving</i> notification to all registered LpexViewListeners.
  * Return the listener return code.
  */
 boolean saving()
 {
  boolean abort = false;

  beginScanning();
  for (ListenerNode node = (ListenerNode)first();
       node != null && !abort;
       node = (ListenerNode)node.next())
   {
    abort = node.listener().saving(_view.lpexView());
   }
  endScanning();

  return abort;
 }

 /**
  * Send the <i>saved</i> notification to all registered LpexViewListeners.
  */
 void saved()
 {
  beginScanning();
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    node.listener().saved(_view.lpexView());
   }
  endScanning();
 }

 /**
  * Send the <i>renaming</i> notification to all registered LpexViewListeners.
  * Return the listener return code.
  */
 boolean renaming()
 {
  boolean abort = false;

  beginScanning();
  for (ListenerNode node = (ListenerNode)first();
       node != null && !abort;
       node = (ListenerNode)node.next())
   {
    abort = node.listener().renaming(_view.lpexView());
   }
  endScanning();

  return abort;
 }

 /**
  * Send the <i>renamed</i> notification to all registered LpexViewListeners.
  */
 void renamed()
 {
  beginScanning();
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    node.listener().renamed(_view.lpexView());
   }
  endScanning();
 }

 /**
  * Set a pending <i>readonly</i> notification to be sent.
  */
 void setReadonlyChangeAttempted()
 {
  _readonlyChangeAttempted = true;
 }

 /**
  * Send the <i>readonly</i> notification to all registered LpexViewListeners
  * if one is pending.
  */
 void readonly()
 {
  if (_readonlyChangeAttempted)
   {
    beginScanning();
    for (ListenerNode node = (ListenerNode)first();
         node != null;
         node = (ListenerNode)node.next())
     {
      node.listener().readonly(_view.lpexView());
     }
    endScanning();
    _readonlyChangeAttempted = false;
   }
 }

 /**
  * Send the <i>updateProfile</i> notification to all registered
  * LpexViewListeners.
  */
 void updateProfile()
 {
  beginScanning();
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    node.listener().updateProfile(_view.lpexView());
   }
  endScanning();
 }

 /**
  * Send the <i>disposed</i> notification to all registered LpexViewListeners.
  */
 void disposed()
 {
  beginScanning();
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    node.listener().disposed(_view.lpexView());
   }
  endScanning();
 }

 /**
  * Find a registered LpexViewListener for this View.
  */
 ListenerNode find(LpexViewListener listener)
 {
  for (ListenerNode node = (ListenerNode)first();
       node != null;
       node = (ListenerNode)node.next())
   {
    if (node.listener() == listener)
     {
      return node;
     }
   }

  return null;
 }
}


final class ListenerNode extends ListNode
{
 private LpexViewListener _listener;

 ListenerNode(LpexViewListener listener)
 {
  _listener = listener;
 }

 LpexViewListener listener()
 {
  return _listener;
 }
}