//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ExcludedClassesParameter - handles the excludedClasses parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>excludedClasses</b> parameter.
 */
final class ExcludedClassesParameter extends Parameter
{
 private static ExcludedClassesParameter _parameter;

 static ExcludedClassesParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ExcludedClassesParameter();
   }
  return _parameter;
 }

 private ExcludedClassesParameter()
 {
  super(LpexConstants.PARAMETER_EXCLUDED_CLASSES);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  if (view != null)
   {
    long classes = 0;
    boolean ok = true; // this flag is used to work around a problem in the JIT

    LpexStringTokenizer st = new LpexStringTokenizer(parameters);
    while (ok && st.hasMoreTokens())
     {
      String token = st.nextToken();
      long mask = view.classes().mask(token);
      if (mask == 0)
       {
        CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
        ok = false;
       }
      classes |= mask;
     }

    if (!ok)
     {
      return false;
     }

    view.setExcludedClasses(classes);
   }

  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.classes().names(view.excludedClasses()) : null;
 }
}