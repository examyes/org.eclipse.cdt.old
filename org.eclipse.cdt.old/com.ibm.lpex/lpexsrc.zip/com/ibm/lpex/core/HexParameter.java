//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// HexParameter - handles the hex parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>hex</b> parameter.
 */
final class HexParameter extends Parameter
{
 private static HexParameter _parameter;

 static HexParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new HexParameter();
   }
  return _parameter;
 }

 private HexParameter()
 {
  super(PARAMETER_HEX);
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null && documentLocation != null)
   {
    Element element = view.document().elementList().elementAt(documentLocation.element);
    if (element != null)
     {
      char c = '\0';
      String text = element.text();
      if (text.length() >= documentLocation.position)
       {
        c = text.charAt(documentLocation.position - 1);
       }
      return Integer.toHexString(c);
     }
   }

  return null;
 }

 boolean set(View view, String qualifier, String parameters)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (!st.hasMoreTokens())
   {
    return CommandHandler.incomplete(view, "set " + name());
   }

  String token = st.nextToken();
  char newChar;
  try
   {
    newChar = (char)Integer.parseInt(token, 16);
   }
  catch(NumberFormatException e)
   {
    return CommandHandler.invalidParameter(view, token, "set " + name());
   }

  if (st.hasMoreTokens())
   {
    return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name());
   }

  if (view != null)
   {
    view.deleteText(1);
    view.insertText(String.valueOf(newChar));
   }
  return true;
 }
}