//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterQualifiedWordDefault
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

abstract class ParameterQualifiedWordDefault extends ParameterDefault
{
 ParameterQualifiedWordDefault(String name)
 {
  super(name);
 }

 String installValue(String qualified)
 {
  return Install.getString(PARAMETER_INSTALL + name(qualified));
 }

 String defaultValue(String qualifier)
 {
  return Profile.getString(PARAMETER_DEFAULT + name(qualifier));
 }

 boolean setDefaultValue(String qualifier, String value)
 {
  Profile.putString(PARAMETER_DEFAULT + name(qualifier), value);
  return true;
 }

 String currentValue(View view, String qualifier)
 {
  String value = value(view, qualifier);
  if (value == null)
   {
    value = defaultValue(qualifier);
    if (value == null)
     {
      value = installValue(qualifier);
     }
   }

  if ("null".equals(value))
   {
    value = null;
   }

  return value;
 }

 boolean set(View view, String qualifier, String parameters)
 {
  String value = "null";
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    value = token.equals("default")? null : token;

    if (st.hasMoreTokens())
     {
      return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name(qualifier));
     }
   }

  return setValue(view, qualifier, value);
 }

 abstract boolean setValue(View view, String qualifier, String value);

 boolean setDefault(View view, String qualifier, String parameters)
 {
  String value = "null";
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    value = token.equals("install")? null : token;

    if (st.hasMoreTokens())
     {
      return CommandHandler.invalidParameter(view, st.nextToken(),
                                             "set " + PARAMETER_DEFAULT + name(qualifier));
     }
   }

  return setDefaultValue(qualifier, value);
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    String value = value(view, qualifier);
    if (value == null)
     {
      return "default";
     }

    if ("null".equals(value))
     {
      value = null;
     }
    return value;
   }

  return null;
 }

 abstract String value(View view, String qualifier);

 String queryInstall(String qualifier)
 {
  return installValue(qualifier);
 }

 String queryDefault(String qualifier)
 {
  String value = defaultValue(qualifier);
  if (value == null)
   {
    return "install";
   }

  if ("null".equals(value))
   {
    value = null;
   }
  return value;
 }

 String queryCurrent(View view, String qualifier)
 {
  return currentValue(view, qualifier);
 }
}