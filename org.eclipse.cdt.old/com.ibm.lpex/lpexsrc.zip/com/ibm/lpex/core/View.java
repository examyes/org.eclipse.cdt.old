//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// View - manages a document view.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.ibm.lpex.util.RegularExpression;
import com.ibm.lpex.util.RegularExpression.Match;


/**
 * This class is used to manage a document view.
 * There is at least one instance of this class for each instance of Document.
 * There is also a one-to-one mapping of this class to the LpexView class:
 * this class is essentially the implementation class of LpexView.
 */
final class View implements LpexConstants
{
 View _next;

 // prefixAreaText parameter settings
 static final int
  PREFIX_AREA_TEXT_NONE            = 0, // i.e., default/install
  PREFIX_AREA_TEXT_LINENUMBERS     = 1, // lineNumbers
  PREFIX_AREA_TEXT_SEQUENCENUMBERS = 2; // sequenceNumbers

 private Document            _document;
 private LpexView            _lpexView;
 private LpexWindow          _lpexWindow;
 private DocumentPosition    _documentPosition;
 private StyleAttributesList _styleAttributesList;
 private LpexNls             _nls;
 private Screen              _screen;
 private ActionHandler       _actionHandler;
 private CommandHandler      _commandHandler;
 private ParsePendingList    _parsePendingList;
 private ViewListenerList    _viewListenerList;
 private CursorListenerList  _cursorListenerList;
 private int                 _flags;
 private String              _baseProfile;
 private String              _popup;

 private int     _showSosiParm = Parameter.DEFAULT;
 private int     _cursorBlinkParm = Parameter.DEFAULT;

 // expandTabs parameter for this view, and cached current value
 private int     _expandTabsParm = Parameter.DEFAULT;
 private boolean _expandTabs;

 // tabs parameter for this view (null/new Settings == DEFAULT), cached current value
 private TabsParameter.Settings _tabsParm;
 private TabsParameter.Settings _currentTabs;

 // hideSequenceNumbers parameter, and cached current value
 private int       _hideSequenceNumbersParm = Parameter.DEFAULT;
 private boolean   _hideSequenceNumbers;

 // sequenceNumbersFormat parameter, and cached current value & its style
 String            _sequenceNumbersFormatParm; // null == DEFAULT for word parms
 private String    _sequenceNumbersFormat;
 private String    _sequenceNumbersFormatStyle;

 // prefixAreaText parameter setting
 int               _prefixAreaTextParm = PREFIX_AREA_TEXT_NONE;

 private int       _fields[] = null;
 private Classes   _classes;
 private boolean   _updateProfileIssued;
 private String    _lastComparedTo;
 private boolean   _autoCheck = true;
 private ViHandler _viHandler;
 private boolean   _vi;

 private boolean   _maxElementWidthValid;
 private int       _maxElementWidth;
 private boolean   _maxPrefixAreaWidthValid;
 private int       _maxPrefixAreaWidth;
 private boolean   _topExpanded;
 private boolean   _hiddenElements;
 private boolean   _visibleElementOrdinalsValid;
 private boolean   _insertMode = true;
 private boolean   _inPrefix;
 private boolean   _prefixProtect;
 private Element   _userActionElement;

 private long      _includedClasses = Classes.ALL;
 private long      _excludedClasses = Classes.NONE;

 private MarkList  _markList;
 private boolean   _readonly;
 private int       _ignoreFieldsCount;
 private boolean   _forceAllVisible;

 private Writer    _saveWriter;    // Writer for the saveToWriter action
 private String    _saveEol;       // eol for the save & saveToWriter actions

 private ClassLoader _classLoader; // alternative class loader

 private DocumentPosition.Preserve _findPositionPreserve;

 private BlockCommand.Settings         _blockCommandSettings;
 private CompareCommand.Settings       _compareCommandSettings;
 private FindTextCommand.Settings      _findTextCommandSettings;
 private PrintCommand.Settings         _printCommandSettings;
 private UpdateProfileCommand.Settings _updateProfileCommandSettings;

 private int _documentSectionThreshold;


 /**
  * Constructor.
  */
 View(LpexView lpexView, Document document, boolean updateProfile)
 {
  _next = document._firstView;    // link ourselves in document's views list
  document._firstView = this;
  _document = document;

  _lpexView = lpexView;           // our reference to LpexView
  _lpexView._view = this;         //  & also set reference to us back in LpexView
  _nls = new LpexNls(lpexView);   // instantiate view's NLS object
  _documentPosition = new DocumentPosition(this);
  _screen = new Screen(this);

  _styleAttributesList = new StyleAttributesList();
  _styleAttributesList.set(Screen.CHAR_STYLE_SEQUENCE_NUMBER,
                           _screen.styleAttributes(Screen.STYLE_SEQUENCE_NUMBER));
  _styleAttributesList.set(Screen.CHAR_STYLE_SEQUENCE_TEXT,
                           _screen.styleAttributes(Screen.STYLE_SEQUENCE_TEXT));

  _classes = new Classes();
  _actionHandler = new ActionHandler(this);
  _commandHandler = new CommandHandler(this);
  _parsePendingList = new ParsePendingList(this);
  _viewListenerList = new ViewListenerList(this);

  // set up cached current values of tabs & expandTabs parameters
  _expandTabs = ExpandTabsParameter.getParameter().currentValue(this);
  _currentTabs = TabsParameter.getParameter().currentValue(this);

  // set up cached sequence-numbers data
  _hideSequenceNumbers = HideSequenceNumbersParameter.getParameter().currentValue(this);
  cacheSequenceNumbersFormat();

  // establish document-section management threshold
  setDocumentSectionThreshold();

  if (updateProfile && _next != null)
   {
    updateProfile();
   }
 }

 String baseProfile()
 {
  return _baseProfile;
 }

 boolean updateProfileIssued()
 {
  return _updateProfileIssued;
 }

 /**
  * Do view's (main) part in the <b>updateProfile</b> command.
  */
 void updateProfile()
 {
  // set readonly parameter off
  _readonly = false;

  // show all: include all classes, exclude none
  setIncludedClasses(Classes.ALL);
  setExcludedClasses(Classes.NONE);

  // deregister all user-defined classes
  _classes = new Classes();

  _styleAttributesList.clear();
  _styleAttributesList.set(Screen.CHAR_STYLE_SEQUENCE_NUMBER,
                           _screen.styleAttributes(Screen.STYLE_SEQUENCE_NUMBER));
  _styleAttributesList.set(Screen.CHAR_STYLE_SEQUENCE_TEXT,
                           _screen.styleAttributes(Screen.STYLE_SEQUENCE_TEXT));

  setPopup(null);
  setExpandTabs(Parameter.DEFAULT);
  setTabs(new TabsParameter.Settings());

  //SourceEncodingParameter.getParameter().setValue(this, null);
  //ShiftOutCharacterParameter.getParameter().setValue(this, null, (char)0);
  //ShiftInCharacterParameter.getParameter().setValue(this, null, (char)0);
  //setShowSosi(Parameter.DEFAULT);

  setFields(null);

  _baseProfile = UpdateProfileCommand.BaseProfileParameter
                                     .getParameter().currentValue(this);
  if (_baseProfile != null &&
      (_baseProfile.equals("seu") ||
       _baseProfile.equals("xedit") ||
       _baseProfile.equals("ispf")))
   {
    setPrefixProtect(false); // Screen.updateProfile() will set prefixArea "on"
    // if there are sequence numbers, hide them,
    // and set the prefixAreaText parameter to sequenceNumbers
    if (_document.elementList().sequenceNumbersWidth() != 0)
     {
      _prefixAreaTextParm = PREFIX_AREA_TEXT_SEQUENCENUMBERS;
      setHideSequenceNumbers(Parameter.ON);
     }
    else
     {
      setHideSequenceNumbers(Parameter.DEFAULT);
     }
   }
  else
   {
    setPrefixProtect(true); // Screen.updateProfile() will set prefixArea to "default"
    setHideSequenceNumbers(Parameter.DEFAULT);
    // delete any exclude marks previously created by prefix commands --
    // including their excluded-header (show) elements --, as in the new
    // profile the user won't be able to remove them
    markList().removePrefixExcludeMarks();
   }

  /*-------------------------------------------------------------------------*/
  /*  delete all show elements, clear style & classes for the text elements  */
  /*-------------------------------------------------------------------------*/
  Element next = null;
  for (Element element = _document.elementList().first();
       element != null;
       element = next)
   {
    ElementView elementView = element.elementView(this);
    next = element.next();
    if (elementView.show())
     {
      deleteElement(element);
     }
    else
     {
      if (!element.show())
       {
        elementView.setStyle(null);
        elementView.setClasses(Classes.DEFAULT);
       }
     }
   }

  document().undo().setDefaults(this);

  if ("vi".equals(_baseProfile))
   {
    setAutoCheck(false);
    viHandler().setCommandMode();
    _vi = true;
   }
  else
   {
    setAutoCheck(true);
    _vi = false;
   }

  _screen.updateProfile();
  _actionHandler.updateProfile();
  _commandHandler.updateProfile();

  /*-----------------------*/
  /*  run the user profile */
  /*-----------------------*/
  String userProfile = UpdateProfileCommand.UserProfileParameter
                                           .getParameter().currentValue(this);
  if (userProfile != null && userProfile.length() > 0)
   {
    Class userProfileClass = null;
    boolean invalidUserProfileClass = false;
    try
     {
      userProfileClass = Class.forName(userProfile);
     }
    catch(ClassNotFoundException e) {}
    // managed in Eclipse 0.128 to cause Class.forName() to throw a java.lang.
    // NoClassDefFoundError (wrong name) - mismatch between the .jar with
    // TestUserProfile and a VM cached version of this class!?
    catch (Throwable e)
     {
      invalidUserProfileClass = true;
     }

    // if couldn't load, try the alternative class loader if set
    if (userProfileClass == null && getClassLoader() != null &&
        !invalidUserProfileClass)
     {
      try
       {
        userProfileClass = Class.forName(userProfile, true, getClassLoader());
       }
      catch(ClassNotFoundException e) {}
      catch (Throwable e)
       {
        invalidUserProfileClass = true;
       }
     }

    if (userProfileClass == null)
     {
      if (invalidUserProfileClass)
       {
        setLpexMessageText(MSG_USERPROFILE_INVALID, userProfile);
       }
      else
       {
        setLpexMessageText(MSG_CLASS_NOTFOUND, userProfile);
       }
     }
    else
     {
      Class[] parameterTypes = { LpexView.class };
      try
       {
        Method userProfileMethod =
               userProfileClass.getMethod("userProfile", parameterTypes);
        Object[] arguments = { lpexView() };
        userProfileMethod.invoke(null, arguments);
       }
      catch (InvocationTargetException e)
       {
        e.getTargetException().printStackTrace();
       }
      catch (Exception e)
       {
        setLpexMessageText(MSG_USERPROFILE_INVALID, userProfile);
       }
     }
   }

  /*---------------------------------*/
  /*  set parser, call totalParse()  */
  /*---------------------------------*/
  _parsePendingList.updateProfile();

  /*------------------------------------------------------------------*/
  /*  update view's readonly indication based on the document's file  */
  /*  (if applicable - in SWT LPEX input can be IFile or IStorage)    */
  /*------------------------------------------------------------------*/
  String name = _document.name();
  if (name != null && name.length() > 0)
   {
    try
     {
      File file = new File(name);
      _readonly = file.exists() && !file.canWrite();
     }
    catch (SecurityException e) // not allowed to touch file
     {
      _readonly = true;
     }
    catch (Exception e)         // maybe because it's an Eclipse IStorage
     {
      _readonly = false;
     }
   }

  /*------------------------------------------------------------------------*/
  /*  inform listeners at this point, let them add actions, commands, etc.  */
  /*------------------------------------------------------------------------*/
  _viewListenerList.updateProfile();
  _updateProfileIssued = true;

  /*------------------------*/
  /*  take out the garbage  */
  /*------------------------*/
  System.gc();
 }

 void dispose()
 {
  _viewListenerList.disposed();
  if (Block.view() == this)
   {
    Block.clear();
   }
  setWindow(null);

  View prevView = null;
  for (View view = _document._firstView; view != null; view = view._next)
   {
    if (view == this)
     {
      if (prevView == null)
       {
        _document._firstView = _next;
       }
      else
       {
        prevView._next = _next;
       }
      break;
     }
    prevView = view;
   }

  if (_document._firstView == null)
   {
    _document.dispose();
   }
  else
   {
    _document.elementList().disposeView(this);
   }

  // seems that it helps to clear those lists explicitly when disposing of a
  // View, or the 1.1.2 garbage collector is a bit lazy in getting rid of the
  // KeyActions!?                                                  @as 4/2001
  _actionHandler.clearActionLists();

  _lpexView._view = null;
  KillRing.disposeView(this);
 }

 LpexView lpexView()
 {
  return _lpexView;
 }

 Document document()
 {
  return _document;
 }

 Screen screen()
 {
  return _screen;
 }

 CommandHandler commandHandler()
 {
  return _commandHandler;
 }

 ActionHandler actionHandler()
 {
  return _actionHandler;
 }

 DocumentPosition documentPosition()
 {
  return _documentPosition;
 }

 String fileLastComparedTo()
 {
  return _lastComparedTo;
 }

 void setFileLastComparedTo(String fileName)
 {
  _lastComparedTo = fileName;
 }

 void setWindow(LpexWindow lpexWindow)
 {
  if (lpexWindow != _lpexWindow)
   {
    if (_lpexWindow != null)
     {
      _lpexWindow._lpexView = null;
      _lpexWindow.dissociate();
     }

    if (lpexWindow != null)
     {
      if (lpexWindow._lpexView != null)
       {
        View view = lpexWindow._lpexView._view;
        view._lpexWindow = null;
        view.screen().setWindow(null);
       }
      lpexWindow._lpexView = _lpexView;
     }

    _lpexWindow = lpexWindow;
    screen().setWindow(lpexWindow);
   }
 }

 LpexWindow window()
 {
  return _lpexWindow;
 }

 int maxElementWidth()
 {
  if (!_maxElementWidthValid)
   {
    _maxElementWidth = 0;
    for (Element element = _document.elementList().firstVisible(this);
         element != null;
         element = element.nextVisible(this))
     {
      int width = element.elementView(this).width();
      if (width > _maxElementWidth)
       {
        _maxElementWidth = width;
       }
     }
    _maxElementWidthValid = true;
   }
  return _maxElementWidth;
 }

 void setMaxElementWidthInvalid()
 {
  _maxElementWidthValid = false;
 }

 boolean maxElementWidthValid()
 {
  return _maxElementWidthValid;
 }

 void setElementWidthsInvalid()
 {
  for (Element element = _document.elementList().first();
       element != null;
       element = element.next())
   {
    element.elementView(this).setWidthInvalid();
   }
  setMaxElementWidthInvalid();
 }

 int maxPrefixAreaWidth()
 {
  if (!_maxPrefixAreaWidthValid)
   {
    _maxPrefixAreaWidth = 0;
    for (Element element = _document.elementList().firstVisible(this);
         element != null;
         element = element.nextVisible(this))
     {
      int width = element.elementView(this).prefixAreaWidth();
      if (width > _maxPrefixAreaWidth)
       {
        _maxPrefixAreaWidth = width;
       }
     }
    _maxPrefixAreaWidthValid = true;
   }
  return _maxPrefixAreaWidth;
 }

 void setMaxPrefixAreaWidthInvalid()
 {
  _maxPrefixAreaWidthValid = false;
 }

 boolean maxPrefixAreaWidthValid()
 {
  return _maxPrefixAreaWidthValid;
 }

 void setPrefixAreaWidthsInvalid()
 {
  for (Element element = _document.elementList().first();
       element != null;
       element = element.next())
   {
    element.elementView(this).setPrefixAreaWidthInvalid();
   }
  setMaxPrefixAreaWidthInvalid();
 }

 boolean topExpandHideHeader()
 {
  if (_forceAllVisible)
   {
    return false;
   }
  for (Element element = _document.elementList().first();
       element != null;
       element = element.next())
   {
    ElementView elementView = element.elementView(this);
    if (elementView.expandHideVisible())
     {
      return false;
     }
    if (!element.show() || elementView.show())
     {
      return true;
     }
   }
  return false;
 }

 String topExpandHideText()
 {
  if (topExpandHideHeader())
   {
    return topExpanded()? "-" : "+";
   }
  return "";
 }

 boolean topExpanded()
 {
  return _topExpanded;
 }

 void setTopExpanded(boolean topExpanded)
 {
  if (_topExpanded != topExpanded)
   {
    _topExpanded = topExpanded;
    setVisibleElementOrdinalsInvalid();
   }
 }

 boolean hiddenElements()
 {
  validateVisibleElements();
  return _hiddenElements;
 }

 void setVisibleElementOrdinalsInvalid()
 {
  _visibleElementOrdinalsValid = false;
 }

 void validateVisibleElements()
 {
  if (!_visibleElementOrdinalsValid)
   {
    _hiddenElements = false;
    boolean withinExpanded = topExpanded();
    Element element;
    int count = 0;
    if (_screen != null && _screen.currentExpandHide() && topExpandHideHeader())
     {
      count = 1;
     }
    for (element = _document.elementList().first();
         element != null;
         element = element.next())
     {
      ElementView elementView = element.elementView(this);
      elementView.setExpandedVisible(false);
      if (_forceAllVisible || elementView.expandHideVisible())
       {
        count++;
        withinExpanded = elementView.expanded();
       }
      else if (!element.show() || elementView.show())
       {
        elementView.setExpandedVisible(withinExpanded);
        if (withinExpanded)
         {
          count++;
         }
        _hiddenElements = true;
       }
      elementView.setVisibleOrdinal(count);
     }
    _visibleElementOrdinalsValid = true;
   }
 }

 int visibleElementOrdinalOf(Element element)
 {
  validateVisibleElements();
  return element.elementView(this).visibleOrdinal();
 }

 int visibleElementCount()
 {
  Element last = _document.elementList().last();
  if (last != null)
   {
    return visibleElementOrdinalOf(last);
   }
  return 0;
 }

 void expandAll(boolean on)
 {
  setTopExpanded(on);
  document().elementList().expandAll(this, on);
  document().undo().expandAll(this, on);
 }

 /**
  * Return the [character*] position = ONE-based offset into the displayText,
  * that corresponds to <code>textPosition</code> into the text of an element
  * in this view.
  *
  * @param charPosition true = *showSosi is "on" and the sourceEncoding is EBCDIC
  *                     DBCS:  ensure that the position returned is that of a real
  *                     character, not that of an emulated SO/SI control character
  */
 private int displayPosition(ElementView elementView, int textPosition, boolean charPosition)
 {
  Element element = elementView.element();
  int sequenceNumbersWidth = document().elementList().sequenceNumbersWidth();
  boolean expandTabs = element.tabs() && currentExpandTabs();

  /*======================================================*/
  /*  (a) no tabs to expand, no sequence numbers to show  */
  /*======================================================*/
  if (!expandTabs &&
      (currentHideSequenceNumbers() || sequenceNumbersWidth == 0))
   {
    // not even SO/SIs
    if (!nls().displayingSosi())
     {
      return textPosition;
     }

    // OK, maybe some SO/SIs...
    return (charPosition)? nls().emulationCharIndex(element.text(), textPosition-1) + 1 :
                           nls().emulationIndex(element.text(), textPosition-1) + 1;
   }

  /*==================================================*/
  /*  (b) tabs and/or sequence numbers and/or SO/SIs  */
  /*==================================================*/
  String fullDisplayText;              // get text [+ display-formatted sequence numbers]
  if (currentHideSequenceNumbers() || sequenceNumbersWidth == 0)
   {
    fullDisplayText = element.text();
   }
  else
   {
    fullDisplayText = document().elementList().addDisplaySequenceNumbers(element, this);
    // textPosition is in element.text(), adjust to make it in fullDisplayText
    textPosition += getSequenceNumbersStyle().length();
   }

  /*----------------------------------------------*/
  /* adjust textPosition for the emulation SO/SIs */
  /*----------------------------------------------*/
  if (nls().displayingSosi())
   {
    textPosition = (charPosition)?
                    nls().emulationCharIndex(fullDisplayText, textPosition-1) + 1 :
                    nls().emulationIndex(fullDisplayText, textPosition-1) + 1;

    // add SO/SIs here, *before* calculating tab expansions
    fullDisplayText = nls().addSourceSosi(fullDisplayText);
   }

  /*-----------------------------------------------------------*/
  /* get displayPosition from textPosition with Tabs expansion */
  /*-----------------------------------------------------------*/
  int displayPosition = textPosition;
  if (expandTabs)
   {
    // if sequence numbers, skip them before expanding tabs
    int startMeat = 0;
    int iText = 0;
    if (!currentHideSequenceNumbers() &&
        sequenceNumbersWidth != 0)
     {
      startMeat = getSequenceNumbersStyle().length();
      // assume no DBCS / MBCS / SO/SIs in text's sequence-numbers area... -as-
      iText = getSequenceNumbersStyle().length();
     }

    boolean mbcs = nls().isSourceMbcs();
    displayPosition = startMeat; // UNICODE char offset into displayText

    // TABS EXPANDED BY tabs PARAMETER SETTING
    int tc = 0;         // last-used tab stop in tabs._tabStops[]
    int lastTabVal = 0; // last-used tab stop position

    int pos = 1; // column position in the display text
    for (int i = iText + 1;
         i < textPosition;
         i++)
     {
      char c = (i <= fullDisplayText.length())? fullDisplayText.charAt(i - 1) : ' ';
      if (c == '\t')
       {
        while (tc < _currentTabs._tabStops.length && lastTabVal <= pos)
         {
          lastTabVal = _currentTabs._tabStops[tc++];
         }
        while (lastTabVal <= pos)
         {
          lastTabVal += (_currentTabs._tabIncrement == 0)? 1 : _currentTabs._tabIncrement;
         }
        int tabLen = lastTabVal - pos;
        displayPosition += tabLen; /* we're at lastTabVal */
        pos = lastTabVal;          /*   display position now */
       }
      else
       {
        displayPosition++;
        if (mbcs)
         {
          pos += nls().sourceWidth(c);
         }
        else
         {
          pos++;
         }
       }
     }

    displayPosition++;

    // TABS EXPANDED TO EVERY-8-CHARACTERS:
    // int pos = 1; // 1 .. 8 for each tab
    // for (int i = iText + 1; i < textPosition; i++)
    //  {
    //   char c = (i <= fullDisplayText.length())? fullDisplayText.charAt(i - 1) : ' ';
    //   if (c == '\t')
    //    {
    //     while (pos < 9)
    //      {
    //       displayPosition++;
    //       pos++;
    //      }
    //    }
    //   else
    //    {
    //     displayPosition++;
    //     if (mbcs)
    //      {
    //       pos += nls().sourceWidth(c);
    //      }
    //     else
    //      {
    //       pos++;
    //      }
    //    }
    //   if (pos >= 9)
    //    {
    //     pos -= 8;
    //    }
    //  }
    // displayPosition++;
   }

  return displayPosition;
 }

 /**
  * Return the display column for an offset into the display text.
  */
 int displayColumn(ElementView elementView, int position)
 {
  // in SBCS, offset into displayText is good enough
  int column = displayPosition(elementView, position, true);

  if (nls().isSourceMbcs())
   {
    // DBCS/MBCS-sensitive column corresponding to the offset above:  note that
    // we expand Tabs according to the DBCS/MBCS chars' widths...
    column = nls().columnFromDisplayIndex(elementView.displayText().text(), column-1)+1;
   }

  return column;
 }

 /**
  * Return the display column for an offset into the display text, good for
  * processing tabs expansion.  When there are sequence numbers, the tabs
  * expansion starts only *after* them.
  */
 int displayColumnForTabs(ElementView elementView, int position)
 {
  int column = displayColumn(elementView, position);

  if (!currentHideSequenceNumbers() &&
      document().elementList().sequenceNumbersWidth() != 0)
   {
    // consider the sequence-numbers width as showing [formatted] on display
    column -= getSequenceNumbersStyle().length();
    if (column < 1)
     {
      column = 1;
     }
   }

  return column;
 }

 /**
  * Retrieve the current column for the "Column" field on the LPEX status line.
  * When useSourceColumns is "on", the column in the source character encoding
  * is returned.
  *
  * @see #currentFormatLineColumn
  */
 int currentColumn(ElementView elementView)
 {
  // char offset into displayText
  int column = displayPosition(elementView,
                               documentPosition().position(), true);

  // don't consider those display columns showing the [formatted] sequence numbers
  // as actual document columns
  boolean adjustForSequenceNumbers =
             !currentHideSequenceNumbers() &&
             document().elementList().sequenceNumbersWidth() != 0;

  if (nls().usingSourceColumns())
   {
    // source-encoding column corresponding to the char offset above
    column = nls().sourceColumnFromDisplayIndex(elementView.displayText().text(), column-1)+1;
   }

  if (adjustForSequenceNumbers)
   {
    // assume no DBCS/MBCS in the sequence-numbers area...
    column -= getSequenceNumbersStyle().length();
   }

  return column;
 }

 /**
  * Retrieve the current column offset for cursor display in the format line.
  * The format line displays blanks for any [formatted] sequence-numbers area,
  * so its cursor offset *should* count take all these columns into account.
  *
  * @see #currentColumn
  */
 int currentFormatLineColumn(ElementView elementView)
 {
  // return offset into displayText
  return displayPosition(elementView, documentPosition().position(), true);
 }

 /**
  * Return the offset into the text of an element in this view, corresponding to
  * the value of / assigned to the displayPosition parameter (column).
  * Called from e.g., DisplayPositionParameter.setValue().
  */
 int positionFromDisplayPosition(ElementView elementView, int displayPosition)
 {
  // DBCS/MBCS:  first convert the column position (sensitive to the
  // characters' widths) to an offset into displayText
  boolean mbcs = nls().isSourceMbcs();
  if (mbcs)
   {
    displayPosition =
      nls().displayIndexFromColumn(elementView.displayText().text(), displayPosition-1)+1;
   }

  ElementList elementList = document().elementList();
  Element element = elementView.element();
  boolean expandTabs = element.tabs() && currentExpandTabs();
  boolean addSequenceNumbers = !currentHideSequenceNumbers() &&
                               elementList.sequenceNumbersWidth() != 0;

  /*======================================================*/
  /*  (a) no tabs to expand, no sequence numbers to show  */
  /*======================================================*/
  if (!expandTabs && !addSequenceNumbers)
   {
    // adjust for any SO/Sis
    if (nls().displayingSosi())
     {
      // right here, displayPosition is the offset into the original text but
      // with emulation SO/SIs added:  convert to offset into the element text
      displayPosition = nls().indexFromEmulationIndex(element.text(), displayPosition-1)+1;
     }
    return displayPosition;
   }

  /*==================================================*/
  /*  (b) tabs and/or sequence numbers and/or SO/SIs  */
  /*==================================================*/
  String fullDisplayText;              // get text [+ display-formatted sequence numbers]
  if (!addSequenceNumbers)
   {
    fullDisplayText = element.text();
   }
  else
   {
    fullDisplayText = document().elementList().addDisplaySequenceNumbers(element, this);
   }

  /*--------------------------------*/
  /* adjust back for Tabs expansion */
  /*--------------------------------*/
  int textPosition = displayPosition;
  if (expandTabs)
   {
    String text = fullDisplayText;
    if (nls().displayingSosi())
     {
      // add SO/SIs here, *before* calculating tab expansions
      text = nls().addSourceSosi(text);
     }

    // if sequence numbers, skip them before expanding tabs
    int startMeat = 1;
    int iText = 0;
    if (addSequenceNumbers)
     {
      startMeat = getSequenceNumbersStyle().length() + 1;
      // assume no SO/SIs were added in fullDisplayText's sequence-numbers area... -as-
      iText = getSequenceNumbersStyle().length();
     }

    // (a) we are inside sequence-numbers area
    if (displayPosition < startMeat)
     {
      textPosition = displayPosition;
      //text here is fullDISPLAYText, so this is not necessary:
      //if (textPosition < iText + 1)
      // {
      //  textPosition = iText + 1;
      // }
     }

    // (b) we are inside actual text area
    else
     {
      // TABS EXPANDED BY tabs PARAMETER SETTING
      int tc = 0;         // last-used tab stop in tabs._tabStops[]
      int lastTabVal = 0; // last-used tab stop position

      int pos = 1; // column position in the display text
      for (int i = startMeat;
           i < displayPosition; // until we reach display position
           iText++)
       {
        char c = (iText < text.length())? text.charAt(iText) : ' ';
        if (c == '\t')
         {
          while (tc < _currentTabs._tabStops.length && lastTabVal <= pos)
           {
            lastTabVal = _currentTabs._tabStops[tc++];
           }
          while (lastTabVal <= pos)
           {
            lastTabVal += (_currentTabs._tabIncrement == 0)? 1 : _currentTabs._tabIncrement;
           }
          int tabLen = lastTabVal - pos;
          i += tabLen;      /* we're at lastTabVal */
          pos = lastTabVal; /*   display position now */
         }
        else
         {
          i++;
          if (mbcs)
           {
            pos += nls().sourceWidth(c);
           }
          else
           {
            pos++;
           }
         }
       }
      textPosition = ++iText;

      // TABS EXPANDED TO EVERY-8-CHARACTERS:
      // int pos = 1; // 1 .. 8 for each tab
      // for (int i = startMeat;
      //      i < displayPosition; // until we reach display position
      //      iText++)
      //  {
      //   char c = (iText < text.length())? text.charAt(iText) : ' ';
      //   if (c == '\t')
      //    {
      //     while (pos < 9)
      //      {
      //       i++;
      //       pos++;
      //      }
      //    }
      //   else
      //    {
      //     i++;
      //     if (mbcs)
      //      {
      //       pos += nls().sourceWidth(c);
      //      }
      //     else
      //      {
      //       pos++;
      //      }
      //    }
      //   if (pos >= 9)
      //    {
      //     pos -= 8;
      //    }
      //  }
      // textPosition = ++iText;
     }
   }

  /*-------------------*/
  /* adjust for SO/SIs */
  /*-------------------*/
  if (nls().displayingSosi())
   {
    // here, textPosition = the offset into the original text (i.e., before the
    // Tab expansions), but one with emulation SO/SIs added:  convert to offset
    // into the element text
    textPosition = nls().indexFromEmulationIndex(fullDisplayText, textPosition-1)+1;
   }

  /*-----------------------------------------------------------*/
  /* position in fullDisplayText => position in element.text() */
  /*-----------------------------------------------------------*/
  if (addSequenceNumbers)
   {
    // consider sequence numbers width as showing [formatted] on display
    textPosition -= getSequenceNumbersStyle().length();
    if (textPosition < 1)
     {
      textPosition = 1;
     }
   }

  return textPosition;
 }

 /**
  * Return the [character] pixel position in the displayText of an element in
  * this view, that corresponds to <code>position</code> into its text.
  *
  * @param charPosition true = ensure pixel position of a character, not that
  *                            of an emulated SO/SI control
  */
 int pixelPosition(ElementView elementView, int position, boolean charPosition)
 {
  int pixelPosition = 0;
  TextFontMetrics textFontMetrics = screen().textFontMetrics();
  if (textFontMetrics != null)
   {
    // if SO/SIs must even calculate position=1, to steer away from initial SO
    if (position > 0)
     {
      if (charPosition) // get char offset into displayText (away from SO/SIs)
       {
        position = displayPosition(elementView, position, true);
       }
      else              // get offset into displayText
       {
        position = displayPosition(elementView, position, false);
       }

      String text = elementView.displayText().text();
      if (text != null && text.length() > 0)
       {
        if (text.length() > position - 1)
         {
          pixelPosition = textFontMetrics.substringWidth(text, 0, position - 1);
         }
        else
         {
          pixelPosition = elementView.width() +
            textFontMetrics.spaceWidth() * (position - 1 - text.length());
         }
       }
      else
       {
        pixelPosition = textFontMetrics.spaceWidth() * (position - 1);
       }
     }
   }
  return pixelPosition;
 }

 /**
  * Return the pixel position in the prefix text of an element in this view.
  */
 int prefixPixelPosition(ElementView elementView, int prefixPosition)
 {
  int prefixPixelPosition = 0;
  TextFontMetrics textFontMetrics = screen().textFontMetrics();
  if (textFontMetrics != null)
   {
    if (prefixPosition > 1)
     {
      String prefixText = elementView.prefixText();
      if (prefixText != null && prefixText.length() > 0)
       {
        if (prefixPosition > prefixText.length() + 1)
         {
          prefixPosition = prefixText.length() + 1;
         }
        prefixPixelPosition = textFontMetrics.substringWidth(prefixText, 0, prefixPosition - 1);
       }
     }
   }
  return prefixPixelPosition;
 }

 /**
  * Return the width in pixels of the character at <code>position</code> in the
  * text of an element in this view.
  */
 int charWidth(Element element, int position)
 {
  int charWidth = 0;
  TextFontMetrics textFontMetrics = screen().textFontMetrics();
  if (textFontMetrics != null && position > 0)
   {
    charWidth = textFontMetrics.spaceWidth();
    String text = element.text();
    if (text.length() > 0 &&
        text.length() > position - 1)
     {
      char c = text.charAt(position - 1);
      if (c == '\t' && currentExpandTabs())
       {
        ElementView elementView = element.elementView(this);
        charWidth *= displayPosition(elementView, position + 1, false) - // display position
                     displayPosition(elementView, position, true);       // display char position
       }
      else
       {
        charWidth = textFontMetrics.charWidth(c);
       }
     }
   }
  return charWidth;
 }

 /**
  * Return the width in pixels of the character at <code>prefixPosition</code>
  * in the prefix text of an element in this view.
  */
 int prefixCharWidth(ElementView elementView, int prefixPosition)
 {
  int prefixCharWidth = 0;
  TextFontMetrics textFontMetrics = screen().textFontMetrics();
  if (textFontMetrics != null)
   {
    String prefixText = elementView.prefixText();
    if (prefixText != null &&
        prefixText.length() > 0 &&
        prefixText.length() > prefixPosition - 1)
     {
      char c = prefixText.charAt(prefixPosition - 1);
      prefixCharWidth = textFontMetrics.charWidth(c);
     }
   }
  return prefixCharWidth;
 }

 /**
  * Return the position in the text of an element in this view, that corresponds
  * to <code>pixelPosition</code> into its displayText.
  */
 int position(ElementView elementView, int pixelPosition)
 {
  // first find out what the position would be if the line
  // were all spaces - this will be used as a starting point
  int position = 1;
  TextFontMetrics textFontMetrics = screen().textFontMetrics();
  if (textFontMetrics != null)
   {
    int spaceWidth = textFontMetrics.spaceWidth();
    if (spaceWidth != 0)
     {
      position = (pixelPosition / textFontMetrics.spaceWidth()) + 1;

      int x = pixelPosition(elementView, position, false);
      if (x <= pixelPosition)
       {
        for (;;)
         {
          x = pixelPosition(elementView, position + 1, false);
          if (x > pixelPosition)
           {
            break;
           }
          position++;
         }
       }
      else
       {
        while(position > 1)
         {
          x = pixelPosition(elementView, position, false);
          if (x <= pixelPosition)
           {
            break;
           }
          position--;
         }
       }
     }
   }

  return position;
 }

 /**
  * Return the position in the prefix text of an element in this view, that
  * is at <code>prefixPixelPosition</code>.
  */
 int prefixPosition(ElementView elementView, int prefixPixelPosition)
 {
  // first find out what the position would be if the text
  // were all spaces - this will be used as a starting point
  int prefixPosition = 1;
  TextFontMetrics textFontMetrics = screen().textFontMetrics();
  if (textFontMetrics != null)
   {
    int spaceWidth = textFontMetrics.spaceWidth();
    if (spaceWidth != 0)
     {
      prefixPosition = (prefixPixelPosition / textFontMetrics.spaceWidth()) + 1;
      int maxPosition = elementView.prefixEnd();
      if (prefixPosition > maxPosition)
       {
        prefixPosition = maxPosition;
       }

      int x = prefixPixelPosition(elementView, prefixPosition);
      if (x <= prefixPixelPosition)
       {
        while (prefixPosition < maxPosition)
         {
          x = prefixPixelPosition(elementView, prefixPosition + 1);
          if (x > prefixPixelPosition)
           {
            break;
           }
          prefixPosition++;
         }//end "while"
       }
      else
       {
        while(prefixPosition > 1)
         {
          x = prefixPixelPosition(elementView, prefixPosition);
          if (x <= prefixPixelPosition)
           {
            break;
           }
          prefixPosition--;
         }//end "while"
       }
     }
   }

  return prefixPosition;
 }

 void setInsertMode(boolean insertMode)
 {
  _insertMode = insertMode;
 }

 boolean insertMode()
 {
  return _insertMode;
 }

 void setInPrefix(boolean inPrefix)
 {
  if (!_prefixProtect)
   {
    _inPrefix = inPrefix;
   }
 }

 boolean inPrefix()
 {
  return _inPrefix;
 }

 void setPrefixProtect(boolean prefixProtect)
 {
  _prefixProtect = prefixProtect;
  if (_prefixProtect)
   {
    _inPrefix = false;
   }
 }

 boolean prefixProtect()
 {
  return _prefixProtect;
 }

 boolean tryToDeleteStreamBlock()
 {
  if (!changeAllowed())
   {
    return false;
   }
  if (Block.view() == this &&
      Block.type() == Block.STREAM && Block.anythingUnprotectedSelected())
   {
    Block.delete();
    Block.clear();
    return true;
   }
  return false;
 }

 void receiveCharacter(char character)
 {
  receiveCharacter(insertMode(), character);
 }

 void receiveCharacter(boolean insertMode, char character)
 {
  Element element = documentPosition().element();
  if (element == null)
   {
    return;
   }
  boolean insert = insertMode;
  if (_inPrefix)
   {
    if (insert)
     {
      insertPrefixText(String.valueOf(character));
     }
    else
     {
      replacePrefixText(String.valueOf(character));
     }
   }
  else if (!element.show() && !markList().protect(element) && changeAllowed())
   {
    if (tryToDeleteStreamBlock())
     {
      insert = true;
     }
    if (insert)
     {
      insertText(String.valueOf(character));
     }
    else
     {
      replaceText(String.valueOf(character));
     }
   }
 }

 /**
  * Insert a piece of text at the current cursor position.
  *
  * Line delimiters considered:
  *   CRLF "\r\n" (carriage return + line feed 0x0D + 0x0A),
  *   CR   '\r'   (carriage return 0x0D),
  *   LF   '\n'   (line feed 0x0A).
  */
 void insertText(String insertText)
 {
  if (insertText.length() == 0)
   {
    return; // no text to insert.
   }

  Element element = documentPosition().element();
  boolean ignoreFieldsSet = false;

  int i = 0;
  int indexOfLF = insertText.indexOf('\n');
  int indexOfCR = insertText.indexOf('\r');

  // 1.- if insertText consists of *new* lines, insert a new element even in
  // those circumstances where we wouldn't otherwise allow insert (no visible
  // cursor, mark-protected element, readonly document)
  boolean insertingNewLines = (indexOfLF == 0 || indexOfCR == 0);
  if (insertingNewLines &&
      (element == null ||
       (element.show() && !markList().insertElementProtect(element) && changeAllowed())))
   {
    setIgnoreFields();
    ignoreFieldsSet = true;
    element = new Element(document());
    insertElement(element);

    // skip the initial EOL sequence
    i = (indexOfCR == 0 && indexOfLF == 1)? 2 : 1;
    if (indexOfLF != -1)
       indexOfLF = insertText.indexOf('\n', i);
    if (indexOfCR != -1)
       indexOfCR = insertText.indexOf('\r', i);
   }

  if (element == null || markList().protect(element) ||
      (!element.show() && !changeAllowed()))
   {
    return; // no cursor / cursor on mark-protected element / cursor on non-show element in readonly doc.
   }

  // 2.- insert all the new lines of text
  if (indexOfLF >= 0 || indexOfCR >= 0)
   {
    if (!ignoreFieldsSet)
     {
      setIgnoreFields();
      ignoreFieldsSet = true;
     }

    _document.resetUserActionElements();
    boolean forceAllVisible = forceAllVisible();
    setForceAllVisible(true);

    do
     {
      // CRLF / CR: CR encountered before LF *OR* no LF at all
      if ((indexOfCR < indexOfLF && indexOfCR != -1) || indexOfLF == -1)
       {
        insertText(insertText.substring(i, indexOfCR)); // recursive!
        i = indexOfCR + ((indexOfLF == indexOfCR+1)? 2 : 1);
       }                                        // CRLF  CR
      // LF: LF encountered before any CR
      else
       {
        insertText(insertText.substring(i, indexOfLF)); // recursive!
        i = indexOfLF + 1;
       }

      splitElement();
      element = documentPosition().element();

      if (indexOfLF != -1)
         indexOfLF = insertText.indexOf('\n', i);
      if (indexOfCR != -1)
         indexOfCR = insertText.indexOf('\r', i);
     } while (indexOfLF >= 0 || indexOfCR >= 0);

    setForceAllVisible(forceAllVisible);
   }

  // 3.- insert any trailing piece of text left
  if (i < insertText.length())
   {
    insertText(element, documentPosition().position(), insertText.substring(i));
   }

  if (ignoreFieldsSet)
   {
    resetIgnoreFields();
   }
 }

 /**
  * Insert a no-new-lines piece of text in an element at the given position.
  */
 void insertText(Element element, int position, String insertText)
 {
  insertText(element, position, insertText, false);
 }

 /**
  * Insert a no-new-lines piece of text in an element at the given position.
  *
  * @param force true = insert even if readonly / the element is protected
  */
 void insertText(Element element, int position, String insertText, boolean force)
 {
  if (element != null && insertText.length() > 0 &&
      (force ||
         (!markList().protect(element) && (element.show() || changeAllowed()))))
   {
    int insertLength = insertText.length();
    int availableFieldSpace = availableFieldSpace(element, position);
    if (availableFieldSpace != -1 && availableFieldSpace < insertLength)
     {
      insertText = insertText.substring(0, availableFieldSpace);
      insertLength = availableFieldSpace;
     }
    if (insertLength > 0)
     {
      _document.undo().recordChange(this, element, position);
      int fieldLimit = fieldLimit(position);
      if (fieldLimit != 0)
       {
        setIgnoreFields();
        deleteText(element, fieldLimit - insertLength + 1, insertLength, force);
        resetIgnoreFields();
       }
      if (element.length() >= position)
       {
        markList().textInserted(element, position, insertLength);
       }
      else
       {
        markList().textReplaced(element, position, insertLength);
       }
      padTextTo(element, position, force);
      StringBuffer buffer;
      String text = element.text();
      buffer = new StringBuffer(text);
      buffer.insert(position - 1, insertText);
      element.setText(this, buffer.toString());
      for (ElementView elementView = element._firstElementView;
           elementView != null;
           elementView = elementView._next)
       {
        String style = elementView.style();
        if (style != null && style.length() >= position)
         {
          buffer = new StringBuffer(style);
          for (int i = 0; i < insertLength; i++)
           {
            buffer.insert(position - 1, '!');
           }
          elementView.setStyle(buffer.toString());
         }
       }
      documentPosition().textInserted(element, position, insertLength);
      _document.undo().recordPosition(element, position + insertLength);
     }
   }
 }

 void insertTextRectangle(String insertText)
 {
  Element element = documentPosition().element();
  if (markList().protect(element) || !changeAllowed())
   {
    return;
   }
  if (element == null && insertText.length() > 0 && insertText.charAt(0) == '\n')
   {
    element = new Element(document());
    insertElement(element);
    insertText = insertText.substring(1);
   }
  if (element != null)
   {
    ElementView elementView = element.elementView(this);
    int pixelPosition = elementView.pixelPosition(documentPosition().position());
    int indexOfLineSeparator = insertText.indexOf('\n');
    if (indexOfLineSeparator >= 0)
     {
      _document.resetUserActionElements();
     }
    if (element.show())
     {
      Element nextVisibleNonShow = element.nextVisibleNonShow(this);
      if (nextVisibleNonShow != null && markList().protect(nextVisibleNonShow))
       {
        element = null;
       }
      else
       {
        element = nextVisibleNonShow;
       }
      if (element == null)
       {
        element = new Element(document());
        insertElement(element);
       }
      documentPosition().jump(element, position(element.elementView(this), pixelPosition));
     }
    while (indexOfLineSeparator >= 0)
     {
      insertText(insertText.substring(0, indexOfLineSeparator));
      insertText = insertText.substring(indexOfLineSeparator + 1);
      Element next = element.nextVisibleNonShow(this);
      if (next != null && !markList().protect(next))
       {
        element = next;
       }
      else
       {
        Element newElement = new Element(document());
        insertElement(newElement);
        element = newElement;
       }
      documentPosition().jump(element, position(element.elementView(this), pixelPosition));
      indexOfLineSeparator = insertText.indexOf('\n');
     }
    insertText(insertText);
   }
 }

 void replaceText(String replaceText)
 {
  replaceText(replaceText, false);
 }

 /**
  * Replace a piece of text at the current cursor position.
  * The <i>n</i> characters of the new text replace up to <i>n</i> characters
  * in the existing text.
  *
  * Line delimiters considered: '\n' LF (line feed 0x0A).
  */
 void replaceText(String replaceText, boolean transparent)
 {
  Element element = documentPosition().element();
  if (element == null || markList().protect(element) ||
      (!element.show() && !changeAllowed()))
   {
    return; // no cursor / cursor on mark-protected element / cursor on non-show element in readonly doc.
   }

  if (element != null)
   {
    int position = documentPosition().position();

    // (1) replaceText has new line(s)
    if (replaceText.indexOf('\n') != -1)
     {
      _document.resetUserActionElements();
      String text = element.text();
      if (text.length() >= position)
       {
        deleteText(text.length() - position + 1); // length of text to delete from cursor
       }
      insertText(replaceText);
      return;
     }

    // (2) replaceText has no new lines
    _document.undo().recordChange(this, element);
    String text = element.text();
    if (text.length() < position)
     {
      insertText(replaceText);
     }
    else
     {
      markList().textReplaced(element, position, replaceText.length());
      if (transparent)
       {
        String originalText = text;
        originalText = originalText.substring(position - 1);
        StringBuffer buffer = new StringBuffer(replaceText);
        for (int i = 0; i < buffer.length() && i < originalText.length(); i++)
         {
          if (originalText.charAt(i) != ' ')
           {
            buffer.setCharAt(i, originalText.charAt(i));
           }
         }
        replaceText = buffer.toString();
       }

      String newText;
      if (position > 1)
       {
        newText = text.substring(0, position - 1) + replaceText;
       }
      else
       {
        newText = replaceText;
       }
      if (text.length() > newText.length())
       {
        newText += text.substring(newText.length());
       }
      element.setText(this, newText);

      for (ElementView elementView = element._firstElementView;
           elementView != null;
           elementView = elementView._next)
       {
        String style = elementView.style();
        if (style != null && style.length() >= position)
         {
          StringBuffer buffer;
          if (position > 1)
           {
            buffer = new StringBuffer(style.substring(0, position - 1));
           }
          else
           {
            buffer = new StringBuffer();
           }
          for (int i = 0; i < replaceText.length(); i++)
           {
            buffer.append('!');
           }
          if (style.length() > buffer.length())
           {
            buffer.append(style.substring(buffer.length()));
           }
          elementView.setStyle(buffer.toString());
         }
       }

      documentPosition().right(replaceText.length());
     }

    _document.undo().recordPosition(this);
   }
 }

 String deleteText()
 {
  return deleteText(1);
 }

 String deleteText(int len)
 {
  return deleteText(documentPosition().element(), documentPosition().position(), len);
 }

 String deleteText(Element element, int position)
 {
  return deleteText(element, position, 1);
 }

 String deleteText(Element element, int position, int len)
 {
  return deleteText(element, position, len, false);
 }

 String deleteText(Element element, int position, int len, boolean force)
 {
  return deleteText(element, position, len, force, true);
 }

 /**
  * @param element  element
  * @param position ONE-based starting position for deletion
  * @param len      number of characters to delete
  * @param force    true = delete even if readonly / the element is protected
  * @param maintainSequenceText true = update the sequence-numbers text part
  *                 of the element if necessary
  */
 String deleteText(Element element, int position, int len,
                   boolean force, boolean maintainSequenceText)
 {
  String deleteText = "";
  if (element != null &&
      (force || (!markList().protect(element) && (element.show() || changeAllowed()))))
   {
    // update _position, _desiredPixelPosition, and preserves for this deletion
    documentPosition().textDeleted(element, position, len);

    String text = element.text();
    if (text.length() >= position) // there is some 'meat' to delete
     {
      if (position + len - 1 > text.length())
       {
        len = text.length() - position + 1;
       }

      // add corresponding number of blanks to the next field limit
      int fieldLimit = fieldLimit(position + len - 1);
      if (fieldLimit != 0 && text.length() > fieldLimit)
       {
        String insertText = "";
        for (int i = 0; i < len; i++)
         {
          insertText += " ";
         }
        setIgnoreFields();
        insertText(element, fieldLimit + 1, insertText, force);
        resetIgnoreFields();
        text = element.text();
       }

      // update any marks for this deletion
      markList().textDeleted(element, position, len);

      // record this element deletion for undo/redo
      _document.undo().recordChange(this, element, position);

      // build up the new element text
      String newText;
      if (position > 1)
       {
        newText = text.substring(0, position - 1);
       }
      else
       {
        newText = "";
       }
      if (position + len - 1 < text.length())
       {
        newText += text.substring(position + len - 1);
        deleteText = text.substring(position - 1, position + len - 1);
       }
      else
       {
        deleteText = text.substring(position - 1);
       }

      // set the new text in the element
      element.setText(this, newText, maintainSequenceText);

      // delete corresponding style characters in all the element views
      for (ElementView elementView = element._firstElementView;
           elementView != null;
           elementView = elementView._next)
       {
        String style = elementView.style();
        if (style != null && style.length() >= position)
         {
          StringBuffer buffer;
          if (position > 1)
           {
            buffer = new StringBuffer(style.substring(0, position - 1));
           }
          else
           {
            buffer = new StringBuffer();
           }
          if (position + len < style.length())
           {
            buffer.append(style.substring(position + len - 1));
           }
          elementView.setStyle(buffer.toString());
         }
       }

      // record the position for undo/redo
      _document.undo().recordPosition(element, position);
     }
   }

  return deleteText;
 }

 String deleteText(Element element1, int position1,
                   Element element2, int position2)
 {
  String deleteText = "";
  if (element1 != null && element2 != null && changeAllowed())
   {
    Element topElement = null;
    Element bottomElement = null;
    int topPosition = 0;
    int bottomPosition = 0;
    if (element1 == element2)
     {
      topElement = bottomElement = element1;
      if (position1 > position2)
       {
        topPosition = position2;
        bottomPosition = position1;
       }
      else
       {
        topPosition = position1;
        bottomPosition = position2;
       }
     }
    else
     {
      ElementList elementList = document().elementList();
      if (elementList.ordinalOf(element1) > elementList.ordinalOf(element2))
       {
        topElement = element2;
        topPosition = position2;
        bottomElement = element1;
        bottomPosition = position1;
       }
      else
       {
        topElement = element1;
        topPosition = position1;
        bottomElement = element2;
        bottomPosition = position2;
       }
     }
    if (topElement == bottomElement)
     {
      if (!topElement.show() && !markList().protect(topElement))
       {
        int len = bottomPosition - topPosition;
        if (len > 0)
         {
          deleteText = deleteText(topElement, topPosition, len);
         }
       }
     }
    else
     {
      boolean join = true;
      if (!topElement.show() && !markList().protect(topElement))
       {
        if (topElement.length() >= topPosition)
         {
          deleteText = deleteText(topElement,
                                  topPosition,
                                  topElement.length() - topPosition + 1);
         }
        else
         {
          padTextTo(topElement, topPosition);
         }
        deleteText += '\n';
       }
      else
       {
        join = false;
       }
      Element element;
      Element next;
      for (element = topElement.next(), next = null;
           element != bottomElement && element != null;
           element = next)
       {
        next = element.next();
        if (element.visible(this) && !markList().protect(element))
         {
          element.setDeletePending(true);
         }
        else
         {
          join = false;
         }
       }
      boolean forceAllVisible = forceAllVisible();
      setForceAllVisible(true);
      for (element = topElement.next(), next = null;
           element != bottomElement && element != null;
           element = next)
       {
        next = element.next();
        if (element.deletePending())
         {
          element.setDeletePending(false);
          if (!element.show())
           {
            deleteText += element.text() + '\n';
           }
          deleteElement(element);
         }
       }
      setForceAllVisible(forceAllVisible);
      if (!bottomElement.show() && !markList().protect(element))
       {
        int len = bottomPosition - 1;
        if (len > 0)
         {
          deleteText += deleteText(bottomElement, 1, len);
         }
       }
      else
       {
        join = false;
       }
      if (join)
       {
        joinElements(topElement, bottomElement);
       }
     }
   }
  return deleteText;
 }

 void padText()
 {
  padTextTo(documentPosition().element(), documentPosition().position());
 }

 void padTextTo(Element element, int position)
 {
  padTextTo(element, position, false);
 }

 void padTextTo(Element element, int position, boolean force)
 {
  if (element != null &&
      (force || (!markList().protect(element) && (element.show() || changeAllowed()))))
   {
    String text = element.text();
    if (position > 1 && (text.length() < position - 1))
     {
      _document.undo().recordChange(this, element, position);
      StringBuffer buffer;
      int originalLength;
      if (text == null)
       {
        buffer = new StringBuffer();
        originalLength = 0;
       }
      else
       {
        buffer = new StringBuffer(text);
        originalLength = text.length();
       }
      buffer.setLength(position - 1);
      for (int i = originalLength; i < position - 1; i++)
       {
        buffer.setCharAt(i, ' ');
       }
      element.setText(this, buffer.toString());
     }
   }
 }

 void changeCase(int len, boolean upperCase)
 {
  changeCase(documentPosition().element(), documentPosition().position(), len, upperCase);
 }

 void changeCase(Element element, boolean upperCase)
 {
  changeCase(element, 1, upperCase);
 }

 void changeCase(Element element, int position, boolean upperCase)
 {
  if (element != null)
   {
    changeCase(element, position, element.end() - position, upperCase);
   }
 }

 void changeCase(Element element, int position, int len, boolean upperCase)
 {
  if (element != null && !markList().protect(element) &&
      (element.show() || changeAllowed()))
   {
    String text = element.text();
    if (len > 0 && position <= text.length())
     {
      StringBuffer buffer = new StringBuffer(text);
      if (position + len - 1 > buffer.length())
       {
        len = buffer.length() - position + 1;
       }
      for (int i = position - 1; i < position - 1 + len; i++)
       {
        char c = buffer.charAt(i);
        c = upperCase? Character.toUpperCase(c) : Character.toLowerCase(c);
        buffer.setCharAt(i, c);
       }
      _document.undo().recordChange(this, element, position);
      element.setText(this, buffer.toString());
     }
   }
 }

 void changeCase(Element element1, int position1,
                 Element element2, int position2,
                 boolean upperCase)
 {
  changeCase(element1, position1, element2, position2, upperCase, false);
 }

 void changeCase(Element element1, int position1,
                 Element element2, int position2,
                 boolean upperCase, boolean rectangle)
 {
  if (element1 != null && element2 != null && changeAllowed())
   {
    Element topElement = null;
    Element bottomElement = null;
    int topPosition = 0;
    int bottomPosition = 0;
    if (element1 == element2)
     {
      topElement = bottomElement = element1;
      if (position1 > position2)
       {
        topPosition = position2;
        bottomPosition = position1;
       }
      else
       {
        topPosition = position1;
        bottomPosition = position2;
       }
     }
    else
     {
      ElementList elementList = document().elementList();
      if (elementList.ordinalOf(element1) > elementList.ordinalOf(element2))
       {
        topElement = element2;
        topPosition = position2;
        bottomElement = element1;
        bottomPosition = position1;
       }
      else
       {
        topElement = element1;
        topPosition = position1;
        bottomElement = element2;
        bottomPosition = position2;
       }
     }
    int left = 0;
    int right = 0;
    if (rectangle)
     {
      int leftTop = topElement.elementView(this).pixelPosition(topPosition);
      int leftBottom = bottomElement.elementView(this).pixelPosition(bottomPosition);
      left = (leftTop < leftBottom)? leftTop : leftBottom;
      int rightTop = topElement.elementView(this).pixelCharPosition(topPosition+1) - 1;
      int rightBottom = bottomElement.elementView(this)
                                     .pixelCharPosition(bottomPosition+1) - 1;
      right = (rightBottom > rightTop)? rightBottom : rightTop;
     }
    Element lastElement = bottomElement.next();
    for (Element element = topElement;
         element != lastElement;
         element = element.next())
     {
      if (!element.show() && element.visible(this))
       {
        if (rectangle)
         {
          ElementView elementView = element.elementView(this);
          int leftPosition  = position(elementView, left);
          int rightPosition = position(elementView, right);
          changeCase(element, leftPosition, rightPosition - leftPosition + 1, upperCase);
         }
        else
         {
          if (element == topElement && element == bottomElement)
           {
            int len = bottomPosition - topPosition;
            changeCase(element, topPosition, len, upperCase);
           }
          else if (element == topElement)
           {
            changeCase(element, topPosition, upperCase);
           }
          else if (element == bottomElement)
           {
            int len = bottomPosition - 1;
            changeCase(element, 1, len, upperCase);
           }
          else
           {
            changeCase(element, upperCase);
           }
         }
       }
     }
   }
 }

 void fill(Element element, String fillString)
 {
  fill(element, 1, fillString);
 }

 void fill(Element element, int position, String fillString)
 {
  if (element != null)
   {
    fill(element, position, element.end() - position, fillString);
   }
 }

 void fill(Element element, int position, int len, String fillString)
 {
  int fillLen = (fillString != null)? fillString.length() : 0;

  if (fillLen > 0 && len > 0 && element != null &&
      !markList().protect(element) &&
      (element.show() || changeAllowed()))
   {
    String text = element.text();
    StringBuffer buffer = new StringBuffer(text);

    // pad from end of element to the fill start position if needed
    int oldLength = buffer.length();
    if (oldLength < position + len - 1)
     {
      buffer.setLength(position + len - 1);
      for (int i = oldLength; i < position - 1; i++)
       {
        buffer.setCharAt(i, ' ');
       }
     }

    int j = 0; // index into fillString
    for (int i = position - 1; i < position + len - 1; i++)
     {
      buffer.setCharAt(i, fillString.charAt(j++));
      if (j >= fillLen)
       {
        j = 0;
       }
     }

    _document.undo().recordChange(this, element, position);
    element.setText(this, buffer.toString());
   }
 }

 void shift(int count)
 {
  shift(documentPosition().element(), count);
 }

 void shift(Element element, int count)
 {
  shift(element, 1, count, true);
 }

 void shift(Element element, int count, boolean truncate)
 {
  shift(element, 1, count, truncate);
 }

 void shift(Element element, int position, int count)
 {
  shift(element, position, count, true);
 }

 void shift(Element element, int position, int count, boolean truncate)
 {
  if (element != null && count != 0 && element.length() >= position &&
      !markList().protect(element) && (element.show() || changeAllowed()))
   {
    if (count > 0)
     {
      StringBuffer buffer = new StringBuffer();
      buffer.setLength(count);
      for (int i = 0; i < count; i++)
       {
        buffer.setCharAt(i, ' ');
       }
      insertText(element, position, buffer.toString());
     }
    else
     {
      count = -count;
      if (!truncate)
       {
        String text = element.text();
        int spacesAtPosition = 0;
        int i;
        for (i = position - 2; i > 0; i--)
         {
          if (text.charAt(i) == ' ')
           {
            spacesAtPosition++;
           }
          else
           {
            break;
           }
         }
        if (i <= 0)
         {
          for (i = position - 1; i < text.length(); i++)
           {
            if (text.charAt(i) == ' ')
             {
              spacesAtPosition++;
             }
            else
             {
              break;
             }
           }
         }
        if (spacesAtPosition < count)
         {
          count = spacesAtPosition;
         }
       }
      position -= count;
      if (position <= 0)
       {
        position = 1;
       }
      deleteText(element, position, count);
     }
   }
 }

 /**
  * Trim any trailing blanks in the text of an element during save.
  */
 private void trim(Element element)
 {
  if (element != null)
   {
    int len = element.length();
    if (len > 0)
     {
      // get length of element's text trimmed of trailing blanks
      int trimmedLength = len;
      String text = element.text();
      for (int i = trimmedLength - 1; i >= 0 && text.charAt(i) == ' '; i--)
       {
        trimmedLength--;
       }

      if (len > trimmedLength)
       {
        setIgnoreFields();
        deleteText(element,               // element
                   trimmedLength + 1,     // position
                   len - trimmedLength,   // number of characters to delete
                   false,                 // don't do it if readonly / element is protected
                   false);                // do NOT maintain the sequence-numbers text part
        resetIgnoreFields();
       }
     }
   }
 }

 void insertPrefixText(String insertText)
 {
  Element element = documentPosition().element();
  if (element != null && insertText != null && insertText.length() > 0)
   {
    int position = documentPosition().prefixPosition();
    ElementView elementView = element.elementView(this);
    String prefixText = elementView.prefixText();
    if (prefixText == null)
     {
      prefixText = "";
     }
    if (position > prefixText.length() + 1)
     {
      position = prefixText.length() + 1;
     }
    prefixText = prefixText.substring(0, position - 1) + insertText +
                 prefixText.substring(position - 1);
    elementView.setPrefixText(prefixText);
    documentPosition().prefixTextInserted(element, position, insertText.length());
   }
 }

 void replacePrefixText(String replaceText)
 {
  Element element = documentPosition().element();
  if (element != null && replaceText.length() > 0)
   {
    deletePrefixText(replaceText.length());
    insertPrefixText(replaceText);
   }
 }

 void deletePrefixText()
 {
  deletePrefixText(1);
 }

 void deletePrefixText(int len)
 {
  Element element = documentPosition().element();
  if (element != null && len > 0)
   {
    ElementView elementView = element.elementView(this);
    String prefixText = elementView.prefixText();
    int position = documentPosition().prefixPosition();
    if (prefixText != null && position <= prefixText.length())
     {
      if (position + len - 1 > prefixText.length())
       {
        len = prefixText.length() - (position - 1);
       }
      prefixText = prefixText.substring(0, position - 1) +
                   prefixText.substring(position + len - 1);
      elementView.setPrefixText(prefixText);
      documentPosition().prefixTextDeleted(element, position, len);
     }
   }
 }

 void deleteElement(Element element)
  {
   if (element != null &&
       !markList().protect(element) && (element.show() || changeAllowed()))
    {
     Element prev = element.prev();
     Element next = element.next();
     _document.undo().recordDelete(this, element);
     _document.elementList().remove(element);
     _document.undo().recordPosition((prev != null)? prev : next, 1);
    }
  }

 void insertElement(Element element)
  {
   if (element != null &&
       !markList().insertElementProtect(documentPosition().element()) &&
       (element.show() || changeAllowed()))
    {
     _document.undo().recordInsert(this, element);
     _document.elementList().addAfter(this, documentPosition().element(), element);
     _document.undo().recordPosition(element, element.end());
     documentPosition().jump(element, element.end());
    }
  }

 void insertElementBefore(Element element)
  {
   if (element != null &&
       !markList().insertElementBeforeProtect(documentPosition().element()) &&
       (element.show() || changeAllowed()))
    {
     _document.undo().recordInsert(this, element);
     _document.elementList().addBefore(this, documentPosition().element(), element);
     _document.undo().recordPosition(element, element.end());
     documentPosition().jump(element, element.end());
    }
  }

 void joinElements(Element element1, Element element2)
  {
   if (element1 != null && element2 != null &&
       !markList().protect(element1) && !markList().protect(element2) &&
       !element1.show() && !element2.show() && changeAllowed())
    {
     _document.resetUserActionElements();

     markList().joinElements(element1, element2);
     markList().setIgnoreChanges(true);
     documentPosition().joinElements(element1, element2);
     documentPosition().setIgnoreChanges(true);

     _document.resetUserActionElements();

     String text = element2.text();
     int position = element1.end();
     setIgnoreFields();
     insertText(element1, position, text);
     resetIgnoreFields();
     deleteElement(element2);
     _document.undo().recordPosition(element1, position);

     documentPosition().setIgnoreChanges(false);
     markList().setIgnoreChanges(false);
    }
  }

 void splitElement()
  {
   Element element = documentPosition().element();
   if (element != null && !markList().insertElementProtect(element) && changeAllowed())
    {
     boolean realSplit = !element.show() && !markList().protect(element);
     if (!realSplit)
      {
       documentPosition().end();
      }
     int position = documentPosition().position();

     _document.resetUserActionElements();

     markList().setIgnoreChanges(true);
     documentPosition().setIgnoreChanges(true);

     Element newElement = new Element(_document);
     String text = element.text();
     if (text.length() >= position)
      {
       newElement.setText(this, text.substring(position - 1));
       setIgnoreFields();
       deleteText(element, position, text.length() - position + 1);
       resetIgnoreFields();
      }
     insertElement(newElement);
     if (realSplit)
      {
       _document.undo().recordPosition(element, position);
      }
     else
      {
       _document.undo().recordPosition(newElement, 1);
      }

     documentPosition().setIgnoreChanges(false);
     documentPosition().splitElement(element, position);
     markList().setIgnoreChanges(false);
     markList().splitElement(element, position);
    }
  }

 void overlayRectangle(String overlayText)
  {
   overlayRectangle(overlayText, false);
  }

 void overlayRectangle(String overlayText, boolean transparent)
  {
   if (overlayText.length() <= 0)
    {
     return;
    }
   Element element = documentPosition().element();
   if ((element != null && (element.show() || markList().protect(element))) ||
       !changeAllowed())
    {
     return;
    }
   _document.resetUserActionElements();
   if (element == null)
    {
     element = new Element(document());
     insertElement(element);
    }
   int pixelPosition = element.elementView(this)
                              .pixelPosition(documentPosition().position());
   int indexOfLineSeparator = overlayText.indexOf('\n');
   while (indexOfLineSeparator >= 0)
    {
     replaceText(overlayText.substring(0, indexOfLineSeparator), transparent);
     overlayText = overlayText.substring(indexOfLineSeparator + 1);
     Element next = element.nextVisibleNonShow(this);
     if (next != null && !markList().protect(next))
      {
       element = next;
      }
     else
      {
       Element newElement = new Element(document());
       insertElement(newElement);
       element = newElement;
      }
     documentPosition().jump(element, position(element.elementView(this), pixelPosition));
     indexOfLineSeparator = overlayText.indexOf('\n');
    }
   replaceText(overlayText, transparent);
  }

 void overlayElements(String overlayText)
  {
   overlayElements(overlayText, false);
  }

 void overlayElements(String overlayText, boolean transparent)
  {
   Element element = documentPosition().element();
   if (element == null || element.show() ||
       markList().protect(element) || !changeAllowed())
    {
     return;
    }
   _document.resetUserActionElements();
   if (overlayText == null)
    {
     overlayText = "";
    }

   setIgnoreFields();
   documentPosition().home();
   int indexOfLineSeparator = overlayText.indexOf('\n');
   while (indexOfLineSeparator >= 0)
    {
     String elementOverlayText = overlayText.substring(0, indexOfLineSeparator);
     overlayText = overlayText.substring(indexOfLineSeparator + 1);
     if (transparent)
      {
       replaceText(elementOverlayText, true);
      }
     else
      {
       deleteText(element.length());
       insertText(elementOverlayText);
      }
     Element next = element.nextVisibleNonShow(this);
     if (next != null && !markList().protect(next))
      {
       element = next;
      }
     else
      {
       element = new Element(document());
       insertElement(element);
      }
     documentPosition().jump(element, 1);
     indexOfLineSeparator = overlayText.indexOf('\n');
    }
   if (transparent)
    {
     replaceText(overlayText, true);
    }
   else
    {
     deleteText(element.length());
     insertText(overlayText);
    }
   resetIgnoreFields();
  }

 String delete(int count)
  {
   String deleteText = "";
   if (changeAllowed() && !tryToDeleteStreamBlock())
    {
     for (int i = 0; i < count; i++)
      {
       Element element = documentPosition().element();
       int position = documentPosition().position();
       if (element != null && !element.show() && !markList().protect(element))
        {
         if (position <= element.length())
          {
           deleteText += deleteText(element, position);
          }
         else
          {
           Element nextElement = element.nextVisibleNonShow(this);
           if (nextElement != null && !nextElement.show() &&
               !markList().protect(nextElement))
            {
             padTextTo(element, position);
             joinElements(element, nextElement);
             deleteText += "\n";
            }
          }
        }
      }
    }
   return deleteText;
  }

 String backSpace(int count)
  {
   String deleteText = "";
   if (changeAllowed() && !tryToDeleteStreamBlock())
    {
     for (int i = 0; i < count; i++)
      {
       Element element = documentPosition().element();
       int position = documentPosition().position();
       if (element != null && !element.show() && !markList().protect(element))
        {
         if (position > 1)
          {
           documentPosition().left();
           deleteText = deleteText(element, documentPosition().position(), 1) +
                        deleteText;
          }
         else
          {
           Element prevElement = element.prevVisibleNonShow(this);
           if (prevElement != null)
            {
             joinElements(prevElement, element);
             deleteText = "\n" + deleteText;
            }
          }
        }
      }
    }
   return deleteText;
  }

 void selectCharacter(int count, boolean next)
  {
   Element element = documentPosition().element();
   if (element != null)
    {
     if (Block.type() == Block.ELEMENT || Block.view() != this)
      {
       Block.clear();
      }
     if (Block.type() == Block.NONE &&
         BlockCommand.DefaultTypeParameter.getParameter().currentValue(this) ==
           Block.ELEMENT)
      {
       Block.set(Block.STREAM, this);
      }
     else
      {
       Block.set(this);
      }

     for (int i = 0; i < count; i++)
      {
       element = documentPosition().element();
       int position = documentPosition().position();
       if (!next) // "Shift+<="
        {
         if (Block.type() == Block.RECTANGLE || position > 1)
          {
           documentPosition().left();
          }
         else
          {
           // if position==1 (Block.type() != BLOCK_RECTANGLE) we may still want
           // to do a left():  it ensures that when the cursor is at its leftest
           // possible and there are sequence numbers still
           // scrolled left outside the view, they are revealed [first, before
           // going up & to the end of that line]...  But then there are too
           // many 'jumps' with seq nums in & out of the screen if the user
           // goes continually "Shift+<="ing through previous lines...

           documentPosition().up();
           if (documentPosition().element() != element)
            {
             documentPosition().end();
            }
          }
        }
       else // "Shift+=>"
        {
         if (Block.type() == Block.RECTANGLE || position < element.end())
          {
           documentPosition().right();
          }
         else
          {
           documentPosition().down();
           if (documentPosition().element() != element)
            {
             documentPosition().home();
            }
          }
        }
       Block.set(this);
      }
    }
  }

 void selectWord(int count, boolean next)
  {
   Element element = documentPosition().element();
   if (element != null)
    {
     if (Block.type() == Block.ELEMENT || Block.view() != this)
      {
       Block.clear();
      }
     if (Block.type() == Block.NONE &&
         BlockCommand.DefaultTypeParameter.getParameter().currentValue(this) ==
           Block.ELEMENT)
      {
       Block.set(Block.STREAM, this);
      }
     else
      {
       Block.set(this);
      }
     for (int i = 0; i < count; i++)
      {
       element = documentPosition().element();
       int position = documentPosition().position();
       Element anchorElement = Block.anchorElement();
       int anchorPosition = Block.anchorPosition();
       if (next)
        {
         boolean belowAnchor = Block.anchorAtTop();
         if (anchorElement == element && anchorPosition == position)
          {
           belowAnchor = true;
          }
         if (belowAnchor)
          {
           if (Block.type() == Block.STREAM)
            {
             documentPosition().nextWordEnd(1);
            }
           else
            {
             documentPosition().nextWordEnd();
            }
           Block.set(this);
          }
         else
          {
           documentPosition().nextWord();
           if (Block.anchorAtTop() ||
               (anchorElement == documentPosition().element() &&
                anchorPosition == documentPosition().position()))
            {
             documentPosition().jump(anchorElement, anchorPosition);
             Block.set(this);
            }
           Block.set(this);
          }
        }
       else
        {
         boolean aboveAnchor = !Block.anchorAtTop();
         if (anchorElement == element && anchorPosition == position)
          {
           aboveAnchor = true;
          }
         if (aboveAnchor)
          {
           documentPosition().prevWord();
           Block.set(this);
          }
         else
          {
           if (Block.type() == Block.STREAM)
            {
             documentPosition().prevWordEnd(1);
            }
           else
            {
             documentPosition().prevWordEnd();
            }
           Block.set(this);
           if (!Block.anchorAtTop() ||
               (element == documentPosition().element() &&
                position == documentPosition().position()))
            {
             documentPosition().jump(anchorElement, anchorPosition);
             Block.set(this);
            }
          }
        }
      }
    }
  }

 /**
  * @see #beginUserAction(int)
  */
 void beginUserAction()
  {
   beginUserAction(ACTION_INVALID);
  }

 /**
  * Called before running a user action.
  */
 void beginUserAction(int actionId)
  {
   // end any previous user action
   endUserAction();

   _userActionElement = documentPosition().element();

   _screen.resetNewMessage();
   _actionHandler.setUserActionId(actionId);
  }

 /**
  * Called after running a user action.
  */
 void endUserAction()
  {
   if (_userActionElement == null ||
       _userActionElement != documentPosition().element())
    {
     // ensure we still have at least one text element
     if (_document.elementList().count() == 0)
      {
       insertElement(new Element(_document));
      }

     _document.resetUserActionElements();
     _document.parse();

     if (_autoCheck)
      {
       _document.undo().check(this);
      }

     if (!_screen.newMessage())
      {
       _screen.setMessageText(null);
      }
    }
  }

 void resetUserActionElement()
  {
   if (_userActionElement != null)
    {
     _userActionElement = null;
     if (_autoCheck)
      {
       _document.undo().check(this);
      }
    }
  }

 void verifyUserActionElement(Element element)
  {
   if (_userActionElement != null && element != _userActionElement)
    {
     _document.resetUserActionElements();
    }
  }

 // Element userActionElement()
 //  {
 //   return _userActionElement;
 //  }

 void get(String fileName)
  {
   CommandHandler._status = null;
   Element element = documentPosition().element();
   if (element == null)
    {
     return;
    }
   boolean first = true;
   if (element.show())
    {
     if (markList().insertElementProtect(element))
      {
       return;
      }
     first = false;
    }
   else if (markList().protect(element))
    {
     return;
    }
   if (!changeAllowed())
    {
     return;
    }
   boolean forceAllVisible = forceAllVisible();
   setForceAllVisible(true);
   setIgnoreFields();
   try
    {
     _document.resetUserActionElements();
     FileReader fileReader = new FileReader(fileName);
     BufferedReader bufferedReader = new BufferedReader(fileReader);
     for (;;)
      {
       String text = bufferedReader.readLine();
       if (text == null)
        {
         break;
        }
       if (!first)
        {
         insertText("\n");
        }
       first = false;
       insertText(text);
      }
     bufferedReader.close();
    }
   catch(FileNotFoundException e)
    {
     setLpexMessageText(MSG_FILE_NOT_FOUND, fileName);
     CommandHandler._status = STATUS_FILE_NOTFOUND;
    }
   catch(IOException e)
    {
     setLpexMessageText(MSG_FILE_ERROR_READING, fileName);
     CommandHandler._status = STATUS_FILE_ERRORREADING;
    }
   resetIgnoreFields();
   setForceAllVisible(forceAllVisible);
  }

 void setSaveWriter(Writer writer)
  {
   _saveWriter = writer;
  }

 Writer getSaveWriter()
  {
   return _saveWriter;
  }

 /**
  * The save line separator facilitates the saving of a file in a certain
  * line-delimiter standard (Windows/UNIX), different from the platform's
  * default line separator.  If not given, the platform's default is used.
  * This allows, for example, the editing of UNIX files on Windows.  LPEX
  * does not record the original line delimiters when a file is loaded in.
  */
 void setSaveLineSeparator(String eol)
  {
   _saveEol = eol;
  }

 void save(String fileName, boolean visible, boolean trim, int textLimit)
  {
   save(null, fileName, visible, trim, textLimit);
  }

 /**
  * Save document to <code>writer</code>, if one provided, or else to
  * <code>fileName</code>.  Use the save line separator, if one provided,
  * otherwise use the platform's default one (via the BufferedWriter.newLine()
  * method).
  *
  * <p>An untitled document is assigned the name of the saved file.
  * If <code>fileName</code> is null or empty, the document name is used;
  * however, no save takes place if the document is untitled.
  * On a saveAs operation the textLimit and trim arguments are ignored,
  * there are no 'saving' and 'saved' notifications issued, the changes
  * parameter is not cleared.
  * No trimming is done when only visible elements are saved.
  *
  * @param visible true = save only the visible elements;  show lines are saved
  *                       as well
  */
 void save(Writer writer, String fileName, boolean visible, boolean trim, int textLimit)
  {
   try
    {
     if (fileName == null || fileName.trim().length() == 0)
      {
       fileName = document().name();
      }
     if (fileName == null)
      {
       setLpexMessageText(MSG_FILE_SAVE_NONAME);
       return;
      }

     File file = new File(fileName);
     try
      {
       fileName = file.getCanonicalPath();
      }
     catch(IOException e)
      {
       setLpexMessageText(MSG_FILE_ERROR_WRITING, fileName);
       CommandHandler._status = STATUS_SAVE_FAILED;
       return;
      }
     if (document().name() == null)
      {
       document().setName(fileName);
      }
     boolean saveas = !fileName.equals(document().name());

     // on a real save, issue saving notification; don't go on if asked to abort
     if (!saveas && _viewListenerList.saving())
      {
       return;
      }

     Element truncatedElement = null;

     // if no writer given, assume we write to the file itself.
     // FileWriter - Convenience class for writing character files.  The
     //   constructors of this class assume that the default character encoding
     //   and the default byte-buffer size are acceptable.  To specify these
     //   values yourself, construct an OutputStreamWriter on a FileOutputStream.
     BufferedWriter bufferedWriter =
        new BufferedWriter((writer != null)? writer : new FileWriter(fileName));

     //boolean first = true;
     boolean useSourceColumns = _nls.useSourceColumns();
     String eol = _saveEol;

     /*==============================*/
     /*  for all the elements . . .  */
     /*==============================*/
     for (Element element = document().elementList().first();
          element != null;
          element = element.next())
      {
       if ((!visible && !element.show()) ||     // save all & not a SHOW line  OR
           (visible && element.visible(this)))  // save visibles only & is visible line
        {                                       //   (including SHOW)
         // NOTE 1:
         // Used to *pre*pend <eol> to lines > 1st, like C++ LPEX does now...
         // However, in order to avoid the problems C++ LPEX now has doing
         // this (need for -nfs flags, adding last 'dummy' element when reading
         // a file ending in <eol>, etc.), trying to emulate workstation editors
         // while still OK for host files brought over locally by e.g., NFS,
         // and in order to avoid changing the reading of a file (to see if it
         // ends in <eol> - currently not done, and because of this 'eating up'
         // empty lines at the end of the file;  *how* to do that at all would
         // also be a good question: use RandomAccessFile class??), so we'll
         // just add <eol> after every line we save...
         // THIS implementation still has a few 'difficulties', but they are,
         // I think, easier to live with:  extra <eol> added to files which
         // do not end in one in the first place;  cannot cursor to the last
         // 'dummy' element (i.e., the <eol>) of a file (like, e.g., Notepad
         // does)...
         //if (!first) {
         // if (eol == null) bufferedWriter.newLine();
         // else bufferedWriter.write(eol, 0, eol.length());
         // }
         if (trim && !saveas && !visible)
          {
           trim(element);
          }

         // if save visibles only, use display text (untrimmed, expanded tabs, etc.)
         String text = visible? element.elementView(this).displayNetText() :
                                element.fullText();

         if (text != null)
          {
           // length of the text to bufferedWriter.write()
           int textLength = text.length();
           // & its length as saved [on host, after encoding conversion]
           int saveLength = useSourceColumns? _nls.sourceLength(text) :
                                              textLength;
           if (!saveas && !visible && textLimit != 0 && saveLength > textLimit)
            {
             textLength = useSourceColumns? _nls.sourceTruncate(text, textLimit) :
                                            textLimit;
             if (truncatedElement == null)
              {
               truncatedElement = element;
              }
            }
           if (textLength != 0)
            {
             bufferedWriter.write(text, 0, textLength);
            }
          }

         // write the line separator - see NOTE 1 above...
         if (eol == null)
          {
           bufferedWriter.newLine();
          }
         else
          {
           bufferedWriter.write(eol, 0, eol.length());
          }
         //first = false;
        }
      }//end "for"

     bufferedWriter.close();
     if (truncatedElement != null)
      {
       setLpexMessageText(MSG_FILE_SAVE_TRUNCATION);
       documentPosition().jump(truncatedElement, 1);
      }
     if (!saveas)
      {
       _viewListenerList.saved();
      }
     if (!saveas && !visible)
      {
       document().undo().resetChanges(this);
      }
    }
   catch(IOException e)
    {
     setLpexMessageText(MSG_FILE_ERROR_WRITING, fileName);
     CommandHandler._status = STATUS_SAVE_FAILED;
    }
  }

 /**
  * Save document as HTML to <code>fileName</code>.
  * This is a variant of save() above.
  *
  * <p>If <code>fileName</code> is null or empty, the document name is used,
  * suffixed with ".html".  An untitled document is not assigned the name
  * of the saved file.  When saving the file as HTML, like in a saveAs
  * operation, the textLimit and trim arguments are ignored, there are no
  * 'saving' and 'saved' notifications issued, and the changes parameter is
  * not cleared.
  *
  * <p>This method uses <b><code>dtd html 4.0 transitional</code></b> for
  * tagging the HTML file.  Individual token background color, if different from
  * the default style's background color in the active palette, cannot be coded.
  *
  * @param visible true = only the visible elements should be saved;  show lines
  *                       are saved as well
  * @param block true = save only selected text
  * @param lineNumbers true = save line numbers to the left of each line
  */
 void saveAsHtml(String fileName, boolean visible, boolean block,
                 boolean lineNumbers)
  {
   int lineNumberWidth = 0;
   try
    {
     // establish file name & HTML page title
     if (fileName == null || fileName.trim().length() == 0)
      {
       fileName = document().name();
       if (fileName == null)
        {
         fileName = LpexResources.message(MSG_UNTITLED_DOCUMENT, document().id());
        }
       fileName += ".html";
      }

     File file = new File(fileName);
     try
      {
       fileName = file.getCanonicalPath();
      }
     catch(IOException e)
      {
       setLpexMessageText(MSG_FILE_ERROR_WRITING, fileName);
       CommandHandler._status = STATUS_SAVE_FAILED;
       return;
      }

     String title = file.getName();
     if (title.endsWith(".html"))
        title = title.substring(0, title.length()-5);
     else if (title.endsWith(".htm"))
        title = title.substring(0, title.length()-4);

     BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(fileName));
     String eol = _saveEol;

     // establish the start & end elements to save
     ElementList elementList = document().elementList();
     int startElement = 1;
     int endElement = elementList.count();
     if (block && Block.view() == this)
      {
       Element topElement = Block.topElement();
       if (topElement != null)
        {
         startElement = elementList.ordinalOf(topElement);
        }
       Element bottomElement = Block.bottomElement();
       if (bottomElement != null)
        {
         endElement = elementList.ordinalOf(bottomElement);
        }
      }
     Element stopElement = elementList.elementAt(endElement);
     if (stopElement != null)
      {
       stopElement = stopElement.next();
      }

     // width of line-numbers to fit longest (cf. PrintCommand.java/doCommand())
     if (lineNumbers)
      {
       lineNumberWidth = Math.max(String.valueOf(endElement).length(), 2);
      }

     StyleAttributes defaultStyle    = _screen.styleAttributes(Screen.STYLE_DEFAULT);
     StyleAttributes lineNumberStyle = _screen.styleAttributes(Screen.STYLE_PREFIX_AREA);

     /*==================*/
     /*  do HTML header  */
     /*==================*/
     bufferedWriter.write("<!doctype html public \"-//w3c//dtd html 4.0 transitional//en\">");
     if (eol == null)
      {
       bufferedWriter.newLine();
      }
     else
      {
       bufferedWriter.write(eol, 0, eol.length());
      }

     bufferedWriter.write("<html><head><title>"+title+
                          "</title></head><body bgcolor=\"#");
     bufferedWriter.write(getRGBAsHtml(defaultStyle.backgroundColor()));
     bufferedWriter.write("\"><pre>");

     if (eol == null)
      {
       bufferedWriter.newLine();
      }
     else
      {
       bufferedWriter.write(eol, 0, eol.length());
      }

     /*==============================*/
     /*  for all the elements . . .  */
     /*==============================*/
     String text = null;
     for (Element e = elementList.elementAt(startElement);
          e != stopElement;
          e = e.next())
      {
       if ((!visible && !e.show()) || (visible && e.visible(this)))
        {
         // element's line number
         if (lineNumbers)
          {
           saveTokenAsHtml(bufferedWriter, lineNumberStyle,
                           lineNumberText(e, lineNumberWidth));
           //saveTokenAsHtml(bufferedWriter, defaultStyle, " ");
           bufferedWriter.write(' ');
          }

         // element's text
         text = e.elementView(this).displayText().text();
         if (text != null)
          {
           int textLength = text.length();
           ElementView elementView = e.elementView(this);
           String style = (elementView != null)? elementView.displayStyle() : null;
           if (style == null)
            {
             style = "";
            }
           int len = (style.length() > text.length())?
                      style.length() : text.length();
           int i = 0;
           // build up the text line from its token subtexts
           while (i < len)
            {
             StyleAttributes styleAttributes = null;
             if (style.length() > i)
              {
               styleAttributes = _styleAttributesList.find(style.charAt(i));
              }
             if (styleAttributes == null)
              {
               styleAttributes = defaultStyle;
              }

             // establish extent of a token
             int subTextLength = 1; // one char so far
             while (i + subTextLength < len)
              {
               StyleAttributes styleAttributesNext = null;
               if (style.length() > i + subTextLength)
                {
                 styleAttributesNext = _styleAttributesList.find(style.charAt(i + subTextLength));
                }
               if (styleAttributesNext == null)
                {
                 styleAttributesNext = defaultStyle;
                }
               if (!styleAttributes.equals(styleAttributesNext))
                {
                 break;
                }
               subTextLength++;
              }//end "while" token

             String subText;
             if (i + subTextLength <= textLength)
              {
               subText = text.substring(i, i + subTextLength);
              }
             else
              {
               if (i < textLength)
                {
                 subText = text.substring(i);
                }
               else
                {
                 subText = "";
                }
               StringBuffer buffer = new StringBuffer(subText);
               int originalLength = buffer.length();
               buffer.setLength(len);
               for (int j = originalLength; j < len; j++)
                {
                 buffer.setCharAt(j, ' ');
                }
               subText = buffer.toString();
              }

             // we are setting the bgcolor for the entire HTML panel body to be
             // the active palette's defaultStyle's background color - ensure
             // that some visible color is used (for tokens which may use a
             // background color different from the default style's, like the
             // error token usually does - as we cannot tag in this HTML version
             // the background color of individual tokens...)
             // [if we used <body bgcolor="#ffffff">, then we'd check against white:
             //  if (styleAttributes.foregroundColor().isWhite())]
             if (styleAttributes.foregroundColor().equals(defaultStyle.backgroundColor()))
              {
               styleAttributes = defaultStyle;
              }
             saveTokenAsHtml(bufferedWriter, styleAttributes, subText);

             i += subTextLength;
            }//end "while" line
          }

         if (eol == null)
          {
           bufferedWriter.newLine();
          }
         else
          {
           bufferedWriter.write(eol, 0, eol.length());
          }
        }
      }//end "for"

     /*===================*/
     /*  do HTML trailer  */
     /*===================*/
     bufferedWriter.write("</pre></body></html>");
     bufferedWriter.close();
    }

   catch(IOException e)
    {
     setLpexMessageText(MSG_FILE_ERROR_WRITING, fileName);
     CommandHandler._status = STATUS_SAVE_FAILED;
    }
  }

 /**
  * Write out one token <code>text</code> in the given
  * <code>styleAttributes</code>.
  */
 private static void saveTokenAsHtml(BufferedWriter bufferedWriter,
                                     StyleAttributes styleAttributes,
                                     String text) throws java.io.IOException
  {
   StringBuffer sb = new StringBuffer(48);

   sb.append("<font color=\"#");
   sb.append(getRGBAsHtml(styleAttributes.foregroundColor()));
   sb.append("\">");
   if (styleAttributes.underline())
      sb.append("<u>");

   // save text, replacing undesirable characters
   for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);
      if (c == '<')
         sb.append("&lt;");
      else if (c == '&')
         sb.append("&amp;");
      else
         sb.append(c);
      }

   if (styleAttributes.underline())
      sb.append("</u>");
   sb.append("</font>");

   bufferedWriter.write(sb.toString());
  }

 private static String getRGBAsHtml(Color c)
  {
   StringBuffer rgb = new StringBuffer(8);
   int i = c.getRed();
   if (i < 16)
      rgb.append('0');
   rgb.append(Integer.toHexString(i));
   i = c.getGreen();
   if (i < 16)
      rgb.append('0');
   rgb.append(Integer.toHexString(i));
   i = c.getBlue();
   if (i < 16)
      rgb.append('0');
   rgb.append(Integer.toHexString(i));
   return rgb.toString();
  }

 /**
  * Return the line number inside the (complete) document, as a String padded
  * with leading blanks to n positions.
  */
 private String lineNumberText(Element e, int n)
 {
  StringBuffer lineNumberText =
     new StringBuffer(String.valueOf(e.nonShowOrdinal() + document().linesBeforeStart()));

  while (lineNumberText.length() < n)
   {
    lineNumberText.insert(0, ' ');
   }

  return lineNumberText.toString();
 }

 ParsePendingList parsePendingList()
  {
   return _parsePendingList;
  }

 StyleAttributesList styleAttributesList()
  {
   return _styleAttributesList;
  }

 /**
  * Re-set <b>includedClasses</b> for the elements in this view.
  */
 void setIncludedClasses(long includedClasses)
  {
   // when a new filtered view is set (e.g., action "showAll", or command
   // "findText all", or Java parser's "Ctrl+G" to show methods only), drop
   // all the excluded-text settings for the elements in this view
   clearClasses(Classes.EXCLUDE_TEXT);

   // recalculate visibility of the elements for this view
   setVisibleElementOrdinalsInvalid();
   setMaxElementWidthInvalid();
   setMaxPrefixAreaWidthInvalid();
   expandAll(false);

   _includedClasses = includedClasses;
  }

 long includedClasses()
  {
   return _includedClasses;
  }

 /**
  * Re-set <b>excludedClasses</b> for the elements in this view.
  */
 void setExcludedClasses(long excludedClasses)
  {
   // if the new filtered view set here no longer includes the progressive exclusion
   // of elements, drop all the excluded-text settings for the elements in this view
   if ((_excludedClasses & Classes.EXCLUDE_TEXT) != 0 &&
       (excludedClasses & Classes.EXCLUDE_TEXT) == 0)
    {
     clearClasses(Classes.EXCLUDE_TEXT);
    }

   // recalculate visibility of the elements for this view
   setVisibleElementOrdinalsInvalid();
   setMaxElementWidthInvalid();
   setMaxPrefixAreaWidthInvalid();
   expandAll(false);

   _excludedClasses = excludedClasses;
  }

 long excludedClasses()
  {
   return _excludedClasses;
  }

 /**
  * Clear all elements' Classes.FIND_TEXT and/or EXCLUDE_TEXT for this view.
  * Any change in the visibility of the affected elements is also handled.
  */
 private void clearTextClasses(long textClasses)
  {
   for (Element element = document().elementList().first();
        element != null;
        element = element.next())
    {
     element.elementView(this).clearTextClasses(textClasses);
    }
  }

 /**
  * Clear the specified element class(es) in all the elements for this view.
  * Any resulting changes in visibility are <b>not</b> handled here.
  */
 private void clearClasses(long clearClasses)
  {
   for (Element element = document().elementList().first();
        element != null;
        element = element.next())
    {
     element.elementView(this).clearClasses(clearClasses);
    }
  }

 /**
  * Find text in this view.
  *
  * @return true = text was found [and replaced]
  */
 boolean findText(FindTextOptions options)
  {
   if (options._replace && !changeAllowed())
    {
     CommandHandler._status = STATUS_FINDTEXT_READONLY;
     return false;
    }

   /*=================================*/
   /*  resolve any options conflicts  */
   /*=================================*/
   if (options._all)
    {
     options._up = false;
    }
   // NB "exclude" is only effective with "all"

   /*==================================================================*/
   /*  initialize find per options - starting element, position, etc.  */
   /*==================================================================*/
   boolean startedInFindAll = (includedClasses() == Classes.FIND_TEXT);
   ElementList elementList = document().elementList();
   Element element = null;
   int position = 1;

   // (a) "findText [replace | exclude] all"
   if (options._all)
    {
     if (!options._exclude)
      {
       // the findText command only works with the visible elements;  if started
       // in a "findText all", first make all elements visible for re-processing;
       // the new visibility of the elements is necessary for this processing of
       // the findText command later below
       if (startedInFindAll)
        {
         setIncludedClasses(Classes.ALL);
        }

       // clear FIND_TEXT class from any previously-run "findText all" command;
       // EXCLUDE_TEXT taggings are also cleared from doc on a new "findText all"
       // (regardless of whether we started in a "findText all" or not);
       // the new visibility of the elements is necessary for this processing of
       // the findText command later below
       clearTextClasses(Classes.FIND_TEXT | Classes.EXCLUDE_TEXT);
      }

     element = elementList.first();
     if (element != null)
      {
       if (!element.visible(this) || element.show())
        {
         element = element.nextVisibleNonShow(this);
        }
      }
    }

   // (b) "findText [replace]" single occurrence
   else
    {
     element = documentPosition().element();
     if (element != null)
      {
       if (element.visible(this) && !element.show())
        {
         position = documentPosition().position();
        }
       else
        {
         if (options._up)
          {
           element = element.prevVisibleNonShow(this, options._wrap);
           position = element.end();
          }
         else
          {
           element = element.nextVisibleNonShow(this, options._wrap);
          }
        }
      }
    }

   Element startElement = element;
   int elementOrdinal = elementList.ordinalOf(element);
   int startPosition = position;

   /*===============*/
   /*  do the find  */
   /*===============*/
   CommandHandler._status = null;
   boolean found = false;
   boolean wrapped = false;
   boolean replaced = false;

   if (element != null && options._findText != null && options._findText.length() > 0)
    {
     /*---------------------------------*/
     /*  (a) "findText up" (backwards)  */
     /*---------------------------------*/
     if (options._up)
      {
       if (!options._checkStart)
        {
         position--;
        }

       for (;;)
        {
         position = findText(element, position, options);
         if (position > 0)
          {
           if (options._replace && !markList().protect(element))
            {
             deleteText(element, position, options._foundTextLength);
             if (options._replaceText != null && options._replaceText.length() != 0)
              {
               insertText(element, position, options._replaceText);
              }
             replaced = true;
            }
           documentPosition().jump(element, position);
           found = true;
           break;
          }
         element = element.prevVisible(this, options._wrap);
         if (element == null)
          {
           break;
          }
         int newElementOrdinal = elementList.ordinalOf(element);
         if (newElementOrdinal >= elementOrdinal)
          {
           if (wrapped)
            {
             break;
            }
           wrapped = true;
          }
         elementOrdinal = newElementOrdinal;
         position = element.end();
        }//end "for (;;)
      }

     /*----------------------------------*/
     /*  (b) "findText [[exclude] all]"  */
     /*----------------------------------*/
     else
      {
       if (!options._checkStart && !options._all)
        {
         position++;
        }

       for (;;)
        {
         position = findText(element, position, options);
         if (position > 0)
          {
           if (options._all)
            {
             if (options._exclude)
              {
               // "findText exclude all" - set Classes.EXCLUDE_TEXT in this element
               element.elementView(this).setTextClasses(Classes.EXCLUDE_TEXT);
              }
             else
              {
               // "findText all" - set Classes.FIND_TEXT in this element
               element.elementView(this).setTextClasses(Classes.FIND_TEXT);

               // "findText all replace" - replace *all* occurrences in this element
               // NB this may also affect the visibility characteristics of the
               // element (max. width, etc.)
               if (options._replace && !markList().protect(element))
                {
                 int elementPosition = position;
                 while (elementPosition > 0)
                  {
                   deleteText(element, elementPosition, options._foundTextLength);
                   if (options._replaceText != null && options._replaceText.length() != 0)
                    {
                     insertText(element, elementPosition, options._replaceText);
                     elementPosition += options._replaceText.length() - 1;
                    }
                   replaced = true;
                   elementPosition++;
                   elementPosition = findText(element, elementPosition, options);
                  }
                }
              }
            }

           else
            {
             if (options._replace && !markList().protect(element))
              {
               deleteText(element, position, options._foundTextLength);
               if (options._replaceText != null && options._replaceText.length() != 0)
                {
                 insertText(element, position, options._replaceText);
                }
               replaced = true;
              }
            }

           if (!found)
            {
             documentPosition().jump(element, position);
            }
           found = true;

           if (!options._all)
            {
             break;
            }
          }//end findText() position > 0

         element = element.nextVisible(this, options._wrap && !options._all);
         if (element == null)
          {
           break; // there are no more elements to search
          }

         int newElementOrdinal = elementList.ordinalOf(element);
         if (newElementOrdinal <= elementOrdinal)
          {
           if (wrapped)
            {
             break; // done, we've already wrapped once before...
            }
           wrapped = true;
          }
         elementOrdinal = newElementOrdinal;
         position = 1;
        }//end "for (;;)"
      }
    }

   // if it's a "findText all", filter view on FIND_TEXT class (only! - forget
   // about any previously-included classes, e.g. from a previous Ctrl+G);
   // but if it's a "findText replace all" operation (e.g., triggered by the
   // "Replace all" button in live find), don't filter the view unless it was
   // already filtered by "findText all" in the beginning
   if (options._all && !options._exclude &&
       (startedInFindAll || !options._replace))
    {
     // this now re-does all the visibility of the view - although our calls to
     // setTextClasses() took care of each element's visibility change, any replaces
     // may have caused further visibility-characteristics changes
     setIncludedClasses(Classes.FIND_TEXT);
    }

   // if it's a "findText exclude all", progressively remove all the
   // newly-found lines
   else if (options._all && options._exclude)
    {
     //-as- OPTIMIZE!?: this now re-does all the visibility of the view - although
     // our calls to setTextClasses() took care of each element's visibility change
     setExcludedClasses(excludedClasses() | Classes.EXCLUDE_TEXT);
    }

   /*----------------------*/
   /*  (a) text not found  */
   /*----------------------*/
   if (!found)
    {
     CommandHandler._status = STATUS_FINDTEXT_NOTFOUND;
     if (!options._quiet)
      {
       setLpexMessageText(MSG_FINDTEXTCOMMAND_NOTFOUND, options._findText);
       if (!options._noBeep)
        {
         BeepParameter.getParameter().setValue(true);
        }
      }
     if (options._emphasis)
      {
       documentPosition().setEmphasisLength(0);
      }
     if (options._mark)
      {
       Block.clear();
      }
    }

   /*------------------*/
   /*  (b) text found  */
   /*------------------*/
   else
    {
     if (!options._quiet)
      {
       _screen.setMessageText(null);
      }

     if (!options._all)
      {
       if (wrapped)
        {
         if (element == startElement && position == startPosition)
          {
           CommandHandler._status = STATUS_FINDTEXT_ONLYOCCURRENCE;
           if (!options._quiet)
            {
             setLpexMessageText(MSG_FINDTEXTCOMMAND_ONLYOCCURRENCE);
             if (!options._noBeep)
              {
               BeepParameter.getParameter().setValue(true);
              }
            }
          }
         else
          {
           CommandHandler._status = STATUS_FINDTEXT_WRAPPED;
           if (!options._quiet)
            {
             setLpexMessageText(MSG_FINDTEXTCOMMAND_WRAPPED);
             if (!options._noBeep)
              {
               BeepParameter.getParameter().setValue(true);
              }
            }
          }
        }
      }

     if (options._exclude)
      {
       return found;
      }

     // select/emphasize found text, scroll to show as much of it as possible
     int emphasisLength;
     if (replaced)
      {
       emphasisLength = (options._replaceText != null)? options._replaceText.length() : 0;
      }
     else
      {
       emphasisLength = options._foundTextLength;
      }

     if (options._mark)                        // (1) must select the found text
      {
       Block.clear();
       documentPosition().setEmphasisLength(0);
       int currentBlockDefaultType =
           BlockCommand.DefaultTypeParameter.getParameter().currentValue(this);
       if (currentBlockDefaultType == Block.ELEMENT ||
           currentBlockDefaultType == Block.STREAM)
        {
         documentPosition().right(emphasisLength);
         Block.set(Block.STREAM, this);
         documentPosition().left(emphasisLength);
        }
       else
        {
         documentPosition().right(emphasisLength - 1);
         Block.set(this);
         documentPosition().left(emphasisLength - 1);
        }
       Block.set(this);
      }
     else                                      // (2) don't select found text
      {
       // we *found* some text, i.e., cursor moved:  if there is a stream
       // selection in this doc, clear the block (� la Block.validate())
       // (this needed for live find, when e.g., just toggling the "Select found
       // text" checkbox, with the cursor *staying* on same found piece of text)
       if (Block.type() == Block.STREAM && _document == Block.view().document())
        {
         Block.clear();
        }

       if (options._emphasis)
        {
         documentPosition().setEmphasisLength(emphasisLength);
        }
      }

     // try to show as much of the found / replaced text as possible
     if (options._all)
      {
       element = documentPosition().element();
       position = documentPosition().position();
      }
     ElementView elementView = element.elementView(this);
     screen().build();
     int scroll = screen().scroll();

     int scrollDelta = elementView.pixelPosition(position + emphasisLength) -
                       (scroll + screen().textAreaWidth());
     if (scrollDelta > 0)
      {
       // don't let the cursor position fall below the left margin of the screen
       int startPixelPosition = elementView.pixelPosition(position);
       if (startPixelPosition < scroll + scrollDelta)
        {
         scrollDelta = startPixelPosition - scroll;
        }

       if (scrollDelta != 0)
        {
         screen().setScroll(scroll + scrollDelta);
        }
      }
    }

   return found;
  }

 /**
  * Find text in an element in this view.
  *
  * @return the position in element where the text was found, or
  *         0 if the text was not found
  */
 private int findText(Element element, int position, FindTextOptions options)
  {
   if (element.length() == 0 || options._findText == null)
    {
     return 0;
    }

   int findTextLength = options._findText.length();
   String text = element.text();
   int elementLength = text.length();
   boolean regularExpression = options._regularExpression != null;

   if (findTextLength == 0 ||
       (!regularExpression && elementLength < findTextLength))
    {
     return 0;
    }

   options._foundTextLength = findTextLength;

   int startStartColumn;
   int startEndColumn;
   int endColumn = elementLength;
   if (options._up)
    {
     startStartColumn = 1;
     startEndColumn = position;
     if (!regularExpression)
      {
       endColumn = position + findTextLength - 1;
       if (endColumn > elementLength)
        {
         endColumn = elementLength;
        }
      }
    }
   else
    {
     startStartColumn = position;
     if (regularExpression)
      {
       startEndColumn = elementLength;
      }
     else
      {
       startEndColumn = elementLength - findTextLength + 1;
      }
    }

   if (options._block)
    {
     int blockStart = Block.leftPosition(this, element);
     int blockEnd = Block.rightPosition(this, element);

     if (startStartColumn < blockStart)
      {
       startStartColumn = blockStart;
      }
     if (regularExpression)
      {
       if (startEndColumn > blockEnd)
        {
         startEndColumn = blockEnd;
        }
      }
     else
      {
       if (startEndColumn > blockEnd - findTextLength + 1)
        {
         startEndColumn = blockEnd - findTextLength + 1;
        }
      }
     if (endColumn > blockEnd)
      {
       endColumn = blockEnd;
      }
    }

   if (options._columns)
    {
     if (startStartColumn < options._startColumn)
      {
       startStartColumn = options._startColumn;
      }
     if (regularExpression)
      {
       if (startEndColumn > options._endColumn)
        {
         startEndColumn = options._endColumn;
        }
      }
     else
      {
       if (startEndColumn > options._endColumn - findTextLength + 1)
        {
         startEndColumn = options._endColumn - findTextLength + 1;
        }
      }
     if (endColumn > options._endColumn)
      {
       endColumn = options._endColumn;
      }
    }

   if ((!regularExpression && (endColumn - startStartColumn + 1 < findTextLength)) ||
       (startEndColumn < startStartColumn))
    {
     return 0;
    }

   if (!options._asis && !regularExpression)
    {
     text = text.toUpperCase();
    }

   if (options._up)
    {
     if (!regularExpression)
      {
       position = text.lastIndexOf(options._findText, startEndColumn - 1) + 1;
       if (position < startStartColumn)
        {
         position = 0;
        }
      }
     else
      {
       RegularExpression.Match match = options._regularExpression
                                              .lastMatch(text, startStartColumn - 1, endColumn);
       if (match != null)
        {
         position = match.start() + 1;
         options._foundTextLength = match.end() - match.start();
        }
       else
        {
         position = 0;
        }
      }
    }
   else
    {
     if (options._regularExpression == null)
      {
       position = text.indexOf(options._findText, startStartColumn - 1) + 1;
       if (position > startEndColumn)
        {
         position = 0;
        }
      }
     else
      {
       RegularExpression.Match match =
          options._regularExpression.match(text, startStartColumn - 1, endColumn);
       if (match != null)
        {
         position = match.start() + 1;
         options._foundTextLength = match.end() - match.start();
        }
       else
        {
         position = 0;
        }
      }
    }

   return position;
  }

 String popup()
  {
   return _popup;
  }

 void setPopup(String popup)
  {
   _popup = popup;
  }

 MarkList markList()
  {
   if (_markList == null)
    {
     _markList = new MarkList(this);
    }
   return _markList;
  }

 boolean readonly()
  {
   return _readonly;
  }

 void setReadonly(boolean readonly)
  {
   _readonly = readonly;
  }

 /**
  * Return the list of registered LpexViewListeners.
  */
 ViewListenerList listenerList()
  {
   return _viewListenerList;
  }

 CursorListenerList cursorListenerList()
  {
   if (_cursorListenerList == null)
    {
     _cursorListenerList = new CursorListenerList(this);
    }
   return _cursorListenerList;
  }

 /**
  * Called by the Screen to send any needed cursor notifications, if any cursor
  * listeners are registered.
  */
 void triggerCursorListeners()
  {
   if (_cursorListenerList != null)
    {
     _cursorListenerList.elementChanged();
    }
  }

 boolean changeAllowed()
  {
   if (_readonly)
    {
     _viewListenerList.setReadonlyChangeAttempted();
    }
   return !_readonly;
  }

 void preserveFindPosition()
  {
   if (_findPositionPreserve != null)
    {
     documentPosition().disposePreserve(_findPositionPreserve);
    }
   _findPositionPreserve = documentPosition().preserve();
  }

 void restoreFindPosition()
  {
   if (_findPositionPreserve != null)
    {
     _findPositionPreserve.restore();
    }
  }

 int[] fields()
  {
   return _fields;
  }

 void setFields(int fields[])
  {
   _fields = fields;
  }

 boolean ignoreFields()
  {
   return _ignoreFieldsCount > 0;
  }

 void setIgnoreFields()
  {
   _ignoreFieldsCount++;
  }

 void resetIgnoreFields()
  {
   if (_ignoreFieldsCount > 0)
    {
     _ignoreFieldsCount--;
    }
  }

 int fieldLimit(int position)
  {
   int fieldLimit = 0;
   if (_fields != null && !ignoreFields())
    {
     for (int i = 0; i < _fields.length; i++)
      {
       if (_fields[i] > position)
        {
         fieldLimit = _fields[i] - 1;
         break;
        }
      }
    }
   return fieldLimit;
  }

 int availableFieldSpace(Element element, int position)
  {
   int availableFieldSpace = -1;
   int fieldLimit = fieldLimit(position);
   if (fieldLimit != 0)
    {
     availableFieldSpace = 0;
     for (int i = fieldLimit; i >= position && i > 0; i--)
      {
       if (i <= element.length() && element.text().charAt(i - 1) != ' ')
        {
         break;
        }
       availableFieldSpace++;
      }
    }
   return availableFieldSpace;
  }

 /**
  * The actual <b>expandTabs</b> value for this view changed.
  * Re-set display for all this view's ElementViews whose elements have tabs.
  *
  * Called from ExpandTabsParameter.java when setting for this view
  * is DEFAULT and the default.expandTabs changed, and in here from
  * setExpandTabs() when a new value results from a
  * <code>set expandTabs on|off|default</code> command.
  */
 void expandTabsChanged()
  {
   // update cache to new actual value
   _expandTabs = ExpandTabsParameter.getParameter().currentValue(this);

   for (Element element = _document.elementList().first();
        element != null;
        element = element.next())
    {
     if (element.tabs())
      {
       element.elementView(this).resetDisplayText();
      }
    }
  }

 /**
  * The actual <b>tabs</b> value for this view changed.
  * Tabs are (now 2/2002) expanded on the display according to the <b>tabs</b>
  * parameter, so re-set display for all this view's ElementViews whose elements
  * contain tabs.
  *
  * Called from TabsParameter.java when setting for this view
  * is DEFAULT and the default.tabs may have changed, and in here from
  * setTabs() when a new value potentially results from a
  * <code>set tabs ..|default</code> command.
  */
 void tabsChanged()
  {
   // update cache to new actual value
   _currentTabs = TabsParameter.getParameter().currentValue(this);

   if (_expandTabs)
    {
     for (Element element = _document.elementList().first();
          element != null;
          element = element.next())
      {
       if (element.tabs())
        {
         element.elementView(this).resetDisplayText();
        }
      }
    }
  }

 /**
  * Set the expandTabs parameter for this view:
  *   <code>set expandTabs <i>value</i></code>.
  *
  * @param expandTabsParm Parameter.ON, .OFF, or .DEFAULT
  */
 void setExpandTabs(int expandTabsParm)
  {
   _expandTabsParm = expandTabsParm;

   // if expandTabs parameter value has changed, update tabs expansions on display
   if (_expandTabs != ExpandTabsParameter.getParameter().currentValue(this))
    {
     expandTabsChanged();
    }
  }

 /**
  * Retrieve the setting of the expandTabs parameter for this view:
  *   <code>query expandTabs</code>.
  *
  * @return Parameter.ON, .OFF, or .DEFAULT
  */
 int expandTabs()
  {
   return _expandTabsParm;
  }

 /**
  * Retrieve the actual value of the expandTabs parameter in effect
  * for this view (<code>query current.expandTabs</code>).
  */
 boolean currentExpandTabs()
  {
   return _expandTabs;
  }

 /**
  * Called from TabsParameter.java on <b>set tabs [default]</b> command.
  */
 void setTabs(TabsParameter.Settings tabsParm)
  {
   _tabsParm = tabsParm;

   // tabs parameter value may have changed, update tabs expansions on display
   tabsChanged();
  }

 /**
  * Retrieve the setting of the tabs parameter for this view:
  *   <code>query tabs</code>.
  *
  * @return actual settings, or a new TabsParameter.Settings for DEFAULT
  */
 TabsParameter.Settings tabs()
  {
   if (_tabsParm == null)
    {
     _tabsParm = new TabsParameter.Settings();
    }
   return _tabsParm;
  }

 /**
  * Retrieve the actual value of the tabs parameter in effect
  * for this view (<code>query current.tabs</code>).
  */
 TabsParameter.Settings currentTabs()
  {
   return _currentTabs;
  }

 /**
  * Expand the tabs in the text of an element for display purposes.  Adds spaces
  * to the display string for the expanded tabs.
  *
  * NOTE:  The tab expansion in LPEX is a *display* feature - same EBCDIC DBCS
  * source-encoding text may expand differently (a) if showSosi is on (which is
  * what happens on the host, if the host indeed supports & expands Tabs!?!?),
  * (b) if showSosi is off.
  *
  * @param displayText: element's text + [SO/SIs] (without sequence numbers)
  *
  * @see #expandStyleTabs
  */
 String expandTextTabs(String displayText)
  {
   // TABS EXPANDED BY tabs PARAMETER SETTING
   StringBuffer buffer = new StringBuffer(displayText.length() + 32);
   boolean mbcs = nls().isSourceMbcs();

   int tc = 0;         // last-used tab stop in tabs._tabStops[]
   int lastTabVal = 0; // last-used tab stop position

   int i = 0;          // index into displayText
   int pos = 1;        // display position

   for (; i < displayText.length(); i++)
    {
     char c = displayText.charAt(i);
     if (c == '\t')
      {
       while (tc < _currentTabs._tabStops.length && lastTabVal <= pos)
        {
         lastTabVal = _currentTabs._tabStops[tc++];
        }
       while (lastTabVal <= pos)
        {
         lastTabVal += (_currentTabs._tabIncrement == 0)? 1 : _currentTabs._tabIncrement;
        }
       int tabLen = lastTabVal - pos;
       for (int j = 0; j < tabLen; j++)
        {
         buffer.append(' ');
        }
       pos = lastTabVal; /* we're at lastTabVal display position now */
      }
     else
      {
       buffer.append(c);
       if (mbcs)
        {
         pos += nls().sourceWidth(c);
        }
       else
        {
         pos++;
        }
      }
    }

   return buffer.toString();
  }

 // TABS EXPANDED TO EVERY-8-CHARACTERS:
 // String expandTextTabs(String displayText) {
 //  StringBuffer buffer = new StringBuffer(displayText.length() + 32);
 //
 //  boolean mbcs = nls().isSourceMbcs();
 //  int i = 0;
 //  int pos = 1; // 1 .. 8 for each tab
 //
 //  for (; i < displayText.length(); i++)
 //   {
 //    char c = displayText.charAt(i);
 //    if (c == '\t')
 //     {
 //      while (pos < 9)
 //       {
 //        buffer.append(' ');
 //        pos++;
 //       }
 //     }
 //    else
 //     {
 //      buffer.append(c);
 //      if (mbcs)
 //       {
 //        pos += nls().sourceWidth(c);
 //       }
 //      else
 //       {
 //        pos++;
 //       }
 //     }
 //
 //    if (pos >= 9)
 //     {
 //      pos -= 8;
 //     }
 //   }
 //
 //  return buffer.toString();

 /**
  * Adjust the element's display style for the expanded tabs in the display text.
  *
  * @param style style for text (without sequence numbers)
  * @param text  element's text + [SO/SIs] (without sequence numbers)
  *
  * @see #expandTextTabs
  */
 String expandStyleTabs(String style, String text)
  {
   // TABS EXPANDED BY tabs PARAMETER SETTING
   StringBuffer buffer = new StringBuffer(style.length() + 32);
   boolean mbcs = nls().isSourceMbcs();

   int tc = 0;         // last-used tab stop in tabs._tabStops[]
   int lastTabVal = 0; // last-used tab stop position

   int iText = 0;      // index into text
   int i = 0;          // index into style
   int pos = 1;        // display position

   for (; i < style.length(); i++, iText++)
    {
     char c = (iText < text.length())? text.charAt(iText) : ' ';
     char s = style.charAt(i);
     if (c == '\t')
      {
       while (tc < _currentTabs._tabStops.length && lastTabVal <= pos)
        {
         lastTabVal = _currentTabs._tabStops[tc++];
        }
       while (lastTabVal <= pos)
        {
         lastTabVal += (_currentTabs._tabIncrement == 0)? 1 : _currentTabs._tabIncrement;
        }
       int tabLen = lastTabVal - pos;
       for (int j = 0; j < tabLen; j++)
        {
         buffer.append(s);
        }
       pos = lastTabVal; /* we're at lastTabVal display position now */
      }
     else
      {
       buffer.append(s);
       if (mbcs)
        {
         pos += nls().sourceWidth(c);
        }
       else
        {
         pos++;
        }
      }
    }

   return buffer.toString();
  }

 // TABS EXPANDED TO EVERY-8-CHARACTERS:
 // String expandStyleTabs(String style, String text) {
 //   StringBuffer buffer = new StringBuffer(style.length() + 32);
 //
 //   boolean mbcs = nls().isSourceMbcs();
 //   int iText = 0;
 //   int i = 0;
 //   int pos = 1; // 1 .. 8 for each tab
 //
 //   for (; i < style.length(); i++, iText++)
 //    {
 //     char c = (iText < text.length())? text.charAt(iText) : ' ';
 //     char s = style.charAt(i);
 //     if (c == '\t')
 //      {
 //       while (pos < 9)
 //        {
 //         buffer.append(s);
 //         pos++;
 //        }
 //      }
 //     else
 //      {
 //       buffer.append(s);
 //       if (mbcs)
 //        {
 //         pos += nls().sourceWidth(c);
 //        }
 //       else
 //        {
 //         pos++;
 //        }
 //      }
 //
 //     if (pos >= 9)
 //      {
 //       pos -= 8;
 //      }
 //    }
 //
 //   return buffer.toString();
 //  }

 /**
  * The actual hideSequenceNumbers value for this view changed.
  * Re-set display for all this view's ElementViews.
  *
  * Called from HideSequenceNumbersParameter.java when setting for this view
  * is DEFAULT and the default.hideSequenceNumbers changed, and in here from
  * setHideSequenceNumbers() when a new value results from a
  * <code>set hideSequenceNumbers on|off|default</code> command.
  */
 void hideSequenceNumbersChanged()
  {
   // update cache to new actual value
   _hideSequenceNumbers =
      HideSequenceNumbersParameter.getParameter().currentValue(this);

   // our DocumentPosition's _desiredPixelPosition into display text changed as
   // columns were added/removed - tell it to stick to its _position into the
   // element text:
   //   documentPosition()._desiredPixelPosition = -1;
   // this is best accomplished by a jump 'in place':
   documentPosition().jump(documentPosition().documentLocation());

   if (document().elementList().sequenceNumbersWidth() != 0)
    {
     for (Element element = _document.elementList().first();
          element != null;
          element = element.next())
      {
       // must re-set display text even for show elements
       element.elementView(this).resetDisplayText();
      }
    }
  }

 /**
  * Set the hideSequenceNumbers parameter for this view:
  *   <code>set hideSequenceNumbers <i>value</i></code>.
  *
  * @param hideSequenceNumbersParm Parameter.ON, .OFF, or .DEFAULT
  */
 void setHideSequenceNumbers(int hideSequenceNumbersParm)
  {
   _hideSequenceNumbersParm = hideSequenceNumbersParm;
   if (_hideSequenceNumbers !=
       HideSequenceNumbersParameter.getParameter().currentValue(this))
    {
     hideSequenceNumbersChanged();
    }
  }

 /**
  * Retrieve the setting of the hideSequenceNumbers parameter for this view:
  *   <code>query hideSequenceNumbers</code>.
  *
  * @return Parameter.ON, .OFF, or .DEFAULT
  */
 int hideSequenceNumbers()
  {
   return _hideSequenceNumbersParm;
  }

 /**
  * Retrieve the actual value of the hideSequenceNumbers parameter in effect
  * for this view (<code>query current.hideSequenceNumbers</code>).
  */
 boolean currentHideSequenceNumbers()
  {
   return _hideSequenceNumbers;
  }

 /**
  * The sequenceNumbersFormat setting for this view changed.
  * Re-set the display for all this view's ElementViews.  If the prefix area is
  * displaying sequence numbers, re-set it as well.
  */
 void sequenceNumbersFormatChanged()
  {
   // adjust cached values according to new setting
   cacheSequenceNumbersFormat();

   // re-set the display for all this view's ElementViews
   if (document().elementList().sequenceNumbersWidth() != 0)
    {
     for (Element element = _document.elementList().first();
          element != null;
          element = element.next())
      {
       // must re-set display text even for show elements
       element.elementView(this).resetDisplayText();
      }
    }

   // if the prefix area is affected, invalidate it as well
   if (PrefixAreaParameter.getParameter().currentValue(this) == true &&
       PrefixAreaTextParameter.getParameter().currentValue(this) ==
       View.PREFIX_AREA_TEXT_SEQUENCENUMBERS)
    {
     setPrefixAreaWidthsInvalid(); // re-set prefix area text for all elements
    }
  }

 /**
  * Cache the sequence numbers display format string & its style, according to
  * the current (updated) value of the view's sequenceNumbersFormat parameter.
  */
 private void cacheSequenceNumbersFormat()
  {
   _sequenceNumbersFormat = SequenceNumbersFormatParameter.getParameter()
                                                          .currentValue(this);
   if (_sequenceNumbersFormat == null)
    {
     _sequenceNumbersFormatStyle = null;
    }
   else
    {
     int len = _sequenceNumbersFormat.length();
     StringBuffer style = new StringBuffer(len);
     for (int i = 0;  i < len; i++)
      {
       char c = _sequenceNumbersFormat.charAt(i);
       if (c == '9')
        {
         style.append(Screen.CHAR_STYLE_SEQUENCE_NUMBER);
        }
       else
        {
         if (c == '\\' && i < len-1)
          {
           i++;
          }
         style.append(Screen.CHAR_STYLE_SEQUENCE_TEXT);
        }
      }

     _sequenceNumbersFormatStyle = style.toString();
    }
  }

 /**
  * Retrieve the current sequence-numbers display-format string.
  */
 String sequenceNumbersFormat()
  {
   return _sequenceNumbersFormat;
  }

 /**
  * Retrieve the current display style in effect for
  * the (view-scoped) sequenceNumbersFormat parameter or, if none set,
  * the (document-scoped) sequenceNumbers parameter.
  */
 String getSequenceNumbersStyle()
  {
   if (_sequenceNumbersFormatStyle != null)
    {
     return _sequenceNumbersFormatStyle;
    }

   return _document.elementList().sequenceNumbersStyle();
  }

 /**
  * Retrieve the National Language Support object associated with this View.
  * The NLS functions in LPEX are accessible via this object.
  */
 LpexNls nls()
  {
   return _nls;
  }

 /**
  * Set showSosi setting for this view.
  *
  * @param showSosi Parameter.ON, .OFF, or .DEFAULT
  */
 void setShowSosi(int showSosi)
  {
   boolean oldCurrentShowSosi = currentShowSosi();
   _showSosiParm = showSosi;

   if (oldCurrentShowSosi != currentShowSosi())
    {
     showSosiChanged();
    }
  }

 /**
  * View's showSosi / shiftOutCharacter / shiftInCharacter changed - reset any
  * cached displayText *for those lines with SO/SIs* (ie, could OPTIMIZE here!).
  */
 void showSosiChanged()
  {
   for (Element element = _document.elementList().first();
        element != null;
        element = element.next())
    {
     element.elementView(this).resetDisplayText();
    }
  }

 /**
  * Retrieve this view's showSosi parameter.
  *
  * @return Parameter.ON, .OFF, or .DEFAULT
  */
 int showSosi()
  {
   return _showSosiParm;
  }

 /**
  * Retrieve the effective "on" (true) / "off" (false) current value of the
  * showSosi setting for this view.
  */
 boolean currentShowSosi()
  {
   return ShowSosiParameter.getParameter().currentValue(this);
  }

 void setCursorBlink(int cursorBlink)
  {
   _cursorBlinkParm = cursorBlink;
  }

 int cursorBlink()
  {
   return _cursorBlinkParm;
  }

 boolean currentCursorBlink()
  {
   return CursorBlinkParameter.getParameter().currentValue(this);
  }

 /**
  * Return the element classes defined in this view.
  */
 Classes classes()
  {
   return _classes;
  }

 boolean forceAllVisible()
  {
   return _forceAllVisible;
  }

 void setForceAllVisible(boolean forceAllVisible)
  {
   setVisibleElementOrdinalsInvalid();
   _forceAllVisible = forceAllVisible;
  }

 void elementRemoved(Element element)
  {
   documentPosition().elementRemoved(element);
   parsePendingList().elementRemoved(element);
   if (_markList != null)
    {
     _markList.elementRemoved(element);
    }
  }

 void elementInserted(Element element)
  {
   if (!element.show())
    {
     parsePendingList().add(element, PARSE_PENDING_CHANGE_MASK);
    }

   setVisibleElementOrdinalsInvalid();

   if (_markList != null)
    {
     _markList.elementInserted(element);
    }
  }

 BlockCommand.Settings blockCommandSettings()
  {
   if (_blockCommandSettings == null)
    {
     _blockCommandSettings = new BlockCommand.Settings();
    }
   return _blockCommandSettings;
  }

 CompareCommand.Settings compareCommandSettings()
  {
   if (_compareCommandSettings == null)
    {
     _compareCommandSettings = new CompareCommand.Settings();
    }
   return _compareCommandSettings;
  }

 FindTextCommand.Settings findTextCommandSettings()
  {
   if (_findTextCommandSettings == null)
    {
     _findTextCommandSettings = new FindTextCommand.Settings();
    }
   return _findTextCommandSettings;
  }

 PrintCommand.Settings printCommandSettings()
  {
   if (_printCommandSettings == null)
    {
     _printCommandSettings = new PrintCommand.Settings();
    }
   return _printCommandSettings;
  }

 UpdateProfileCommand.Settings updateProfileCommandSettings()
  {
   if (_updateProfileCommandSettings == null)
    {
     _updateProfileCommandSettings = new UpdateProfileCommand.Settings();
    }
   return _updateProfileCommandSettings;
  }

 ViHandler viHandler()
  {
   if (_viHandler == null)
    {
     _viHandler = new ViHandler(this);
    }
   return _viHandler;
  }

 boolean autoCheck()
  {
   return _autoCheck;
  }

 void setAutoCheck(boolean autoCheck)
  {
   _autoCheck = autoCheck;
  }

 boolean vi()
  {
   return _vi;
  }

 /**
  * Set an alternative class loader to be used by this view.
  * See LpexView#setClassLoader().
  */
 void setClassLoader(ClassLoader classLoader)
  {
   _classLoader = classLoader;
  }

 /**
  * Retrieve the alternative class loader used by this view.
  * See #setClassLoader.
  */
 ClassLoader getClassLoader()
  {
   return _classLoader;
  }

 /**
  * Check for the current line inside the currently-loaded document section
  * vis-a-vis the threshold from its boundaries, to determine if the current
  * section must be expanded (on one or both sides).
  *
  * This method is usually called after an operation that may have changed
  * the line inside the current section, or may have deleted big chunks of it.
  */
 void verifyDocumentSection()
  {
   // prevent recursion from listener's adjustments to the document section
   if (document().triggeringDocumentSectionListeners())
    {
     return;
    }

   int neededLine = document().elementList().nonShowOrdinalOf(documentPosition().element()) +
                    document().linesBeforeStart();

   int lowest  = Math.max(1, neededLine - _documentSectionThreshold);
   int highest = Math.min(document().linesCount(), neededLine + _documentSectionThreshold);

   if (lowest < document().linesBeforeStart())
    {
     // this will load & re-set linesBeforeStart
     document().triggerDocumentSectionListeners(_lpexView, lowest);
    }

   // now use the new values, after any expansion above

   if (highest > document().linesBeforeStart() + document().elementList().nonShowCount())
    {
     // this will load & re-set linesAfterEnd
     document().triggerDocumentSectionListeners(_lpexView, highest);
    }
  }

 /**
  * Check for the given line inside the currently-loaded document section
  * vis-a-vis the threshold from its boundaries, to determine if the current
  * section must be expanded (on either side).
  *
  * @param estimated needed line inside the complete document
  */
 void verifyDocumentSectionLine(int neededLine)
  {
   // prevent recursion from listener's adjustments to the document section
   if (document().triggeringDocumentSectionListeners())
    {
     return;
    }

   int lowest  = Math.max(1, neededLine - _documentSectionThreshold);
   int highest = Math.min(document().linesCount(), neededLine + _documentSectionThreshold);

   if (lowest < document().linesBeforeStart())
    {
     // this will load & re-set linesBeforeStart
     document().triggerDocumentSectionListeners(_lpexView, lowest);
    }
   else if (highest > document().linesBeforeStart() + document().elementList().nonShowCount())
    {
     // this will load & re-set linesAfterEnd
     document().triggerDocumentSectionListeners(_lpexView, highest);
    }
  }

 /**
  * Check for the given element inside the currently-loaded document section
  * vis-a-vis the threshold from its boundaries, to determine if the current
  * section must be expanded (on either side).
  *
  * @param estimated needed element inside the complete document
  */
 void verifyDocumentSectionElement(int neededElement)
  {
   // prevent recursion from listener's adjustments to the document section
   if (document().triggeringDocumentSectionListeners())
    {
     return;
    }

   int sectionElements = document().elementList().count();
   int totalElements = document().linesBeforeStart() +
                       sectionElements +
                       document().linesAfterEnd();
   int lowest  = Math.max(1, neededElement - _documentSectionThreshold);
   int highest = Math.min(totalElements, neededElement + _documentSectionThreshold);

   if (lowest < document().linesBeforeStart())
    {
     // this will load & re-set linesBeforeStart
     document().triggerDocumentSectionListeners(_lpexView, lowest);
    }
   else if (highest > document().linesBeforeStart() + sectionElements)
    {
     // convert highest needed element to a needed line
     int showElements = sectionElements - document().elementList().nonShowCount();
     // this will load & re-set linesAfterEnd
     document().triggerDocumentSectionListeners(_lpexView, highest - showElements);
    }
  }

 /**
  * Check for the current-line change inside the currently-loaded document
  * section vis-a-vis the threshold from its boundaries, to determine if the
  * current section must be expanded in the direction of the delta.
  *
  * @param estimated change in the current line
  */
 void verifyDocumentSectionDelta(int delta)
  {
   // prevent recursion from listener's adjustments to the document section
   if (document().triggeringDocumentSectionListeners())
    {
     return;
    }

   if (delta == 0 ||
       (delta < 0 && document().linesBeforeStart() == 0) ||
       (delta > 0 && document().linesAfterEnd() == 0))
    {
     return;
    }

   int neededLine = document().elementList().nonShowOrdinalOf(documentPosition().element()) +
                    document().linesBeforeStart() + delta;

   if (delta < 0)
    {
     int lowest  = Math.max(1, neededLine - _documentSectionThreshold);
     if (lowest < document().linesBeforeStart())
      {
       // load & re-set linesBeforeStart
       document().triggerDocumentSectionListeners(_lpexView, lowest);
      }
     return;
    }

   int highest = Math.min(document().linesCount(), neededLine + _documentSectionThreshold);
   if (highest > document().linesBeforeStart() + document().elementList().nonShowCount())
    {
     // load & re-set linesAfterEnd
     document().triggerDocumentSectionListeners(_lpexView, highest);
    }
  }

 /**
  * Set a document-section expansion threshold for this view's screen of at
  * least two screens of rows.  This ensures e.g., a page down can be completed
  * when the current line is displayed on the top row of the screen.
  */
 void setDocumentSectionThreshold()
  {
   int newThreshold = Math.max(100, screen().rows() * 2);
   _documentSectionThreshold = newThreshold;
  }

 /**
  * Convenience method to display an LpexResources.message on the message line.
  * setLpexMessageText(key) is equivalent to
  * screen().setMessagetext(LpexResources.message(key)).
  * @param key message key in LpexResources
  */
 void setLpexMessageText(String key)
  {
   screen().setMessageText(LpexResources.message(key));
  }

 /**
  * Convenience method to display an LpexResources.message on the message line.
  * setLpexMessageText(key, arg1) is equivalent to
  * screen().setMessagetext(LpexResources.message(key, arg1)).
  * @param key message key in LpexResources
  * @param arg1 int substitution argument in message
  */
 void setLpexMessageText(String key, int arg1)
  {
   screen().setMessageText(LpexResources.message(key, arg1));
  }

 /**
  * Convenience method to display an LpexResources.message on the message line.
  * setLpexMessageText(key, arg1) is equivalent to
  * screen().setMessagetext(LpexResources.message(key, arg1)).
  * @param key message key in LpexResources
  * @param arg1 String substitution argument in message
  */
 void setLpexMessageText(String key, String arg1)
  {
   screen().setMessageText(LpexResources.message(key, arg1));
  }

 /**
  * Convenience method to display an LpexResources.message on the message line.
  * setLpexMessageText(key, arg1) is equivalent to
  * screen().setMessagetext(LpexResources.message(key, arg1)).
  * @param key message key in LpexResources
  * @param arg1 first String substitution argument in message
  * @param arg2 second String substitution argument
  */
 void setLpexMessageText(String key, String arg1, String arg2)
  {
   screen().setMessageText(LpexResources.message(key, arg1, arg2));
  }
}