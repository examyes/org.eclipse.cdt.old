//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ElementList - manage a Document's list of elements.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages the list of elements that make up a document.
 * There is one instance of this class per Document.
 */
final class ElementList implements LpexConstants
{
 private Document _document;
 private boolean  _nonShowOrdinalsValid;
 private Element  _firstElement;
 private Element  _lastElement;
 private Element  _lastOrdinalRequested;
 private boolean  _ordinalsValid;
 private int      _textLimit;

 // the current sequence-numbers settings: cache them here rather than querying
 // the SequenceNumbersParameter.getParameter().current values all the time...
 private int     _sequenceNumbersColumn;
 private int     _sequenceNumbersWidth;
 private int     _sequenceNumbersNumColumn;
 private int     _sequenceNumbersNumWidth;
 private int     _sequenceNumbersTextColumn;
 private int     _sequenceNumbersTextWidth;
 private String  _sequenceNumbersStyle;

 private boolean _maintainSequenceNumbers;
 private boolean _sequenceNumbersValid;
 private int     _maxSequenceNumber;

 // SequenceDefaultTextParameter value
 String _sequenceDefaultTextParm;
 // cache actual default text adjusted for the current sequence-numbers settings
 private String _sequenceDefaultText;


 /**
  * Construct a list of elements for the Document.
  */
 ElementList(Document document)
  {
   _document = document;
   _maintainSequenceNumbers = true;
   _textLimit = SaveCommand.TextLimitParameter.getParameter()
                                              .currentValue(_document._firstView);
   // set the starting sequence-numbers settings
   SequenceNumbersParameter seq = SequenceNumbersParameter.getParameter();
   _sequenceNumbersNumColumn  = seq.currentNumColumn(_document);
   _sequenceNumbersNumWidth   = seq.currentNumWidth(_document);
   _sequenceNumbersTextColumn = seq.currentTextColumn(_document);
   _sequenceNumbersTextWidth  = seq.currentTextWidth(_document);
   cacheSequenceNumbersData();
  }

 Element first()
  {
   return _firstElement;
  }

 Element last()
  {
   return _lastElement;
  }

 Element elementAt(int ordinal)
  {
   if (ordinal < 1 ||
       ordinal > ordinalOf(_lastElement)) // (call also ensures _ordinalsValid)
    {
     return null;
    }

   // try to speed things up by starting at the Element for last ordinal requested
   if (_lastOrdinalRequested == null)
    {
     _lastOrdinalRequested = first();
    }

   if (ordinal >= ordinalOf(_lastOrdinalRequested))
    {
     while (_lastOrdinalRequested != null && ordinalOf(_lastOrdinalRequested) != ordinal)
      {
       _lastOrdinalRequested = _lastOrdinalRequested.next();
      }
    }
   else
    {
     while (_lastOrdinalRequested != null && ordinalOf(_lastOrdinalRequested) != ordinal)
      {
       _lastOrdinalRequested = _lastOrdinalRequested.prev();
      }
    }

   return _lastOrdinalRequested;
  }

 int ordinalOf(Element element)
  {
   if (element != null && element._partOfList)
    {
     if (!_ordinalsValid)
      {
       Element current;
       int count;
       for (current = first(), count = 1;
            current != null;
            current = current.next(), count++)
        {
         current._ordinal = count;
        }
       _ordinalsValid = true;
      }
     return element._ordinal;
    }

   return 0;
  }

 /**
  * Returns the number of elements in the list.
  */
 int count()
  {
   return (_lastElement == null)? 0 : ordinalOf(_lastElement);
  }

 void addAfter(View view, Element prev, Element element)
  {
   addAfter(view, prev, element, false);
  }

 /**
  * @param undoElement true = we're restoring (undoind/redoing) this element:
  *                           try to keep its original sequence-numbers text part
  */
 void addAfter(View view, Element prev, Element element, boolean undoElement)
  {
   if (element != null)
    {
     Element next;
     if (prev == null)
      {
       next = _firstElement;
       _firstElement = element;
      }
     else
      {
       next = prev.next();
       prev._next = element;
      }

     element._prev = prev;
     element._next = next;
     if (next != null)
      {
       next._prev = element;
      }
     else
      {
       _lastElement = element;
      }
     element._partOfList = true;
     _ordinalsValid = false;
    }

   insert(view, element, undoElement);
  }

 void addBefore(View view, Element next, Element element)
  {
   if (element != null)
    {
     Element prev;
     if (next == null)
      {
       prev = _lastElement;
       _lastElement = element;
      }
     else
      {
       prev = next.prev();
       next._prev = element;
      }

     element._next = next;
     element._prev = prev;
     if (prev != null)
      {
       prev._next = element;
      }
     else
      {
       _firstElement = element;
      }
     element._partOfList = true;
     _ordinalsValid = false;
    }

   insert(view, element, false);
  }

 /**
  * Insert a new element in the list.
  * Called from addBefore() and addAfter().
  *
  * @parameter undoElement true = the inserted element is an undo/redo element,
  *                               don't set default sequence text (keep original)
  */
 private void insert(View view, Element element, boolean undoElement)
  {
   element.setWidthsInvalid();
   element.setPrefixAreaWidthsInvalid();
   _document.elementInserted(element);
   _nonShowOrdinalsValid = false;

   if (!element.show())
    {
     // if a textLimit, check whether we're going over
     if (_textLimit > 0 && saveLength(element) > _textLimit)
      {
       view.setLpexMessageText(MSG_TEXTLIMIT_OVERFLOW);
      }

     // undo element: re-set original seq-num text part (in case settings changed)
     if (undoElement)
      {
       element.setSequenceText(element.sequenceText());
      }
     // regular-operation element: set default sequence text if maintaining
     else if (_maintainSequenceNumbers)
      {
       element.setSequenceText(_sequenceDefaultText);
      }

     int sequenceNumber = element.sequenceNumber();
     Element prev = element.prevNonShow();
     Element next = element.nextNonShow();

     // if maintainSequenceNumbers, assign a sequence number
     if (_maintainSequenceNumbers && _sequenceNumbersNumWidth > 0)
      {
       int prevSequenceNumber = (prev == null)? 0 : prev.sequenceNumber();
       int nextSequenceNumber = (next == null)? _maxSequenceNumber : next.sequenceNumber();
       if (prevSequenceNumber >= sequenceNumber ||
           nextSequenceNumber <= sequenceNumber)
        {
         sequenceNumber = prevSequenceNumber;
         for (;;)
          {
           sequenceNumber++;
           if (sequenceNumber >= _maxSequenceNumber)
            {
             if (view != null)
              {
               view.setLpexMessageText(MSG_SEQUENCENUMBERS_OVERFLOW);
              }
             break;
            }
           element.setSequenceNumber(sequenceNumber);
           if (next == null || sequenceNumber < next.sequenceNumber())
            {
             break;
            }
           element = next; // NB Changing variable element here!
           next = element.nextNonShow();
          }//end "for"
        }
      }

     else if (_sequenceNumbersValid &&
              (sequenceNumber == 0 ||
               sequenceNumber >= _maxSequenceNumber ||
               (prev != null && prev.sequenceNumber() >= sequenceNumber) ||
               (next != null && next.sequenceNumber() <= sequenceNumber)))
      {
       _sequenceNumbersValid = false;
      }
    }
  }

 /**
  * Remove an element from the list.
  * Record information in the parse-pending list.
  */
 Element remove(Element element)
  {
   _document.elementRemoved(element);
   Block.elementRemoved(element);
   if (!element.show())
    {
     Element e = element.prevNonShow();
     if (e != null)
      {
       _document.addParsePending(e, PARSE_PENDING_NEXT_DELETED_MASK);
      }
     e = element.nextNonShow();
     if (e != null)
      {
       _document.addParsePending(e, PARSE_PENDING_PREV_DELETED_MASK);
      }
    }
   else
    {
     Element e = element.prevNonShow();
     if (e != null)
      {
       element.showView().parsePendingList().add(e, PARSE_PENDING_NEXT_SHOW_DELETED_MASK);
      }
     e = element.nextNonShow();
     if (e != null)
      {
       element.showView().parsePendingList().add(e, PARSE_PENDING_PREV_SHOW_DELETED_MASK);
      }
    }

   Element prev = element.prev();
   Element next = element.next();
   if (prev != null)
    {
     prev._next = next;
    }
   else
    {
     _firstElement = next;
    }

   if (next != null)
    {
     next._prev = prev;
    }
   else
    {
     _lastElement = prev;
    }
   element._next = null;
   element._prev = null;

   element._partOfList = false;
   _ordinalsValid = false;
   if (_lastOrdinalRequested == element)
    {
     _lastOrdinalRequested = next;
    }

   element.setWidthsInvalid();
   element.setPrefixAreaWidthsInvalid();
   _document.setVisibleElementOrdinalsInvalid();
   _nonShowOrdinalsValid = false;
   return element;
  }

 /**
  * Clear the element list.
  */
 void clear()
  {
   while (_firstElement != null)
    {
     remove(_firstElement);
    }

   _ordinalsValid = false;
   _document.resetUserActionElements();

   for (View view = _document._firstView; view != null; view = view._next)
    {
     view.setMaxElementWidthInvalid();
     view.setMaxPrefixAreaWidthInvalid();
    }

   _document.setVisibleElementOrdinalsInvalid();
   _nonShowOrdinalsValid = false;
  }

 void disposeView(View view)
  {
   Element nextElement = null;
   for (Element element = first(); element != null; element = nextElement)
    {
     nextElement = element.next();
     if (element.show() && element.elementView(view).show())
      {
       remove(element);
      }
     else
      {
       element.disposeView(view);
      }
    }
  }

 void expandAll(View view, boolean expanded)
  {
   for (Element element = first(); element != null; element = element.next())
    {
     element.elementView(view).setExpanded(expanded);
    }
  }

 /**
  * Locate the non-show element (document line) at the specified position.
  */
 Element nonShowElementAt(int ordinal)
  {
   if (ordinal < 1)
    {
     return null;
    }

   if (ordinal > nonShowCount())
    {
     return null;
    }

   for (Element element = first(); element != null; element = element.next())
    {
     if (nonShowOrdinalOf(element) == ordinal)
      {
       return element;
      }
    }
   return null;
  }

 /**
  * Find the non-show ordinal (line number in document) of the specified
  * element.
  */
 int nonShowOrdinalOf(Element element)
  {
   if (element != null && element._partOfList)
    {
     if (!_nonShowOrdinalsValid)
      {
       Element current;
       int count = 0;
       for (current = first(); current != null; current = current.next())
        {
         if (!current.show())
          {
           count++;
          }
         current.setNonShowOrdinal(count);
        }
       _nonShowOrdinalsValid = true;
      }
     return element.nonShowOrdinal();
    }

   return 0;
  }

 /**
  * Return the number of non-show elements in the list
  * (number of lines in document section).
  */
 int nonShowCount()
  {
   return (_lastElement == null)? 0 : nonShowOrdinalOf(last());
  }

 /**
  * Get the first visible element in the view.
  */
 Element firstVisible(View view)
  {
   Element element = first();
   if (element != null && !element.visible(view))
    {
     element = element.nextVisible(view);
    }

   return element;
  }

 /**
  * Get the last visible element in the view.
  */
 Element lastVisible(View view)
  {
   Element element = last();
   if (element != null && !element.visible(view))
    {
     element = element.prevVisible(view);
    }

   return element;
  }

 /**
  * Find position of the next word in an element.
  */
 static int nextWord(Element element, int position)
  {
   String text = element.text();
   int textLength = text.length();
   if (textLength > 0)
    {
     if (position > 0)
      {
       // locate the first whitespace past position
       for (; position <= textLength; position++)
        {
         char c = text.charAt(position - 1);
         if (c == ' ' || c == '\t')
          {
           break;
          }
        }
      }

     // locate the next non-whitespace character
     for (position++; position <= textLength; position++)
      {
       char c = text.charAt(position - 1);
       if (c != ' ' && c != '\t')
        {
         return position;
        }
      }
    }

   return 0;
  }

 /**
  * Find end position of next word in an element.
  */
 static int nextWordEnd(Element element, int position)
  {
   String text = element.text();
   int textLength = text.length();
   if (textLength > 0)
    {
     // locate the first non whitespace character past position
     for (position++; position <= textLength; position++)
      {
       char c = text.charAt(position - 1);
       if (c != ' ' && c != '\t')
        {
         break;
        }
      }

     if (position <= textLength)
      {
       // locate the next whitespace character
       for (; position < textLength; position++)
        {
         char c = text.charAt(position);
         if (c == ' ' || c == '\t')
          {
           break;
          }
        }
       return position;
      }
    }

   return 0;
  }

 /**
  * Find position of previous word in an element.
  */
 static int prevWord(Element element, int position)
  {
   String text = element.text();
   int textLength = text.length();
   if (textLength > 0)
    {
     if (position > textLength + 1)
      {
       position = textLength + 1;
      }

     for (position--; position > 0; position--)
      {
       char c = text.charAt(position - 1);
       if (c != ' ' && c != '\t')
        {
         break;
        }
      }

     for (; position > 0; position--)
      {
       if (position == 1)
        {
         return 1;
        }
       char c = text.charAt(position - 2);
       if (c == ' ' || c == '\t')
        {
         return position;
        }
      }
    }
   return 0;
  }

 /**
  * Find end position of previous word in an element.
  */
 static int prevWordEnd(Element element, int position)
  {
   String text = element.text();
   int textLength = text.length();
   if (textLength > 0)
    {
     if (position > textLength)
      {
       position = textLength;
      }
     else
      {
       // move to first whitespace character
       for (; position > 0; position--)
        {
         char c = text.charAt(position - 1);
         if (c == ' ' || c == '\t')
          {
           break;
          }
        }
      }

     // move to first non-whitespace character
     for (; position > 0; position--)
      {
       char c = text.charAt(position - 1);
       if (c != ' ' && c != '\t')
        {
         return position;
        }
      }
    }
   return 0;
  }

 boolean maintainSequenceNumbers()
  {
   return _maintainSequenceNumbers;
  }

 /**
  * Set the maintainSequenceNumbers parameter.
  */
 void setMaintainSequenceNumbers(View view, boolean maintainSequenceNumbers)
  {
   if (_maintainSequenceNumbers != maintainSequenceNumbers)
    {
     _maintainSequenceNumbers = maintainSequenceNumbers;
     if (_maintainSequenceNumbers &&
         !_sequenceNumbersValid && _sequenceNumbersNumWidth > 0)
      {
       if (resequence())
        {
         view.setLpexMessageText(MSG_SEQUENCENUMBERS_RESEQUENCED);
        }
       else
        {
         view.setLpexMessageText(MSG_SEQUENCENUMBERS_OVERFLOW);
         _maintainSequenceNumbers = false;
        }
      }
    }
  }

 /**
  * Re-sequence the numbers part of the sequence numbers.
  * New sequence numbers are set in the document section currently loaded
  * in the editor, according to the number of lines in the complete document.
  *
  * @return false if the resequence failed
  */
 boolean resequence()
  {
   int start = 100;
   int increment = 100;
   int count = _document.linesCount(); // number of lines in complete document

   while (increment > 0 && start + (increment * (count - 1)) >= _maxSequenceNumber)
    {
     start /= 2;
     increment /= 2;
    }
   if (increment == 0)
    {
     return false;
    }

   return resequence(start, increment);
  }

 /**
  * Re-sequence the numbers part of the sequence numbers, starting at
  * <code>start</code>, with a given <code>increment</code>.
  * New sequence numbers are set in the document section currently loaded
  * in the editor, according to the number of lines in the complete document.
  *
  * @return false = resequence failed
  */
 boolean resequence(int start, int increment)
  {
   if (start <= 0 || increment <= 0)
    {
     return false;
    }

   /*-------------------------------------------------------------------*/
   /*  check start & increment won't overflow in the complete document  */
   /*-------------------------------------------------------------------*/
   int sequenceNumber = start;
   int i = 0;
   for (; i < _document.linesBeforeStart(); i++)
    {
     if (sequenceNumber > _maxSequenceNumber)
      {
       return false;
      }
     sequenceNumber += increment;
    }
   int firstSequenceNumber = sequenceNumber;

   int restOfLinesCount = nonShowCount() + _document.linesAfterEnd();
   for (; i < restOfLinesCount; i++)
    {
     if (sequenceNumber > _maxSequenceNumber)
      {
       return false;
      }
     sequenceNumber += increment;
    }

   /*------------------------------------------------------------------------*/
   /*  resequence according to the number of lines in the complete document  */
   /*------------------------------------------------------------------------*/
   sequenceNumber = firstSequenceNumber;
   for (Element element = first(); element != null; element = element.next())
    {
     if (!element.show())
      {
       element.setSequenceNumber(sequenceNumber);
       sequenceNumber += increment;
      }
    }

   _sequenceNumbersValid = true;
   return true;
  }

 /**
  * Sequence numbers settings changed - (re)set sequence numbers in all the
  * elements of the document's element list.
  * Called from SequenceNumbersParameter & Document, with correct values.
  */
 void setSequenceNumbers(int numColumn, int numWidth, int textColumn, int textWidth)
  {
   // go on only if actual change in sequence numbers settings (column or width)
   if (_sequenceNumbersNumWidth  != numWidth  ||
       _sequenceNumbersTextWidth != textWidth ||
       (numWidth > 0  && _sequenceNumbersNumColumn  != numColumn) ||
       (textWidth > 0 && _sequenceNumbersTextColumn != textColumn))
    {
     _document.resetUserActionElements();
     boolean recording = _document.undo().recording();
     _document.undo().setRecording(false);
     View view = _document._firstView;          // access a view of our document
     view.setIgnoreFields();

     /*------------------------------------------------------------------*/
     /* if sequence numbers are currently set, insert them back into the */
     /* actual element text according to the *current* settings          */
     /*------------------------------------------------------------------*/
     if (_sequenceNumbersWidth > 0)
      {
       for (Element element = first(); element != null; element = element.next())
        {
         if (element.show())
          {
           // no text change in show elements, but must still re-set display
           for (ElementView elementView = element._firstElementView;
                elementView != null;
                elementView = elementView._next)
            {
             elementView.resetDisplayText();
            }
          }
         else
          {
           String sequenceNumbersText = getSequenceNumbersString(element);
           if (LpexNls.usingSourceColumns(_document))
            {
             // length of Unicode fullText to keep prior to seq no.s inside DBCS-source
             int len = LpexNls.sourceTruncate(element.text(),
                                              _sequenceNumbersColumn-1, _document);
             // calculate blanks to insert from this len in source-encoding bytes
             int spaces = _sequenceNumbersColumn -
                   LpexNls.sourceLength(element.text().substring(0, len), _document) - 1;
             while (spaces-- > 0)
              {
               sequenceNumbersText = " " + sequenceNumbersText;
              }
             view.insertText(element, len+1, sequenceNumbersText, true);
            }
           else
            {
             view.insertText(element, _sequenceNumbersColumn, sequenceNumbersText, true);
            }
          }
        }
      }

     // dispose of elements' sequenceText if we have a text part no more
     if (_sequenceNumbersTextWidth > 0 && textWidth == 0)
      {
       for (Element element = first(); element != null; element = element.next())
        {
         element.setSequenceText();
        }
      }

     /*---------------------------------------*/
     /* set the new sequence-numbers settings */
     /*---------------------------------------*/
     _sequenceNumbersNumColumn = numColumn;
     _sequenceNumbersNumWidth = numWidth;
     _sequenceNumbersTextColumn = textColumn;
     _sequenceNumbersTextWidth = textWidth;
     // re-set rest of cached sequence-numbers settings
     cacheSequenceNumbersData();
     // & adjust defaultText cached value to the new settings
     sequenceDefaultTextChanged();

     /*----------------------------------------------------------------------*/
     /* if the new setting of sequence numbers is on, delete them from the   */
     /* actual element text according to these *new* settings;  original doc */
     /* text may now be lost if now 'interpreted' as sequence numbers...     */
     /*----------------------------------------------------------------------*/
     if (_sequenceNumbersWidth != 0)
      {
       int prevSequenceNumber = 0;
       for (Element element = first(); element != null; element = element.next())
        {
         if (!element.show())
          {
           String sequenceNumbersText = "";
           if (LpexNls.usingSourceColumns(_document))
            {
             // length of Unicode fullText to keep prior to seq no.s inside DBCS-source
             int len1 = LpexNls.sourceTruncate(element.text(),
                          _sequenceNumbersColumn - 1, _document);
             // length of Unicode fullText to end of seq no.s inside DBCS-source
             int len2 = LpexNls.sourceTruncate(element.text(),
                          _sequenceNumbersColumn - 1 + _sequenceNumbersWidth, _document);

             if (len2 > len1)
              {
               sequenceNumbersText = textSubstring(element, len1, len2);
               view.deleteText(element, len1 + 1, len2 - len1, true);
              }

             // ensure sequenceNumbersText has all the meat for operations below
             while (sequenceNumbersText.length() < _sequenceNumbersWidth)
              {
               sequenceNumbersText += " ";
              }
            }
           else
            {
             sequenceNumbersText =
               textSubstring(element,
                             _sequenceNumbersColumn - 1,
                             _sequenceNumbersColumn - 1 + _sequenceNumbersWidth);
             view.deleteText(element,
                             _sequenceNumbersColumn, _sequenceNumbersWidth, true);
            }

           // set the numeric & text parts of the sequence numbers in the element
           int num = 0;
           if (_sequenceNumbersNumWidth > 0)
            {
             int col1 = _sequenceNumbersNumColumn - _sequenceNumbersColumn;
             try
              {
               num = Integer.parseInt(sequenceNumbersText
                                      .substring(col1, col1 + _sequenceNumbersNumWidth));
              }
             catch(NumberFormatException e) {}
             if (num <= prevSequenceNumber)
              {
               _sequenceNumbersValid = false;
              }
            }
           element.setSequenceNumber(num);
           prevSequenceNumber = num;

           String text = null;
           if (_sequenceNumbersTextWidth > 0)
            {
             int col1 = _sequenceNumbersTextColumn - _sequenceNumbersColumn;
             text = sequenceNumbersText.substring(col1, col1 + _sequenceNumbersTextWidth);
            }
           element.setSequenceText(text);
          }
        }
      }

     // if maintaining the sequence numbers and now on, resequence them
     if (_maintainSequenceNumbers &&
         !_sequenceNumbersValid && _sequenceNumbersNumWidth != 0)
      {
       String messageKey = null;
       if (resequence())
        {
         messageKey = MSG_SEQUENCENUMBERS_RESEQUENCED;
        }
       else
        {
         messageKey = MSG_SEQUENCENUMBERS_OVERFLOW;
         _maintainSequenceNumbers = false;
        }
       for (View v = _document._firstView; v != null; v = v._next)
        {
         v.setLpexMessageText(messageKey);
        }
      }

     // if any view's prefix area is affected, invalidate it as well
     for (View v = _document._firstView; v != null; v = v._next)
      {
       if (PrefixAreaParameter.getParameter().currentValue(v) == true &&
           PrefixAreaTextParameter.getParameter().currentValue(v) ==
             View.PREFIX_AREA_TEXT_SEQUENCENUMBERS)
        {
         v.setPrefixAreaWidthsInvalid(); // re-set prefix area text for all elements
        }
      }

     view.resetIgnoreFields();
     _document.undo().setRecording(recording);
    }
  }

 /**
  * Return a substring of an element's text.
  * Padding with blanks is done for ranges outside the actual text.
  */
 private static String textSubstring(Element element, int beginIndex, int endIndex)
  {
   String text = element.text();
   if (endIndex <= text.length())
    {
     return text.substring(beginIndex, endIndex);
    }
   StringBuffer buffer;
   int end = (endIndex <= text.length())? endIndex : text.length();
   if (beginIndex < end)
    {
     buffer = new StringBuffer(text.substring(beginIndex));
    }
   else
    {
     buffer = new StringBuffer();
    }

   for (int i = buffer.length(); i < endIndex - beginIndex; i++)
    {
     buffer.append(' ');
    }
   return buffer.toString();
  }

 /**
  * Return the sequence-numbers string (numeric + text parts) of an element.
  */
 private String getSequenceNumbersString(Element element)
  {
   if (_sequenceNumbersWidth == 0)
    {
     return "";
    }

   StringBuffer num = null;
   if (_sequenceNumbersNumWidth != 0)
    {
     num = new StringBuffer(String.valueOf(element.sequenceNumber()));
     while (num.length() < _sequenceNumbersNumWidth)
      {
       num.insert(0, '0');
      }
     while (num.length() > _sequenceNumbersNumWidth)
      {
       num.deleteCharAt(0);
      }
    }

   if (_sequenceNumbersTextWidth == 0)
    {
     return num.toString();
    }

   String text = null;
   if (_sequenceNumbersTextWidth > 0)
    {
     text = element.sequenceText();
     while (text.length() < _sequenceNumbersTextWidth)
      {
       text += ' ';
      }
     }

   if (_sequenceNumbersNumWidth == 0)
    {
     return text;
    }

   if (_sequenceNumbersNumColumn < _sequenceNumbersTextColumn)
    {
     return num.append(text).toString();
    }
   return num.insert(0, text).toString();
  }

 /**
  * Return the sequence-numbers string (numeric + text parts) of an element,
  * formatted for display according to the view's sequenceNumbersFormat parameter.
  * If no sequence numbers are set, return an empty String.
  */
 String getSequenceNumbersDisplayString(Element element, View view)
  {
   if (_sequenceNumbersWidth == 0)                   // no sequence numbers.
    {
     return "";
    }
   String sequenceNumbersFormat = view.sequenceNumbersFormat();
   if (sequenceNumbersFormat == null)                // straight, no formatting.
    {
     if (element.show())
      {
       return blanks(_sequenceNumbersWidth);
      }
     return getSequenceNumbersString(element);
    }

   // here (we're formatting), just as good as view._sequenceNumbersFormatStyle:
   String style = view.getSequenceNumbersStyle();

   if (element.show())
    {
     return blanks(style.length());
    }

   StringBuffer formatted = new StringBuffer(style.length());

   // 1.- format text part
   String part = (_sequenceNumbersTextWidth > 0)?
                 element.sequenceText() : "";
   int p = 0;
   for (int i = 0; i < sequenceNumbersFormat.length(); i++)
    {
     char c = sequenceNumbersFormat.charAt(i);
     if (c == 'X')
      {
       if (p < part.length())
        {
         formatted.append(part.charAt(p++));
        }
       else
        {
         formatted.append(' ');
        }
      }
     else if (c == '9')
      {
       formatted.append('0');
      }
     else
      {
       if (c == '\\' && i < sequenceNumbersFormat.length()-1)
        {
         c = sequenceNumbersFormat.charAt(++i);
        }
       formatted.append(c);
      }
    }

   // 2.- format numeric part
   part = (_sequenceNumbersNumWidth > 0)?
          String.valueOf(element.sequenceNumber()) : "";
   p = part.length()-1;
   for (int i = style.length() - 1; i >= 0 && p >= 0; i--)
    {
     if (style.charAt(i) == Screen.CHAR_STYLE_SEQUENCE_NUMBER)
      {
       formatted.setCharAt(i, part.charAt(p--));
      }
    }

   return formatted.toString();
  }

 private String blanks(int n)
  {
   StringBuffer buffer = new StringBuffer(n);
   for (; n > 0; n--)
    {
     buffer.append(' ');
    }
   return buffer.toString();
  }

 /**
  * Add the sequence numbers, if "on", to the [trimmed] text of the given
  * element in this ElementList.
  *
  * @see #addDisplaySequenceNumbers
  */
 String addSequenceNumbers(Element element, String text)
  {
   if (text == null)
      text = "";

   String sequenceNumbers = getSequenceNumbersString(element);
   if (sequenceNumbers.length() == 0)                     // no sequence numbers
    {
     return text;
    }

   // add the sequence numbers to the text
   StringBuffer fullText = new StringBuffer(text);
   int len, spaces, colIndex;

   /*---------------------------------*/
   /*  1.- DBCS/MBCS source encoding  */
   /*---------------------------------*/
   if (LpexNls.usingSourceColumns(_document))
    {
     // length of Unicode fullText to keep prior to seq no.s inside DBCS-source
     len = LpexNls.sourceTruncate(text, _sequenceNumbersColumn-1, _document);
     // calculate blanks to insert from this len in source-encoding bytes
     spaces = _sequenceNumbersColumn -
              LpexNls.sourceLength(text.substring(0, len), _document) - 1;
     // and offset to insert the sequenceNumbers into the Unicode text
     colIndex = len + spaces;
    }

   /*--------------------------*/
   /*  2.- stick with Unicode  */
   /*--------------------------*/
   else
    {
     // length of the element's text
     len = fullText.length();
     // blanks to insert if the sequence numbers are beyond end of the text
     spaces = _sequenceNumbersColumn - len - 1;
     // offset to insert the sequenceNumbers
     colIndex = _sequenceNumbersColumn - 1;
    }

   for (; spaces > 0; spaces--)
    {
     fullText.insert(len, ' ');
    }

   return fullText.insert(colIndex, sequenceNumbers).toString();
  }

 /**
  * Adds the sequence numbers to the text of the given element in this ElementList.
  * Called when view's currentHideSequenceNumbers is "off", and documents's
  * sequenceNumbersWidth > 0.
  * Formats the sequence numbers for display, according to the view's
  * sequenceNumbersFormat parameter.
  *
  * @see #addSequenceNumbers
  */
 DisplayString addDisplaySequenceNumbers(Element element, View view)
  {
   DisplayString displayString = new DisplayString();
   String text = element.text();
   String sequenceNumbers = getSequenceNumbersDisplayString(element, view);
   if (sequenceNumbers.length() == 0)   // empty sequence-numbers format String
    {
     displayString.text = text;
     displayString.sequenceNumbersPosition = 0;
     return displayString;
    }

   // add the sequence numbers to the text
   StringBuffer fullText = new StringBuffer(text);
   int len, spaces, colIndex;

   /*---------------------------------*/
   /*  1.- DBCS/MBCS source encoding  */
   /*---------------------------------*/
   if (LpexNls.usingSourceColumns(_document))
    {
     // length of Unicode fullText to keep prior to seq no.s inside DBCS-source
     len = LpexNls.sourceTruncate(text, _sequenceNumbersColumn-1, _document);
     // calculate blanks to insert from this len in source-encoding bytes
     spaces = _sequenceNumbersColumn -
              LpexNls.sourceLength(text.substring(0, len), _document) - 1;
     // and offset to insert the sequenceNumbers into the Unicode text
     colIndex = len + spaces;
    }

   /*--------------------------*/
   /*  2.- stick with Unicode  */
   /*--------------------------*/
   else
    {
     // length of the element's text
     len = fullText.length();
     // blanks to insert if the sequence numbers are beyond end of the text
     spaces = _sequenceNumbersColumn - len - 1;
     // offset to insert the sequenceNumbers
     colIndex = _sequenceNumbersColumn - 1;
    }

   for (; spaces > 0; spaces--)
    {
     fullText.insert(len, ' ');
    }

   displayString.text = fullText.insert(colIndex, sequenceNumbers).toString();
   displayString.sequenceNumbersPosition = colIndex + 1;
   return displayString;
  }

 /**
  * (Re-)establish cached sequence-numbers information.
  */
 private void cacheSequenceNumbersData()
  {
   // _sequenceNumbersWidth: width of the file's sequence numbers
   _sequenceNumbersWidth = _sequenceNumbersNumWidth + _sequenceNumbersTextWidth;

   // _sequenceNumbersColumn: starting column of the file's sequence numbers
   if (_sequenceNumbersNumWidth != 0 && _sequenceNumbersTextWidth != 0)
    {
     _sequenceNumbersColumn =             // both numbers & text: first's column
        Math.min(_sequenceNumbersNumColumn, _sequenceNumbersTextColumn);
    }
   else
    {                                     // either numbers or text or none
     _sequenceNumbersColumn = (_sequenceNumbersNumWidth != 0)?
                               _sequenceNumbersNumColumn : _sequenceNumbersTextColumn;
    }

   // _maxSequenceNumber:  max. sequence number allowed (i.e., that fits)
   _maxSequenceNumber = 1;
   for (int i = 0; i < _sequenceNumbersNumWidth; i++)
    {
     if (_maxSequenceNumber == 1000000000)
      {
       break; // (shouldn't happen, numWidth is <= 9)
      }
     _maxSequenceNumber *= 10;
    }
   _sequenceNumbersValid = true;

   // _sequenceNumbersStyle:  style string for the sequence-numbers settings
   if (_sequenceNumbersWidth == 0)
    {
     _sequenceNumbersStyle = "";
     return;
    }

   StringBuffer buffer = new StringBuffer();
   if (_sequenceNumbersNumWidth > 0)
    {
     while (buffer.length() < _sequenceNumbersNumWidth)
      {
       buffer.append(Screen.CHAR_STYLE_SEQUENCE_NUMBER);
      }
     if (_sequenceNumbersTextWidth > 0)
      {
       if (_sequenceNumbersNumColumn < _sequenceNumbersTextColumn)
        {
         for (int i = 0; i < _sequenceNumbersTextWidth; i++)
          {
           buffer.append(Screen.CHAR_STYLE_SEQUENCE_TEXT);
          }
        }
       else
        {
         for (int i = 0; i < _sequenceNumbersTextWidth; i++)
          {
           buffer.insert(0, Screen.CHAR_STYLE_SEQUENCE_TEXT);
          }
        }
      }
    }
   else // sequence numbers with text part only
    {
     while (buffer.length() < _sequenceNumbersTextWidth)
      {
       buffer.append(Screen.CHAR_STYLE_SEQUENCE_TEXT);
      }
    }
   _sequenceNumbersStyle = buffer.toString();
  }

 int sequenceNumbersColumn()
  {
   return _sequenceNumbersColumn;
  }

 int sequenceNumbersWidth()
  {
   return _sequenceNumbersWidth;
  }

 int sequenceNumbersNumColumn()
  {
   return _sequenceNumbersNumColumn;
  }

 int sequenceNumbersNumWidth()
  {
   return _sequenceNumbersNumWidth;
  }

 int sequenceNumbersTextColumn()
  {
   return _sequenceNumbersTextColumn;
  }

 int sequenceNumbersTextWidth()
  {
   return _sequenceNumbersTextWidth;
  }

 /**
  * Return a style string for the current sequenceNumbers settings.
  * For a view in which sequenceNumbersFormat was set, the style will differ:
  * see View.getSequenceNumbersStyle().
  */
 String sequenceNumbersStyle()
  {
   return _sequenceNumbersStyle;
  }

 /**
  * Set the sequenceNumber number for an element.
  */
 void setSequenceNumber(View view, Element element, int sequenceNumber)
  {
   if (element.show())
    {
     view.setLpexMessageText(MSG_SEQUENCENUMBERS_SHOWELEMENT);
    }
   else if (sequenceNumber >= _maxSequenceNumber)
    {
     view.setLpexMessageText(MSG_SEQUENCENUMBERS_TOOBIG, sequenceNumber);
    }
   else
    {
     if (_sequenceNumbersValid)
      {
       Element prev = element.prevNonShow();
       Element next = element.nextNonShow();
       if ((prev != null && prev.sequenceNumber() >= sequenceNumber) ||
           (next != null && next.sequenceNumber() <= sequenceNumber))
        {
         _sequenceNumbersValid = false;
         if (_maintainSequenceNumbers)
          {
           _maintainSequenceNumbers = false;
           view.setLpexMessageText(MSG_SEQUENCENUMBERS_OUTOFORDER, sequenceNumber);
          }
        }
      }
     element.setSequenceNumber(sequenceNumber);
    }
  }

 /**
  * Set the value of the sequenceDefaultText parameter.
  */
 void setSequenceDefaultTextParm(String newParameterValue)
  {
   _sequenceDefaultTextParm = newParameterValue;
  }

 String sequenceDefaultText()
  {
   return _sequenceDefaultText;
  }

 /**
  * Adjust (pad / truncate) the current default text string to the new current
  * sequence-numbers settings (sequenceDefaultText and text-part width) in effect.
  */
 void sequenceDefaultTextChanged()
  {
   if (_sequenceNumbersTextWidth == 0)
    {
     _sequenceDefaultText = null;
    }
   else
    {
     _sequenceDefaultText =
       SequenceDefaultTextParameter.getParameter().currentValue(_document._firstView);
     if (_sequenceDefaultText == null)
      {
       _sequenceDefaultText = " ";
      }
     while (_sequenceDefaultText.length() < _sequenceNumbersTextWidth)
      {
       _sequenceDefaultText += ' ';
      }
     if (_sequenceDefaultText.length() > _sequenceNumbersTextWidth)
      {
       _sequenceDefaultText = _sequenceDefaultText.substring(0, _sequenceNumbersTextWidth);
      }
    }
  }

 /**
  * Find the element with a certain sequenceNumber number.
  */
 Element findSequenceNumber(int sequenceNumber)
  {
   if (_sequenceNumbersNumWidth > 0)
    {
     for (Element element = first(); element != null; element = element.next())
      {
       if (!element.show() && element.sequenceNumber() == sequenceNumber)
        {
         return element;
        }
      }
    }

   return null;
  }

 int textLimit()
  {
   return _textLimit;
  }

 void setTextLimit(View view, int textLimit)
  {
   _textLimit = textLimit;
   if (_textLimit > 0)
    {
     for (Element element = first(); element != null; element = element.next())
      {
       if (!element.show() && saveLength(element) > _textLimit)
        {
         view.setLpexMessageText(MSG_TEXTLIMIT_OVERFLOW);
         break;
        }
      }
    }
  }

 /**
  * Return the length of an element's text in a file-save operation (assuming
  * trimmed text, and including the sequence numbers).
  * For DBCS/MBCS source encodings with useSourceColumns <code>on</code>, the
  * save length returned is the number of *bytes* of the saved source text.
  * Used for textLimit checks.
  */
 int saveLength(Element element)
  {
   // initialize to length of element's text trimmed of trailing blanks
   int saveLength = element.length();
   if (saveLength > 0)
    {
     String text = element.text();
     for (int i = saveLength - 1; i >= 0 && text.charAt(i) == ' '; i--)
      {
       saveLength--;
      }
    }

   if (LpexNls.usingSourceColumns(_document))
    {
     // get the element text trimmed of trailing blanks
     String trimmedText = (saveLength == 0)? "" : element.text().substring(0, saveLength);

     if (_sequenceNumbersWidth > 0)
      {
       // DBCS/MBCS source encodings - if sequence numbers are in middle of the
       // text, a good truncation point for the first part of the text is found,
       // which may add SO/SIs, spaces + the sequence numbers are then inserted,
       // etc.  Best way to find out the length in bytes of the result may be to
       // just look at the resulting text converted to the source encoding...
       trimmedText = addSequenceNumbers(element, trimmedText);
      }
     saveLength = LpexNls.sourceLength(trimmedText, _document);
    }
   else
    {
     if (_sequenceNumbersWidth > 0)
      {
       if (_sequenceNumbersColumn <= saveLength)
        {
         saveLength += _sequenceNumbersWidth;
        }
       else
        {
         saveLength = _sequenceNumbersColumn + _sequenceNumbersWidth - 1;
        }
      }
    }

   return saveLength;
  }

 /**
  * Return the length in Unicode characters of an element's full text
  * (i.e., including sequence numbers).
  * Used by CompareCommand.
  */
 int fullTextLength(Element element)
  {
   int fullTextLength = element.length();

   if (_sequenceNumbersWidth > 0)
    {
     if (LpexNls.usingSourceColumns(_document))
      {
       fullTextLength += _sequenceNumbersColumn - 1 -
          LpexNls.sourceTruncate(element.text(), _sequenceNumbersColumn-1, _document) +
          _sequenceNumbersWidth;
      }
     else
      {
       if (_sequenceNumbersColumn <= fullTextLength)
        {
         fullTextLength += _sequenceNumbersWidth;
        }
       else
        {
         fullTextLength = _sequenceNumbersColumn + _sequenceNumbersWidth - 1;
        }
      }
    }

   return fullTextLength;
  }

 /**
  * Retrieve an element's full text, i.e., including sequence numbers if "on".
  */
 String fullText(Element element)
  {
   return addSequenceNumbers(element, element.text());
  }
}