//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FieldsParameter - handles the fields parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>fields</b> parameter.
 */
final class FieldsParameter extends Parameter
{
 private static FieldsParameter _parameter;

 static FieldsParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new FieldsParameter();
   }
  return _parameter;
 }

 private FieldsParameter()
 {
  super(PARAMETER_FIELDS);
 }

 boolean set(View view, String qualifier, String parameters)
 {
  int count = 0;
  int lastField = 0;

  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  while (st.hasMoreTokens())
   {
    String token = st.nextToken();
    try
     {
      int field = Integer.parseInt(token);
      if (field <= lastField)
       {
        return CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
       }
      count++;
      lastField = field;
     }
    catch(NumberFormatException e)
     {
      return CommandHandler.invalidParameter(view, token, "set " + name(qualifier));
     }
    // avoid problems with NumberFormatException above when compiled
    // with HPJ using no null checking option
    catch(java.lang.Exception e2) {}
   }

  int fields[] = null;
  if (count > 0)
   {
    fields = new int[count];
    st = new LpexStringTokenizer(parameters);
    for (int i = 0; i < count; i++)
     {
      try
       {
        fields[i] = Integer.parseInt(st.nextToken());
       }
      catch(NumberFormatException e) {}
     }
   }

  if (view != null)
   {
    view.setFields(fields);
   }

  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    int fields[] = view.fields();
    if (fields != null)
     {
      boolean first = true;
      StringBuffer queryString = new StringBuffer(120);
      for (int i = 0; i < fields.length; i++)
       {
        if (!first)
         {
          queryString.append(' ');
         }
        first = false;
        queryString.append(fields[i]);
       }
      return queryString.toString();
     }
   }

  return null;
 }
}