//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexDocumentLocation - represents a location in the document.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class is used to represent a location in a document (or in the document
 * section that is currently loaded in the editor).
 *
 * @see LpexView
 */
public class LpexDocumentLocation
{
 /**
  * The element number.
  * The number of the first document element is 1.
  */
 public int element;

 /**
  * The position within the element.
  * The position of the first character within an element is 1.
  */
 public int position;

 /**
  * This constructor creates a document location object for the
  * given <code>position</code> in the specified <code>element</code>.
  */
 public LpexDocumentLocation(int element, int position)
 {
  this.element  = element;
  this.position = position;
 }

 /**
  * This constructor creates a document location object representing the same
  * location as the specified <code>documentLocation</code>.
  */
 public LpexDocumentLocation(LpexDocumentLocation documentLocation)
 {
  this(documentLocation.element, documentLocation.position);
 }

 /**
  * Return a String representation of this LpexDocumentLocation suitable for
  * debugging purposes.
  */
 public String toString()
 {
  return "LpexDocumentLocation[" + element + "," + position + "]";
 }
}