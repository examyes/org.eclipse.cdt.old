//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Match - handles bracket matching.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Match parentheses, braces, square brackets, angle brackets.
 */
public final class LpexMatch
{
   private static final String DEFAULT_BRA = "({[<", DEFAULT_KET = ")}]>";

   /**
    * Match a paranthesis / brace / square bracket / angle bracket.
    * No error messages are issued.
    * This method is intended primarily for use by other classes.
    *
    * @param view document view
    * @param loc document location of the character to match
    *
    * @return the matching document location, or <code>null</code> if none
    */
   public static LpexDocumentLocation match (LpexView view, LpexDocumentLocation loc)
   {
      return match(view, loc, false);
   }

   /**
    * Match a paranthesis / brace / square bracket / angle bracket.
    *
    * @param view document view
    * @param loc document location of the character to match
    * @param noisy true = issue error messages if any problems
    *
    * @return the matching document location, or <code>null</code> if none
    */
   public static LpexDocumentLocation match (LpexView view, LpexDocumentLocation loc,
                                             boolean noisy)
   {
      int i = loc.position-1;              // char index in the text
      if (i < 0)
         return null;                      // bad parameter...

      int element = loc.element;
      String text = view.elementText(element);
      int len = text.length();
      if (i >= len)
         return null;                      // beyond the text, nothing to match.

      int j;
      int dir = 1;                         // forward = +1, backward = -1
      char bracket = text.charAt(i), match;
      if ((j = DEFAULT_BRA.indexOf(bracket)) >= 0)
         match = DEFAULT_KET.charAt(j);
      else if ((j = DEFAULT_KET.indexOf(bracket)) >= 0) {
         match = DEFAULT_BRA.charAt(j);
         dir = -1;
         }
      else {
         if (noisy)
            view.doDefaultCommand("set messageText " +
                                  LpexResources.message("match.char", String.valueOf(bracket)));
         return null;
         }

      String style = view.elementStyle(element);
      char fnt = (style.length() > i)? style.charAt(i) : '!';

      int elements = view.elements();
      for (int nesting=0; ; i = (dir > 0)? 0 : len-1) {
         for (; (dir > 0)? i < len : i >= 0;  i+=dir) {
            char ch = text.charAt(i);                 // char & style must match
            char ft = (style.length() > i)? style.charAt(i) : '!';
            if (ft == fnt && ch == bracket) {
               nesting++;                                 // go one level deeper
               }
            else if (ft == fnt && ch == match)
               if (--nesting == 0) {
                  return new LpexDocumentLocation(element, i+1); // found match.
                  }
            }

         element += dir;
         if (element < 1 || element > elements)
            break;
         text  = view.elementText(element);
         style = view.elementStyle(element);
         len   = text.length();
         }

      if (noisy)
         view.doDefaultCommand("set messageText " +
                               LpexResources.message((dir > 0)? "match.end" : "match.start"));
      return null;
   }
}