//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LocateCommand - implements the locate command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>locate</b> command.
 */
final class LocateCommand
{
 static boolean doCommand(View view, String parameters)
  {
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (!st.hasMoreTokens())
    {
     return CommandHandler.noParameters(view, "locate");
    }

   boolean emphasis = false;
   String token = st.nextToken();
   if (token.equals("emphasis"))
    {
     emphasis = true;
     if (!st.hasMoreTokens())
      {
       return CommandHandler.incomplete(view, "locate");
      }
     token = st.nextToken();
    }

   if (token.equals("element"))
    {
     return locateElement(view, st, emphasis);
    }
   if (token.equals("line"))
    {
     return locateLine(view, st, emphasis);
    }
   if (token.equals("mark"))
    {
     return locateMark(view, st, emphasis);
    }
   if (token.equals("sequenceNumber"))
    {
     return locateSequenceNumber(view, st, emphasis);
    }
   if (token.equals("sequenceText"))
    {
     return locateSequenceText(view, st, emphasis);
    }

   return CommandHandler.invalidParameter(view, token, "locate");
  }

 /**
  * Handle command
  *   <b>locate element</b>.
  * Find an element inside the (complete) document.
  */
 private static boolean locateElement(View view, LpexStringTokenizer st, boolean emphasis)
  {
   if (!st.hasMoreTokens())
    {
     return CommandHandler.incomplete(view, "locate element");
    }

   String token = st.nextToken();
   try
    {
     // get the complete-document element to locate
     int element = Integer.parseInt(token);
     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "locate element");
      }

     // command format correct, now run it if there is a view
     if (view != null)
      {
       // check & trigger expansion of currently-loaded document section
       view.verifyDocumentSectionElement(element);

       // adjust from complete doc -> currently-loaded [newly-expanded] doc section
       element -= view.document().linesBeforeStart();

       CommandHandler._status = null;
       if (element < 1 || element > view.document().elementList().count())
        {
         view.setLpexMessageText(LpexConstants.MSG_LOCATECOMMAND_ELEMENTNOTFOUND, element);
         CommandHandler._status = LpexConstants.STATUS_LOCATE_NOTFOUND;
        }
       else
        {
         Element e = view.document().elementList().elementAt(element);
         if (e != null)
          {
           view.documentPosition().jump(e, 1);
           if (emphasis)
            {
             int len = e.length();
             if (len == 0)
              {
               len = 1;
              }
             view.documentPosition().setEmphasisLength(len);
            }
          }
        }
      }
    }
   catch(NumberFormatException e)
    {
     return CommandHandler.invalidParameter(view, token, "locate element");
    }

   return true;
  }

 /**
  * Handle command
  *   <b>locate line</b>.
  * Find a line inside the (complete) document.
  */
 private static boolean locateLine(View view, LpexStringTokenizer st, boolean emphasis)
  {
   if (!st.hasMoreTokens())
    {
     return CommandHandler.incomplete(view, "locate line");
    }

   String token = st.nextToken();
   try
    {
     // get the complete-document line to locate
     int line = Integer.parseInt(token);
     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "locate line");
      }

     // command format correct, now run it if there is a view
     if (view != null)
      {
       // check & trigger expansion of currently-loaded document section
       view.verifyDocumentSectionLine(line);

       // adjust from complete doc -> currently-loaded [newly-expanded] doc section
       line -= view.document().linesBeforeStart();

       CommandHandler._status = null;
       if (line < 1 || line > view.document().elementList().nonShowCount())
        {
         view.setLpexMessageText(LpexConstants.MSG_LOCATECOMMAND_LINENOTFOUND, line);
         CommandHandler._status = LpexConstants.STATUS_LOCATE_NOTFOUND;
        }
       else
        {
         Element e = view.document().elementList().nonShowElementAt(line);
         if (e != null)
          {
           view.documentPosition().jump(e, 1);
           if (emphasis)
            {
             int len = e.length();
             if (len == 0)
              {
               len = 1;
              }
             view.documentPosition().setEmphasisLength(len);
            }
          }
        }
      }
    }
   catch(NumberFormatException e)
    {
     return CommandHandler.invalidParameter(view, token, "locate line");
    }

   return true;
  }

 /**
  * Handle command
  *   <b>locate mark</b>.
  * Locate a mark inside the currently-loaded document section.
  */
 private static boolean locateMark(View view, LpexStringTokenizer st, boolean emphasis)
  {
   if (!st.hasMoreTokens())
    {
     return CommandHandler.incomplete(view, "locate mark");
    }

   String token = st.nextToken();
   if (st.hasMoreTokens())
    {
     return CommandHandler.invalidParameter(view, st.nextToken(), "locate mark");
    }

   if (view != null)
    {
     CommandHandler._status = null;
     MarkList.Mark mark = view.markList().find(token);
     if (mark != null)
      {
       view.documentPosition().jump(mark.documentLocation());
       if (emphasis)
        {
         view.documentPosition().setEmphasisLength(1);
        }
      }
     else
      {
       view.setLpexMessageText(LpexConstants.MSG_LOCATECOMMAND_MARKNOTFOUND, token);
       CommandHandler._status = LpexConstants.STATUS_LOCATE_NOTFOUND;
      }
    }
   return true;
  }

 /**
  * Handle command
  *   <b>locate sequenceNumber</b>.
  * Locate a sequence number inside the currently-loaded document section.
  */
 private static boolean locateSequenceNumber(View view, LpexStringTokenizer st, boolean emphasis)
  {
   if (!st.hasMoreTokens())
    {
     return CommandHandler.incomplete(view, "locate sequenceNumber");
    }

   String token = st.nextToken();
   try
    {
     int sequenceNumber = Integer.parseInt(token);
     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "locate sequenceNumber");
      }

     if (view != null)
      {
       CommandHandler._status = null;
       Element e = view.document().elementList().findSequenceNumber(sequenceNumber);
       if (e == null)
        {
         view.setLpexMessageText(LpexConstants.MSG_LOCATECOMMAND_SEQUENCENUMBERNOTFOUND,
                                 sequenceNumber);
         CommandHandler._status = LpexConstants.STATUS_LOCATE_NOTFOUND;
        }
       else
        {
         view.documentPosition().jump(e, 1);
         if (emphasis)
          {
           int len = e.length();
           if (len == 0)
            {
             len = 1;
            }
           view.documentPosition().setEmphasisLength(len);
          }
        }
      }
    }
   catch(NumberFormatException e)
    {
     return CommandHandler.invalidParameter(view, token, "locate sequenceNumber");
    }

   return true;
  }

 /**
  * Handle command
  *   <b>locate sequenceText</b>.
  * Locate a sequence text [in range] inside the currently-loaded document
  * section.
  *
  * Note that presently the string parameters cannnot be quoted.
  */
 private static boolean locateSequenceText(View view, LpexStringTokenizer st, boolean emphasis)
  {
   if (!st.hasMoreTokens())
    {
     return CommandHandler.incomplete(view, "locate sequenceText");
    }

   /*------------------------------------------------------------------------*/
   /*  extract "from" and optional "to" string(s), one range at a time:      */
   /*  str [to str [str [to str]]]  (C++ LPEX: str [to str] [str [to str]])  */
   /*------------------------------------------------------------------------*/
   String from[] = {"", ""};
   String to[] = {"", ""};
   int ranges = 0;

   while (st.hasMoreTokens())
    {
     if (ranges == 2)
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "locate sequenceText");
      }
     from[ranges] = st.nextToken();
     if (st.hasMoreTokens())
      {
       String token = st.nextToken();
       if (!token.equals("to"))
        {
         return CommandHandler.invalidParameter(view, token, "locate sequenceText");
        }
       if (!st.hasMoreTokens())
        {
         return CommandHandler.incomplete(view, "locate sequenceText");
        }
       to[ranges] = st.nextToken();
      }
     else
      {
       to[ranges] = from[ranges];
      }
     ranges++;
    }

   CommandHandler._status = null;
   if (view == null)
    {
     return true;
    }

   if (view.document().elementList().sequenceNumbersTextWidth() == 0)
    {
     view.setLpexMessageText(LpexConstants.MSG_LOCATECOMMAND_NOSEQUENCETEXT);
     CommandHandler._status = LpexConstants.STATUS_LOCATE_NOSEQUENCETEXT;
     return true;
    }

   for (int i = 0; i < ranges; i++)
    {
     if (from[i].compareTo(to[i]) > 0)
      {
       String temp = from[i];
       from[i] = to[i];
       to[i] = temp;
      }
    }

   /*----------------------------*/
   /*  locate the sequence text  */
   /*----------------------------*/
   boolean found = false;
   boolean wrapped = false;
   Element e = view.documentPosition().element();
   e = (e == null)? null : e.next();
   Element lastElementAfterWrap = e;
   for (;;)
    {
     if (e == null && !wrapped)
      {
       e = view.document().elementList().first();
       wrapped = true;
      }
     if (e == null || (wrapped && e == lastElementAfterWrap))
      {
       break;
      }
     if (!e.show())
      {
       String sequenceText = e.sequenceText();
       if (sequenceText != null)
        {
         for (int i = 0; i < ranges; i++)
          {
           if (sequenceText.compareTo(from[i]) >= 0  &&
               sequenceText.compareTo(to[i])   <= 0)
            {
             found = true;
             break;
            }
          }
        }
       if (found)
        {
         break;
        }
      }
     e = e.next();
    }

   if (found)
    {
     view.documentPosition().jump(e, 1);
     if (emphasis)
      {
       int len = e.length();
       if (len == 0)
        {
         len = 1;
        }
       view.documentPosition().setEmphasisLength(len);
      }
     if (wrapped)
      {
       CommandHandler._status = LpexConstants.STATUS_LOCATE_WRAPPED;
      }
    }
   else
    {
     String searchText = from[0] + " to " + to[0];
     if (ranges == 2)
      {
       searchText += " " + from[1] + " to " + to[1];
      }
     view.setLpexMessageText(LpexConstants.MSG_LOCATECOMMAND_SEQUENCETEXTNOTFOUND, searchText);
     CommandHandler._status = LpexConstants.STATUS_LOCATE_NOTFOUND;
    }

   return true;
  }
}