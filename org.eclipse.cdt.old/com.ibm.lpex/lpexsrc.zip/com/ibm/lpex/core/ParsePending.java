//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParsePending - represents one parse-pending element
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ParsePending extends ListNode
{
 private Element _element;
 private int _type;

 ParsePending(Element element, int type)
 {
  _element = element;
  _type = type;
 }

 Element element()
 {
  return _element;
 }

 void addType(int type)
 {
  _type |= type;
 }

 int type()
 {
  return _type;
 }
}