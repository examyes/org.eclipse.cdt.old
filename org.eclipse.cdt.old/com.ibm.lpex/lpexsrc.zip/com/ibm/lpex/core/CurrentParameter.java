//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CurrentParameter - handles "query current.xxx" for an editor parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>current</b> parameter.
 *
 * This is a query-only parameter for editor parameters which
 * support a <b>current</b> setting.  Examples:
 * <pre>
 *   <b>query current.statusLine</b>,
 *   <b>query current.updateProfile.palette</b>. </pre>
 */
final class CurrentParameter extends ParameterQuery
{
 private static CurrentParameter _parameter;

 static CurrentParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new CurrentParameter();
   }
  return _parameter;
 }

 private CurrentParameter()
 {
  super(PARAMETER_CURRENT);
 }

 /**
  * <b>query current.xxx</b>
  */
 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  Parameter p = Parameters.getParameter(qualifier);
  if (p != null && p.hasCurrentSetting())
   {
    return p.queryCurrent(view, Parameters.getQualifierString(qualifier));
   }
  return null; // no such parm / parm doesn't support a "current." setting
 }
}