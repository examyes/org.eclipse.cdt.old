//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// UseSourceColumnsParameter - handles the useSourceColumns parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;


//-as- to support in the fields parameter, find/replace range columns,
//     HLASM & JCL parsers


/**
 * This class implements the <b>useSourceColumns</b> parameter.
 * The Parameter class it extends provides the framework for handling
 * parameters in LPEX (setting install values, commands SET and QUERY, etc.).
 */
final class UseSourceColumnsParameter extends ParameterOnOffDefault
{
   /**
    * Singleton UseSourceColumnsParameter (static _parameter) object handles
    * (by occasionally delegating to Document) useSourceColumns for all the
    * documents (note that all its methods have a View argument passed in).
    *
    * The actual value of a view's useSourceColumns is stored in the Document
    * (_useSourceColumns, initialized to Parameter.DEFAULT).
    */
   private static UseSourceColumnsParameter _parameter;


   static UseSourceColumnsParameter getParameter()
   {
      if (_parameter == null)
         _parameter = new UseSourceColumnsParameter();
      return _parameter;
   }

   /**
    * Private constructor - UseSourceColumnsParameter is not instantiated
    * directly, but via a first call to UseSourceColumnsParameter.getParameter().
    */
   private UseSourceColumnsParameter()
   {
      // construct a Parameter.OnOffDefault with the _name
      // PARAMETER_USE_SOURCE_COLUMNS, and a _hardCodedValue = true (ON).
      super(PARAMETER_USE_SOURCE_COLUMNS, true);
   }

   /**
    * Set the useSourceColumns parameter for this view's document.
    *
    * @param value Parameter.ON, .OFF, .DEFAULT (one of .ON, .OFF, .INSTALL)
    */
   boolean setValue(View view, int value)
   {
      if (view != null) {
         boolean oldValue = currentValue(view);
         view.document().setUseSourceColumns(value);
         if (oldValue != currentValue(view))
            view.document().useSourceColumnsChanged();
         }
      return true;
   }

   /**
    * Handle the notification of a change in the actual true/false value of
    * the document's useSourceColumns parameter, by delegating it to the
    * Document.useSourceColumnsChanged().
    */
   void currentValueChanged(View view)
   {
      view.document().useSourceColumnsChanged();
   }

   /**
    * Get the useSourceColumns parameter, through Document.useSourceColumns().
    *
    * @return Parameter.ON, .OFF, .DEFAULT (in .ON, .OFF, .INSTALL), .INSTALL
    */
   int value(View view)
   {
      return (view != null)? view.document().useSourceColumns() : DEFAULT;
   }

   /**
    * Get the useSourceColumns parameter, through Document.useSourceColumns().
    *
    * @return Parameter.ON, .OFF, .DEFAULT (in .ON, .OFF, .INSTALL), .INSTALL
    */
   int value(Document doc)
   {
      return (doc != null)? doc.useSourceColumns() : DEFAULT;
   }

   /**
    * Retrieve the effective true/false current value of the useSourceColumns
    * setting for this document.
    * A necessary adaptation of Parameter.OnOffDefault's currentValue(View) for
    * document-scoped parameters...
    */
   boolean currentValue(Document doc)
   {
      int value = value(doc);
      if (value == DEFAULT) {
         value = defaultValue();
         if (value == INSTALL)
            return installValue();
         }

      return (value == ON);
   }

   //-as- ParameterOnOffDefault assumes scope = view, so it iterates through all
   // the views of all documents to check & call currentValueChanged()...
   // May want to separate that code so that we can override here & skip this
   // all-the-views part - we're document scoped! (see another way to do it in
   // SequenceNumbersParameter.java)
}