//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// InstallProfileParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class InstallProfileParameter extends ParameterWordOnly
{
 private static InstallProfileParameter _parameter;

 static InstallProfileParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new InstallProfileParameter();
   }
  return _parameter;
 }

 private InstallProfileParameter()
 {
  super(PARAMETER_INSTALL_PROFILE);
 }

 boolean setValue(View view, String qualifier, String value)
 {
  Install.setName(value);
  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return Install.name();
 }
}