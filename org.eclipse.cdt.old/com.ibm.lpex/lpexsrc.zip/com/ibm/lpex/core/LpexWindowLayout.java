//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexWindowLayout - lays out the various components of the LPEX window.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Layout;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.widgets.Control;


/**
 * This class manages the layout for the LpexWindow.
 */
final class LpexWindowLayout extends Layout
{
   /**
    * Compute the size of the LpexWindow.
    *
    * SWT: This method computes the minimum size that the client area of the
    * composite must be in order to position all children at their minimum size
    * inside the composite according the layout algorithm.  When a width or
    * height hint is supplied, it is used to constrain the result.
    *
    * @param parent parent composite widget
    * @param widthHint width (DEFAULT for minimim)
    * @param heightHint height (DEFAULT for minimum)
    * @param flushCache flush cached layout values
    */
   protected Point computeSize(Composite parent, int wHint, int hHint, boolean flushCache)
   {
      LpexWindow lpexWindow = (LpexWindow)parent;

      Composite statusLine = lpexWindow.statusLine();
      Point statusLinePreferredSize = statusLine.computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);

      Composite separator0 = lpexWindow.separator0();
      Point separator0PreferredSize = separator0.computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);

      Composite formatLine = lpexWindow.formatLine();
      Point formatLinePreferredSize = formatLine.computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);

      Composite separator1 = lpexWindow.separator1();
      Point separator1PreferredSize = separator1.computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);

      Composite textWindow = lpexWindow.textWindow();
      Point textWindowPreferredSize = textWindow.computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);

      Composite messageLine = lpexWindow.messageLine();
      Point messageLinePreferredSize = messageLine.computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);

      Composite commandLine = lpexWindow.commandLine();
      Point commandLinePreferredSize = commandLine.computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);

      int width = 0;
      int height = 0;

      if (statusLine.getVisible())
       {
        width = statusLinePreferredSize.x;
        if (separator0PreferredSize.x > width)
         {
          width = separator0PreferredSize.x;
         }
        height += statusLinePreferredSize.y + separator0PreferredSize.y;
       }

      if (formatLine.getVisible())
       {
        if (formatLinePreferredSize.x > width)
         {
          width = formatLinePreferredSize.x;
         }
        height += formatLinePreferredSize.y + separator1PreferredSize.y;
       }

      if (textWindowPreferredSize.x > width)
       {
        width = textWindowPreferredSize.x;
       }
      height += textWindowPreferredSize.y;

      if (messageLine.getVisible())
       {
        if (messageLinePreferredSize.x > width)
         {
          width = messageLinePreferredSize.x;
         }
        height += messageLinePreferredSize.y;
       }

      if (commandLine.getVisible())
       {
        if (commandLinePreferredSize.x > width)
         {
          width = commandLinePreferredSize.x;
         }
        height += commandLinePreferredSize.y;
       }

   return new Point(width, height);
   }

   /**
    * Layout the children of the LpexWindow composite.
    *
    * SWT: This method lays out children of a composite using the layout algorithm
    * encoded by the class.  Children of the composite are positioned in the
    * client area of the composite.  The position of the composite is not altered
    * by this method.  When the flush cache hint is true, the layout is instructed
    * to flush any cached values associated with the children.
    *
    * Typically, a layout will cache the preferred sizes of the children in the
    * layout data of the child to avoid the expense of computing this values each
    * time the widget is layed out.  When layout is triggered explicitly by the
    * programmer, the flush cache hint is true.  When layout is triggered by a
    * resize, caused either by the programmer or by the user, the hint is false.
    *
    * @param parent parent composite widget
    * @param flushCache flush cached layout values
    */
   protected void layout(Composite parent, boolean flushCache)
   {
      LpexWindow lpexWindow  = (LpexWindow)parent;
      Composite  statusLine  = lpexWindow.statusLine();
      Composite  separator0  = lpexWindow.separator0();
      Composite  formatLine  = lpexWindow.formatLine();
      Composite  separator1  = lpexWindow.separator1();
      Composite  textWindow  = lpexWindow.textWindow();
      ScrollBar  hScrollBar  = lpexWindow.horizontalScrollBar();
      Composite  separator2  = lpexWindow.separator2();
      Composite  messageLine = lpexWindow.messageLine();
      Composite  commandLine = lpexWindow.commandLine();

      int statusLineHeight = statusLine.getVisible()?
                             statusLine.computeSize(SWT.DEFAULT,SWT.DEFAULT).y : 0;
      int separator0Height = (statusLineHeight > 0)? 1 : 0;
      int formatLineHeight = formatLine.getVisible()?
                             formatLine.computeSize(SWT.DEFAULT,SWT.DEFAULT).y : 0;
      int separator1Height = (formatLineHeight > 0)? 1 : 0;

      int separator2Height = hScrollBar.getVisible()? 0 : 1;
      int messageLineHeight = messageLine.getVisible()?
                              messageLine.computeSize(SWT.DEFAULT,SWT.DEFAULT).y : 0;

      int commandLineHeight = commandLine.getVisible()?
                              commandLine.computeSize(SWT.DEFAULT,SWT.DEFAULT).y : 0;


      Rectangle parentRect = parent.getClientArea();
      int width  = parentRect.width;
      int height = parentRect.height;

      int textWindowHeight = parentRect.height -
                             statusLineHeight -
                             separator0Height -
                             formatLineHeight -
                             separator1Height -
                             separator2Height -
                             messageLineHeight -
                             commandLineHeight;
      if (textWindowHeight < 0)
         textWindowHeight = 0;

      statusLine.setBounds(0, /*parentRect.x*/        // x
                           0, /*parentRect.y*/        // y
                           width,                     // cx
                           statusLineHeight);         // cy

      separator0.setBounds(0,
                           statusLineHeight,
                           width,
                           separator0Height);

      formatLine.setBounds(0,
                           statusLineHeight + separator0Height,
                           width,
                           formatLineHeight);

      separator1.setBounds(0,
                           statusLineHeight + separator0Height +
                              formatLineHeight,
                           width,
                           separator1Height);

      //-as- Linux Eclipse: moved textWindow.setBounds() to the end (see below),
      // or message & command lines don't appear correctly until a resize!?!?...
      // (maybe on Linux our calculations here are off by a pixel or so????????)

      separator2.setBounds(0,
                           height - commandLineHeight -
                              separator2Height - messageLineHeight,
                           width,
                           separator2Height);

      messageLine.setBounds(0,
                            height - commandLineHeight - messageLineHeight,
                            width,
                            messageLineHeight);

      commandLine.setBounds(0,
                            height - commandLineHeight,
                            width,
                            commandLineHeight);

      textWindow.setBounds(0,
                           statusLineHeight + separator0Height +
                              formatLineHeight + separator1Height,
                           width,
                           textWindowHeight);
   }
}