//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ScreenShowCommand - handle the screenShow command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>screenShow</b> command.
 */
final class ScreenShowCommand
{
 static boolean doCommand(View view, String parameters)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);

  if (st.hasMoreTokens())
   {
    return CommandHandler.invalidParameter(view, st.nextToken(), "screenShow");
   }

  Document.screenShow();
  return true;
 }
}