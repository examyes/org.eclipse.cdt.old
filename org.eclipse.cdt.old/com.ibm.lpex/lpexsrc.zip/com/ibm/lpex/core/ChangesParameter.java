//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ChangesParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ChangesParameter extends ParameterIntegerQuery
{
 private static ChangesParameter _parameter;

 static ChangesParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ChangesParameter();
   }
  return _parameter;
 }

 private ChangesParameter()
 {
  super(PARAMETER_CHANGES);
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.document().undo().changes() : 0;
 }
}