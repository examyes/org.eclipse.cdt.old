//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DefaultProfileParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class DefaultProfileParameter extends ParameterWordOnly
{
 private static DefaultProfileParameter _parameter;

 static DefaultProfileParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new DefaultProfileParameter();
   }
  return _parameter;
 }

 private DefaultProfileParameter()
 {
  super(PARAMETER_DEFAULT_PROFILE);
 }

 boolean setValue(View view, String qualifier, String value)
 {
  Profile.setName(value);
  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return Profile.name();
 }
}