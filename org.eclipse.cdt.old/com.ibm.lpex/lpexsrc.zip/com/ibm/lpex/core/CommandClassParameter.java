//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CommandClassParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class CommandClassParameter extends ParameterWordOnly
{
 private static CommandClassParameter _parameter;

 static CommandClassParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new CommandClassParameter();
   }
  return _parameter;
 }

 private CommandClassParameter()
 {
  super(PARAMETER_COMMAND_CLASS);
 }

 boolean setValue(View view, String qualifier, String value)
 {
  if (view != null)
   {
    view.commandHandler().defineCommand(qualifier, value);
   }
  return true;
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.commandHandler().commandClass(qualifier) : null;
 }
}