//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LinesParameter - handles the lines parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>lines</b> parameter.
 * This parameter is query only.
 * It returns the total number of lines in the entire document.
 */
final class LinesParameter extends ParameterIntegerQuery
{
 private static LinesParameter _parameter;

 static LinesParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new LinesParameter();
   }
  return _parameter;
 }

 private LinesParameter()
 {
  super(PARAMETER_LINES);
 }

 int value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view == null)? 0 : view.document().linesCount(); // lines in complete document
 }
}