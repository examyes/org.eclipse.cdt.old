//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ActionKeyParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ActionKeyParameter extends ParameterQuery
{
 private static ActionKeyParameter _parameter;

 static ActionKeyParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ActionKeyParameter();
   }
  return _parameter;
 }

 private ActionKeyParameter()
 {
  super(PARAMETER_ACTION_KEY);
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view != null)
   {
    int id = view.actionHandler().id(qualifier);
    if (id != ACTION_INVALID)
     {
      return view.actionHandler().keyString(id);
     }
   }

  return null;
 }
}