//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Parameters - handles the editor built-in parameters.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class Parameters implements LpexConstants
{
 /**
  * Internal parameter id.
  */
 private static final int
  ACTION_ARGUMENT           =   1,
  ACTION_CLASS              =   2,
  ACTION_KEY                =   3,
  ACTION_KEY_TEXT           =   4,
  ACTION_REPEAT             =   5,
  ACTIONS                   =   6,
  AUTO_CHECK                =   7,
  BASE_PROFILE              =   8,
  BEEP                      =   9,
  BLOCK                     =  10,
  CHANGES                   =  11,
  CLASS                     =  12,
  CLASSES                   =  13,
  COMMANDS                  =  14,
  COMMAND_CLASS             =  15,
  COMMAND_LINE              =  16,
  COMPARE                   =  17,
  CURRENT                   =  18,
  CURRENT_KEY               =  19,
  CURSOR_BLINK              =  20,
  CURSOR_ROW                =  21,
  DEFAULT                   =  22,
  DEFAULT_PROFILE           =  23,
  DIRTY                     =  24,
  DISPLAY_POSITION          =  25,
  DOCUMENT_ID               =  26,
  ELEMENT                   =  27,
  ELEMENT_CLASSES           =  28,
  ELEMENTS                  =  29,
  EMPHASIS_LENGTH           =  30,
  EXCLUDED_CLASSES          =  31,
  EXPANDED                  =  32,
  EXPAND_HIDE               =  33,
  EXPAND_HIDE_AREA_WIDTH    =  34,
  EXPAND_TABS               =  35,
  FIELDS                    =  36,
  FIND_TEXT                 =  37,
  FONT                      =  38,
  FORCE_ALL_VISIBLE         =  39,
  FORCE_VISIBLE             =  40,
  FORMAT_LINE               =  41,
  FORMAT_LINE_TEXT          =  42,
  HEADER_MARK               =  43,
  HELP                      =  44,
  HEX                       =  45,
  HIDE_SEQUENCE_NUMBERS     =  46,
  IN_PREFIX                 =  47,
  INCLUDED_CLASSES          =  48,
  INSERT_MODE               =  49,
  INSTALL                   =  50,
  INSTALL_PROFILE           =  51,
  KEY_ACTION                =  52,
  KEYS                      =  53,
  LENGTH                    =  54,
  LINE                      =  55,
  LINES                     =  56,
  MAINTAIN_SEQUENCE_NUMBERS =  57,
  MARK                      =  58,
  MARK_EXCLUDED             =  59,
  MARK_EXCLUDED_HEADER      =  60,
  MARK_HIGHLIGHT            =  61,
  MARK_ID                   =  62,
  MARK_INCLUDED             =  63,
  MARK_PROTECT              =  64,
  MARK_STYLE                =  65,
  MESSAGE_LINE              =  66,
  MESSAGE_TEXT              =  67,
  MOUSE_ACTION              =  68,
  MOUSE_EVENTS              =  69,
  NAME                      =  70,
  PALETTE                   =  71,
  PARSER                    =  72,
  PIXEL_POSITION            =  73,
  POPUP                     =  74,
  POSITION                  =  75,
  PREFIX_AREA               =  76,
  PREFIX_AREA_TEXT          =  77,
  PREFIX_AREA_WIDTH         =  78,
  PREFIX_POSITION           =  79,
  PREFIX_PROTECT            =  80,
  PREFIX_TEXT               =  81,
  PRINT                     =  82,
  READONLY                  =  83,
  RECORDING                 =  84,
  ROW_HEIGHT                =  85,
  ROWS                      =  86,
  SAVE                      =  87,
  SCROLL                    =  88,
  SEQUENCE_DEFAULT_TEXT     =  89,
  SEQUENCE_NUMBER           =  90,
  SEQUENCE_NUMBERS          =  91,
  SEQUENCE_NUMBERS_FORMAT   =  92,
  SEQUENCE_TEXT             =  93,
  SHIFT_IN_CHARACTER        =  94,
  SHIFT_OUT_CHARACTER       =  95,
  SHOW                      =  96,
  SHOW_SOSI                 =  97,
  SOURCE_ENCODING           =  98,
  STATUS                    =  99,
  STATUS_LINE               = 100,
  STYLE                     = 101,
  STYLE_ATTRIBUTES          = 102,
  SYSTEM_PROPERTY           = 103,
  TABS                      = 104,
  TEXT                      = 105,
  TEXT_AREA_WIDTH           = 106,
  TEXT_WIDTH                = 107,
  TOP_EXPANDED              = 108,
  UPDATE_PROFILE            = 109,
  USE_SOURCE_COLUMNS        = 110,
  VERSION                   = 111,
  VISIBLE                   = 112;

 /**
  * Table of the LPEX built-in parameters.
  * NB Parameters must be in alphabetical order (by the PARAMETER_xxx name -
  * see LpexConstants.java) for the binary search.
  */
 private static TableNode[] _parameters =
  {
   //            parameter name                       parameter id
   //            --------------                       ------------
   new TableNode(PARAMETER_ACTION_ARGUMENT,           ACTION_ARGUMENT),
   new TableNode(PARAMETER_ACTION_CLASS,              ACTION_CLASS),
   new TableNode(PARAMETER_ACTION_KEY,                ACTION_KEY),
   new TableNode(PARAMETER_ACTION_KEY_TEXT,           ACTION_KEY_TEXT),
   new TableNode(PARAMETER_ACTION_REPEAT,             ACTION_REPEAT),
   new TableNode(PARAMETER_ACTIONS,                   ACTIONS),
   new TableNode(PARAMETER_AUTO_CHECK,                AUTO_CHECK),
   new TableNode(PARAMETER_BASE_PROFILE,              BASE_PROFILE),
   new TableNode(PARAMETER_BEEP,                      BEEP),
   new TableNode(PARAMETER_BLOCK,                     BLOCK),
   new TableNode(PARAMETER_CHANGES,                   CHANGES),
   new TableNode(PARAMETER_CLASS,                     CLASS),
   new TableNode(PARAMETER_CLASSES,                   CLASSES),
   new TableNode(PARAMETER_COMMAND_CLASS,             COMMAND_CLASS),
   new TableNode(PARAMETER_COMMAND_LINE,              COMMAND_LINE),
   new TableNode(PARAMETER_COMMANDS,                  COMMANDS),
   new TableNode(PARAMETER_COMPARE,                   COMPARE),
   new TableNode(PARAMETER_CURRENT,                   CURRENT),
   new TableNode(PARAMETER_CURRENT_KEY,               CURRENT_KEY),
   new TableNode(PARAMETER_CURSOR_BLINK,              CURSOR_BLINK),
   new TableNode(PARAMETER_CURSOR_ROW,                CURSOR_ROW),
   new TableNode(PARAMETER_DEFAULT,                   DEFAULT),
   new TableNode(PARAMETER_DEFAULT_PROFILE,           DEFAULT_PROFILE),
   new TableNode(PARAMETER_DIRTY,                     DIRTY),
   new TableNode(PARAMETER_DISPLAY_POSITION,          DISPLAY_POSITION),
   new TableNode(PARAMETER_DOCUMENT_ID,               DOCUMENT_ID),
   new TableNode(PARAMETER_ELEMENT,                   ELEMENT),
   new TableNode(PARAMETER_ELEMENT_CLASSES,           ELEMENT_CLASSES),
   new TableNode(PARAMETER_ELEMENTS,                  ELEMENTS),
   new TableNode(PARAMETER_EMPHASIS_LENGTH,           EMPHASIS_LENGTH),
   new TableNode(PARAMETER_EXCLUDED_CLASSES,          EXCLUDED_CLASSES),
   new TableNode(PARAMETER_EXPAND_HIDE,               EXPAND_HIDE),
   new TableNode(PARAMETER_EXPAND_HIDE_AREA_WIDTH,    EXPAND_HIDE_AREA_WIDTH),
   new TableNode(PARAMETER_EXPAND_TABS,               EXPAND_TABS),
   new TableNode(PARAMETER_EXPANDED,                  EXPANDED),
   new TableNode(PARAMETER_FIELDS,                    FIELDS),
   new TableNode(PARAMETER_FIND_TEXT,                 FIND_TEXT),

   // allow qualifiers for the font parameter (e.g., "query current.font.fontData" on SWT)
   new TableNode(PARAMETER_FONT,                      FONT),
   new TableNode(PARAMETER_FONT + ".",                FONT),

   new TableNode(PARAMETER_FORCE_ALL_VISIBLE,         FORCE_ALL_VISIBLE),
   new TableNode(PARAMETER_FORCE_VISIBLE,             FORCE_VISIBLE),
   new TableNode(PARAMETER_FORMAT_LINE,               FORMAT_LINE),
   new TableNode(PARAMETER_FORMAT_LINE_TEXT,          FORMAT_LINE_TEXT),
   new TableNode(PARAMETER_HEADER_MARK,               HEADER_MARK),
   new TableNode(PARAMETER_HELP,                      HELP),
   new TableNode(PARAMETER_HEX,                       HEX),
   new TableNode(PARAMETER_HIDE_SEQUENCE_NUMBERS,     HIDE_SEQUENCE_NUMBERS),
   new TableNode(PARAMETER_IN_PREFIX,                 IN_PREFIX),
   new TableNode(PARAMETER_INCLUDED_CLASSES,          INCLUDED_CLASSES),
   new TableNode(PARAMETER_INSERT_MODE,               INSERT_MODE),
   new TableNode(PARAMETER_INSTALL,                   INSTALL),
   new TableNode(PARAMETER_INSTALL_PROFILE,           INSTALL_PROFILE),
   new TableNode(PARAMETER_KEY_ACTION,                KEY_ACTION),
   new TableNode(PARAMETER_KEYS,                      KEYS),
   new TableNode(PARAMETER_LENGTH,                    LENGTH),
   new TableNode(PARAMETER_LINE,                      LINE),
   new TableNode(PARAMETER_LINES,                     LINES),
   new TableNode(PARAMETER_MAINTAIN_SEQUENCE_NUMBERS, MAINTAIN_SEQUENCE_NUMBERS),
   new TableNode(PARAMETER_MARK,                      MARK),
   new TableNode(PARAMETER_MARK_EXCLUDED,             MARK_EXCLUDED),
   new TableNode(PARAMETER_MARK_EXCLUDED_HEADER,      MARK_EXCLUDED_HEADER),
   new TableNode(PARAMETER_MARK_HIGHLIGHT,            MARK_HIGHLIGHT),
   new TableNode(PARAMETER_MARK_ID,                   MARK_ID),
   new TableNode(PARAMETER_MARK_INCLUDED,             MARK_INCLUDED),
   new TableNode(PARAMETER_MARK_PROTECT,              MARK_PROTECT),
   new TableNode(PARAMETER_MARK_STYLE,                MARK_STYLE),
   new TableNode(PARAMETER_MESSAGE_LINE,              MESSAGE_LINE),
   new TableNode(PARAMETER_MESSAGE_TEXT,              MESSAGE_TEXT),
   new TableNode(PARAMETER_MOUSE_ACTION,              MOUSE_ACTION),
   new TableNode(PARAMETER_MOUSE_EVENTS,              MOUSE_EVENTS),
   new TableNode(PARAMETER_NAME,                      NAME),
   new TableNode(PARAMETER_PALETTE,                   PALETTE),
   new TableNode(PARAMETER_PARSER,                    PARSER),
   new TableNode(PARAMETER_PIXEL_POSITION,            PIXEL_POSITION),
   new TableNode(PARAMETER_POPUP,                     POPUP),
   new TableNode(PARAMETER_POSITION,                  POSITION),
   new TableNode(PARAMETER_PREFIX_AREA,               PREFIX_AREA),
   new TableNode(PARAMETER_PREFIX_AREA_TEXT,          PREFIX_AREA_TEXT),
   new TableNode(PARAMETER_PREFIX_AREA_WIDTH,         PREFIX_AREA_WIDTH),
   new TableNode(PARAMETER_PREFIX_POSITION,           PREFIX_POSITION),
   new TableNode(PARAMETER_PREFIX_PROTECT,            PREFIX_PROTECT),
   new TableNode(PARAMETER_PREFIX_TEXT,               PREFIX_TEXT),
   new TableNode(PARAMETER_PRINT,                     PRINT),
   new TableNode(PARAMETER_READONLY,                  READONLY),
   new TableNode(PARAMETER_RECORDING,                 RECORDING),
   new TableNode(PARAMETER_ROW_HEIGHT,                ROW_HEIGHT),
   new TableNode(PARAMETER_ROWS,                      ROWS),
   new TableNode(PARAMETER_SAVE,                      SAVE),
   new TableNode(PARAMETER_SCROLL,                    SCROLL),
   new TableNode(PARAMETER_SEQUENCE_DEFAULT_TEXT,     SEQUENCE_DEFAULT_TEXT),
   new TableNode(PARAMETER_SEQUENCE_NUMBER,           SEQUENCE_NUMBER),
   new TableNode(PARAMETER_SEQUENCE_NUMBERS,          SEQUENCE_NUMBERS),
   new TableNode(PARAMETER_SEQUENCE_NUMBERS_FORMAT,   SEQUENCE_NUMBERS_FORMAT),
   new TableNode(PARAMETER_SEQUENCE_TEXT,             SEQUENCE_TEXT),
   new TableNode(PARAMETER_SHIFT_IN_CHARACTER,        SHIFT_IN_CHARACTER),
   new TableNode(PARAMETER_SHIFT_OUT_CHARACTER,       SHIFT_OUT_CHARACTER),
   new TableNode(PARAMETER_SHOW,                      SHOW),
   new TableNode(PARAMETER_SHOW_SOSI,                 SHOW_SOSI),
   new TableNode(PARAMETER_SOURCE_ENCODING,           SOURCE_ENCODING),
   new TableNode(PARAMETER_STATUS,                    STATUS),
   new TableNode(PARAMETER_STATUS_LINE,               STATUS_LINE),
   new TableNode(PARAMETER_STYLE,                     STYLE),
   new TableNode(PARAMETER_STYLE_ATTRIBUTES,          STYLE_ATTRIBUTES),
   new TableNode(PARAMETER_SYSTEM_PROPERTY,           SYSTEM_PROPERTY),
   new TableNode(PARAMETER_TABS,                      TABS),
   new TableNode(PARAMETER_TEXT,                      TEXT),
   new TableNode(PARAMETER_TEXT_AREA_WIDTH,           TEXT_AREA_WIDTH),
   new TableNode(PARAMETER_TEXT_WIDTH,                TEXT_WIDTH),
   new TableNode(PARAMETER_TOP_EXPANDED,              TOP_EXPANDED),
   new TableNode(PARAMETER_UPDATE_PROFILE,            UPDATE_PROFILE),
   new TableNode(PARAMETER_USE_SOURCE_COLUMNS,        USE_SOURCE_COLUMNS),
   new TableNode(PARAMETER_VERSION,                   VERSION),
   new TableNode(PARAMETER_VISIBLE,                   VISIBLE)
  };

 static String getQualifierString(String parameter)
  {
   parameter = parameter.trim();
   String qualifier = null;
   int qualifierIndex = parameter.indexOf(".");
   if (qualifierIndex >= 0)
    {
     qualifier = parameter.substring(qualifierIndex + 1);
    }
   return qualifier;
  }

 static String getParameterString(String parameter)
  {
   parameter = parameter.trim();
   int qualifierIndex = parameter.indexOf(".");
   if (qualifierIndex >= 0)
    {
     parameter = parameter.substring(0, qualifierIndex + 1);
    }

   return parameter;
  }

 /**
  * Get the Parameter object handling the editor <code>parameter</code>.
  */
 static Parameter getParameter(String parameter)
  {
   TableNode p = TableNode.binarySearch(_parameters, getParameterString(parameter));
   if (p != null)
    {
     switch (p.id())
      {
       case ACTION_ARGUMENT:
        {
         return ActionArgumentParameter.getParameter();
        }
       case ACTION_CLASS:
        {
         return ActionClassParameter.getParameter();
        }
       case ACTION_KEY:
        {
         return ActionKeyParameter.getParameter();
        }
       case ACTION_KEY_TEXT:
        {
         return ActionKeyTextParameter.getParameter();
        }
       case ACTION_REPEAT:
        {
         return ActionRepeatParameter.getParameter();
        }
       case ACTIONS:
        {
         return ActionsParameter.getParameter();
        }
       case AUTO_CHECK:
        {
         return AutoCheckParameter.getParameter();
        }
       case BASE_PROFILE:
        {
         return BaseProfileParameter.getParameter();
        }
       case BEEP:
        {
         return BeepParameter.getParameter();
        }
       case BLOCK:
        {
         return BlockCommand.getParameter(getQualifierString(parameter));
        }
       case CHANGES:
        {
         return ChangesParameter.getParameter();
        }
       case CLASS:
        {
         return ClassParameter.getParameter();
        }
       case CLASSES:
        {
         return ClassesParameter.getParameter();
        }
       case COMMAND_CLASS:
        {
         return CommandClassParameter.getParameter();
        }
       case COMMAND_LINE:
        {
         return CommandLineParameter.getParameter();
        }
       case COMMANDS:
        {
         return CommandsParameter.getParameter();
        }
       case COMPARE:
        {
         return CompareCommand.getParameter(getQualifierString(parameter));
        }
       case CURRENT:
        {
         return CurrentParameter.getParameter();
        }
       case CURRENT_KEY:
        {
         return CurrentKeyParameter.getParameter();
        }
       case CURSOR_BLINK:
        {
         return CursorBlinkParameter.getParameter();
        }
       case CURSOR_ROW:
        {
         return CursorRowParameter.getParameter();
        }
       case DEFAULT:
        {
         return DefaultParameter.getParameter();
        }
       case DEFAULT_PROFILE:
        {
         return DefaultProfileParameter.getParameter();
        }
       case DIRTY:
        {
         return DirtyParameter.getParameter();
        }
       case DISPLAY_POSITION:
        {
         return DisplayPositionParameter.getParameter();
        }
       case DOCUMENT_ID:
        {
         return DocumentIdParameter.getParameter();
        }
       case ELEMENT:
        {
         return ElementParameter.getParameter();
        }
       case ELEMENT_CLASSES:
        {
         return ElementClassesParameter.getParameter();
        }
       case ELEMENTS:
        {
         return ElementsParameter.getParameter();
        }
       case EMPHASIS_LENGTH:
        {
         return EmphasisLengthParameter.getParameter();
        }
       case EXCLUDED_CLASSES:
        {
         return ExcludedClassesParameter.getParameter();
        }
       case EXPAND_HIDE:
        {
         return ExpandHideParameter.getParameter();
        }
       case EXPAND_HIDE_AREA_WIDTH:
        {
         return ExpandHideAreaWidthParameter.getParameter();
        }
       case EXPAND_TABS:
        {
         return ExpandTabsParameter.getParameter();
        }
       case EXPANDED:
        {
         return ExpandedParameter.getParameter();
        }
       case FIELDS:
        {
         return FieldsParameter.getParameter();
        }
       case FIND_TEXT:
        {
         return FindTextCommand.getParameter(getQualifierString(parameter));
        }
       case FONT:
        {
         return FontParameter.getParameter();
        }
       case FORCE_ALL_VISIBLE:
        {
         return ForceAllVisibleParameter.getParameter();
        }
       case FORCE_VISIBLE:
        {
         return ForceVisibleParameter.getParameter();
        }
       case FORMAT_LINE:
        {
         return FormatLineParameter.getParameter();
        }
       case FORMAT_LINE_TEXT:
        {
         return FormatLineTextParameter.getParameter();
        }
       case HEADER_MARK:
        {
         return HeaderMarkParameter.getParameter();
        }
       case HELP:
        {
         return HelpCommand.getParameter(getQualifierString(parameter));
        }
       case HEX:
        {
         return HexParameter.getParameter();
        }
       case HIDE_SEQUENCE_NUMBERS:
        {
         return HideSequenceNumbersParameter.getParameter();
        }
       case IN_PREFIX:
        {
         return InPrefixParameter.getParameter();
        }
       case INCLUDED_CLASSES:
        {
         return IncludedClassesParameter.getParameter();
        }
       case INSERT_MODE:
        {
         return InsertModeParameter.getParameter();
        }
       case INSTALL:
        {
         return InstallParameter.getParameter();
        }
       case INSTALL_PROFILE:
        {
         return InstallProfileParameter.getParameter();
        }
       case KEY_ACTION:
        {
         return KeyActionParameter.getParameter();
        }
       case KEYS:
        {
         return KeysParameter.getParameter();
        }
       case LENGTH:
        {
         return LengthParameter.getParameter();
        }
       case LINE:
        {
         return LineParameter.getParameter();
        }
       case LINES:
        {
         return LinesParameter.getParameter();
        }
       case MAINTAIN_SEQUENCE_NUMBERS:
        {
         return MaintainSequenceNumbersParameter.getParameter();
        }
       case MARK:
        {
         return MarkParameter.getParameter();
        }
       case MARK_EXCLUDED:
        {
         return MarkExcludedParameter.getParameter();
        }
       case MARK_EXCLUDED_HEADER:
        {
         return MarkExcludedHeaderParameter.getParameter();
        }
       case MARK_HIGHLIGHT:
        {
         return MarkHighlightParameter.getParameter();
        }
       case MARK_ID:
        {
         return MarkIdParameter.getParameter();
        }
       case MARK_INCLUDED:
        {
         return MarkIncludedParameter.getParameter();
        }
       case MARK_PROTECT:
        {
         return MarkProtectParameter.getParameter();
        }
       case MARK_STYLE:
        {
         return MarkStyleParameter.getParameter();
        }
       case MESSAGE_LINE:
        {
         return MessageLineParameter.getParameter();
        }
       case MESSAGE_TEXT:
        {
         return MessageTextParameter.getParameter();
        }
       case MOUSE_ACTION:
        {
         return MouseActionParameter.getParameter();
        }
       case MOUSE_EVENTS:
        {
         return MouseEventsParameter.getParameter();
        }
       case NAME:
        {
         return NameParameter.getParameter();
        }
       case PALETTE:
        {
         return PaletteParameter.getParameter();
        }
       case PARSER:
        {
         return ParserParameter.getParameter();
        }
       case PIXEL_POSITION:
        {
         return PixelPositionParameter.getParameter();
        }
       case POPUP:
        {
         return PopupParameter.getParameter();
        }
       case POSITION:
        {
         return PositionParameter.getParameter();
        }
       case PREFIX_AREA:
        {
         return PrefixAreaParameter.getParameter();
        }
       case PREFIX_AREA_TEXT:
        {
         return PrefixAreaTextParameter.getParameter();
        }
       case PREFIX_AREA_WIDTH:
        {
         return PrefixAreaWidthParameter.getParameter();
        }
       case PREFIX_POSITION:
        {
         return PrefixPositionParameter.getParameter();
        }
       case PREFIX_PROTECT:
        {
         return PrefixProtectParameter.getParameter();
        }
       case PREFIX_TEXT:
        {
         return PrefixTextParameter.getParameter();
        }
       case PRINT:
        {
         return PrintCommand.getParameter(getQualifierString(parameter));
        }
       case READONLY:
        {
         return ReadonlyParameter.getParameter();
        }
       case RECORDING:
        {
         return RecordingParameter.getParameter();
        }
       case ROW_HEIGHT:
        {
         return RowHeightParameter.getParameter();
        }
       case ROWS:
        {
         return RowsParameter.getParameter();
        }
       case SAVE:
        {
         return SaveCommand.getParameter(getQualifierString(parameter));
        }
       case SCROLL:
        {
         return ScrollParameter.getParameter();
        }
       case SEQUENCE_DEFAULT_TEXT:
        {
         return SequenceDefaultTextParameter.getParameter();
        }
       case SEQUENCE_NUMBER:
        {
         return SequenceNumberParameter.getParameter();
        }
       case SEQUENCE_NUMBERS:
        {
         return SequenceNumbersParameter.getParameter();
        }
       case SEQUENCE_NUMBERS_FORMAT:
        {
         return SequenceNumbersFormatParameter.getParameter();
        }
       case SEQUENCE_TEXT:
        {
         return SequenceTextParameter.getParameter();
        }
       case SHIFT_IN_CHARACTER:
        {
         return ShiftInCharacterParameter.getParameter();
        }
       case SHIFT_OUT_CHARACTER:
        {
         return ShiftOutCharacterParameter.getParameter();
        }
       case SHOW:
        {
         return ShowParameter.getParameter();
        }
       case SHOW_SOSI:
        {
         return ShowSosiParameter.getParameter();
        }
       case SOURCE_ENCODING:
        {
         return SourceEncodingParameter.getParameter();
        }
       case STATUS:
        {
         return StatusParameter.getParameter();
        }
       case STATUS_LINE:
        {
         return StatusLineParameter.getParameter();
        }
       case STYLE:
        {
         return StyleParameter.getParameter();
        }
       case STYLE_ATTRIBUTES:
        {
         return StyleAttributesParameter.getParameter();
        }
       case SYSTEM_PROPERTY:
        {
         return SystemPropertyParameter.getParameter();
        }
       case TABS:
        {
         return TabsParameter.getParameter();
        }
       case TEXT:
        {
         return TextParameter.getParameter();
        }
       case TEXT_AREA_WIDTH:
        {
         return TextAreaWidthParameter.getParameter();
        }
       case TEXT_WIDTH:
        {
         return TextWidthParameter.getParameter();
        }
       case TOP_EXPANDED:
        {
         return TopExpandedParameter.getParameter();
        }
       case UPDATE_PROFILE:
        {
         return UpdateProfileCommand.getParameter(getQualifierString(parameter));
        }
       case USE_SOURCE_COLUMNS:
        {
         return UseSourceColumnsParameter.getParameter();
        }
       case VERSION:
        {
         return VersionParameter.getParameter();
        }
       case VISIBLE:
        {
         return VisibleParameter.getParameter();
        }
       default:
        {
         break;
        }
      }
    }

   return null;
  }
}