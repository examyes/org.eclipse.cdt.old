//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// InPrefixParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class InPrefixParameter extends ParameterOnOffOnly
{
 private static InPrefixParameter _parameter;

 static InPrefixParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new InPrefixParameter();
   }
  return _parameter;
 }

 private InPrefixParameter()
 {
  super(PARAMETER_IN_PREFIX);
 }

 boolean setValue(View view, String qualifier, boolean value)
 {
  if (view != null)
   {
    view.setInPrefix(value);
   }
  return true;
 }

 boolean value(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.inPrefix() : false;
 }
}