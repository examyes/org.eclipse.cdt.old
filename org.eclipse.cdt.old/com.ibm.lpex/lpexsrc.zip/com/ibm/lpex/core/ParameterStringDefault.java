//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParameterStringDefault - framework for handling quoted string parameters with
// install, default, and current settings.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

 /**
  * The Parameter <- ParameterDefault <- ParameterStringDefault abstract class
  * provides a framework for handling editor parameters that accept a single
  * quoted string, and have install, default, and current values.
  * It handles commands SET and QUERY [install.|default.|current.]<parm>, etc.
  *
  * @see ParameterWordDefault
  */
abstract class ParameterStringDefault extends ParameterDefault
{
 private String  _hardCodedValue;
 private String  _installValue;
 private boolean _installValueLoaded;
 private String  _defaultValue;
 private boolean _defaultValueLoaded;


 ParameterStringDefault(String name, String hardCodedValue)
  {
   super(name);
   _hardCodedValue = hardCodedValue;
   Install.addProfileChangedListener(new Install.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _installValueLoaded = false;
       if (defaultValue() == null)
        {
         for (Document document = Document._firstDocument;
              document != null;
              document = document._next)
          {
           for (View view = document._firstView; view != null; view = view._next)
            {
             if (value(view) == null)
              {
               currentValueChanged(view);
              }
            }
          }
        }
      }
    });

   Profile.addProfileChangedListener(new Profile.ProfileChangedListener()
    {
     public void profileChanged()
      {
       _defaultValueLoaded = false;
       for (Document document = Document._firstDocument;
            document != null;
            document = document._next)
        {
         for (View view = document._firstView; view != null; view = view._next)
          {
           if (value(view) == null)
            {
             currentValueChanged(view);
            }
          }
        }
      }
    });
  }

 String installValue()
  {
   if (!_installValueLoaded)
    {
     String value = LpexStringTokenizer.removeQuotes(Install.getString(PARAMETER_INSTALL + name()));
     _installValue = (value == null)? _hardCodedValue : value;
     _installValueLoaded = true;
    }
   return _installValue;
  }

 private void loadDefaultValue()
  {
   if (!_defaultValueLoaded)
    {
     _defaultValue = LpexStringTokenizer.removeQuotes(Profile.getString(PARAMETER_DEFAULT + name()));
     _defaultValueLoaded = true;
    }
  }

 String defaultValue()
  {
   loadDefaultValue();
   return _defaultValue;
  }

 boolean setDefaultValue(String value)
  {
   _defaultValue = value;
   _defaultValueLoaded = true;
   if (_defaultValue != null)
    {
     Profile.putString(PARAMETER_DEFAULT + name(), LpexStringTokenizer.addQuotes(_defaultValue));
    }
   else
    {
     Profile.remove(PARAMETER_DEFAULT + name());
    }

   for (Document document = Document._firstDocument;
        document != null;
        document = document._next)
    {
     for (View view = document._firstView; view != null; view = view._next)
      {
       if (value(view) == null)
        {
         currentValueChanged(view);
        }
      }
    }

   return true;
  }

 String currentValue(View view)
  {
   String value = value(view);
   if (value == null)
    {
     value = defaultValue();
     if (value == null)
      {
       value = installValue();
      }
    }

   return value;
  }

 boolean set(View view, String qualifier, String parameters)
  {
   String value = null;
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (!token.equals("default"))
      {
       if (LpexStringTokenizer.isInvalidQuotedString(token))
        {
         return CommandHandler.invalidQuotedParameter(view, token, "set " + this.name());
        }
       value = LpexStringTokenizer.removeQuotes(token);
      }
     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(), "set " + this.name());
      }
    }

   return setValue(view, value);
  }

 abstract boolean setValue(View view, String value);

 boolean setDefault(View view, String qualifier, String parameters)
  {
   String value = null;
   LpexStringTokenizer st = new LpexStringTokenizer(parameters);
   if (st.hasMoreTokens())
    {
     String token = st.nextToken();
     if (!token.equals("install"))
      {
       if (LpexStringTokenizer.isInvalidQuotedString(token))
        {
         return CommandHandler.invalidQuotedParameter(view, token,
                                                      "set " + PARAMETER_DEFAULT + this.name());
        }
       value = LpexStringTokenizer.removeQuotes(token);
      }
     if (st.hasMoreTokens())
      {
       return CommandHandler.invalidParameter(view, st.nextToken(),
                                              "set " + PARAMETER_DEFAULT + this.name());
      }
    }

   return setDefaultValue(value);
  }

 void currentValueChanged(View view) {}

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
  {
   if (view != null)
    {
     String value = value(view);
     if (value == null)
      {
       return "default";
      }
     else
      {
       return LpexStringTokenizer.addQuotes(value);
      }
    }

   return null;
  }

 abstract String value(View view);

 String queryInstall(String qualifier)
  {
   return LpexStringTokenizer.addQuotes(installValue());
  }

 String queryDefault(String qualifier)
  {
   String value = defaultValue();
   return (value == null)? "install" : LpexStringTokenizer.addQuotes(value);
  }

 String queryCurrent(View view, String qualifier)
  {
   return LpexStringTokenizer.addQuotes(currentValue(view));
  }
}