//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ClassesParameter
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

final class ClassesParameter extends ParameterQuery
{
 private static ClassesParameter _parameter;

 static ClassesParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new ClassesParameter();
   }
  return _parameter;
 }

 private ClassesParameter()
 {
  super(PARAMETER_CLASSES);
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  return (view != null)? view.classes().list() : null;
 }
}