//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexKeyListener - SWT-specific key listener able to consume LPEX's keys
// (Eclipse R2.0).
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

import java.util.EventListener;
import org.eclipse.swt.widgets.Event;


/**
 * Key listener on the Eclipse Platform, able to consume LPEX's keys.
 * Key-pressed notifications are received from LPEX through
 * <code>keyPressed(Event event)</code> calls.  If the listener
 * changes <code>event.doit</code> to <code>false</code> on exit,
 * LPEX will not process this key.
 *
 * <p>This mechanism makes up for the lack in SWT of the AWT capability of
 * consuming (key and other) events.  In AWT, input events are delivered to
 * listeners before they are processed normally by the source where they
 * originated.  This allows listeners and component subclasses to "consume" the
 * event, so that the source will not process them in their default manner.
 * For example, consuming mousePressed events on a Button component prevents the
 * Button from being activated.
 */
public interface LpexKeyListener extends EventListener
{
   /**
    * Notification of a key-pressed event in LPEX.
    * The <code>event</code> received by the listener contains the following
    * fields:
    * <ul>
    *   <li>character - the character that was typed
    *   <li>keyCode - the key code that was typed
    *   <li>stateMask - the state of the keyboard
    *   <li>doit - the listener may set this field, on exit, to
    *              <code>false</code> to indicate that LPEX should
    *              not further handle this key.
    * </ul>
    */
   public void keyPressed(Event event);
}