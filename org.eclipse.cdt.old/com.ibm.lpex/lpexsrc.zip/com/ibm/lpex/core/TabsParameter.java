//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// TabsParameter - handles the tabs parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>tabs</b> parameter.
 */
final class TabsParameter extends ParameterDefault
{
 private static TabsParameter _parameter;

 private Settings _installValue;
 private Settings _defaultValue;


 static TabsParameter getParameter()
 {
  if (_parameter == null)
   {
    _parameter = new TabsParameter();
   }
  return _parameter;
 }

 private TabsParameter()
 {
  super(PARAMETER_TABS);
  Install.addProfileChangedListener(new Install.ProfileChangedListener()
   {
    public void profileChanged()
     {
      _installValue = null;
      currentValueChanged(); // assume worst (= an actual install-value tabs change)...
     }
   });

  Profile.addProfileChangedListener(new Profile.ProfileChangedListener()
   {
    public void profileChanged()
     {
      _defaultValue = null;
      currentValueChanged(); // assume worst (= an actual default-value tabs change)...
     }
   });
 }

 Settings installValue()
 {
  if (_installValue == null)
   {
    String value = Install.getString("install." + name());
    if (value == null)
     {
      value = "1 every 8";
     }

    _installValue = new Settings();
    setTabs(null, "load install." + name(), value, _installValue);
   }

  return _installValue;
 }

 Settings defaultValue()
 {
  if (_defaultValue == null)
   {
    String value = Profile.getString("default." + name());

    _defaultValue = new Settings();
    setTabs(null, "load default." + name(), value, _defaultValue);
   }

  return _defaultValue;
 }

 Settings currentValue(View view)
 {
  Settings value = (view != null)? view.tabs() : null;
  if (value == null || (value._tabStops == null && value._tabIncrement == 0))
   {
    value = defaultValue();
    if (value._tabStops == null && value._tabIncrement == 0)
     {
      value = installValue();
     }
   }

  return value;
 }

 boolean set(View view, String qualifier, String parameters)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  Settings value = new Settings();
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    if (!token.equals("default"))
     {
      if (!setTabs(view, "set " + name(), parameters, value))
       {
        return false;
       }
     }
    else if (st.hasMoreTokens())
     {
      return CommandHandler.invalidParameter(view, st.nextToken(), "set " + name());
     }
   }

  if (view != null)
   {
    view.setTabs(value);
   }

  return true;
 }

 boolean setDefault(View view, String qualifier, String parameters)
 {
  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  Settings value = new Settings();
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    if (!token.equals("install"))
     {
      if (!setTabs(view, "set default." + name(), parameters, value))
       {
        return false;
       }
     }
    else if (st.hasMoreTokens())
     {
      return CommandHandler.invalidParameter(view, st.nextToken(), "set default." + name());
     }
   }

  // set [potentially new] default value
  _defaultValue = value;
  Profile.putString("default." + name(), getTabsString(_defaultValue));

  // default value *may have been* changed, update all views that are set to DEFAULT
  currentValueChanged();
  return true;
 }

 /**
  * The current value of tabs in a DEFAULT-set view *may* have changed...
  */
 private void currentValueChanged()
 {
  for (Document document = Document._firstDocument; document != null; document = document._next)
   {
    for (View view = document._firstView; view != null; view = view._next)
     {
      Settings value = view.tabs();
      if (value._tabStops == null && value._tabIncrement == 0) // view has DEFAULT setting
       {
        view.tabsChanged();
       }
     }
   }
 }

 String query(View view, LpexDocumentLocation documentLocation, String qualifier)
 {
  if (view == null)
   {
    return null;
   }

  Settings value = view.tabs();
  return (value._tabStops == null && value._tabIncrement == 0)? "default" : getTabsString(value);
 }

 String queryInstall(String qualifier)
 {
  return getTabsString(installValue());
 }

 String queryDefault(String qualifier)
 {
  Settings value = defaultValue();
  return (value._tabStops == null && value._tabIncrement == 0)? "install" : getTabsString(value);
 }

 String queryCurrent(View view, String qualifier)
 {
  return getTabsString(currentValue(view));
 }

 private String getTabsString(Settings settings)
 {
  if (settings._tabStops == null && settings._tabIncrement == 0)
   {
    return null;
   }

  StringBuffer tabsString = new StringBuffer(120);
  tabsString.append('1');
  if (settings._tabStops != null)
   {
    for (int i = 0; i < settings._tabStops.length; i++)
     {
      int tabStop = settings._tabStops[i];
      if (tabStop != 1)
       {
        tabsString.append(' ').append(tabStop);
       }
     }
   }

  if (settings._tabIncrement > 0)
   {
    tabsString.append(" every ").append(settings._tabIncrement);
   }

  return tabsString.toString();
 }

 /**
  * Set tab settings for the given tab-specification input string.
  *
  * @param view where to display error messages
  * @param command the command that invoked us (for error messages)
  * @param tabsString e.g., "1 4 8 every 8";
  *                   if null, settings are set to {null, 0}
  * @param settings TabsParameter.Settings to store the result
  *
  * @return true = <code>tabsString</code> correct, <code>settings</code> has been set
  */
 static boolean setTabs(View view, String command, String tabsString, Settings settings)
 {
  int tabStops[] = null;
  int tabIncrement = 0;

  if (tabsString != null)
   {
    String token = null;
    int lastTabStop = 0;
    int count = 1;

    LpexStringTokenizer st = new LpexStringTokenizer(tabsString);
    while (st.hasMoreTokens())
     {
      token = st.nextToken();
      try
       {
        int tabStop = Integer.parseInt(token);
        if (tabStop <= lastTabStop)
         {
          return CommandHandler.invalidParameter(view, token, command);
         }

        if (tabStop != 1)
         {
          count++;
         }
        lastTabStop = tabStop;
        token = null;
       }
      catch(NumberFormatException e)
       {
        break;
       }
     }

    if (token != null)
     {
      if (!token.equals("every"))
       {
        return CommandHandler.invalidParameter(view, token, command);
       }
      if (!st.hasMoreTokens())
       {
        return CommandHandler.incomplete(view, command);
       }

      token = st.nextToken();
      try
       {
        tabIncrement = Integer.parseInt(token);
        if (tabIncrement < 1)
         {
          return CommandHandler.invalidParameter(view, token, command);
         }
       }
      catch(NumberFormatException e)
       {
        return CommandHandler.invalidParameter(view, token, command);
       }

      if (st.hasMoreTokens())
       {
        return CommandHandler.invalidParameter(view, st.nextToken(), command);
       }
     }

    tabStops = new int[count];
    tabStops[0] = 1;
    st = new LpexStringTokenizer(tabsString);
    int i = 1;
    while (st.hasMoreTokens() && i < count)
     {
      try
       {
        int tabStop = Integer.parseInt(st.nextToken());
        if (tabStop != 1)
         {
          tabStops[i] = tabStop;
          i++;
         }
       }
      catch(NumberFormatException e) {}
     }
   }

  settings._tabStops = tabStops;
  settings._tabIncrement = tabIncrement;
  return true;
 }


 static class Settings
 {
  int _tabStops[] = null;
  int _tabIncrement;
 }
}