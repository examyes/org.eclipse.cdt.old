//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexCommand - user command interface.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * Interface LpexCommand can be implemented to define a user command.
 *
 * @see LpexView#defineCommand
 * @see com.ibm.lpex.samples.TestCommand
 */
public interface LpexCommand
{
 /**
  * This method in the defined command will be called to run the command.
  *
  * @param lpexView the document view in which the command was issued
  * @param parameters the command parameters
  */
 public boolean doCommand(LpexView lpexView, String parameters);
}