//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ExpandAllCommand - handles the expandAll command.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class implements the <b>expandAll</b> command.
 */
final class ExpandAllCommand
{
 static boolean doCommand(View view, String parameters)
 {
  boolean on = true;

  LpexStringTokenizer st = new LpexStringTokenizer(parameters);
  if (st.hasMoreTokens())
   {
    String token = st.nextToken();
    if (token.equals("off"))
     {
      on = false;
     }
    else if (!token.equals("on"))
     {
      return CommandHandler.invalidParameter(view, token, "expandAll");
     }

    if (st.hasMoreTokens())
     {
      return CommandHandler.invalidParameter(view, st.nextToken(), "expandAll");
     }
   }

  // command format is correct, now if we have a view do it
  if (view != null)
   {
    view.expandAll(on);
   }

  return true;
 }
}