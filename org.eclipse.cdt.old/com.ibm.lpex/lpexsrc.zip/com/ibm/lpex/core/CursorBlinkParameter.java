//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CursorBlinkParameter - handles the cursorBlink parameter.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;


//*as* currently this parameter is not documented.  When the cursor is narrow,
//     it is not visible at the start & end of a selection...  The current
//     implementation in TextWindow.java has the cursorBlinkTimer *always*
//     running - we may want to still blink in these two extreme cases??


/**
 * CursorBlinkParameter handles the cursorBlink LPEX parameter.
 * The Parameter class it extends provides the framework for handling
 * parameters in LPEX (setting install values, commands SET and QUERY, etc.).
 */
final class CursorBlinkParameter extends ParameterOnOffDefault
{
   /**
    * One single CursorBlinkParameter (static _parameter) object handles
    * (by occasionally delegating to View) cursorBlink for all the
    * views (note that all its methods have a View argument passed in).
    *
    * The actual value of a view's cursorBlink is stored in the View
    * (_cursorBlink, initialized to Parameter.DEFAULT).
    */
   private static CursorBlinkParameter _parameter;

   static CursorBlinkParameter getParameter()
   {
      if (_parameter == null)
         _parameter = new CursorBlinkParameter();
      return _parameter;
   }

   /**
    * Private constructor - CursorBlinkParameter is not instantiated
    * directly, but via a first call to CursorBlinkParameter.getParameter().
    */
   private CursorBlinkParameter()
   {
      // construct a Parameter.OnOffDefault with the _name
      // PARAMETER_CURSOR_BLINK, and a _hardCodedValue = true (ON)
      super(PARAMETER_CURSOR_BLINK, true);
   }

   /**
    * Set the cursorBlink parameter for this view.
    * @param value Parameter.ON, .OFF, .DEFAULT (one of .ON, .OFF, .INSTALL)
    */
   boolean setValue(View view, int value)
   {
      if (view != null) {
//       boolean oldValue = currentValue(view);
         view.setCursorBlink(value);
//       if (oldValue != currentValue(view))
//          view.cursorBlinkChanged();
         }
      return true;
   }

// /**
//  * Handle the notification of a change in the actual true/false value of
//  * the document's cursorBlink parameter, by delegating it to the
//  * View.cursorBlinkChanged().
//  * Overrides currentValueChanged(View) in class ParameterOnOffDefault,
//  * which does nothing.  It is called when the profile changed, when the
//  * DEFAULT value was modified, etc.
//  *
//  * NOTE: not needed, we always keep the cursor-blink timer going in
//  *       TextWindow, so we sense value changes quite instantly anyway...
//  */
// void currentValueChanged (View view)
// {
//    view.cursorBlinkChanged();
// }

   /**
    * Get the cursorBlink parameter, through View.cursorBlink().
    * @return Parameter.ON, .OFF, .DEFAULT (in .ON, .OFF, .INSTALL), .INSTALL
    */
   int value(View view)
   {
      return (view != null)? view.cursorBlink() : DEFAULT;
   }
}