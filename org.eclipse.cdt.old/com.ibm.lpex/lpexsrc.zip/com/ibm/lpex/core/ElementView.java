//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ElementView - manage a view on a text element.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages element-scoped information that is specific to
 * a particular document view.
 * There is one instance of this class per element per document view.
 */
final class ElementView
{
 ElementView _next;

 private Element _element;
 private View    _view;
 private int     _flags;
 private String  _prefixText;
 private int     _prefixScroll;

 private int     _width;
 private int     _prefixAreaWidth;
 private String  _style;
 private String  _displayStyle;
 private long    _classes = Classes.DEFAULT;
 private int     _visibleOrdinal;
 private ParsePending _parsePending;

 // cached display text (when the line has expanded tabs
 // and/or sequence numbers and/or SOS/SIs)
 private DisplayString _displayText = new DisplayString();

 // set by outsiders:  list of marks for this element in this view
 MarkNode _firstMarkNode;

 // values for _flags
 private final static int
  SHOW                    = 0x00000001,
  WIDTH_VALID             = 0x00000002,
  PREFIX_AREA_WIDTH_VALID = 0x00000004,
  FORCE_VISIBLE           = 0x00000008,
  EXPANDED                = 0x00000010,
  EXPANDED_VISIBLE        = 0x00000020;


 /**
  * Constructor for a show or non-show element view.
  */
 ElementView(Element element, View view, boolean show)
  {
   _element = element;
   _view = view;
   _flags = show? SHOW : 0;
  }

 /**
  * Constructor for a non-show element view.
  */
 ElementView(Element element, View view)
  {
   //this(element, view, false);
   _element = element;
   _view = view;
  }

 Element element()
  {
   return _element;
  }

 View view()
  {
   return _view;
  }

 private boolean widthValid()
  {
   return (_flags & WIDTH_VALID) != 0;
  }

 private void setWidthValid(boolean widthValid)
  {
   if (widthValid)
    {
     _flags |= WIDTH_VALID;
    }
   else
    {
     _flags &= ~WIDTH_VALID;
    }
  }

 private boolean prefixAreaWidthValid()
  {
   return (_flags & PREFIX_AREA_WIDTH_VALID) != 0;
  }

 private void setPrefixAreaWidthValid(boolean prefixAreaWidthValid)
  {
   if (prefixAreaWidthValid)
    {
     _flags |= PREFIX_AREA_WIDTH_VALID;
    }
   else
    {
     _flags &= ~PREFIX_AREA_WIDTH_VALID;
    }
  }

 boolean show()
  {
   return (_flags & SHOW) != 0;
  }

 int width()
  {
   if (!widthValid())
    {
     String text = displayText().text;
     if (text != null)
      {
       TextFontMetrics textFontMetrics = _view.screen().textFontMetrics();
       if (textFontMetrics != null)
        {
         _width = textFontMetrics.stringWidth(text);
         setWidthValid(true);
        }
      }
    }

   return _width;
  }

 void setWidthInvalid()
  {
   if (widthValid())
    {
     setWidthValid(false);
     if (_view.maxElementWidthValid() && visible())
      {
       _view.setMaxElementWidthInvalid();
      }
    }
  }

 int prefixAreaWidth()
  {
   if (!prefixAreaWidthValid())
    {
     // prefix area width depends on the prefixAreaText setting:
     // sequenceNumbers or [if none set] lineNumbers
     String prefixAreaText = "";
     int prefixAreaTextValue = PrefixAreaTextParameter.getParameter().currentValue(_view);
     if (prefixAreaTextValue == View.PREFIX_AREA_TEXT_SEQUENCENUMBERS)
      {
       prefixAreaText = _view.document().elementList().getSequenceNumbersDisplayString(_element, _view);
      }
     if (prefixAreaText.length() == 0)
      {
       prefixAreaText = _element.lineNumberText(6);
      }

     TextFontMetrics textFontMetrics = _view.screen().textFontMetrics();
     if (textFontMetrics != null)
      {
       _prefixAreaWidth = textFontMetrics.stringWidth(prefixAreaText);
       setPrefixAreaWidthValid(true);
      }
    }

   return _prefixAreaWidth;
  }

 void setPrefixAreaWidthInvalid()
  {
   if (prefixAreaWidthValid())
    {
     setPrefixAreaWidthValid(false);
     if (_view.maxPrefixAreaWidthValid() && visible())
      {
       _view.setMaxPrefixAreaWidthInvalid();
      }
    }
  }

 /**
  * Return the character pixel position in displayText that corresponds to
  * <code>position</code> into the text.  When showSosi is "on" and the
  * sourceEncoding is EBCDIC DBCS, the pixel position returned will not be
  * that of a SO/SI control character.
  */
 int pixelCharPosition(int position)
  {
   return _view.pixelPosition(this, position, true);
  }

 /**
  * Return the pixel position in displayText that corresponds to
  * <code>position</code> into the text.
  */
 int pixelPosition(int position)
  {
   return _view.pixelPosition(this, position, false);
  }

 long classes()
  {
   return _classes;
  }

 void setClasses(long classes)
  {
   boolean wasVisible = visible();
   _classes = classes |                         // the new class bits
              Classes.DEFAULT |                 // always have DEFAULT class
              (_classes & Classes.FIND_TEXT);   // preserve current FIND_TEXT class

   if (wasVisible != visible())
    {
     _view.setVisibleElementOrdinalsInvalid();
     if (_view.maxElementWidthValid())
      {
       if (width() >= _view.maxElementWidth())
        {
         _view.setMaxElementWidthInvalid();
        }
      }
     if (_view.maxPrefixAreaWidthValid())
      {
       if (prefixAreaWidth() >= _view.maxPrefixAreaWidth())
        {
         _view.setMaxPrefixAreaWidthInvalid();
        }
      }
    }
  }

 void setFindTextClass(boolean findTextClass)
  {
   boolean wasVisible = visible();
   if (findTextClass)
    {
     _classes |= Classes.FIND_TEXT;
    }
   else
    {
     _classes &= ~Classes.FIND_TEXT;
    }

   if (wasVisible != visible())
    {
     _view.setVisibleElementOrdinalsInvalid();
     if (_view.maxElementWidthValid())
      {
       if (width() >= _view.maxElementWidth())
        {
         _view.setMaxElementWidthInvalid();
        }
      }
     if (_view.maxPrefixAreaWidthValid())
      {
       if (prefixAreaWidth() >= _view.maxPrefixAreaWidth())
        {
         _view.setMaxPrefixAreaWidthInvalid();
        }
      }
    }
  }

 boolean expandHideVisible()
  {
   return _view.forceAllVisible() || forceVisible() ||
          ((_classes & _view.includedClasses()) != 0 &&
           (_classes & _view.excludedClasses()) == 0 &&
           _view.markList().visible(_element) &&
           (!_element.show() || show()));
  }

 boolean visible()
  {
   if (_view.forceAllVisible())
    {
     return true;
    }

   _view.validateVisibleElements();
   return (expandHideVisible() || expandedVisible()) &&
          (!_element.show() || show());
  }

 int visibleOrdinal()
  {
   return _visibleOrdinal;
  }

 void setVisibleOrdinal(int visibleOrdinal)
  {
   _visibleOrdinal = visibleOrdinal;
  }

 ParsePending parsePending()
  {
   return _parsePending;
  }

 void setParsePending(ParsePending parsePending)
  {
   _parsePending = parsePending;
  }

 void setPrefixText(String prefixText)
  {
   _prefixText = prefixText;
  }

 String prefixText()
  {
   return _prefixText;
  }

 int prefixEnd()
  {
   return (_prefixText != null)? _prefixText.length() + 1 : 1;
  }

 int prefixScroll()
  {
   return _prefixScroll;
  }

 void setPrefixScroll(int prefixScroll)
  {
   _prefixScroll = prefixScroll;
  }

 void setForceVisible(boolean forceVisible)
  {
   if (forceVisible)
    {
     _flags |= FORCE_VISIBLE;
    }
   else
    {
     _flags &= ~FORCE_VISIBLE;
    }
  }

 boolean forceVisible()
  {
   return (_flags & FORCE_VISIBLE) != 0;
  }

 void setExpanded(boolean expanded)
  {
   if (expanded != expanded())
    {
     if (expanded)
      {
       _flags |= EXPANDED;
      }
     else
      {
       _flags &= ~EXPANDED;
      }
     _view.setVisibleElementOrdinalsInvalid();
    }
  }

 boolean expanded()
  {
   return (_flags & EXPANDED) != 0;
  }

 void setExpandedVisible(boolean expandedVisible)
  {
   if (expandedVisible)
    {
     _flags |= EXPANDED_VISIBLE;
    }
   else
    {
     _flags &= ~EXPANDED_VISIBLE;
    }
  }

 boolean expandedVisible()
  {
   return (_flags & EXPANDED_VISIBLE) != 0;
  }

 /**
  * Retrieve the string to display for this element's text.
  * This will include expanded Tabs, sequence numbers (formatted for display),
  * and emulation SO/SIs as needed.
  *
  * Whatever needs time-consuming processing (expanding tabs, adding SO/SIs,
  * etc.) is done once & cached in _displayText for faster retrieval next time.
  *
  * Called in here in several places, and also by Screen.show(),
  * PrintCommand.doCommand(), and View.saveAsHtml().
  *
  * <p>Example:<pre>
  *
  *                           0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4
  * Tabs                      |               |               |               |
  *
  * element.text()            a b c T D e f g T h
  * fullText                  a b c T D e f X X X g T h
  * + SO/SIs                  a b c T > D < e f X X X g T h
  * + expanded Tabs           a b c           > D D < e f X X X g             h
  *
  * hideSequenceNumbers "on"  a b c           > D D < e f g   h
  *
  * a,b,c,d,e,f,g,h = SBCS chars
  * T = Tab char
  * D = DBCS char
  * XXX = sequence-numbers area
  * </pre>
  *
  * @see #displayStyle
  * @see #displayNetText
  */
 DisplayString displayText()
  {
   boolean expandTabs = _element.tabs() && _view.currentExpandTabs();
   boolean addSequenceNumbers =
           !_view.currentHideSequenceNumbers() &&
           _view.document().elementList().sequenceNumbersWidth() != 0;

   /*======================================================*/
   /*  (a) no tabs to expand, no sequence numbers to show  */
   /*======================================================*/
   if (!expandTabs && !addSequenceNumbers)
    {
     // 1.- not even emulation SO/SIs!
     if (!_view.nls().displayingSosi())
      {
       _displayText.text = _element.text();
       return _displayText;
      }

     // 2.- OK, a couple SO/SIs...
     if (_displayText.text == null)
      {
       _displayText.text = _view.nls().addSourceSosi(_element.text());
      }
    }

   // have display text in the cache from above/previous processing?
   if (_displayText.text != null)
    {
     return _displayText;
    }

   /*====================================================================*/
   /*  (b) tabs to expand and/or sequence numbers to show and/or SO/SIs  */
   /*====================================================================*/
   // get this element's full text for display:  if the view shows sequence
   // numbers, include them, formatted for display according to the current
   // sequenceNumbersFormat setting for the view;
   // _displaySequenceNumbersPosition will also be set
   DisplayString fullDisplayText;
   if (addSequenceNumbers)
    {
     fullDisplayText = _view.document().elementList()
                                       .addDisplaySequenceNumbers(_element, _view);
    }
   else
    {
     fullDisplayText = new DisplayString(_element.text());
    }

   /*-----------------------------------------------------------------------*/
   /* SO/SI: add emulation SO/SIs here, *before* calculating tab expansions */
   /*-----------------------------------------------------------------------*/
   // assume no SO/SIs added to the sequence-numbers area -as-
   if (_view.nls().displayingSosi())
    {
     // fullDisplayText.sequenceNumbersPosition may be also updated
     _view.nls().addSourceSosi(fullDisplayText.text);
    }

   /*-------------*/
   /* expand Tabs */
   /*-------------*/
   if (expandTabs)
    {
     // fullDisplayText.sequenceNumbersPosition may be also updated
     _view.expandTextTabs(fullDisplayText);
    }

   // cache display text info now
   _displayText = fullDisplayText;
   return _displayText;
  }

 /**
  * Retrieve a displayText without any emulation SO/SIs.
  * This method is used by save 'visible' (see View.save()).
  * If there are SO/SIs on the screen, Tabs will now be expanded differently
  * than what's on the display, but tabs & SO/SIs shouldn't really go together
  * anyway...
  *
  * @see #displayText
  */
 String displayNetText()
  {
   boolean expandTabs = _element.tabs() && _view.currentExpandTabs();
   boolean addSequenceNumbers =
           !_view.currentHideSequenceNumbers() &&
           _view.document().elementList().sequenceNumbersWidth() != 0;

   /*======================================================*/
   /*  (a) no tabs to expand, no sequence numbers to show  */
   /*======================================================*/
   if (!expandTabs && !addSequenceNumbers)
    {
     return _element.text();
    }

   // have cached display text without SO/SIs from a previous processing?
   if (_displayText.text != null && !_view.nls().displayingSosi())
    {
     return _displayText.text;
    }

   /*======================================================*/
   /*  (b) tabs to expand and/or sequence numbers to show  */
   /*======================================================*/
   // get this element's full text for display:  if the view shows sequence
   // numbers, include them, formatted for display according to the current
   // sequenceNumbersFormat setting for the view
   DisplayString fullDisplayText;
   if (addSequenceNumbers)
    {
     fullDisplayText = _view.document().elementList()
                                       .addDisplaySequenceNumbers(_element, _view);
    }
   else
    {
     fullDisplayText = new DisplayString(_element.text());
    }

   /*-------------*/
   /* expand Tabs */
   /*-------------*/
   if (expandTabs)
    {
     _view.expandTextTabs(fullDisplayText);
    }

   return fullDisplayText.text;
  }

 /**
  * Reset any cached display info for this element view.  This is done when
  * displayText must be recalculated - text changed / expandTabs changed /
  * showSosi changed / hideSequenceNumbers changed / etc...
  */
 void resetDisplayText()
  {
   _displayText.text = null;
   _displayStyle = null;
   setWidthInvalid();
  }

 /**
  * Return the element's style string for this view, or an empty string if none.
  */
 String style()
  {
   return (_style == null)? "" : _style;
  }

 /**
  * Invalidate the cached display style string for this element in this view.
  */
 void resetDisplayStyle()
  {
   _displayStyle = null;
  }

 /**
  * Retrieve the display style for this element's text.
  * The display style must be kept in sync with the element's display text.
  * It is adjusted to the text for sequence numbers (formatted for display),
  * expanded Tabs, and emulation SO/SIs as needed.
  *
  * Whatever needs time-consuming processing (expanding tabs, adding SO/SIs,
  * etc.) is done once & cached in _displayStyle for faster retrieval next time.
  *
  * @see #displayText
  */
 String displayStyle()
  {
   if (_displayStyle != null)
    {
     return _displayStyle; // cached copy already available.
    }

   _displayStyle = _view.markList().style(_element, _style);

   ElementList elementList = _view.document().elementList();
   boolean addSequenceNumbers =
           !_view.currentHideSequenceNumbers() &&
           elementList.sequenceNumbersWidth() != 0;
   LpexNls nls = _view.nls();

   /*==========================================*/
   /*  add the style for the sequence numbers  */
   /*==========================================*/
   if (addSequenceNumbers)
    {
     if (_displayStyle == null)
      {
       _displayStyle = "";
      }
     StringBuffer buffer = new StringBuffer(_displayStyle);

     String sequenceNumbersStyle = _view.getSequenceNumbersStyle();
     int sequenceNumbersColumn = elementList.sequenceNumbersColumn();

     int len, spaces, colIndex;
     /*---------------------------------*/
     /*  1.- DBCS/MBCS source encoding  */
     /*---------------------------------*/
     if (nls.usingSourceColumns())
      {
       // length of Unicode fullText to keep prior to seq no.s inside DBCS-source
       len = nls.sourceTruncate(_element.text(), sequenceNumbersColumn-1);
       // calculate blanks to insert from this len in source-encoding bytes
       spaces = sequenceNumbersColumn -
                nls.sourceLength(_element.text().substring(0, len)) - 1;
       // and offset to insert the sequenceNumber into the Unicode text
       colIndex = len + spaces;
       // there may be no style set at all for element yet
       if (len > buffer.length())
        {
         spaces += len - buffer.length();
         len = buffer.length();
        }
      }
     /*--------------------------*/
     /*  2.- stick with Unicode  */
     /*--------------------------*/
     else
      {
       // length of the element's display style
       len = buffer.length();
       // blanks to insert if the sequence numbers are beyond end of the text
       spaces = sequenceNumbersColumn - len - 1;
       // offset to insert the sequenceNumber
       colIndex = sequenceNumbersColumn - 1;
      }

     for (int i = len; spaces > 0; i++, spaces--)
      {
       buffer.insert(i, '!');
      }

     buffer.insert(colIndex, sequenceNumbersStyle);
     _displayStyle = buffer.toString();
    }

   if (_displayStyle == null)
    {
     return _displayStyle;
    }

   /*====================================*/
   /*  adjust style for Tabs and SO/SIs  */
   /*====================================*/
   // retrieve this element's full text:  text + [sequence numbers]
   String fullText = addSequenceNumbers? _element.fullText() : _element.text();

   if (!_element.tabs() || !_view.currentExpandTabs())
    {
     if (nls.displayingSosi())
      {
        _displayStyle = nls.addSosiStyle(_displayStyle, fullText);
      }
     return _displayStyle;
    }

   /*-------------------------------------------------------------------*/
   /* SO/SI: adjust to the emulation SO/SIs here, *before* calculating  */
   /* tab expansions, exactly like we do with the text in displayText() */
   /*-------------------------------------------------------------------*/
   if (nls.displayingSosi())
    {
     _displayStyle = nls.addSosiStyle(_displayStyle, fullText);
     fullText = nls.addSourceSosi(fullText);   // sync text for the '\t' checks
    }

   /*-------------*/
   /* expand Tabs */
   /*-------------*/
   _displayStyle = _view.expandStyleTabs(_displayStyle, fullText);
   return _displayStyle;
  }

 void setStyle(String style)
  {
   _style = style;
   _displayStyle = null;
  }

 boolean expandHideHeader()
  {
   if (expandHideVisible())
    {
     for (Element element = _element.next();
          element != null;
          element = element.next())
      {
       ElementView elementView = element.elementView(_view);
       if (elementView.expandHideVisible())
        {
         return false;
        }
       if (!element.show() || elementView.show())
        {
         return true;
        }
      }
    }
   return false;
  }

 /**
  * Returns the text for the expand/hide area for this element, or
  * an empty String if the element is not an expande/hide [+]/[-] header.
  */
 String expandHideText()
  {
   if (expandHideHeader())
    {
     return expanded()? "-" : "+";
    }
   return "";
  }


 static final class MarkNode
  {
   MarkList.Mark _mark;
   MarkNode _next;

   MarkNode(MarkList.Mark mark)
    {
     _mark = mark;
    }

   MarkList.Mark mark()
    {
     return _mark;
    }
  }
}