//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ElementView - manage a view on a text element.
//----------------------------------------------------------------------------

package com.ibm.lpex.core;

/**
 * This class manages element-scoped information that is specific to
 * a particular document view.
 * There is one instance of this class per element per document view.
 */
final class ElementView
{
 ElementView _next;

 private Element _element;
 private View    _view;
 private int     _flags;
 private String  _prefixText;
 private int     _prefixScroll;

 private int     _width;                // see WIDTH_VALID
 private int     _prefixAreaWidth;      // see PREFIX_AREA_WIDTH_VALID
 private String  _style;
 private String  _displayStyle;
 private long    _classes = Classes.DEFAULT;
 private int     _visibleOrdinal;
 private ParsePending _parsePending;

 // cached display text
 private String _displayText;
 private DisplayTextBidi _displayTextBidi;

 // set by outsiders:  list of marks for this element in this view
 MarkNode _firstMarkNode;

 // values for _flags
 private final static int
  SHOW                    = 0x00000001,
  WIDTH_VALID             = 0x00000002,
  PREFIX_AREA_WIDTH_VALID = 0x00000004,
  FORCE_VISIBLE           = 0x00000008,
  EXPANDED                = 0x00000010,
  EXPANDED_VISIBLE        = 0x00000020;


 /**
  * Constructor for a show or non-show element view.
  */
 ElementView(Element element, View view, boolean show)
 {
  _element = element;
  _view = view;
  _flags = show? SHOW : 0;
 }

 /**
  * Constructor for a non-show element view.
  */
 ElementView(Element element, View view)
 {
  this(element, view, false);
 }

 Element element()
 {
  return _element;
 }

 View view()
 {
  return _view;
 }

 private boolean widthValid()
 {
  return (_flags & WIDTH_VALID) != 0;
 }

 private void setWidthValid(boolean widthValid)
 {
  if (widthValid)
   {
    _flags |= WIDTH_VALID;
   }
  else
   {
    _flags &= ~WIDTH_VALID;
   }
 }

 private boolean prefixAreaWidthValid()
 {
  return (_flags & PREFIX_AREA_WIDTH_VALID) != 0;
 }

 private void setPrefixAreaWidthValid(boolean prefixAreaWidthValid)
 {
  if (prefixAreaWidthValid)
   {
    _flags |= PREFIX_AREA_WIDTH_VALID;
   }
  else
   {
    _flags &= ~PREFIX_AREA_WIDTH_VALID;
   }
 }

 boolean show()
 {
  return (_flags & SHOW) != 0;
 }

 /**
  * Cache and return the display width in pixels of this element in this view.
  */
 int width()
 {
  if (!widthValid())
   {
    String text = displayText();
    if (text.length() == 0)
     {
      _width = 0;
      setWidthValid(true);
     }
    else
     {
      // (1) bidirectional
      if (LpexUtilities.isBidi())
       {
        _width = displayTextBidi().width();
        setWidthValid(true);
       }

      // (2) unidirectional
      else
       {
        TextFontMetrics textFontMetrics = _view.screen().textFontMetrics();
        if (textFontMetrics != null)
         {
          _width = textFontMetrics.stringWidth(text);
          setWidthValid(true);
         }
       }
     }
   }

  return _width;
 }

 /**
  * Invalidate cached width of this element in this view.
  */
 void setWidthInvalid()
 {
  setWidthValid(false);
  if (_view.maxElementWidthValid() && visible())
   {
    _view.setMaxElementWidthInvalid();
   }
 }

 int prefixAreaWidth()
 {
  if (!prefixAreaWidthValid())
   {
    // prefix area width depends on the prefixAreaText setting:
    // sequenceNumbers or [if none set] lineNumbers
    String prefixAreaText = "";
    int prefixAreaTextValue = PrefixAreaTextParameter.getParameter().currentValue(_view);
    if (prefixAreaTextValue == View.PREFIX_AREA_TEXT_SEQUENCENUMBERS)
     {
      prefixAreaText = _view.document().elementList()
                                       .getSequenceNumbersDisplayString(_element, _view);
     }
    if (prefixAreaText.length() == 0)
     {
      prefixAreaText = _element.lineNumberText(6);
     }

    TextFontMetrics textFontMetrics = _view.screen().textFontMetrics();
    if (textFontMetrics != null)
     {
      _prefixAreaWidth = textFontMetrics.stringWidth(prefixAreaText);
      setPrefixAreaWidthValid(true);
     }
   }

  return _prefixAreaWidth;
 }

 void setPrefixAreaWidthInvalid()
 {
  if (prefixAreaWidthValid())
   {
    setPrefixAreaWidthValid(false);
    if (_view.maxPrefixAreaWidthValid() && visible())
     {
      _view.setMaxPrefixAreaWidthInvalid();
     }
   }
 }

 /**
  * Return the character pixel position in displayText that corresponds to
  * <code>position</code> into the text.  When showSosi is "on" and the
  * sourceEncoding is EBCDIC DBCS, the pixel position returned will not be
  * that of a SO/SI control character.
  */
 int pixelCharPosition(int position)
 {
  return pixelPosition(position, true);
 }

 /**
  * Return the pixel position in displayText that corresponds to
  * <code>position</code> into the text.
  */
 int pixelPosition(int position)
 {
  return pixelPosition(position, false);
 }

 /**
  * Return the [character] pixel position in the displayText of an element in
  * this view, that corresponds to <code>position</code> into its text.
  *
  * @param position ONE-based position into the element's text
  * @param charPosition true = ensure pixel position of a character, not that of
  *                            an emulated SO/SI control (effective in MBCS only)
  */
 int pixelPosition(int position, boolean charPosition)
 {
  // if SO/SIs must even calculate for position=1, to steer away from initial SO
  if (position <= 0)
   {
    return 0;
   }

  // get corresponding (bidi: logical) position into display text
  if (charPosition) // (a) char offset into displayText (away from SO/SIs)
   {
    position = _view.displayPosition(this, position, true);
   }
  else              // (b) offset into displayText
   {
    position = _view.displayPosition(this, position, false);
   }

  if (position == 1 && !LpexUtilities.isBidi())
   {
    return 0;
   }

  TextFontMetrics textFontMetrics = _view.screen().textFontMetrics();
  if (textFontMetrics == null)
   {
    return 0;
   }

  // [Set up and] get the display text for this element in this view
  String text = displayText();
  if (text.length() == 0)
   {
    return textFontMetrics.spaceWidth() * (position - 1);
   }

  // (A) bidi: get visual pixel position (sensitive to bidi ordering & ligatures)
  if (LpexUtilities.isBidi())
   {
    return displayTextBidi().pixelPosition(position);
   }

  // (B1) regular: inside the text
  if (text.length() > position - 1)
   {
    return textFontMetrics.substringWidth(text, 0, position - 1);
   }

  // (B2) regular: at / beyond end of the text
  return width() + textFontMetrics.spaceWidth() * (position - 1 - text.length());
 }

 /**
  * Return the direction of the character at the specified position in the text.
  *
  * @param textPosition ONE-based position into the element's text
  */
 boolean isRightToLeft(int textPosition)
 {
  if (!LpexUtilities.isBidi() || textPosition < 1)
   {
    return false;
   }

  // get corresponding (bidi: logical) position into display text
  int displayPosition = _view.displayPosition(this, textPosition, true);
  return displayTextBidi().isRightToLeft(displayPosition);
 }

 long classes()
 {
  return _classes;
 }

 /**
  * Re-set the element classes for an element in this view.
  * Any resulting visibility change is handled in here.
  */
 void setClasses(long classes)
 {
  boolean wasVisible = visible();
  _classes = classes |                            // the new class bits
             Classes.DEFAULT |                    // always have DEFAULT class
             (_classes & (Classes.FIND_TEXT |     // preserve any current FIND_TEXT
                          Classes.EXCLUDE_TEXT)); //  & EXCLUDE_TEXT classes
  visibilityChanged(wasVisible);
 }

 /**
  * Set Classes.FIND_TEXT or Classes.EXCLUDE_TEXT for an element in this
  * view.  Any resulting visibility change is handled in here.
  */
 void setTextClasses(long textClasses)
 {
  boolean wasVisible = visible();
  _classes |= textClasses;
  visibilityChanged(wasVisible);
 }

 /**
  * Clear Classes.FIND_TEXT and/or Classes.EXCLUDE_TEXT from an element in this
  * view.  Any resulting visibility change is handled in here.
  */
 void clearTextClasses(long textClasses)
 {
  boolean wasVisible = visible();
  _classes &= ~textClasses;
  visibilityChanged(wasVisible);
 }

 /**
  * Clear the specified element class(es) from an element in this view.
  * Any resulting changes in its visibility are <b>not</b> handled here.
  */
 void clearClasses(long clearClasses)
 {
  _classes &= ~clearClasses;
 }

 private void visibilityChanged(boolean wasVisible)
 {
  if (wasVisible != visible())
   {
    _view.setVisibleElementOrdinalsInvalid();

    if (_view.maxElementWidthValid())
     {
      if (width() >= _view.maxElementWidth())
       {
        _view.setMaxElementWidthInvalid();
       }
     }

    if (_view.maxPrefixAreaWidthValid())
     {
      if (prefixAreaWidth() >= _view.maxPrefixAreaWidth())
       {
        _view.setMaxPrefixAreaWidthInvalid();
       }
     }
   }
 }

 boolean expandHideVisible()
 {
  return _view.forceAllVisible() || forceVisible() ||
         ((_classes & _view.includedClasses()) != 0 &&
          (_classes & _view.excludedClasses()) == 0 &&
          _view.markList().visible(_element) &&
          (!_element.show() || show()));
 }

 boolean visible()
 {
  if (_view.forceAllVisible())
   {
    return true;
   }

  _view.validateVisibleElements();
  return (expandHideVisible() || expandedVisible()) &&
         (!_element.show() || show());
 }

 int visibleOrdinal()
 {
  return _visibleOrdinal;
 }

 void setVisibleOrdinal(int visibleOrdinal)
 {
  _visibleOrdinal = visibleOrdinal;
 }

 ParsePending parsePending()
 {
  return _parsePending;
 }

 void setParsePending(ParsePending parsePending)
 {
  _parsePending = parsePending;
 }

 void setPrefixText(String prefixText)
 {
  _prefixText = prefixText;
 }

 String prefixText()
 {
  return _prefixText;
 }

 int prefixEnd()
 {
  return (_prefixText != null)? _prefixText.length() + 1 : 1;
 }

 int prefixScroll()
 {
  return _prefixScroll;
 }

 void setPrefixScroll(int prefixScroll)
 {
  _prefixScroll = prefixScroll;
 }

 void setForceVisible(boolean forceVisible)
 {
  if (forceVisible)
   {
    _flags |= FORCE_VISIBLE;
   }
  else
   {
    _flags &= ~FORCE_VISIBLE;
   }
 }

 boolean forceVisible()
 {
  return (_flags & FORCE_VISIBLE) != 0;
 }

 void setExpanded(boolean expanded)
 {
  if (expanded != expanded())
   {
    if (expanded)
     {
      _flags |= EXPANDED;
     }
    else
     {
      _flags &= ~EXPANDED;
     }
    _view.setVisibleElementOrdinalsInvalid();
   }
 }

 boolean expanded()
 {
  return (_flags & EXPANDED) != 0;
 }

 void setExpandedVisible(boolean expandedVisible)
 {
  if (expandedVisible)
   {
    _flags |= EXPANDED_VISIBLE;
   }
  else
   {
    _flags &= ~EXPANDED_VISIBLE;
   }
 }

 boolean expandedVisible()
 {
  return (_flags & EXPANDED_VISIBLE) != 0;
 }

 /**
  * Optionally set and return the string to display for this element's text in
  * this view.  The display text will include:
  *  - sequence numbers (formatted for display),
  *  - expanded Tabs, and
  *  - emulation SO/SIs as needed.
  * Once set here (or re-set after a #resetDisplayText(), for example after
  * a text-editing operation, or a change in any of the settings affecting the
  * above), the display string of this ElementView is cached in _displayText for
  * fast retrieval next time.
  *
  * Called in here in several places, and also by Screen.show(),
  * PrintCommand.doCommand(), and View.saveAsHtml().
  *
  * <p>Example:<pre>
  *
  * element.text()             a b c T D e f g T h
  * + SO/SIs                   a b c T > D < e f g T h
  *
  *                            0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8
  * Tabs                       |               |               |
  *
  * + expanded Tabs            a b c           > D D < e f g   h      // D in source encoding
  * + sequence numbers   X X X a b c           > D D < e f g   h      //  (two bytes)
  *
  * In a non-DBCS font,
  * will display as:     X X X a b c           > D < e f g   h        // D as Unicode blob
  *                                                                   //  (one character-wide)
  *
  * a,b,c,d,e,f,g,h = SBCS chars
  * T = Tab char
  * D = DBCS char
  * XXX = sequence-numbers area
  * </pre>
  *
  * @return the element's display text for this view, or
  *         an empty string if none
  *
  * @see #displayStyle
  * @see #displayNetText
  */
 String displayText()
 {
  // have display text in the cache from previous processing?
  if (_displayText != null)
   {
    return _displayText;
   }

  String displayText = _element.text();  // get element text, "" if none

  boolean expandTabs = _element.tabs() && _view.currentExpandTabs();
  boolean addSequenceNumbers =
          !_view.currentHideSequenceNumbers() &&
          _view.document().elementList().sequenceNumbersWidth() != 0;

  /*======================================================*/
  /*  (a) no tabs to expand, no sequence numbers to show  */
  /*======================================================*/
  if (!expandTabs && !addSequenceNumbers)
   {
    // 1.- not even emulation SO/SIs!
    if (!_view.nls().displayingSosi())
     {
      return cacheDisplayText(displayText);
     }

    // 2.- OK, a couple SO/SIs...
    return cacheDisplayText(_view.nls().addSourceSosi(displayText));
   }

  /*====================================================================*/
  /*  (b) tabs to expand and/or SO/SIs and/or sequence numbers to show  */
  /*====================================================================*/
  /*-----------------------------------------------------------------------*/
  /* SO/SI: add emulation SO/SIs here, *before* calculating tab expansions */
  /*-----------------------------------------------------------------------*/
  if (_view.nls().displayingSosi())
   {
    displayText = _view.nls().addSourceSosi(displayText);
   }

  /*-------------*/
  /* expand Tabs */
  /*-------------*/
  if (expandTabs)
   {
    displayText = _view.expandTextTabs(displayText);
   }

  // if the view shows sequence numbers, include them, formatted for display
  // according to the current sequenceNumbersFormat setting for the view
  if (addSequenceNumbers)
   {
    String sequenceNumbers = _view.document().elementList()
                                             .getSequenceNumbersDisplayString(_element, _view);
    if (sequenceNumbers.length() != 0)
     {
      displayText = sequenceNumbers + displayText;
     }
   }

  // cache display text info now
  return cacheDisplayText(displayText);
 }

 /**
  * Optionally create (when needed) and return the bidi information for this
  * ElementView.  This will be created when LpexUtilities.isBidi() returns true
  * (i.e., the running environment supports bidirectional functionality).
  */
 DisplayTextBidi displayTextBidi()
 {
  if (_displayTextBidi == null && LpexUtilities.isBidi())
   {
    _displayTextBidi = new DisplayTextBidi(this);
   }
  return _displayTextBidi;
 }

 /**
  * Retrieve a displayText without any emulation SO/SIs.
  * This method is used by save 'visible' (see View.save()).
  * If there are SO/SIs on the screen, Tabs will now be expanded differently
  * than what's on the display, but tabs & SO/SIs shouldn't really go together
  * anyway...
  *
  * @see #displayText
  */
 String displayNetText()
 {
  /*========================*/
  /*  (a) no SO/SIs anyway  */
  /*========================*/
  if (!_view.nls().displayingSosi())
   {
    return displayText();
   }

  /*===================================================================*/
  /*  (b) SO/SIs [and tabs to expand and/or sequence numbers to show]  */
  /*===================================================================*/
  boolean expandTabs = _element.tabs() && _view.currentExpandTabs();
  boolean addSequenceNumbers =
          !_view.currentHideSequenceNumbers() &&
          _view.document().elementList().sequenceNumbersWidth() != 0;
  String displayText = _element.text();

  /*-------------*/
  /* expand Tabs */
  /*-------------*/
  if (expandTabs)
   {
    displayText = _view.expandTextTabs(displayText);
   }

  // if the view shows sequence numbers, include them, formatted for display
  // according to the current sequenceNumbersFormat setting for the view
  if (addSequenceNumbers)
   {
    String sequenceNumbers = _view.document().elementList()
                                             .getSequenceNumbersDisplayString(_element, _view);
    if (sequenceNumbers.length() != 0)
     {
      displayText = sequenceNumbers + displayText;
     }
   }

  return displayText;
 }

 /**
  * Reset any cached display info for this element view.  This is done when
  * displayText must be recalculated - e.g., text changed / expandTabs changed /
  * showSosi changed / hideSequenceNumbers changed.
  *
  * @see #resetDisplayTextBidi
  */
 void resetDisplayText()
 {
  _displayText = null;
  if (_displayTextBidi != null)
     _displayTextBidi.reset();
  _displayStyle = null;
  setWidthInvalid();
 }

 /**
  * Reset any cached bidi info for this element view.  This is done when
  * bidi info must be recalculated - e.g., the view's font changed.
  *
  * @see #resetDisplayText
  */
 void resetDisplayTextBidi()
 {
  if (_displayTextBidi != null)
     _displayTextBidi.reset();
 }

 /**
  * Cache a new _displayText, and ensure that _displayTextBidi information
  * is re-set.
  */
 private String cacheDisplayText(String text)
 {
  _displayText = text;
  if (_displayTextBidi != null)
     _displayTextBidi.reset();
  return _displayText;
 }

 /**
  * Return the element's style string for this view, or an empty string if none.
  */
 String style()
 {
  return (_style == null)? "" : _style;
 }

 /**
  * Invalidate the cached display style string for this element in this view.
  */
 void resetDisplayStyle()
 {
  _displayStyle = null;
 }

 /**
  * Retrieve the display style for this element's text.
  * The display style must be kept in sync with the element's display text.
  * It is adjusted to the text for sequence numbers (formatted for display),
  * expanded Tabs, and emulation SO/SIs as needed.
  *
  * Whatever needs time-consuming processing (expanding tabs, adding SO/SIs,
  * etc.) is done once & cached in _displayStyle for faster retrieval next time.
  *
  * @see #displayText
  */
 String displayStyle()
 {
  if (_displayStyle != null)
   {
    return _displayStyle; // cached copy already available.
   }

  ElementList elementList = _view.document().elementList();
  boolean addSequenceNumbers =
          !_view.currentHideSequenceNumbers() &&
          elementList.sequenceNumbersWidth() != 0;
  LpexNls nls = _view.nls();

  _displayStyle = _view.markList().style(_element, _style);
  if (_displayStyle == null)
   {
    _displayStyle = "";
   }

  /*====================================*/
  /*  adjust style for Tabs and SO/SIs  */
  /*====================================*/
  // retrieve this element's text
  String text = _element.text();

  if (!_element.tabs() || !_view.currentExpandTabs())
   {
    if (nls.displayingSosi())
     {
       _displayStyle = nls.addSosiStyle(_displayStyle, text);
     }

    if (addSequenceNumbers)
     {
      _displayStyle = _view.getSequenceNumbersStyle() + _displayStyle;
     }

    return _displayStyle;
   }

  /*-------------------------------------------------------------------*/
  /* SO/SI: adjust to the emulation SO/SIs here, *before* calculating  */
  /* tab expansions, exactly like we do with the text in displayText() */
  /*-------------------------------------------------------------------*/
  if (nls.displayingSosi())
   {
    _displayStyle = nls.addSosiStyle(_displayStyle, text);
    text = nls.addSourceSosi(text); // sync text for the '\t' checks
   }

  /*-------------*/
  /* expand Tabs */
  /*-------------*/
  _displayStyle = _view.expandStyleTabs(_displayStyle, text);

  /*==========================================*/
  /*  add the style for the sequence numbers  */
  /*==========================================*/
  if (addSequenceNumbers)
   {
    _displayStyle = _view.getSequenceNumbersStyle() + _displayStyle;
   }

  return _displayStyle;
 }

 void setStyle(String style)
 {
  _style = style;
  _displayStyle = null;
 }

 boolean expandHideHeader()
 {
  if (expandHideVisible())
   {
    for (Element element = _element.next();
         element != null;
         element = element.next())
     {
      ElementView elementView = element.elementView(_view);
      if (elementView.expandHideVisible())
       {
        return false;
       }
      if (!element.show() || elementView.show())
       {
        return true;
       }
     }
   }

  return false;
 }

 /**
  * Returns the text for the expand/hide area for this element, or
  * an empty String if the element is not an expande/hide [+]/[-] header.
  */
 String expandHideText()
 {
  if (expandHideHeader())
   {
    return expanded()? "-" : "+";
   }
  return "";
 }


 /**
  * One mark for this element in this view.
  * This element view's marks are linked in a list _firstMarkNode.
  */
 static final class MarkNode
 {
  MarkList.Mark _mark;
  MarkNode _next;

  MarkNode(MarkList.Mark mark)
  {
   _mark = mark;
  }

  MarkList.Mark mark()
  {
   return _mark;
  }
 }
}