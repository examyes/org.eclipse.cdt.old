//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// HLAsmParser - document parser for High Level Assembler.
//----------------------------------------------------------------------------

package com.ibm.lpex.hlasm;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import com.ibm.lpex.core.HelpCommand;
import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCommand;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import com.ibm.lpex.util.LpexSysutil;


//-as- to do proto for instruction formats!? (read it from iTable!?)


/**
 * Document parser for HLASM (High Level Assembler).
 *
 * <p>Actions added by this language parser: <b>asmInstructions, tpfMacros,
 * branches, errors, comments</b> for selective views of the document:
 * assembler instructions, TPF macros, branch instructions and labels, errors,
 * and comments.
 *
 * <br>Commands added by this parser: <b>queryUserMacrosFile, setUserMacrosFile</b>
 * to query and set a custom file of supported macro instructions.
 */
public class HLAsmParser extends LpexCommonParser
{
   // whether the help index has been loaded, and the index .properties file
   private static boolean properties_loaded;
   private static Properties helpPages;

   private static ResourceBundle resource =
      ResourceBundle.getBundle("com.ibm.lpex.hlasm.Profile");

   // LPEX classes we use
   static final String
      CLASS_CONTINUE   = "continue",
      CLASS_FWDLINK    = "forwardLink",  // double link macro header elements:
      CLASS_BWDLINK    = "backwardLink", //  MACRO .. MEND
      CLASS_CODE       = "code",
      CLASS_COMMENT    = "comment",
      CLASS_ERROR      = "error",
      CLASS_SEQUENCE   = "sequence",
      CLASS_QSTRING    = "qString",
      CLASS_REMARK     = "remark",
      CLASS_OPERAND    = "operand",
      CLASS_PENDINGOP  = "pendingOp",
      CLASS_OPERLINE   = "operLine",
      CLASS_MACHINEINS = "machineIns",
      CLASS_ASSEMINS   = "assemIns",
      CLASS_TPFMACRO   = "tpfMacro",
      CLASS_LABEL      = "label",
      CLASS_BRANCH     = "branch",
      CLASS_UNKNOWN    = "unknown",      // unknown macro / incorrect operation
      CLASS_ASMMACROB  = "asmMacroB",    // macro definition begin
      CLASS_ASMMACROE  = "asmMacroE",    // macro definition end
      CLASS_ASMMACRON  = "asmMacroN",    // macro definition name
      CLASS_MACROCALL  = "macroCall";    // macro instruction

   // & the corresponding class bits for *this* view (parser instance)
   private long
      classContinue,
      classForwardLink,
      classBackwardLink,
      classCode,
      classComment,
      classError,
      classSequence,
      classQString,
      classRemark,
      classOperand,
      classPendingOp,
      classOperLine,
      classMachineIns,
      classAssemIns,
      classTpfMacro,
      classLabel,
      classBranch,
      classUnknown,
      classAsmMacroB,
      classAsmMacroE,
      classAsmMacroN,
      classMacroCall,
      classAll;

   // parsing macro definitions
   //
   // Macro definition:
   //   macro def header:            MACRO
   //   prototype:          &LABEL   MACID    &PARAM1,&PARAM2
   //                                .. body of macro ..
   //   macro def trailer:           MEND
   //
   // Macro instruction:             MACID    OPERAND1,OPERAND2
   private int macroState;
   private static final int
      MACRO_NONE   = 0x00000000,
      MACRO_HEADER = 0x00000001,      // found def header, searching for prototype
      MACRO_PROTO  = 0x00000002;      // found prototype, looking for end

   String  Specials = "+-,=.*()`/&";

   StringBuffer m_font;               // fonts for the line
   String       m_all_operands = "";
   long         m_classes;
   long         m_prev_classes;
   int          m_paren;              // paren count (i.e. '(' ')')
   Instruction  m_instruction;        // instruction

   StringNode   m_seqMacros;          // list of macros defined in this doc
   private int firstMacroName, lastMacroName; // doc's first, last macro def name

   static Instruction instructions;   // supported instructions, loaded in
   static int ii;                     // index into Instructions
   static boolean userMacrosRead;     // user instructions read in?
   static BufferedReader userReader;
   private static final int
      ITYPE_UNDEFINED  = 0,
      ITYPE_MACHINE    = 1,
      ITYPE_ASSEMBLER  = 2,
      ITYPE_TPF        = 3,
      ITYPE_SPECIALS   = 4,
      ITYPE_REGISTERS  = 5,
      ITYPE_ATTRIBUTES = 6,
      ITYPE_USER       = 7;


   /**
    * Constructor for the parser.
    * @param  lpexView  the LPEX document view associated with this parser.
    */
   public HLAsmParser(LpexView lpexView)
   {
      super(lpexView);        // LpexCommonParser constructor (view := lpexView)
      initializeParser();     // initialize LpexView with our stuff
      loadInstrTable();       // load table of instructions
   }

   /**
    * Returns the parser's properties profile resource bundle.
    */
   public ResourceBundle getProfile()
   {
      return resource;
   }

   /**
    * Return "HLASM", the language supported by this parser.
    * @see com.ibm.lpex.core.LpexCommonParser#LANGUAGE_HLASM
    */
   public String         getLanguage()
   {
      return LANGUAGE_HLASM;
   }

   /**
    * Initialize the parser for an LPEX document view:  set up style attributes
    * for the styles we need, classes, etc., and initialize the view
    * for the language-sensitive edit features supported.
    */
   private void          initializeParser()
   {
      // set attributes for the styles we use
      String tokenHighlight = getProperty("tokenHighlight");
      setStyleAttributes(tokenHighlight == null || !tokenHighlight.equals("off"));

      // register the classes we use
      // & get their allocated bit-masks
      classContinue     = view.registerClass(CLASS_CONTINUE);
      classForwardLink  = view.registerClass(CLASS_FWDLINK);
      classBackwardLink = view.registerClass(CLASS_BWDLINK);
      classCode         = view.registerClass(CLASS_CODE);
      classComment      = view.registerClass(CLASS_COMMENT);
      classError        = view.registerClass(CLASS_ERROR);
      classSequence     = view.registerClass(CLASS_SEQUENCE);
      classQString      = view.registerClass(CLASS_QSTRING);
      classRemark       = view.registerClass(CLASS_REMARK);
      classOperand      = view.registerClass(CLASS_OPERAND);
      classPendingOp    = view.registerClass(CLASS_PENDINGOP);
      classOperLine     = view.registerClass(CLASS_OPERLINE);
      classMachineIns   = view.registerClass(CLASS_MACHINEINS);
      classAssemIns     = view.registerClass(CLASS_ASSEMINS);
      classTpfMacro     = view.registerClass(CLASS_TPFMACRO);
      classLabel        = view.registerClass(CLASS_LABEL);
      classBranch       = view.registerClass(CLASS_BRANCH);
      classUnknown      = view.registerClass(CLASS_UNKNOWN);
      classAsmMacroB    = view.registerClass(CLASS_ASMMACROB);
      classAsmMacroE    = view.registerClass(CLASS_ASMMACROE);
      classAsmMacroN    = view.registerClass(CLASS_ASMMACRON);
      classMacroCall    = view.registerClass(CLASS_MACROCALL);

      classAll = classContinue | classForwardLink | classBackwardLink |
                 classCode | classComment | classError |
                 classSequence | classQString | classRemark |
                 classOperand | classPendingOp | classOperLine | classMachineIns |
                 classAssemIns | classTpfMacro | classLabel | classBranch |
                 classUnknown | classAsmMacroB | classAsmMacroE | classAsmMacroN |
                 classMacroCall;


      // add view filter action - errors
      LpexAction lpexAction = new LpexAction() {      // "errors"
         public void    doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " +
                       CLASS_ERROR + " " + CLASS_UNKNOWN + " " + CLASS_MESSAGE);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { // could check if any errors in doc...
           return true; }
         };
      view.defineAction("errors", lpexAction);

      // view filter action - assembler instructions
      lpexAction = new LpexAction() {                 // "asmInstructions"
         public void    doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_ASSEMINS);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("asmInstructions", lpexAction);

      // view filter action - TPF macros
      lpexAction = new LpexAction() {                 // "tpfMacros"
         public void    doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_TPFMACRO);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("tpfMacros", lpexAction);

      // view filter action - branch instructions and labels
      lpexAction = new LpexAction() {                 // "branches"
         public void    doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " +
                       CLASS_BRANCH + " " + CLASS_LABEL);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("branches", lpexAction);

      // view filter action - comments
      lpexAction = new LpexAction() {                 // "comments"
         public void    doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_COMMENT);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("comments", lpexAction);

      // query the name of the user macros file
      LpexCommand lpexCommand = new LpexCommand() {   // "queryUserMacrosFile"
         public boolean doCommand(LpexView view, String params)
         { view.doDefaultCommand("set messageText userMacrosFile "+getUserMacrosFile());
           return true; }
         };
      view.defineCommand("queryUserMacrosFile", lpexCommand);

      // set the name of the user macros file
      lpexCommand = new LpexCommand() {               // "setUserMacrosFile"
         public boolean doCommand(LpexView view, String params)
         { setUserMacrosFile(params);
           return true; }
         };
      view.defineCommand("setUserMacrosFile", lpexCommand);
   }

   /**
    * Return parser's items for the popup View submenu.
    */
   public String   getPopupViewItems()
   {
      return getLanguage() + ".popup.asmInstructions asmInstructions " +
             getLanguage() + ".popup.branches branches " +
             getLanguage() + ".popup.tpfMacros tpfMacros " +
             getLanguage() + ".popup.comments comments " +
             MSG_POPUP_ERRORS + " errors";
   }

   /**
    * Define parser's style attributes.
    * @param colours true = token highlighting,
    *                false = no token highlighting
    */
   public void     setStyleAttributes(boolean colours)
   {
      // dummy style 'O' is reserved for temporary macro names, do not use!
      String toBackground = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                        BACKGROUND_COLOR, toBackground);
      if (colours) {
         setStyle("_t", attributes);   // Layout blanks, Special symbol/character

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("cr", attributes);   // Line comment, Statement remark

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_ERROR,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("x",  attributes);   // Error

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("s",  attributes);   // TPF macro instruction

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_STRING,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("n",  attributes);   // Single-quoted string

         attributes = LpexPaletteAttributes.convert("128 128 128 255 255 255",
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("pv", attributes);   // Statement name/label, Sequence information

         attributes = LpexPaletteAttributes.convert("0   0   128 255 255 255",
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("qz", attributes);   // Machine instruction, Default text

         attributes = LpexPaletteAttributes.convert("0   128 0   255 255 255",
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("a",  attributes);   // Assembler instruction

         attributes = LpexPaletteAttributes.convert("0   0   0   0   255 0",
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("w",  attributes);   // Continuation character
         }
      else // drop the nice colours
         setStyle("pqavwz_tcrxsn", attributes);
   }

   /**
    * Total parse of the entire document.
    */
   public void     parseAll()                         // total parse
   {
      m_prev_classes = 0;
      m_instruction = null;
      firstMacroName = 0;
      lastMacroName = 0;
      macroState = MACRO_NONE;

      // first parse the entire doc
      int element = 1, endElement = view.elements();
      do {
         if (!view.show(element)) {
            parseLine(element);
            m_prev_classes = m_classes;
            }
         } while (++element <= endElement);

      if (macroState == MACRO_HEADER)
         parserMsg(endElement, "expectingMacroId", 0);
      else if (macroState == MACRO_PROTO)
         parserMsg(endElement, "expectingMacroEnd", 0);

      // if any macros defined in the doc, find them & fix-up macro calls
      if (firstMacroName != 0) {
         recordMacroNames(firstMacroName);
         fixupMacroCalls();
         }
   }

   /**
    * Incremental parse.
    * @param element the element whose committed change triggered the parse,
    *                or the element that precedes / follows a deleted block.
    *                The parser may identify other neighbouring elements that
    *                will have to be reparsed as a unit
    */
   public void     parseElement(int changedElement)   // incremental parse
   {
      m_classes = 0;
      m_prev_classes = 0;
      m_instruction = null;
      macroState = MACRO_NONE;

      // find beginning line for the previous operation / go back to the
      // beginning of a (doubly-linked) macro definition
      int element  = changedElement;
      int elements = view.elements();

      while (--element >= 1)
         if (!view.show(element)) {
            long classes = view.elementClasses(element);
            if ((classes & (classOperLine | classComment)) != 0 &&
                (classes & classBackwardLink) == 0)
            // *as* !? don't go all the way back to the beginning of a macro
            // definition - if we can establish that macroState == MACRO_PROTO,
            // then stop & just set it: macroState = MACRO_PROTO...
               break;
            }
      if (element < 1)
         element = 1;

      // keep track of range actually parsed
      int beginElement = element, endElement = element;

      /*------------------------------------------------------------*/
      /*  parse until end of continuation and a new operation line  */
      /*------------------------------------------------------------*/
      long oldClass = 0;                            // parsed line's old classes
      do {
         if (!view.show(element)) {
            oldClass = view.elementClasses(element);
            parseLine(endElement=element);          // parse element &
            view.elementParsed(element);            //  drop it off pending list
            m_prev_classes = m_classes;
            }

         if (++element > elements)
            break;

         } while ((element <= changedElement) ||
                  // this line continues or used to: go on...
                  ((m_classes & classContinue) != 0) ||
                  ((oldClass  & classContinue) != 0) ||
                  ((view.elementClasses(element) &
                        (classOperLine | classComment)) == 0) ||
                  // go on if looking for a macro name
                  (macroState == MACRO_HEADER) ||
                  // go on if a macro definition has been now removed
                  (macroState == MACRO_NONE && (oldClass & classForwardLink) != 0) ||

                  // NOTE: if adding counter for nested macros, may have to
                  // give up on this shortcut below!...
                  // go on if still waiting for MEND, unless was beforehand too
                  (macroState == MACRO_PROTO &&
                   ((view.elementClasses(element) &
                        (classForwardLink | classBackwardLink)) !=
                        (classForwardLink | classBackwardLink))));

      if (macroState == MACRO_HEADER)
         parserMsg(elements, "expectingMacroId", 0);
      else if (macroState == MACRO_PROTO && element > elements)
         parserMsg(elements, "expectingMacroEnd", 0);

      /*-----------------------------------------------------*/
      /*  get rid of old error messages in the parsed range  */
      /*-----------------------------------------------------*/
      removeMessages(beginElement, endElement);

      // if any macros defined in the doc, find them & fix-up macro calls
      if (firstMacroName != 0) {
         if (beginElement > lastMacroName)       // macros list didn't change
            fixupMacroCalls(beginElement, endElement); //  fix-up changed range
         else {                                  // macros list may have changed
            recordMacroNames(firstMacroName);    //  update it
            fixupMacroCalls();                   //  fix-up entire doc
            }
         }
   }

   /**
    * Retrieve the fully-qualified name of the user macros file.
    */
   public String   getUserMacrosFile()
   {
      String userMacrosFile = getProperty("userMacrosFile");
      if (userMacrosFile == null) {                     // none set, use default
         userMacrosFile = LpexSysutil.getUserHomeDirectory();
         userMacrosFile += File.separator + "HLAsmParser.dat";
         }
      return userMacrosFile;
   }

   /**
    * Set the fully-qualified name of the user macros file.
    */
   private void    setUserMacrosFile(String fileName)
   {
      setProperty("userMacrosFile", fileName);
   }

   /**
    * Load the static table(s) of supported instructions, registers, etc.
    */
   private void    loadInstrTable()
    {
     if (instructions != null)
      {
       return;
      }

     int iType = ITYPE_UNDEFINED;
     String  line, lineX = "";
     boolean cont = false;

     while ((line=nextInstruction()) != null)
      {
       if (line.length() > 0 && line.charAt(0) <= ' ' && line.charAt(line.length() - 1) <= ' ')
        {
         line = line.trim();
        }
       if (line.length() == 0 || line.charAt(0) == '*')
        {
         continue;
        }

       if (!cont)
        {
         lineX  = line;
        }
       else
        {
         lineX += line;
        }

       if (line.charAt(line.length() - 1) == ',')
        {
         cont = true;
         continue;
        }
       else
        {
         cont = false;
        }

       if (lineX.charAt(0) == '[')     // a new data type is indicated
        {
         if (lineX.equals("[MACHINE]"))
          {
           iType = ITYPE_MACHINE;
          }
         else if (lineX.equals("[ASSEMBLER]"))
          {
           iType = ITYPE_ASSEMBLER;
          }
         else if (lineX.equals("[TPF]"))
          {
           iType = ITYPE_TPF;
          }
         else if (lineX.equals("[SPECIALS]"))
          {
           iType = ITYPE_SPECIALS;
          }
         else if (lineX.equals("[REGISTERS]"))
          {
           iType = ITYPE_REGISTERS;
          }
         else if (lineX.equals("[ATTRIBUTES]"))
          {
           iType = ITYPE_ATTRIBUTES;
          }
         else if (lineX.equals("[USER]"))
          {
           iType = ITYPE_USER;
          }
         else
          {
           iType = ITYPE_UNDEFINED;
          }
        }
       else if (iType == ITYPE_MACHINE)     // - instructions
        {
         new Machine(lineX);
        }
       else if (iType == ITYPE_ASSEMBLER)
        {
         new Assembler(lineX);
        }
       else if (iType == ITYPE_TPF)
        {
         new TPFmacros(lineX);
        }
       else if (iType == ITYPE_SPECIALS)    // - override default specials
        {
         Specials = Asm.word(lineX, 1);
        }
       else if (iType == ITYPE_REGISTERS)   // - define registers (with an
        {                                   //   after-space for search)
         Asm.Registers += lineX + " ";
        }
       else if (iType == ITYPE_ATTRIBUTES)  // - override default attributes
        {
         Asm.Attributes = Asm.word(lineX, 1);
        }
       else if (iType == ITYPE_USER)        // - user stuff!??
        {
        }
      }
    }

   /**
    * Retrieve the next instruction-format line.
    * This method is being called repeatedly to set up the parser's instructions
    * table, until it returns <code>null</code>.
    *
    * <p>The method can be extended by a subclassing parser to add custom
    * macros/instructions.
    */
   public String   nextInstruction()
   {
      if (ii < HLAsmInstructions.Instructions.length)   // built-in instructions
         return HLAsmInstructions.Instructions[ii++];
      return nextUserInstruction();                     // user instructions
   }

   /**
    * Retrieve the next user instruction-format line.
    * It is being called repeatedly to set up the parser's instructions table,
    * until it returns <code>null</code>.
    */
   private String  nextUserInstruction()
   {
      // didn't do the loading of the user instructions yet?
      if (userMacrosRead)
         return null;

      // open the user instructions file
      if (userReader == null) {
         try {
            userReader=new BufferedReader(new FileReader(new File(getUserMacrosFile())));
            // as a first line, return "[TPF]" - the default instruction type,
            // just in case there isn't any in the user file...
            return "[TPF]";
            }
         catch (java.io.FileNotFoundException e) {
            return null;
            }
         }

      // retrieve one user instruction-definition line
      try {
         String line = userReader.readLine();
         if (line != null)
            return line;
         // end of the stream reached
         userReader.close();
         }
      catch (java.io.IOException e) {
         }

      userMacrosRead = true;
      return null;
   }

   /**
    * Parse one element.
    */
   private void    parseLine(int lxLine)              // parse one element
    {
     m_classes = 0;

     String line = view.elementText(lxLine);
     int len = line.length();
     if (m_font == null)
      {
       m_font = new StringBuffer((len > 80) ? len : 80);
      }
     m_font.setLength(len);
     //if (len>0) {
     // line.stripTrailing(WHITESPACE);
     // view.setElementText(lxLine,line);} // NB readonly doc, text limit, etc.

     /*============================================*/
     /*  CONTINUATION / SEQUENCE NUMBERS / MORE??  */
     /*============================================*/
     // first parse any stuff beyond column 71:
     // 72 = continuation, 73-80 = sequence numbers, 81-.. = errors.
     if (len > 71)
      {
       if (line.charAt(71) != ' ')
        {
         m_font.setCharAt(71, 'w');
         m_classes |= classContinue;
        }
       else
        {
         m_font.setCharAt(71, '_');
        }
       if (len > 72)
        {
         for (int i = 72; i < len && i < 80; i++)
          {
           m_font.setCharAt(i, 'v');
          }
         m_classes |= classSequence;
        }
       if (len > 80)
        {
         if (isBlank(line, 80, line.length()))
          {
           for (int i = 80; i < len; i++)
            {
             m_font.setCharAt(i, '_');
            }
          }
         else
          {                      // errors if any non-blanks after col 80
           for (int i = 80; i < len; i++)
            {
             m_font.setCharAt(i, 'x');
            }
           parserMsg(lxLine, "textBeyond80", 0);
          }
        }
      }

     /*=============*/
     /*  ANY BEEF?  */
     /*=============*/
     if (isBlank(line, 0, 70))
      {
       if ((m_prev_classes & classQString) != 0)
        {
         parserMsg(lxLine, "unendedString", 0);
        }
       if (macroState != MACRO_NONE)
        {
         if ((m_classes & classError) == 0)
          {
           m_classes |= classForwardLink | classBackwardLink;
          }
         else
          {
           macroState = MACRO_NONE;
          }
        }
       for (int i = 0; i < len && i < 71; i++)
        {
         m_font.setCharAt(i, '_');
        }
       view.setElementStyle(lxLine, m_font.toString());
       setElementClasses(lxLine);
       return;
      }

     /*--------------------*/
     /*  (a) COMMENT LINE  */
     /*--------------------*/
     if (line.startsWith("*") || line.startsWith(".*"))
      {
       for (int i = 0; i < len && i < 71; i++)
        {
         m_font.setCharAt(i, 'c');
        }
       m_classes |= classComment;
       if (macroState != MACRO_NONE)
        {
         if ((m_classes & classError) == 0)
          {
           m_classes |= classForwardLink | classBackwardLink;
          }
         else
          {
           macroState = MACRO_NONE;
          }
        }
       view.setElementStyle(lxLine, m_font.toString());
       setElementClasses(lxLine);
       return;
      }

     /*---------------------------------------------------*/
     /*  (b) THIS IS THE CONTINUATION OF A PREVIOUS LINE  */
     /*---------------------------------------------------*/

     if ((m_prev_classes & classContinue) != 0)
      {
       //  ENFORCE CONTINUATION RULES
       if ((line.length() < 16) && isBlank(line))
        {
         for (int i = 0; i < len; i++)
          {
           m_font.setCharAt(i, '_');
          }
        }
       else if (!isBlank(line, 0, 15))
        {
         for (int i = 0; i < 15 && i < len; i++)
          {
           m_font.setCharAt(i, 'x');
          }
         for (int i = 15; i < len && i < 71; i++)
          {
           m_font.setCharAt(i, 'z');
          }
         parserMsg(lxLine, "textBelow15", 0);
        }

       //  THIS LINE CONTINUES AN OPERAND
       else if ((m_prev_classes & (classOperand | classPendingOp)) != 0)
        {
         int pos = 0;
         if ((m_instruction == null) ||
             (m_instruction.HasOperands()))
          {
           pos = parseLayout(line, 0, 70);
           pos = parseOperands(line, lxLine, pos, m_prev_classes);
          }
         pos = parseLayout(line, pos, 70);
         parseRemarks(line, pos);
        }

       //  THIS LINE CONTINUES A COMMENT LINE / PREV LINE'S REMARKS
       else
        {
         if (!isBlank(line, 0, 16))
          {
           for (int i = 0; i < 16 && i < len; i++)
            {
             m_font.setCharAt(i, 'x');
            }
           for (int i = 16; i < len && i < 71; i++)
            {
             m_font.setCharAt(i, 'z');
            }
           parserMsg(lxLine, "textBelow16", 0);
          }
         else
          {
           parseRemarks(line, 0);
          }
        }

       if (macroState != MACRO_NONE)
        {
         if ((m_classes & classError) == 0)
          {
           m_classes |= classForwardLink | classBackwardLink;
          }
         else
          {
           macroState = MACRO_NONE;
          }
        }
       view.setElementStyle(lxLine, m_font.toString());
       setElementClasses(lxLine);
       return;
      }

     /*------------------------------------------*/
     /*  (c) NON-COMMENT LINE, NOT CONTINUATION  */
     /*------------------------------------------*/
     int pos = 0;
     if (!Character.isWhitespace(line.charAt(0)))
      {
       pos = parseName(line);                  // parse the instruction's label
      }

     pos = parseLayout(line, pos, 70); // parse following layout blanks
     pos = parseOperation(line, lxLine, pos); // parse the operation
     pos = parseLayout(line, pos, 70);
     parseRemarks(line, pos);

     // on errors, give up on looking for the current macro definition
     if (macroState != MACRO_NONE)
      {
       if ((m_classes & classError) == 0)
        {
         m_classes |= classForwardLink | classBackwardLink;
        }
       else
        {
         macroState = MACRO_NONE;
        }
      }
     view.setElementStyle(lxLine, m_font.toString());
     setElementClasses(lxLine);
    }

   /**
    * Parse layout blanks.
    * Updates m_font.
    *
    * @return position where parse left off (first non blank)
    */
   private int     parseLayout(String line, int startColumn, int endColumn)
    {
     int i = startColumn;
     for (i = startColumn;
          i <= endColumn && i < line.length() && Character.isWhitespace(line.charAt(i));
          i++)
      {
       m_font.setCharAt(i, '_');
      }
     return i;
    }

   /**
    * Parse an instruction's label.
    * Updates m_font, m_classes.
    *
    * @return position where parse left off
    */
   private int     parseName(String line)
    {
     int endname = -1;
     if (line.charAt(0) == '\'')
      {
       endname = line.indexOf('\'',1);
      }
     else
      {
       for (int i = 0; i < line.length(); i++)
        {
         if (line.charAt(i) <= ' ')
          {
           endname = i - 1;
           break;
          }
        }
      }
     if (endname < 0)
      {
       endname = line.length();
      }
     if (endname >= 71)
      {
       endname = 70;
      }

     for (int i = 0; i <= endname && i < line.length(); i++)
      {
       m_font.setCharAt(i, 'p');
      }
     m_classes |= classCode | classLabel;
     return endname + 1;
    }

   /**
    * Parse the operation.
    * Sets the instruction (m_instruction), and updates m_font, m_classes.
    *
    * @return position where parse left off
    */
   private int     parseOperation(String line, int element, int startColumn)
    {
     m_instruction = null;
     m_classes |= classCode | classOperLine;
     m_all_operands = "";

     int endOperation = -1;
     for (int i = startColumn; i < line.length(); i++)
      {
       if (line.charAt(i) <= ' ')
        {
         endOperation = i - 1;
         break;
        }
      }
     if (endOperation < startColumn)
      {
       endOperation = line.length() - 1;
      }
     if (endOperation >= 71)
      {
       endOperation = 70;
      }

     Instruction inst = null;
     for (inst = instructions;
          (inst != null) && !Asm.stringsEqualIgnoreCase(inst._format, 0, inst._operationEnd,
                                                        line, startColumn, endOperation);
          inst = inst._next) {}

     /*---------------------------------------------------------------*/
     /*  record macro definition boundaries for later macro searches  */
     /*---------------------------------------------------------------*/
     // *as* add counter for nested macros!!

     // 1.- "MACRO"
     if (Asm.stringsEqualIgnoreCase(line, startColumn, endOperation, "MACRO"))
      {
       // HLASM S/390: "MACRO must not have a name entry" *as*
       m_classes |= classAsmMacroB | classForwardLink;
       macroState = MACRO_HEADER; // looking for the macro prototype now
      }
     // 2.- "MEND"
     else if (Asm.stringsEqualIgnoreCase(line, startColumn, endOperation, "MEND"))
      {
       if (macroState == MACRO_HEADER)
        {
         for (int i = startColumn; i <= endOperation; i++)
          {
           m_font.setCharAt(i, 'a');
          }
         m_classes |= classBackwardLink;
         parserMsg(element, "reservedWord", "MEND", 0);
         //macroState = MACRO_NONE;
         int end = parseLayout(line, endOperation + 1, 70);
         end = parseOperands(line, element, end, m_prev_classes);
         return end;
        }
       else if (macroState == MACRO_PROTO)
        {
         m_classes |= classBackwardLink | classAsmMacroE;
        }
       else
        { // MACRO_NONE
         m_classes |= classBackwardLink;
         parserMsg(element, "undefinedMacro", 106);
        }
       macroState = MACRO_NONE;
      }
     // 3.- macro prototype line
     else if (macroState == MACRO_HEADER)
      {
       if (endOperation < startColumn)
        {
         m_classes |= classBackwardLink;
         parserMsg(element, "expectingMacroId", 0);
         //macroState = MACRO_NONE;
        }
       // we have a macro name
       else
        {
         // use temp 'O', to be fixed-up in recordMacroNames()...
         for (int i = startColumn; i <= endOperation; i++)
          {
           m_font.setCharAt(i, 'O');
          }
         m_classes |= classBackwardLink | classForwardLink | classAsmMacroN;
         if ((firstMacroName == 0) || (element < firstMacroName))
          {
           firstMacroName = element;
          }
         if ((lastMacroName == 0) || (element > lastMacroName))
          {
           lastMacroName = element;
          }
         macroState = MACRO_PROTO;
        }
       int end = parseLayout(line, endOperation + 1, 70);
       end = parseOperands(line, element, end, m_prev_classes);
       return end;
      }
     // 4.- somewhere inside macro definition, before the "MEND"
     else if (macroState == MACRO_PROTO)
      {
       m_classes |= classBackwardLink | classForwardLink;
      }

     /*-------------------------*/
     /*  process the operation  */
     /*-------------------------*/
     if (inst != null)
      {
       for (int i = startColumn; i <= endOperation; i++)
        {
         m_font.setCharAt(i, inst.opFont);
        }
       m_classes |= view.classMask(inst.opClass);
       if (((m_classes & classMachineIns) != 0) &&
           line.charAt(startColumn) == 'B')
        {
         m_classes |= classBranch;
        }
       m_instruction = inst;
       int end = endOperation + 1;
       if (m_instruction.HasOperands())
        {
         end = parseLayout(line, end, 70);
         end = parseOperands(line, element, end, m_prev_classes);
        }
       return end;
      }

     else
      {
       for (int i = startColumn; i <= endOperation; i++)
        {
         m_font.setCharAt(i, 'x');
        }
       m_classes |= classUnknown;                             // unknown macro
       int end = parseLayout(line, endOperation + 1, 70);
       end = parseOperands(line, element, end, m_prev_classes);
       return end;
      }
    }

   private int     parseOperands(String line, int element, int startColumn, long classes)
    {
     String t_font;
     String f_operands = "";
     String m_operands = "";

     if ((classes & classContinue) == 0)
      {
       // not continuing operands, not continuing string, not pending operands
       m_classes &= ~(classOperand | classQString | classPendingOp);
       m_paren = 0;                              // reset character match counts
      }
     else
      {
       if ((classes & classOperand) != 0)       // continuing operands
        {
         m_classes |= classOperand;
        }
       if ((classes & classQString) != 0)       // continuing a string
        {
         m_classes |= classQString;
        }
      }

     int len = line.length();
     int pos;
     int end = startColumn - 1;

     /*--------------------------------------------------------------*/
     /*  parse operands in the line - i.e., up to a (real) blank...  */
     /*--------------------------------------------------------------*/
     for (pos = startColumn + 1; pos <= len && pos <= 71; pos++)
      {
       char chr = line.charAt(pos-1);
       if ((chr == ' ') &&
           ((m_classes & classQString) == 0) && (m_paren == 0))
        {
         break;
        }

       end = pos - 1;
       if (chr == '\'')
        {
         String DIGITS = "+-0123456789";
         boolean attrib_char =
                    ((pos > startColumn + 1) &&
                      ((m_classes & classQString) == 0)) &&
                    (Asm.Attributes.indexOf(line.charAt(pos-2)) >= 0);
         boolean good_prev_char =
                    (pos == startColumn + 2) ||
                    ((pos > startColumn + 2) && ((line.charAt(pos-3) == ' ') ||
                    (((line.charAt(pos-3) != '\'') &&
                      (line.charAt(pos-3) != '&')) &&
                      (Specials.indexOf(line.charAt(pos-3)) >= 0))));
         boolean digit_follows =
                   (pos < len && pos < 71) &&
                   (DIGITS.indexOf(line.charAt(pos)) >= 0);

         if (!attrib_char || !good_prev_char || digit_follows)
          {
           m_font.setCharAt(end, 'n'); // single-quoted string style
           m_classes  ^= classQString;
          }
         else
          {
           m_font.setCharAt(end, 't'); // special symbol / character style
          }
        }
       else if ((m_classes & classQString) != 0)
        {
         m_font.setCharAt(end, 'n');
        }
       else if (Specials.indexOf(chr) >= 0)
        {
         m_font.setCharAt(end, 't');
        }
       else
        {
         m_font.setCharAt(end, 'z');   // default style
        }

       m_operands += chr;                            // EXTRACT OPERANDS FIELD

       if ((m_classes & classQString) == 0)
        { // count parens if not in string
         if (chr == '(')
          {
           m_paren++;
          }
         else if (chr == ')')
          {
           m_paren--;
          }
        }
      }//end "for" thru line

     if (end < startColumn)
      {
       m_classes |= classPendingOp;      // still waiting for some operands...
      }

     m_classes &= ~classOperand;
     if (((m_classes & classContinue) != 0) &&
         ((m_operands.length() == 0) || (m_paren != 0) ||
           m_operands.endsWith(",")  ||
          ((len < pos || 71 < pos) && end == 70)))
      {
       m_classes |= classOperand;
      }

     m_classes |= classCode;

     // unended string? - use error style (rather than f_operands)
     if (((m_classes & classQString)  != 0) &&
         ((m_classes & classContinue) == 0))
      {
       for (int i = startColumn; i <= end; i++)
        {
         m_font.setCharAt(i, 'x');
        }
       parserMsg(element, "unendedString", 0);
       return end + 1;
      }

     if (m_instruction == null)
      {
       return end + 1;
      }

     m_all_operands += m_operands;

     if ((m_classes & classContinue) != 0)
      {
       m_classes |= classPendingOp;      // still waiting for some operands...
       return end + 1;
      }

     /*------------------------------------------------------------------*/
     /*  verify the operands as per particular instruction being parsed  */
     /*------------------------------------------------------------------*/
     int rc = m_instruction.ValidateOperands(m_all_operands);
     if (rc != 0)
      {
       parserMsg(element,                                    // line in error
                 "badOperand",                               // bad operand(s)
                 m_instruction.GetFormat(),                  // correct syntax
                 rc);                                        // return code
       for (Instruction inst = m_instruction._multiLevel; inst != null; inst = inst._next)
        {
         parserMsg(element,
                   "alternateSyntax",
                   inst.GetFormat(),
                   rc);
        }
      }

     return end + 1;
    }

   /**
    * Parse the (remaining) line as remarks:  m_font, m_classes.
    */
   private void    parseRemarks(String line, int startColumn)
    {
     if (startColumn < line.length() && startColumn < 71)
      {
       for (int i = startColumn; i < line.length() && i < 71; i++)
        {
         m_font.setCharAt(i, 'r');
        }
       m_classes |= classRemark;
      }
    }

   /**
    * Search for all doc's macro names and add them to our list m_seqMacros.
    * Classes were already set for the macro prototype (classAsmMacroN).
    *
    * @param line first line in document to scan from (there are no macro names
    *             below this element)
    */
   private void    recordMacroNames(int line)
   {
      // *as* could update first/lastMacroName here too - in parsing we only
      // update to *extend* this range, but never shrink it!...
      m_seqMacros = null;                          // empty the macro-names list
      int elements = view.elements();

      for (; line <= elements; line++) {
         if (view.show(line))
            continue;

         // macro name
         if ((view.elementClasses(line) & classAsmMacroN) != 0) {
            String style = view.elementStyle(line);
            int j, i = style.indexOf('O');
            if (i > 0) {
               for (j = i; j < style.length() && style.charAt(j) == 'O'; j++) {}
               String name = view.elementText(line).substring(i, j);
               style = style.substring(0, i) + styleString('a', j - i) +
                       style.substring(j);
               view.setElementStyle(line, style);      // re-set name's style
               StringNode temp = new StringNode(name);
               temp._next = m_seqMacros;
               m_seqMacros = temp;                     // add macro name to list
               }
            }
         }

      // no more macro names in entire doc...
      if (m_seqMacros == null) {
         firstMacroName = 0;
         lastMacroName = 0;
         }
   }

   /**
    * Once the list of macros defined in the doc is established, check against
    * the UNKNOWN lines and the macro-call lines.
    */
   private void    fixupMacroCalls()
   {
      fixupMacroCalls(1, view.elements());
   }

   /**
    * Once the list of macros defined in the doc is established, check against
    * the UNKNOWN lines and the macro-call lines.
    * If the macro definitions didn't change, it's enough to fix-up only the
    * macro calls located inside the parse range.
    */
   private void    fixupMacroCalls(int start, int end)
   {
      for (int line = start; line <= end; line++) {
         if (view.show(line))
            continue;

         long classes = view.elementClasses(line);
         if ((classes & (classUnknown | classMacroCall)) == 0)
            continue;

         String style = view.elementStyle(line);
         String text  = view.elementText(line);
         int i, j;

         if ((classes & classUnknown) != 0) {
            i = style.indexOf('x');
            if (i > 0) {
               for (j = i; j < style.length() && style.charAt(j) == 'x'; j++) {}
               String name = text.substring(i, j);
               for (StringNode stringNode = m_seqMacros;
                    stringNode != null;
                    stringNode = stringNode._next) {
                  if (name.equals(stringNode._string)) {
                     style = style.substring(0, i) + styleString('a', j - i) +
                             style.substring(j);
                     view.setElementStyle(line, style);
                     classes |= classMacroCall;
                     view.setElementClasses(line, classes & ~classUnknown);
                     break;
                     }
                  }//end "for"
               }
            }
         else { // classMacroCall
            i = style.indexOf('a');
            if (i > 0) {
               for (j = i; j < style.length() && style.charAt(j) == 'a'; j++) {}
               String name = text.substring(i, j);
               for (StringNode stringNode = m_seqMacros;
                    stringNode != null;
                    stringNode = stringNode._next) {
                  if (name.equals(stringNode._string)) {
                     i = -1; // found the macro name
                     break;
                     }
                  }//end "for"
               if (i > 0) { // macro not defined:
                  style = style.substring(0, i) + styleString('x', j - i) +
                          style.substring(j);
                  view.setElementStyle(line, style);
                  view.setElementClasses(line,
                                    (classes & ~classMacroCall) | classUnknown);
                  }
               }
            }
         }// end "for" all doc
   }

   /**
    * Set m_classes in the element.
    */
   private void    setElementClasses(int element)
   {
      long classes = view.elementClasses(element) & ~classAll; // others' +
      view.setElementClasses(element, classes | m_classes);    // our new classes
   }

   private void    parserMsg(int element, String msgId, int rc)
   {
      parserMsg(element, msgId, null, rc);
   }

   /**
    * Display an error message for the current <code>element</code>.
    * The current element classes (m_classes) also get a classError.
    */
   private void    parserMsg(int element, String msgId, String subst, int rc)
   {
      m_classes |= classError;
      msgId = getLanguage() + "." + msgId;
      String msg = null;
      if (subst == null)
         msg = LpexResources.message(msgId);
      else
         msg = LpexResources.message(msgId, subst);
      if (msg == null)
         msg = "";

      //if (rc != 0) {
      //   if (rc < 0)
      //       rc =- rc;
      //   msg = "HLA" + String.valueOf(rc) + "I " + msg;
      //   }

      //if (msg.length() > 100) {
      //   if (msg.charAt(96) == ' ')
      //      msg = msg.substring(0, 96);
      //   else {
      //      msg = msg.substring(0, 97);
      //      msg = msg.substring(0, msg.lastIndexOf(','));
      //      }
      //   msg = msg.trim() + " ...";
      //   }

      if (msg.length() > 0)
         addMessage(element, msg);
   }

   /**
    * Check if string is blank.
    */
   private boolean isBlank(String s)
   {
      int end = s.length();
      for (int start = 0; start < end; start++)
         if (s.charAt(start) != ' ' && s.charAt(start) != '\t')
            return false;

      return true;
   }

   /**
    * Check if <code>s.substring(start, end)</code> is blank.
    */
   private boolean isBlank(String s, int start, int end)
   {
      if (end > s.length())
         end = s.length();

      for (; start < end; start++)
         if (s.charAt(start) != ' ' && s.charAt(start) != '\t')
            return false;

      return true;
   }

   /**
    * Retrieve the name of the html help page that the parser identifies
    * as appropriate for the currently selected token.
    */
   public String   getHelpPage()
   {
      String helpPage = null;
      loadProperties();
      if (helpPages != null)
       {
        String token = getToken(view.documentLocation());
        if (token != null)
         {
          helpPage = helpPages.getProperty(token);
         }
       }
      return helpPage;
   }

   static private void loadProperties()
   {
      if (!properties_loaded) {
         helpPages = HelpCommand.loadHelpMap(HELP_HLASM);
         // whether the load succeeded or not, there's no point in trying
         // again until LPEX is restarted...
         properties_loaded = true;
         }
   }
}


/**
 * Various global data & static methods used throughout the parser.
 */
final class Asm
{
   static String Registers  = " ";  // an initial space
   static String Attributes = "TLSIKNDOtlsikndo";

   /**
    * Return the ONE-based <i>n</i>th white-space-delimited word in the string.
    */
   static String   word(String s, int n)
   {
      StringTokenizer st = new StringTokenizer(s);
      if (n > st.countTokens())
         return "";
      for (int i = 1;  i < n; i++)
         st.nextToken();
      return st.nextToken();
   }

   static boolean  stringsEqual(String s1, String s2)
   {
      return stringsEqual(s1, 0, s1.length() - 1, s2, 0, s2.length() - 1);
   }

   static boolean  stringsEqual(String s1, int start1, int end1, String s2)
   {
      return stringsEqual(s1, start1, end1, s2, 0, s2.length() - 1);
   }

   static boolean  stringsEqual(String s1, int start1, int end1,
                                String s2, int start2, int end2)
   {
      int len1 = end1 - start1 + 1;
      int len2 = end2 - start2 + 1;
      if (len1 <= 0 && len2 <= 0)
       {
        return true;
       }
      if (len1 == len2 && end1 < s1.length() && end2 < s2.length())
       {
        int i1 = start1;
        int i2 = start2;
        while (i1 <= end1)
         {
          if (s1.charAt(i1) != s2.charAt(i2))
           {
            return false;
           }
          i1++;
          i2++;
         }
        return true;
       }
      return false;
   }

   static boolean  stringsEqualIgnoreCase(String s1, int start1, int end1,
                                          String s2)
   {
      return stringsEqualIgnoreCase(s1, start1, end1, s2, 0, s2.length() - 1);
   }

   static boolean  stringsEqualIgnoreCase(String s1, int start1, int end1,
                                          String s2, int start2, int end2)
   {
      int len1 = end1 - start1 + 1;
      int len2 = end2 - start2 + 1;
      if (len1 <= 0 && len2 <= 0)
       {
        return true;
       }
      if (len1 == len2 && end1 < s1.length() && end2 < s2.length())
       {
        int i1 = start1;
        int i2 = start2;
        while (i1 <= end1)
         {
          if (Character.toUpperCase(s1.charAt(i1)) !=
              Character.toUpperCase(s2.charAt(i2)))
           {
            return false;
           }
          i1++;
          i2++;
         }
        return true;
       }
      return false;
   }
}


class Instruction
{
   Instruction _next;                  // next instruction

   char   opFont;                      // style character
   String opClass;                     //  & class

   String _format;                     // instruction format

   int _operationEnd;
   int _firstOperandStart;
   int _firstOperandEnd;

   Instruction _multiLevel;            // first multilevel

   static final int                    // nth operand characteristics:
      opInUse      = 0x0001,           //
      opRequired   = 0x0002,           //  defined without "[]"
      opPositional = 0x0004,           //
      opKeyword    = 0x0008,           //  defined with "="
      opRepeats    = 0x0010;           //  defined with "..."

   static Instruction lastInstruction; // last Instruction processed (used for
                           // multilevel-setting during instruction-table setup,
                           // for parser messages during the parsing)

   /**
    * Validate the operands of an instruction.
    * An 'abstract' method, overriden by the extending classes for the
    * particular instruction types.
    *
    * [parm]    = optional parameters
    * parm|parm = mutually-exclusive parameters
    * ...       = one or more parameters, keyword or positional, may be coded;
    *             can only be used at the end of a definition
    * [...]     = zero or more parameters, keyword or positional, may be coded;
    *             can only be used at the end of a definition
    * parm=     = keyword parameter;  must be defined in uppercase
    *
    * If the parameter is defined in uppercase, the item must be coded exactly
    * as stated;  if in lowercase, an item is required but can be anything.
    * If an instruction has different parameter requirements (dependent on what
    * the first parameter is defined as), more that one definition can be
    * entered, but all definitions must follow each other.
    */
   int         ValidateOperands(String operands)
   {
      return 12;
   }

   /**
    * Generic initialization for all the kinds of instructions:
    * record operation, operands, opFont, and opClass;  initialize verOperands;
    * handle multilevel support;  link it in.
    *
    * @param format   instruction format line read in
    * @param opFontX  style char for this instruction type
    * @param opClassX class bit for this instruction type
    */
   void        InstrInit(String format, char opFontX, String opClassX)
    {
     _format = format;
     for (_operationEnd = 0;
          _operationEnd + 1 < format.length() && format.charAt(_operationEnd + 1) > ' ';
          _operationEnd++) {}
     for (_firstOperandStart = _operationEnd + 1;
          _firstOperandStart < format.length() && format.charAt(_firstOperandStart) <= ' ';
          _firstOperandStart++) {}
     _firstOperandEnd = _firstOperandStart;

     if (_firstOperandStart < format.length())
      {
       while (_firstOperandEnd + 1 < format.length())
        {
         char c = format.charAt(_firstOperandEnd + 1);
         if (c <= ' ' || c == ',')
          {
           break;
          }
         _firstOperandEnd++;
        }//end "while"
      }
     else
      {
       _firstOperandEnd = _firstOperandStart - 1;
      }

     if (_firstOperandStart < format.length() &&
         _firstOperandEnd   < format.length() &&
         format.charAt(_firstOperandStart) == '[' &&
         format.charAt(_firstOperandEnd)   == ']')
      {
       _firstOperandEnd = _firstOperandStart - 1;
      }

     opFont  = opFontX;
     opClass = opClassX;

     if (lastInstruction != null &&
         Asm.stringsEqual(lastInstruction._format,
                          0, lastInstruction._operationEnd,
                          _format,
                          0, _operationEnd))
      {
       // same operation: add multilevel, to support another set of operands
       lastInstruction.addMultiLevel(this);
      }
     else
      {
       // a new operation: link it in
       lastInstruction = this;
       _next = HLAsmParser.instructions;
       HLAsmParser.instructions = this;
      }
    }

   String      GetFormat()
    {
     if (_firstOperandEnd >= _firstOperandStart &&
         _firstOperandStart - _operationEnd > 2)
      {
       return _format.substring(0, _operationEnd + 1) + " " +
              _format.substring(_firstOperandStart);
      }
     return _format;
    }

   boolean     HasOperands()
    {
     if (_firstOperandStart < _format.length())
      {
       return true;
      }
     for (Instruction inst = _multiLevel; inst != null; inst = inst._next)
      {
       if (inst._firstOperandStart < inst._format.length())
        {
         return true;
        }
      }
     return false;
    }

   int         formatOperandStart(int index)
    {
     while (index < _format.length())
      {
       char c = _format.charAt(index);
       if (c > ' ' && c != ',')
        {
         break;
        }
       index++;
      }
     return index;
    }

   int         formatOperandEnd(int index)
    {
     boolean done = false;
     int len = _format.length();
     while (index < len)
      {
       char c = _format.charAt(index);
       if (c == ',' || c == ' ')
        {
         return index - 1;
        }
       index++;
      }
     return len - 1;
    }

   int         operandEnd(String operands, int index)
    {
     int brackets = 0;
     boolean quoteOn = false;
     boolean done = false;
     int len = operands.length();
     while (index < len)
      {
       char c = operands.charAt(index);
       switch (c)
        {
         case ',':
          {
           if (!quoteOn && brackets == 0)
            {
             return index - 1;
            }
           break;
          }
         case '(':
          {
           if (!quoteOn)
            {
             brackets++;
            }
           break;
          }
         case ')':
          {
           if (!quoteOn && brackets > 0)
            {
             brackets--;
            }
           break;
          }
         case '\'':
          {
           if (!quoteOn)
            {
             if ((index > 0) &&
                 Asm.Attributes.indexOf(operands.charAt(index-1)) < 0)
              {
               quoteOn = true;
              }
            }
           else
            {
             if (index + 1 < len && operands.charAt(index + 1) == '\'')
              {
               index++;
              }
             else
              {
               quoteOn = false;
              }
            }
           break;
          }
        }
       index++;
      }
     return len - 1;
    }

   /**
    * Add multilevel support for an instruction operation.  This method is
    * called on the original (i.e., first) instruction that had this operation.
    *
    * @param addP new instruction format to add to the original
    */
   void        addMultiLevel(Instruction addP)
   {
      addP._next = _multiLevel;
      _multiLevel = addP;
   }
}


/**
 * HLASM machine instructions.
 */
final class Machine extends Instruction
{
   int  _numOperands;
   char _verFuncP[] = {'0', '0', '0', '0', '0'}; // up to 5 operands to verify

   /**
    * Create info about a machine instruction: operator, operands, a verify
    * pattern for the operands.
    *
    * @param  instrX  instruction-format line as read in
    *
    * Building the verify pattern:
    *      syntax         ix     verify function
    *      -------        ----   ------------------------
    *      "D(XB)"        ,"1",  // Machine::DispIndexBase,
    *      "D(B)"         ,"2",  // Machine::DispBase,
    *      "D(LB)"        ,"3",  // Machine::DispLenBase,
    * 5 in 5B is the func number for &Register specified below
    *      "D(5B)"        ,"4",  // Machine::DispRegBase,
    * following already translated via 'translate("RMI","567")'
    *      "R"            ,"5",  // Machine::Register,
    *      "M"            ,"6",  // Machine::Mask,
    *      "I"            ,"7",  // Machine::Immediate,
    *
    * Example:
    *   instrX                    AP D1(L1,B1),D2(L2,B2)
    *   verOperands := operands   D1(L1,B1),D2(L2,B2)
    *   "12345RMI" -> "?????567"  D?(L?,B?),D?(L?,B?)
    *   "?" / ""                  D(L,B),D(L,B)
    *   "," / ""                  D(LB)D(LB)
    *   "D(LB)" / "3"             "33"
    *   xxxNumOperands := 2
    */
   Machine(String instrX)
    {
     InstrInit(instrX, 'q', HLAsmParser.CLASS_MACHINEINS);

     for (int i = _firstOperandStart; i < _format.length() && _numOperands < 5; i++)
      {
       char c = _format.charAt(i);
       switch (c)
        {
         case 'D':
          {
           int j = i + 2;
           if (j < _format.length() && _format.charAt(j) == '(')
            {
             j++;
             if (j < _format.length())
              {
               c = _format.charAt(j);
               if (c == 'X' &&
                   j + 5 < _format.length() &&
                   _format.charAt(j + 3) == 'B' &&
                   _format.charAt(j + 5) == ')')
                {
                 i = j + 5;
                 _verFuncP[_numOperands] = '1';   // Dn(Xn,Bn)
                 _numOperands++;
                }
               else if (c == 'B' &&
                        j + 2 < _format.length() &&
                        _format.charAt(j + 2) == ')')
                {
                 i = j + 2;
                 _verFuncP[_numOperands] = '2';   // Dn(Bn)
                 _numOperands++;
                }
               else if (c == 'L' &&
                        j + 5 < _format.length() &&
                        _format.charAt(j + 3) == 'B' &&
                        _format.charAt(j + 5) == ')')
                {
                 i = j + 5;
                 _verFuncP[_numOperands] = '3';   // Dn(Ln,Bn)
                 _numOperands++;
                }
               else if (c == 'L' &&
                        j + 4 < _format.length() &&
                        _format.charAt(j + 2) == 'B' &&
                        _format.charAt(j + 4) == ')')
                {
                 i = j + 4;
                 _verFuncP[_numOperands] = '3';   // Dn(L,Bn)
                 _numOperands++;
                }
               else if (c == 'R' &&
                        j + 5 < _format.length() &&
                        _format.charAt(j + 3) == 'B' &&
                        _format.charAt(j + 5) == ')')
                {
                 i = j + 5;
                 _verFuncP[_numOperands] = '4';   // Dn(Rn,Bn)
                 _numOperands++;
                }
              }
            }
           break;
          }
         case 'R':
          {
           _verFuncP[_numOperands] = '5';
           _numOperands++;
           break;
          }
         case 'M':
          {
           _verFuncP[_numOperands] = '6';
           _numOperands++;
           break;
          }
         case 'I':
          {
           _verFuncP[_numOperands] = '7';
           _numOperands++;
           break;
          }
         default:
          {
           break;
          }
        }
      }
    }

   /**
    * Validate the operands of a Machine instruction.
    */
   int         ValidateOperands(String  operands)
    {
     int rc = 0;
     int start = 0;
     int operand;

     for (operand = 0;
          operand < _numOperands && rc == 0 && start < operands.length();
          operand++)
      {
       int end = operandEnd(operands, start);
       switch (_verFuncP[operand])
        {
         case '1':
          {
           rc = DispIndexBase(operands, start, end);
           break;
          }
         case '2':
          {
           rc = DispBase(operands, start, end);
           break;
          }
         case '3':
          {
           rc = DispLenBase(operands, start, end);
           break;
          }
         case '4':
          {
           rc = DispRegBase(operands, start, end);
           break;
          }
         case '5':
          {
           rc = Register(operands, start, end);
           break;
          }
         case '6':
          {
           rc = Mask(operands, start, end);
           break;
          }
         case '7':
          {
           rc = Immediate(operands, start, end);
           break;
          }
        }
       start = end + 2;
      }

     if (rc != 0)
      {
       return rc;                                   // bad operand
      }
     if (operand != _numOperands || start < operands.length())
      {
       return -10;                                  // too many / few operands
      }
     return 0;                                      // all okay
    }

   /**
    * Check validity of the register.
    */
   int         Register(String operands, int start, int end)
    {
     String registers = Asm.Registers;
     int len = registers.length();
     char startChar = Character.toUpperCase(operands.charAt(start));
     for (int i = 0; i < len; i++)
      {
       char c = registers.charAt(i);
       if (c == ' ' && i + 1 < len)
        {
         i++;
         c = registers.charAt(i);
         if (c == startChar)
          {
           boolean match = true;
           i++;
           for (int j = start + 1; match && j <= end && i < len; i++, j++)
            {
             c = registers.charAt(i);
             if (c != Character.toUpperCase(operands.charAt(j)))
              {
               match = false;
              }
            }
           if (match && registers.charAt(i) == ' ')
            {
             return 0;
            }
          }
         i--;
        }
      }
     if (operands.charAt(start) == '&')
      {
       return 0;
      }
     return -15;
    }

   int         DispIndexBase(String operands, int start, int end)
    {
     int vvarStart = start;
     int vvarEnd = end;
     int regXStart = start;
     int regXEnd = start - 1;
     int regBStart = start;
     int regBEnd = start - 1;

     if (end > start && operands.charAt(start) != '=' && operands.charAt(end) == ')')
      {
       int x = operands.lastIndexOf('(', end);
       if (x >= start &&
           "+-*/".indexOf(operands.charAt(x-1)) == -1)
        {
         vvarEnd = x - 1;
         regXStart = x + 1;
         int comma = operands.indexOf(',', x);
         if (comma >= x && comma < end)
          {
           regXEnd = comma - 1;
           regBStart = comma + 1;
           regBEnd = end - 1;
           while (operands.charAt(regBEnd) == ')')
            {
             regBEnd--;
            }
          }
         else
          {
           regXEnd = end - 1;
           while (operands.charAt(regXEnd) == ')')
            {
             regXEnd--;
            }
          }
        }
      }

     try
      {
       if (vvarStart <= vvarEnd &&
           Integer.valueOf(operands.substring(vvarStart, vvarEnd + 1)).intValue() > 4095)
        {
         return -1;
        }
      }
     catch (NumberFormatException e) {}

     if ((regXStart <= regXEnd && Register(operands, regXStart, regXEnd) != 0) ||
         (regBStart <= regBEnd && Register(operands, regBStart, regBEnd) != 0))
      {
       return -1;
      }
     return 0;
    }

   int         DispBase(String operands, int start, int end)
    {
     int vvarStart = start;
     int vvarEnd = end;
     int regBStart = start;
     int regBEnd = start - 1;

     if (end > start && operands.charAt(start) != '=' && operands.charAt(end) == ')')
      {
       int x = operands.lastIndexOf('(', end);
       if (x >= start &&
           "+-*/".indexOf(operands.charAt(x-1)) == -1)
        {
         vvarEnd = x - 1;
         regBStart = x + 1;
         regBEnd = end - 1;
         while (operands.charAt(regBEnd) == ')')
          {
           regBEnd--;
          }
        }
      }

     try
      {
       if (vvarStart <= vvarEnd &&
           Integer.valueOf(operands.substring(vvarStart, vvarEnd + 1)).intValue() > 4095)
        {
         return -1;
        }
      }
     catch (NumberFormatException e) {}

     if (regBStart <= regBEnd && Register(operands, regBStart, regBEnd) != 0)
      {
       return -1;
      }
     return 0;
    }

   int         DispLenBase(String operands, int start, int end)
    {
     int vvarStart = start;
     int vvarEnd = end;
     int lenStart = start;
     int lenEnd = start - 1;
     int regBStart = start;
     int regBEnd = start - 1;

     if (end > start && operands.charAt(start) != '=' && operands.charAt(end) == ')')
      {
       int x = operands.lastIndexOf('(', end);
       if (x >= start &&
           "+-*/".indexOf(operands.charAt(x-1)) == -1)
        {
         vvarEnd = x - 1;
         lenStart = x + 1;
         int comma = operands.indexOf(',', x);
         if (comma >= x && comma < end)
          {
           lenEnd = comma - 1;
           regBStart = comma + 1;
           regBEnd = end - 1;
           while (operands.charAt(regBEnd) == ')')
            {
             regBEnd--;
            }
          }
         else
          {
           lenEnd = end - 1;
           while (operands.charAt(lenEnd) == ')')
            {
             lenEnd--;
            }
          }
        }
      }

     try
      {
       if (vvarStart <= vvarEnd &&
           Integer.valueOf(operands.substring(vvarStart, vvarEnd+1)).intValue() > 4095)
        {
         return -1;
        }
      }
     catch (NumberFormatException e) {}

     if (lenStart <= lenEnd)
      {
       int maxLen = 256;
       int dispLenBaseCount = 0;
       for (int i = 0; i < _numOperands; i++)
        {
         if (_verFuncP[i] == '3')
          {
           dispLenBaseCount++;
          }
        }
       if (dispLenBaseCount == 2)
        {
         maxLen = 15;
        }
       try
        {
         if (Integer.valueOf(operands.substring(lenStart, lenEnd+1)).intValue() > maxLen)
          {
           return -1;
          }
        }
       catch (NumberFormatException e) {}
      }

     if (regBStart <= regBEnd && Register(operands, regBStart, regBEnd) != 0)
      {
       return -1;
      }
     return 0;
    }

   int         DispRegBase(String operands, int start, int end)
    {
     return DispIndexBase(operands, start, end);
    }

   int         Mask(String operands, int start, int end)
    {
     try
      {
       if (Integer.valueOf(operands.substring(start, end + 1)).intValue() > 15)
        {
         return -1;
        }
      }
     catch (NumberFormatException e) {}

     if (end - start >= 1 &&
         operands.charAt(start) == 'B' &&
         operands.charAt(start + 1) == '\'')
      {
       int endQuote = operands.indexOf('\'', start + 2);
       if (endQuote > end || (endQuote - start - 2) > 4)
        {
         return -1;
        }
       for (int i = start + 2; i < endQuote; i++)
        {
         if ((operands.charAt(i) != '0') && (operands.charAt(i) != '1'))
          {
           return -1;
          }
        }
      }
     return 0;
    }

   int         Immediate(String operands, int start, int end)
    {
     try
      {
       if (Integer.valueOf(operands.substring(start, end + 1)).intValue() > 255)
        {
         return -1;
        }
      }
     catch (NumberFormatException e) {}
     return 0;
    }
}


final class Assembler extends Instruction
{
   int  requireds, totals;
   char opAttr[] = new char[1024];

   /**
    * Build an assembler instruction from the instruction format read in.
    */
   Assembler(String instrX)
    {
     InstrInit(instrX, 'a', HLAsmParser.CLASS_ASSEMINS);
     requireds = 0; // number of *required* operands for this instruction
     totals    = 0; // index to operand being handled (1 .. n)

     for (int i = _firstOperandStart;
          i < _format.length();
          i = formatOperandStart(i + 1))
      {
       totals++;
       opAttr[totals] = '\0';
       if (_format.charAt(i) == '[')
        {
         if (i + 3 < _format.length() &&
             _format.charAt(i + 1) == '.' &&
             _format.charAt(i + 2) == '.' &&
             _format.charAt(i + 3) == '.')
          {
           opAttr[totals] |= opRepeats;
          }
        }
       else
        {
         requireds++;
         opAttr[totals] |= opRequired;
        }
       i = formatOperandEnd(i);
      }
    }

   /**
    * Validate the operands of an assembler instruction.
    * Returns   0 = all good
    *        -105 =
    *        -110 =
    *        -120 =
    *        -202 =
    * NOTES:
    *  - allow for multi-level (like TPFmacros's ValidateOperands()),
    *    in order to be able to code more refined/correct definitions of the
    *    assembler instructions (e.g., the POP and PUSH).
    *    Moreover, we go beyond first (multilevel) format that matches, so we
    *    can code several formats with the same first operand...    @as 10/99
    */
   int         ValidateOperands(String operands)
    {
     int operandStart = 0;
     int operandEnd = operandEnd(operands, operandStart);

     // instruction has multiple levels: find correct Instruction object to call
     if (_multiLevel != null) {

        /*-------------------------------*/
        /*  1.- first try *this* format  */
        /*-------------------------------*/
        if (ValidateOperandsBeef(operands, operandStart, operandEnd) == 0)
           return 0;

        /*-------------------------------------------*/
        /*  2.- try the *multilevel-linked* formats  */
        /*-------------------------------------------*/
        Instruction inst;
        for (inst = _multiLevel; inst != null; inst = inst._next) {
           if (((Assembler)inst).ValidateOperandsBeef(operands,
                                 operandStart, operandEnd) == 0)
              return 0;
           }

        return -202;
        }

     return ValidateOperandsBeef(operands, operandStart, operandEnd);
    }

   /**
    * Does the real work for ValidateOperands().
    */
   private int ValidateOperandsBeef(String operands,
                                    int operandStart, int operandEnd)
    {
     for (int i = 1; i <= totals; i++)
      {
       opAttr[i] &= ~opInUse;
      }

     //System.out.println(" ** "+_format);

     int reqCnt = 0, totCnt = 0;
     while (operandStart < operands.length() && operandEnd >= operandStart)
      {
       if (++totCnt > totals)
        {
         return -105;
        }
       int opN = ValidateData(operands, operandStart, operandEnd);
       if (opN == 0)
        {
         return -110;
        }
       if ((opAttr[opN] & opRepeats) != 0)
        {
         return 0;
        }
       opAttr[opN] |= opInUse;
       if ((opAttr[opN] & opRequired) != 0)
        {
         reqCnt++;
        }
       operandStart = operandEnd + 2;
       operandEnd   = operandEnd(operands, operandStart);
      }

     if (reqCnt < requireds)
      {
       return -120;
      }

     return 0;
    }

   /**
    * Validate the data in an assembler instruction operand.
    */
   int         ValidateData(String operands, int start, int end)
    {
     int formatOperandStart = _firstOperandStart;
     int formatOperandEnd = formatOperandEnd(formatOperandStart);
     for (int i = 1; i <= totals; i++)
      {
       if ((opAttr[i] & opInUse) != 0)
        {
         formatOperandStart = formatOperandStart(formatOperandEnd + 1);
         formatOperandEnd = formatOperandEnd(formatOperandStart);
         continue;
        }
       int subWordStart = formatOperandStart;
       while (subWordStart <= formatOperandEnd)
        {
         char formatChar = _format.charAt(subWordStart);
         while (formatChar == '[' || formatChar == '|' || formatChar == ']')
          {
           subWordStart++;
           if (subWordStart <= formatOperandEnd)
            {
             formatChar = _format.charAt(subWordStart);
            }
           else
            {
             break;
            }
          }
         if (subWordStart > formatOperandEnd)
          {
           break;
          }
         int subWordEnd = subWordStart + 1;
         while (subWordEnd <= formatOperandEnd)
          {
           formatChar = _format.charAt(subWordEnd);
           if (formatChar == '[' || formatChar == '|' || formatChar == ']')
            {
             break;
            }
           subWordEnd++;
          }
         subWordEnd--;
         if (Asm.stringsEqual(_format, subWordStart, subWordEnd, "...") ||
             Character.isLowerCase(_format.charAt(subWordStart)) ||
             Asm.stringsEqualIgnoreCase(_format, subWordStart, subWordEnd,
                                        operands, start, end))
          {
           return i;
          }
         subWordStart = subWordEnd + 1;
        }
       formatOperandStart = formatOperandStart(formatOperandEnd + 1);
       formatOperandEnd = formatOperandEnd(formatOperandStart);
      }
     return 0;
    }
}


/**
 * A TPFmacros object hold all the information for one particular TPF macro
 * instruction:  name, operands, syntax-verification information.
 */
final class TPFmacros extends Instruction
{
   int  requireds,           // number of required operands for this instruction
        positionals,
        totals;
   char opAttr[] = new char[1024];

   // Constructor.
   TPFmacros(String instrX)
    {
     InstrInit(instrX,                      // TPF macro definition
               's',                         // LPEX style character
               HLAsmParser.CLASS_TPFMACRO); // LPEX class

     requireds = positionals = totals = 0;

     for (int i = _firstOperandStart;
          i < _format.length();
          i = formatOperandStart(i + 1))
      {
       totals++;
       opAttr[totals] = '\0';
       if (_format.charAt(i) == '[')
        {
         if (i + 3 < _format.length() &&
             _format.charAt(i + 1) == '.' &&
             _format.charAt(i + 2) == '.' &&
             _format.charAt(i + 3) == '.')
          {
           opAttr[totals] |= opRepeats;
          }
        }
       else
        {
         requireds++;
         opAttr[totals] |= opRequired;
        }
       int formatOperandEnd = formatOperandEnd(i);
       int subWordStart = i;
       while (subWordStart <= formatOperandEnd)
        {
         char formatChar = _format.charAt(subWordStart);
         while (formatChar == '[' || formatChar == '|' || formatChar == ']')
          {
           subWordStart++;
           if (subWordStart <= formatOperandEnd)
            {
             formatChar = _format.charAt(subWordStart);
            }
           else
            {
             break;
            }
          }
         if (subWordStart > formatOperandEnd)
          {
           break;
          }
         int subWordEnd = subWordStart + 1;
         while (subWordEnd <= formatOperandEnd)
          {
           formatChar = _format.charAt(subWordEnd);
           if (formatChar == '[' || formatChar == '|' || formatChar == ']')
            {
             break;
            }
           subWordEnd++;
          }
         subWordEnd--;
         boolean hasEquals = false;
         for (int j = subWordStart; j <= subWordEnd; j++)
          {
           if (_format.charAt(j) == '=')
            {
             hasEquals = true;
             break;
            }
          }
         if (hasEquals)
          {
           opAttr[totals] |= opKeyword;
          }
         else
          {
           opAttr[totals] |= opPositional;
          }
         subWordStart = subWordEnd + 1;
        }
       if ((opAttr[totals] & opPositional) != 0)
        {
         positionals++;
        }
       i = formatOperandEnd;
      }
    }

   /**
    * Validate the operands of a TPF macro.
    */
   int         ValidateOperands(String operands)
    {
     int reqCnt = 0, totCnt = 0, posCnt = 0;
     boolean repeats = false;
     int opN;

     for (int i = 1; i <= totals; i++)
      {
       opAttr[i] &= ~opInUse;
      }

     int operandStart = 0;
     int operandEnd = operandEnd(operands, operandStart);

     // not inside multilevel call, and instruction has multiple levels:
     // check other levels first
     if (_multiLevel != null)
      {
       for (Instruction inst = _multiLevel; inst != null; inst = inst._next)
        {
         if (inst.ValidateOperands(operands) == 0)
          {
           return 0;
          }
        }
      }

     while (operandStart < operands.length())
      {
       if ((++totCnt > totals) && !repeats)
        {
         return -205;
        }

       boolean hasEquals = false;
       for (int j = operandStart; j <= operandEnd; j++)
        {
         if (operands.charAt(j) == '=')
          {
           hasEquals = true;
           break;
          }
        }

       // 1.- handle positional operands
       if (operandStart > operandEnd ||
           operands.charAt(operandStart) == '\'' ||
           ((operandEnd > operandStart) && (operands.charAt(operandStart+1) == '\'')) ||
           operands.charAt(operandStart) == '='  ||
           !hasEquals)
        {
         if (repeats)
          {
           operandStart = operandEnd + 2;
           operandEnd = operandEnd(operands, operandStart);
           continue;
          }

         if (++posCnt > positionals)
          {
           return -210;
          }

         opN = ValidatePositional(operands, operandStart, operandEnd, posCnt);

         if (opN == 0)
          {
           return -221;
          }

         if ((opAttr[opN] & opRepeats) != 0)
          {
           repeats = true;
           operandStart = operandEnd + 2;
           operandEnd = operandEnd(operands, operandStart);
           continue;
          }
        }

       // 2.- handle non-positional operands
       else
        {
         opN = ValidateKeyword(operands, operandStart, operandEnd, totCnt);
         if (opN == 0)
          {
           return -222;
          }
        }

       if ((opAttr[opN] & opInUse) != 0)
        {
         return -225;
        }

       opAttr[opN] |= opInUse;
       if ((opAttr[opN] & opRequired) != 0)
        {
         reqCnt++;
        }

       operandStart = operandEnd + 2;
       operandEnd = operandEnd(operands, operandStart);
      }//end "while"

     if (reqCnt < requireds)
      {
       return -230;
      }

     return 0;
    }

   /**
    * Used to check non positional parameters (can replace places,
    * but can't be duplicated)
    */
   int         ValidateKeyword(String operands, int start, int end, int totCnt)
    {
     int startOptPosition = 1024;                    // max number of arguments
     int eqIndex = -1;
     for (int j = start; j <= end; j++)
      {
       if (operands.charAt(j) == '=')
        {
         eqIndex = j;
         break;
        }
      }
     if (eqIndex > 0)
      {
       end = eqIndex - 1;
      }
     char startChar = Character.toUpperCase(operands.charAt(start));

     int formatOperandStart = _firstOperandStart;
     int formatOperandEnd = formatOperandEnd(formatOperandStart);
     for (int i = 1; i <= totals; i++)
      {
       if ((opAttr[i] & opPositional) == 0)
        {
         if (_format.charAt(formatOperandStart) == '[' &&
             _format.charAt(formatOperandEnd) == ']')
          {
           startOptPosition = i;
          }

         if (eqIndex == -1 && totCnt >= startOptPosition)
          {
           return i;
          }
         if (eqIndex == -1)
          {
           formatOperandStart = formatOperandStart(formatOperandEnd + 1);
           formatOperandEnd = formatOperandEnd(formatOperandStart);
           continue;
          }
         for (int j = formatOperandStart; j <= formatOperandEnd; j++)
          {
           char c = Character.toUpperCase(_format.charAt(j));
           if (c == startChar)
            {
             boolean match = true;
             int k;
             for (j=j+1, k=start+1;  j <= formatOperandEnd && k <= end;  j++, k++)
              {
               c = Character.toUpperCase(_format.charAt(j));
               if (c != Character.toUpperCase(operands.charAt(k)))
                {
                 match = false;
                 break;
                }
              }
             if (j <= formatOperandEnd)
              {
               c = _format.charAt(j);
               if (c != '[' && c != ']' && c != '|' && c != ' ' && c != '=')
                {
                 match = false;
                }
              }
             if (k <= end)
              {
               match = false;
              }
             if (match)
              {
               return i;
              }
            }
           while (j <= formatOperandEnd)
            {
             c = _format.charAt(j);
             if (c == '[' || c == ']' || c== '|' || c == ' ' || c == '=')
              {
               break;
              }
             j++;
            }
          }
        }
       formatOperandStart = formatOperandStart(formatOperandEnd + 1);
       formatOperandEnd = formatOperandEnd(formatOperandStart);
      }

     return 0;
    }

   /**
    * Check positional parameters (can't replace places and can't be replaced).
    */
   int         ValidatePositional(String operands, int start, int end,
                                  int posCnt)
    {
     int formatOperandStart = _firstOperandStart;
     int formatOperandEnd = formatOperandEnd(formatOperandStart);
     int i;
     for (i = 1;
          i <= totals && (((opAttr[i] & opPositional) == 0) || ((opAttr[i] & opInUse) != 0));
          i++)
      {
       formatOperandStart = formatOperandStart(formatOperandEnd + 1);
       formatOperandEnd = formatOperandEnd(formatOperandStart);
      }

     if (i <= totals)
      {
       if (end < start &&
           _format.charAt(formatOperandStart) == '[' &&
           _format.charAt(formatOperandEnd) == ']')
        {
         return i; // [] operand allows ,, empty space
        }

       int subWordStart = formatOperandStart;
       while (subWordStart <= formatOperandEnd)
        {
         char formatChar = _format.charAt(subWordStart);
         while (formatChar == '[' || formatChar == '|' || formatChar == ']')
          {
           subWordStart++;
           if (subWordStart <= formatOperandEnd)
            {
             formatChar = _format.charAt(subWordStart);
            }
           else
            {
             break;
            }
          }
         if (subWordStart > formatOperandEnd)
          {
           break;
          }
         int subWordEnd = subWordStart + 1;
         while (subWordEnd <= formatOperandEnd)
          {
           formatChar = _format.charAt(subWordEnd);
           if (formatChar == '[' || formatChar == '|' || formatChar == ']')
            {
             break;
            }
           subWordEnd++;
          }
         subWordEnd--;
         if (subWordEnd < subWordStart)
          {
           break;
          }

         boolean hasEquals = false;
         for (int j = subWordStart; j <= subWordEnd; j++)
          {
           if (_format.charAt(j) == '=')
            {
             hasEquals = true;
             break;
            }
          }

         if (hasEquals)
          {
          }
         else if ((subWordEnd - subWordStart == 2 &&
                   _format.charAt(subWordStart) == '.' &&
                   _format.charAt(subWordStart + 1) == '.' &&
                   _format.charAt(subWordStart + 2) == '.') ||
                  Character.isLowerCase(_format.charAt(subWordStart)) ||
                  Asm.stringsEqualIgnoreCase(_format, subWordStart, subWordEnd,
                                             operands, start, end))
          {
           return i;
          }
         subWordStart = subWordEnd + 1;
        }
      }

     return 0;
    }
}


final class StringNode
{
   String     _string;
   StringNode _next;

   StringNode(String string)
   {
      _string = string;
   }
}