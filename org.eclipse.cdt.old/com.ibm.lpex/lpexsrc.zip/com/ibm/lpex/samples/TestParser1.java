//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
//
// DESCRIPTION:
// TestParser1 - LpexCommonParser sample parser: STEP 1 - minimum code.
//----------------------------------------------------------------------------

package com.ibm.lpex.samples;

import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexView;


/**
 * Sample LpexCommonParser parser: <b>STEP 1 - minimum code.</b>
 *
 * <p>This is a sample skeleton for a parser extending LpexCommonParser.
 * It shows the minimum code needed to implement such a parser.
 * TestParser2 will build on this foundation to carry out a simple parsing of
 * comments in text files.
 *
 * <p>When a new file is opened as a document, the editor looks for the
 * parser associated with that file's name extension.  Parsers may
 * be set up via the <b>updateProfile.parserClass</b>,
 * <b>updateProfile.parserAssociation</b>, and <b>updateProfile.parser</b>
 * editor parameters.
 *
 * <p>For example, opening sample.cpp may point the editor to the parser class
 * "CppParserWIN.class".  Once found, the editor will load this class -
 * CppParserWIN's constructor will instantiate one object for the newly-created
 * document view -, and then call one of its public methods to carry out a
 * <b>total parse</b> on the document sample.cpp.
 * Afterwards, each time the user modifies (edits) sample.cpp, a method in
 * CppParserWIN will be called to do an <b>incremental parse</b> on the changes
 * in the document.
 *
 * <p>Whatever the parser chooses to do is at its discretion.  Usually, a parser
 * will scan the file to understand its structure, and colorize the various
 * tokens as an aid to the programmer editing that type of files:  say, keywords
 * in blue, numbers in red, and comments in green.
 * While the user is editing the file, the parser will 'play catch-up'
 * and maintain its information of the file structure (and the displayed token
 * colours) up-to-date.
 *
 * <p>At a minimum, a parser written by extending class LpexCommonParser
 * should have a constructor, and implement two methods (defined as
 * <code>abstract</code> in LpexCommonParser):  parseAll() and parseElement().
 * LpexCommonParser handles the rest.
 *
 * <pre>
 * public class TestParser1 extends LpexCommonParser
 * {
 *    public TestParser1(LpexView lpexView) {super(lpexView);}
 *    public void parseAll() {}
 *    public void parseElement(int element) {}
 * }</pre>
 *
 * See the rest of the documentation below.  It shows and explains the code of
 * this example.
 *
 * <p>TestParser2 will do some real parsing, building on this framework.
 *
 * @see com.ibm.lpex.core.LpexCommonParser
 * @see com.ibm.lpex.samples.TestParser2
 */
public class TestParser1 extends LpexCommonParser
{
   /**
    * The parser's constructor.
    * First thing to do in here is to call the superclass constructor, i.e.,
    * LpexCommonParser's.  Next, whatever else may be needed by the parser
    * should be initialized (more on this in the next example, when the parser
    * will actually parse).
    *
    * <pre>
    * public TestParser1(LpexView lpexView)
    * {
    *    super(lpexView);
    * }</pre>
    *
    * One instance of the parser controls one LpexView of a document.
    * When several edit views are created for the same document, several parser
    * objects will be instantiated, one for each view, and each will be called
    * to parse the document.
    *
    * @param lpexView the LpexView object associated with <b>this</b>
    *                  parser object.
    */
   public TestParser1(LpexView lpexView)
   {
      super(lpexView);
   }

   /**
    * Total parse.  The parser is called here to parse the entire document,
    * immediately after it has been loaded in the editor.
    *
    * <p>Nothing is being done here right now:
    *
    * <pre>
    * public void parseAll()
    * {
    * }</pre>
    */
   public void parseAll()
   {
   }

   /**
    * Incremental parse.  This call-back method is invoked by the editor to
    * incrementally parse changes to the document:  some new text was typed
    * in, a line was deleted, a block operation (copy / move / delete) was
    * performed, etc.
    *
    * <p>Nothing is done here right now, therefore there is no visible effect
    * on the editing:
    *
    * <pre>
    * public void parseElement(int element)
    * {
    * }</pre>
    *
    * @param element the element whose committed change triggered the parse,
    *                or the element that precedes / follows a deleted block.
    *                The parser may identify other neighbouring elements that
    *                will have to be reparsed as a unit.
    */
   public void parseElement(int element)
   {
   }
}