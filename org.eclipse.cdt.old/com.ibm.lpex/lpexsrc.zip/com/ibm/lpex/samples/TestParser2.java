//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
//
// DESCRIPTION:
// TestParser - LpexCommonParser sample parser: STEP 2 - tokenize.
//----------------------------------------------------------------------------

package com.ibm.lpex.samples;

import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexView;


/**
 * Sample LpexCommonParser parser: <b>STEP 2 - tokenize.</b>
 *
 * <p>This takes the sample a little further, setting a few element classes
 * and styles.  Our parser will be activated by the loading in the editor of
 * file types that it is associated with, and display them in two colours:
 * regular text (blue), and comments (green).
 *
 * <p>A parser communicates with its associated document view in the editor
 * through public methods in class LpexView.  This is the main class of the
 * editor API (Application Programming Interface) for parsers and user-defined
 * commands, actions, and user profiles.  LpexView allows a parser class to
 * access the text of the document loaded in the editor, set display styles for
 * the elements, assign element classes to the elements, and query them as
 * reference points during incremental parsing.
 *
 * <p>Element <b>classes</b> are used to roughly classify document structures,
 * or identify other points of interest inside the parsed document.
 * An element can be assigned any combination of element classes.
 * Here, we'll define two such classes:  one for elements that contain text,
 * and one for elements which (also) contain C++-style comments (those
 * starting with a double-slash "//").
 *
 * <p>Element classes are defined and registered by name.  LPEX allocates
 * view-scoped bits for the classes enabled, which bit-masks may be used to
 * query and set classes in the elements via the API.
 *
 * <p>An element's <b>styles</b> string 'parallels' its text string:  each
 * character in the styles string determines how the corresponding character
 * in the text will display (foreground and background colour, regular or
 * underlined, etc.).
 *
 * <pre>
 * // two element classes
 * static final String
 *    CLASS_TEXT    = "text",
 *    CLASS_COMMENT = "comment";
 *
 * // the two element classes as bit-masks, and a mask for all our classes
 * private long
 *    classText,
 *    classComment,
 *    classAll;</pre>
 *
 * @see com.ibm.lpex.core.LpexView
 */
public class TestParser2 extends LpexCommonParser
{
   // two element classes
   static final String
      CLASS_TEXT    = "text",
      CLASS_COMMENT = "comment";

   // the two element classes as bit-masks, and a mask for all our classes
   private long
      classText,
      classComment,
      classAll;

   /**
    * Constructor for the parser.
    * In adition to calling superclass LpexCommonParser's constructor,
    * we must also initialize what's needed for parsing and tokenizing the
    * document:  we define two style display attributes 't' and 'c', for text
    * and comments, enable the element classes, and query their allocated bit-masks.
    *
    * <pre>
    * public TestParser2(LpexView lpexView)
    * {
    *    super(lpexView);
    *
    *    String toBackground = LpexPaletteAttributes.background(view);
    *    // text style = blue/white
    *    String attributes = LpexPaletteAttributes.convert("0 0 255 255 255 255",
    *                                                      BACKGROUND_COLOR,
    *                                                      toBackground);
    *    view.doDefaultCommand("set styleAttributes.t " + attributes);
    *    // comment style = green/white
    *    attributes = LpexPaletteAttributes.convert("0 128 128 255 255 255",
    *                                               BACKGROUND_COLOR,
    *                                               toBackground);
    *    view.doDefaultCommand("set styleAttributes.c " + attributes);
    *
    *    // enable the "text" and "comment" element classes and
    *    // get the bits allocated for them
    *    classText    = view.registerClass(CLASS_TEXT);
    *    classComment = view.registerClass(CLASS_COMMENT);
    *
    *    // keep a bit-mask of all our element classes
    *    classAll = classText | classComment;
    * }</pre>
    *
    * Remember that LpexCommonParser's variable <code>view</code>, pointing to
    * the LpexView associated with this parser object, and used here throughout
    * to access the Java LPEX API, is set by LpexCommonParser in its constructor
    * (the first thing called in our own constructor above).
    *
    * @param lpexView the LpexView object associated with this parser object.
    * @see com.ibm.lpex.core.LpexCommonParser#view
    * @see com.ibm.lpex.core.LpexView#doDefaultCommand
    * @see com.ibm.lpex.core.LpexView#classMask
    */
   public TestParser2(LpexView lpexView)
   {
      super(lpexView);

      String toBackground = LpexPaletteAttributes.background(view);
      // text style = blue/white
      String attributes = LpexPaletteAttributes.convert("0 0 255 255 255 255",
                                                        BACKGROUND_COLOR,
                                                        toBackground);
      view.doDefaultCommand("set styleAttributes.t " + attributes);
      // comment style = green/white
      attributes = LpexPaletteAttributes.convert("0 128 128 255 255 255",
                                                 BACKGROUND_COLOR,
                                                 toBackground);
      view.doDefaultCommand("set styleAttributes.c " + attributes);

      // enable the "text" and "comment" element classes
      // and get the bits allocated for them
      classText    = view.registerClass(CLASS_TEXT);
      classComment = view.registerClass(CLASS_COMMENT);

      // keep a bit-mask of all our element classes
      classAll = classText | classComment;
   }

   /**
    * Parse the entire document.
    *
    * <pre>
    * public void parseAll()
    * {
    *    for (int element = 1; element <= view.elements(); element++)
    *       parseOneElement(element);
    * }</pre>
    *
    * During the development of a parser, one can easily verify the operation
    * of the parser by querying, from the command line of Test, the <b>style</b>
    * and <b>elementClasses</b> being set in the document for each element.
    */
   public void parseAll()
   {
      for (int element = 1; element <= view.elements(); element++)
         parseOneElement(element);
   }

   /**
    * Parse a change in the document.
    *
    * <pre>
    * public void parseElement(int element)
    * {
    *    parseOneElement(element);
    * }</pre>
    *
    * @param element the element whose committed change triggered the parse,
    *                or the element that precedes / follows a deleted block.
    */
   public void parseElement(int element)
   {
      parseOneElement(element);
   }

   /**
    * Parse one element in the document.  Our own method
    * (which could very well be declared <code>private</code>),
    * called by parseAll() and parseElement().
    *
    * <p>We query the text of the element, analyze it, and set display styles
    * for the text and comment portions.  We also set the element classes of the
    * element according to its contents.  LpexCommonParser's utility method
    * <code>styleString</code> is used to create the style strings for the
    * element.
    *
    * <pre>
    * public void parseOneElement(int element)
    * {
    *    // query element's text and current classes (as possibly set by others)
    *    String text    = view.elementText(element);
    *    long   classes = view.elementClasses(element) & ~classAll;
    *
    *    // establish the new styles, and which of our element classes to set
    *    String styles = "";
    *    int i = text.indexOf("//");
    *    if (i < 0) {                                     // 1.- no comment found
    *       if (text.length() > 0) {                      //   any regular text?
    *          styles = styleString('t', text.length());
    *          classes |= classText;
    *          }
    *       }
    *    else {                                           // 2.- there is a comment
    *       styles = styleString('t', i) + styleString('c', text.length() - i);
    *       classes |= classComment;
    *       if (i > 0)                                    //   any regular text?
    *          classes |= classText;
    *       }
    *
    *    // set the element's display styles, and our element classes
    *    view.setElementStyle(element, styles);
    *    view.setElementClasses(element, classes);
    * }</pre>
    *
    * @param element one document element to parse
    * @see com.ibm.lpex.core.LpexCommonParser#styleString
    * @see com.ibm.lpex.core.LpexView#elementText
    * @see com.ibm.lpex.core.LpexView#elementClasses
    * @see com.ibm.lpex.core.LpexView#setElementStyle
    * @see com.ibm.lpex.core.LpexView#setElementClasses
    */
   public void parseOneElement(int element)
   {
      // query element's text and current classes (as possibly set by others)
      String text    = view.elementText(element);
      long   classes = view.elementClasses(element) & ~classAll;

      // establish the new styles, and which of our element classes to set
      String styles = "";
      int i = text.indexOf("//");
      if (i < 0) {                                     // 1.- no comment found
         if (text.length() > 0) {                      //   any regular text?
            styles = styleString('t', text.length());
            classes |= classText;
            }
         }
      else {                                           // 2.- there is a comment
         styles = styleString('t', i) + styleString('c', text.length() - i);
         classes |= classComment;
         if (i > 0)                                    //   any regular text?
            classes |= classText;
         }

      // set the element's display styles, and our element classes
      view.setElementStyle(element, styles);
      view.setElementClasses(element, classes);
   }
}