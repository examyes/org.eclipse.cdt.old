//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
//
// DESCRIPTION:
// TestUserProfile - sample user profile.
//----------------------------------------------------------------------------

package com.ibm.lpex.samples;

import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexDocumentLocation;
import com.ibm.lpex.core.LpexView;


/**
 * This class is a sample user profile.  It customizes the <b>lpex</b> base
 * editor profile by redefining several keys and settings.
 *
 * <p>The user profile is run during the processing of the <b>updateProfile</b>
 * command.  The <b>updateProfile</b> command is normally run when a document
 * view is created, and it may be issued at any time to allow the document view
 * to reflect changes to the profile.</p>
 *
 * <p>Here is the <a href="doc-files/TestUserProfile.java.html">TestUserProfile
 * code</a>.</p>
 *
 * <p>To run this sample:
 * <ul>
 *  <li>Compile the user-profile class:
 *    <pre>javac TestUserProfile.java</pre>
 *  <li>Set the user profile, by entering this on the editor command line:
 *    <pre>set updateProfile.userProfile com.ibm.lpex.samples.TestUserProfile</pre>
 *  <li>Run the <b>updateProfile</b> command from the editor command line,
 *    by entering:
 *    <pre>updateProfile</pre>
 * </ul></p>
 *
 * See the <b>updateProfile.userProfile</b> parameter.
 */
public class TestUserProfile
{
 public static void userProfile(LpexView lpexView)
 {
  // if the current profile is different from "lpex" (or none), don't touch it
  String baseProfile = lpexView.query("baseProfile");
  if (baseProfile != null && !baseProfile.equals("lpex"))
   {
    lpexView.doDefaultCommand("set messageText Base profile not 'lpex', settings not changed by TestUserProfile.");
    return;
   }

  // define a backSpace action restricted to the current line
  lpexView.defineAction("myBackSpace", new LpexAction()
  {
   public void doAction(LpexView view)
   {
    if (view.currentPosition() > 1)
     {
      view.doDefaultAction(view.actionId("backSpace"));
     }
   }
   public boolean available(LpexView view) { return true; }
  });

  // define a delete action restricted to the current line
  lpexView.defineAction("myDelete", new LpexAction()
  {
   public void doAction(LpexView view)
   {
    if (view.currentPosition() <= view.queryInt("length"))
     {
      view.doDefaultAction(view.actionId("delete"));
     }
   }
   public boolean available(LpexView view) { return true; }
  });

  // define an action to select the current line
  lpexView.defineAction("myBlockMarkElement", new LpexAction()
  {
   public void doAction(LpexView view)
   {
    view.doDefaultCommand("block clear");
    view.doDefaultCommand("block set element");
   }
   public boolean available(LpexView view) { return true; }
  });

  // define a deleteLine action that preserves the cursor column position
  lpexView.defineAction("myDeleteLine", new LpexAction()
  {
   public void doAction(LpexView view)
   {
    int displayPosition = view.queryInt("displayPosition");
    if (displayPosition > 0)
     {
      view.doDefaultAction(view.actionId("deleteLine"));
      view.doDefaultCommand("set displayPosition " + displayPosition);
     }
   }
   public boolean available(LpexView view) { return true; }
  });

  // define a join action that keeps one and only one space between texts
  lpexView.defineAction("myJoin", new LpexAction()
  {
   public void doAction(LpexView view)
   {
    LpexDocumentLocation joinLocation = view.documentLocation();
    if (joinLocation.element > 0)
     {
      // save cursor position, may be affected by deleteWhiteSpace / insertText
      int displayPosition = view.queryInt("displayPosition");
      joinLocation.position = view.queryInt("length") + 1;
      view.doDefaultAction(view.actionId("join"));
      view.doDefaultCommand(joinLocation, "action oneSpace");
      // restore original cursor position
      view.doDefaultCommand("set displayPosition " + displayPosition);
     }
   }
   public boolean available(LpexView view) { return true; }
  });

  // set default selection to character (not stream)
  lpexView.doDefaultCommand("set block.defaultType character");

  // set "Enter" key to go to the next line (not split)
  lpexView.doDefaultCommand("set keyAction.enter.t newLine");

  // set "Delete" and "Backspace" keys to keep it inside the current line
  lpexView.doDefaultCommand("set keyAction.backSpace.t myBackSpace");
  lpexView.doDefaultCommand("set keyAction.delete.t myDelete");

  // set "Alt+J" to join next line's text with just one space in-between
  lpexView.doDefaultCommand("set keyAction.a-j.t myJoin");

  // set mouse button 1 double-click to select the line (not word)
  lpexView.doDefaultCommand("set mouseAction.1-pressed.2 myBlockMarkElement");

  // indicate this profile has run
  lpexView.doDefaultCommand("set messageText My settings (TestUserProfile) in effect.");
 }
}