//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2000
// All Rights Reserved.
//
// DESCRIPTION:
// TestCommand - sample user-defined command.
//----------------------------------------------------------------------------

package com.ibm.lpex.samples;

import com.ibm.lpex.core.LpexCommand;
import com.ibm.lpex.core.LpexView;
import java.util.StringTokenizer;

/**
 * This class is a sample command implementation.  Running this command will
 * display a short message on the editor message line.
 *
 * <p>Here is the <A HREF="doc-files/TestCommand.java.html">TestCommand code</A>.
 *
 * <p>To run this sample:
 * <ul>
 * <li>Compile the command class:
 *   <pre>javac TestCommand.java</pre>
 * <li>Define the command, by entering this on the editor command line:
 *   <pre>set commandClass.testCommand com.ibm.lpex.samples.TestCommand</pre>
 * <li>Run the command from the editor command line, by entering:
 *   <pre>testCommand message</pre>
 * </ul>
 *
 * @see com.ibm.lpex.core.LpexCommand
 * @see com.ibm.lpex.core.LpexView
 */
public class TestCommand implements LpexCommand
{
   public boolean doCommand(LpexView lpexView, String parameters)
   {
      StringTokenizer st = new StringTokenizer(parameters);
      if (!st.hasMoreTokens()) {
         lpexView.doCommand("set messageText " +
          "Parameters are required for the \"testCommand\" command.");
         // return false to indicate that the command syntax was invalid
         return false;
         }

      String token = st.nextToken();
      if (st.hasMoreTokens()) {
         lpexView.doCommand("set messageText \"" + st.nextToken() +
          "\" is not a valid parameter for the \"testCommand\" command.");
         return false;
         }

      if (token.equals("message")) {
         lpexView.doCommand("set messageText Hello there from testCommand!");
         }
      else if (!token.equals("quiet")) {
         lpexView.doCommand("set messageText \"" + token +
          "\" is not a valid parameter for the \"testCommand\" command.");
         return false;
         }

      // return true to indicate the parameters were specified correctly
      return true;
   }
}