//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2000
// All Rights Reserved.
//
// DESCRIPTION:
// TestAction - sample user-defined action.
//----------------------------------------------------------------------------

package com.ibm.lpex.samples;

import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexView;

/**
 * This class is a sample action implementation.  Running this action will
 * display a short message on the editor message line.  The action is available
 * in any non-readonly view in which it is defined.
 *
 * <p>Here is the <A HREF="doc-files/TestAction.java.html">TestAction code</A>.
 *
 * <p>To run this sample:
 * <ul>
 * <li>Compile the action class:
 *   <pre>javac TestAction.java</pre>
 * <li>Define the action, by entering this on the editor command line:
 *   <pre>set actionClass.testAction com.ibm.lpex.samples.TestAction</pre>
 * <li>Run the action from the editor command line, by entering:
 *   <pre>action testAction</pre>
 * </ul>
 *
 * @see com.ibm.lpex.core.LpexAction
 * @see com.ibm.lpex.core.LpexView
 */
public class TestAction implements LpexAction
{
   public void doAction(LpexView lpexView)
   {
      lpexView.doCommand("set messageText Thank you for running TestAction...");
   }
   public boolean available(LpexView lpexView)
   {
      return lpexView.query("readonly").equals("off");
   }
}