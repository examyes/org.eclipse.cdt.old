//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SqlLexerStyles - styles for the SQL lexer.
//----------------------------------------------------------------------------

package com.ibm.lpex.sql;


/**
 * Styles for the SQL lexer.  The style characters used by the SQL lexer must be
 * defined by the host document parser.
 *
 * <p>The default style character set in the LpexCharStream by the host parser
 * (usually '_' for layout blanks) will also appear in elements tokenized by the
 * SQL lexer.
 */
public final class SqlLexerStyles
{
   char Comment,       // comment
        Error,         // error
        Keyword,       // keyword
        Function,      // built-in function
        Numeric,       // numeric constant
        CharString,    // character string constant
        Identifier,    // identifier
        Punctuator;    // punctuation

   /**
    * Construct a set of SQL lexer styles.
    * If the <code>styles</code> string is <code>null</code> or too short,
    * all the SQL lexer styles are set to '!'.
    *
    * @param styles string of 8 style characters, in the following order:
    *               comment,
    *               error,
    *               keyword,
    *               built-in function,
    *               numeric constant,
    *               character string constant,
    *               identifier,
    *               punctuation
    */
   public SqlLexerStyles (String styles)
   {
      if (styles == null || styles.length() < 8)
         styles = "!!!!!!!!";

      Comment    = styles.charAt(0);
      Error      = styles.charAt(1);
      Keyword    = styles.charAt(2);
      Function   = styles.charAt(3);
      Numeric    = styles.charAt(4);
      CharString = styles.charAt(5);
      Identifier = styles.charAt(6);
      Punctuator = styles.charAt(7);
   }
}