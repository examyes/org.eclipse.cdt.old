//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SqlLexerClasses - element classes for the SQL lexer.
//----------------------------------------------------------------------------

package com.ibm.lpex.sql;

import com.ibm.lpex.core.LpexView;


/**
 * Element classes for the SQL lexer.  The classes used by the SQL lexer must
 * be first defined and registered by the host document parser.
 * Using certain classes in both the host and the SQL parser allows
 * common features and tools to view the document as one integrated unit.
 * In incremental parsing, for example, the host parser will interpret the SQL
 * forward & backward link classes when evaluating the optimal parse range.
 * Also, the <b>Errors</b> filtered view will show the errors in the
 * entire document.
 */
public final class SqlLexerClasses
{
   long Code,           // any SQL code in the line
        ForwardLink,    // double-link elements belonging
        BackwardLink,   //   to one parse unit
        Comment,        // comment
        Error,          // SQL syntax error
        SqlStatement;   // SQL statement

   /**
    * Default set of SQL lexer classes.
    *
    * @param lpexView the LPEX document view associated with the lexer
    */
   public SqlLexerClasses(LpexView lpexView)
   {
      validateClasses(lpexView);
   }

   /**
    * Construct a set of SQL lexer classes.
    *
    * @param lpexView the LPEX document view associated with the lexer
    */
   public SqlLexerClasses(LpexView lpexView,
                          long code, long forwardLink, long backwardLink,
                          long comment, long error, long sqlStatement)
   {
      Code         = code;
      ForwardLink  = forwardLink;
      BackwardLink = backwardLink;
      Comment      = comment;
      Error        = error;
      SqlStatement = sqlStatement;
      validateClasses(lpexView);
   }

   /**
    * Ensure the classes set are OK.  Element links are used in incremental
    * parsing, must set them.
    */
   private void validateClasses(LpexView lpexView)
   {
      if (ForwardLink == 0)
         ForwardLink  = lpexView.registerClass("sqlForwardLink");
      if (BackwardLink == 0)
         BackwardLink = lpexView.registerClass("sqlBackwardLink");
   }
}