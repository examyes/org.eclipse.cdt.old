//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// PliKeywords - keywords for the PL/I document parser.
//----------------------------------------------------------------------------

package com.ibm.lpex.pli;


/**
 * Keywords for the PL/I document parser.
 */
final class PliKeywords
{
   static final String Keywords[] = {
/*
A line starting with '*' is a comment.
The layout is:
  - optional leading blanks
  - comma-separated list of keyword names;  case is irrelevant
  - at least one space
  - help token which appears in the appropriate help mapping properties file, or
    '~' to indicate help panel name is the [1st] keyword name [in list], or
    '*' if there is no help panel;
  - one of a list of tokens which tell the parser what kind of
    token this is.  These attributes are:
      ATU  - Attribute unqualified, i.e., you CANNOT put anything
             in parentheses after it.  E.g., ALIGNED
      ATQ  - Attribute qualified, i.e., you CAN put something
             in parentheses after it.  E.g., FIXED(3) or INIT(...)
      FLO  - A statement keyword which can influence flow of control.
             E.g., PROC, CALL, IF
      BIF  - A built-in function name
      TYF  - A type function name - has args enclosed in (: and :)
      CON  - A condition name
      SOP  - A statement option keyword
             E.g., INTO, SET
      OPT  - A word which may appear in a compiler option.
             E.g., OPTIMIZE, MAX
      OPS  - A word which may appear in an OPTIONS option.
             E.g., ASSEMBLER
      ENV  - A word which may appear in an ENVIRONMENT attribute.
             E.g., TOTAL
      T0   - A pseudo statement keyword.  Used to allow a statement
             keyword to be in the file for look-up purposes.
      T1   - A 'type 1' statement keyword - the type of statement
             which takes only options and parentheses.
             E.g., READ FILE(..) INTO(..) ;
      T2   - A 'type 2' statement keyword - the type of statement which
             takes an identifier or an expression as its first item.
             E.g., ALLOCATE x SET(..) ;
             Also used to encompass 'anything not a type 1'.
      PPS  - It's to do with preprocessing exclusively.  However, a lot
             of the preprocessor words appear in here as if they were
             ordinary statements.  This is because they can be used as if
             they were ordinary statements in the construction of a
             preprocessor procedure.
      *    - Tells the parser that this line is just a placeholder
             to allow specification of a resource id.

    Certain things are recognized by the code itself, and only appear in this
    file for completeness.

    NB This is stuff from the old PL/I parser;  the Java LPEX PL/I parser does
    much less in terms of validation, so it doesn't use much of this info...

  - Auto-indentation value.  The value is either a signed number, or
    an '*' to say that this token does not participate in auto indentation.

  - Auto-indentation default value.

  - A list of comma-separated LANGUAGE-level tokens for which this token
    is valid, or an '*' to say that this this line is just a placeholder
    to allow specification of a resource id.
    Valid values are:
      SAA
      SAA2
      OS

  - An optional comment, introduced by ';'.

Example:
  "sprog,nosprog sprog OPT * * SAA,SAA2,OS ;allowed at all lang levels"

NOTES:
  - see "IBM PL/I Programming Guide", V1R1 (old PL/I parser code)
  - "wkstn @as" indicates stuff from VisualAge PL/I, V2R2 documentation.
*/

/*--------------------*/
/*  compiler options  */
/*--------------------*/

//OPTION                  HELP   TYPE AI  LANGUAGELEVEL
"addext,noaddext          ~       OPT * * SAA,SAA2,OS", // wkstn @as
"aggregate,ag             ~       OPT * * SAA,SAA2,OS",
"attributes,a,full,short  ~       OPT * * SAA,SAA2,OS",
"check                    ~       OPT * * SAA,SAA2,OS", // wkstn @as
"cmpat,v1,v2              *       OPT * *          OS",
"compile,c,s,e,w          ~       OPT * * SAA,SAA2,OS",
"control                  *       OPT * *          OS",
"currency                 ~       OPT * * SAA,SAA2,OS", // wkstn @as
"deck,d,nodeck,nd         *       OPT * *          OS",

// "DEFAULT" option
"default,dft,ibm,ans      ~       OPT * * SAA,SAA2",
"ascii,ebcdic             default OPT * * SAA,SAA2",
"assignable,asgn          default OPT * * SAA,SAA2",
"nonassignable,nonasgn    default OPT * * SAA,SAA2",
"byaddr,byvalue           default OPT * * SAA,SAA2",
"nonconnected,nonconn     default OPT * * SAA,SAA2",
"connected,conn           default OPT * * SAA,SAA2",
"descriptor,nodescriptor  default OPT * * SAA,SAA2",
"native,nonnative         default OPT * * SAA,SAA2",
"nativeaddr,nonnativeaddr default OPT * * SAA,SAA2",    // wkstn @as
"noinline,inline          default OPT * * SAA,SAA2",
"order,reorder            default OPT * * SAA,SAA2",
"nodirected,directed,asm  default OPT * * SAA,SAA2",
"cobol,plitdli            default OPT * * SAA,SAA2",
"linkage,optlink,system   default OPT * * SAA,SAA2",
"ieee,hexadec,e           default OPT * * SAA,SAA2",
"evendec,noevendec        default OPT * * SAA,SAA2",    // wkstn @as
"initfill,noinitfill      default OPT * * SAA,SAA2",    // wkstn @as
"nullsys,null370          default OPT * * SAA,SAA2",    // wkstn @as
"recursive,nonrecursive   default OPT * * SAA,SAA2",    // wkstn @as
"desclist,desclocator     default OPT * * SAA,SAA2",    // wkstn @as
"returns                  default OPT * * SAA,SAA2",    // wkstn @as
"dummy,aligned,unaligned  default OPT * * SAA,SAA2",    // wkstn @as
"noretcode,retcode        default OPT * * SAA,SAA2",    // wkstn @as

"dllinit,nodllinit        ~       OPT * *     SAA2",
"esd                      *       OPT * *          OS",
"exit,noexit              exitopt OPT * * SAA,SAA2",
"flag,f,i                 ~       OPT * * SAA,SAA2,OS",
"gonumber,gn              ~       OPT * * SAA,SAA2,OS",
"gostmt,gs                *       OPT * *          OS",
"graphic,gr            graphicopt OPT * *          OS",
"imprecise,imp            ~       OPT * * SAA,SAA2,OS",
"incafter,process         ~       OPT * * SAA,SAA2",    // wkstn @as
"include,inc              ~       OPT * * SAA,SAA2,OS",
"ext                      ~       OPT * * SAA,SAA2",
"insource,is              ~       OPT * * SAA,SAA2,OS",
"interrupt,int            ~       OPT * * SAA,SAA2,OS",

// allow at all language levels, as these change to another language level
"langlvl,os               ~       OPT * * SAA,SAA2,OS",
"saa,saa2,noext           ~       OPT * * SAA,SAA2,OS",
"os2,windows              saa     OPT * * SAA,SAA2,OS",

"sprog,nosprog            *       OPT * * SAA,SAA2,OS",
"libs,nolibs              ~       OPT * * SAA,SAA2",
"single,multi             libs    OPT * *     SAA2",
"dynamic,static           libs    OPT * *     SAA2",
"limits,extname,fixeddec  ~       OPT * * SAA,SAA2",
"linecount,lc             ~       OPT * * SAA,SAA2,OS",
"list,nolist              ~       OPT * * SAA,SAA2,OS",
"lmessage,lmsg            *       OPT * *          OS",
"smessage,smsg            *       OPT * *          OS",
"macro,m,nomacro,nm       ~       OPT * * SAA,SAA2,OS",
"map,nomap                *       OPT * *          OS",
"margini,mi               ~       OPT * * SAA,SAA2,OS",
"nomargini,nmi            margini OPT * *          OS",
"margins,mar              ~       OPT * * SAA,SAA2,OS",
"mdeck,md,nomdeck,nmd     ~       OPT * * SAA,SAA2,OS",
"name,n                   *       OPT * *          OS",
"names                    ~       OPT * * SAA,SAA2",
"natlang,enu,jpn          ~       OPT * * SAA,SAA2",
"nest,nonest              ~       OPT * * SAA,SAA2,OS",
"noaggregate,nag          ~       OPT * * SAA,SAA2,OS",
"noattributes,na          ~       OPT * * SAA,SAA2,OS",
"nocompile,nc             ~       OPT * * SAA,SAA2,OS",
"noesd                    *       OPT * *          OS",
"nogonumber,ngn           ~       OPT * * SAA,SAA2,OS",
"nogostmt,ngs             *       OPT * *          OS",
"nographic,ngr            ~       OPT * *          OS",
"noimprecise,nimp         ~       OPT * * SAA,SAA2,OS",
"noinclude,ninc           ~       OPT * * SAA,SAA2,OS",
"noinsource,nis           ~       OPT * * SAA,SAA2,OS",
"nointerrupt,nint         ~       OPT * * SAA,SAA2,OS",
"nonumber,nonum           *       OPT * *          OS",
"nosequence,nseq          *       OPT * *          OS",
"not                      ~       OPT * * SAA,SAA2,OS",
"number,num               *       OPT * *          OS",
"object,obj,noobject,nobj *       OPT * *          OS",
"offset,of                *       OPT * *          OS",
"nooffset,nof             *       OPT * *          OS",
"optimize,opt,time        ~       OPT * * SAA,SAA2,OS",
"nooptimize,nopt          ~       OPT * * SAA,SAA2,OS",
"options,op,nooptions,nop optionsopt OPT * * SAA,SAA2,OS",
"or                       or      OPT * * SAA,SAA2,OS",
"pp,nopp                  pp      OPT * * SAA,SAA2",
"pptrace,nopptrace        ~       OPT * * SAA,SAA2",    // wkstn @as
"prefix                   ~       OPT * * SAA,SAA2",
"probe,noprobe            ~       OPT * * SAA,SAA2",
"proceed,pro              ~       OPT * * SAA,SAA2",
"noproceed,nopro          proceed OPT * * SAA,SAA2",
"profile,prof             ~       OPT * * SAA,SAA2",    // wkstn @as
"noprofile,nprof          profile OPT * * SAA,SAA2",    // wkstn @as
"respect,date             ~       OPT * *     SAA2",
"rules,nolaxbif,laxbif    ~       OPT * *     SAA2",
"nobyname,byname          rules   OPT * *     SAA2",
"nolaxctl,laxctl          rules   OPT * *     SAA2",
"nolaxdcl,laxdcl          rules   OPT * *     SAA2",
"nolaxif,laxif            rules   OPT * *     SAA2",
"nolaxqual,laxqual        rules   OPT * *     SAA2",
"nolaxmargins,laxmargins  rules   OPT * *     SAA2",
"nolaxstrz,laxstrz        rules   OPT * *     SAA2",
"nolaxcomment,nolaxcom    rules   OPT * *     SAA2",
"laxcomment,laxcom        rules   OPT * *     SAA2",
"nomulticlose,multiclose  rules   OPT * *     SAA2",
"runops,norunops          ~       OPT * * SAA,SAA2",
"semantic,sem           semantics OPT * * SAA,SAA2",
"nosemantic,nsem        semantics OPT * * SAA,SAA2",
"sequence,seq             *       OPT * *          OS",
"size,sz,max              *       OPT * *          OS",
"snap,nosnap              ~       OPT * * SAA,SAA2",
"source,s,nosource,ns     ~       OPT * * SAA,SAA2,OS",
"stmt,nostmt              *       OPT * *          OS",
"storage,stg              *       OPT * *          OS",
"nostorage,nstg           *       OPT * *          OS",
"syntax,syn,nosyntax,nsyn ~       OPT * * SAA,SAA2,OS",
"sysparm                  ~       OPT * * SAA,SAA2",
"system,cms,cmstpl,mvs    ~       OPT * *          OS",
"tso,cics,ims             system  OPT * *          OS",
"system,os2,ims,cms,mvs   ~       OPT * * SAA,SAA2",
"tso,s386,s486,pentium    system  OPT * * SAA,SAA2",
"terminal,term            ~       OPT * * SAA,SAA2,OS",
"noterminal,nterm        terminal OPT * * SAA,SAA2,OS",
"test,notest,all,block    ~       OPT * * SAA,SAA2,OS",
"tiled,notiled            ~       OPT * * SAA,SAA2,OS", // wkstn @as
"none,path,stmt,sym,nosym test    OPT * * SAA,SAA2,OS",
"track,date               ~       OPT * *     SAA2",
"window                   ~       OPT * *     SAA2",
"xinfo,def,nodef          ~       OPT * * SAA,SAA2",
"nomsg,msg                xinfo   OPT * * SAA,SAA2",
"nosyn,syn                xinfo   OPT * * SAA,SAA2",
"nosyntax,syntax          xinfo   OPT * *     SAA2",
"widechar,wchar           ~       OPT * *     SAA2",
"bigendian,littleendian  widechar OPT * *     SAA2",
"xref,x,noxref,nx         ~       OPT * * SAA,SAA2,OS",

/*----------------------------*/
/*  source language keywords  */
/*----------------------------*/

//KEYWORD                 HELP  TYPE AI   LANGUAGELEVEL
"abnormal                 ~     ATU  *  *     SAA2",    // non-data attribute -
"addbuff                  *     ENV  *  *          OS", // environment option
"alias                    ~     ATU  *  *     SAA2",    // non-data attribute
"aligned                  ~     ATU  *  * SAA,SAA2,OS", // descriptive attribute
"all                      *     SOP  *  *          OS", // stream i/o option
"allocate,alloc           ~     T2   *  * SAA,SAA2,OS", // statement keyword
"anycondition,anycond     ~     CON  *  *     SAA2",    // condition
"area                     area1 ATQ  *  * SAA,SAA2,OS", // data attribute
"area                     area2 CON  *  * SAA,SAA2,OS", // condition
"as                       ~     ATU  *  * SAA,SAA2,OS", // sql  attribute
"ascii                    *     ENV  *  *          OS", // environment option
"assembler,asm            ~     OPS  *  *     SAA2,OS", // options option ----
"assignable,asgn          ~     ATU  *  *     SAA2",    // non-data attribute
"nonassignable,nonasgn    ~     ATU  *  *     SAA2",    // non-data attribute
"attach                   ~     FLO  *  *     SAA2",    // statement keyword
"attention,attn           ~     CON  *  * SAA,SAA2,OS", // condition name
"automatic,auto           ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"backward                 *     ATU  *  *          OS", // non-data attribute
"based                    ~     ATQ  *  * SAA,SAA2,OS", // non-data attribute
"begin                    ~     FLO  3  3 SAA,SAA2,OS", // statement keyword
"binary,bin               ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"bit                      ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"bkwd                     ~     ENV  *  * SAA,SAA2,OS", // environment option
"blksize                  *     ENV  *  *          OS", // environment option
"blob                     ~     ATU  *  * SAA,SAA2,OS", // sql attribute
"buffered,buf             ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"buffers                  *     ENV  *  *          OS", // environment option
"buffoff                  *     ENV  *  *          OS", // environment option
"bufnd                    *     ENV  *  *          OS", // environment option
"bufni                    *     ENV  *  *          OS", // environment option
"bufsp                    *     ENV  *  *          OS", // environment option
"builtin                  ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"by                       ~     SOP  *  * SAA,SAA2,OS", // do statement keyword
"byaddr                 byaddr1 ATU  *  * SAA,SAA2",    // non-data attribute
"byaddr                 byaddr2 OPS  *  * SAA,SAA2",    // options option
"byvalue               byvalue1 ATU  *  * SAA,SAA2",    // non-data attribute
"byvalue               byvalue2 OPS  *  * SAA,SAA2",    // options option
"call                     ~     FLO  *  * SAA,SAA2,OS", // statement keyword
"cdecl                    ~     OPS  *  *     SAA2",    // options option
"cdecl16                  ~     OPS  *  *     SAA2",    // attribute keyword
"character,char           ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"chargraphic,charg chargraphic1 ATU  *  * SAA,SAA2,OS", // non data attribute ----
"chargraphic,charg chargraphic2 OPS  *  * SAA,SAA2,OS", // options option ----
"cics                     ~     SOP  *  * SAA,SAA2,OS", // statement option
"clob                     ~     ATU  *  * SAA,SAA2,OS", // sql attribute
"close                    ~     T1   *  * SAA,SAA2,OS", // statement keyword
"cobol                    ~     OPS  *  *     SAA2,OS", // options option ----
"cobol                    *     ENV  *  *          OS", // environment option
"consecutive              ~     ENV  *  * SAA,SAA2,OS", // environment option
"column,col             column1 SOP  *  *     SAA2",    // preprocessor stmt option or stream I/O option
"complex,cplx             ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"condition,cond      condition1 ATU  *  * SAA,SAA2,OS", // non-data attribute
"condition,cond      condition2 CON  *  * SAA,SAA2,OS", // non-data attribute --
"connected,conn           ~     ATU  *  * SAA,SAA2,OS", // descriptive attribute
"constant                 ~     *    *  * SAA,SAA2,OS", // non-data attribute ---- not allowed in source code - used as a tag RH
"controlled,ctl           ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"conversion,conv          ~     CON  *  * SAA,SAA2,OS", // condition name/prefix
"copy                     ~     SOP  *  * SAA,SAA2,OS", // stream i/o option
"ctlasa                   ~     ENV  *  * SAA,SAA2,OS", // environment option
"ctl360                   *     ENV  *  *          OS", // environment option
"d,db                     *     ENV  *  *          OS", // environment option
"data                     ~     SOP  *  * SAA,SAA2,OS", // stream i/o option
"date                     ~     ATQ  *  *     SAA2",    // date attribute
"decimal,dec              ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"declare,dcl              ~     T0   *  * SAA,SAA2,OS", // statement keyword
"default,dft              ~     T0   *  * SAA,SAA2,OS", // statement keyword
"define                   ~     T0   *  *     SAA2",    // statement keyword -
"defined,def              ~     ATQ  *  * SAA,SAA2,OS", // non-data attribute
"delay                    ~     T2   *  * SAA,SAA2,OS", // statement keyword
"delete                   ~     T1   *  * SAA,SAA2,OS", // statement keyword
"descriptor               ~     OPS  *  *     SAA2",    // attribute keyword
"detach                   ~     T1   *  *     SAA2",    // statement keyword
"descriptors              ~     SOP  *  * SAA,SAA2,OS", // default statement keyword
"dimension,dim            ~     ATQ  *  *     SAA2,OS", // data attribute ---- not allowed in source
"direct                   ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"display                  ~     T2   *  * SAA,SAA2,OS", // statement keyword
"do                       ~     T0   3  3 SAA,SAA2,OS", // statement keyword
"downthru                 ~     SOP  *  *     SAA2",    // do statement keyword
"edit                     ~     SOP  *  * SAA,SAA2,OS", // stream i/o option
"else                     ~     T0   3  3 SAA,SAA2,OS", // statement keyword
"end                      ~     FLO -3 -3 SAA,SAA2,OS", // statement keyword
"endfile,endf             ~     CON  *  * SAA,SAA2,OS", // condition name
"endpage,endp             ~     CON  *  * SAA,SAA2,OS", // condition name
"entry                   entry1 ATQ  *  * SAA,SAA2,OS", // data attribute
"entry                   entry2 T0   *  * SAA,SAA2,OS", // data attribute
"environment,env   environment1 ATQ  *  * SAA,SAA2,OS", // non-data attribute
"environment,env   environment2 SOP  *  * SAA,SAA2,OS", // statement option
"error                    ~     CON  *  * SAA,SAA2,OS", // condition name
"event                    *     SOP  *  *          OS", // non-data attribute
"exclusive                *     ATU  *  *          OS", // non-data attribute
"exit                     ~     FLO  *  * SAA,SAA2,OS", // statement keyword
"exports                  ~     ATQ  *  *     SAA2",    // package statement option
"external,ext             ~     ATQ  *  * SAA,SAA2,OS", // non-data attribute
"f,fb,fs,fbs              *     ENV  *  *          OS", // environment option
"fastcall16               ~     OPS  *  *     SAA2",    // attribute keyword
"fetch                    ~     FLO  *  * SAA,SAA2,OS", // statement keyword
"fetchable                ~     OPS  *  * SAA,SAA2",    // options option
"file                     file1 ATU  *  * SAA,SAA2,OS", // data attribute
"file                     file2 SOP  *  * SAA,SAA2,OS", // i/o option
"finish                   ~     CON  *  * SAA,SAA2,OS", // condition name
"fixed                    ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"fixedoverflow,fofl       ~     CON  *  * SAA,SAA2,OS", // condition name/prefix
"float                    ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"flow                     *     SOP  *  *          OS", // stream i/o option
"forever                  ~     SOP  *  * SAA,SAA2,OS", // do statement keyword
"format                   ~     T0   *  * SAA,SAA2,OS", // statement keyword
"fortran                  ~     OPS  *  *     SAA2,OS", // options option ----
"free                     ~     T2   *  * SAA,SAA2,OS", // statement keyword
"from                     ~     SOP  *  * SAA,SAA2,OS", // record i/o option
"fromalien                ~     OPS  *  *     SAA2",    // attribute keyword
"generic                  ~     ATQ  *  * SAA,SAA2,OS", // non-data attribute
"genkey                   ~     ENV  *  * SAA,SAA2,OS", // environment option
"get                      ~     T0   *  * SAA,SAA2,OS", // statement keyword
"go                       ~     T2   *  * SAA,SAA2,OS", // statement keyword, the TO is handled by special case code
"goto                     ~     T2   *  * SAA,SAA2,OS", // statement keyword
"graphic,g             graphic1 ATQ  *  * SAA,SAA2,OS", // data attribute
"graphic               graphic2 ENV  *  * SAA,SAA2,OS", // environment option
"handle                   ~     ATQ  *  *     SAA2",    // non-data attribute
"hexadec                  ~     ATU  *  *     SAA2",    // data attribute
"ieee                     ~     ATU  *  *     SAA2",    // data attribute
"if                       ~     T0   3  3 SAA,SAA2,OS", // statement keyword
"ignore                   ~     SOP  *  * SAA,SAA2,OS", // statement keyword
"in                       ~     SOP  *  * SAA,SAA2,OS", // allocate/free option
"indexed                  ~     ENV  *  *          OS", // environment option
"indexarea                *     ENV  *  *          OS", // environment option
"initial,init             ~     ATQ  *  * SAA,SAA2,OS", // non-data attribute
"input                    ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"inline                   ~     OPS  *  *     SAA2",    // options option ----
"inter                    *     OPS  *  *          OS", // options option ----
"internal,int             ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"into                     ~     SOP  *  * SAA,SAA2,OS", // record i/o option
"invalidop                ~     CON  *  *     SAA2",    // condition prefix
"irreducible,irred        *     ATU  *  * SAA,     OS", // non-data attribute
"irreducible,irred        ~     OPS  *  *     SAA2",    // options keyword
"is                       ~     ATU  *  * SAA,SAA2,OS", // sql  attribute
"iterate                  ~     FLO  *  *     SAA2",    // statement keyword
"key                      key1  CON  *  * SAA,SAA2,OS", // condition
"key                      key2  SOP  *  * SAA,SAA2,OS", // record i/o option
"keyed                    ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"keyfrom                  ~     SOP  *  * SAA,SAA2,OS", // record i/o option
"keylength                *     ENV  *  *          OS", // environment option
"keys                     ~     ATQ  *  * SAA,SAA2,OS", // preprocessor attribute
"keyloc                   ~     ENV  *  * SAA,SAA2,OS", // environment option
"keyto                    ~     SOP  *  * SAA,SAA2,OS", // record i/o option
"label                    ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"large                    ~     ATU  *  * SAA,SAA2,OS", // sql attribute
"leave                    ~     T2   *  * SAA,SAA2,OS", // statement keyword
"leave                    *     ENV  *  *          OS", // environment option
"like                     ~     ATQ  *  * SAA,SAA2,OS", // non-data attribute
"limited                  ~     ATU  *  *     SAA2",    // non-data attribute -
"line                     ~     SOP  *  * SAA,SAA2,OS", // stream i/o option
"linkage                  ~     OPS  *  *     SAA2",    // attribute keyword
"linesize                 ~     SOP  *  * SAA,SAA2,OS", // open option
"list                     ~     SOP  *  * SAA,SAA2,OS", // stream i/o option
"locate                   ~     T2   *  * SAA,SAA2,OS", // statement keyword
"locator                  ~     ATU  *  * SAA,SAA2,OS", // sql attribute
"loop                     ~     SOP  *  * SAA,SAA2,OS", // do statement keyword
"m                        *     ENV  *  *          OS", // environment option
"main                     ~     OPS  *  * SAA,SAA2,OS", // options option
"margins,mar              ~     SOP  *  *     SAA2",    // preprocessor statement option
"name                     name1 SOP  *  * SAA,SAA2,OS", // the 'name' part of BY NAME
"name                     name2 CON  *  * SAA,SAA2,OS", // condition name/prefix
"native                   ~     ATU  *  *     SAA2",    // non-data attribute -
"ncp                      *     ENV  *  *          OS", // environment option
"nochargraphic,nocharg    *     ATU  *  *          OS", // non data attribute - used to allow appearance on PROC stmt
"nochargraphic,nocharg    ~     OPS  *  * SAA,SAA2,OS", // options option ----
"noconversion,noconv      ~     CON  *  * SAA,SAA2,OS", // condition prefix
"nodescriptor             ~     OPS  *  *     SAA2",    // attribute keyword
"noexecops                ~     OPS  *  * SAA,SAA2,OS", // options option
"nofixedoverflow,nofofl   ~     CON  *  * SAA,SAA2,OS", // condition prefix
"noinline                 ~     OPS  *  *     SAA2",    // options option ----
"noinvalidop          invalidop CON  *  *     SAA2",    // condition prefix
"nolock                   *     SOP  *  *          OS", // i/o statement option
"nonconnected,nonconn     ~     ATU  *  *     SAA2",    // data attribute
"nonnative                ~     ATU  *  *     SAA2",    // non-data attribute -
"nonvarying,nonvar        ~     ATU  *  *     SAA2",    // data attribute
"nooverflow,noofl         ~     CON  *  * SAA,SAA2,OS", // condition prefix
"norescan             norescan1 ATU  *  * SAA,SAA2,OS", // preprocessor attribute
"norescan             norescan2 SOP  *  * SAA,SAA2,OS", // preprocessor statement option
"normal                 normal1 ATU  *  *     SAA2",    // non-data attribute -
"normal                 normal2 ATU  *  *     SAA2",    // non-data attribute -
"nosize                   ~     CON  *  * SAA,SAA2,OS", // condition prefix
"nostringrange,nostrg     ~     CON  *  * SAA,SAA2,OS", // condition prefix
"nostringsize,nostrz      ~     CON  *  * SAA,SAA2,OS", // condition prefix
"nosubscriptrange,nosubrg ~     CON  *  * SAA,SAA2,OS", // condition prefix
"note                     ~     SOP  *  * SAA,SAA2,OS", // preprocessor statement keyword
"nounderflow,noufl        ~     CON  *  * SAA,SAA2,OS", // condition prefix
"nowrite                  *     ENV  *  *          OS", // environment option
"nozerodivide,nozdiv      ~     CON  *  * SAA,SAA2,OS", // condition prefix
"noscan                 noscan1 ATU  *  * SAA,SAA2,OS", // preprocessor attribute
"noscan                 noscan2 SOP  *  * SAA,SAA2,OS", // preprocessor statement option
"object                   ~     ATQ  *  * SAA,SAA2,OS", // sql attribute
"offset                   ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"on                       ~     T0   *  * SAA,SAA2,OS", // statement keyword
"open                     ~     T0   *  * SAA,SAA2,OS", // statement keyword
"optional                 ~     ATU  *  *     SAA2",    // non-data attribute -
"options                  ~     ATQ  *  * SAA,SAA2,OS", // non-data attribute
"optlink                  ~     OPS  *  *     SAA2",    // options option ----
"order                    *     ATU  *  *          OS", // non-data attribute
"order                    ~     OPS  *  *     SAA2",    // options option ----
"ordinal                  ~     ATQ  *  *     SAA2",    // non-data attribute
"organization             ~     ENV  *  *     SAA2",    // environment option
"otherwise,other         other1 T0   3  3 SAA,SAA2,OS", // statement keyword
"otherwise,other         other2 ATQ  *  * SAA,SAA2,OS", // option of generic
"output                   ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"overflow,ofl             ~     CON  *  * SAA,SAA2,OS", // condition name/prefix
"package                  ~     T0   3  3     SAA2",    // statement keyword
"page                     ~     SOP  *  * SAA,SAA2,OS", // stream i/o option
"pagesize                 ~     SOP  *  * SAA,SAA2,OS", // open option
"parameter                ~     ATU  *  *     SAA2",    // data attribute
"pascal16                 ~     OPS  *  *     SAA2",    // attribute keyword
"password                 *     ENV  *  *          OS", // environment option
"pending                  *     CON  *  *          OS",
"picture,pic              ~     ATU  *  * SAA,SAA2,OS", // data attribute
"pointer,ptr              ~     ATU  *  * SAA,SAA2,OS", // data attribute
"position,pos             ~     ATQ  *  * SAA,SAA2,OS", // non-data attribute
"precision,prec           ~     ATQ  *  *     SAA2",    // non-data attribute -
"print                    ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"priority                 *     SOP  *  *          OS",
"procedure,proc           ~     T0   3  3 SAA,SAA2,OS", // statement keyword
"put                      ~     T0   *  * SAA,SAA2,OS", // statement keyword
"r                        *     ENV  *  *          OS", // environment option
"range                    ~     SOP  *  * SAA,SAA2,OS", // default statement keyword
"read                     ~     T1   *  * SAA,SAA2,OS", // statement keyword
"real                     ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"record                 record1 ATU  *  * SAA,SAA2,OS", // non-data attribute
"record                 record2 CON  *  * SAA,SAA2,OS", // condition
"recsize                  ~     ENV  *  * SAA,SAA2,OS", // environment option
"recursive                ~     ATU  *  * SAA,SAA2,OS", // non-data attribute - to allow it to appear on PROC stmt
"reducible,red            *     ATU  *  * SAA,     OS", // non-data attribute
"reducible,red            ~     OPS  *  *     SAA2",    // options keyword
"reentrant                ~     OPS  *  * SAA,SAA2,OS", // options option
"refer                    ~     ATQ  *  * SAA,SAA2,OS", // data attribute option
"regional                 ~     ENV  *  * SAA,SAA2,OS", // environment option
"relative                 ~     ENV  *  * SAA,SAA2",    // environment option
"release                  ~     T2   *  * SAA,SAA2,OS", // statement keyword
"reorder               reorder1 ATU  *  * SAA,SAA2,OS", // non-data attribute - to allow it to appear on PROC stmt
"reorder               reorder2 OPS  *  *     SAA2",    // options option ----
"repeat                   ~     SOP  *  * SAA,SAA2,OS", // do statement keyword
"reply                    ~     SOP  *  * SAA,SAA2,OS", // display option
"reread                   *     ENV  *  *          OS", // environment option
"rescan                 rescan1 ATU  *  * SAA,SAA2,OS", // preprocessor attribute
"rescan                 rescan2 SOP  *  * SAA,SAA2,OS", // preprocessor statement option
"reserved                 ~     ATU  *  *     SAA2",    // non-data attribute
"reserves                 ~     ATQ  *  *     SAA2",    // package statement attribute
"resignal                 ~     FLO  *  *     SAA2",    // statement keyword
"retcode                  ~     OPS  *  *     SAA2,OS", // options option ----
"return                   ~     FLO  *  * SAA,SAA2,OS", // statement keyword
"returns                  ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"reuse                    *     ENV  *  *          OS", // environment option
"revert                   ~     T2   *  * SAA,SAA2,OS", // statement keyword
"rewrite                  ~     T1   *  * SAA,SAA2,OS", // statement keyword
"scalarvarying            ~     ENV  *  * SAA,SAA2,OS", // environment option
"scan                     scan1 ATU  *  * SAA,SAA2,OS", // preprocessor attribute
"scan                     scan2 SOP  *  * SAA,SAA2,OS", // preprocessor statement option
"segmented                ~     ATU  *  *     SAA2",    // non - data attribute
"select                   ~     FLO  3  3 SAA,SAA2,OS", // statement keyword
"sequential,seql          ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"set                      ~     SOP  *  * SAA,SAA2,OS", // allocate/locate option
"signal                   ~     FLO  *  * SAA,SAA2,OS", // statement keyword
"signed,unsigned          ~     ATU  *  *     SAA2",    // non-data attribute
"sis                      *     ENV  *  *          OS", // environment option
"size                     ~     CON  *  * SAA,SAA2,OS", // condition name/prefix
"skip                     ~     SOP  *  * SAA,SAA2,OS", // stream i/o option
"skip                     *     ENV  *  *          OS", // environment option
"snap                     ~     SOP  *  * SAA,SAA2,OS", // on statement keyword
"sql                       sql1 SOP  *  * SAA,SAA2,OS", // statement option
"sql                       sql2 ATU  *  * SAA,SAA2,OS", // sql attribute
"statement                ~     ATU  *  * SAA,SAA2,OS", // preprocessor attribute
"static                   ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"stdcall                  ~     OPS  *  *     SAA2",    // options option ----
"stop                     ~     T1   *  * SAA,SAA2,OS", // statement keyword
"storage                  ~     CON  *  *     SAA2",    // condition prefix
"stream                   ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"string                   ~     SOP  *  * SAA,SAA2,OS", // stream i/o option
"stringrange,strg         ~     CON  *  * SAA,SAA2,OS", // condition name/prefix
"stringsize,strz          ~     CON  *  * SAA,SAA2,OS", // condition name/prefix
"structure                ~     ATU  *  *     SAA2",    // non-data attribute
"subscriptrange,subrg     ~     CON  *  * SAA,SAA2,OS", // condition name/prefix
"system                 system1 SOP  *  * SAA,SAA2,OS", // on statement keyword
"system                 system2 OPS  *  *     SAA2",    // options option ----
"task                     ~     ATU  *  *     SAA2,OS",
"task                     *     SOP  *  *     SAA2,OS",
"then                     ~     SOP  *  * SAA,SAA2,OS", // if statement keyword
"thread                   ~     SOP  *  *     SAA2",    // attach statement option
"title                    ~     SOP  *  * SAA,SAA2,OS", // open/fetch option
"to                       ~     SOP  *  * SAA,SAA2,OS", // do statement keyword
"total                    *     ENV  *  *          OS", // I/O env option ----- special for testing
"tp                       *     ENV  *  *          OS", // environment option
"transmit                 ~     CON  *  * SAA,SAA2,OS", // condition name
"trkofl                   *     ENV  *  *          OS", // environment option
"tstack                   ~     ENV  *  *     SAA2",    // attach statement env option
"type                     type1 ATQ  *  *     SAA2",    // non-data attribute
"type                     type2 SOP  *  * SAA,SAA2,OS", // statement option
"u                        *     ENV  *  *          OS", // environment option
"unaligned,unal           ~     ATU  *  * SAA,SAA2,OS", // descriptive attribute
"unbuffered,unbuf         ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"undefinedfile,undf       ~     CON  *  * SAA,SAA2,OS", // condition name
"underflow,ufl            ~     CON  *  * SAA,SAA2,OS", // condition name/prefix
"union                    ~     ATU  *  *     SAA2",    // non-data attribute
"unlock                   *     T1   *  *          OS", // i/o statemnent
"until                    ~     SOP  *  * SAA,SAA2,OS", // do statement keyword
"update                   ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"upthru                   ~     SOP  *  *     SAA2",    // do statement keyword
"v,vb,vs,vbs              *     ENV  *  *          OS", // environment option
"value                    ~     ATQ  *  *     SAA2",    // non-data attribute ----
"variable                 ~     ATU  *  * SAA,SAA2,OS", // non-data attribute
"varying,var              ~     ATU  *  * SAA,SAA2,OS", // data attribute
"varyingz,varz            ~     ATU  *  *     SAA2",    // data attribute
"vsam                     ~     ENV  *  * SAA,SAA2,OS", // environment option
"wait                     ~     T1   *  *     SAA2",    // statement keyword
"wait                     *     T2   *  *          OS", // statement keyword
"when                     when1 T0   3  3 SAA,SAA2,OS", // statement keyword
"when                     when2 ATQ  *  * SAA,SAA2,OS", // option of GENERIC
"while                    ~     SOP  *  * SAA,SAA2,OS", // do statement keyword
"widechar,wchar           ~     ATQ  *  * SAA,SAA2,OS", // data attribute
"winmain                  ~     OPS  *  *     SAA2",    // attribute keyword
"write                    ~     T1   *  * SAA,SAA2,OS", // statement keyword
"zerodivide,zdiv          ~     CON  *  * SAA,SAA2,OS", // condition name/prefix

/*--------------------*/
/*  SAA1 %statements  */
/*--------------------*/

// % statements & directives appear in here just like any others, and will be
// accepted as if they were normal statements.  The tokenizer recognizes a
// leading '%' as 'special', and uses the preprocessor style for the keywords.
// Beyond that, % statements get no special treatment.
//
// A number of the keywords are commented because they reflect underlying
// statements already supported above.

//STATEMENT       HELP       TYP AI  LANGUAGELEVEL
"activate,act     ~          T2  * * SAA,SAA2,OS",
"answer,ans       ~          T2  * *     SAA2",
"deactivate,deact ~          T2  * * SAA,SAA2,OS",
//do              %do        *   * * SAA,SAA2,OS",
//end             %end       *   * * SAA,SAA2,OS",
//go to           %goto          * * SAA,SAA2,OS",
//if              %if            * * SAA,SAA2,OS",
//then            %then          * * SAA,SAA2,OS",
"include          includedir PPS * * SAA,SAA2,OS",
"keys             *          T1  * * SAA,SAA2,OS",
"line             ~          PPS * *     SAA2",
"noprint          ~          PPS * * SAA,SAA2,OS",
"note             ~          PPS * * SAA,SAA2,OS",
//%null           %null          * * SAA,SAA2,OS",
"option           ~          PPS * * SAA,SAA2,OS", // wkstn @as
"page             ~          PPS * * SAA,SAA2,OS",
"pop              ~          PPS * * SAA,SAA2,OS", // wkstn @as
"print            ~          PPS * * SAA,SAA2,OS",
//procedure       %procedure     * * SAA,SAA2,OS",
"process          ~          PPS * * SAA,SAA2,OS",
"push             ~          PPS * * SAA,SAA2,OS", // wkstn @as
"replace          ~          PPS * * SAA,SAA2,OS", // wkstn @as
"skip             skipdir    PPS * * SAA,SAA2,OS",
"statement        *          PPS * * SAA,SAA2,OS",

/*-------------*/
/*  BIF names  */
/*-------------*/

//BIF              HELP TYP AI  LANGUAGELEVEL
"abs                  ~ BIF * * SAA,SAA2,OS",
"acos                 ~ BIF * * SAA,SAA2,OS",
"acosf                ~ BIF * *     SAA2",
"add                  ~ BIF * * SAA,SAA2,OS",
"addr                 ~ BIF * * SAA,SAA2,OS",
"addrdata             ~ BIF * *     SAA2",
"all                  ~ BIF * * SAA,SAA2,OS",
"allocate,alloc       ~ BIF * *     SAA2",
"allocation,allocn    ~ BIF * * SAA,SAA2,OS",
"allocsize            ~ BIF * *     SAA2",
"any                  ~ BIF * * SAA,SAA2,OS",
"asin                 ~ BIF * * SAA,SAA2,OS",
"asinf                ~ BIF * *     SAA2",
"atan                 ~ BIF * * SAA,SAA2,OS",
"atanf                ~ BIF * *     SAA2",
"atand                ~ BIF * * SAA,SAA2,OS",
"atanh                ~ BIF * * SAA,SAA2,OS",
"automatic,auto       ~ BIF * *     SAA2",
"availablearea        ~ BIF * *     SAA2",
"binary,bin           ~ BIF * * SAA,SAA2,OS",
"binaryvalue,binvalue ~ BIF * * SAA,SAA2,OS",
"bit                  ~ BIF * * SAA,SAA2,OS",
"bitlocation,bitloc   ~ BIF * *     SAA2",
"bool                 ~ BIF * * SAA,SAA2,OS",
"byte                 ~ BIF * *     SAA2",
"ceil                 ~ BIF * * SAA,SAA2,OS",
"centerleft,center    ~ BIF * *     SAA2",
"centreleft,centre    ~ BIF * *     SAA2",
"centerright          ~ BIF * *     SAA2",
"centreright          ~ BIF * *     SAA2",
"character            ~ BIF * *     SAA2",
"char                 ~ BIF * * SAA,SAA2,OS",
"chargraphic,charg    ~ BIF * *     SAA2",
"charval              ~ BIF * *     SAA2",
"checkstg             ~ BIF * *     SAA2",
"collate              ~ BIF * *     SAA2",
"comment              ~ BIF * *     SAA2",
"compare              ~ BIF * *     SAA2",
"compiledate          ~ BIF * *     SAA2",
"compiletime          ~ BIF * * SAA,SAA2,OS",
"completion           * BIF * *          OS",
"complex,cplx         ~ BIF * * SAA,SAA2,OS",
"conjg                ~ BIF * * SAA,SAA2,OS",
"copy                 ~ BIF * *     SAA2",
"cos                  ~ BIF * * SAA,SAA2,OS",
"cosf                 ~ BIF * *     SAA2",
"cosd                 ~ BIF * * SAA,SAA2,OS",
"cosh                 ~ BIF * * SAA,SAA2,OS",
"cotan                ~ BIF * *     SAA2",
"cotand               ~ BIF * *     SAA2",
"count                ~ BIF * * SAA,SAA2,OS",
"counter              ~ BIF * * SAA,SAA2,OS",
"currentsize          ~ BIF * *     SAA2",
"currentstorage,cstg  ~ BIF * * SAA,SAA2,OS",
"datafield            ~ BIF * * SAA,SAA2,OS",
"date                 ~ BIF * * SAA,SAA2,OS",
"datetime             ~ BIF * * SAA,SAA2,OS",
"days                 ~ BIF * *     SAA2",
"daystodate           ~ BIF * *     SAA2",
"daystosecs           ~ BIF * *     SAA2",
"decimal,dec          ~ BIF * * SAA,SAA2,OS",
"dimension,dim        ~ BIF * * SAA,SAA2,OS",
"divide               ~ BIF * * SAA,SAA2,OS",
"edit                 ~ BIF * *     SAA2",
"endfile              ~ BIF * *     SAA2",
"empty                ~ BIF * * SAA,SAA2,OS",
"entryaddr            ~ BIF * * SAA,SAA2,OS",
"epsilon              ~ BIF * *     SAA2",
"erf                  ~ BIF * * SAA,SAA2,OS",
"erfc                 ~ BIF * * SAA,SAA2,OS",
"exp                  ~ BIF * * SAA,SAA2,OS",
"expf                 ~ BIF * *     SAA2",
"exponent             ~ BIF * *     SAA2",
"fileddint            ~ BIF * *     SAA2",
"fileddtest           ~ BIF * *     SAA2",
"fileddword           ~ BIF * *     SAA2",
"fileid               ~ BIF * *     SAA2",
"fileopen             ~ BIF * *     SAA2",
"fileread             ~ BIF * *     SAA2",
"fileseek             ~ BIF * *     SAA2",
"filetell             ~ BIF * *     SAA2",
"filewrite            ~ BIF * *     SAA2",
"fixed                ~ BIF * * SAA,SAA2,OS",
"float                ~ BIF * * SAA,SAA2,OS",
"floor                ~ BIF * * SAA,SAA2,OS",
"gamma                ~ BIF * *     SAA2",
"getenv               ~ BIF * *     SAA2",
"graphic     graphicbif BIF * * SAA,SAA2,OS",
"handle               ~ BIF * *     SAA2",
"hbound               ~ BIF * * SAA,SAA2,OS",
"hex                  ~ BIF * *     SAA2",
"heximage             ~ BIF * *     SAA2",
"high                 ~ BIF * * SAA,SAA2,OS",
"huge                 ~ BIF * *     SAA2",
"iand                 ~ BIF * *     SAA2",
"ieor                 ~ BIF * *     SAA2",
"imag                 ~ BIF * * SAA,SAA2,OS",
"index                ~ BIF * * SAA,SAA2,OS",
"inot                 ~ BIF * *     SAA2",
"ior                  ~ BIF * *     SAA2",
"isigned              ~ BIF * *     SAA2",
"isll                 ~ BIF * *     SAA2",
"isrl                 ~ BIF * *     SAA2",
"item                 ~ BIF * *     SAA2",
"itemcount            ~ BIF * *     SAA2",
"iunsigned            ~ BIF * *     SAA2",
"lbound               ~ BIF * * SAA,SAA2,OS",
"left                 ~ BIF * *     SAA2",
"length               ~ BIF * * SAA,SAA2,OS",
"lineno               ~ BIF * * SAA,SAA2,OS",
"location,loc         ~ BIF * *     SAA2",
"log                  ~ BIF * * SAA,SAA2,OS",
"logf                 ~ BIF * *     SAA2",
"loggamma             ~ BIF * *     SAA2",
"log2                 ~ BIF * * SAA,SAA2,OS",
"log10                ~ BIF * * SAA,SAA2,OS",
"log10f               ~ BIF * *     SAA2",
"low                  ~ BIF * * SAA,SAA2,OS",
"lower2               ~ BIF * *     SAA2",
"macargs              ~ BIF * *     SAA2",
"maccol               ~ BIF * *     SAA2",
"macecho              ~ BIF * *     SAA2",
"macindex             ~ BIF * *     SAA2",
"maclmar              ~ BIF * *     SAA2",
"macparmset           ~ BIF * *     SAA2",
"macrmar              ~ BIF * *     SAA2",
"max                  ~ BIF * * SAA,SAA2,OS",
"maxexp               ~ BIF * *     SAA2",
"maxlength            ~ BIF * *     SAA2",
"min                  ~ BIF * * SAA,SAA2,OS",
"minexp               ~ BIF * *     SAA2",
"mod                  ~ BIF * * SAA,SAA2,OS",
"mpstr                ~ BIF * * SAA,SAA2,OS",
"multiply             ~ BIF * * SAA,SAA2,OS",
"null                 ~ BIF * * SAA,SAA2,OS",
"offset               ~ BIF * * SAA,SAA2,OS",
"offsetadd            ~ BIF * *     SAA2",
"offsetdiff           ~ BIF * *     SAA2",
"offsetsubtract       ~ BIF * *     SAA2",
"offsetvalue          ~ BIF * *     SAA2",
"omitted              ~ BIF * *     SAA2",
"onchar               ~ BIF * * SAA,SAA2,OS",
"oncode               ~ BIF * * SAA,SAA2,OS",
"oncondcond           ~ BIF * *     SAA2",
"oncondid             ~ BIF * *     SAA2",
"oncount              ~ BIF * * SAA,SAA2,OS",
"onfile               ~ BIF * * SAA,SAA2,OS",
"ongsource            ~ BIF * *     SAA2",
"onkey                ~ BIF * * SAA,SAA2,OS",
"onloc                ~ BIF * * SAA,SAA2,OS",
"onsource             ~ BIF * * SAA,SAA2,OS",
"onsubcode            ~ BIF * *     SAA2",
"onwchar              ~ BIF * *     SAA2",
"onwsource            ~ BIF * *     SAA2",
"ordinalhigh          ~ BIF * *     SAA2",
"ordinallow           ~ BIF * *     SAA2",
"ordinalname          ~ BIF * *     SAA2",
"ordinalpred          ~ BIF * *     SAA2",
"ordinalsucc          ~ BIF * *     SAA2",
"packagename          ~ BIF * *     SAA2",
"pageno               ~ BIF * *     SAA2",
"parmset              ~ BIF * * SAA,SAA2,OS",
"places               ~ BIF * *     SAA2",
"pliascii             ~ BIF * *     SAA2",
"plidelete            ~ BIF * *     SAA2",    // -
"plidump              ~ BIF * * SAA,SAA2,OS",
"pliebcdic            ~ BIF * *     SAA2",
"plifill              ~ BIF * *     SAA2",
"plifree              ~ BIF * *     SAA2",
"plimove              ~ BIF * *     SAA2",
"pliover              ~ BIF * *     SAA2",
"pliretc              ~ BIF * * SAA,SAA2,OS",
"pliretv              ~ BIF * * SAA,SAA2,OS",
"plisrta              ~ BIF * * SAA,SAA2,OS",
"plisrtb              ~ BIF * * SAA,SAA2,OS",
"plisrtc              ~ BIF * * SAA,SAA2,OS",
"plisrtd              ~ BIF * * SAA,SAA2,OS",
"plistsize            ~ BIF * *     SAA2",
"plitest              ~ BIF * * SAA,SAA2,OS",
"pointer,ptr          ~ BIF * * SAA,SAA2,OS",
"pointeradd,ptradd    ~ BIF * * SAA,SAA2,OS",
"pointerdiff,ptrdiff  ~ BIF * *     SAA2",
"pointersubtract,ptrsubtract ~ BIF * * SAA2",
"pointervalue,ptrvalue ~ BIF * * SAA,SAA2,OS",
"poly                 ~ BIF * *     SAA2",    // wkstn @as
"precision,prec       ~ BIF * * SAA,SAA2,OS",
"pred                 ~ BIF * *     SAA2",
"present              ~ BIF * *     SAA2",
"priority             ~ BIF * * SAA,SAA2,OS",
"procedurename,procname ~ BIF * *   SAA2",
"prod                 ~ BIF * * SAA,SAA2,OS",
"putenv               ~ BIF * *     SAA2",
"quote                ~ BIF * *     SAA2",
"radix                ~ BIF * *     SAA2",
"raise2               ~ BIF * *     SAA2",
"random               ~ BIF * *     SAA2",
"rank                 ~ BIF * *     SAA2",
"real           realbif BIF * * SAA,SAA2,OS",
"rem                  ~ BIF * *     SAA2",
"repattern            ~ BIF * *     SAA2",
"repeat               ~ BIF * * SAA,SAA2,OS",
"reverse              ~ BIF * *     SAA2",
"right                ~ BIF * *     SAA2",
"round                ~ BIF * * SAA,SAA2,OS",
"samekey              ~ BIF * * SAA,SAA2,OS",
"scale                ~ BIF * *     SAA2",
"search               ~ BIF * *     SAA2",
"searchr              ~ BIF * *     SAA2",
"secs                 ~ BIF * *     SAA2",
"secstodate           ~ BIF * *     SAA2",
"secstodays           ~ BIF * *     SAA2",
"serialize4           ~ BIF * *     SAA2",
"sign                 ~ BIF * * SAA,SAA2,OS",
"signed               ~ BIF * *     SAA2",
"sin                  ~ BIF * * SAA,SAA2,OS",
"sind                 ~ BIF * * SAA,SAA2,OS",
"sinf                 ~ BIF * *     SAA2",
"sinh                 ~ BIF * * SAA,SAA2,OS",
"size                 ~ BIF * *     SAA2",
"sourcefile           ~ BIF * *     SAA2",
"sourceline           ~ BIF * *     SAA2",
"sqrt                 ~ BIF * * SAA,SAA2,OS",
"sqrtf                ~ BIF * *     SAA2",
"status               ~ BIF * *          OS",
"storage,stg          ~ BIF * * SAA,SAA2,OS",
"string               ~ BIF * * SAA,SAA2,OS",
"substr               ~ BIF * * SAA,SAA2,OS",
"subtract             ~ BIF * *     SAA2",
"succ                 ~ BIF * *     SAA2",
"sum                  ~ BIF * * SAA,SAA2,OS",
"sysnull              ~ BIF * * SAA,SAA2,OS",
"sysparm              ~ BIF * *     SAA2",
"system       systembif BIF * *     SAA2",
"sysversion           ~ BIF * *     SAA2",
"tally                ~ BIF * *     SAA2",
"tan                  ~ BIF * * SAA,SAA2,OS",
"tand                 ~ BIF * * SAA,SAA2,OS",
"tanf                 ~ BIF * *     SAA2",
"tanh                 ~ BIF * * SAA,SAA2,OS",
"threadid             ~ BIF * *     SAA2",    // -
"time                 ~ BIF * * SAA,SAA2,OS",
"tiny                 ~ BIF * *     SAA2",
"translate            ~ BIF * * SAA,SAA2,OS",
"trim                 ~ BIF * *     SAA2",
"trunc                ~ BIF * * SAA,SAA2,OS",
"type                 ~ BIF * *     SAA2",
"unallocated          ~ BIF * *     SAA2",
"unsigned             ~ BIF * *     SAA2",
"unspec               ~ BIF * * SAA,SAA2,OS",
"valid                ~ BIF * *     SAA2",
"validdate            ~ BIF * *     SAA2",
"varglist             ~ BIF * *     SAA2",
"vargsize             ~ BIF * *     SAA2",
"verify               ~ BIF * * SAA,SAA2,OS",
"verifyr              ~ BIF * *     SAA2",
"wchar                ~ BIF * *     SAA2",
"whigh                ~ BIF * *     SAA2",
"widechar             ~ BIF * *     SAA2",
"wlow                 ~ BIF * *     SAA2",
"weekday              ~ BIF * *     SAA2",
"y4date               ~ BIF * *     SAA2",
"y4julian             ~ BIF * *     SAA2",
"y4year               ~ BIF * *     SAA2",

/*------------------*/
/*  TYPE functions  */
/*------------------*/

//FUNC  H TYP AI  LEVEL
"bind   ~ TYF * * SAA2",
"cast   ~ TYF * * SAA2",
"first  ~ TYF * * SAA2",
"last   ~ TYF * * SAA2",
"new    ~ TYF * * SAA2",
"respec ~ TYF * * SAA2",
"size   ~ TYF * * SAA2",
};
}