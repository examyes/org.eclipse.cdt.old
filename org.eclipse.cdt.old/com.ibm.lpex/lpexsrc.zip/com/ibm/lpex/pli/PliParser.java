//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// PliParser - document parser for PL/I.
//----------------------------------------------------------------------------

package com.ibm.lpex.pli;

import java.text.MessageFormat;        // for format(), to substitute arguments
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.Vector;

import com.ibm.lpex.core.HelpCommand;
import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCharStream;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexDocumentLocation;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import com.ibm.lpex.cc.LpexPliParserTokenManager;
import com.ibm.lpex.cc.Token;
import com.ibm.lpex.cc.TokenMgrError;

import com.ibm.lpex.cics.CicsLexer;
import com.ibm.lpex.cics.CicsLexerClasses;
import com.ibm.lpex.cics.CicsLexerStyles;
import com.ibm.lpex.sql.SqlLexer;
import com.ibm.lpex.sql.SqlLexerClasses;
import com.ibm.lpex.sql.SqlLexerStyles;


/**
 * Document parser for PL/I.
 *
 * <p>Actions added by this tokenizer:  <b>procedures</b> (Ctrl+G), <b>outline,
 * preproc, includes, extensions, sqlCics, errors</b> for selective views of
 * the document:  procedures, a logical outline, preprocessor statements,
 * includes, extensions, embedded SQL and CICS, and errors.
 *
 * <br>Action modified by this parser:  <b>split</b> for handling text moved
 * below the left margin after a split, and <b>match</b> (Ctrl+M) for matching
 * PL/I constructs.
 */
public class PliParser extends LpexCommonParser
{
   // whether the help index was loaded, and the help index .properties file
   private static boolean    properties_loaded;
   private static Properties helpPages;

   private static Vector                    // supported keywords, loaded in:
      optKeywords,                          // - compile-option keywords,
      keywords;                             // - all other keywords
   private static int ii;                   // index into Keywords

   // the input stream the view feeds
   private LpexCharStream stream;

   private static ResourceBundle resource =
      ResourceBundle.getBundle("com.ibm.lpex.pli.Profile");

   // LPEX classes we use
   private static final String
      CLASS_CODE        = "code",
      CLASS_SPACE       = "space",          // empty line
      CLASS_FWDLINK     = "forwardLink",    // doubly-link parse
      CLASS_BWDLINK     = "backwardLink",   //   units
      CLASS_SEMICOLON   = "semicolon",      // end of PL/I statement
      CLASS_ERROR       = "error",
      CLASS_COMMENT     = "comment",
      CLASS_CONTROL     = "control",        // flow control
      CLASS_PROC        = "proc",
      CLASS_PERCENT     = "percent",        // % preprocessor statement
      CLASS_INCLUDE     = "include",        // %INCLUDE preprocessor statement
      CLASS_EXTENSION   = "extension",      // word not at this language level
      CLASS_SQL         = "sql",            // embedded SQL
      CLASS_CICS        = "cics";           // embedded CICS

   private long
      classCode,
      classSpace,
      classForwardLink,
      classBackwardLink,
      classSemicolon,
      classError,
      classComment,
      classControl,
      classProc,
      classPercent,
      classInclude,
      classExtension,
      classSql,
      classCics,
      classAll;

   // parsing special states
   private static final int
      STATE_NONE        = 0x00000000,

      STATE_DCL         = 0x00000001,      // DCL statement
      STATE_PROC        = 0x00000002,      // PROC statement

      STATE_MAYBELABEL  = 0x00000004,      // current WORD may be a label

      STATE_PROCESS     = 0x00000020,      // expecting "*PROCESS"
      STATE_PROCESS_ARG = 0x00000021,      // - "*PROCESS" arguments

      STATE_EXEC        = 0x00000040,      // after "EXEC"
      STATE_SQL         = 0x00000041,      // - after "EXEC SQL"
      STATE_CICS        = 0x00000042;      // - after "EXEC CICS"

   private int state;                           // current state
   private PliToken beginUnit = new PliToken(); // 1st of (potential) parse unit

   private int firstLabel;                      // first in a series of labels
   private boolean ppLabel;                     // is it a %label?

   private int
      // parser's default margins [as set in Profile.properties]
      defaultLeftMargin = 2, defaultRightMargin = 72,
      // margins, as set by the latest *PROCESS statement / parser defaults
      leftMargin, rightMargin,
      // margins with which we parsed the doc
      docLeftMargin, docRightMargin,
      // language level
      defaultLanguageLevel = SAA2, languageLevel,
      // level with which we parsed doc (must change if can set inside doc! -
      // we currently do not support %OPTION LANGLVL / MARGINS / ... *as*)
      docLanguageLevel,
      // ANSI control character column
      ccColumn;

   // statement built-up from PliTokens
   private PliToken statement, lastStatementToken;

   // first PL/I source element in the file (after any *PROCESS statements)
   private int firstSourceElement;

   // lexers we (may) use
   private static final int
      LEXER_PLI  = 0,
      LEXER_SQL  = 1,
      LEXER_CICS = 2;

   private PliLexer  pliLexer;
   private SqlLexer  sqlLexer;
   private CicsLexer cicsLexer;
   private int       activeLexer = LEXER_PLI;

   // token delimiters for isTokenDelimiter()
   private static final String TOKEN_DELIMITERS = "();,";

   // group (attribute) names for keywords
   private static final int
      ATU  =  0, // Attribute unqualified, i.e., you CANNOT put anything
                 // in parentheses after it.  E.g., ALIGNED
      ATQ  =  1, // Attribute qualified, i.e., you CAN put something
                 // in parentheses after it.  E.g., FIXED(3) or INIT(...)
      FLO  =  2, // Statement keyword which can influence flow of control.
                 // E.g., PROC, CALL, IF
      BIF  =  3, // Built-in function name
      TYF  =  4, // Type function name - has args enclosed in (: and :)
      CON  =  5, // Condition name
      SOP  =  6, // Statement option keyword
                 // E.g., INTO, SET
      OPT  =  7, // Word which may appear in a compiler option.
                 // E.g., OPTIMIZE, MAX
      OPS  =  8, // Word which may appear in an OPTIONS option.
                 // E.g., ASSEMBLER
      ENV  =  9, // Word which may appear in an ENVIRONMENT attribute.
                 // E.g., TOTAL
      T0   = 10, // Pseudo statement keyword.  Used to allow a statement
                 // keyword to be in the file for look-up purposes.
      T1   = 11, // A 'type 1' statement keyword - the type of statement
                 // which takes only options and parentheses.
                 // E.g., READ FILE(..) INTO(..) ;
      T2   = 12, // A 'type 2' statement keyword - the type of statement which
                 // takes an identifier or an expression as its first item.
                 // E.g., ALLOCATE x SET(..) ;
                 // also used to encompass 'anything not a type 1'.
      PPS  = 13, // It's to do with preprocessing EXCLUSIVLY.  However, a lot
                 // of the preprocessor words appear in here as if they were
                 // ordinary statements.  This is because they can be used as if
                 // they were ordinary statements in the construction of a
                 // preprocessor procedure.
      ASTR = 14; // It was specified as '*', i.e., it does not have one.

   // language levels
   private static final int
      SAA  = 0x00000001,
      SAA2 = 0x00000002,
      OS   = 0x00000004;

// // iMode values for bDclStatement, bDoStatement and bKeyWordStatement
// private static final int
//    REQUIRE_IDENTIFIERS          = 0x00000001,
//    REQUIRE_DECLARE              = 0x00000002,
//    REQUIRE_SINGLE_ATTRIBUTE_SET = 0x00000004,
//    REQUIRE_SEMICOLON            = 0x00000008,
//    OPTIONAL_SEMICOLON           = 0x00000010,
//    FORBID_SEMICOLON             = 0x00000020,
//    VALUE_AS_IN_DEFAULT          = 0x00000040,
//    MARK_DO_AS_KEYWORD           = 0x00000080;

      // no AI value/default
      private static final int NO_AI = 9999;


   /**
    * Constructor for the parser.
    * Adds all of the parser specifics to the LPEX document view.
    * It initializes the view for the parser:  it sets up the style
    * attributes, classes, etc. for the language-sensitive edit features
    * supported.
    *
    * @param lpexView the LPEX document view associated with this parser
    */
   public PliParser(LpexView lpexView)
   {
      super(lpexView);        // LpexCommonParser constructor (view := lpexView)

      initializeParser();     // initialize LpexView with our stuff
      loadKeywords();         // load the table of PL/I keywords

      // instantiate an input stream for this view, and the main (PL/I) lexer
      stream   = new LpexCharStream(view);
      pliLexer = new PliLexer(stream);
   }

   /**
    * Total parse of the entire document.
    * Done initially, after a document has been loaded in LPEX, or after an
    * <b>updateProfile</b> command.
    */
   public void           parseAll()
   {
      firstSourceElement = 1;

      if (view.elements() == 0)                   // a bit of preventive care...
         return;

      // initialize parse operation & get parsing
      stream.Init(1, view.elements(), classAll, classSpace, '_', false);
      setLexer(LEXER_PLI);                  // the TokenManager defaults to PL/I
      statement = null;

      leftMargin    = defaultLeftMargin;
      rightMargin   = defaultRightMargin;
      languageLevel = defaultLanguageLevel;
      state = STATE_PROCESS;       // expect *PROCESS statements at start of doc
      stream.setMargins(0, defaultRightMargin, '?');

      while (true) {
         try {
            if ((processToken() & LEXER_RC_EOF) != 0)
               break;
            }
         catch (TokenMgrError e) {            // EOF in middle of token/bad char
            stream.setStyles(stream.getBeginColumn(),stream.getEndColumn(),'e');
            stream.setClasses(classError | classCode);
            addErrorMessage(stream.getEndLine(), "syntaxError");
            if (stream.EOFSeen()) {                 // EOF (styles already set)?
               stream.setCurrentStyles();           //  do it again, complete
               break;                               //  & that's it, folks...
               }

            stream.skipChar();       // skip the error character (presumably...)
            reinitializeLexer();                          //  & continue past it
            }
         }

      handleEndOfFile();                // EOF: complete any unfinished business
   }

   /**
    * Incremental parse.
    * @param element the (first) element whose committed change triggered the
    *                parse, or the element that precedes/follows a deleted block.
    *                The parser may identify other neighbouring elements that
    *                will have to be reparsed as a unit
    */
   public void           parseElement(int element)
   {
      int elements = view.elements();
      if (elements == 0)                                   // preventive care...
         return;

      // evaluate optimal range to parse
      int beginElement = evaluateBeginElement(element);
      int endElement   = evaluateEndElement(element);

      // clear any previously-marked lexical errors in the parse range
      removeMessages(beginElement, endElement);

      // initialize parse operation & get parsing
      stream.Init(beginElement, endElement, classAll, classSpace, '_',
                  true);         // clear parsePending once done with an element
      setLexer(LEXER_PLI);                  // the TokenManager defaults to PL/I
      statement = null;

      if (beginElement <= firstSourceElement) { // assume<MARGINS,LANGLVL options
         leftMargin    = defaultLeftMargin;
         rightMargin   = defaultRightMargin;
         languageLevel = defaultLanguageLevel;
         state = STATE_PROCESS;
         stream.setMargins(0, defaultRightMargin, '?');
         }
      else {
         state = STATE_NONE;
         stream.setMargins(leftMargin, rightMargin, '?');
         }

      while (true) {
         try {
            int rc = processToken();
            // on EOF, we may have to extend the parse range
            if ((rc & LEXER_RC_EOF) != 0) {
               endElement = stream.getEndLine(); // may have been Expand()ed...
               if ((rc & LEXER_RC_MORE) != 0 ||
                   (view.elementClasses(endElement) & classForwardLink) != 0) {
                  do {
                     endElement++;
                     } while ((endElement <= elements) && view.show(endElement));
                  if (endElement > elements)
                     break;
                  expandParseRange(endElement);
                  }
               else
                  break;
               }
            }
         catch (TokenMgrError e) {            // EOF in middle of token/bad char
            stream.setStyles(stream.getBeginColumn(),stream.getEndColumn(),'e');
            stream.setClasses(classError | classCode);
            addErrorMessage(stream.getEndLine(), "syntaxError");
            if (stream.EOFSeen()) {                 // EOF (styles already set)?
               stream.setCurrentStyles();           //  do it again, complete
               break;                               //  & that's it, folks...
               }

            stream.skipChar();       // skip the error character (presumably...)
            reinitializeLexer();                          //  & continue past it
            }
         }//end "while true"

      handleEndOfFile();                // EOF: complete any unfinished business
   }

   /**
    * EOF during parsing:  complete any unfinished business.
    *
    * @see #parseAll
    * @see #parseElement
    */
   private void          handleEndOfFile()
   {
      // if we linked any PliTokens for later parsing, complete the task
      pliLexer.handleStatement();
      // on a PROC statement, link as much as we have gathered so far
      if (state == STATE_PROC)
         setParseUnitClass(firstLabel, stream.getEndLine(), classProc);
   }

   /**
    * Returns the parser's properties profile resource bundle.
    */
   public ResourceBundle getProfile()
   {
      return resource;
   }

   /**
    * Returns "PLI", the languages supported by this parser (PL/I).
    *
    * @see com.ibm.lpex.core.LpexCommonParser#LANGUAGE_PLI
    */
   public String         getLanguage()
   {
      return LANGUAGE_PLI;
   }

   /**
    * Retrieve a string identifying the language segment at the specified
    * location.  In mixed-content documents, this may differ from the main
    * language of the document.
    *
    * The method assumes that no parse is pending.
    *
    * @return one of: LpexCommonParser.LANGUAGE_PLI,
    *                 LpexCommonParser.LANGUAGE_CICS,
    *                 LpexCommonParser.LANGUAGE_SQL
    */
   public String         getLanguage(LpexDocumentLocation loc)
   {
      long classes = view.elementClasses(loc.element);
      if ((classes & classSql) != 0)
         return LANGUAGE_SQL;
      if ((classes & classCics) != 0)
         return LANGUAGE_CICS;
      return getLanguage();
   }

   /**
    * Initialize the parser for an LPEX document view: set up style attributes
    * for the styles we need, classes, etc., and initialize the view
    * for the language-sensitive edit features supported.
    */
   private void          initializeParser()
   {
      /*----------------------------------------*/
      /*  set attributes for the styles we use  */
      /*----------------------------------------*/
      String tokenHighlight = getProperty("tokenHighlight");
      setStyleAttributes(tokenHighlight==null || !tokenHighlight.equals("off"));

      /*--------------------------------------------*/
      /*  read default properties from the Profile  */
      /*--------------------------------------------*/
      int margin = 0;
      try {
         margin = Integer.parseInt(getProperty("leftMargin"));
         }
      catch (Exception e) {}
      if (margin > 0)
         defaultLeftMargin = margin;
      margin = 0;
      try {
         margin = Integer.parseInt(getProperty("rightMargin"));
         }
      catch (Exception e) {}
      if (margin >= defaultLeftMargin)
         defaultRightMargin = margin;
      if (defaultLeftMargin > defaultRightMargin)
         defaultLeftMargin = defaultRightMargin;

      leftMargin  = defaultLeftMargin;
      rightMargin = defaultRightMargin;

      try {
         int langLevel = 0;
         StringTokenizer st =
            new StringTokenizer(getProperty("languageLevel").toUpperCase(),",");
         while (st.hasMoreTokens()) {
            String s = st.nextToken();
            if      (s.equals("SAA"))  langLevel |= SAA;
            else if (s.equals("SAA2")) langLevel |= SAA2;
            else if (s.equals("OS"))   langLevel |= OS;
            }
         if (langLevel != 0)
            defaultLanguageLevel = langLevel;
         }
      catch (Exception e) {}

      languageLevel = defaultLanguageLevel;

      // also read "names", "or", and "not"!? *as*

      // set our format line
      setPliFormatLine();

      /*----------------------------------------------------*/
      /*  register classes & get their allocated bit-masks  */
      /*----------------------------------------------------*/
      classCode         = view.registerClass(CLASS_CODE);
      classSpace        = view.registerClass(CLASS_SPACE);
      classForwardLink  = view.registerClass(CLASS_FWDLINK);
      classBackwardLink = view.registerClass(CLASS_BWDLINK);
      classSemicolon    = view.registerClass(CLASS_SEMICOLON);
      classError        = view.registerClass(CLASS_ERROR);
      classComment      = view.registerClass(CLASS_COMMENT);
      classControl      = view.registerClass(CLASS_CONTROL);
      classProc         = view.registerClass(CLASS_PROC);
      classPercent      = view.registerClass(CLASS_PERCENT);
      classInclude      = view.registerClass(CLASS_INCLUDE);
      classExtension    = view.registerClass(CLASS_EXTENSION);
      classSql          = view.registerClass(CLASS_SQL);
      classCics         = view.registerClass(CLASS_CICS);
      classAll = classCode | classSpace | classForwardLink | classBackwardLink |
                 classSemicolon | classError | classComment | classControl |
                 classProc | classPercent | classInclude | classExtension |
                 classSql | classCics;

      // redefine action "split"
      LpexAction lpexAction = new LpexAction()             // "split"
      {
         public void     doAction(LpexView view)
         { split(); }

         public boolean  available(LpexView view)
         { return view.defaultActionAvailable(ACTION_SPLIT); }
      };
      view.defineAction("split", lpexAction);

      /*-----------------------------------*/
      /*  define LPEX view-filter actions  */
      /*-----------------------------------*/
      lpexAction = new LpexAction() {                      // "procedures"
         public void     doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_PROC);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean  available(LpexView lpexView)
         { return true; }
         };
      view.defineAction("procedures", lpexAction);
      view.doDefaultCommand("set keyAction.c-g.t.p.c procedures");

      lpexAction = new LpexAction() {                      // "outline"
         public void     doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_PROC + " " +
                                  CLASS_CONTROL);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean  available(LpexView lpexView)
         { return true; }
         };
      view.defineAction("outline", lpexAction);

      lpexAction = new LpexAction() {                      // "preproc"
         public void     doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_PERCENT);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean  available(LpexView lpexView)
         { return true; }
         };
      view.defineAction("preproc", lpexAction);

      lpexAction = new LpexAction() {                      // "includes"
         public void     doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_INCLUDE);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean  available(LpexView lpexView)
         { return true; }
         };
      view.defineAction("includes", lpexAction);

      lpexAction = new LpexAction() {                      // "extensions"
         public void     doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_EXTENSION);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean  available(LpexView lpexView)
         { return true; }
         };
      view.defineAction("extensions", lpexAction);

      lpexAction = new LpexAction()                        // "sqlCics"
      {
         public void     doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " +
                                  CLASS_SQL + " " + CLASS_CICS);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean  available(LpexView view)
         { return true; }
      };
      view.defineAction("sqlCics", lpexAction);

      lpexAction = new LpexAction() {                      // "errors"
         public void     doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " +
                                 CLASS_ERROR + " " + CLASS_MESSAGE);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean  available(LpexView lpexView)
         { return /* could check if any errors in doc... */ true; }
         };
      view.defineAction("errors", lpexAction);
   }

   /**
    * Return parser's items for the popup View submenu:
    * procedures, outline, etc.
    */
   public String         getPopupViewItems()
   {
      StringBuffer buffer = new StringBuffer();
      buffer.append(getLanguage());
      buffer.append(".popup.procedures procedures ");
      buffer.append(getLanguage());
      buffer.append(".popup.outline outline ");
      buffer.append(getLanguage());
      buffer.append(".popup.preproc preproc ");
      buffer.append(getLanguage());
      buffer.append(".popup.includes includes ");
      buffer.append(getLanguage());
      buffer.append(".popup.extensions extensions ");
      buffer.append(getLanguage());
      buffer.append(".popup.sqlCics sqlCics ");
      buffer.append(MSG_POPUP_ERRORS);
      buffer.append(" errors");
      return buffer.toString();
   }

   /**
    * Define parser's style attributes.  Unscanned text uses default '!'.
    *
    * @param colours true = token highlighting,
    *                false = no token highlighting
    */
   public void           setStyleAttributes(boolean colours)
   {
      String toBackground = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                        BACKGROUND_COLOR,
                                                        toBackground);

      if (colours) {
         setStyle("_aus", attributes);      // Layout blanks, Variable name,
                                            //   Label,
                                            //   Language symbol

         attributes = LpexPaletteAttributes.convert("140 140 255 255 255 255",
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("g", attributes);         // Extension

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_NONSOURCE,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("?", attributes);         // Outside margins

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("c", attributes);         // Comment

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_ERROR,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("e", attributes);         // Lexical error

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("k", attributes);        // Keyword

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_LIBRARY,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("b", attributes);         // Built-in function

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_NUMERAL,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("n", attributes);         // Number

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_STRING,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("l", attributes);         // Literal

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DIRECTIVE,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("qr", attributes);        // Preprocessor keyword,
                                            //   Preprocessor '?'
         }
      else                                  // drop the nice colours
         setStyle("_ausg?cekbnlqr", attributes);
   }

   /**
    * Ensure split text doesn't go below left margin after a split action
    * (Alt+S), or else things will be misinterpreted, e.g., split [under Ctrl+G]
    * causes a PROC to not be defined as PROC any more...
    * LpexCommonParser takes care of the splitLine action (Enter key), as
    * there the cursor also moves to the new line, so AI is well justified.
    */
   private void          split()
   {
      // this works fine if current line's (where we do the split) left
      // margin is empty - needs additional work if it is not!...  *as*
      LpexDocumentLocation loc = view.documentLocation();  // current location
      splitLine();                                         // do splitLine, set
      // if loc is visible! + move to LpexCommonParser.java?! *as*
      view.jump(loc);                                      //  original cursor
   }

   /**
    * Match PL/I constructs (e.g., "PROC" - "END").
    *
    * @param loc document location of the token to match
    * @return matching-token location (with <code>loc</code> adjusted to include
    *         the entire original token), or
    *         <code>null</code> if not a matchable token, or
    *         original <code>loc</code> if no match found for the token
    */
   protected LpexDocumentLocation matchToken(LpexDocumentLocation loc)
   {
      LpexDocumentLocation s = tokenBegin(loc);
      if (s == null)
         return null;
      LpexDocumentLocation e = tokenEnd(loc);

      /* matchable token? */
      char style;
      int dir = matchTokenDirection(s,e, (style='k')); // PL/I control token?
      if (dir == 0)
         dir = matchTokenDirection(s,e, (style='q'));  // preprocessor token?
      if (dir == 0)          // +1 = search forward, -1 = backward (from [%]END)
         return null;                                  // not a matchable token.

      int locAdjust = (dir==1) ? s.position : e.position;
      int nesting   = dir;

      String token = view.elementText(s.element)       // save token to match
                         .substring(s.position-1, e.position);

      /* find match */
      while ((dir==1) ? nextToken(s,e) : previousToken(s,e)) {
         nesting += matchTokenDirection(s,e, style);
         if (nesting == 0) {                           // found matching token:
            loc.position = locAdjust;                  //  include orig. token
            return new LpexDocumentLocation(e.element, //  return match.
                                            (dir==1) ? e.position : s.position);
            }
         }

      view.doDefaultCommand("set messageText " +       // no match found in doc
                            LpexResources.message("match.token", token));
      return loc;   // return original loc, so doesn't try to match parentheses.
   }

   /**
    * Verify type of match for PL/I token.
    *
    * @param s          start of a token
    * @param e          end of the token
    * @param tokenStyle the style that the token must have
    * @return +1 matching forward (e.g., "PROC"), or
    *         -1 matching backward (e.g., "END"), or
    *         0  not a matchable token
    */
   private int           matchTokenDirection(LpexDocumentLocation s,
                                        LpexDocumentLocation e, char tokenStyle)
   {
      String style = view.elementStyle(s.element);
      if (style.length() < s.position ||
          tokenStyle != style.charAt(s.position-1))
         return 0;
      String token = view.elementText(s.element)
                         .substring(s.position-1, e.position).toUpperCase();

      if (tokenStyle == 'k' &&
          (token.equals("DO")      || token.equals("BEGIN") ||
           token.equals("PROC")    || token.equals("PROCEDURE") ||
           token.equals("PACKAGE") || token.equals("SELECT"))
          ||
          tokenStyle == 'q' &&
          (token.equals("%DO")     || token.equals("DO") ||
           token.equals("%PROC")   || token.equals("%PROCEDURE") ||
           token.equals("PROC")    || token.equals("PROCEDURE")))
         return 1;

      if (tokenStyle == 'k' &&  token.equals("END")  ||
          tokenStyle == 'q' && (token.equals("%END") || token.equals("END")))
         return -1;

      return 0;                                        // not a matchable token.
   }

   /**
    * Set <code>s</code> and <code>e</code> to the next token in doc.
    *
    * @return false if no next token in document
    */
   private boolean       nextToken(LpexDocumentLocation s,
                                   LpexDocumentLocation e)
   {
      LpexDocumentLocation l = new LpexDocumentLocation(e);
      for (int i=l.position; l.element <= view.elements(); l.element++, i=0) {
         String text = view.elementText(l.element);
         while (i < text.length() &&
                (text.charAt(i)==' ' || text.charAt(i)=='\t'))
            i++;
         if (i < text.length()) {
            l.position = i + 1;
            LpexDocumentLocation t = tokenBegin(l);
            if (t != null) {
               s.element  = t.element;
               s.position = t.position;
               t = tokenEnd(l);
               e.element  = t.element;
               e.position = t.position;
               return true;
               }
            }
         }
      return false;
   }

   /**
    * Set <code>s</code> and <code>e</code> to the previous token in doc.
    *
    * @return false if no previous token in document
    */
   private boolean       previousToken(LpexDocumentLocation s,
                                       LpexDocumentLocation e)
   {
      LpexDocumentLocation l = new LpexDocumentLocation(s);
      for (int i=l.position-2; l.element > 0; l.element--, i=-99) {
         String text = view.elementText(l.element);
         if (i == -99)
            i = text.length() - 1;
         while (i >= 0 && (text.charAt(i)==' ' || text.charAt(i)=='\t'))
            i--;
         if (i >= 0) {
            l.position = i + 1;
            LpexDocumentLocation t = tokenBegin(l);
            if (t != null) {
               s.element  = t.element;
               s.position = t.position;
               t = tokenEnd(l);
               e.element  = t.element;
               e.position = t.position;
               return true;
               }
            }
         }
      return false;
   }

   /**
    * Return true if the specified character is a token delimiter.
    */
   public boolean        isTokenDelimiter(char ch)
   {
      return TOKEN_DELIMITERS.indexOf(ch) >= 0;
   }

   /**
    * Set a class unitClass for all the elements
    * beginUnit.endLine .. endUnit that belong to a parse unit.
    *
    * @see #setParseUnitClass(int,int,long)
    */
   private void          setParseUnitClass(int endUnit, long unitClass)
   {
      setParseUnitClass(beginUnit.endLine, endUnit, unitClass);
   }

   /**
    * Set a class for all the elements that belong to a parse unit, and
    * double-link them if necessary (note that strictly for purposes of
    * incremental parsing, double-linking may not be really always necessary,
    * as evaluateXxxxxElement()s usually go back & forth between lines with
    * a SEMICOLON...).
    * Marks imbedded SQL and CICS, links ENTRY labels, and PROC headers.
    *
    * @param endUnit   first element of the parse unit
    * @param endUnit   last element of the parse unit
    * @param unitClass the class bit-mask to set, e.g., classSql
    */
   private void          setParseUnitClass(int startUnit, int endUnit,
                                           long unitClass)
   {
      // for a multi-line unit, double-link classes
      long classes = (startUnit < endUnit) ?
                         unitClass | classForwardLink : unitClass;

      // may have been called by handleEndOfFile(), don't use the stream if EOF
      int currentElement = stream.EOFSeen() ? -1 : stream.getEndLine();

      for (int i = startUnit; i <= endUnit; i++) {
         if (view.show(i))
            continue;
         if (i == endUnit)
            classes &= ~classForwardLink;
         if (i == currentElement)
            stream.setClasses(classes);
         else {
            if (unitClass == 0)   // no particular class, don't clear classSpace
               view.setElementClasses(i, view.elementClasses(i) | classes);
            else
               view.setElementClasses(i, view.elementClasses(i) &
                                              ~classSpace | classes);
            }
         classes |= classBackwardLink;
         }
   }

   /**
    * Display an error message for an element.
    */
   private void          addErrorMessage(int element, String message)
   {
      StringBuffer buffer = new StringBuffer(getLanguage());
      buffer.append('.');
      buffer.append(message);
      addMessage(element, LpexResources.message(buffer.toString()));
   }

   /**
    * Load the static tables of supported PL/I keywords.
    */
   private void          loadKeywords()
   {
      if (keywords == null)
         keywords = new Vector();
      if (optKeywords == null)
         optKeywords = new Vector();
      if (!keywords.isEmpty() || !optKeywords.isEmpty())
         return;

      String s, line, keyword, helpPanel;
      int    attribute, autoIndent, defaultAutoIndent, languageLevel;

      while ((line=nextKeyword()) != null) {
         if (line.length() > 0  && line.charAt(0) <= ' ')
            line = line.trim();
         if (line.length() == 0 || line.charAt(0) == '*')
            continue;

         StringTokenizer st = new StringTokenizer(line," \t");

         try {
            keyword   = st.nextToken();
            helpPanel = st.nextToken();

            s = st.nextToken();
            if      (s.equals("ATU")) attribute = ATU;
            else if (s.equals("FLO")) attribute = FLO;
            else if (s.equals("BIF")) attribute = BIF;
            else if (s.equals("TYF")) attribute = TYF;
            else if (s.equals("CON")) attribute = CON;
            else if (s.equals("T0"))  attribute = T0;
            else if (s.equals("T1"))  attribute = T1;
            else if (s.equals("T2"))  attribute = T2;
            else if (s.equals("SOP")) attribute = SOP;
            else if (s.equals("OPT")) attribute = OPT;
            else if (s.equals("OPS")) attribute = OPS;
            else if (s.equals("ENV")) attribute = ENV;
            else if (s.equals("ATQ")) attribute = ATQ;
            else if (s.equals("PPS")) attribute = PPS;
            else if (s.equals("*"))   attribute = ASTR;
            else
               continue; // bad, bad attribute...

            s = st.nextToken();
            autoIndent = s.equals("*") ? NO_AI : Integer.parseInt(s);

            s = st.nextToken();
            defaultAutoIndent = s.equals("*") ? NO_AI : Integer.parseInt(s);

            languageLevel = 0;
            StringTokenizer st1 = new StringTokenizer(st.nextToken(), ",");
            while (st1.hasMoreTokens()) {
               s = st1.nextToken();
               if      (s.equals("SAA"))  languageLevel |= SAA;
               else if (s.equals("SAA2")) languageLevel |= SAA2;
               else if (s.equals("OS"))   languageLevel |= OS;
               }
            if (languageLevel == 0)
               continue; // bad input for language level...
            }
         catch (Exception e) {
            //System.out.println(" Skipping bad PL/I keywords line:\n "+line);
            continue;
            }

         // add keywords to vector "keywords" or "optKeywords"
         boolean oneHelpPanel = helpPanel.equals("~");
         if (helpPanel.equals("*"))
            helpPanel = null;

         Vector v = (attribute == OPT) ? optKeywords : keywords;
         StringTokenizer st1 = new StringTokenizer(keyword, ",");
         for (int i = 0; st1.hasMoreTokens(); i++) {
            if (i == 1 && oneHelpPanel)          // ~ = 1st word in list is also
               helpPanel = s;                    //     the name of help panel
            s = st1.nextToken();
            v.addElement(new Keyword(s.toUpperCase(), attribute, languageLevel,
                                     helpPanel, autoIndent, defaultAutoIndent));
            }
         // for AI create a smaller vector (as not many kwds have AI data) -as-
         }//end "while keywords"

      sort(keywords);
      sort(optKeywords);

      //for (int i=0; i < keywords.size();
      // System.out.println(((Keyword)(keywords.elementAt(i++))).keyword));
    }

   /**
    * Retrieve the next keyword-definition line.
    * This method is being called repeatedly to set up the parser's keywords
    * tables, until it returns <code>null</code>.
    *
    * <p>The method can be extended by a subclassing parser to add custom
    * keywords.
    */
   public String         nextKeyword()
   {
      if (ii < PliKeywords.Keywords.length)             // built-in keywords
         return PliKeywords.Keywords[ii++];
      return null;
   }


   /**
    * Retrieve the name of the html help page that the parser identifies
    * as appropriate for the currently selected token.
    */
   public String         getHelpPage()
   {
      String helpPage = null;
      loadProperties();
      if (helpPages != null) {
         String token = getToken(view.documentLocation());
         if (token != null) {
            // either here, or in our getToken():                 *as*
            // go by token type (numeric->numerics help, comment->help
            //                   on comments, SQL/CICS area->sql/cics help, ..)
            //   unless it's keyword/extension/optKeyword/etc:
            // token = keywords/optKeyords[token].helpPanel /
            //         if ("~") then stays token
            // if (token == null)
            //   token = "generalHelp" or something;
            helpPage = helpPages.getProperty(token);
            }
         }
      return helpPage;
   }

   /**
    * Load in the PL/I help-mapping properties file.
    */
   private static void   loadProperties()
   {
      if (!properties_loaded) {
         helpPages = HelpCommand.loadHelpMap(HELP_PLI);
         // whether the load succeeded or not, there's no point
         // in trying again until LPEX is restarted
         properties_loaded = true;
         }
   }

   /**
    * Expand LpexCommonParser's getProperty() to substitute the arguments for
    * key PROTOKEY_EMPTY.  Argument {0} is blanks for the default left margin,
    * {1} is for the procedure name (this substitution is based on the name
    * parameter of the document).
    */
   public String         getProperty(String key)
   {
      if (!key.equals(PROTOKEY_EMPTY))
         return super.getProperty(key);

      Object arguments[] = { " ", "myProc" };

      String name = view.query("name");
      if (name != null) {
         // remove file extension and any drive letter from path part
         int i = name.lastIndexOf('.');
         if (i >= 0)
            name = name.substring(0, i);
         if ((i = name.indexOf(':')) >= 0)
            name = name.substring(i+1);

         // consider both '\\' & '/' as file separators (MS Windows does)
         name = name.replace('\\', '/');

         // extract file name from path
         i = name.lastIndexOf('/');
         if (i >= 0) {
            if (i < name.length()-1)
               arguments[1] = name.substring(i+1);
            }
         else if (name.length() > 0)
            arguments[1] = name;
         }

      if (defaultLeftMargin > 2) {
         StringBuffer margin = new StringBuffer();
         for (int i = defaultLeftMargin; i > 1; i--)
            margin.append(' ');
         arguments[0] = margin;
         }

      try {
         return MessageFormat.format(super.getProperty(key), arguments);
         }
      catch (Exception e) {
         return super.getProperty(key);
         }
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * up to the top of the file.
    * Extra lines may be included as follows:
    * - the previous non-show line is included if it has been modified or if it
    *   has a classForwardLink, or if the current line has a classBackwardLink
    *   or doesn't have classSemicolon, or if a line between the current and the
    *   previous was deleted;
    * - once an extra line is included, the one previous to it is also checked.
    * The first parse line, then, will be the end (';') of a statement (aa)
    * which was *not* affected by the edit change, potentially followed by the
    * beginning of a parse unit (xx) which *is* affected:
    *   "aa aa aa; xx"   <-- start line returned (has a SEMICOLON)
    *   "xx xx xx; xx"   <-- elem
    *   . . .
    *
    * @param  elem  main line that triggered the parse
    * @return suggested start line for parsing (may be a show line)
    */
   private int           evaluateBeginElement(int elem)
   {
      int  tryElem;          // an element preceding elem
      long classes,          // classes of current elem
           tryClasses;       //  & classes of element preceding it

      // get current line's class;  do not let a SEMICOLON (which can be just
      // *anywhere* in the line) in the starting line fool you: go deeper!
      // (this ensures we include previous line, if there is one, which is good
      // for this case too:  Enter at the end of a line in error opens a new
      // element pushing that line's message one down, we clear this error (as
      // it is now in our parse range), so it's lost!)
      for (;  elem > 1 && view.show(elem);  elem--) {}
      classes = view.elementClasses(elem) & ~classSemicolon;

      // LOOP BACKWARDS (up to top of the file)...
      while (elem > 1) {
         for (tryElem=elem-1;  tryElem > 1 && view.show(tryElem);  tryElem--) {}
         tryClasses = view.elementClasses(tryElem);               // prev line's

         // Include prev line in parse range and go on searching if *any* of:
         //   (a) current line has a BWDLINK;
         //   (b) current line doesn't have a SEMICOLON;
         //   (c) previous non-show line has a FWDLINK;
         //   (d) line(s) between previous and current line was/were deleted;
         //   (e) previous non-show line has been modified.
         if ((classes & classBackwardLink)   == 0 &&
             (classes & classSemicolon)      != 0 &&
             (tryClasses & classForwardLink) == 0
             /*&&(view.parsePending(elem) & LX_PENDING_DELETE)==0*/
             /*&&(view.parsePending(tryElem) & PARSE_PENDING_CHANGE_MASK)==0*/)
            break;

         classes = tryClasses;
         elem    = tryElem;
         }

      // if in the *PROCESS area, go to its start (or at least to its last
      // MARGINS & LANGLVL-setting *PROCESS statement, if any...)
      if (elem < firstSourceElement)
         //for (;elem>1 && (view.elementClasses(elem)&classPercent)==0; elem--);
         elem = 1;

      return elem;
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * to the bottom of the file.
    * Extra lines may be included as follows:
    * - the next line is included if it's been modified, or if it has a class
    *   classBackwardLink, or is just a SHOW line;
    *   or if the current line has a class of classForwardLink or has no SEMICOLON;
    * - once an extra line is included, the one after it is also checked.
    *
    * @param  elem  main line that triggered the parse
    * @return suggested end line for parsing (may be a show line)
    */
   private int           evaluateEndElement(int elem)
   {
      // LOOP FORWARDS (down to bottom of the file)...
      for (int first=elem, lines=view.elements();  elem < lines;  elem++) {
         if (!view.show(elem)) {
            long classes = view.elementClasses(elem);
            // if elem has a SEMICOLON ignore it, edit change may be *after* the
            // ';' (this ensures we always include the next line, if there is
            // one), even though parseElement() will expand the parse range
            // anyway if warranted...
            if (elem == first)
               classes &= ~classSemicolon;

            // Include next line in parse range and go on searching if *any* of:
            //   (-) current line is just a SHOW line (see "if" above);
            //   (a) current line has a FWDLINK;
            //   (b) current line (NB not the 1st, see above) has no SEMICOLON;
            //   (c) next line is a SHOW line (maybe a prev error in our stmt);
            //   (d) next line was modified;
            //   (e) next line has a BWDLINK.
            // Also: current line has PARSE_PENDING_NEXT_DELETED_MASK ?!? -as-
            // This, of course, will continue expanding for every line followed
            // by error (show line) messages...  And, deservedly so!? :-)
            if (((classes & classForwardLink) == 0) &&
                ((classes & classSemicolon)   != 0) &&
                (!view.show(elem+1))                &&
                ((view.parsePending(elem+1) & PARSE_PENDING_CHANGE_MASK)==0) &&
                ((view.elementClasses(elem+1) & classBackwardLink)==0))
               break;
            }
         }

      return elem;
   }

   /**
    * Expand the parse range.
    */
   private void          expandParseRange(int newEndElement)
   {
      int oldEndElement = stream.getEndElement();
      newEndElement = stream.Expand(newEndElement);

      // in incremental parsing (NB there cannot be an actual expansion in total
      // parsing!) must clear any old messages in a newly expanded parse range
      if (newEndElement > oldEndElement)
         removeMessages(oldEndElement+1, newEndElement);
   }

   /**
    * Set the format line to show columns leftMargin .. rightMargin.
    */
   private void          setPliFormatLine()
   {
      if (rightMargin > 990) {
         view.doCommand("set formatLineText");
         return;
         }

      StringBuffer t = new StringBuffer();
      for (int i = 1; i <= rightMargin; i += 10) {
         t.append((i < 91) ? "----+----" : "----+---");
         t.append(Integer.toString(i/10+1));
         }
      for (int i = 0; i < leftMargin-1; i++)
         t.setCharAt(i, ' ');
      for (int i = t.length()-1; i >= rightMargin; i--)
         t.setCharAt(i, ' ');
      view.doCommand("set formatLineText "+t.toString());
   }

   /**
    * Check whether passed-in token is a non compile-option PL/I keyword.
    *
    * @param  token  token to check
    * @return Keyword, or
    *         <code>null</code> if it is not a PL/I keyword
    */
   private Keyword       isKeyword(Token token)
   {
      return isKeyword(token, -1);
   }

   /**
    * Check whether passed-in token is a PL/I keyword of a particular attribute.
    *
    * @param  token     token to check
    * @param  attribute its attribute
    * @return Keyword, or
    *         <code>null</code> if it is not a PL/I keyword of this attribute
    */
   private Keyword       isKeyword(Token token, int attribute)
   {
      Vector v;
      if (attribute == OPT) { // 1.- OPT (compile option) keywords:
         v = optKeywords;     //  search in optKeywords
         attribute = -1;
         }
      else                    // 2.- other / any attribute:
         v = keywords;        //  search in keywords

      if (v.isEmpty() || token.beginLine != token.endLine)
         return null;

      String text = view.elementText(token.beginLine);
      if (text == null || text.length() < token.endColumn)
         return null;

      int top    = v.size() - 1,
          bottom = 0;
      int hi     = top,
          lo     = bottom,
          index  = (hi + lo)/2,
          result = 1;

      while ((result = ((Keyword)(v.elementAt(index)))
                        .compareTo(text, token.beginColumn, token.endColumn,
                                   attribute))
              != 0 && hi > lo) {
         if (result < 0)
            lo = index < top ?    index+1 : index;        // index < search word
         else
            hi = index > bottom ? index-1 : index;

         index = (hi + lo) / 2;
         }

      //boolean: return (result==0);
      return (result==0) ? (Keyword)v.elementAt(index) : null;
   }

   /**
    * Sort a Keywords vector from <code>bottom</code> to <code>top</code>.
    */
   private static void   quickSort(Vector v, int bottom, int top)
   {
      int arraySize = v.size();

      if (bottom >= 0 && bottom < arraySize &&
          top < arraySize && top >= 0 && top > bottom) {
         int ptrOne = bottom,
             ptrTwo = top;
         Keyword midElement = ((Keyword)(v.elementAt((top + bottom) / 2)));

         while (ptrOne <= ptrTwo) {
            for (; ptrOne < top &&
                   (((Keyword)(v.elementAt(ptrOne))).compareTo(midElement) < 0);
                   ptrOne++);
            for (; ptrTwo > bottom &&
                   (((Keyword)(v.elementAt(ptrTwo))).compareTo(midElement) > 0);
                   ptrTwo--);

            if (ptrOne <= ptrTwo) {
               swap(v, ptrOne, ptrTwo);
               ptrOne++;
               ptrTwo--;
               }
            }

         if (bottom < ptrTwo)
            quickSort(v, bottom, ptrTwo);

         if (ptrOne < top)
            quickSort(v, ptrOne, top);
         }
   }

   /**
    * Swap a Keywords vector's element at index a with that at index b.
    */
   private static void   swap(Vector v, int a, int b)
   {
      Object temp = v.elementAt(a);
      v.setElementAt(v.elementAt(b), a);
      v.setElementAt(temp, b);
   }

   /**
    * Quicksort given vector of Keywords.
    */
   private static void   sort(Vector v)
   {
      quickSort(v, 0, v.size() - 1);
   }

   /**
    * Set/switch lexer.
    * Imbedded SQL/CICS statements must be coded within the current margins.
    *
    * @return true = new lexer set as the active lexer;
    *                it is set in its DEFAULT lexical state
    */
   private boolean       setLexer(int newLexer)
   {
      if (newLexer == LEXER_PLI)
         pliLexer.initialize();
      else if (newLexer == LEXER_SQL) {
         if (sqlLexer == null) {
            sqlLexer = getSqlLexer(stream);
            if (sqlLexer == null)
               return false;
            }
         sqlLexer.initialize();
         }
      else {// newLexer == LEXER_CICS
         if (cicsLexer == null) {
            cicsLexer = getCicsLexer(stream);
            if (cicsLexer == null)
               return false;
            }
         cicsLexer.initialize();
         }
      activeLexer = newLexer;
      return true;
   }

   /**
    * Retrieve the SqlLexer.
    * This method constructs and returns an SqlLexer object for parsing
    * PL/I-embedded SQL statements.
    *
    * @param stream input character stream for the SQL lexer
    */
   private SqlLexer      getSqlLexer(LpexCharStream stream)
   {
      return new SqlLexer(stream, getLanguage(),
                 new SqlLexerStyles("cekbnlas"),
                 new SqlLexerClasses(view, classCode,
                                     classForwardLink, classBackwardLink,
                                     classComment, classError,
                                     0)); // we don't care about an sqlStatement
   }

   /**
    * Retrieve the CicsLexer.
    * This method constructs and returns a CicsLexer object for parsing
    * PL/I-embedded CICS statements.
    *
    * @param stream input character stream for the CICS lexer
    */
   private CicsLexer     getCicsLexer(LpexCharStream stream)
   {
      return new CicsLexer(stream, getLanguage(),
                 new CicsLexerStyles("ceknlas"),
                 new CicsLexerClasses(view, classCode,
                                     classForwardLink, classBackwardLink,
                                     classComment, classError,
                                     0)); // we don't care about a cicsStatement
   }

   /**
    * Reinitialize active lexer for the same input char stream.
    * For example, after an exception (such as EOF at end of the
    * initially-estimated parse range):  we skip the token in
    * error and continue parsing.
    */
   private void          reinitializeLexer()
   {
      if (activeLexer == LEXER_PLI)
         pliLexer.reinitialize();
      else if (activeLexer == LEXER_SQL)
         sqlLexer.reinitialize();
      else // activeLexer == LEXER_CICS
         cicsLexer.reinitialize();
   }

   /**
    * Process a token with the active lexer.
    *
    * @return LEXER_RC_OK, LEXER_RC_EOF [+LEXER_RC_MORE]
    * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_OK
    * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_EOF
    */
   private int           processToken()
   {
      int rc;
      if (activeLexer == LEXER_PLI)
         rc = pliLexer.processToken();
      else if (activeLexer == LEXER_SQL) {
         rc = sqlLexer.processToken();
         // embedded-SQL statement ended
         if ((rc & LEXER_RC_END) != 0) {
            setParseUnitClass(stream.getEndLine(), classSql);
            setLexer(LEXER_PLI);
            state = STATE_NONE;
            rc = LEXER_RC_OK;
            }
         }
      else { // activeLexer == LEXER_CICS
         rc = cicsLexer.processToken();
         // embedded-CICS statement ended
         if ((rc & LEXER_RC_END) != 0) {
            setParseUnitClass(stream.getEndLine(), classCics);
            setLexer(LEXER_PLI);
            state = STATE_NONE;
            rc = LEXER_RC_OK;
            }
         }
      return rc;
   }

   /**
    * Subclass LpexPliParserTokenManager for LPEX-specific operations.
    * LpexPliParserTokenManager.java, our token manager helper, is
    * generated by:
    *   \JavaCC\bin\javacc cc\LpexPliParser.jj
    */
   final class PliLexer extends LpexPliParserTokenManager
   {
      private long comments;             // comments state for FWDLINK & BWDLINK
      private int lastToken;                    // last token (t.kind) processed

      /**
       * Constructor.  Use LpexPliParserTokenManager's constructor, then
       * initialize any other specific information of ours.
       */
      PliLexer(LpexCharStream charstream)
      {
         super(charstream /*,DEFAULT*/);    // start up in DEFAULT lexical state
      }

      /**
       * Initialize the token manager for the same character input stream,
       * and in the default lexical state (DEFAULT).
       * This method is normally called when the parser sets / switches the
       * active lexer [back] to the PL/I lexer.
       */
      void               initialize()
      {
         ReInit(stream);
         lastToken = EOF;                   // ignore previous [SQL/CICS] tokens
         comments = 0;                      // not inside multi-line comments
      }

      /**
       * Reinitialize the token manager for the same character input stream,
       * and in the default lexical state (DEFAULT).
       * This method is normally called after a TokenMgrError exception (e.g.,
       * encountered EOF in the middle of a token / a bad character), after the
       * token in error is skipped and we continue parsing.
       */
      void               reinitialize()
      {
         ReInit(stream);
      }

      /**
       * Like JavaCC's CommonTokenAction() which is called just before
       * getNextToken() returns a matched token.
       * Comments are SPECIAL_TOKENs, and are being processed by setComment().
       * White space is SKIPped altogether.
       *
       * @return LEXER_RC_OK, LEXER_RC_EOF [+LEXER_RC_MORE]
       *
       * @see #setComment
       * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_OK
       * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_EOF
       * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_MORE
       */
      private int        processToken()
      {
         Token t = getNextToken();
         int currentToken = t.kind;   // don't fiddle with t.kind directly below

         /*=====================================================*/
         /*  (a) end of current parse range / real end of file  */
         /*=====================================================*/
         if (currentToken == EOF) {
            if (state != STATE_NONE ||
               // EXEC SQL/CICS in progress / another *PROCESS in area still
               // expected (better go on through all them *PROCESSes!) / etc.
                lastToken == LABEL)
               // may start a PROC or an ENTRY
               return LEXER_RC_EOF | LEXER_RC_MORE;
            return LEXER_RC_EOF;
            }

         /*===============================*/
         /*  (b) EXEC SQL/CICS construct  */
         /*===============================*/
         if ((state & STATE_EXEC) != 0)
            return processEXECToken(t);

         /*=====================================================*/
         /*  (c) expecting a "*PROCESS" or a *PROCESS argument  */
         /*=====================================================*/
         if ((state & STATE_PROCESS) != 0)
            return processPROCESSToken(t);

         /*===================*/
         /*  (d) end of line  */
         /*===================*/
         if (currentToken == EOL) {
            // this token is mostly ignored, and doesn't participate in parse
            // Set ccColumn style?! (in setComment() too, on EOL!?) -as-
            // /* Check the carriage control column of non xPROCESS lines.
            // (if there is any data for the column) */
            // if (ccColumn-1 < elementText.length())
            //  switch (elementText.charAt(ccColumn-1)) {
            //   case ' ' :
            //   case '-' :
            //   case '+' :
            //   case '0' :
            //   case '1' :
            //    setStyles(ccColumn,ccColumn,'?');
            //    classes = 0;
            //    break ;
            //   default :
            //    setStyles(ccColumn,ccColumn,'e');
            //    classes = classError;
            //   }
            return LEXER_RC_OK;
            }

         /*=================================================*/
         /*  (e) previous token was a potential-LABEL WORD  */
         /*=================================================*/
         if (state == STATE_MAYBELABEL) {
            if (currentToken != COLON) {   // also accept one pair of () !? *as*
               // not label, restyle the potentially-label WORD (from 'u')
               Keyword k;
               if ((k=isKeyword(beginUnit, BIF)) != null)   // built-in function
                  beginUnit.style = 'b';
               else if ((k=isKeyword(beginUnit)) != null) { // keyword
                  if (ppLabel) {
                     beginUnit.style = 'q';
                     if (k.keyword.equals("INCLUDE"))
                        beginUnit.classes |= classInclude;
                     }
                  else {
                     beginUnit.style = 'k';
                     if (k.attribute == FLO)                // - flow control
                        beginUnit.classes |= classControl;
                     }
                  }
               else
                  beginUnit.style = 'a';                    // identifier
               if (k != null && (k.languageLevel & languageLevel) == 0)
                  beginUnit.style = 'g';                    // extension
               reSetStyles(beginUnit);
               state = STATE_NONE;
               }
            }

         /*=================================*/
         /*  (f) other PL/I tokens & states */
         /*=================================*/
         char style;
         long classes = classCode;
         switch (currentToken) {
            /*------------*/
            /*  keywords  */
            /*------------*/
            case PROCESS: {
                 // not in STATE_PROCESS, so: '*'=operator, 'process'=identifier
                 String text = lpexView().elementText(t.beginLine);
                 if (text != null && text.length() >= t.endColumn) {
                    stream.setStyles(t.beginColumn, t.beginColumn, 's');  // '*'
                    stream.setStyles(t.endColumn-6, t.endColumn,   'a');  // id
                    }
                 lastToken = WORD;
                 }
                 return LEXER_RC_OK;

            /*-------------------------------------------*/
            /*  keyword / bilt-in function / identifier  */
            /*-------------------------------------------*/
            // basic keywords in all language levels
            case IF:            // "if"
            case ELSE:          // "else"
            case DO:            // "do"
            case END:           // "end"
                 if (lastToken == PERCENT)
                    style = 'q';
                 else {
                    style = 'k';
                    classes |= classControl;
                    }
                 break;

            case THEN:          // "then"
                 if (lastToken == PERCENT)
                    style = 'q';
                 else
                    style = 'k';
                 break;

            case PROC:          // "proc" / "procedure"
                 if (lastToken == PERCENT)
                    style = 'q';
                 else if (lastToken == EOF || lastToken == SEMICOLON) {
                    style = 'k';
                    classes |= classProc;
                    state = STATE_PROC;
                    firstLabel = t.endLine;    // to later link entire header...
                    }
                 else if (lastToken == LABEL) {
                    if (ppLabel) {
                       style = 'q';
                       setParseUnitClass(firstLabel, t.endLine, 0);
                       }
                    else {
                       style = 'k';
                       state = STATE_PROC;
                       }
                    }
                 else
                    style = 'a';
                 break;

            case ENTRY:         // "entry"
                 if (lastToken == EOF || lastToken == SEMICOLON) {
                    style = 'k';
                    classes |= classControl;
                    }
                 else if (lastToken == LABEL && !ppLabel) {
                    style = 'k';                         // link with its labels
                    setParseUnitClass(firstLabel, t.endLine, classControl);
                    }
                 else
                    style = 'a';
                 break;

            // other keywords
            case WORD:
                 if (lastToken == EOF   || lastToken == SEMICOLON ||
                     lastToken == LABEL || lastToken == PERCENT) {
                    state = STATE_MAYBELABEL;
                    style = 'u';
                    beginUnit.setToToken(t);
                    beginUnit.style   = style;
                    beginUnit.classes = classes;
                    if (lastToken != LABEL) {
                       firstLabel = t.endLine;
                       ppLabel = (lastToken == PERCENT);
                       }
                    }
                 else {
                    // 1.- built-in function
                    //  Invoking built-in functions & pseudovariables:
                    // name [([arg[,arg..]])]
                    // Built-ins w/o arguments must be either declared explicitly
                    // with the BUILTIN attribute, or be contextually declared by
                    // including a null arg list, e.g. ONCHAR(), in the reference;
                    // otherwise the name is not recognized as a built-in.   -as-
                    //  Invoking built-in subroutines (don't return value):
                    // CALL name [([arg[,arg..]])];
                    Keyword k;
                    if (state != STATE_DCL && (k=isKeyword(t, BIF)) != null) {
                       if ((k.languageLevel & languageLevel) != 0)
                          style = 'b'; // BIF at current language level
                       else
                          style = 'g'; // extension keyword
                       }
                    // 2.- keyword
                    else if ((k=isKeyword(t)) != null) {
                       if (lastToken == PERCENT) {
                          style = 'q';
                          if (k.keyword.equals("INCLUDE"))
                             classes |= classInclude;
                          }
                       else {
                          if ((k.languageLevel & languageLevel) != 0)
                             style = 'k';          // keyword at current lang level
                          else
                             style = 'g';          // extension keyword

                          if (k.attribute == FLO)  // a flow-control keyword
                             classes |= classControl;
                          }
                       }
                    // 3.- identifier (programmer-defined name)
                    else
                       style = 'a';
                    }
                 break;

            case DCL:           // "declare" / "dcl"
                 if (lastToken == EOF   || lastToken == SEMICOLON ||
                     lastToken == LABEL || lastToken == PERCENT) {
                    style = (lastToken == PERCENT) ? 'q' : 'k';
                    state = STATE_DCL;
                    beginUnit.setToToken(t);
                    }
                 else
                    style = 'a';
                 break;

            /*--------------*/
            /*  delimiters  */
            /*--------------*/
            case SEMICOLON:     // ';'
                 style = 's';
                 classes |= classSemicolon;
                 if (state == STATE_DCL) {
                    setParseUnitClass(t.endLine, 0);     // link entire DCL stmt
                    state = STATE_NONE;
                    }
                 else if (state == STATE_PROC) {      // link entire PROC header
                    setParseUnitClass(firstLabel, t.endLine, classProc);
                    state = STATE_NONE;
                    }
                 break;

            case PERCENT:       // '%' - %statement
                 style = 'q';
                 classes |= classPercent;
                 break;

            case QUESTION:      // '?' macro trigger char
                 style = 'r';
                 // state = ?? *as*
                 break;

            case COLON:         // ':'
                 if (state == STATE_MAYBELABEL) {
                    currentToken = LABEL;                       // link "label:"
                    setParseUnitClass(t.endLine, (ppLabel) ? 0 : classControl);
                    state = STATE_NONE;
                    }
                 // what if other prev keyword is actually a label name?! *as*
                 style = 's';
                 break;

            case LPAREN:        // '('
            case RPAREN:        // ')'
            case DOT:           // '.'
            case COMMA:         // ','
            case PT:            // "->"
            case PPT:           // "=>"
            case LPAREN_COLON:  // "(:"
            case COLON_RPAREN:  // ":)"

            /*-------------*/
            /*  operators  */
            /*-------------*/
            case ADD:           // '+'
            case SUB:           // '-'
            case DIV:           // '/'
            case STAR:          // '*'
            case EXP:           // "**"
            case EQUAL:         // '='
            case NE:            // <NOT> "="
            case LT:            // '<'
            case NL:            // <NOT> "<"
            case GE:            // ">="
            case GT:            // '>'
            case NG:            // <NOT> ">"
            case LE:            // "<="
            case NOT:           // '~'  | '^'
            case AND:           // '&'
            case OR:            // '|'
            case CAT:           // "||"
            case ADD_ASSIGN:    // "+="
            case SUB_ASSIGN:    // "-="
            case MUL_ASSIGN:    // "*="
            case DIV_ASSIGN:    // "/="
            case OR_ASSIGN:     // "|="
            case AND_ASSIGN:    // "&="
            case CAT_ASSIGN:    // "||="
            case EXP_ASSIGN:    // "**="
                 style = 's';
                 break;

            /*-----------*/
            /*  numbers  */
            /*-----------*/
            case INTEGER:
            case NUMBER:
                 style = 'n';
                 break;

            /*------------*/
            /*  literals  */
            /*------------*/
            // count accumulated length of these for errors?! -as-
            case CONT_SQUOTE:
            case CONT_DQUOTE:
                 classes |= classBackwardLink;
                 // vvv fall through...
            case SQUOTE:
            case DQUOTE:
                 style = 'l';
                 break;

            case CONT_SQUOTE_CONT:
            case CONT_DQUOTE_CONT:
                 classes |= classBackwardLink;
                 // vvv fall through...
            case SQUOTE_CONT:
            case DQUOTE_CONT:
                 style = 'l';
                 t.endColumn--; // set no style for the EOL 'char'
                 classes |= classForwardLink;
                 break;

            /*-----------------------------------*/
            /*  end-of-comment from thin air...  */
            /*-----------------------------------*/
            case EOC:      // unexpected "*/" (could make it SPECIAL_TOKEN -as-)
                 style = 'e';
                 currentToken = lastToken;       // keep parsing as if no EOC...
                 t.endColumn--;  // for extra char after "*/" that we check!="/"
                 addErrorMessage(t.endLine, "endOfComment");
                 break;

            /*---------------------------------------*/
            /*  language / system extension keyword  */
            /*---------------------------------------*/
            case EXEC:                 // imbedded SQL/CICS
                 // if a STATE in progress, stop it with ERROR/ignore EXEC? -as-
                 style = 'k';
                 classes |= classControl;   // show it in "Logical outline" view
                 state = STATE_EXEC;
                 beginUnit.setToToken(t);
                 SwitchTo(IN_EXEC);
                 break;

            case SQL:                  // SQL/CICS not preceded by EXEC...
            case CICS:
                 style = 'k'; // 'e'?!
                 state = STATE_NONE;
                 break;

            /*----------------------------------------*/
            /*  any other unmatched char / construct  */
            /*----------------------------------------*/
            case ANY_OTHER:
                 // if one-char-length token,      *as*
                 //  check for [newly] defined NOT char
                 //  check for [newly] defined OR char
                 //  check for [newly] defined NAMES char (extralingual char)
                 //  else error?!
                 style = '!';
                 break;

            /*----------------------*/
            /*  everything else...  */
            /*----------------------*/
            default:
                 lastToken = currentToken;
                 return LEXER_RC_OK;
            }//end "switch"

         lastToken = currentToken;
         if (style == 'e')
            classes |= classError;
         else if (style == 'g')
            classes |= classExtension;
         stream.setStyles(t.beginColumn, t.endColumn, style);
         stream.setClasses(classes);
         return LEXER_RC_OK;
      }

      /**
       * Process a *PROCESS statement token.
       * All the tokens of a *PROCESS statement are saved, later parsed,
       * and then set in LPEX.
       *
       * @param t a token retrieved in STATE_PROCESS[_xx]
       */
      private int        processPROCESSToken(Token t)
      {
         // advance firstSourceElement as we progress through the *PROCESS area
         if (t.endLine >= firstSourceElement)
            firstSourceElement = t.endLine + 1;

         /*--------------------------------------------------------*/
         /*  1.- expecting "*PROCESS" of a new *PROCESS statement  */
         /*--------------------------------------------------------*/
         if (state == STATE_PROCESS) {
            if (t.kind == PROCESS && t.beginColumn == 1) {
               state = STATE_PROCESS_ARG;
               buildStatement(t);              // start to gather up tokens...
               }
            else // *PROCESS area ends on any != "*PROCESS", incl. a blank line
               endProcessArea(t.endLine);
            }

         /*-------------------------------------*/
         /*  2.- handle the *PROCESS arguments  */
         /*-------------------------------------*/
         else {
            if (t.kind == EOL) {
               if (getCurLexState() == COMMENT_TO_EOL) {
                  state = STATE_PROCESS;
                  SwitchTo(DEFAULT);
                  }
               }
            else if (t.kind == SEMICOLON) {
               buildStatement(t);              // end accumulated *PROCESS stmt,
               handleStatement();              //   parse & style it
               SwitchTo(COMMENT_TO_EOL);       // comments all the way to eol
               lastToken = SEMICOLON;
               }
            else
               buildStatement(t);              // gather up the tokens...
            }

         return LEXER_RC_OK;
      }

      /**
       * Handles the EXEC constructs for embedded SQL / CICS statements.
       * These are handled by the SqlLexer's and CicsLexer's processToken(),
       * if these are defined in this parser or in subclassing parser(s);
       * the code in here is sufficient to 'tolerate' the
       *   EXEC {SQL|CICS} .. ;
       * construct.
       *
       * @param t an EXEC-construct token
       */
      private int        processEXECToken(Token t)
      {
         int  currentToken = t.kind;
         char style;
         long classes = classCode;

         /*====================================*/
         /*  A.- after EXEC SQL                */
         /*  Actually handled by SqlLexer's    */
         /*  processToken(), if available.     */
         /*====================================*/
         if (state == STATE_SQL) {
            if (currentToken == SEMICOLON) {
               style = 's';
               setParseUnitClass(t.endLine, classSql);
               state = STATE_NONE;
               SwitchTo(DEFAULT); // switch scanner to default lexical state
               }
            else // e.g., ANY_OTHER
               style = '!'; // good enough default style...
            }

         /*====================================*/
         /*  B.- after EXEC CICS               */
         /*  Actually handled by CicsLexer's   */
         /*  processToken(), where available.  */
         /*====================================*/
         else if (state == STATE_CICS) {
            if (currentToken == SEMICOLON) {
               style = 's';
               setParseUnitClass(t.endLine, classCics);
               state = STATE_NONE;
               SwitchTo(DEFAULT); // switch scanner to default lexical state
               }
            else // e.g., ANY_OTHER
               style = '!'; // good enough default style...
            }

         /*==================*/
         /*  C.- after EXEC  */
         /*==================*/
         else {
            if (currentToken == SQL) {
               style = 'k';
               state = STATE_SQL;
               setLexer(LEXER_SQL);
               }
            else if (currentToken == CICS) {
               style = 'k';
               state = STATE_CICS;
               setLexer(LEXER_CICS);
               }
            else { // e.g., ANY_OTHER
               style = 'e'; classes |= classError;
               addErrorMessage(t.endLine, "syntaxError");
               state = STATE_NONE;
               SwitchTo(DEFAULT); // switch scanner to default (PL/I) lex state
               }
            }

         lastToken = currentToken;
         stream.setStyles(t.beginColumn, t.endColumn, style);
         stream.setClasses(classes);
         return LEXER_RC_OK;
      }

      /**
       * End of the area of *PROCESS statements was encountered.  Backup to the
       * start of this element - we'll have to reparse it as regular PL/I
       * source, with the correct margins in effect.
       */
      private void       endProcessArea(int element)
      {
         SwitchTo(DEFAULT);                           // lexer -> DEFAULT state
         stream.backupToStart();                      // reparse current element
         stream.setMargins(leftMargin, rightMargin, '?');

         // redo doc & update format line if margins != what doc was parsed in
         if (leftMargin != docLeftMargin || rightMargin != docRightMargin) {
            expandParseRange(lpexView().elements());
            setPliFormatLine();
            }
         // redo entire doc if lang level != what doc was parsed in
         else if (languageLevel != docLanguageLevel)
            expandParseRange(lpexView().elements());
         else
         // if current firstSourceElement was above us, parse at least up to it
            expandParseRange(firstSourceElement);

         firstSourceElement = element;
         docLeftMargin      = leftMargin;
         docRightMargin     = rightMargin;
         docLanguageLevel   = languageLevel;
         state = STATE_NONE;
      }

      /**
       * Set style & class for comments.  Activated by \n or * / encountered
       * while in a comment SPECIAL_TOKEN (started by / *).  SPECIAL_TOKEN,
       * rather than TOKEN, is used for these, as we don't need to see the same
       * tokens in processToken() too, nor have them recorded in the parse.
       *
       * Does the real work for the extended dummy in LpexPliParser.jj.
       *
       * @param t special token
       */
      protected void     setComment(Token t)
      {
         long classes = classComment;

         // a new line, starts with comment: we're out of *PROCESSes area!? -as-
         if (state == STATE_PROCESS) {
            endProcessArea(t.endLine);
            return;
            }

         switch (getCurLexState()) {
            // 1.- "comment .. <EOL>", or "*/" after a previous "comment .."
            case IN_COMMENT:
            case IN_EXECCOMMENT:
                 if (t.kind != COMMENT_END && t.kind != EXECCOMMENT_END)
                    classes |= classForwardLink;         //  comment continues
                 if ((comments & classForwardLink) != 0) //  continuing comment:
                    classes |= classBackwardLink;        //   double-link it
                 break;
            // 2.- "comment .. <EOL>" after a previous "*PROCESS .. ;"
            case IN_COMMENT_TO_EOL:
                 state = STATE_PROCESS;
                 break;
            }
         comments = classes;

         if (t.endColumn >= t.beginColumn)
            stream.setStyles(t.beginColumn, t.endColumn, 'c');
         stream.setClasses(classes);
      }

      /**
       * Build up a statement, or just a chain of tokens which may have to be
       * restyled, one token at a time.
       */
      private void       buildStatement(Token t)
      {
         // make copy of TokenManager's Token, link it in the statement
         PliToken token = new PliToken(t);
         if (statement == null) {           // statement start, defines its type
            statement = token;
            if (token.kind == PROCESS)
               token.classes = classPercent;
            }
         else                               // just one more token in statement
            lastStatementToken.next = token;
         lastStatementToken = token;

         // set default style for the token - right now, for those handled in
         // handleStatement():  expand to share code with processToken() *as*
         token.classes |= classCode; // these are all meaty tokens (no EOL, etc)
         switch (token.kind) {
            case INTEGER:
            case NUMBER:
                 token.style = 'n';
                 break;
            case SQUOTE:
            case DQUOTE:
                 token.style = 'l';
                 break;
            case LPAREN:
            case RPAREN:
            case COMMA:
                 token.style = 's';
                 break;
            case SEMICOLON:
                 token.style = 's';
                 token.classes |= classSemicolon;
                 break;
            case PROCESS:
                 token.style = 'q';
                 break;
            // all cases with keyWORDs defined in the .jj
            case IF:
            case ELSE:
            case DO:
            case END:
            case THEN:
            case PROC:
            case ENTRY:
            case DCL:
            case EXEC:
                 if (statement.kind == PROCESS) {
                    token.kind = WORD;    // store them as WORDs
                    if (isKeyword(t, OPT) != null)
                       token.style = 'q';
                    else
                       token.style = 'a'; // not a compile-option keyword
                    }
                 break;
            case WORD:
                 if (statement.kind == PROCESS) {
                    if (isKeyword(t, OPT) != null)
                       token.style = 'q'; // *PROCESS: lang level not final yet!
                    else
                       token.style = 'a'; // not a compile-option keyword
                    }
                 else {
                    Keyword k = isKeyword(t);
                    if (k != null) {
                       if ((k.languageLevel & languageLevel) != 0)
                          token.style = 'k';    // kwd at current language level
                       else
                          token.style = 'g';    // extension kwd
                       }
                    else
                       token.style = 'a';       // identifier
                    }
                 break;
            default:
                 token.style = '!';
            }
      }

      /**
       * Parse a statement for which we gathered tokens, then set its styles.
       */
      private void       handleStatement()
      {
         if (statement == null)
            return;

         // parse the statement
         switch (statement.kind) {
            case PROCESS:
                 parsePROCESSStatement();        // *PROCESS statement
                 break;
            }

         // set statement styles
         for (PliToken t = statement; t != null; t = t.next)
            reSetStyles(t);
         statement = null;
      }

      /**
       * Parse a *PROCESS statement.
       */
      private void       parsePROCESSStatement()
      {
         parseLoop:
         for (PliToken t = statement.next; t != null && t.kind != SEMICOLON;) {
            if (t.kind == WORD) {
               /*-----------*/
               /*  MARGINS  */
               /*-----------*/
               if (t.getImage().equals("MARGINS") ||
                   t.getImage().equals("MAR")) {
                  int newLeftMargin  = leftMargin,
                      newRightMargin = rightMargin,
                      newCcColumn = ccColumn;
                  t = t.next;
                  if (t.kind != LPAREN) {
                     t = parseWordPlusParensList(t, true, 0);
                     continue;
                     }
                  t = t.next;
                  if (t.kind == INTEGER) {
                     newLeftMargin = t.getValue();
                     if (newLeftMargin < 1) {
                        t = parseWordPlusParensList(t, true, 1);
                        continue;
                        }
                     t = t.next;
                     }
                  if (t.kind == COMMA)
                     t = t.next;
                  if (t.kind == INTEGER) {
                     newRightMargin = t.getValue();
                     if (newRightMargin < newLeftMargin) {
                        t = parseWordPlusParensList(t, true, 1);
                        continue;
                        }
                     t = t.next;
                     }
                  // can't see this MARGINS-ccColumn business in docs I have!?
                  if (t.kind == COMMA)
                     t = t.next;
                  if (t.kind == INTEGER) {
                     newCcColumn = t.getValue();
                     if (newCcColumn < 0) {
                        t = parseWordPlusParensList(t, true, 1);
                        continue;
                        }
                     t = t.next;
                     }
                  else
                     newCcColumn = 0;
                  if (t.kind != RPAREN) {
                     t = parseWordPlusParensList(t, true, 1);
                     continue;
                     }

                  // set new margins (endProcessArea() may decide to reparse doc)
                  leftMargin  = newLeftMargin;
                  rightMargin = newRightMargin;
                  ccColumn = newCcColumn;

                  t = t.next;
                  }
               /*-----------*/
               /*  LANGLVL  */
               /*-----------*/
               else if (t.getImage().equals("LANGLVL")) {
                  int newLanguageLevel = 0;
                  t = t.next;
                  if (t.kind != LPAREN) {
                     t = parseWordPlusParensList(t, true, 0);
                     continue parseLoop;
                     }
                  t = t.next;
                  do {
                     if (t.kind != WORD) {
                        t = parseWordPlusParensList(t, true, 1);
                        continue parseLoop;
                        }
                     if (t.getImage().equals("SAA"))
                        newLanguageLevel |= SAA;
                     else if (t.getImage().equals("SAA2"))
                        newLanguageLevel |= SAA2;
                     else if (t.getImage().equals("OS"))
                        newLanguageLevel |= OS;
                     else if (!t.getImage().equals("NOEXT") &&
                              !t.getImage().equals("OS2")   &&
                              !t.getImage().equals("WINDOWS")) {
                        t = parseWordPlusParensList(t, true, 1);
                        continue parseLoop;
                        }
                     t = t.next;
                     if (t.kind == COMMA)
                        t = t.next;
                     } while (t.kind != RPAREN && t.kind != SEMICOLON);
                  if (t.kind != RPAREN) {
                     t = parseWordPlusParensList(t, true, 1);
                     continue parseLoop;
                     }

                  // set new level (endProcessArea() may decide to reparse doc)
                  if (newLanguageLevel == 0)
                     newLanguageLevel = defaultLanguageLevel;   // error?? -as-
                  languageLevel = newLanguageLevel;

                  t = t.next;
                  }
               /*-----------------------------------------------------------*/
               /*  another option, which we don't care about - tolerate it  */
               /*-----------------------------------------------------------*/
               else {
                  // old PL/I code looks also at NAMES, NOT, and OR!? *as*
                  t = parseWordPlusParensList(t, false, 0);
                  }
               }
            else // error - not a WORD
               t = parseWordPlusParensList(t, true, 0);
            }
      }

      /**
       * Handle one option, including any paranthesized arguments:  either in
       * its tolerable entirety, or just in order to skip rest of one in error.
       *
       * @param  t           first statement-token to handle
       * @param  error       is this an option in error?
       * @param  parensCount count of '('s open already
       * @return next statement-token to handle
       */
      private PliToken   parseWordPlusParensList(PliToken t, boolean error,
                                                 int parensCount)
      {
         if (error)
            t.style = 'e';
         //if (t.kind == LPAREN) // don't count a bad '('
         // parensCount++;

         for (t=t.next; t!=null && (t.kind!=WORD || parensCount!=0); t=t.next) {
            if (t.kind == LPAREN)
               parensCount++;
            else if (t.kind == RPAREN) {
               if (parensCount > 0)
                  parensCount--;
               else
                  t.style = 'e';
               }

            if (t.next == null && parensCount != 0)   // pending ')' at stmt end
               t.style = 'e';
            }

         return t;
      }

      /**
       * [Re-]set the styles & classes for a token.
       * The current implementation assumes that any PliToken is fully inside
       * one element (i.e., PliToken.beginLine == PliToken.endLine).
       */
      private void       reSetStyles(PliToken t)
      {
         // when LpexCharStream raised EOF, line's styles have been set in LPEX
         int currentLine = stream.EOFSeen() ? -1 : stream.getEndLine();

         if (t.style == 'e')
            t.classes |= classError;
         else if (t.style == 'g')
            t.classes |= classExtension;

         if (t.beginLine == currentLine) {  // this line is in LpexCharStream
            stream.setStyles(t.beginColumn, t.endColumn, t.style);
            if (t.classes != 0)
               stream.setClasses(t.classes);
            }
         else {                             // line's styles already in LPEX
            StringBuffer styles =
               new StringBuffer(lpexView().elementStyle(t.beginLine));
            for (int i = t.beginColumn - 1; i < t.endColumn; i++)
               styles.setCharAt(i, t.style);
            lpexView().setElementStyle(t.beginLine, styles.toString());
            if (t.classes != 0)
               lpexView().setElementClasses(t.beginLine,
                                            lpexView().elementClasses(t.beginLine)
                                                  & ~classSpace | t.classes);
            }
      }
   }

   /**
    * PL/I keyword information.
    */
   final class Keyword
   {
      String keyword;
      int    attribute;
      int    languageLevel;      // level of the PL/I language definition
      String helpPanel;
      int    autoIndent,
             defaultAutoIndent;

      Keyword(String keyword, int attribute, int languageLevel,
              String helpPanel, int autoIndent, int defaultAutoIndent)
      {
         this.keyword           = keyword;
         this.attribute         = attribute;
         this.languageLevel     = languageLevel;
         this.helpPanel         = helpPanel;
         this.autoIndent        = autoIndent;
         this.defaultAutoIndent = defaultAutoIndent;
      }

      /**
       * Compare Keywords, taking into account their attribute.
       * Used in sorting keywords[] after they're loaded in.
       */
      int      compareTo(Keyword kwd)
      {
         int rc = keyword.compareTo(kwd.keyword);
         if (rc == 0)
            rc = attribute - kwd.attribute;
         return rc;
      }

      /**
       * Use for keyword searches, does a case-insensitive compare.
       * If a positive <code>attribute</code> is supplied, the keyword searched
       * must be of that particular attribute.
       */
      int      compareTo(String text, int beginColumn, int endColumn,
                         int attribute)
      {
         int rc = keyword.compareTo(text.substring(beginColumn-1, endColumn)
                                        .toUpperCase());
         if (rc == 0 && attribute >= 0)
            rc = this.attribute - attribute;
         return rc;
      }
   }

   /**
    * PL/I token.  These tokens may be linked for one entire statement, up to
    * the ';', which is then parsed & styled.
    *
    * Note that one single JavaCC-TokenManager Token is continually recycled in
    * LPEX (see cc/Token.java), so we have to create new PliTokens in order to
    * build a statement for parsing.  Also, no image is set in Token (see core.
    * LpexCharStream.java):  here it is only set when actually queried.
    */
   final class PliToken extends Token
   {
      PliToken next;             // don't use Token's next, to avert a few casts
      char     style;
      long     classes;

      // private as it suppossedly is, it's still accessible from anywhere in
      // the PliParser, including its inner classes;  at least hide it from
      // anything outside this scope!? (JDK1.1.8) - one must use getImage()!
      private String image;

      PliToken() {}

      PliToken(Token t)
      {
         setToToken(t);
      }

      /**
       * Set the PliToken to the data in Token <code>t</code>.
       */
      void     setToToken(Token t)
      {
         kind = t.kind;
         beginLine = t.beginLine;
         beginColumn = t.beginColumn;
         endLine = t.endLine;
         endColumn = t.endColumn;

         style   = '!';
         classes = 0;
      }

      /**
       * Retrieve the token's image (in uppercase).
       */
      String   getImage()
      {
         if (image == null)
            // assume token fully inside one element
            image = lpexView().elementText(beginLine)
                              .substring(beginColumn-1,endColumn)
                              .toUpperCase();
         return image;
      }

      /**
       * Retrieve an INTEGER token's value.
       * @return <code>-1</code> if not an integer
       */
      int      getValue()
      {
         getImage();                                     // set up this.image
         StringBuffer sb = new StringBuffer();
         try {
            for (int i = 0; i < image.length(); i++)     // drop any break chars
               if (image.charAt(i) != '_')
                  sb.append(image.charAt(i));
            return Integer.parseInt(sb.toString());
            }
         catch (Exception e) {
            return -1;
            }
      }
   }
}