//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// RexxKeywords - keywords for the REXX document parser.
//----------------------------------------------------------------------------

package com.ibm.lpex.rexx;


/**
 * Keywords for the REXX document parser.
 * The table must be in ascending alphabetical order
 * (e.g., UPPERCASE keywords go before lowercase ones!).
 */
final class RexxKeywords
{
 static final String Keywords[] = {
  // REXX keywords
  "ADDRESS",
  "ARG",
  "BY",
  "CALL",
  "DIGITS",
  "DO",
  "DROP",
  "ELSE",
  "END",
  "ENGINEERING",
  "EXIT",
  "EXPOSE",
  "FOR",
  "FOREVER",
  "FORM",
  "FUZZ",
  "IF",
  "INTERPRET",
  "ITERATE",
  "LEAVE",
  "LINEIN",
  "NOP",
  "NUMERIC",
  "OFF",
  "ON",
  "OPTIONS",
  "OTHERWISE",
  "PARSE",
  "PROCEDURE",
  "PULL",
  "PUSH",
  "QUEUE",
  "RETURN",
  "SAY",
  "SCIENTIFIC",
  "SELECT",
  "SIGNAL",
  "SOURCE",
  "THEN",
  "TO",
  "TRACE",
  "UNTIL",
  "UPPER",
  "VALUE",
  "VAR",
  "VERSION",
  "WHEN",
  "WHILE",
  "WITH"
  };
}