//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// RexxParser - document parser for REXX.
//----------------------------------------------------------------------------

package com.ibm.lpex.rexx;

import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Vector;

import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexView;


//-as- add support for ObjectREXX!?

/**
 * Document parser for REXX.
 *
 * <p>Actions added by this parser: <b>errors, labels</b> for selective views
 * of the errors and the labels in the document.
 */
public class RexxParser extends LpexCommonParser
{
   private RexxLexer lexer;                    // the REXX lexer
   private static ResourceBundle resource =
      ResourceBundle.getBundle("com.ibm.lpex.rexx.Profile");

   private static Vector keywordTable;         // REXX keywords table loaded in
   private static int ii;                      // index into keywords


   /**
    * Constructor for the REXX parser.
    * Adds all of the parser specifics to the LPEX document view.
    * It initializes the view for the parser:  it sets up all the style
    * attributes, classes, etc. for the language-sensitive edit features
    * supported.
    *
    * @param lpexView the LPEX document view associated with this parser
    */
   public RexxParser(LpexView lpexView)
   {
      super(lpexView);        // LpexCommonParser constructor (view := lpexView)
      initializeParser();     // initialize LpexView with our stuff

      loadTable();                 // initialize REXX-keywords table
      lexer = new RexxLexer(view); // instantiate the lexer
   }

   /**
    * Total parse of the entire document.
    */
   public void     parseAll()
   {
      lexer.parseAll();
   }

   /**
    * Incremental parse.
    *
    * @param element the element whose committed change triggered the parse,
    *                or the element that precedes / follows a deleted block.
    *                The parser may identify other neighbouring elements that
    *                will have to be reparsed as a unit
    */
   public void     parseElement(int element)
   {
      lexer.parseElement(element);
   }

   /**
    * Returns the parser's properties profile resource bundle.
    */
   public ResourceBundle getProfile()
   {
      return resource;
   }

   /**
    * Returns "REXX", the language supported by this parser.
    *
    * @see com.ibm.lpex.core.LpexCommonParser#LANGUAGE_REXX
    */
   public String   getLanguage()
   {
      return LANGUAGE_REXX;
   }

   /**
    * Check whether passed-in keyword is a REXX keyword.
    * Override this method to add your own keywords.
    *
    * @param keyword alphanumeric to check
    */
   public boolean  isKeyword(String keyword)
   {
      if (keywordTable.isEmpty())
         return false;

      keyword = keyword.toUpperCase();

      int top    = keywordTable.size() - 1,
          bottom = 0;
      int hi     = top,
          lo     = bottom,
          index  = (hi + lo)/2,
          result = 1;

      while ((result =
             ((Keyword)(keywordTable.elementAt(index))).word.compareTo(keyword))
              != 0 && hi > lo) {
         if (result < 0)
            lo = (index < top)?    index+1 : index;        // index < search word
         else
            hi = (index > bottom)? index-1 : index;

         index = (hi + lo) / 2;
         }

      return (result == 0);
   }

   /**
    * Initialize the parser for an LPEX document view: set up style attributes
    * for the styles we need, classes, etc., and initialize the view
    * for the language-sensitive edit features supported.
    */
   private void    initializeParser()
   {
      // set attributes for the styles we use
      String tokenHighlight = getProperty("tokenHighlight");
      setStyleAttributes(tokenHighlight == null || !tokenHighlight.equals("off"));

      // view filter actions "errors" & "labels"
      LpexAction lpexAction = new LpexAction() {                // "errors"
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + RexxLexer.CLASS_ERROR);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { // could check if any errors in document...
           return true; }
         };
      view.defineAction("errors", lpexAction);

      lpexAction = new LpexAction() {                           // "labels"
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + RexxLexer.CLASS_LABEL);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("labels", lpexAction);
   }

   /**
    * Return parser's items for the popup View submenu:
    * labels, errors.
    */
   public String   getPopupViewItems()
   {
      return getLanguage() + ".popup.labels labels " +
             LpexConstants.MSG_POPUP_ERRORS + " errors";
   }

   /**
    * Define parser's style attributes.
    * @param colours true = token highlighting,
    *                false = no token highlighting
    */
   public void     setStyleAttributes(boolean colours)
   {
      String toBackground = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                        BACKGROUND_COLOR,
                                                        toBackground);
      if (colours) {
         setStyle("_",  attributes);         // Layout blanks

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("c",  attributes);         // Comment

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_ERROR,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("e",  attributes);         // Error

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("k",  attributes);         // Keyword

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_NUMERAL,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("nh", attributes);         // Number, Hexadecimal string

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_STRING,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("l",  attributes);         // Literal - quoted string

         attributes = LpexPaletteAttributes.convert("0   0 170 255 255 255",
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("as", attributes);         // Alphanumeric - variable name, Special

         attributes = LpexPaletteAttributes.convert("255 0 255 255 255 255",
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle(":",  attributes);         // Function
         }
      else                                   // drop the nice colours
         setStyle("a:s_ceknhl", attributes);
   }

   /**
    * Load the parser table with REXX keywords.
    */
   static void     loadTable()
   {
      if (keywordTable == null)
         keywordTable = new Vector();
      if (!keywordTable.isEmpty())
         return;

      String  line;
      while ((line = nextRexxKeyword()) != null) {
         line = line.trim();
         int lineLength = line.length();

         // get the first space-delimited token (word)
         int loop;
         for (loop = 0; loop < lineLength && line.charAt(loop) != ' '; loop++) {}
         String word = line.substring(0,loop);

         // get indent value, if it exists
         int indent = 0;
         if (word.length() < lineLength) {
            try {
               indent = (Integer.valueOf((line.substring(loop)).trim())).intValue();
               }
            catch (java.lang.IllegalArgumentException e) {
               indent = 0;
               }
            }

         keywordTable.addElement(new Keyword(word, indent));
         }

      // VectorSort.sort(keywordTable);
   }

   /**
    * Get next keyword line.
    */
   static String   nextRexxKeyword()
   {
      if (ii >= RexxKeywords.Keywords.length)
         return null;                                    // has read everything.
      return RexxKeywords.Keywords[ii++];
   }
}


//-as- should perhaps add more REXX keywords to the table, and all others
//     should be just alphanumerics - will make calls() faster...
final class RexxLexer
{
   static final String XDIGITS   = "0123456789ABCDEFabcdef";
   static final String OPERATOR  = "+-*/%|&=^\\><:�";   // � is caret (upper -|)
   static final String OPERATOR2 = "*/%|&=\\><:";

   // REXX classes
   static final String
      CLASS_CODE        = "code",
      CLASS_SPACE       = "space",
      CLASS_COMMENT     = "comment",
      CLASS_OPENCOMMENT = "openComment",
      CLASS_ERROR       = "error",
      CLASS_LABEL       = "label",
      CLASS_FUNCTION    = "function";

   private long
      classCode,
      classSpace,
      classComment,
      classOpenComment,
      classError,
      classLabel,
      classFunction,
      classAll;

   // styles
   private static final char
      FONT_ALPHA   = 'a',
      FONT_COMMENT = 'c',
      FONT_ERROR   = 'e',
      FONT_HEX     = 'h',
      FONT_KEYWORD = 'k',
      FONT_LABEL   = ':',
      FONT_LITERAL = 'l',
      FONT_NUMBER  = 'n',
      FONT_L_SPACE = '_',
      FONT_SPECIAL = 's',
      FONT_DEFAULT = '!';

   private String       content;
   private int          contentLength;
   private StringBuffer fonts = new StringBuffer();
   private long         rclass;

   private char     chr1;
   private int      pos,
                    backpos,
                    commentDepth;

   private boolean  symbol;

   private int      doc;                        // LPEX document ID
   private LpexView view;                       // the view of the document


   /**
    * Constructor of the REXX lexer.
    */
   RexxLexer(LpexView vpCurr)
   {
      view = vpCurr;
      doc  = view.queryInt("documentId");

      // register the classes we use
      // & get their allocated bit-masks
      classCode        = view.registerClass(CLASS_CODE);
      classSpace       = view.registerClass(CLASS_SPACE);
      classComment     = view.registerClass(CLASS_COMMENT);
      classOpenComment = view.registerClass(CLASS_OPENCOMMENT);
      classError       = view.registerClass(CLASS_ERROR);
      classLabel       = view.registerClass(CLASS_LABEL);
      classFunction    = view.registerClass(CLASS_FUNCTION);

      classAll = classCode | classSpace | classComment | classOpenComment |
                 classError | classLabel | classFunction;
   }

   /**
    * Total parse.
    */
   void            parseAll()
   {
      commentDepth = 0;

      int endElement = view.elements();
      for (int ep = 1; ep <= endElement; ep++)
         if (!view.show(ep))
            parseRexxElement(ep);
   }

   /**
    * Incremental parse.  Parse the current element;  if inside comments,
    * extend range accordingly.
    */
   void            parseElement(int element)
   {
      int startElement = element, endElement,
          totalElements = view.elements();

      /* set parsing range:
       *  - start on the earliest opencomment in the current block
       *  - finish on the first non-opencomment in the current block.
       */
      while (startElement > 1  &&
             (view.show(startElement) || inOpenComment(startElement-1)))
         startElement--;

      for (endElement = startElement + 1;  // enough to start from element? *as*
           endElement <= totalElements  &&
              (view.show(endElement) || inOpenComment(endElement));
           endElement++) {}
      if (endElement <= totalElements)
         endElement++;

      // parse all elements in the established range
      commentDepth = 0;
      for (int ep = startElement; ep < endElement; ) {
         if (!view.show(ep))
            parseRexxElement(ep);
         ep++;

         // if we are ending in a comment, extend the parse range
         if (endElement <= totalElements && ep == endElement && commentDepth > 0)
            for (endElement++;
                 endElement <= totalElements && view.show(endElement);
                 endElement++) {}
         }
   }

   /**
    * Parse one element.
    */
   private void    parseRexxElement(int element)
   {
      // extract element text content
      content = view.elementText(element);
      contentLength = content.length();
      backpos = pos = 0;

      // set the current char
      chr1 = getCharAt(pos);

      // setup the fonts buffer for this element
      fonts.setLength(contentLength);
      for (int i = 0; i < contentLength; i++)
         fonts.setCharAt(i, FONT_DEFAULT);

      // initialize some variables
      symbol = false;
      if (element == 1 &&
          (view.elementText(1).startsWith("/*") ||
           view.elementText(1).startsWith("#!/bin/rexx")))
         rclass = classLabel;
      else
         rclass = classSpace;

      // if we are still in a comment, go into the comment routine
      if (commentDepth != 0)
         rexxComment();

      // parse element one token at a time
      while (chr1 != '\0')
         rexxCharacter();

      // set the fonts & classes for the element
      view.setElementStyle(element, fonts.toString());
      if (rclass != classSpace)
         rclass &= ~classSpace;
      view.setElementClasses(element,
                             (view.elementClasses(element) & ~classAll) | rclass);

      // prevent reparsing of this element by removing from parse-pending list
      view.elementParsed(element);
   }

   /**
    * Set style passed in to the current char.
    * Step to the next character position, and set global variable chr1 to
    * the next in the content string.
    */
   private void    setFont(char font)
   {
      if (pos >= 0 && pos < contentLength)
         fonts.setCharAt(pos, font);          // set the font
      chr1 = getCharAt(++pos);                // advance to the next char
   }

   /**
    * Return the char at the given index in the content string.
    */
   private char    getCharAt(int index)
   {
      return (index >= 0 && index < contentLength)?
             content.charAt(index) : '\0';
   }

   /**
    * Return true if specified char is a REXX special char.
    */
   private boolean isRexxOperator(char chrr)
   {
      return OPERATOR.indexOf(chrr) >= 0;
   }

   /**
    * Test if specified char is a REXX special char.
    */
   private boolean isRexxOperator2(char chrr)
   {
      return OPERATOR2.indexOf(chrr) >= 0;
   }

   /**
    * Return true if specified char is a REXX symbol char.
    */
   private boolean isRexxSymbol(char chrr)
   {
      return (Character.isLetter(chrr) || Character.isDigit(chrr) ||
              chrr == '.' || chrr == '!' || chrr == '?' || chrr == '_');
   }

   /**
    * Return true if char is hex digit (0-9, a-f, A-F).
    */
   private boolean isHexDigit(char chrr)
   {
      return XDIGITS.indexOf(chrr) >= 0;
   }

   /**
    * Detect numbers (including floaters).
    */
   private void    rexxNumber()
   {
      rclass |= classCode;

      while (Character.isDigit(chr1))
         setFont(FONT_NUMBER);
      if (chr1 == '.') {
         setFont(FONT_NUMBER);
         while (Character.isDigit(chr1))
            setFont(FONT_NUMBER);
         }

      if (chr1 == 'E' || chr1 == 'e') {
         setFont(FONT_NUMBER);
         if (chr1 == '+' || chr1 == '-')
            setFont(FONT_NUMBER);
         while (Character.isDigit(chr1))
            setFont(FONT_NUMBER);
         }

      symbol = false;
   }

   /**
    * Continue quote until end of quote found or until end of line.
    */
   private void    rexxHex()
   {
      char font;
      int  oldpos = pos;
      char quote  = getCharAt(pos);          // quote is starting '

      do {                                   // scan suspected hex string
         pos++;
         chr1 = getCharAt(pos);
         } while (chr1 != quote &&
                  (isHexDigit(chr1) || Character.isWhitespace(chr1)));

      if (chr1 == quote)                     // all valid till terminating quote
         font = FONT_HEX;
      else {                                 // unidentifiable: flag as error
         rclass |= classError;
         font = FONT_ERROR;
         }

      chr1 = '!';                            // set to anything but quote!
      pos = oldpos;                          // rewind, fill in apropriate style
      while (chr1 != quote && chr1 != '\0')
         setFont(font);
      setFont(font);
      setFont(font);
   }

   /**
    * Continue literal until end of literal found or until end of line.
    */
   private void    rexxLiteral()
   {
      rclass |= classCode;

      int  oldpos = pos;
      char qchr   = getCharAt(pos);
      symbol      = false;
      setFont(FONT_LITERAL);

      while (chr1 != '\0') {
         if (chr1 == qchr) {
            setFont(FONT_LITERAL);
            if ((chr1 == 'x' || chr1 == 'X') &&
                !isRexxSymbol(getCharAt(pos+1))) {
               pos = oldpos;
               rexxHex();
               }
            else if (chr1 == '(') {
               pos = oldpos;
               setFont(FONT_KEYWORD);
               while (chr1 != qchr)
                  setFont(FONT_KEYWORD);
               setFont(FONT_KEYWORD);
               }
            return;
            }
         setFont(FONT_LITERAL);
         }

      rclass |= classError;
      pos = oldpos;
      chr1 = '!';                                   // set to anything but '\0'!
      while (chr1 != '\0')
         setFont(FONT_ERROR);
   }

   /**
    * Read the following word, see if it's a keyword or a label etc.
    */
   private void    rexxSymbol()
   {
      // set up the status
      backpos = pos;
      rclass |= classCode;

      // if this is actually a number, then call the number routine
      if (Character.isDigit(chr1) ||
          (chr1 == '.' && Character.isDigit(getCharAt(pos+1)))) {
         rexxNumber();
         if (isRexxSymbol(chr1))
            pos = backpos;
         else
            return;
         }

      // this must now be a symbol
      symbol = true;

      // is this symbol a keyword or just an ordinary symbol?
      String word  = "";
      char c = 0;

      for (int loop = 0; isRexxSymbol((c = getCharAt(pos+loop))); loop++) {
         if (loop < 30)
            word += c;
         }

      char font = FONT_ALPHA;
      if (c == '(' ||  // hmmmmmm... *as*
          ((RexxParser)view.parser()).isKeyword(word.trim()))
         font = FONT_KEYWORD;

      while (isRexxSymbol(chr1))
         setFont(font);
   }

   /**
    * Colon ':' found.  It's an error if it doesn't directly follow a symbol.
    */
   private void    rexxColon()
   {
      if (!symbol || isRexxOperator(getCharAt(pos+1))) {
         rclass |= classError;
         setFont(FONT_ERROR);
         while (isRexxOperator(chr1))
            setFont(FONT_ERROR);
         return;
         }

      /* ... else we've just found a label! */
      symbol = false;
      rclass |= classLabel;
      pos = backpos;
      chr1 = '!';
      while (chr1 != ':')
         setFont(FONT_LABEL);
      setFont(FONT_LABEL);
   }

   /**
    * Continue comment until the end-of-comments found, or until end of line,
    * whichever comes first.
    */
   private void    rexxComment()
   {
      // if this is not an open-comment, and we are not in a comment,
      // then this must be the symbol '/'   [*as* THIS STILL NEEDED?!]
      if (commentDepth == 0 && getCharAt(pos+1) != '*') {
         setFont(FONT_SPECIAL);
         rclass |= classCode;
         return;
         }

      // we are now definitely in a comment, so set comment class
      rclass |= classComment | classOpenComment;

      // now repeat char-by-char until end of comment, or end of element...
      boolean sameLine = false;
      do {
         if (chr1 == '\0')                                  // end of element
            return;

         //if (chr1 == '-' && getCharAt(pos+1) == '-') {    // IGNORE insider "--"
         // while (chr1 != '\0')
         //  setFont(FONT_COMMENT);
         // return;
         // }

         if (chr1 == '/' && getCharAt(pos+1) == '*') {      // extra "/*"
            commentDepth++;
            setFont(FONT_COMMENT);
            sameLine = true;
            }

         else if (chr1 == '*' && getCharAt(pos+1) == '/') { // ending "*/"
            commentDepth--;
            setFont(FONT_COMMENT);
            if (sameLine) {
               rclass  &= ~classOpenComment;
               sameLine = false;
               }
            }

         if (commentDepth > 0)
            rclass |= classOpenComment;

         setFont(FONT_COMMENT);
         } while (commentDepth != 0);
   }

   /**
    * Detect REXX special characters + % ? etc.
    */
   private void    rexxChar()
   {
      char font;
      char chr2 = getCharAt(pos+1);

      if (chr1 == '-' && chr2 == '-') {              // (a) --ANSI's LineComment
         rclass |= classComment;
         while (chr1 != '\0')
            setFont(FONT_COMMENT);
         return;
         }

      if (isRexxOperator(chr1)) {                   // (b) REXX special char
         char chr3 = '\0', chr4 = '\0';

         if (chr2 != '\0')
            chr3 = getCharAt(pos+2);
         if (chr3 != '\0')
            chr4 = getCharAt(pos+3);

         font = FONT_SPECIAL;
         if (isRexxOperator2(chr2)) {
            switch (chr1) {
               case '/':
                  if (chr2 == '*') {
                     rexxComment();
                     return;
                     }
                  else if (chr2 != '/' || isRexxOperator2(chr3))
                     font = FONT_ERROR;
                  break;

               case '\\': case '^': case '�':        // NB � is caret (upper -|)
                  if (chr2 == '<' || chr2 == '>' || chr2 == '=') {
                     if (isRexxOperator2(chr3)) {
                        if (chr3 != chr2 || isRexxOperator2(chr4))
                           font = FONT_ERROR;
                        }
                     }
                  else
                     font = FONT_ERROR;
                  break;

               case '%': case '+': case '-':
                  font = FONT_ERROR;
                  break;

               case '|': case '*': case '&':
                  if (chr2 != chr1 || isRexxOperator2(chr3))
                     font = FONT_ERROR;
                  break;

               case '=':
                  if (chr2 != '=' && chr2 != '\\' && chr2 != '^' && chr2 != '�')
                     font = FONT_ERROR;
                  if (isRexxOperator2(chr3))
                     font = FONT_ERROR;
                  break;

               case '>': case '<':
                  if (chr2 == chr1 && chr3 == '=') {
                     if (isRexxOperator2(chr4))
                        font = FONT_ERROR;
                     }
                  else if (chr2 == '<' || chr2 == '>' || chr2 == '=') {
                     if (isRexxOperator2(chr3))
                        font = FONT_ERROR;
                     }
                  else
                     font = FONT_ERROR;
                  break;

               default:
                  break;
               }
            }
         }

      else if (pos==0 && chr1=='#' && chr2=='!') {   // (c) allow "#!/bin/rexx"
         rclass |= classComment;
         while (chr1 != '\0')
            setFont(FONT_COMMENT);
         return;
         }

      else {                                         // (d) else, too bad...
         font = FONT_ERROR;
         setFont(FONT_ERROR);
         }

      symbol = false;
      rclass |= classCode;
      if (font == FONT_ERROR)
         rclass |= classError;

      while (isRexxOperator(chr1))
         setFont(font);
   }

   /**
    * Set style and classes for the current REXX character.
    */
   private void    rexxCharacter()
   {
      if (isRexxSymbol(chr1)) {
         rexxSymbol();
         return;
         }

      switch(chr1) {
         case ':':
            rexxColon();
            break;

         case '\'': case '"':
            rexxLiteral();
            break;

         case ' ': case '\t': case '\f':
            setFont(FONT_L_SPACE);
            break;

         case '0': case '1': case '2': case '3': case '4':
         case '5': case '6': case '7': case '8': case '9':
            rexxNumber();
            break;

         case '.':
            rclass |= classCode;
            if (Character.isDigit(getCharAt(pos+1)))
               rexxNumber();
            else
               setFont(FONT_SPECIAL);
            break;

         case '(': case ')': case ',': case ';':
            setFont(FONT_SPECIAL);
            rclass |= classCode;
            break;

         default:
            rexxChar();
            break;
         }
   }

   /**
    * Are we inside an open comment on this element?
    */
   private boolean inOpenComment(int element)
   {
      return (element > 0) &&
             ((view.elementClasses(element) & classOpenComment) != 0);
   }


// /**
//  * Return code source units (REXX labels) in this file.
//  * The main program and all the labels "xxx:" in the file are added to vector
//  * <code>labels</code>.
//  */
// Vector labels(Vector labels)
// {
//    // should handle better several labels on same code!? *as*
//
//    if (labels == null)
//       labels = new Vector();
//
//    String CODE = "ahklns"; // code-stuff styles
//    int i, j;
//    for (int element = 1; element <= view.elements(); element++) {
//       //if (view.show(element)) continue;
//       long classes = view.elementClasses(element);
//       if ((classes & classLabel) != 0) {
//          String text  = view.elementText(element);
//          String style = view.elementStyle(element);
//          for (i = 0;  (i=style.indexOf(FONT_LABEL,i)) >=0;  i = j+1) {
//             if (labels.isEmpty())        // any code before this first label?
//                for (int c = 0; c < i; c++) {
//                   if (CODE.indexOf(style.charAt(c)) >= 0) {
//                      labels.addElement(new LpexSourceUnit("",doc,element,1));
//                      break;
//                      }
//                   }
//             for (j=i; style.charAt(j) ==':' && text.charAt(j) !=':'; j++) {}
//             labels.addElement(new LpexSourceUnit(text.substring(i,j).trim(),
//                                                  doc, element, i+1));
//             }
//          }
//       // code elements before labels
//       else if (labels.isEmpty() && (classes & classCode) != 0)
//          labels.addElement(new LpexSourceUnit("", doc, element, 1));
//       }
//
//    // main program body - use source file name
//    if (!labels.isEmpty() &&
//        ((LpexSourceUnit)labels.firstElement()).name.length() == 0) {
//       String name = view.query("name");
//       if (name == null)
//          name = "Untitled Document " + doc;
//       else if ((i = name.lastIndexOf(System.getProperty("file.separator"))) >=0)
//          name = name.substring(i + 1);
//       ((LpexSourceUnit)labels.firstElement()).name = name;
//       }
//
//    return labels;
// }
//
// /**
//  * Add the calls in this file to a vector of code source units.
//  */
// void calls(Vector labels)
// {
//    if (labels == null || labels.isEmpty())
//       return;                                            // no labels at all.
//
//    LpexSourceUnit su = (LpexSourceUnit)labels.firstElement(), su2;
//    int li = 1;                                 // next index to use in labels
//
//    int i, j;
//    for (int element = 1; element <= view.elements(); element++) {
//       //if (view.show(element)) continue;
//       if ((view.elementClasses(element) & classCode) != 0) {
//          String text  = view.elementText(element);
//          String style = view.elementStyle(element);
//          for (i = -1; ++i < style.length(); ) {
//             // look for keywords & alphanumerics
//             if (style.charAt(i) == 'k' || style.charAt(i) == 'a') {
//                for (j = i+1;
//                     j < style.length() && style.charAt(j) == style.charAt(i);
//                     j++) {}
//                if (isLabel(labels, text.substring(i,j))) {
//                   while (li < labels.size() &&
//                          ((su2 = (LpexSourceUnit)labels.elementAt(li)).element <
//                                                  element  ||
//                           (su2.element == element && su2.position < i+1))) {
//                      su = su2;
//                      li++;
//                      }
//                   addCall(su, new LpexSourceUnit(text.substring(i,j),
//                                                  doc, element, i+1));
//                   }
//                i = j-1;
//                }
//             }
//          }
//       }
// }
//
// /**
//  * Check if keyword / alphanumeric is a label in the code source units
//  * vector.
//  */
// private boolean isLabel(Vector labels, String id)
// {
//    for (int i = 0;  i < labels.size(); i++)
//       if (id.equals(((LpexSourceUnit)labels.elementAt(i)).name))
//          return true;
//    return false;
// }
//
// /**
//  * Add a new source unit to a label's calls.
//  */
// private void addCall(LpexSourceUnit caller, LpexSourceUnit su)
// {
//    if (caller.subunits == null)
//       caller.subunits = new Vector();
//    for (int i = 0; i < caller.subunits.size(); i++)
//       if (((LpexSourceUnit)caller.subunits.elementAt(i)).name.equals(su.name))
//          return; // already in the list
//    caller.subunits.addElement(su);
// }
}


/**
 * REXX keyword & its indent value.
 */
final class Keyword
{
   String word;    // language keyword
   int    indent;  // autoindent value

   Keyword(String word, int indent)
   {
      this.word   = word;
      this.indent = indent;
   }
}