//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// JclParser - document parser for JCL.
//----------------------------------------------------------------------------

package com.ibm.lpex.jcl;

import java.util.Properties;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import com.ibm.lpex.core.HelpCommand;
import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;


/**
 * Document parser for MVS JCL.
 *
 * <p>The system-specific options used by JclParser are
 * <b>JES3</b> and <b>ESA</b>.
 *
 * <p>Actions added by this parser:  <b>jobs, execs, dds, procs, errors</b>
 * for selective views of the cards and errors in the document.
 *
 * @see #getJclOptions
 */
public class JclParser extends LpexCommonParser
{
   // whether the help index has been loaded, and the index .properties file
   private static boolean properties_loaded;
   private static Properties helpPages;

   private static ResourceBundle resource =
                  ResourceBundle.getBundle("com.ibm.lpex.jcl.Profile");

   /**
    * @see #getJclOptions
    */
   public static final int
      OPTION_JES2 = 0x00000001,
      OPTION_JES3 = 0x00000002,
      OPTION_ESA  = 0x00000004,
      OPTION_XA   = 0x00000008;

   /**
    * LPEX classes we use.
    * Each card image is equivalent to one LPEX element.  The basic element
    * classes are:  "jcl", "comment", "command", "control" and "instream".
    * "jes2" and "jes3" are added for command or control statements.
    * Class "proc" is set for JCL contained in an in-line proc.
    */
   private static final String
      CLASS_JCL      = "jcl",      // JCL statements:
      CLASS_COMMENT  = "comment",  //   Comment statement
      CLASS_COMMAND  = "command",
      CLASS_CONTROL  = "control",
      CLASS_JOB      = "job",      //   JOB statement
      CLASS_EXEC     = "exec",     //   EXEC statement
      CLASS_DD       = "dd",       //   DD (data definition) statement
      CLASS_DLM      = "dlm",      //   Delimiter statement
      CLASS_NULL     = "null",     //   Null statement
      CLASS_PROC     = "proc",     //   PROC statement
      CLASS_PEND     = "pend",     //   PEND statement
      CLASS_OUTPUT   = "output",   //   OUTPUT statement
      CLASS_JES2     = "jes2",     //   JES2 command or control statement
      CLASS_JES3     = "jes3",     //   JES3 command or control statement
      CLASS_XMIT     = "xmit",     //   XMIT statement
      CLASS_CNTL     = "cntl",     //   CNTL statement
      CLASS_ENDCNTL  = "endcntl",  //   ENDCNTL statement
      CLASS_INSTREAM = "instream",
      CLASS_FWDLINK  = "fwdLink",
      CLASS_BWDLINK  = "bwdLink",
      CLASS_ERROR    = "error",
      CLASS_LIB      = "lib",      //   JCLLIB and INCLUDE statements (ESA)
      CLASS_COND     = "cond",     //   IF, ELSE, ENDIF and SET statements (ESA)
      CLASS_SPLIT    = "split";    //   ESA split quoted parameter

   // & the corresponding class bits for *this* view (parser instance)
   private long
      classJcl,
      classComment,
      classCommand,
      classControl,
      classJob,
      classExec,
      classDd,
      classDlm,
      classNull,
      classProc,
      classPend,
      classOutput,
      classJes2,
      classJes3,
      classXmit,
      classCntl,
      classEndcntl,
      classInstream,
      classFwdlink,
      classBwdlink,
      classError,
      classLib,
      classCond,
      classSplit,
      classAll;

   // the styles we use
   private static final char
      FONT_BLANK        = '_',
      FONT_PREFIX       = '/',
      FONT_COMMENT      = 'c',
      FONT_SEQNO        = 'z',
      FONT_JOBNAME      = 'j',
      FONT_STEPNAME     = 's',
      FONT_PROCNAME     = 'r',
      FONT_PROCSTEPNAME = 'p',
      FONT_DDNAME       = 'd',
      FONT_OPERATION    = 'o',
      FONT_KEYWORD      = 'k',
      FONT_SUBKEYWORD   = 'b',
      FONT_KEYWORDSYM   = 'y',
      FONT_SYMBOLIC     = 'x',
      FONT_VALUE        = 'v',
      FONT_INSTREAM     = 'i',
      FONT_COMMAND      = 'n',
      FONT_CONTROL      = 'l',
      FONT_QUOTEDSTRING = 'q',
      FONT_DELIMITER    = '*',
      FONT_LEFTPAREN    = '(',
      FONT_RIGHTPAREN   = ')',
      FONT_COMMA        = ',',
      FONT_EQUALSIGN    = '=',
      FONT_PERIOD       = '.',
      FONT_ERROR        = 'e';

   // basic JCL card fonts
   private static final String JCL_BASICSTYLE =
    "//______________________________________________________________________zzzzzzzz";
   /*12345678901234567890123456789012345678901234567890123456789012345678901234567890*/

   // default data delimiter
   private static final String DEFAULT_DLM = "/*";

   // DD key options
   // There are 94 of these.  Keep order for other cross-ref, etc., tables!
   private static final int
      DDKEY_STAR    = 1, DDKEY_DATA     = 2, DDKEY_DUMMY    = 3, DDKEY_DYNAM    = 4,
      DDKEY_DISP    = 5, DDKEY_DSN      = 6, DDKEY_DSNAME   = 7, DDKEY_LIKE     = 8,
      DDKEY_SYSOUT  = 9, DDKEY_UNIT     =10, DDKEY_VOL      =11, DDKEY_VOLUME   =12,
      DDKEY_SPACE   =13, DDKEY_DDNAME   =14, DDKEY_LABEL    =15, DDKEY_EXPDT    =16,
      DDKEY_RETPD   =17, DDKEY_DLM      =18, DDKEY_DCB      =19, DDKEY_LRECL    =20,
      DDKEY_BLKSIZE =21, DDKEY_BUFL     =22, DDKEY_RECFM    =23, DDKEY_DSORG    =24,
      DDKEY_TERM    =25, DDKEY_ACCODE   =26, DDKEY_AVGREC   =27, DDKEY_BURST    =28,
      DDKEY_CHARS   =29, DDKEY_CHKPT    =30, DDKEY_CNTL     =31, DDKEY_OUTPUT   =32,
      DDKEY_REFDD   =33, DDKEY_DATACLAS =34, DDKEY_MGMTCLAS =35, DDKEY_STORCLAS =36,
      DDKEY_DSID    =37, DDKEY_FCB      =38, DDKEY_FLASH    =39, DDKEY_FREE     =40,
      DDKEY_HOLD    =41, DDKEY_MODIFY   =42, DDKEY_MSVGP    =43, DDKEY_OUTLIM   =44,
      DDKEY_BUFIN   =45, DDKEY_INTVL    =46, DDKEY_LIMCT    =47, DDKEY_NTM      =48,
      DDKEY_PROTECT =49, DDKEY_RECORG   =50, DDKEY_SUBSYS   =51, DDKEY_UCS      =52,
      DDKEY_BFALN   =53, DDKEY_BFTEK    =54, DDKEY_CPRI     =55, DDKEY_DEN      =56,
      DDKEY_PRTSP   =57, DDKEY_DIAGNS   =58, DDKEY_BUFMAX   =59, DDKEY_BUFNO    =60,
      DDKEY_GNCP    =61, DDKEY_BUFOUT   =62, DDKEY_BUFOFF   =63, DDKEY_BUFSIZE  =64,
      DDKEY_CYLOFL  =65, DDKEY_EROPT    =66, DDKEY_FUNC     =67, DDKEY_IPLTXID  =68,
      DDKEY_MODE    =69, DDKEY_NCP      =70, DDKEY_OPTCD    =71, DDKEY_PCI      =72,
      DDKEY_RESERVE =73, DDKEY_KEYLEN   =74, DDKEY_RKP      =75, DDKEY_KEYOFF   =76,
      DDKEY_STACK   =77, DDKEY_THRESH   =78, DDKEY_TRTCH    =79, DDKEY_DEST     =80,
      DDKEY_QNAME   =81, DDKEY_SECMODEL =82, DDKEY_AMP      =83, DDKEY_COPIES   =84,
      DDKEY_SEGMENT =85, DDKEY_SPIN     =86,
      // @as added 3/99:
                                             DDKEY_PATH     =87, DDKEY_PATHDISP =88,
      DDKEY_PATHMODE=89, DDKEY_PATHOPTS =90, DDKEY_DSNTYPE  =91, DDKEY_FILEDATA =92,
      DDKEY_LGSTREAM=93, DDKEY_RLS      =94;

   private static final String DDKeyTable[] = {
      "*"       , /*DDKEY_STAR     */        "DATA"    , /*DDKEY_DATA     */
      "DUMMY"   , /*DDKEY_DUMMY    */        "DYNAM"   , /*DDKEY_DYNAM    */
      "DISP"    , /*DDKEY_DISP     */        "DSN"     , /*DDKEY_DSN      */
      "DSNAME"  , /*DDKEY_DSNAME   */        "LIKE"    , /*DDKEY_LIKE     */
      "SYSOUT"  , /*DDKEY_SYSOUT   */        "UNIT"    , /*DDKEY_UNIT     */
      "VOL"     , /*DDKEY_VOL      */        "VOLUME"  , /*DDKEY_VOLUME   */
      "SPACE"   , /*DDKEY_SPACE    */        "DDNAME"  , /*DDKEY_DDNAME   */
      "LABEL"   , /*DDKEY_LABEL    */        "EXPDT"   , /*DDKEY_EXPDT    */
      "RETPD"   , /*DDKEY_RETPD    */        "DLM"     , /*DDKEY_DLM      */
      "DCB"     , /*DDKEY_DCB      */        "LRECL"   , /*DDKEY_LRECL    */
      "BLKSIZE" , /*DDKEY_BLKSIZE  */        "BUFL"    , /*DDKEY_BUFL     */
      "RECFM"   , /*DDKEY_RECFM    */        "DSORG"   , /*DDKEY_DSORG    */
      "TERM"    , /*DDKEY_TERM     */        "ACCODE"  , /*DDKEY_ACCODE   */
      "AVGREC"  , /*DDKEY_AVGREC   */        "BURST"   , /*DDKEY_BURST    */
      "CHARS"   , /*DDKEY_CHARS    */        "CHKPT"   , /*DDKEY_CHKPT    */
      "CNTL"    , /*DDKEY_CNTL     */        "OUTPUT"  , /*DDKEY_OUTPUT   */
      "REFDD"   , /*DDKEY_REFDD    */        "DATACLAS", /*DDKEY_DATACLAS */
      "MGMTCLAS", /*DDKEY_MGMTCLAS */        "STORCLAS", /*DDKEY_STORCLAS */
      "DSID"    , /*DDKEY_DSID     */        "FCB"     , /*DDKEY_FCB      */
      "FLASH"   , /*DDKEY_FLASH    */        "FREE"    , /*DDKEY_FREE     */
      "HOLD"    , /*DDKEY_HOLD     */        "MODIFY"  , /*DDKEY_MODIFY   */
      "MSVGP"   , /*DDKEY_MSVGP    */        "OUTLIM"  , /*DDKEY_OUTLIM   */
      "BUFIN"   , /*DDKEY_BUFIN    */        "INTVL"   , /*DDKEY_INTVL    */
      "LIMCT"   , /*DDKEY_LIMCT    */        "NTM"     , /*DDKEY_NTM      */
      "PROTECT" , /*DDKEY_PROTECT  */        "RECORG"  , /*DDKEY_RECORG   */
      "SUBSYS"  , /*DDKEY_SUBSYS   */        "UCS"     , /*DDKEY_UCS      */
      "BFALN"   , /*DDKEY_BFALN    */        "BFTEK"   , /*DDKEY_BFTEK    */
      "CPRI"    , /*DDKEY_CPRI     */        "DEN"     , /*DDKEY_DEN      */
      "PRTSP"   , /*DDKEY_PRTSP    */        "DIAGNS"  , /*DDKEY_DIAGNS   */
      "BUFMAX"  , /*DDKEY_BUFMAX   */        "BUFNO"   , /*DDKEY_BUFNO    */
      "GNCP"    , /*DDKEY_GNCP     */        "BUFOUT"  , /*DDKEY_BUFOUT   */
      "BUFOFF"  , /*DDKEY_BUFOFF   */        "BUFSIZE" , /*DDKEY_BUFSIZE  */
      "CYLOFL"  , /*DDKEY_CYLOFL   */        "EROPT"   , /*DDKEY_EROPT    */
      "FUNC"    , /*DDKEY_FUNC     */        "IPLTXID" , /*DDKEY_IPLTXID  */
      "MODE"    , /*DDKEY_MODE     */        "NCP"     , /*DDKEY_NCP      */
      "OPTCD"   , /*DDKEY_OPTCD    */        "PCI"     , /*DDKEY_PCI      */
      "RESERVE" , /*DDKEY_RESERVE  */        "KEYLEN"  , /*DDKEY_KEYLEN   */
      "RKP"     , /*DDKEY_RKP      */        "KEYOFF"  , /*DDKEY_KEYOFF   */
      "STACK"   , /*DDKEY_STACK    */        "THRESH"  , /*DDKEY_THRESH   */
      "TRTCH"   , /*DDKEY_TRTCH    */        "DEST"    , /*DDKEY_DEST     */
      "QNAME"   , /*DDKEY_QNAME    */        "SECMODEL", /*DDKEY_SECMODEL */
      "AMP"     , /*DDKEY_AMP      */        "COPIES"  , /*DDKEY_COPIES   */
      "SEGMENT" , /*DDKEY_SEGMENT  */        "SPIN"    , /*DDKEY_SPIN     */
      // @as added 3/99:
      "PATH"    , /*DDKEY_PATH     */        "PATHDISP", /*DDKEY_PATHDISP */
      "PATHMODE", /*DDKEY_PATHMODE */        "PATHOPTS", /*DDKEY_PATHOPTS */
      "DSNTYPE" , /*DDKEY_DSNTYPE  */        "FILEDATA", /*DDKEY_FILEDATA */
      "LGSTREAM", /*DDKEY_LGSTREAM */        "RLS"       /*DDKEY_RLS      */
      };


   // keytbl & conf_bits for mux_test(): test for mutually exclusive DD keywords (N/U right now...)
   //  -"-   & lvl_mask & mxp_mask in dd_lvl_test(): test for paren & parm count
   // NB ZERO-origin index is used to access this table!
   private static final String keytbl =
      "         "  +
      "*        "  +  "AMP      "  +  "BURST    "  +  "CHARS    "  +  //  1 ..  4
      "CHKPT    "  +  "COPIES   "  +  "DATA     "  +  "DCB      "  +  //  5 ..  8
      "DDNAME   "  +  "DEST     "  +  "DISP     "  +  "DLM      "  +  //  9 .. 12
      "DSID     "  +  "DSNAME   "  +  "DUMMY    "  +  "DYNAM    "  +  // 13 .. 16
      "FCB      "  +  "FLASH    "  +  "FREE     "  +  "HOLD     "  +  // 17 .. 20
      "LABEL    "  +  "MODIFY   "  +  "MSVGP    "  +  "OUTLIM   "  +  // 21 .. 24
      "OUTPUT   "  +  "PROTECT  "  +  "QNAME    "  +  "SPACE    "  +  // 25 .. 28
      "SUBSYS   "  +  "SYSOUT   "  +  "TERM     "  +  "UCS      "  +  // 29 .. 32
      "UNIT     "  +  "VOLUME   "  +  "ACCODE   "  +  "CNTL     "  +  // 33 .. 36
      "AVGREC   "  +  "DATACLAS "  +  "EXPDT    "  +  "KEYLEN   "  +  // 37 .. 40
      "KEYOFF   "  +  "LIKE     "  +  "LRECL    "  +  "MGMTCLAS "  +  // 41 .. 44
      "RECFM    "  +  "RECORG   "  +  "REFDD    "  +  "RETPD    "  +  // 45 .. 48
      "SECMODEL "  +  "STORCLAS "  +  "BFALN    "  +  "BFTEK    "  +  // 49 .. 52
      "BLKSIZE  "  +  "BUFIN    "  +  "BUFL     "  +  "BUFMAX   "  +  // 53 .. 56
      "BUFNO    "  +  "BUFOFF   "  +  "BUFOUT   "  +  "BUFSIZE  "  +  // 57 .. 60
      "CPRI     "  +  "CYLOFL   "  +  "DEN      "  +  "DIAGNS   "  +  // 61 .. 64
      "DSORG    "  +  "EROPT    "  +  "FUNC     "  +  "GNCP     "  +  // 65 .. 68
      "INTVL    "  +  "IPLTXID  "  +  "LIMCT    "  +  "MODE     "  +  // 69 .. 72
      "NCP      "  +  "NTM      "  +  "OPTCD    "  +  "PCI      "  +  // 73 .. 76
      "PRTSP    "  +  "RESERVE  "  +  "RKP      "  +  "STACK    "  +  // 77 .. 80
      "THRESH   "  +  "TRTCH    "  +  "SEGMENT  "  +  "SPIN     "  +  // 81 .. 84
      // @as added 3/99:
      "PATH     "  +  "PATHDISP "  +  "PATHMODE "  +  "PATHOPTS "  +  // 85 .. 88
      "DSNTYPE  "  +  "FILEDATA "  +  "LGSTREAM "  +  "RLS      ";    // 89 .. 92

   // // N/U right now... *as*
   // const char conf_bits[96+1][96+1] = {
   // /*4        5         6         7         8
   //            1         2         3         4
   //   123456789012345678901234567890123456789012345678    */
   //
   // ("1111111011100111111111111111111110010000" ||             // 1 *
   //  "000000000000000000000000000000000000000000000000"),
   // ("1111011100010001110001011011011100010000" ||             // 2 AMP
   //  "000000000000000000000000000000000000000000000000"),
   // ("1110001010111101000010100110000001010000" ||             // 3 BURST
   //  "000000000000000000000000000000000000000000000000"),
   // ("1101001010111101000010100110000001010000" ||             // 4 CHARS
   //  "000000000000000000000000000000000000000000000000"),
   // ("1000101010110001000000011010010000010000" ||             // 5 CHKPT
   //  "000000000000000000000000000000000000000000000000"),
   // ("1100011010110101000010100010100001010000" ||             // 6 COPIES
   //  "000000000000000000000000000000000000000000000000"),
   // ("1111111011100111111111111111111110010000" ||             // 7 DATA
   //  "000000000000000000000000000000000000000000000000"),
   // ("0100000100000001000000000000000000010000" ||             // 8 DCB
   //  "000000000000000000000000000000000000000000000000"),
   // ("1011111011111111111111111111111111010000" ||             // 9 DDNAME
   //  "000000000000000000000000000000000000000000000000"),
   // ("1000001011010001000000000010100000010000" ||             // 10 DEST
   //  "000000000000000000000000000000000000000000000000"),
   // ("1011111010110001010001011010010000010000" ||             // 11 DISP
   //  "000000000000000000000000000000000000000000000000"),
   // ("0111110011110111111111111111111111010000" ||             // 12 DLM
   //  "000000000000000000000000000000000000000000000000"),
   // ("0011000010001001010001100010000000010000" ||             // 13 DSID
   //  "000000000000000000000000000000000000000000000000"),
   // ("1011011010010101010001011010010000010000" ||             // 14 DSNAME
   //  "000000000000000000000000000000000000000000000000"),
   // ("1000001010010011000000000010000000010000" ||             // 15 DUMMY
   //  "000000000000000000000000000000000000000000000000"),
   // ("1111111111111111111111111111111111010000" ||             // 16 DYNAM
   //  "000000000000000000000000000000000000000000000000"),
   // ("1100001010010001100000000110100000010000" ||             // 17 FCB
   //  "000000000000000000000000000000000000000000000000"),
   // ("1100001010111101010010100110000001010000" ||             // 18 FLASH
   //  "000000000000000000000000000000000000000000000000"),
   // ("1000001010010001001000000010000000010000" ||             // 19 FREE
   //  "000000000000000000000000000000000000000000000000"),
   // ("1000001010010001000100000010000000010000" ||             // 20 HOLD
   //  "000000000000000000000000000000000000000000000000"),
   // ("1011011010010001010011011010010000010000" ||             // 21 LABEL
   //  "000000000000000000000000000000000000000000000000"),
   // ("1100001010111101000011100110000001010000" ||             // 22 MODIFY
   //  "000000000000000000000000000000000000000000000000"),
   // ("1011011010011001010001111010010001010000" ||             // 23 MSVGP
   //  "000000000000000000000000000000000000000000000000"),
   // ("1100101010110101000010110111100011010000" ||             // 24 OUTLIM
   //  "000000000000000000000000000000000000000000000000"),
   // ("1100101010110101000010101111100011010000" ||             // 25 OUTPUT
   //  "000000000000000000000000000000000000000000000000"),
   // ("1011001010010001110001011110011100010000" ||             // 26 PROTECT
   //  "000000000000000000000000000000000000000000000000"),
   // ("1111111011111111111111111111111111010000" ||             // 27 QNAME
   //  "000000000000000000000000000000000000000000000000"),
   // ("1100001010010001000000011011110000010000" ||             // 28 SPACE
   //  "000000000000000000000000000000000000000000000000"),
   // ("1000011011010001100000011011110000010000" ||             // 29 SUBSYS
   //  "000000000000000000000000000000000000000000000000"),
   // ("1100101010110101000010100111110011010000" ||             // 30 SYSOUT
   //  "000000000000000000000000000000000000000000000000"),
   // ("1100001010010001000000000110001000010000" ||             // 31 TERM
   //  "000000000000000000000000000000000000000000000000"),
   // ("1100001010010001000000000110000100010000" ||             // 32 UCS
   //  "000000000000000000000000000000000000000000000000"),
   // ("1000001010010001000000011010010010010000" ||             // 33 UNIT
   //  "000000000000000000000000000000000000000000000000"),
   // ("0011010010010001010001111010010001010000" ||             // 34 VOLUME
   //  "000000000000000000000000000000000000000000000000"),
   // ("1011011010010001010011011010010000010000" ||             // 35 ACCODE
   //  "000000000000000000000000000000000000000000000000"),
   // ("1111111111111111111111111111111111110000" ||             // 36 CNTL
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 37 AVGREC
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 38 DATACLAS
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 39 EXPDT
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 40 KEYLEN
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 41 KEYOFF
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 42 LIKE
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 43 LRECL
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 44 MGMTCLAS
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 45 RECFM
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 46 RECORG
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 47 REFDD
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 48 RETPD
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 49 SECMODEL
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 50 STORCLAS
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 51 BFALN
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 52 BFTEK
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 53 BLKSIZE
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 54 BUFIN
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 55 BUFL
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 56 BUFMAX
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 57 BUFNO
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 58 BUFOFF
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 59 BUFOUT
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 60 BUFSIZE
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 61 CPRI
   //  "000000000000000000000000000000000000000000000000"),
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 63 DEN
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 64 DIAGNS
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 65 DSORG
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 66 EROPT
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 67 FUNC
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 68 GNCP
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 69 INTVL
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 70 IPLTXID
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 71 LIMCT
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 72 MODE
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 73 NCP
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 74 NTM
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 75 OPTCD
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 76 PCI
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 77 PRTSP
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 78 RESERVE
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 79 RKP
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 80 STACK
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 81 THRESH
   //  "000000000000000000000000000000000000000000000000"),
   // ("0000000000000000000000000000000000000000" ||             // 82 TRTCH
   //  "000000000000000000000000000000000000000000000000"),
   //    '','','','','','','','','','','','','',''};             // 83 - 96


   /*---------------------------------------------------------------*/
   /*  tables for dd_lvl_test() - ONE-origin (e.g., 6 for "COPIES") */
   /*---------------------------------------------------------------*/
   // testing paren levels (96 flags)
   //  ' ' = no parameter-values list allowed     DD  XXX=x
   //  'S' = sub-parm value list not allowed      DD  XXX=(x,(y,z))
   //  'F' = sub-parm list allowed                DD  XXX=(x,y)
   private static final String lvl_mask =
      //          1         2         3         4         5
      // 12345678901234567890123456789012345678901234567890
        " S S F S SS S   SS  SSS S  FSS SSF                " +
      //          6         7         8         9
      // 1234567890123456789012345678901234567890123456
        "                         F F       SSS        "    ;

   // testing subparm counts - max. number of parameters in list (96 flags):
   //  '1' = only one parm allowed in a list
   //        .. ..
   //  '6' = 6 or more parms allowed in list
   private static final String mxp_mask =
      //          1         2         3         4         5
      // 12345678901234567890123456789012345678901234567890
        " 1 5 2 6 23 2   22  522 6  563 335                " +
      //          6         7         8         9
      // 1234567890123456789012345678901234567890123456
        "                         2 2       266        "    ;


   private int          card;                // card flags (first, ..)
   private static final int
                        CARD_NONE  = 0x00000000,
                        CARD_FIRST = 0x00000001,
                        CARD_PROC  = 0x00000002,
                        CARD_DATA  = 0x00000004,
                        CARD_JES3  = 0x00000008,
                        CARD_LAST  = 0x00000010,
                        CARD_FINAL = 0x00000020,
                        CARD_SPLIT = 0x00000040;

   private boolean      fEjes2, fEjes3, fEesa, fExa;  // options

   private String       data_dlm;            // data delimiter (2 chars)
   // *as* 5/99 should stack these, there can be nested delimiter statements
   //           (and also double-link all elements for such nestings!?)...

   private long         ulEClass,            // cards before & after parse range
                        ulEClassAfterLast;

   private String       jcl_id;              // "//" usually
   private String       oper;                // 80-char long JCL line
   private int          oper_offset;

   private int          EEndLine;            // end of parse range
   private int          ECurLine;            // current line in range

   private StringBuffer Etxt =
                         new StringBuffer(); // local 80-chars massaged text copy
   private String       lotxt;               //  & its mixed-case ~ original
   private StringBuffer Efnts;               //  & fonts
   private int          Etxtl;               // actual length of the text line

   private String       name;

   private int          cur_offset,
                        value_offset,
                        parm_key_offset,
                        sub_key_offset;
   private String       parm_key,
                        sub_key,
                        value;

   private int          parm_num,
                        sub_num,
                        field_num;

   private boolean      Esub_p,
                        field_p,
                        symbolic,
                        in_quote,            // inside a 'quoted string'
                        endOfSubparameters,
                        endOfFields,
                        endOfCard;           // end of the current card

   private char         Estream_type;
   private String       key_list;            // keywords encountered so far
   private int          Ekey_num;

   //char  Ekey_bits[96+1];


   /**
    * Constructor for the parser.
    * @param  lpexView  the LPEX document view associated with this parser.
    */
   public JclParser(LpexView lpexView)
   {
      super(lpexView);        // LpexCommonParser constructor (view := lpexView)
      initializeParser();     // initialize LpexView with our stuff
   }

   /**
    * Returns the parser's properties profile resource bundle.
    */
   public ResourceBundle getProfile()
   {
      return resource;
   }

   /**
    * Returns "JCL", the language supported by this parser.
    * @see com.ibm.lpex.core.LpexCommonParser#LANGUAGE_JCL
    */
   public String       getLanguage()
   {
      return LANGUAGE_JCL;
   }

   /**
    * Query parser's system-specific JCL options.
    * The parser uses two sets of options:  JES2 / JES3, and ESA / XA.
    * <br>JES2 or JES3 specifies the Job entry subsystem.
    * The default is <b>JES3</b>.
    * <br>ESA specifies that MVS/ESA JCL (JES level 4) is used;
    * XA specifies that only MVS/XA JCL (JES level 2) is recognized.
    * The default is <b>ESA</b>.
    * <p>
    * To modify these settings, extend JclParser and override this method.
    * @see #OPTION_JES2
    * @see #OPTION_JES3
    * @see #OPTION_ESA
    * @see #OPTION_XA
    */
   public int          getJclOptions()
   {
      return (OPTION_JES3 | OPTION_ESA);
   }

   /**
    * Initialize the parser for an LPEX document view: set up style attributes
    * for the styles we need, classes, etc., and initialize the view
    * for the language-sensitive edit features supported.
    */
   private void        initializeParser()
   {
      // set attributes for the styles we use
      String tokenHighlight = getProperty("tokenHighlight");
      setStyleAttributes(tokenHighlight == null || !tokenHighlight.equals("off"));

      // register the classes we use
      // & get their allocated bit-masks
      classJcl      = view.registerClass(CLASS_JCL);
      classComment  = view.registerClass(CLASS_COMMENT);
      classCommand  = view.registerClass(CLASS_COMMAND);
      classControl  = view.registerClass(CLASS_CONTROL);
      classJob      = view.registerClass(CLASS_JOB);
      classExec     = view.registerClass(CLASS_EXEC);
      classDd       = view.registerClass(CLASS_DD);
      classDlm      = view.registerClass(CLASS_DLM);
      classNull     = view.registerClass(CLASS_NULL);
      classProc     = view.registerClass(CLASS_PROC);
      classPend     = view.registerClass(CLASS_PEND);
      classOutput   = view.registerClass(CLASS_OUTPUT);
      classJes2     = view.registerClass(CLASS_JES2);
      classJes3     = view.registerClass(CLASS_JES3);
      classXmit     = view.registerClass(CLASS_XMIT);
      classCntl     = view.registerClass(CLASS_CNTL);
      classEndcntl  = view.registerClass(CLASS_ENDCNTL);
      classInstream = view.registerClass(CLASS_INSTREAM);
      classFwdlink  = view.registerClass(CLASS_FWDLINK);
      classBwdlink  = view.registerClass(CLASS_BWDLINK);
      classError    = view.registerClass(CLASS_ERROR);
      classLib      = view.registerClass(CLASS_LIB);
      classCond     = view.registerClass(CLASS_COND);
      classSplit    = view.registerClass(CLASS_SPLIT);

      classAll = classJcl | classComment | classCommand | classControl |
                 classJob | classExec | classDd | classDlm | classNull |
                 classProc | classPend | classOutput | classJes2 | classJes3 |
                 classXmit | classCntl | classEndcntl | classInstream |
                 classFwdlink | classBwdlink | classError | classLib |
                 classCond | classSplit;


      // view filter actions "jobs", "execs", "dds", "procs", "errors"
      LpexAction lpexAction = new LpexAction() {                // "jobs"
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_JOB);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("jobs", lpexAction);

      lpexAction = new LpexAction() {                           // "execs"
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_EXEC);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("execs", lpexAction);

      lpexAction = new LpexAction() {                           // "dds"
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_DD);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("dds", lpexAction);

      lpexAction = new LpexAction() {                           // "procs"
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_PROC);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("procs", lpexAction);

      lpexAction = new LpexAction() {                           // "errors"
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " +
                                  CLASS_ERROR + " " + CLASS_MESSAGE);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
         };
      view.defineAction("errors", lpexAction);

      // get JCL options, use the defaults if conflicting options
      int options = getJclOptions();
      fEjes2 = (options & OPTION_JES2) != 0;
      fEjes3 = (options & OPTION_JES3) != 0;
      fEesa  = (options & OPTION_ESA)  != 0;
      fExa   = (options & OPTION_XA)   != 0;
      if ((!fEjes2 && !fEjes3) || (fEjes2 && fEjes3)) {
         fEjes3 = true;
         fEjes2 = false;
         }
      if ((!fEesa && !fExa) || (fEesa && fExa)) {
         fEesa  = true;
         fExa   = false;
         }
   }

   /**
    * Return parser's items for the popup View submenu.
    */
   public String       getPopupViewItems()
   {
      return getLanguage() + ".popup.jobs jobs " +
             getLanguage() + ".popup.execs execs " +
             getLanguage() + ".popup.dds dds " +
             getLanguage() + ".popup.procs procs " +
             MSG_POPUP_ERRORS + " errors";
   }

   /**
    * Define parser's style attributes.
    * @param  colours  true = token highlighting,
    *                  false = no token highlighting
    */
   public  void        setStyleAttributes(boolean colours)
   {
      String toBackground = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                        BACKGROUND_COLOR,
                                                        toBackground);
      if (colours) {
         setStyle("_i" +                    // Blank/unparsed characters, In-stream data
                  "z*(),=." +               // Sequence number, Delimiter, First & Second level
                                            //   parenthesis, Comma, Equal sign, Period
                  "jsrpd", attributes);     // Job & Step & Proc & Proc step & DD name

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("c",   attributes);       // Comment

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_ERROR,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("e",   attributes);       // Error

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("kby", attributes);       // Keyword, Subkeyword, Keyword - symbolic

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_STRING,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("q",   attributes);       // Quoted string

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_NONSOURCE,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("/",   attributes);       // JCL statement prefix

         attributes = LpexPaletteAttributes.convert("128 0   0   255 255 255",
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("on",  attributes);       // Operation field, Command statement

         attributes = LpexPaletteAttributes.convert("0   0   0   255 255 255",
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("xv",  attributes);       // Symbolic value, Parameter value

         attributes = LpexPaletteAttributes.convert("128 0   128 255 255 255",
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("l",   attributes);       // Control statement
         }
      else                                  // drop the nice colours
         setStyle("/oxvnl_icekbyqz*(),=.jsrpd", attributes);
   }

   /**
    * Total parse of the entire document.
    */
   public  void        parseAll()
   {
      ulEClass = ulEClassAfterLast = 0;     // no lines before & after range
      doParse(1, view.elements(),           // parse entire doc
              false);                       //  no need to remove error messages
   }

   /**
    * Incremental parse.
    * @param  element  the element whose committed change triggered the parse,
    *                  or the element that precedes / follows a deleted block.
    *                  The parser may identify other neighbouring elements that
    *                  will have to be reparsed as a unit.
    */
   public  void        parseElement(int element)
   {
      // get Start/End line, set init (prev line's) + last (next line's) classes
      int Start = evaluateBeginElement(element);  // also sets ulEClass
      int End   = evaluateEndElement(element);    // also sets ulEClassAfterLast
      doParse(Start, End, true);                  // parse range
   }


   /**
    * Evaluate a parse range for incremental parse from the specified element
    * up to the top of the file.  Also set the class of the line preceding
    * the first - ulEClass.
    * Extra lines may be included as follows:
    * - the previous non-show line is included if it has been modified or if it
    *   has a class FWDLINK or INSTREAM, or if the current line has a class
    *   BWDLINK, or if a line between the current and the previous was deleted;
    * - once an extra line is included, the one previous to it is also checked.
    *
    * @param  elem  main line that triggered the parse
    * @return suggested start line for parsing (may be a show line)
    */
   private int         evaluateBeginElement(int elem)
   {
      int  tryElem;          // an element preceding elem
      long classes,          // classes of current elem
           tryClasses;       //  & classes of element preceding it

      /* always include previous line: e.g., Enter at the end of a line in error
         will open a new element pushing that line's message one down, we clear
         this error (now in our parse range), so it's lost! */
      if (elem > 1)
         elem--;

      // get current line's class
      for (;  elem > 1 && view.show(elem);  elem--) {}
      classes = view.elementClasses(elem);

      // LOOP BACKWARDS (up to top of the file)...
      while (elem > 1) {
         for (tryElem=elem-1;  tryElem > 1 && view.show(tryElem);  tryElem--) {}
         tryClasses = view.elementClasses(tryElem);    // prev non-show line's

         // Include prev line in parse range and go on searching if *any* of:
         //   (a) current line has a BWDLINK;
         //   (b) previous non-show line has a class INSTREAM or FWDLINK;
         //   (c) line(s) between previous and current line was/were deleted;
         //   (d) previous non-show line has been modified.
         if ((classes & classBwdlink)                      == 0  &&
             (tryClasses & (classInstream | classFwdlink)) == 0
             /*&&(view.parsePending(elem) & LX_PENDING_DELETE)==0*/
             /*&&(view.parsePending(tryElem) & PARSE_PENDING_CHANGE_MASK)==0*/) {
            ulEClass = tryClasses;                     // save this line's class
            break;                                     //  break out of loop.
            }

         classes = tryClasses;
         elem    = tryElem;
         }

      if (elem == 1)                    // no line previous to parse range's 1st
         ulEClass = 0;

      return elem;
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * to the bottom of the file.  Also set the class of the line succeeding the
    * last - ulEClassAfterLast.
    * Extra lines may be included as follows:
    * - the next line is included if it's been modified, or if it has a class
    *   BWDLINK or INSTREAM, or if the current line has a class of FWDLINK
    * - once an extra line is included, the one after it is also checked.
    * @param  element  main line that triggered the parse
    * @return suggested end line for parsing (may be a show line)
    */
   private int         evaluateEndElement(int element)
   {
      ulEClassAfterLast = 0;          // assume no line after parse range's last
      int elements = view.elements();

      // LOOP FORWARDS (down to bottom of the file)...
      int endElem = element;
      for (; endElem < elements; endElem++) {
         long classes = view.elementClasses(endElem);

         // Include next line in parse range and go on searching if *any* of:
         //   (a) current line has a FWDLINK;
         //   (b) next line is just a SHOW line;
         //   (c) next line was modified;
         //   (d) next line has a class INSTREAM or BWDLINK.
         // Also: current line has PARSE_PENDING_NEXT_DELETED_MASK ?!? *as*
         if (((classes & classFwdlink) == 0)  &&
             (!view.show(endElem+1))          &&
             ((view.parsePending(endElem+1) & PARSE_PENDING_CHANGE_MASK) == 0) &&
             ((view.elementClasses(endElem+1) &
                (classInstream | classBwdlink)) == 0)) {
            ulEClassAfterLast = classes;               // save this line's class
            break;                                     // break out of loop
            }
         }

      return endElem;
   }


   /**
    * FUNCTION: doParse()
    * DESCRPTN: Parse specified range.
    *           Start - start of range line.
    *           End   - end of range line.
    *
    * NOTES:
    *  1. Neal Eisenberg, Santa Teresa:
    *     From a JCL standpoint, blank lines are considered inline data
    *     for the program to be run.  It is probably OK to ignore them.
    *     In the case where a user indicates a JCL line is to be
    *     continued (end with a comma, followed by a blank or a comma
    *     in column 71), then I think the rule is the next line should
    *     be the continuation, in which case a blank line or other
    *     data would be invalid.  The exact JCL is sufficiently complex
    *     that I am not sure about the continuation case.  For now I
    *     would just all *ignore blank lines* (or for that matter any
    *     line that does not start with //).
    *  2. Reformat option - convert lower case letters to uppercase
    *     where required, and blank JCL lines to "// ").
    */
   private void        doParse(int Start, int End, boolean removeMessages)
   {
      String sFonts;      // font attribute buffer
      int    hNext = 1;
      String pLine;       // line text
      char   cc;          // continuation character
      String seq;         // 8-chars sequence number

      // clear existing lexical errors (if any) in the parse range
      if (removeMessages)
         removeMessages(Start, End);

      // initialize parse information.  ulEClass was set with the class
      // of the line preceding the first one being parsed (if any)
      ECurLine = Start;
      EEndLine = End;
      data_dlm = DEFAULT_DLM;                           // set default delimiter
      Ekey_num = 0;

      //if (readonly doc)
      // fEReformat = false; // readonly - no reformatting...

      /* start:  ** begin parse process */
      card = CARD_NONE;


      /*-------------------------------*/
      /*  P a r s e   l o o p   . . .  */
      /*-------------------------------*/
      do {
         if (!view.show(ECurLine)) {                          // skip SHOW lines
            // initialize for the element
            card |=  CARD_FIRST | CARD_LAST;      // assume one-card statement
            card &= ~(CARD_PROC | CARD_DATA | CARD_JES3 | CARD_SPLIT);

            oper_offset = parm_key_offset = sub_key_offset = value_offset = 0;

            // set flags based on prior line's classes
            if ((ulEClass & classFwdlink) != 0) {  // previous stmt continues
               card &= ~CARD_FIRST;
               if ((ulEClass & classJes3) != 0)    // JES3 card
                  card |= CARD_JES3;
               if ((ulEClass & classSplit) != 0)   // split quoted parameter
                  card |= CARD_SPLIT;
               }
            if ((ulEClass & classProc) != 0 &&
                (ulEClass & classPend) == 0)
               card |= CARD_PROC;
            if ((ulEClass & classInstream) != 0)
               card |= CARD_DATA;

            ulEClass = 0;                   // now clear classes for new element

            // initialize for first card
            if ((card & CARD_FIRST) != 0) {
               parm_num = sub_num = field_num = 0;
               Esub_p = field_p = symbolic = in_quote = false;
               endOfCard = endOfSubparameters = endOfFields = false;
               }

            // retrieve the card text, keep an 80-char local copy
            pLine = view.elementText(ECurLine);
            Etxtl = pLine.length();
            // if (Etxtl > 80) { // just ignore longer lines -as-
            //  setError(1, 80, "RECORDTOOLONG");
            //  return -4;
            //  }

            Etxt.setLength(80);
            int i;
            for (i = 0;  i < pLine.length() && i < 80;  i++)
               Etxt.setCharAt(i, pLine.charAt(i));
            for (;  i < 80;  i++)
               Etxt.setCharAt(i, ' ');

            Efnts = new StringBuffer(JCL_BASICSTYLE);             // basic fonts

            cc  = Etxt.charAt(72-1);                   // keep continuation char 72
            seq = Etxt.toString().substring(73-1, 80); //  & sequence numbers 73-79
            for (i = 72-1;  i < 80;  i++)
               Etxt.setCharAt(i, ' ');           // ignore sequence numbers *as*

            // convert blank lines as required - see NOTE 1 in prolog   2/97 @as
            if (/*fEreformat&&*/ empty(Etxt.toString()) && (card & CARD_DATA)==0) {
               Etxt.setCharAt(0, '/');
               Etxt.setCharAt(1, '/');
               }

            // keep original text, uppercase working & final copy if needed
            lotxt = Etxt.toString();
            //if (fEreformat)
            // uppercase(Etxt);

            // get the JCL ID (first 2 chars) and name fields
            jcl_id = lotxt.substring(0, 2);

            if (Etxt.charAt(3-1)==' ')    // allow no name for now, such as in:
               name = "";                 // //  EXEC PGM=A,PARM='X'  11/97 *as*
            else
               name = extractToken(Etxt.toString().substring(3-1));

            // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            doLine(); // analyze one card <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

            // finally, reset the text, and fonts as required
            if ((card & CARD_PROC) != 0)
               ulEClass |= classProc;

            // reset the text in the editor if anything reformatted
            // Etxt.setCharAt(72-1) = cc; // restore continuation character
            // strcpy(Etxt+73-1, seq);    //  & the sequence numbers
            // if (fEreformat && text != substr(Etxt,1,Etxtl))
            //  rc = lextext(substr(Etxt,1,Etxtl));

            if (Etxtl <= 80)
               sFonts = Efnts.toString().substring(0, Etxtl);
            else
               sFonts = Efnts.toString() +
                        styleString('!', Etxtl-80);           // set rest to '!'
            view.setElementStyle(ECurLine, sFonts);

            // set continuation flags
            if ((card & CARD_FIRST) == 0)
               ulEClass |= classBwdlink;
            if ((card & CARD_LAST) == 0)
               ulEClass |= classFwdlink;
            if (in_quote)
               ulEClass |= classSplit;

            // clear all old JCL-related classes in element, set the new ones
            view.setElementClasses(ECurLine,
                        (view.elementClasses(ECurLine) & ~classAll) | ulEClass);

            if ((card & CARD_LAST) != 0) {
               if ((card & CARD_FINAL) != 0)                  // do final one
                  card &= ~CARD_FINAL;
               else
                  card |= CARD_FINAL;
               }
         }//end "not a SHOW line"

      /*----------------------------------------------------------------------*/
      /*  at the end of the currently intended range: do we need more lines?  */
      /*----------------------------------------------------------------------*/
      if (ECurLine == EEndLine) {
         boolean fExpectedPROC =
            (card & CARD_PROC) != 0 && (ulEClass & classPend) == 0;
         boolean fLaterPROC = (ulEClassAfterLast & classProc) != 0;
         if ((card & CARD_LAST) == 0  ||
             (card & CARD_DATA) != 0  ||  (card & CARD_FINAL) != 0  ||
             // cc != ' ' || // *as* 5/99 handle for continued comments at least!?
             fExpectedPROC != fLaterPROC) {    // we need an extra line to parse
            hNext = EEndLine+1;
            if (hNext <= view.elements()) {    //  extend to even more if needed
               int hNext1 = hNext;             //  start of the new extra area
               hNext = evaluateEndElement(hNext1);
               removeMessages(hNext1, hNext);  //  clear old messages in the
               EEndLine = hNext;               //   newly-extended parse range
               }
            }
         }

      // continue processing next line
      if (ECurLine != EEndLine)
         hNext = ECurLine+1;

      } while (ECurLine != EEndLine &&                  // line done is not last
               (ECurLine=hNext) <= view.elements());    // didn't hit bottom yet
   }

   /**
    * Called by doParse() to analyze & tokenize one element (card) at a time.
    * When returning from here, the element styles & classes will be then set
    * (ol' "set_element" label).
    */
   private boolean     doLine()
   {
      /*===============================*/
      /*  first handle in-stream data  */
      /*===============================*/
      if ((card & CARD_DATA) != 0) {
         // 1.- the expected end-of-data delimiter?
         if (jcl_id.equals(data_dlm) &&
             (fEjes3 || Etxt.charAt(3-1) == ' '))
            return dlm_proc();
         // 2.- more data...
         if (fEjes3 || !jcl_id.equals("//") || Estream_type == 'D')
            return instream_proc();
         }

      /*====================================================*/
      /*  process "/*" JES2 Command and Control statements  */
      /*====================================================*/
      if (fEjes2 && jcl_id.equals("/*") && (card & CARD_FIRST) != 0)
         return jes2_proc();

      /*========================================*/
      /*  process "/*" JES3 Control statements  */
      /*========================================*/
      if (fEjes3 && jcl_id.equals("/*") && (card & CARD_FIRST) != 0) {
         if (!jes3_proc())
            return true;         // done, JES3 indeed, go set the element now...
         }

      /*==================================================================*/
      /*  process "//*" Comments and JES3 Command and Control statements  */
      /*==================================================================*/
      else if (Etxt.toString().startsWith("//*")) {
         // 1.- a JES3 statement
         if (fEjes3 &&
             ((card & CARD_FIRST) != 0 || (card & CARD_JES3) != 0)) {
            if (!jes3_proc())
               return true;      // done with card, it's JES3, go set element...
            }

         // 2.- JCL comment statement
         return comment_proc();
         }

      /*=========================*/
      /*  process "??" stuff...  */
      /*=========================*/
      if (!jcl_id.equals("//")) {
         // if (fEreformat)
         //  Etxt = lotxt; // use original text

         // 1.- missing continuation
         Efnts = new StringBuffer(styleString('!', 80));           // ??!?? *as*
         if ((card & CARD_FIRST) == 0)             // not the first card:
            return setError(1,80, "CONTEXPECTED"); //  continuation was expected

         // 2.- the process assumed "SYSIN DD *":
         // See "OS/390 V2R6.0 MVS JCL Reference" (GC28-1757-05):
         // By convention, people often use a SYSIN DD statement to
         // begin an in-stream data set.  In-stream data sets begin with a DD *
         // or DD DATA statement; these DD statements can have any valid ddname,
         // including SYSIN.  If you omit a DD statement before input data, the
         // system provides a DD * statement with the ddname of SYSIN.
         // Syntax:
         // //SYSIN DD parameter[,parameter]...  [comments]
         // Parameters on SYSIN DD Statements:
         // The first parameter is an * or DATA, to signal that an in-stream
         // data set follows immediately.

         // if (!alll)
         //  reparse = true; // ?? CAN AVOID IN evaluateBeginElement() *as* ??
         Estream_type = '*';
         data_dlm = DEFAULT_DLM;
         return instream_proc();
         }

      /*===============================*/
      /*  process "//" JCL statements  */
      /*===============================*/
      ulEClass |= classJcl;                                       // class = jcl
      cur_offset = 3;

      /*---------------------------------------------------------*/
      /*  (A) get the operation field if this is the first line  */
      /*---------------------------------------------------------*/
      if ((card & CARD_FIRST) != 0) {                  // process this statement
         if (Etxt.toString().startsWith("//") &&
             empty(Etxt.toString().substring(3-1)))
            return null_proc();                                   // handle null

         // set default name fonts & bump up cur_offset
         if (name.length() > 0)
            cur_offset = setFonts(cur_offset, name.length(), FONT_DDNAME);

         // strip the JCL operation field
         oper = Etxt.toString().substring(cur_offset-1);
         if (empty(oper))                                    // missing operator
            return setError(1, cur_offset, "OPERATIONMISSING");

         // strip the blanks, and set the operator fonts
         cur_offset  += verify(oper, " ") - 1;
         oper_offset  = cur_offset;
         oper = extractToken(Etxt.toString().substring(oper_offset-1));
         cur_offset = setFonts(cur_offset, oper.length(), FONT_OPERATION);

         // set the offset to the first parameter
         String opnds;
         opnds = Etxt.toString().substring(cur_offset-1);
         if (!empty(opnds))
            cur_offset += verify(opnds, " ") - 1;
         }

      /*-------------------------------------*/
      /*  (B) process JCL continuation card  */
      /*-------------------------------------*/
      else { /* !first card */
         oper_offset = 0;
         if ((card & CARD_SPLIT) != 0) {
            if (!Etxt.toString().startsWith("//             "))
               return setError(1, 72, "QUOTEDCONTEXPECTED");
            cur_offset = 16;
            }
         else { /* !split card */
            if (!Etxt.toString().startsWith("// ") ||
                 Etxt.toString().startsWith("//              "))
               return setError(1, 72, "PARMCONTEXPECTED");
            String opnds = Etxt.toString().substring(cur_offset-1);
            if (!empty(opnds))
               cur_offset += verify(opnds, " ") - 1;
            }
         }

      // process the JCL statement
      if      (oper.equals("DD"))                dd_proc();
      else if (oper.equals("JOB"))               job_proc();
      else if (oper.equals("EXEC"))              exec_proc();
      else if (oper.equals("PROC"))              proc_proc();
      else if (oper.equals("PEND"))              pend_proc();
      else if (oper.equals("OUTPUT"))            output_proc();
      else if (oper.equals("XMIT"))              xmit_proc();
      else if (oper.equals("CNTL"))              cntl_proc();
      else if (oper.equals("ENDCNTL"))           endcntl_proc();

      // possibly an ESA statement
      else if (fEesa && oper.equals("IF"))       if_then_proc();
      else if (fEesa && oper.equals("ELSE"))     else_proc();
      else if (fEesa && oper.equals("ENDIF"))    endif_proc();
      else if (fEesa && oper.equals("INCLUDE"))  include_proc();
      else if (fEesa && oper.equals("JCLLIB"))   jcllib_proc();
      else if (fEesa && oper.equals("SET"))      set_proc();
      else if (fEesa && oper.equals("COMMAND"))  command_proc(oper);

      // possibly a JES2 Operator Command
      else if (fEjes2)                           command_proc(oper);

      // nothing of the kind, an error no doubt
      else return setError(oper_offset, oper.length(), "BADOPERATION");
      return true;
   }


   /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
   /*     J O B     Card                                                */
   /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
   // @return is irrelevant...
   private boolean     job_proc()
   {
      ulEClass |= classJob;
      if ((card & CARD_PROC) != 0)
         return setError(1, 72, "JOBCARDINPROC");

      if ((card & CARD_FIRST) != 0) {
         if (!isValidName(name))
            return setError(3, name.length(), "BADXXNAME", "JOB");
         setFonts(3, name.length(), FONT_JOBNAME);
         key_list = " ";
         }

      // process all the JOB card fields
      card &= ~CARD_LAST;                        // clear last_card indication
      do { // do until the entire card is processed...
         if (!get_next())
            return true;                         // error from get_next().

         if (!empty(parm_key) && sub_num == 1 && field_num < 2) {
            if (indexStrBB(key_list, parm_key) != 0)
               return setError(parm_key_offset, parm_key.length(), "DUPLICATEKW");
            key_list += parm_key + " ";
            }

         if (field_p && !empty(parm_key) && !parm_key.equals("COND"))
            return setError(value_offset -1, -1, "BADCHAR", "(");

         //*as* else if (Esub_p && !empty(parm_key) && !parm_key.equals("COND")) {
         //*as*  if (sub_key > 2)
         //*as*   return setError(parm_key_offset -1, -1, "TOOMANYPARMSFOR", parm_key);
         //*as*  else if (sub_key > 1) {
         //*as*   if ((fExa && indexStrBB(" MSGLEVEL PASSWORD RESTART TIME ",
         //*as*                           parm_key) == 0) ||
         //*as*       indexStrBB(
         //*as*        " MSGLEVEL PASSWORD RESTART TIME BYTES CARDS LINES PAGES ",
         //*as*        parm_key) == 0)
         //*as*     return setError(parm_key_offset -1, -1, "TOOMANYPARMSFOR", parm_key);
         //*as*    }
         //*as*   }

         if (!empty(sub_key))
            return setError(sub_key_offset -1, -1, "BADCHAR", "=");

         // switch (parm_key)
         if (parm_key.equals("ADDRSPC")) {
            if (!isValueIn(" VIRT REAL "))
               return setError(value_offset, value.length(), "BADADDRSP");
            }

         else if (parm_key.equals("CLASS")) {
            if (!isValidClass(value))
               return setError(value_offset, value.length(), "BADCLASS");
            }

         else if (parm_key.equals("COND")) {
            if (sub_num > 8)
               return setError(cur_offset, -72, "CONDTESTS");
            if ((field_num == 0 && sub_num == 1) || field_num == 1) {
               if (!isNumber(value, 0, 4095))
                  return setError(value_offset, value.length(), "BADCONDCODE");
               if ((field_num == 1 && endOfFields) || endOfSubparameters)
                  return setError(cur_offset, -72, "CONDTESTOPERMISSING");
               }
            else if ((field_num == 0 && sub_num == 2) || field_num == 2) {
               if (!isValueIn(" GT GE EQ NE LT LE "))
                  return setError(value_offset, value.length(), "BADCOND");
               }
            else
               return setError(cur_offset, -72, "BADCONDPARM");
            }

         else if (parm_key.equals("GROUP")) {
            if (!isValidName(value))
               return setError(value_offset, value.length(), "BADXXNAME", "GROUP");
            }

         else if (parm_key.equals("MSGCLASS")) {
            if (!isValidClass(value))
               return setError(value_offset, value.length(), "MSGCLASS");
            }

         else if (parm_key.equals("MSGLEVEL")) {
            if (sub_num == 1 && !isValueIn(" 0 1 2 "))
               return setError(value_offset, value.length(), "MSGLEVEL");
            if (sub_num == 2 && !isValueIn(" 0 1 "))
               return setError(value_offset, value.length(), "MSGLEVELMSG");
            }

         else if (parm_key.equals("NOTIFY")) {
            if (!isValidTsoUserId(value)) {
               //return  @as 2/2000 - see notes under Eparm_key,"USER" below...
               setError(value_offset, value.length(), "BADTSOUSERID");
               }
            }

         else if (parm_key.equals("PASSWORD")) {
            //if ((card & CARD_FIRST) == 0)
            // return setError(value_offset,value.length(),"PWDNOTONFIRST");
            if (!isValidPassword(value))
               return setError(value_offset, value.length(), "BADPWD");
            }

         else if (parm_key.equals("PERFORM")) {
            if (!isNumber(value, 1, 999))
               return setError(value_offset, value.length(), "BADPERFGROUP");
            }

         else if (parm_key.equals("PRTY")) {
            if (fEjes2 && !isNumber(value, 0, 14))
               return setError(value_offset, value.length(), "PRIORITY", "14");
            if (fEjes3 && !isNumber(value, 0, 15))
               return setError(value_offset, value.length(), "PRIORITY", "15");
            }

         else if (parm_key.equals("RD")) {
            if (!isValueIn(" R RNC NR NC "))
               return setError(value_offset, value.length(), "BADRD");
            }

         else if (parm_key.equals("REGION")) {
            char c1 = ' ';                            // last character in value
            String tmpvalue = "";
            if (value.length() > 0) {
               c1 = value.charAt(value.length()-1);
               tmpvalue = value.substring(0, value.length()-1);
               }
            if ((c1 == 'K' && !isNumber(tmpvalue, 0, 2096128)) ||
                (c1 == 'M' && !isNumber(tmpvalue, 0, 2047))    ||
                (c1 != 'K' && c1 != 'M'))
               return setError(value_offset, value.length(), "BADREGION");
            }

         else if (parm_key.equals("RESTART")) {
            if (sub_num == 1) {
               if (!value.equals("*") && !isValidName(value)  &&
                   !isValidNameWithPeriod(value))   // &&s -> ||s ?!?? *as* 5/99
                  return setError(value_offset, value.length(), "BADRESTART");
               }
            //else if (sub_num == 2) {
            // // checkid edit here?? *as*
            // }
            }

         // JOB statement - TIME=([n1][,n2]) | 1440 | NOLIMIT | MAXIMUM
         else if (parm_key.equals("TIME")) {
            if (sub_num == 1) {                // (a) 1st TIME subparameter (n1)
               if (value.length() > 0) {                      // allow TIME(,n2)
                  if (/*!fEesa || ?! @as 3/2000 no checks if ESA ?! */
                      !isValueIn(" NOLIMIT MAXIMUM ")) {
                     if (!isNumber(value, 0, 357912))
                        return setError(value_offset, value.length(), "BADMINUTES");
                     //if (value.equals("1440") && !endOfSubparameters) @as 3/2000
                     // return setError(value_offset, value.length(), "SECONDS");
                     }
                  // /*ESA or*/ NOLIMIT | MAXIMUM
                  else if (!endOfSubparameters)
                     return setError(value_offset, value.length(), "UNEXPECTEDPARM");
                  }
               }

            else if (sub_num == 2) {          /* (b) 2nd TIME subparameter (n2) */
               if (!isNumber(value, 0, 59))
                  return setError(value_offset, value.length(), "BADSECONDS");
               }
            }

         else if (parm_key.equals("TYPRUN")) {
            if (!isValueIn(" HOLD SCAN ")  &&
                !(fEjes2 && isValueIn(" COPY JCLHOLD ")))
               return setError(value_offset, value.length(),
                               fEjes2 ? "BADTYPRUNJES2" : "BADTYPRUNJES3");
            }

         else if (parm_key.equals("USER")) {
            if (!isValidTsoUserId(value)) {
               // *as* 2/2000: may want to extend this on all/most errors!?:
               // * error option 1 - mark error, but continue parsing the card:
               setError(value_offset, value.length(), "BADTSOUSERID");
               // * error option 2 - mark card as last, so the error doesn't
               // propagate to following lines (do it on all setError()s??):
               //card |= CARD_LAST;
               // * error option 3 (original) - mark error & give up:
               //return setError(value_offset, value.length(), "BADTSOUSERID");
               }
            }

         else if (parm_key.equals("BYTES") ||
                  parm_key.equals("LINES")) {
            if (fExa)
               return setError(parm_key_offset, parm_key.length(), "BADJOBKWPARM");
            if (sub_num == 1 && !isNumber(value, 0, 999999))
               return setError(value_offset, value.length(), "BADVALUE0TOXX", "999999");
            if (sub_num == 2 && !isValueIn(" CANCEL DUMP WARNING "))
               return setError(value_offset, value.length(), "CANDUMPWARNEXPECTED");
            }

         else if (parm_key.equals("CARDS") ||
                  parm_key.equals("PAGES")) {
            if (fExa)
               return setError(parm_key_offset, parm_key.length(), "BADJOBKWPARM");
            if (sub_num == 1 && !isNumber(value, 0, 99999999))
               return setError(value_offset, value.length(), "BADVALUE0TOXX", "99999999");
            if (sub_num == 2 && !isValueIn(" CANCEL DUMP WARNING "))
               return setError(value_offset, value.length(), "CANDUMPWARNEXPECTED");
            }

         else {
            if (!empty(parm_key))
               return setError(parm_key_offset, parm_key.length(), "BADJOBKWPARM");
            // else if (parm_num == 1) {
            //  // accounting Information edits go here *as*
            //  }
            else if (parm_num == 2) {
               if (value.length() > 20)
                  return setError(value_offset, value.length(), "PROGRAMMERTOOLONG");
               }
            }
         //end "switch parm_key"
         } while (!endOfCard); //end "do while !endOfCard"

      setComments(cur_offset);             // comments from col cur_offset on...
      return true;
   }


   /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
   /*     E X E C   Card                                                */
   /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
   private boolean     exec_proc()
   {
      int i, j;

      ulEClass |= classExec;

      if ((card & CARD_FIRST) != 0) {
         if (!empty(name) && !isValidName(name))
            return setError(3, name.length(), "BADEXECSTEP");
         key_list = " ";
         setFonts(3, name.length(), FONT_STEPNAME);
         }

      // process all the EXEC card fields
      card &= ~CARD_LAST;                        // clear last_card indication
      do { // do until the entire card is processed
         if (!get_next())
            return true;

         // symbolic parm IS okay in EXEC too!?... (2/2000)
         // //GO     EXEC  PGM=CALCPRG,
         // // REGION=64000K,PARM=('/TEST(,,,VADTCPIP&9.112.21.151:*)')
         //if (symbolic && (card & CARD_PROC) == 0)
         // return setError(value_offset, value.length(), "SYMPARMNOTINPROC");

         i = parm_key.indexOf('.')+1;
         if (i != 0) {
            j = parm_key.length() - i;
            if (!isValidName(parm_key.substring(i+1 -1)))
               return setError(parm_key_offset + i, j, "BADPROCSTEP");

            parm_key = parm_key.substring(0, i-1);
            i += parm_key_offset - 1;
            i = setFonts(i, 1, FONT_PERIOD);
            i = setFonts(i, j, FONT_PROCSTEPNAME);
            }

         if (!empty(parm_key)) {
            if (sub_num == 1 && field_num < 2) {
               // @as 5/99 If looking at parm_key, see first if there is a
               // parm_key_offset - this allows the following continuing
               // parameter field enclosed in apostrophes:
               // //BBSSTART EXEC PGM=BBSSEND,
               // //             PARM='161.2.160.17
               // //             8050 4 1'
               // @as 5/99 Or should perhaps check for CARD_SPLIT here instead?!
               if (parm_key_offset != 0) {
                  if (indexStrBB(key_list, parm_key) != 0)
                     return setError(parm_key_offset, parm_key.length(), "DUPLICATEKW");
                  key_list += parm_key + " ";
                  }
               }
            else if (sub_num > 1 &&
                     indexStr("TIME DPRTY PARM COND ACCT", parm_key) == 0)
               return setError(value_offset, value.length(), "TOOMANYPARMS");
            else if (sub_num > 2 &&
                     indexStr("PARM COND ACCT", parm_key) == 0)
               return setError(value_offset, value.length(), "TOOMANYPARMS");
            }

         /* test according to parm_key */
         if (parm_key.equals("PGM")) {
            if (!symbolic) {
               if (sub_num != 1)
                  return setError(parm_key_offset, parm_key.length(), "PGMNOTFIRST");
               if (!empty(value) && value.charAt(0) == '*') {
                  if (!isBackReference(value))
                     return setError(value_offset, value.length(), "BADPROGRAMREF");
                  }
               else if (!isValidName(value))
                  return setError(value_offset, value.length(), "PROGNAME");
               }
            }

         else if (parm_key.equals("PROC")) {
            if (!symbolic) {
               if (sub_num != 1)
                  return setError(parm_key_offset, parm_key.length(), "PROCNOTFIRST");
               if (!isValidName(value))
                  return setError(value_offset, value.length(), "PROCNAME");
               value_offset = setFonts(value_offset, value.length(), FONT_PROCNAME);
               }
            }

         else if (parm_key.equals("ACCT")) {
            // accounting info edits to go in here *as*
            }

         else if (parm_key.equals("ADDRSPC")) {
            if (!symbolic && !isValueIn(" VIRT READ "))
               return setError(value_offset, value.length(), "BADADDRSP");
            }

         else if (parm_key.equals("COND")) {
            if (!symbolic) {
               if (sub_num > 8)
                  return setError(cur_offset, -72, "CONDTESTS");
               if ((field_num == 0 && sub_num == 1) || field_num == 1) {
                  if (!isValueIn(" EVEN ONLY ")) {
                     if (!isNumber(value, 0, 4095))
                        return setError(value_offset, value.length(), "BADCONDCODE");
                     if ((field_num == 1 && endOfFields) || endOfSubparameters)
                        return setError(cur_offset, -72, "CONDTESTOPERMISSING");
                     }
                  else if (field_p)
                     return setError(value_offset -1, value.length() +1, "UNEXPECTEDSUBPARM");
                  }
               else if ((field_num == 0 && sub_num == 2) || field_num == 2) {
                  if (!isValueIn(" GT GE EQ NE LT LE "))
                     return setError(value_offset, value.length(), "BADCOND");
                  }
               else if ((field_num == 0 && sub_num == 3) || field_num == 3) {
                  i = value.indexOf('.')+1;
                  if (i != 0) {
                     String name1;
                     if (!isValidName(value.substring(i+1 - 1)))
                        return setError(value_offset +i, value.length() -i, "BADPROCSTEP");
                     name1 = value.substring(0, i-1);
                     if (!isValidName(name1))
                        return setError(value_offset, i-1, "STEPNAME");
                     parm_key = parm_key.substring(0, i-1);
                     j = value_offset;
                     j = setFonts(j, i -1, FONT_STEPNAME);
                     j = setFonts(j, 1, FONT_PERIOD);
                     j = setFonts(j, value.length() -i, FONT_PROCSTEPNAME);
                     }
                  else {
                     if (!isValidName(value))
                        return setError(value_offset, value.length(), "STEPNAME");
                     value_offset = setFonts(value_offset, value.length(), FONT_STEPNAME);
                     }
                  }
               else if ((field_num == 0 && sub_num > 3) || field_num > 3)
                  return setError(cur_offset, -72, "CONDSUBFIELDS");  // too many...
               }
            }

         else if (parm_key.equals("DPRTY")) {
            if (!symbolic && !isNumber(value, 0, 15))
               return setError(value_offset, value.length(), "PRIORITY", "15");
            }

         else if (parm_key.equals("DYNAMNBR")) {
            if (!symbolic && !isNumber(value, 0, 3273))
               return setError(value_offset, value.length(), "BADDYNAMNBR");
            }

         else if (parm_key.equals("PARM")) {
            // parm checks to go here: length check? *as*
            }

         else if (parm_key.equals("PERFORM")) {
            if (!symbolic && !isNumber(value, 1, 999))
               return setError(value_offset, value.length(), "BADPERFGROUP");
            }

         else if (parm_key.equals("RD")) {
            if (!symbolic && !isValueIn(" R RNC NR NC "))
               return setError(value_offset, value.length(), "BADRD");
            }

         else if (parm_key.equals("REGION")) {
            if (!symbolic) {      // ?!? not in the original PL/I code ?!? -as-
               char c1 = ' ';                         // last character in value
               String tmpvalue = "";
               if (value.length() > 0) {
                  c1 = value.charAt(value.length()-1);
                  tmpvalue = value.substring(0, value.length()-1);
                  }
               if ((c1 == 'K' && !isNumber(tmpvalue, 0, 2096128)) ||
                   (c1 == 'M' && !isNumber(tmpvalue, 0, 2047))    ||
                   (c1 != 'K' && c1 != 'M'))
                  return setError(value_offset, value.length(), "BADREGION");
               }
            }

         // EXEC statement - TIME=([n1][,n2]) | 1440 | NOLIMIT | MAXIMUM | 0
         else if (parm_key.equals("TIME")) {
            if (!symbolic) {       // ?!? not in the original PL/I code ?!? -as-
               if (sub_num == 1) {             // (a) 1st TIME subparameter (n1)
                  if (value.length() > 0) {                   // allow TIME(,n2)
                     if (/*!fEesa || ?! @as 3/2000 no checks if ESA ?! */
                         !isValueIn(" NOLIMIT MAXIMUM ")) {
                        if (!isNumber(value, 0, 357912))
                           return setError(value_offset,value.length(), "BADMINUTES");
                        //if (value.equals("1440") && !endOfSubparameters) @as 3/2000
                        // return setError(value_offset, value.length(), "SECONDS");
                        }
                     // /*ESA or*/ NOLIMIT | MAXIMUM
                     else if (!endOfSubparameters)
                        return setError(value_offset, value.length(), "UNEXPECTEDPARM");
                     }
                  }

               else if (sub_num == 2) {          /* (b) 2nd TIME subparameter (n2) */
                  if (!isNumber(value, 0, 59))
                     return setError(value_offset, value.length(), "BADSECONDS");
                  }
               }
            }

         else { /* default */
            if (!empty(parm_key)) {
               if (sub_num == 1 && field_num < 2) {
                  if (parm_key.length() > 8 || !isValidName(parm_key))
                     return setError(value_offset, value.length(), "BADSYMPARMNAME");
                  i = parm_key_offset;
                  i = setFonts(i, parm_key.length(), FONT_KEYWORDSYM);
                  }
               }
            else if (parm_num == 1) {
               // may want to first check empty(value), and put
               // up another, more meaningful error message?! *as*
               if (!isValidName(value))
                  return setError(value_offset, value.length(), "PROCNAME");
               value_offset = setFonts(value_offset, value.length(), FONT_PROCNAME);
               }
            else if (parm_num > 1)
               return setError(value_offset, value.length(), "TOOMANYPOSPARMS");
            }
         } while (!endOfCard);  /* end "do while !endOfCard" */

      setComments(cur_offset);             // comments from col cur_offset on...
      return true;
   }


   /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
   /*       D D     Card                                                */
   /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
   private boolean     dd_proc()
   {
      int    i;
      String key = "";
      int  key_offset;

      ulEClass |= classDd;

      if ((card & CARD_FIRST) != 0) {
         //memset(Ekey_bits, 0, sizeof(Ekey_bits));  // clear key_bits for tests
         i = name.indexOf('.')+1;
         if (i != 0) {
            String name1 = name.substring(0, i-1);
            if (!isValidName(name1))
               return setError(3, i, "BADPROCSTEP");
            setFonts(3, i -1, FONT_PROCSTEPNAME);
            if (!isValidName(name.substring(i+1 - 1)))
               return setError(3 + i, name.length() - i, "BADXXNAME", "DD");
            Efnts.setCharAt(i+2 - 1, FONT_PERIOD);
            }
         else if (!empty(name) && !isValidName(name))
            return setError(3, name.length(), "BADXXNAME", "DD");
         }

      // process all the DD card fields
      card &= ~CARD_LAST;                        // clear last_card indication
      do { // do until the entire card is processed...
         if (!get_next())
            return true;

         if (field_num < 2) {
            if (!empty(sub_key) &&
                (parm_key.equals("DCB") || parm_key.equals("LABEL"))) {
               if (sub_num < 2 && !mux_test(parm_key))
                  return setError(parm_key_offset, parm_key.length(), "CONFLICTINGDDPARM");
               key = sub_key;
               key_offset = sub_key_offset;
               }
            else {
               if (empty(parm_key)) {
                  key = value;
                  key_offset = value_offset;
                  }
               else {
                  key = parm_key;
                  key_offset = parm_key_offset;
                  }

               if (sub_num < 2 && !mux_test(key))
                  return setError(key_offset, key.length(), "CONFLICTINGDDPARM");
               if (Ekey_num != 0 && !dd_lvl_test(Ekey_num))
                  return false;
               }

            if (!empty(sub_key) && !sub_key.equals(key)) {
               if (!parm_key.equals("UNIT")  &&
                   !parm_key.equals("VOL")   &&
                   !parm_key.equals("VOLUME"))
                  return setError(sub_key_offset, sub_key.length(), "BADKWPARM");
               }
            }//end "field_num < 2"

         // Process the value
         if (Ekey_num != 0)
            switch (findJCLWord(DDKeyTable, key)) {
            case DDKEY_STAR:
            case DDKEY_DATA:
               if (sub_num > 1)
                  return setError(value_offset, value.length(), "UNEXPECTEDPOSPARM");
               ulEClass |= classInstream;
               Estream_type = key.equals("*") ? '*': 'D';
               break;

            case DDKEY_DUMMY:
            case DDKEY_DYNAM:
               if (sub_num > 1)
                  return setError(value_offset, value.length(), "UNEXPECTEDPOSPARM");
               break;

            case DDKEY_DISP:
               if (!symbolic) {
                  if (sub_num == 1 &&
                      !isValueIn(" NEW OLD SHR MOD "))
                     return setError(value_offset, value.length(), "BADDISPSTATUS");
                  if (sub_num == 2 &&
                      !isValueIn(" DELETE KEEP PASS CATLG UNCATLG "))
                     return setError(value_offset, value.length(), "BADNORMALDISP");
                  if (sub_num == 3 &&
                      !isValueIn(" DELETE KEEP CATLG UNCATLG "))
                     return setError(value_offset, value.length(), "BADABNORMALDISP");
                  }
               break;

            case DDKEY_DSN:
            case DDKEY_DSNAME:
            case DDKEY_LIKE:
               if (!symbolic && !isValidDsName(value))
                  return setError(value_offset,value.length(), "BADDATASET");
               break;

            case DDKEY_SYSOUT:
               if (!symbolic) {
                  if (sub_num == 1) {
                     if (!value.equals("*") &&
                         (!value.equals("$") || !fEjes2) &&
                         !isValidClass(value))
                        return setError(value_offset, value.length(), "BADSYSOUTCLASS");
                     }
                  else if (sub_num == 2 && !isValidName(value))
                     return setError(value_offset, value.length(), "BADSYSOUTWRITER");
                  else if (sub_num == 3 && !isValidCode(value))
                     return setError(value_offset, value.length(), "BADSYSOUTFORM");
                  }
               break;

            case DDKEY_UNIT:
               if (symbolic)
                  break;
               if (empty(sub_key)) {
                  if (sub_num == 1 && value.length() > 8)
                     return setError(value_offset, value.length(), "BADUNIT");
                  if (sub_num == 2 &&
                      !empty(value) &&
                      !value.equals("P") &&  // *as*
                      !isNumber(value, 1, 59))
                     return setError(value_offset, value.length(), "BADUNITCOUNT");
                  if (sub_num == 3 && !isValueIn(" DEFER "))
                     return setError(value_offset,value.length(), "XXEXPECTED", "DEFER");
                  }
               else if (sub_key.equals("AFF")) {
                  if (!isValidName(value))
                     return setError(value_offset, value.length(), "BADXXNAME", "DD");
                  }
               else
                  return setError(sub_key_offset, sub_key.length(), "BADSUBPARMKW");
               break;

            case DDKEY_VOL:
            case DDKEY_VOLUME:
               if (symbolic)
                  break;
               if (empty(sub_key)) {
                  if (sub_num == 1 && !isValueIn(" PRIVATE "))
                     return setError(value_offset, value.length(), "XXEXPECTED", "PRIVATE");
                  if (sub_num == 2 && !isValueIn(" RETAIN "))
                     return setError(value_offset, value.length(), "XXEXPECTED", "RETAIN");
                  if (sub_num == 3 &&
                      !empty(value) && !isNumber(value, 1, 255))
                     return setError(value_offset, value.length(), "BADVOLSEQ");
                  if (sub_num == 4 &&
                      !empty(value) && !isNumber(value, 1, 255))
                     return setError(value_offset,value.length(), "BADVOLCOUNT");
                  }
               else if (sub_key.equals("SER")) {
                  if (value.length() > 8 ||
                      (value.length() > 6 && value.charAt(0) != '\''))
                     return setError(value_offset, value.length(),
                                     "BADVOLSER" /* to add %1 value ?! */);
                  }
               else if (sub_key.equals("REF")) {
                  if (!isBackReference(value))
                     return setError(value_offset, value.length(),
                                     "BADBACKREF" /* to add %1 value ?! */);
                  }
               else
                  return setError(sub_key_offset, sub_key.length(), "BADVOLSUBKW");
               break;

            case DDKEY_SPACE:
               if (symbolic)
                  break;
               i = -1;
               if (sub_num == 1 && !isValueIn(" TRK CYL ") &&
                   !isNumber(value, 1, 65535))
                  return setError(value_offset, value.length(), "TRKEXPECTED");
               if (sub_num == 2 && field_num == 1 &&
                   !isNumber(value, 1, 99999999))
                  return setError(value_offset, value.length(), "BADPRIMSPACE");
               if (sub_num == 2 && field_num == 2 &&
                   !isNumber(value, 0, 99999999) &&
                   // @as 7/98 nothing after ',' OK: "// SPACE=(TRK,(1,)),"
                   !value.equals(")"))
                  return setError(value_offset, value.length(), "BADSECONDSPACE");
               if (sub_num == 2 && field_num == 3 &&
                   !isNumber(value, 0, 99999999))
                  return setError(value_offset, value.length(), "BADDIRSPACE");
               if (sub_num == 3 && !isValueIn(" RLSE "))
                  return setError(value_offset, value.length(), "XXEXPECTED", "RLSE");
               if (sub_num == 4 && !isValueIn(" CONTIG MXIG ALX "))
                  return setError(value_offset, value.length(), "CONTIGEXPECTED");
               if (sub_num == 5 && !isValueIn(" ROUND "))
                  return setError(value_offset, value.length(), "XXEXPECTED", "ROUND");
               break;

            case DDKEY_DDNAME:
               if (!symbolic && !isValidName(value))
                  return setError(value_offset, value.length(), "BADXXNAME", "DD");
               break;

            case DDKEY_LABEL:
               if (symbolic)
                  break;
               if (sub_num == 1 && !empty(value) && !isNumber(value, 1,9999))
                  return setError(value_offset,value.length(), "BADDATASETSEQ");
               if (sub_num == 2 &&
                   !isValueIn(" SL SUL AL AUL NSL NL BLP LTM "))
                  return setError(value_offset, value.length(), "BADLABELTYPE");
               if (sub_num == 3 && !isValueIn(" PASSWORD NOPWREAD "))
                  return setError(value_offset, value.length(), "PWDIFANY");
               if (sub_num == 4 && !isValueIn(" IN OUT "))
                  return setError(value_offset, value.length(), "NOINOUT");
               break;

            case DDKEY_EXPDT:
               if (symbolic)
                  break;
   // *as*     if (value.length() == 5 && isNumber(value, 1, 99999) &&
   // *as*         substr(value, 3) != "000" &&
   // *as*         substr(value, 3) <= "366")
   // *as*        {}
   // *as*     else if (value.length() == 8 &&
   // *as*         value.charAt(5-1) == '/' &&
   // *as*         isNumber(substr(value, 1, 4), 1900, 2155) &&
   // *as*         isNumber(substr(value, 6, 3), 1, 366))
   // *as*        {}
   // *as*     else
   // *as*        return setError(value_offset,value.length(),"BADEXPDT");
               break;

            case DDKEY_RETPD:
               if (!symbolic && !empty(value) && !isNumber(value, 1, 9999))
                  return setError(value_offset,value.length(), "BADRETENTION");
               break;

            case DDKEY_DLM: {                            /* dd [data | *] DLM= */
               if (symbolic)
                  break;
               // redo this? --original author.  And, handle all below??!? --*as*:
               //  ok:  'xx'  ''''  '&&&&'  '''&&'  '&&'''  &&&&  &&x  x&&
               //  nop: ''x   x''   ''&&    &&''    '''''' (this one valid at all?)

               // extract <'>value<'>, or convert '''' => ''
               if (value.length() > 1 &&
                   value.charAt(0) == '\'' && value.charAt(value.length()-1) == '\'') {
                  if (value.length() > 2)
                     value = value.substring(1, value.length()-1);
                  }
               // convert <&& ..> => <& ..>
               if (value.length() > 1 && value.charAt(0)=='&' && value.charAt(1)=='&')
                  value = value.substring(1);
               // convert <.. &&> => <.. &>
               if (value.length() > 2 &&
                   value.charAt(value.length()-1)=='&' &&
                   value.charAt(value.length()-2)=='&')
                  value = value.substring(0, value.length()-1);
               // now we've got a final delimiter string...
               if (value.length() != 2)
                  return setError(value_offset, value.length(), "BADDELIMITER");
               data_dlm = value;
               }
               break;

            case DDKEY_DCB:
               if (symbolic)
                  break;
               if (!empty(value) && value.charAt(0) == '*') {
                  if (!isBackReference(value))
                     return setError(value_offset,value.length(), "BADBACKREF");
                  }
               else if (!isValidDsName(value))
                  return setError(value_offset, value.length(), "BADDATASET");
               break;

            case DDKEY_LRECL:
            //case DDKEY_BLKSIZE moved vv, BLKSIZE=0 is OK says a user?! @as 11/96
            case DDKEY_BUFL:
               if (!symbolic && !isNumber(value, 1, 32760))
                  return setError(value_offset, value.length(), "BADVALUE1TOXX", "32760");
               break;

            case DDKEY_BLKSIZE:
               if (!symbolic && !isNumber(value, 0, 32760))
                  return setError(value_offset, value.length(), "BADVALUE0TOXX", "32760");
               break;

            case DDKEY_RECFM:
               if (!symbolic &&
                   !isValueIn(
             " U F FB FS FBS V VB VS VBS UA FA FBA FSA FBSA VA VBA VSA VBSA " +
             "UM FM FBM FSM FBSM VM VBM VSM VBSM UT FT FBT FBST VT VBT VBST UTA " +
             "FTA FBTA FBSTA VTA VBTA VBSTA UTM FTM FBTM FBSTM VTM VBTM VBSTM "))
                  return setError(value_offset, value.length(), "RECFORMAT");
               break;

            case DDKEY_DSORG:
               if (!symbolic &&
                   !isValueIn(" PS PO DA IS CX GS PSU POU DAU ISU "))
                  return setError(value_offset, value.length(), "BADDATASETORG");
               break;

            case DDKEY_TERM:
               if (!symbolic && !isValueIn(" TS "))
                  return setError(value_offset, value.length(), "TERMTSEXPECTED");
               break;

            case DDKEY_ACCODE: {
               String TEST_ACCODE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
               if (!symbolic &&
                   (empty(value) || value.length() > 8 ||
                    TEST_ACCODE.indexOf(value.charAt(0)) < 0))
                  return setError(value_offset, value.length(), "BADACCODE");
               }
               break;

            case DDKEY_AVGREC:
               if (!symbolic && !isValueIn(" U K M "))
                  return setError(value_offset, value.length(), "NOTUKM");
               break;

            case DDKEY_BURST:
               if (!symbolic && !isValueIn(" YES Y NO N "))
                  return setError(value_offset, value.length(), "NOTYESNO");
               break;

            case DDKEY_CHARS:
               if (!symbolic && !isValidCode(value))
                  return setError(value_offset, value.length(), "CHARTBL");
               break;

            case DDKEY_CHKPT:
               if (!symbolic && !isValueIn(" EOV "))
                  return setError(value_offset, value.length(), "NOTEOV");
               break;

            case DDKEY_CNTL:
            case DDKEY_OUTPUT:
            case DDKEY_REFDD:
               if (!symbolic && !isBackReference(value))
                  return setError(value_offset,value.length(), "BADBACKREF");
               break;

            case DDKEY_DATACLAS:
            case DDKEY_MGMTCLAS:
            case DDKEY_STORCLAS:
               if (!symbolic && !isValidName(value))
                  return setError(value_offset, value.length(), "BADNAME");
               break;

            case DDKEY_DSID:
               if (!symbolic) {
                  if (sub_num == 1 && !isValidName(value))
                     return setError(value_offset, value.length(), "BADIDENTIFIER");
                  if (sub_num == 2 && !isValueIn(" V "))
                     return setError(value_offset,value.length(), "NOTV");
                  }
               break;

            case DDKEY_FCB:
               if (symbolic)
                  break;
               if (sub_num == 1 && !isValidCode(value))
                  return setError(value_offset, value.length(), "BADXXNAME", "FCB");
               if (sub_num == 2 && !isValueIn(" ALIGN VERIFY "))
                  return setError(value_offset, value.length(), "NOTALIGNVERIFY");
               break;

            case DDKEY_FLASH:
               if (symbolic)
                  break;
               if (sub_num == 1 && !isValidCode(value))
                  return setError(value_offset,value.length(), "BADOVERLAY");
               if (sub_num == 2 && !isNumber(value, 0, 255))
                  return setError(value_offset,value.length(), "BADFLASHCOUNT");
               break;

            case DDKEY_FREE:
               if (!symbolic && !isValueIn(" END CLOSE "))
                  return setError(value_offset, value.length(), "NOTENDCLOSE");
               break;

            case DDKEY_HOLD:
               if (!symbolic && !isValueIn(" YES Y NO N "))
                  return setError(value_offset, value.length(), "NOTYESNO");
               break;

            case DDKEY_MODIFY:
               if (!symbolic) {
                  if (sub_num == 1 && !isValidCode(value))
                     return setError(value_offset, value.length(), "BADMODULE");
                  if (sub_num == 2 && !isValueIn(" 0 1 2 3 "))
                     return setError(value_offset, value.length(), "NOT0TO3");
                  }
               break;

            case DDKEY_MSVGP:
               if (symbolic)
                  break;
               if (sub_num == 1 && !isValidName(value))
                  return setError(value_offset, value.length(), "BADGROUPID");
               if (sub_num == 2 && !isValidName(value))
                  return setError(value_offset, value.length(), "BADXXNAME", "DD");
               break;

            case DDKEY_OUTLIM:
            case DDKEY_BUFIN:
            case DDKEY_INTVL:
            case DDKEY_LIMCT:
            case DDKEY_NTM:
               if (!symbolic && !isNumber(value, 1, 16777215))
                  return setError(value_offset, value.length(), "NOTINTEGER");
               break;

            case DDKEY_PROTECT:
               if (!symbolic && !isValueIn(" YES Y "))
                  return setError(value_offset, value.length(), "NOTYES");
               break;

            case DDKEY_RECORG:
               if (!symbolic && !isValueIn(" KS ES RR LS "))
                  return setError(value_offset, value.length(), "NOTKSES");
               break;

            case DDKEY_SUBSYS:
               if (!symbolic && (sub_num == 1 && !isValidCode(value)))
                  return setError(value_offset,value.length(), "BADXXNAME", "SUBSYS");
               break;

            case DDKEY_UCS:
               if (symbolic)
                  break;
               if (sub_num == 1 && !isValidCode(value))
                  return setError(value_offset, value.length(), "BADUCSSET");
               if (sub_num == 2 && !isValueIn(" FOLD "))
                  return setError(value_offset, value.length(), "NOTFOLD");
               if (sub_num == 3 && !isValueIn(" VERIFY "))
                  return setError(value_offset, value.length(), "NOTVERIFY");
               break;

            case DDKEY_BFALN:
               if (!symbolic && !isValueIn(" F D "))
                  return setError(value_offset, value.length(), "NOTFD");
               break;

            case DDKEY_BFTEK:
               if (!symbolic && !isValueIn(" R D S E A "))
                  return setError(value_offset, value.length(), "BADBFTEK");
               break;

            case DDKEY_CPRI:
               if (!symbolic && !isValueIn(" R E S "))
                  return setError(value_offset, value.length(), "BADCPRI");
               break;

            case DDKEY_DEN:
               if (!symbolic && !isValueIn(" 1 2 3 4 "))
                  return setError(value_offset, value.length(), "BADDENSITY");
               break;

            case DDKEY_PRTSP:  // print spacing
               if (!symbolic && !isValueIn(" 0 1 2 3 "))
                  return setError(value_offset, value.length(), "SPACING");
               break;

            case DDKEY_DIAGNS:
               if (!symbolic && !isValueIn(" TRACE "))
                  return setError(value_offset, value.length(), "NOTTRACE");
               break;

            case DDKEY_BUFMAX:
               if (!symbolic && !isNumber(value, 2, 15))
                  return setError(value_offset, value.length(), "BADBUFMAX");
               break;

            case DDKEY_BUFNO:
            case DDKEY_GNCP:
               if (!symbolic && !isNumber(value, 1, 255))
                  return setError(value_offset, value.length(), "BADVALUE1TOXX", "255");
               break;

            case DDKEY_BUFOUT:
               if (!symbolic && !isNumber(value, 1, 15))
                  return setError(value_offset, value.length(), "BADVALUE1TOXX", "15");
               break;

            case DDKEY_BUFOFF:
               if (!symbolic &&
                   !isNumber(value, 1, 99) && !isValueIn(" L "))
                  return setError(value_offset, value.length(), "BADBUFOFF");
               break;

            case DDKEY_BUFSIZE:
               if (!symbolic && !isNumber(value, 31, 65535))
                  return setError(value_offset,value.length(), "BADBUFSIZE");
               break;

            case DDKEY_CYLOFL:
               if (!symbolic && !isNumber(value, 1, 99))
                  return setError(value_offset, value.length(), "BADVALUE1TOXX", "99");
               break;

            case DDKEY_EROPT:
               if (!symbolic && !isValueIn(" T ACC SKP ABE "))
                  return setError(value_offset, value.length(), "BADEROPT");
               break;

            case DDKEY_FUNC:
               if (!symbolic &&
                   !isValueIn(" I R P W WT RP RPD RW RWT PW PWXT RPW " +
                                   "RPWXT RPWD RWX RWXT PWX RPWX RWX "))
                  return setError(value_offset, value.length(), "BADFUNC");
               break;

            case DDKEY_IPLTXID:
               if (!symbolic && !isValidName(value))
                  return setError(value_offset, value.length(), "BADNAME");
               break;

            case DDKEY_MODE:
               if (!symbolic && !isValueIn(" C CO CR E EO ER "))
                  return setError(value_offset, value.length(), "BADFUNC");
               break;

            case DDKEY_NCP:
               if (!symbolic && !isNumber(value, 1, 99))
                  return setError(value_offset, value.length(), "BADVALUE1TOXX", "99");
               break;

            case DDKEY_OPTCD:
               // if (!symbolic) {
               //    /* EDITS not yet done... *as* */
               //    }
               break;

            case DDKEY_PCI:
               if (!symbolic && !isValueIn(" N R A X "))
                  return setError(value_offset, value.length(), "NOTNRAX");
               break;

            case DDKEY_RESERVE:
            case DDKEY_KEYLEN:
               if (!symbolic && (sub_num >= 3 || !isNumber(value, 0, 255)))
                  return setError(value_offset, value.length(), "BADVALUE0TOXX", "255");
               break;

            case DDKEY_RKP:
            case DDKEY_KEYOFF:
               if (!symbolic && !isNumber(value, 0, 32760))
                  return setError(value_offset, value.length(), "BADVALUE0TOXX", "32760");
               break;

            case DDKEY_STACK:
               if (!symbolic && !isValueIn(" 1 2 "))
                  return setError(value_offset, value.length(), "NOT12");
               break;

            case DDKEY_THRESH:
               if (!symbolic && !isNumber(value, 1, 99))
                  return setError(value_offset, value.length(), "BADVALUE1TOXX", "99");
               break;

            case DDKEY_TRTCH:
               if (!symbolic && !isValueIn(" C E T ET "))
                  return setError(value_offset, value.length(), "NOTCETET");
               break;

            case DDKEY_DEST:
               if (!symbolic && !isValidName(value))
                  return setError(value_offset, value.length(), "BADNODE");
               break;

            case DDKEY_QNAME:
               if (symbolic)
                  break;
               i = value.indexOf('.')+1;
               if (i != 0) {
                  String name1;
                  if (!isValidName(value.substring(i+1 - 1)))
                     return setError(value_offset,value.length(), "BADTCAMJOB");
                  name1 = value.substring(0,i-1);
                  if (!isValidName(name1))
                     return setError(value_offset, value.length(), "BADXXNAME", "TPROCESS");
                  }
               else if (!isValidName(name))
                  return setError(value_offset, value.length(), "BADTCAMJOB");
               break;

            case DDKEY_SECMODEL:
               if (!symbolic) {
                  // if (sub_num == 1) {
                  //    /* RACF profile *as* */
                  //    }
                  if (sub_num == 2 && !isValueIn(" GENERIC "))
                     return setError(value_offset, value.length(), "NOGENERIC");
                  }
               break;

            case DDKEY_AMP:
               // if (!symbolic) {
               //    /* AMP check here *as* */
               //    }
               break;

            case DDKEY_COPIES:
               if (symbolic)
                  break;
               if (sub_num == 1 && !empty(value) && !isNumber(value, 1, 255))
                  return setError(value_offset, value.length(), "COPYCNT");
               if (sub_num > 1 && !isNumber(value, 1, 255))
                  return setError(value_offset, value.length(), "BADVALUE1TOXX", "255");

               break;

            case DDKEY_SEGMENT:
               if (fExa)
                  return setError(parm_key_offset, parm_key.length(), "DDKW");
               if (!symbolic && !isNumber(value, 0, 99999999))
                  return setError(value_offset, value.length(), "BADPAGECOUNT");
               break;

            case DDKEY_SPIN:
               if (fExa)
                  return setError(parm_key_offset, parm_key.length(), "DDKW");
               if (!symbolic && !isValueIn(" UNALLOC NO "))
                  return setError(value_offset, value.length(), "NOTUNALLOC");
               break;

            case DDKEY_PATH:
            case DDKEY_PATHDISP:
            case DDKEY_PATHMODE:
            case DDKEY_PATHOPTS:
            case DDKEY_DSNTYPE:
            case DDKEY_FILEDATA:
            case DDKEY_LGSTREAM:
            case DDKEY_RLS:
               // *as*
               break;

            default:                                   /* no routine for the key */
               break;
            } /* end "if (Ekey_num != 0) switch key" */

         else {                                                /* key number = 0 */
            // if (!symbolic && key != '') { *as*
            if (!symbolic && !empty(key)) {
               if (!empty(parm_key)) {
                  if (!key.equals(parm_key))
                     return setError(sub_key_offset, sub_key.length(),
                             "UNKNOWNSUBPARM" /* to add %1 parm_key ?! */);
                  return setError(parm_key_offset, parm_key.length(), "DDKW");
                  }
               else
                  return setError(value_offset, value.length(),
                          (parm_num == 1) ? "DDPOSPARM" : "TOOMANYPOSPARMS");
               }
            }
         } while (!endOfCard); /* end "do while !endOfCard" */

      setComments(cur_offset);             // comments from col cur_offset on...
      return true;
   }


   /**
    * Process the card with the expected delimiter.
    * Called when processing in-stream data: (card & CARD_DATA) != 0.
    * @return true = all OK, false = error
    */
   private boolean     dlm_proc()
   {
      ulEClass |= classJcl | classDlm;                       // class = jcl, dlm

      // 1.- JES2 control statement?! - e.g., "/*JOBPARM"
      if (fEjes2 && data_dlm.equals(DEFAULT_DLM) && Etxt.charAt(3-1) != ' ')
         // a JES2 control stmt should never be part of an in-stream
         return setError(1, 72, "JES2STMT");        // misplaced JES2 statement.

      // 2.- delimiter statement, ending DATA - e.g., "/* [comments]"
      Efnts.setCharAt(0, FONT_DELIMITER);
      Efnts.setCharAt(1, FONT_DELIMITER);
      // if (fEreformat)
      //  Etxt = lotxt; // use original text
      data_dlm = DEFAULT_DLM;                 // restore previous data delimiter
      setComments(3);                               // comments from col 3 on...
      return true;
   }


   /**
    * Process an in-stream data card.
    * Set in-stream class (this will keep setting following card to CARD_DATA),
    * set the in-stream style.
    */
   private boolean     instream_proc()
   {
      ulEClass |= classInstream;                                 // class = data
      // if (fEreformat)
      //  Etxt = lotxt; // use original text
      for (int i = 0;  i < 72;  i++)
         Efnts.setCharAt(i, FONT_INSTREAM);
      return true;
   }


   /**
    * Process a comment card.
    * @return true = all OK, false = error
    */
   private boolean     comment_proc()
   {
      ulEClass |= classJcl | classComment;               // class = jcl, comment
      if ((card & CARD_SPLIT) != 0)
         return setError(1, 72, "QUOTEDCONTEXPECTED");

      // if (fEreformat)
      //  Etxt = lotxt; // use original text
      if ((card & CARD_FIRST) == 0)
         card &= ~CARD_LAST;            // continue (clear last_card indication)
      for (int i = 0;  i < 72;  i++)
         Efnts.setCharAt(i, FONT_COMMENT);
      return true;
   }


   private boolean     null_proc()
   {
      ulEClass |= classNull;                                     // class = null
      return true;
   }

   /**
    * @return true = all OK, false = error
    */
   private boolean     proc_proc()
   {
      ulEClass |= classProc;
      if ((card & CARD_FIRST) != 0) {
         if (!isValidName(name))
            return setError(3, name.length(), "BADXXNAME", "PROC");
         setFonts(3, name.length(), FONT_PROCNAME);
         key_list = " ";
         }

      // process all the PROC card fields
      card &= ~CARD_LAST;                          // clear last card indication
      do { // do until the entire card is processed...
         if (!get_next())
            return true;

         if (!empty(parm_key) && sub_num == 1 && field_num < 2) {
            if (indexStrBB(key_list, parm_key) != 0)
               return setError(parm_key_offset, parm_key.length(), "DUPLICATEKW");
            key_list += parm_key + " ";
            }

         if (!empty(parm_key)) {
            if (parm_key_offset > 1 && sub_num == 1 && field_num < 2 ) {
               if (parm_key.length() > 8 || !isValidName(parm_key)) {
                  //return
                  setError(parm_key_offset, parm_key.length(), "BADSYMPARMNAME");
                  }
               else {
                  parm_key_offset = setFonts(parm_key_offset, parm_key.length(),
                                             FONT_KEYWORDSYM);
                  }
               }
            }
         else // empty(parm_key)
            endOfCard = true;

         } while (!endOfCard);

      setComments(cur_offset);             // comments from col cur_offset on...
      return true;
   }


   private void        pend_proc()
   {
      ulEClass |= classPend;
      setComments(cur_offset);             // comments from col cur_offset on...
      // nothing more to do.
   }


   /**
    * Process an OUTPUT-statement card.
    */
   private void        output_proc()
   {
      ulEClass |= classOutput;                               // lots to do! *as*

      // for now, at least check if statement continues onto the next card
      int i;
      for (i=80-1; i>0 && Etxt.charAt(i)==' '; i--) {} //(always stuff in Etxt!)
      if (Etxt.charAt(i) == ',')
         card &= ~CARD_LAST;                     // clear last_card indication
   }


   private void        xmit_proc()
   {
      ulEClass |= classXmit;
      // this has DEST and DLM keywords only, should be easy to do *as*
   }


   private void        cntl_proc()
   {
      ulEClass |= classCntl;
      /* check for * ?? *as* */
      setComments(cur_offset);             // comments from col cur_offset on...
   }


   private void        endcntl_proc()
   {
      ulEClass |= classEndcntl;
      setComments(cur_offset);             // comments from col cur_offset on...
      /* nothing more to do */
   }

   /**
    * @return true = all OK,
    *         false = error
    */
   private boolean     command_proc(String operat)
   {
      ulEClass |= classCommand;                                    // to do *as*
      for (int i = 2;  i < 71;  i++)   //memset(Efnts+2, FONT_COMMAND, 69);
         Efnts.setCharAt(i, FONT_COMMAND);
      if (!empty(name) && !operat.equals("COMMAND"))
         return setError(3, name.length(), "NOOPERNAME");
      setComments(cur_offset);             // comments from col cur_offset on...
      return true;
   }


   private void        if_then_proc()
   {
      ulEClass |= classCond;                                       // to do *as*
      setComments(cur_offset);             // comments from col cur_offset on...
   }


   private void        else_proc()
   {
      ulEClass |= classCond;
      /* nothing more to do */
      setComments(cur_offset);             // comments from col cur_offset on...
   }


   private void        endif_proc()
   {
      ulEClass |= classCond;                                       // to do *as*
      /* nothing more to do */
      setComments(cur_offset);             // comments from col cur_offset on...
   }


   private void        include_proc()
   {
      ulEClass |= classLib;                                        // to do *as*
      setComments(cur_offset);             // comments from col cur_offset on...
   }


   private void        jcllib_proc()
   {
      ulEClass |= classLib;                                        // to do *as*
      //setComments(cur_offset); why set as comments?! for now, just leave it!?
   }


   /**
    * Process a SET-statement card.
    */
   private void        set_proc()
   {
      ulEClass |= classCond;                                       // to do *as*
      //setComments(cur_offset); why set as comments?! for now, just leave it!?

      // check if statement continues onto the next card
      int i = 70;
      while (i >= cur_offset-1 && Etxt.charAt(i) == ' ')
         i--;
      if (Etxt.charAt(i) == ',')
         card &= ~CARD_LAST;                       // clear last_card indication
   }


   /**
    * Process JES2 Command and Control statements.
    * @return  true  = all OK,
    *          false = syntax error found
    */
   private boolean     jes2_proc()
   {
      ulEClass |= classJes2;                                     // class = jes2

      // 1.- JES2 command statement:
      // /*$TRDR1,H=Y
      if (Etxt.charAt(3-1) == '$') {
         ulEClass |= classCommand;
         for (int i = 0;  i < 71;  i++)
            Efnts.setCharAt(i, FONT_COMMAND);
         return true;
         }

      // 2.- JES2 control statement:
      // /*JOBPARM  LINES=60,ROOM=4222,TIME=50,PROCLIB=PROC03,COPIES=5
      ulEClass |= classControl;
      for (int i = 0;  i < 71;  i++)
         Efnts.setCharAt(i, FONT_CONTROL);

      if (name.equals("JOBPARM") || name.equals("MESSAGE")  ||
          name.equals("NETACCT") || name.equals("NOTIFY")   ||
          name.equals("OUTPUT")  || name.equals("PRIORITY") ||
          name.equals("ROUTE")   || name.equals("SETUP")    ||
          name.equals("SIGNOFF") || name.equals("SIGNON")   ||
          name.equals("XEQ")) {
         return true;
         }

      if (name.equals("XMIT")) {
         // to be done - treat as data *as*
         return true;
         }

      return setError(3, name.length(), "JES2CONTROL");
   }


   /**
    * Process JES3 Command and Control statements.
    * On input, name is e.g., "SIGNON" for a "/*SIGNON .." JES3 statement,
    * or "*DATASET" for a "//*DATASET .." JES3 statement.
    *
    * @return  false = finished with the card, a JES3 statement indeed;
    *          true  = must still process the card, it is not a JES3...
    */
   private boolean     jes3_proc()
   {
      // 1.- JES3 SIGNON/SIGNOFF statement:
      // /*SIGNON       QUIN  A  PSWD1     PSWD2
      if (name.equals("SIGNOFF") ||
          name.equals("SIGNON")) {
         ulEClass |= classJes3 | classControl;
         for (int i = 0;  i < 71;  i++)
             Efnts.setCharAt(i, FONT_CONTROL);
         return false;      // = finished with card, goto set_element when back.
         }

      if (name.length() > 1) {    // (there may be no name if source screwed...)
         name = name.substring(1);      // prefix is longer ("//*"), adjust name
         if (!empty(name) && (card & CARD_FIRST) != 0) {
            String TEST_NAME = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            // 2.- JES3 command statement:
            // //**VARY,280,OFFLINE
            if (name.charAt(0) == '*' && name.length() > 1 &&
                TEST_NAME.indexOf(name.charAt(1)) >= 0) {
               ulEClass |= classJes3 | classCommand;        // class = jes3, cmd
               for (int i = 0;  i < 71;  i++)
                  Efnts.setCharAt(i, FONT_COMMAND);
               return false;// = finished with card, goto set_element when back.
               }

            // 3.- JES3 control statement:
            // //*DATASET DDNAME=MYPRINT,J=YES
            else {
               if (name.equals("DATASET")    ||
                   name.equals("ENDDATASET") ||
                   name.equals("ENDPROCESS") ||
                   name.equals("FORMAT")     ||
                   name.equals("MAIN")       ||
                   name.equals("NET")        ||
                   name.equals("NETACCT")    ||
                   name.equals("OPERATOR")   ||
                   name.equals("PROCESS")    ||
                   name.equals("ROUTE")) {
                  // handle continuation setting here *as*
                  ulEClass |= classJes3 | classControl;
                  for (int i = 0;  i < 71;  i++)
                     Efnts.setCharAt(i, FONT_CONTROL);
                  return false; // = done with card, goto set_element when back.
                  }
               }
            }
         }

      // handle jes3 continuations
      if ((card & CARD_JES3) != 0  &&  (card & CARD_FIRST) == 0) {
         ulEClass |= classJes3 | classControl;
         for (int i = 0;  i < 71;  i++)
            Efnts.setCharAt(i, FONT_CONTROL);
         return false;  // = finished with the card, goto set_element when back.
         }

      return true;                           // the card is not a JES3 thingy...
   }

   /**
    * Strip the next parameter or sub-parameter;
    * cur_offset is advanced to the next parameter.
    *
    * @return false = error,
    *         true  = all okay so far
    *         endOfCard - may be set to true
    *         symbolic  - may be set to true, for symbolic name parm (&AA)
    */
   private boolean     get_next()
   {
      String  split_value = "";
      String  token;
      char    c, c1;
      char    fc;                                              // font character
      int     sym_lng = 0;            // length of symbolic name as being parsed

      /*=============================*/
      /*  clear up after last value  */
      /*=============================*/
      if (endOfSubparameters) {
         endOfSubparameters = Esub_p = false;
         endOfFields = true;
         sub_num = 0;
         }
      if (endOfFields) {
         endOfFields = field_p = false;
         field_num = 0;
         }

      /*===========================================*/
      /*  bump the parm, subparm and field number  */
      /*===========================================*/
      if (!in_quote) {
         if (field_num > 0)
            field_num++;
         else {
            sub_key = "";                                       // sub_key = ""
            sub_key_offset = 1;
            if (sub_num > 0)
               sub_num++;
            else {
               parm_key = "";                                   // parm_key = ""
               parm_key_offset = 1;
               parm_num++;
               }
            }
         value = "";
         symbolic = false;
         }

      int cur = cur_offset;           // pointer used to parse the current token
      endOfCard = false;

      /*=====================*/
      /*  parse to get next  */
      /*=====================*/
      String DELIMITER = ",=() ";
      value_offset = 1;
      boolean skip_amper = false;                                   // skip '&'?
      while (value_offset <= 1) {
         c = Etxt.charAt(cur-1);

         /*-------------------------------------------------------------------*/
         /*  gather a token UNTIL                                             */
         /*   end_of_quote (or col71) / if not_in_quote until a delimiter...  */
         /*-------------------------------------------------------------------*/
         while (in_quote || DELIMITER.indexOf(c) < 0) {
            if (c == '&') {
               if (skip_amper)
                  skip_amper = false;
               else {
                  String TEST_SYMBOL = "ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$";
                  // peek at the char following the one being processed now:
                  c1 = Etxt.charAt(cur + 1-1);
                  // 1.- yet another &
                  // REF: Code each apostrophe and ampersand that is part of the
                  // subparameter as two consecutive apostrophes or ampersands;
                  // for example, code 3462&5 as PARM='3462&&5'.
                  if (c1 == '&')
                     skip_amper = true;
                  // 2.- a program-call quoted PARM='...': let *anything* go, it
                  // is passed as is to pgm, don't parse (VA COBOL, STL 2/2000):
                  // //GO     EXEC  PGM=CALCPRG,
                  // // REGION=64000K,PARM=('/TEST(,,,VADTCPIP&9.112.21.151:*)')
                  else if (parm_key.equals("PARM")) {
                     }
                  // 3.- an alphabetic / @ / # / $ (forming a symbolic name)
                  else if (TEST_SYMBOL.indexOf(c1) >= 0) {
                     Efnts.setCharAt(cur-1, FONT_SYMBOLIC); // a (new) symbolic starts
                     c = c1;
                     cur++;
                     sym_lng = 1;
                     symbolic = true;
                     }
                  // 4.- allow a '&', like in:  //STEP    EXEC PARM='&'
                  else if (in_quote && c1 == '\'') {
                     }
                  // 5.- bad something...
                  else {
                     //System.out.println(" BADSYMPARMNAME symbolic="+symbolic+
                     //   " sym_lng="+sym_lng+" c1="+c1+" park_key="+parm_key);
                     return setError(cur_offset, cur-cur_offset +1, "BADSYMPARMNAME");
                     }
                  }
               }//end of c=='&'

            if (in_quote) {
               fc = FONT_QUOTEDSTRING;
               Etxt.setCharAt(cur-1, lotxt.charAt(cur-1)); // we don't reformat, needed??
               if (c == '\'') {
                  in_quote = false;
                  c1 = Etxt.charAt(cur + 1-1);     // peek at the next character
                  if (c1 != ',' && c1 != '='  && c1 != '(' && c1 != ')' &&
                      c1 != ' ' && c1 != '\'' && c1 != '&')
                     return setError(cur_offset, cur-cur_offset +1, "NODELIMITER");
                  }
               else if (cur > 71) {            // cont quote text ends in col 71
                  if (fEesa) { // 1.- handle esa continuations here
                     //split_value=lotxt.substring(cur_offset-1,cur-1);what for?
                     cur_offset = cur+1;       // so no setComments() over quote
                     endOfCard = true;         // no more stuff on this card
                     // NB in_quote is still true!
                     return true;
                     }
                  else         // 2.- unbalanced quote
                     return setError(1, cur, "QUOTE");
                  }
               }//end of in_quote

            // not yet in_quote
            else if (c == '\'') {
               in_quote = true;              // parsing in_quote starting now...
               fc = FONT_QUOTEDSTRING;
               }

            else
               fc = FONT_VALUE;

            // we're within a symbolic name
            if (sym_lng > 0) {
               String TEST_SYMBDOT = "ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$1234567890.";
               if (TEST_SYMBDOT.indexOf(c) >= 0) {
                  fc = FONT_SYMBOLIC;
                  if (c == '.')
                     sym_lng = 0;
                  else
                     sym_lng++;
                  if (sym_lng > 9) {
                     String TEST_SYMB = "ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$1234567890";
                     c1 = Etxt.charAt(cur + 1-1);  // peek at the following char
                     if (TEST_SYMB.indexOf(c) >= 0)
                        return setError(cur_offset, cur-cur_offset +1, "SYMPARMLEN");
                     }
                  }
               else
                  sym_lng = 0;
               }

            if (c == '.' && fc == FONT_VALUE)
               fc = FONT_PERIOD;

            Efnts.setCharAt(cur-1, fc);
            cur++;
            c = Etxt.charAt(cur-1);
            }/*end "while in_quote"*/

         // save the token gathered
         token = Etxt.toString().substring(cur_offset - 1,
                                           cur - 1);

         /*-----------------------------------------------------------*/
         /*  now process the token, based on the following delimiter  */
         /*-----------------------------------------------------------*/
         switch(c) {
            case '(':
               if (!empty(token)) {
                  int i = (Etxt.toString().substring(cur-1)).indexOf(')')+1;
                  if (i == 0)
                     return setError(cur_offset, 72, "NOCHAR", ")");
                  // token = token | substr(Etxt,cur,i);
                  token += Etxt.toString().substring(cur-1, cur-1 + i);
                  cur += i;
                  c1 = Etxt.charAt(cur-1);
                  if (c1 != ',' && c1 != ' ')
                     return setError(cur_offset, token.length(), "NODELIMITER");
                  }
               else {
                  if (field_num > 0)
                     return setError(cur, 1, "BADCHAR", "(");
                  if (Esub_p) {
                     field_num = 1;
                     field_p = true;
                     Efnts.setCharAt(cur-1, FONT_RIGHTPAREN);
                     }
                  else {
                     sub_num = 1;
                     Esub_p = true;
                     Efnts.setCharAt(cur-1, FONT_LEFTPAREN);
                     }
                  cur++;
                  cur_offset = cur;
                  }
               break;

            case '=':
               if (field_num >0 )
                  return setError(cur, 1, "BADCHAR", "=");
               if (sub_num > 0) {
                  sub_key = token;
                  sub_key_offset = cur_offset;
                  cur_offset = setFonts(cur_offset, token.length(), FONT_SUBKEYWORD);
                  Efnts.setCharAt(cur-1, FONT_EQUALSIGN);
                  }
               else {
                  parm_key = token;
                  parm_key_offset = cur_offset;
                  sub_num = 1;
                  cur_offset = setFonts(cur_offset, token.length(), FONT_KEYWORD);
                  Efnts.setCharAt(cur-1, FONT_EQUALSIGN);
                  }
               cur++;
               cur_offset = cur;
               break;

            case ')':
               if (empty(value)) {
                  value = split_value + token;
                  }
               //if (in_dsn) //not set anywhere?!
               // Efnts.setCharAt(cur-1, FONT_RIGHTPAREN);
               //else
                  if (field_p && !endOfFields) {
                  endOfFields = true;
                  Efnts.setCharAt(cur-1, FONT_RIGHTPAREN);
                  }
               else if (Esub_p && !endOfSubparameters) {
                  endOfSubparameters = true;
                  Efnts.setCharAt(cur-1, FONT_LEFTPAREN);
                  }
               else
                  return setError(cur, 1, "BADCHAR", ")");
               cur++;
               c1 = Etxt.charAt(cur-1);
               if (c1 != ')' && c1 != ',' && c1 != ' ')
                  return setError(cur_offset, 1, "NODELIMITER");
               break;

            case ',':
            case ' ':
               if (empty(value))
                  value = split_value + token;
               value_offset = cur_offset;
               if (sub_num > 0 && !Esub_p)
                  endOfSubparameters = true;
               if (sub_key_offset > 1 && empty(sub_key))
                  return setError(value_offset, -1, "NOSUBPARMKW");
               if (parm_key_offset > 1 && empty(parm_key))
                  return setError(value_offset, -1, "PARMKWEXPECTED");

               if (c == ',') {
                  Efnts.setCharAt(cur-1, FONT_COMMA);
                  cur++;
                  cur_offset = cur;
                  if (Etxt.charAt(cur-1) == ' ')
                     endOfCard = true;
                  }
               else { /* c == ' ' */
                  cur_offset = cur;
                  endOfCard = true;
                  card |= CARD_LAST;  /* set stmt's last_card indication */
                  if ((field_p && !endOfFields) || (Esub_p && !endOfSubparameters))
                     return setError(cur, 1, "NOCHAR", ")");
                  }
               break;

            default:
               return setError(cur, 1, "NODELIMITER");
            }//end "switch(c)"
         }//end "while (value_offset <= 1)"

      //if (a debug parameter) {
      // dcl off fixed bin(31) init(cur_offset);
      // String m = 'Offset'+s(off)+' ';
      // if (!empty(parm_key) m += parm_key+'=';
      // if (!empty(sub_key)  m += '.'+sub_key+'=';
      // m += '"'+value+'", parm'+s(parm_num)+' sub'+s(sub_num)+
      //      ' field'+s(field_num)+' ';
      // if (Esub_p)      m += 'Esub_p ';
      // if (field_p)     m += 'field_p ';
      // if ((card & CARD_LAST) != 0) m += 'last_card ';
      // if (endOfSubparameters) m += 'endOfSubparameters ';
      // if (endOfFields) m += 'endOfFields ';
      // if (endOfCard)   m += 'endOfCard ';
      // System.out.println(m);
      // }
      //s(ss) returns (char(20) var) {
      // dcl ss fixed bin(31), c char(20) var init(ss);
      // while (substr(c,1,1) == ' ') {c=substr(c, 2);}
      // return (' '||c); }

      return true;
   }

   /**
    * Set <code>fchar</code> style in Efnts, starting at <code>col</code>, for
    * <code>len</code> characters.
    * @return  updated col past the fonts set
    */
   private int         setFonts(int col, int len, char fchar)
   {
      for (int i = col;  i <= col + len - 1;  i++)
         Efnts.setCharAt(i-1, fchar);

      return col+len;
   }

   /**
    * Set the rest of the card to comments.
    * @param  col  ONE-based column where any comments start
    */
   private void        setComments(int col)
   {
      if (!empty(Etxt.toString().substring(--col))) {
         //if (fEreformat) // even if reformatting, leave comments in lowercase
         // strcpy(Etxt+col, lotxt+col);
         for (int i = col;  i < 71;  i++)
            if (Etxt.charAt(i) != ' ')
               Efnts.setCharAt(i, FONT_COMMENT);
         }
      // *as* 5/99 - what about comments field continuing to the next line
      //             (when there is a non-blank character in column 72)??!
   }

   /**
    * Set an error message.
    * @return  false
    */
   private boolean     setError(int col, int len, String msg)
   {
      return setError(col, len, msg, null);
   }

   /**
    * Set an error message with a substitution string.
    * @return  false
    */
   private boolean     setError(int col, int lng, String msgId, String pcSubst)
   {
      ulEClass |= classError;                                 // set error class

      // It's the end for this statement.  Problem: if we do this, more error
      // messages will now show up in the following statement lines.  Take it
      // easier on poor JCL-writer, and don't clutter screen with red & pink:
      // card |= CARD_LAST;                                          @as 7/98

      if (lng < 0) {                                 // setting fonts backwards?
         lng = 0 - lng;
         col = (col <= lng) ? 1 : col - lng;
         }
      else if (lng == 0)
         lng = 1;

      // if (fEreformat)
      //  Etxt = lotxt; // don't upcase text in error, keep original

      boolean nb = false;                            // non-blank in error field
      int i;
      for (i = col;  i < col+lng && i > 0 && i <= 80;  i++) {
          Efnts.setCharAt(i-1, FONT_ERROR);
          if (Etxt.charAt(i-1) != ' ')
             nb = true;
          }

      if (!nb)                          // if no beef (non-blanks) in error area
         for (i = (col-1 < 80 ? col-1 : 80); // min(col-1, 80)
              i > 0 && Etxt.charAt(i-1) == ' ';
              i--) {
            Efnts.setCharAt(i-1, FONT_ERROR); // cover prev white space as well,
            col--;  lng++;                  // extend error's domain accordingly
            }

      if (col > Etxtl) {          // if error starts beyond actual line in LPEX
         lng += col - Etxtl;      //  lower col again, so min one err char shows
         col = Etxtl;
         if (col > 0)
            Efnts.setCharAt(col-1, FONT_ERROR);
         }

      msgId = getLanguage() + "." + msgId;
      String msg = null;
      if (pcSubst == null)
         msg = LpexResources.message(msgId);
      else
         msg = LpexResources.message(msgId, pcSubst);
      // msg = product prefix "JCL" + ID "059" + severity "I" + msg; // ?!? *as*

      addMessage(ECurLine, msg);
      return false;
   }

   /**
    * Test for <code>value</code> being in the <code>list</code>.
    */
   private boolean     isValueIn(String list)
   {
      return list.indexOf(" "+value+" ") >= 0;
   }

   /**
    * Validate a name.
    */
   private boolean     isValidName(String token)
   {
      String TEST_NAME = "ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$";
      if (token.length() == 0 || token.length() > 8 ||
          TEST_NAME.indexOf(token.charAt(0)) < 0    ||
          verify(token, "ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$0123456789") != 0)
         return false;

      return true;
   }

   /**
    * Validate a name with an optional period.
    */
   private boolean     isValidNameWithPeriod(String token)
   {
      int i = token.indexOf('.');
      if (i < 0)
         return isValidName(token);                  // no period, check token

      return (isValidName(token.substring(0, i)) &&  // verify each part around
              isValidName(token.substring(i+1)));    //  the period
   }

   /**
    * Test for a valid character code set.
    */
   private boolean     isValidCode(String token)
   {
      String TEST_CODE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$";
      if (token.length() == 0 || token.length() > 4 ||
          TEST_CODE.indexOf(token.charAt(0)) < 0    ||
          verify(token,  "ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$0123456789") != 0)
         return false;

      return true;
   }

   /**
    * Test for a valid data set name.
    */
   private boolean     isValidDsName(String token)
   {
      return true;                                                 // to do *as*
   }

   /**
    * Test for a valid backward reference.
    */
   private boolean     isBackReference(String token)
   {
      return true;                                                 // to do *as*
   }

   /**
    * Test for a valid class.
    */
   private boolean     isValidClass(String token)
   {
      return (token.length() == 1 &&
              verify(token, "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") == 0);
   }

   /**
    * Test for a valid integer between <code>min</code> and <code>max</code>.
    */
   private boolean     isNumber(String token, int min, int max)
   {
      if (token.length() == 0 || token.length() > 8 ||
          verify(token, "0123456789") != 0)
         return false;

      int i = Integer.valueOf(token).intValue();
      return (i >= min && i <= max);
   }

   /**
    * Test for a valid TSO user ID.
    */
   private boolean     isValidTsoUserId(String token)
   {
      if (token.equals("*") ||
          token.equals("&SYSUID"))
         return true;

      return (token.length() > 0 && token.length() < 8 &&
              verify(token, "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789$#@") == 0);
   }

   /**
    * Test for a valid password.
    */
   private boolean     isValidPassword(String token)
   {
      if (token.equals("*") || token.equals("????????"))
         return true;

      return (token.length() > 0 && token.length() <= 8 &&
              verify(token, "ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$0123456789") == 0);
   }

   /**
    * Test for mutually exclusive DD keywords.
    * Sets Ekey_num.
    * @return true - all OK.
    */
   private boolean     mux_test(String token)
   {
      String key = "         "; // nine blanks

      // first convert the input keyword to an integer
      if (token.equals("DSN"))
         key = "DSNAME";
      else if (token.equals("VOL"))
         key = "VOLUME";
      else if (token.length() < 9)
         key = token;

      int ix = indexStr(keytbl, key);
      Ekey_num = (ix - 1)/9;                                    // relative to 1
      if (Ekey_num == 0 || ix != (Ekey_num * 9) - 8)
         return true;                                                   // = OK.

      // now see if the keyword is allowed with what has been found so far
      // *as* if (Ekey_bits[Ekey_num-1])
      // *as*    return false;                                    // = CONFLICT.

      // now remember this keyword and all its conflicts
      // *as* key_bits = key_bits | conf_bits(Ekey_num);

      return true;                                                      // = OK.
   }

   /**
    * Test parentheses levels and sub-parm counts for DD parameters.
    * E.g.,
    *    //DD1  DD  PATHDISP=(KEEP,DELETE)
    * allows two values in the parm list for PATHDISP.
    * @return true  = all okay,
    *         false = error
    */
   private boolean     dd_lvl_test(int num)
   {
      char lvl = lvl_mask.charAt(num-1);
      if (lvl == ' ') {
         if ((Esub_p && !parm_key.equals("DCB")) || field_p)
            // parm-value list not allowed for DD parm.
            return setError(value_offset -1, 1, "BADPARMVALUELIST");
         }
      else {
         char c;
         char mxp = mxp_mask.charAt(num-1);
         if (sub_num >= 6)
            c = '6';
         else if (sub_num == 5)         // '1' to '5'
            c = '5';
         else if (sub_num == 4)
            c = '4';
         else if (sub_num == 3)
            c = '3';
         else if (sub_num == 2)
            c = '2';
         else if (sub_num == 1)
            c = '1';
         else
            c = '0';
         if (c > mxp)                   // too many parm-values in the list.
            return setError(value_offset -1, 1, "LISTPARMS");

         if (lvl == 'S' && field_p)     // sub-parm value list not allowed.
            return setError(value_offset -1, 1, "SUBPARMVALUELIST");

         if (lvl == 'F') {
            /* 6 = "COPIES" */
            if ((num == 6 && sub_num == 1 && field_p)                    ||
                (num == 8 && field_num > 2 &&
                 (sub_key.equals("PCI") || sub_key.equals("RESERVE")))   ||
                (num == 8 && field_p &&
                 (!sub_key.equals("PCI") && !sub_key.equals("RESERVE"))) ||
                (num == 28 && sub_num == 2 && field_num > 2)             ||
                (num == 28 && sub_num != 2 && field_p)                   ||
                (num == 34 && field_p && !sub_key.equals("SER")))
               return setError(value_offset-1, 1, "SUBPARMVALUELIST");

            // ?!?! block below commented out, else parser will flag e.g., this:
            // //A DD COPIES=1                                     ?!?! 2/97 @as
            //if (num == 6 && !field_p)
            // return setError(value_offset, value.length(), "PARENEXPECTED");
            }
         }

      return true;
   }

   /**
    * Extract one blank-delimited word from text.
    * @param  text  String to extract from
    * @return token
    */
   private String      extractToken(String text)
   {
      // how is caller sync-ing offset, if here liberally skipping spaces?? *as*
      StringTokenizer st = new StringTokenizer(text);
      if (st.hasMoreTokens())
         return st.nextToken();
      return "";
   }

   /**
    * Verify text based on charset:  if all the characters of text are in
    * charset, return 0;  else, return the ONE-origin index of the
    * first character that doesn't belong (a la strspn()).
    * @param  text     string to verify
    * @param  charset  character set allowed
    * @return 0 = all text in charset / ONE-origin index of char not in charset
    */
   private int         verify(String text, String charset)
   {
      for (int i = 0; i < text.length(); i++)
         if (charset.indexOf(text.charAt(i)) < 0)
            return i+1;
      return 0;
   }

   /**
    * @return true  = text is all blanks, if anything, or
    *         false = there is some meat in it
    */
   private boolean     empty(String text)
   {
      return text.trim().length() == 0;
   }

   /**
    * Return ONE-origin location of the first occurence of
    * <code>str</code> within <code>list</code>, or
    * <code>0</code> if not found.
    * @param  list  string to search
    *         str   string to look for
    * @return 0 = str not in list, or
    *         n = ONE-origin index of str in list
    */
   private int         indexStr(String list, String str)
   {
      return list.indexOf(str) + 1;
   }

   /**
    * Return ONE-origin location of the first occurence of
    * <code>' 'str' '</code> within <code>list</code>, or
    * <code>0</code> if not found.
    * @param  list  string to search
    *         str   string to look for
    * @return 0 = ' 'str' ' not in list, or
    *         n = its ONE-origin index in list
    */
   private int         indexStrBB(String list, String str)
   {
      return list.indexOf(" "+str+" ") + 1;
   }


   /**
    * Get a switch(word) case index from a JCL table.
    * @param  table  table of JCL keywords
    * @param  word   keyword sought
    * @return ONE-based index of word in table (0 = not found)
    */
   private int         findJCLWord(String table[], String word)
   {
      for (int i = 0;  i < table.length;  i++)
         if (table[i].equals(word))
            return i+1;
      return 0;
   }

   /**
    * Retrieve the name of the html help page that the parser identifies
    * as appropriate for the currently selected token.
    */
   public String       getHelpPage()
   {
      String helpPage = null;
      loadProperties();
      if (helpPages != null) {
         String token = getToken(view.documentLocation());
         if (token != null)
            helpPage = helpPages.getProperty(token);
         }
      return helpPage;
   }

   private static void loadProperties()
   {
      if (!properties_loaded) {
         helpPages = HelpCommand.loadHelpMap(HELP_JCL);
         // whether the load succeeded or not, there's no point
         // in trying again until LPEX is restarted
         properties_loaded = true;
         }
   }
}