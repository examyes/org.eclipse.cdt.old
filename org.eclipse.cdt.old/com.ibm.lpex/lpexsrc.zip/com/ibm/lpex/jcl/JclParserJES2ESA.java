//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// JclParserJES2ESA - document parser for JCL, JES2 ESA.
//----------------------------------------------------------------------------

package com.ibm.lpex.jcl;

import com.ibm.lpex.core.LpexView;


/**
 * Document parser for JES2 ESA flavoured MVS JCL.
 */
public class JclParserJES2ESA extends JclParser
{
   /**
    * Constructor.
    */
   public JclParserJES2ESA(LpexView lpexView)
   {
      super(lpexView);
   }

   /**
    * Query parser's system-specific JCL options.
    * This parser sets these options:  <b>JES2</b> as the Job entry subsystem,
    * and <b>ESA</b> for MVS/ESA JCL (JES level 4) being recognized.
    */
   public int getJclOptions()
   {
      return (OPTION_JES2 | OPTION_ESA);
   }
}