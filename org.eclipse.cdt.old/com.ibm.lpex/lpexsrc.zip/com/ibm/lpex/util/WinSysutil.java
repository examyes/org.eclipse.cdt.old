//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// WinSysutil - Windows-based system methods.
//----------------------------------------------------------------------------

package com.ibm.lpex.util;


/**
 * Windows-based system methods.
 */
public final class WinSysutil implements LpexSysutil.Sysutil
{
   /**
    * Attempt to load the native code for these utilities.
    */
   public WinSysutil()
   {
      System.loadLibrary("alxutils");
   }

   /**
    * Retrieve an environment variable.
    * @param var name of an environment variable
    * @return value of the environment variable
    */
   public native String getSysEnvVariable(String var);
}