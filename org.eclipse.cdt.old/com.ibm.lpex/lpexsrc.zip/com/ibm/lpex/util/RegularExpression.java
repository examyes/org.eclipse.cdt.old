//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// RegularExpression - regex for the find-text implementation.
//----------------------------------------------------------------------------

package com.ibm.lpex.util;

import java.util.BitSet;


/**
 * The class RegularExpression can be used to perform a regular expression search.
 */
public class RegularExpression
 {
  public static class PatternException extends Exception
   {
    public PatternException()
     {
      super();
     }
    public PatternException(String s)
     {
      super(s);
     }
   }

  private Expression _expression;
  private BitSet _firstCharacterMap = new BitSet(256); // map of possible first characters
  private boolean _anyCharacterFirst;

  /**
   * This constructor accepts a regular expression pattern which will be
   * used to perform a regular expression search.
   */
  public RegularExpression(String pattern, boolean ignoreCase) throws PatternException
   {
    if (pattern == null || pattern.length() == 0)
     {
      throw new PatternException("no pattern");
     }

    boolean first = true;
    StringComponent stringComponent = null;
    _expression = new Expression(null, first);
    Expression subexpression = _expression;

    for (int i = 0; i < pattern.length(); i++)
     {
      char c = pattern.charAt(i);
      boolean addCharToString = false;
      switch (c)
       {
        default:
         {
          addCharToString = true;
          break;
         }
        case '*':
         {
          if (subexpression._lastComponent == null ||
              !subexpression._lastComponent.repeatable())
           {
            throw new PatternException("'*' repeat not valid");
           }
          if (subexpression._lastComponent == stringComponent)
           {
            stringComponent.decoupleLastCharacter();
            stringComponent = null;
           }
          subexpression._lastComponent.setRepeat(0);
          first = true;
          break;
         }
        case '?':
         {
          if (subexpression._lastComponent == null ||
              !subexpression._lastComponent.repeatable())
           {
            throw new PatternException("'?' repeat not valid");
           }
          if (subexpression._lastComponent == stringComponent)
           {
            stringComponent.decoupleLastCharacter();
            stringComponent = null;
           }
          subexpression._lastComponent.setRepeat(0, 1);
          first = true;
          break;
         }
        case '+':
         {
          if (subexpression._lastComponent == null ||
              !subexpression._lastComponent.repeatable())
           {
            throw new PatternException("'+' repeat not valid");
           }
          if (subexpression._lastComponent == stringComponent)
           {
            stringComponent.decoupleLastCharacter();
            stringComponent = null;
           }
          subexpression._lastComponent.setRepeat(1);
          break;
         }
        case '{':
         {
          String intervalString = "{";
          int minRepeat = 0;
          int maxRepeat = 0;
          int i2;
          char c2 = '\0';
          for (i2 = i + 1; i2 < pattern.length(); i2++)
           {
            c2 = pattern.charAt(i2);
            intervalString += c2;
            if (c2 >= '0' && c2 <= '9')
             {
              minRepeat = minRepeat * 10 + c2 - '0';
             }
            else
             {
              i2++;
              break;
             }
           }
          if (i2 == i + 1)
           {
            addCharToString = true;
           }
          else if (c2 == '}')
           {
            maxRepeat = minRepeat;
           }
          else if (c2 != ',')
           {
            addCharToString = true;
           }
          else if (i2 < pattern.length() && pattern.charAt(i2) == '}')
           {
            intervalString += '}';
            i2++;
            maxRepeat = -1;
           }
          else
           {
            maxRepeat = 0;
            for (; i2 < pattern.length(); i2++)
             {
              c2 = pattern.charAt(i2);
              intervalString += c2;
              if (c2 >= '0' && c2 <= '9')
               {
                maxRepeat = maxRepeat * 10 + c2 - '0';
               }
              else
               {
                i2++;
                break;
               }
             }
            if (c2 != '}')
             {
              addCharToString = true;
             }
           }
          if ((maxRepeat != -1) && (maxRepeat < minRepeat || maxRepeat == 0))
           {
            addCharToString = true;
           }
          if (!addCharToString)
           {
            if (subexpression._lastComponent == null ||
                !subexpression._lastComponent.repeatable())
             {
              throw new PatternException(intervalString + " repeat not valid");
             }
            if (subexpression._lastComponent == stringComponent)
             {
              stringComponent.decoupleLastCharacter();
              stringComponent = null;
             }
            i = i2 - 1;
            subexpression._lastComponent.setRepeat(minRepeat, maxRepeat);
            if (minRepeat == 0)
             {
              first = true;
             }
           }
          break;
         }
        case '.':
         {
          if (subexpression.endOfLine())
           {
            throw new PatternException("expression follows $");
           }
          new AnyCharacterComponent(subexpression);
          if (first)
           {
            _anyCharacterFirst = true;
            first = false;
           }
          break;
         }
        case '^':
         {
          if (subexpression.endOfLine())
           {
            throw new PatternException("expression follows $");
           }
          new StartOfLineComponent(subexpression);
          if (first)
           {
            _anyCharacterFirst = true;
            first = false;
           }
          break;
         }
        case '$':
         {
          if (subexpression.endOfLine())
           {
            throw new PatternException("expression follows $");
           }
          new EndOfLineComponent(subexpression);
          if (first)
           {
            _anyCharacterFirst = true;
            first = false;
           }
          break;
         }
        case '\\':
         {
          if (i + 1 >= pattern.length())
           {
            throw new PatternException("\\ not valid");
           }
          i++;
          c = pattern.charAt(i);
          addCharToString = true;
          break;
         }
        case '(':
         {
          if (subexpression.endOfLine())
           {
            throw new PatternException("expression follows $");
           }
          subexpression = new Expression(subexpression, first);
          break;
         }
        case ')':
         {
          if (subexpression._parent == null)
           {
            throw new PatternException("subexpression not valid");
           }
          subexpression = subexpression._parent;
          break;
         }
        case '|':
         {
          if (i + 1 < pattern.length() &&
              pattern.charAt(i + 1) != ')' &&
              subexpression._lastComponent != null)
           {
            subexpression.startNewAlternative();
            first = subexpression.first();
           }
          else
           {
            addCharToString = true;
           }
          break;
         }
        case '[':
         {
          if (subexpression.endOfLine())
           {
            throw new PatternException("expression follows $");
           }
          CharacterSetComponent characterSetComponent = new CharacterSetComponent(subexpression, ignoreCase);
          boolean bracketExpressionComplete = false;
          boolean firstChar = true;
          boolean dash = false;
          char prevC = '\0';
          for (i = i + 1; i < pattern.length(); i++)
           {
            c = pattern.charAt(i);
            if (firstChar)
             {
              firstChar = false;
              if (c == '^')
               {
                characterSetComponent.setExclude();
                i++;
                if (i >= pattern.length())
                 {
                  break;
                 }
                c = pattern.charAt(i);
               }
              if (c == '-' || c == ']')
               {
                characterSetComponent.addCharacter(c);
                i++;
                if (i >= pattern.length())
                 {
                  break;
                 }
                c = pattern.charAt(i);
               }
             }
            if (c == ']')
             {
              bracketExpressionComplete = true;
              if (dash)
               {
                characterSetComponent.addCharacter('-');
               }
              break;
             }
            else if (dash)
             {
              characterSetComponent.addRange(prevC, c);
              dash = false;
             }
            else if (c == '-')
             {
              dash = true;
             }
            else
             {
              characterSetComponent.addCharacter(c);
              prevC = c;
              dash = false;
             }
           }
          if (!bracketExpressionComplete)
           {
            throw new PatternException("bracket expression not valid");
           }
          if (first)
           {
            if (!_anyCharacterFirst)
             {
              BitSet firstCharacterMap = characterSetComponent.firstCharacterMap();
              if (firstCharacterMap != null)
               {
                _firstCharacterMap.or(characterSetComponent.firstCharacterMap());
               }
              else
               {
                _anyCharacterFirst = true;
               }
             }
            first = false;
           }
          break;
         }
       }
      if (addCharToString)
       {
        if (subexpression.endOfLine())
         {
          throw new PatternException("expression follows $");
         }
        if (stringComponent == null || stringComponent != subexpression._lastComponent)
         {
          stringComponent = new StringComponent(subexpression, c, ignoreCase);
          if (first)
           {
            if (!_anyCharacterFirst)
             {
              _firstCharacterMap.set(c & 0x00ff);
              if (ignoreCase)
               {
                _firstCharacterMap.set(toggleCase(c) & 0x00ff);
               }
             }
            first = false;
           }
         }
        else
         {
          stringComponent.append(c);
         }
       }
     }
    if (subexpression._parent != null)
     {
      throw new PatternException("subexpression not valid");
     }
   }

  String _matchString;
  int _matchIndex;
  int _matchEnd;
  public Match match(String string, int start, int end)
   {
    if (end > string.length())
     {
      end = string.length();
     }
    _matchString = string;
    _matchEnd = end;
    for (int i = start; i < end; i++)
     {
      char c = string.charAt(i);
      if (_anyCharacterFirst || _firstCharacterMap.get(c & 0x00ff))
       {
        _matchIndex = i;
        if (_expression.match() && _matchIndex > i)
         {
          return new Match(i, _matchIndex);
         }
       }
     }
    return null;
   }

  public Match match(String string, int start)
   {
    return match(string, start, string.length());
   }

  public Match match(String string)
   {
    return match(string, 0);
   }

  public Match lastMatch(String string, int start, int end)
   {
    if (end > string.length())
     {
      end = string.length();
     }
    Match firstMatch = match(string, start, end);
    if (firstMatch != null)
     {
      for (int i = start + 1; i < end; i++)
       {
        if (firstMatch.end() == end)
         {
          break;
         }
        Match nextMatch = match(string, i, end);
        if (nextMatch == null)
         {
          break;
         }
        if (nextMatch.end() > firstMatch.end())
         {
          firstMatch = nextMatch;
         }
       }
     }
    return firstMatch;
   }

  public Match lastMatch(String string, int end)
   {
    return lastMatch(string, 0, end);
   }

  public Match lastMatch(String string)
   {
    return lastMatch(string, string.length());
   }

  private static char toggleCase(char c)
   {
    char c2 = Character.toUpperCase(c);
    if (c2 == c)
     {
      c2 = Character.toLowerCase(c);
     }
    return c2;
   }

  public static final class Match
   {
    private int _start;
    private int _end;

    public Match(int start, int end)
     {
      _start = start;
      _end = end;
     }

    public int start()
     {
      return _start;
     }

    public int end()
     {
      return _end;
     }
   }

  private abstract class ExpressionComponent
   {
    Expression _parent;
    ExpressionComponent _next;
    int _minRepeat = 1;
    int _maxRepeat = 1;

    ExpressionComponent(Expression parent)
     {
      _parent = parent;
      if (parent != null)
       {
        if (parent._firstComponent == null)
         {
          parent._firstComponent = this;
         }
        else
         {
          parent._lastComponent._next = this;
         }
        parent._lastComponent = this;
       }
     }

    final void setRepeat(int minRepeat)
     {
      _minRepeat = minRepeat;
      _maxRepeat = -1;
     }

    final void setRepeat(int minRepeat, int maxRepeat)
     {
      _minRepeat = minRepeat;
      _maxRepeat = maxRepeat;
     }

    boolean repeatable()
     {
      return true;
     }

    final boolean match()
     {
      int saveMatchIndex = _matchIndex;
      for (int repeat = _minRepeat; repeat > 0; repeat--)
       {
        if (!singleMatch())
         {
          _matchIndex = saveMatchIndex;
          return false;
         }
       }
      for (int repeat = _minRepeat; repeat < _maxRepeat || _maxRepeat == -1; repeat++)
       {
        if (!singleMatch())
         {
          return true;
         }
       }
      return true;
     }

    abstract boolean singleMatch();
   }

  private class Alternative
   {
    ExpressionComponent _firstComponent;
    Alternative _next;

    Alternative(Expression expression)
     {
      _firstComponent = expression._firstComponent;
      expression._firstComponent = null;
      expression._lastComponent = null;
      _next = expression._firstAlternative;
      expression._firstAlternative = this;
     }
   }

  private class Expression extends ExpressionComponent
   {
    ExpressionComponent _firstComponent;
    ExpressionComponent _lastComponent;
    Alternative _firstAlternative;
    boolean _first;
    boolean _endOfLine;

    Expression(Expression expression, boolean first)
     {
      super(expression);
      _first = first;
     }

    boolean first()
     {
      return _first;
     }

    boolean endOfLine()
     {
      return _endOfLine;
     }

    void startNewAlternative()
     {
      new Alternative(this);
     }

    boolean singleMatch()
     {
      int saveMatchIndex = _matchIndex;
      int maxMatchIndex = _matchIndex - 1;
      boolean match = false;
      boolean currentMatch;
      for (Alternative alternative = _firstAlternative;
           alternative != null;
           alternative = alternative._next)
       {
        currentMatch = true;
        _matchIndex = saveMatchIndex;
        for (ExpressionComponent expressionComponent = alternative._firstComponent;
             expressionComponent != null;
             expressionComponent = expressionComponent._next)
         {
          if (!expressionComponent.match())
           {
            currentMatch = false;
            break;
           }
         }
        if (currentMatch && _matchIndex > maxMatchIndex)
         {
          maxMatchIndex = _matchIndex;
          match = true;
         }
       }
      currentMatch = true;
      _matchIndex = saveMatchIndex;
      for (ExpressionComponent expressionComponent = _firstComponent;
           expressionComponent != null;
           expressionComponent = expressionComponent._next)
       {
        if (!expressionComponent.match())
         {
          currentMatch = false;
          break;
         }
       }
      if (currentMatch && _matchIndex > maxMatchIndex)
       {
        maxMatchIndex = _matchIndex;
        match = true;
       }
      if (match)
       {
        _matchIndex = maxMatchIndex;
       }
      return match;
     }
   }

  private class StringComponent extends ExpressionComponent
   {
    String _string;
    String _alternateCaseString;

    StringComponent(Expression expression, char c, boolean ignoreCase)
     {
      super(expression);
      _string = String.valueOf(c);
      if (ignoreCase)
       {
        _alternateCaseString = String.valueOf(toggleCase(c));
       }
      else
       {
        _alternateCaseString = null;
       }
     }

    void append(char c)
     {
      _string += c;
      if (_alternateCaseString != null)
       {
        _alternateCaseString += toggleCase(c);
       }
     }

    void decoupleLastCharacter()
     {
      if (_string.length() > 1)
       {
        char c = _string.charAt(_string.length() - 1);
        _string = _string.substring(0, _string.length() - 1);
        new StringComponent(_parent, c, _alternateCaseString != null);
       }
     }

    boolean singleMatch()
     {
      if (_matchIndex + _string.length() <= _matchEnd)
       {
        int i, j;
        for (i = _matchIndex, j = 0; j < _string.length(); i++, j++)
         {
          char matchChar = _matchString.charAt(i);
          if (matchChar != _string.charAt(j) &&
              (_alternateCaseString == null ||
               matchChar != _alternateCaseString.charAt(j)))
           {
            return false;
           }
         }
        _matchIndex += _string.length();
        return true;
       }
      return false;
     }
   }

  private class AnyCharacterComponent extends ExpressionComponent
   {
    AnyCharacterComponent(Expression expression)
     {
      super(expression);
     }

    boolean singleMatch()
     {
      if (_matchIndex < _matchEnd)
       {
        _matchIndex++;
        return true;
       }
      return false;
     }
   }

  private class StartOfLineComponent extends ExpressionComponent
   {
    StartOfLineComponent(Expression expression)
     {
      super(expression);
     }

    boolean repeatable()
     {
      return false;
     }

    boolean singleMatch()
     {
      return _matchIndex == 0;
     }
   }

  private class EndOfLineComponent extends ExpressionComponent
   {
    EndOfLineComponent(Expression expression)
     {
      super(expression);
      expression._endOfLine = true;
     }

    boolean repeatable()
     {
      return false;
     }

    boolean singleMatch()
     {
      return _matchIndex == _matchString.length();
     }
   }

  private class CharacterSetComponent extends ExpressionComponent
   {
    boolean _ignoreCase = true;
    boolean _exclude;
    BitSet _includedChars = new BitSet(256);
    String _additionalChars;

    CharacterSetComponent(Expression expression, boolean ignoreCase)
     {
      super(expression);
      _ignoreCase = ignoreCase;
     }

    void setExclude()
     {
      _exclude = true;
     }

    void addCharacter(char c)
     {
      if (c < 256)
       {
        _includedChars.set(c);
       }
      else
       {
        if (_additionalChars == null)
         {
          _additionalChars = "";
         }
        _additionalChars += c;
       }
      if (_ignoreCase)
       {
        char c2 = toggleCase(c);
        if (c2 != c)
         {
          if (c2 < 256)
           {
            _includedChars.set(c2);
           }
          else
           {
            if (_additionalChars == null)
             {
              _additionalChars = "";
             }
            _additionalChars += c2;
           }
         }
       }
     }

    void addRange(char c1, char c2)
     {
      for (char c = c1; c <= c2; c++)
       {
        addCharacter(c);
       }
     }

    boolean singleMatch()
     {
      if (_matchIndex < _matchEnd &&
          charInSet(_matchString.charAt(_matchIndex)))
       {
        _matchIndex++;
        return true;
       }
      return false;
     }

    boolean charInSet(char c)
     {
      boolean inSet = false;
      if (c < 256)
       {
        inSet = _includedChars.get(c);
       }
      else if (_additionalChars != null)
       {
        for (int i = 0; i < _additionalChars.length(); i++)
         {
          if (_additionalChars.charAt(i) == c)
           {
            inSet = true;
            break;
           }
         }
       }
      return _exclude ? !inSet : inSet;
     }

    BitSet firstCharacterMap()
     {
      if (!_exclude)
       {
        BitSet firstCharacterMap = (BitSet) _includedChars.clone();
        if (_additionalChars != null)
         {
          for (int i = 0; i < _additionalChars.length(); i++)
           {
            firstCharacterMap.set(_additionalChars.charAt(i) & 0x00ff);
           }
         }
        return firstCharacterMap;
       }
      return null;
     }
   }
 }