//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexPopup - popup for the TextWindow.
//----------------------------------------------------------------------------

package com.ibm.lpex.util;

/**
 * Currently, the popup menu is only available in the LPEX plugin (through
 * Eclipse's workbench support), not in the SWT LPEX widget.
 */
class LpexPopup
{
  public LpexPopup()
  {
  }
}