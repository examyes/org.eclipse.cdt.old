//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexSysutil - system-related methods.
//----------------------------------------------------------------------------

package com.ibm.lpex.util;

import java.io.File;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexUtilities;


/**
 * System-related methods.
 * An alternative to these methods is implemented in native code for certain
 * platforms.
 */
public final class LpexSysutil
{
   // platform-dependent utilities implemented in native code
   private static Sysutil _sysutilObj;

   // LPEX's user home directory
   private static String  _home;


   /**
    * On Windows, the Java 2 SDK AWT/Swing platform: try to load the native
    * utilities code;  if it can't be loaded, we will default to pure Java code.
    */
   private static Sysutil getSysutilObj()
   {
      if (_sysutilObj == null) {
         try {
            if (LpexUtilities.getPlatform() == LpexConstants.PLATFORM_AWT)
               _sysutilObj = new WinSysutil();
            }
         catch (UnsatisfiedLinkError e) {}
         }
      return _sysutilObj;
   }

   /**
    * Interface defining the native system utilities.
    */
   public interface Sysutil
   {
      public String getSysEnvVariable(String var);
   }

   /**
    * Retrieve an environment variable.
    * @param var name of an environment variable
    * @return value of the environment variable, or
    *         <code>null</code> if it is not obtainable or not found
    */
   public static String getEnvVariable(java.lang.String var)
   {
      return (getSysutilObj() != null)? _sysutilObj.getSysEnvVariable(var) : null;
   }

   /**
    * Retrieve LPEX's user-data home directory.
    * This directory is assembled like this: <pre>
    *   <"user.home">/IBM/Editor </pre>
    */
   public static String getUserHomeDirectory ()
   {
      if (_home == null) {
         _home = System.getProperties().getProperty("user.home");

         if (!_home.endsWith(File.separator))
            _home += File.separator;
         _home += "IBM";
         File file = new File(_home);
         try {
            file.mkdir();
            }
         catch (Exception e) {}

         _home += File.separator + "Editor";
         file = new File(_home);
         try {
            file.mkdir();
            }
         catch (Exception e) {}
         }
      return _home;
   }

   /**
    * An entry point for testing purposes.
    * Shows the value LPEX reads for an environment variable.
    * Usage:  java com.ibm.lpex.util.LpexSysutil <i>environment_variable</i>.
    */
   public static void main(String args[])
   {
      if (args.length != 1) {
         System.out.println("USAGE: LpexSysutil <envvar>");
         }
      else {
         System.out.println("- getEnvVariable:\n" +
                            "  ENV[" + args[0] + "] = " + getEnvVariable(args[0]));
         }
   }
}