//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexAbstractTextEditor - a line-oriented (LPEX-based) AbstractTextEditor
// (Eclipse R2.0).
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCommand;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexDocumentLocation;
import com.ibm.lpex.core.LpexDocumentSectionListener;
import com.ibm.lpex.core.LpexParser;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexStringTokenizer;
import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.core.LpexViewAdapter;
import com.ibm.lpex.core.LpexViewListener;
import com.ibm.lpex.core.LpexWindow;

import com.ibm.lpex.alef.LpexPlugin;
import com.ibm.lpex.alef.LpexSourceViewer;
import com.ibm.lpex.alef.LpexVerticalRuler;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;

import org.eclipse.jface.action.ActionContributionItem;
import org.eclipse.jface.action.ContributionItem;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;

import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.IPreferencePage;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.JFaceResources;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextOperationTarget;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.Position;

import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.IVerticalRuler;
import org.eclipse.jface.text.source.SourceViewerConfiguration;

import org.eclipse.jface.util.Assert;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IStorage;
import org.eclipse.core.resources.IMarkerDelta;
import org.eclipse.core.resources.IResource;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;

import org.eclipse.ui.IEditorDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorRegistry;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.IPartListener;
import org.eclipse.ui.IReusableEditor;
import org.eclipse.ui.IStorageEditorInput;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.help.WorkbenchHelp;
import org.eclipse.ui.part.EditorPart;

import org.eclipse.ui.texteditor.AbstractMarkerAnnotationModel;
import org.eclipse.ui.texteditor.AddMarkerAction;
import org.eclipse.ui.texteditor.DocumentProviderRegistry;
import org.eclipse.ui.texteditor.IAbstractTextEditorHelpContextIds;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.IDocumentProviderExtension;
import org.eclipse.ui.texteditor.IElementStateListener;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.ITextEditorActionConstants;
import org.eclipse.ui.texteditor.IUpdate;
import org.eclipse.ui.texteditor.MarkerUtilities;
import org.eclipse.ui.texteditor.MarkerRulerAction;
import org.eclipse.ui.texteditor.ResourceAction;
import org.eclipse.ui.texteditor.RevertToSavedAction;
import org.eclipse.ui.texteditor.SaveAction;
import org.eclipse.ui.texteditor.TextEditorAction;


/**
 * A line oriented, LPEX-based abstract base implementation of a text editor.
 * Subclasses are responsible for configuring the editor appropriately.
 * <code>LpexTextEditor</code> is one such example.
 *
 * <p>If a subclass calls <code>setEditorContextMenuId</code>, the arguments is
 * used as the id under which the editor's context menu is registered for extensions.
 * If no id is set, the context menu is registered under <b>[editor_id].EditorContext</b>,
 * whereby [editor_id] is replaced with the editor's part id.  If the editor is instructed
 * to run in version 1.0 context menu registration compatibility mode, the latter form of
 * the registration even happens if a context menu id has been set via
 * <code>setEditorContextMenuId</code>.
 * If no id is set while in compatibility mode, the menu is registered under
 * <code>DEFAULT_EDITOR_CONTEXT_MENU_ID</code>.</p>
 *
 * <p>If a subclass calls <code>setRulerContextMenuId</code>, the arguments is
 * used as the id under which the ruler's context menu is registered for extensions.
 * If no id is set, the context menu is registered under <b>[editor_id].RulerContext</b>,
 * whereby [editor_id] is replaced with the editor's part id.  If the editor is instructed
 * to run in version 1.0 context menu registration compatibility mode, the latter form of
 * the registration even happens if a context menu id has been set via
 * <code>setRulerContextMenuId</code>.
 * If no id is set while in compatibility mode, the menu is registered under
 * <code>DEFAULT_RULER_CONTEXT_MENU_ID</code>.</p>
 *
 * <p>Several AbstractTextEditor classes, methods, and fields are not available
 * in LpexAbstractTextEditor.  Most programming of the underlying LPEX widget
 * should be done directly via its LpexView and LpexWindow.</p>
 *
 * <p>One major difference from SourceViewer, changes to this viewer's
 * stream-oriented IDocument are <b>not</b> recorded in the underlying LPEX text
 * widget.  Always use LpexView to set the text of the edited document.
 * For example:
 * <pre>
 *   IEditorPart editor = IWorkbenchPage.getActiveEditor();
 *   // (a) Using LPEX
 *   if (editor instanceof LpexTextEditor) {
 *      LpexTextEditor lpexEditor = (LpexTextEditor)editor;
 *      LpexView lpexView = lpexEditor.getLpexView();
 *      if (lpexView != null) {
 *         lpexView.doDefaultCommand("insertText " + text); // insert text at cursor
 *         LpexView.doGlobalCommand("screenShow");          // refresh display
 *         }
 *      }
 *   // (b) Using the Eclipse editor
 *   else {
 *      . . . // get DocumentProvider, get IDocument, do replace()
 *      } </pre>
 * Only a total replacement of the IDocument contents will be effected into LPEX.
 *
 * <ul>
 * <li>the popup (context) menu is populated mostly according to LPEX's
 *     <b>popup</b> parameter settings;  for example, action "Goto line"
 *     is not added - in LPEX one can go to a line from the command line
 *     (e.g., by entering ":150" or, simpler, just "150"), or by using the
 *     <b>locateLine</b> action (Ctrl+L)
 *
 * <li>class TextListener implements ITextListener,
 *     private ITextListener fTextListener,
 *     protected final ISelectionChangedListener getSelectionChangedListener(),
 *     public void markAsContentDependentAction(),
 *     public void markAsSelectionDependentAction(),
 *     private void updateAction(),
 *     protected void updateContentDependentActions(),
 *     protected void updateSelectionDependentActions() <br>
 *     -- the global (Workbench) actions are updated on every refresh
 *     of the LPEX screen
 *
 * <li>public final static String PREFERENCE_FONT,
 *     public final static String PREFERENCE_COLOR_FOREGROUND,
 *     public final static String PREFERENCE_COLOR_BACKGROUND,
 *     public final static String PREFERENCE_COLOR_FOREGROUND_SYSTEM_DEFAULT,
 *     public final static String PREFERENCE_COLOR_BACKGROUND_SYSTEM_DEFAULT,
 *     private Font fFont,
 *     private Color fForegroundColor,
 *     private Color fBackgroundColor,
 *     protected void handlePreferenceStoreChanged(...),
 *     private void initializeViewerFont(...),
 *     private void setFont(...),
 *     private void initializeViewerColors(...),
 *     private Color createColor(...) <br>
 *     -- LPEX's install/default settings are stored in its profiles,
 *     not in a preference store
 *
 * <li>.. implements ITextEditorExtension,
 *     public void setStatusField(...),
 *     public boolean isEditorInputReadOnly(), <br>
 *
 *     interface ICursorListener,
 *     private Map fStatusFields,
 *     private ICursorListener fCursorListener,
 *     private boolean fOverwriting,
 *     protected final ICursorListener getCursorListener(),
 *     protected IStatusField getStatusField(...),
 *     protected boolean isInInsertMode(),
 *     protected void handleCursorPositionChanged(),
 *     protected void handleInsertModeChanged(),
 *     protected void updateStatusField(...),
 *     protected String getCursorPosition() <br>
 *     -- LPEX currently uses its own status line.
 * </ul>
 *
 * @see LpexTextEditor
 * @see #getLpexView
 * @see #getLpexWindow
 */
public abstract class LpexAbstractTextEditor extends EditorPart
                                             implements ITextEditor, IReusableEditor
{
   /**
    * Use Eclipse's own resources for AbstractTextEditor-specific messages.
    */
   private static final class EditorMessages
   {
      private static ResourceBundle _bundle;
      public static String getString(String key)
      {
         try {
            if (_bundle == null)
               _bundle = ResourceBundle.getBundle("org.eclipse.ui.texteditor.EditorMessages");
            if (_bundle != null)
               return _bundle.getString(key);
            }
         catch (MissingResourceException e) {}
         return "!" + key + "!";
      }
   }


   /**
    * Internal element state listener.
    * Added to our IDocumentProvider.
    *
    * <p>IElementStateListener - interface for parties interested in standardized
    * element changes.  These changes are:
    *   dirty state changes,
    *   content replacements,
    *   moves,
    *   deletions.
    * The notifications sent to the element-state listeners inform about those
    * standardized, abstract changes.  The concrete change applied might differ
    * from the one the listeners are notified about, but should be interpreted
    * as the one the listeners receive.</p>
    */
   class ElementStateListener implements IElementStateListener
   {
      /*
       * @param isDirty the new dirty state
       * @see IElementStateListener#elementDirtyStateChanged
       */
      public void elementDirtyStateChanged(Object element, boolean isDirty)
      {
         if (element != null && element.equals(getEditorInput())) {
            if (isDirty) {
               validateState((IEditorInput)element);
               //updateStatusField(ITextEditorActionConstants.STATUS_CATEGORY_ELEMENT_STATE);

               // added in Eclipse R2.0 20020214:
               if (!isEditable()) {
                  /* should be replaced with a key verify listener for better appearance */
                  Shell shell = getSite().getShell();
                  if (shell != null) {
                     shell.getDisplay().asyncExec(new Runnable() {
                        public void run() {
                           doRevertToSaved();
                           }
                        });
                     }
                  }

               }

            firePropertyChange(PROP_DIRTY);

            /*
             * Revert should be undoable
             *
            if (!isDirty && fSourceViewer != null)
               fSourceViewer.resetPlugins();
            */
            }
      }

      /*
       * Notifies that the content of the given element is about to be replaced.
       * @see IElementStateListener#elementContentAboutToBeReplaced
       */
      public void elementContentAboutToBeReplaced(Object element)
      {
         if (element != null && element.equals(getEditorInput())) {
            rememberSelection();
            resetHighlightRange();
            }
      }

      /*
       * @see IElementStateListener#elementContentReplaced
       */
      public void elementContentReplaced(Object element)
      {
         if (element != null && element.equals(getEditorInput())) {
            firePropertyChange(PROP_DIRTY);
            /*
             * Revert should be undoable
             *
            if (!isDirty && fSourceViewer != null)
               fSourceViewer.resetPlugins();
            */
            restoreSelection();
            }
      }

      /*
       * @see IElementStateListener#elementDeleted
       */
      public void elementDeleted(Object deletedElement)
      {
         if (deletedElement != null && deletedElement.equals(getEditorInput()))
            close(false);
      }

      /*
       * Notifies that the element has moved.  If movedElement is null, it is
       * similar to elementDeleted(originalElement).
       * @param originalElement the element before the move
       * @param movedElement    the element after the move
       * @see IElementStateListener#elementMoved
       */
      public void elementMoved(Object originalElement, Object movedElement)
      {
         if (originalElement != null &&
             originalElement.equals(getEditorInput()) &&
             (movedElement == null || movedElement instanceof IEditorInput)) {
            rememberSelection();

            IDocumentProvider d= getDocumentProvider();
            IDocument changed= null;
            if (isDirty())
               changed= d.getDocument(getEditorInput());

            setInput((IEditorInput) movedElement);

            if (changed != null) {
               d.getDocument(getEditorInput()).set(changed.get());
               validateState(getEditorInput());
               //updateStatusField(ITextEditorActionConstants.STATUS_CATEGORY_ELEMENT_STATE);
               }

            restoreSelection();
            }
      }
   };


   /**
    * Internal property-change listener for the editor's preference store.
    */
   class PropertyChangeListener implements IPropertyChangeListener
   {
      /**
       * @see IPropertyChangeListener#propertyChange(PropertyChangeEvent)
       */
      public void propertyChange(PropertyChangeEvent event)
      {
         handlePreferenceStoreChanged(event);
      }
   };


   /**
    * Internal part-activation listener.
    */
   class PartListener implements IPartListener
   {
      private long fModificationStamp = -1;

      /**
       * @see IPartListener#partActivated(IWorkbenchPart)
       */
      public void partActivated(IWorkbenchPart part)
      {
         if (part == LpexAbstractTextEditor.this) {
            IDocumentProvider p = getDocumentProvider();

            if (fModificationStamp == -1)
               fModificationStamp = p.getSynchronizationStamp(getEditorInput());

            long stamp = p.getModificationStamp(getEditorInput());
            if (stamp != fModificationStamp) {
               fModificationStamp = stamp;
               if (stamp != p.getSynchronizationStamp(getEditorInput()))
                  handleEditorInputChanged();
               }

            updateState(getEditorInput());
            //updateStatusField(ITextEditorActionConstants.STATUS_CATEGORY_ELEMENT_STATE);
            }
      }

      /**
       * @see IPartListener#partBroughtToTop(IWorkbenchPart)
       */
      public void partBroughtToTop(IWorkbenchPart part) {}

      /**
       * @see IPartListener#partClosed(IWorkbenchPart)
       */
      public void partClosed(IWorkbenchPart part) {}

      /**
       * @see IPartListener#partDeactivated(IWorkbenchPart)
       */
      public void partDeactivated(IWorkbenchPart part) {}

      /**
       * @see IPartListener#partOpened(IWorkbenchPart)
       */
      public void partOpened(IWorkbenchPart part) {}
   };


   /** Menu id for the editor context menu. */
   public final static String DEFAULT_EDITOR_CONTEXT_MENU_ID = "#EditorContext";
   /** Menu id for the ruler context menu. */
   public final static String DEFAULT_RULER_CONTEXT_MENU_ID = "#RulerContext";
   /** The width of the vertical ruler. */
   protected final static int VERTICAL_RULER_WIDTH = 12;

   /** The editor's internal document provider. */
   private IDocumentProvider fInternalDocumentProvider;
   /** The editor's external document provider. */
   private IDocumentProvider fExternalDocumentProvider;
   /** The editor's preference store. */
   private IPreferenceStore fPreferenceStore;
   /** The editor's range indicator. */
   private Annotation fRangeIndicator;
   /** The editor's source viewer configuration. */
   private SourceViewerConfiguration fConfiguration;
   /** The editor's source viewer. */
   private LpexSourceViewer /*(ISourceViewer)*/ fSourceViewer;
   /** The editor's vertical ruler. */
   private IVerticalRuler fVerticalRuler;
   /** The editor's context menu id. */
   private String fEditorContextMenuId;
   /** The ruler's context menu id. */
   private String fRulerContextMenuId;
   /** The editor's help context id */
   private String fHelpContextId;
   /** The editor's presentation mode. */
   private boolean fShowHighlightRangeOnly;
   /** The actions registered with the editor. */
   private Map fActions = new HashMap(10);
   /** Context menu listener. */
   private IMenuListener fMenuListener;
   /** Vertical ruler mouse listener. */
   private MouseListener fMouseListener;
   /** Title image to be disposed. */
   private Image fTitleImage;
   /** The text context menu to be disposed. */
   private Menu fTextContextMenu;
   /** The ruler context menu to be disposed. */
   private Menu fRulerContextMenu;
   /** The editor's element state listener. */
   private IElementStateListener fElementStateListener = new ElementStateListener();
   /** The editor's property change listener on our preference store. */
   private IPropertyChangeListener fPropertyChangeListener = new PropertyChangeListener();
   /** The editor's part listener. */
   private IPartListener fPartListener = new PartListener();

   /** The editor's remembered text selection - see our ElementStateListener. */
   private ITextSelection fRememberedSelection;
   /** Indicates whether the editor runs in 1.0 context menu registration compatibility mode. */
   private boolean fCompatibilityMode = true;
   /** The number of reentrances into error correction code while saving. */
   private int fErrorCorrectionOnSave;

   // last 'dirty' state read from LPEX
   private boolean _modified;
   // LPEX view listener
   private LpexViewListener _lpexViewListener;
   // LPEX command line focus listener
   private FocusListener _commandLineFocusListener;

   // -as- LPEX command line Text field text-selection listener
   // private SelectionListener _commandLineSelectionListener;
   // -as- command line Text field with the _commandLineSelectionListener
   // private Text _commandLineTextControl;

   // list of standard editor actions to update on an LPEX screen refresh
   private LpexEditorAction _firstAction;

   // our current editor-input resource (file/storage)
   private IResource _inputResource;


   /**
    * Creates a new text editor.  If not explicitly set, this editor uses
    * an <code>LpexSourceViewerConfiguration</code> to configure its
    * source viewer.  This viewer does not have a range indicator installed,
    * nor any menu id set.  By default, the created editor runs in 1.0 context
    * menu registration compatibility mode.
    */
   protected LpexAbstractTextEditor()
   {
      super();

      fEditorContextMenuId = null;
      fRulerContextMenuId = null;
   }

   /**
    * Return this text editor's document provider.
    *
    * @see org.eclipse.ui.texteditor.ITextEditor#getDocumentProvider
    */
   public IDocumentProvider getDocumentProvider()
   {
      if (fInternalDocumentProvider != null)
         return fInternalDocumentProvider;
      return fExternalDocumentProvider;
   }

   /**
    * Return this editor's preference store.
    * LPEX's default settings are stored in its <b>defaultProfile</b>, not in
    * the editor's preference store.
    *
    * @return this editor's preference store
    */
   protected final IPreferenceStore getPreferenceStore()
   {
      return fPreferenceStore;
   }

   /**
    * Return this editor's range indicator.
    */
   protected final Annotation getRangeIndicator()
   {
      return fRangeIndicator;
   }

   /**
    * Return the editor's source viewer configuration.
    */
   protected final SourceViewerConfiguration getSourceViewerConfiguration()
   {
      return fConfiguration;
   }

   /**
    * Return the editor's source viewer.
    */
   protected final ISourceViewer getSourceViewer()
   {
      return fSourceViewer;
   }

   /**
    * Return the editor's vertical ruler.
    */
   public /*protected -as- BUT DEBUGGER NEEDS ACCESS*/ final IVerticalRuler getVerticalRuler()
   {
      return fVerticalRuler;
   }

   /**
    * Return the editor's context menu id.
    */
   protected final String getEditorContextMenuId()
   {
      return fEditorContextMenuId;
   }

   /**
    * Return the editor's help context id.
    */
   protected final String getHelpContextId()
   {
      return fHelpContextId;
   }

   /**
    * Return the ruler's context menu id.
    */
   protected final String getRulerContextMenuId()
   {
      return fRulerContextMenuId;
   }

   /**
    * Set the editor's document provider.  This method must be called before the
    * editor's control is created.
    *
    * <p>IDocumentProvider is an interface used by the ITextEditor to
    * interact with its input element based on the input element's textual
    * representation as IDocument.  A document provider may be shared between
    * multiple editors.</p>
    *
    * @param provider the document provider
    */
   protected void setDocumentProvider(IDocumentProvider provider)
   {
      Assert.isNotNull(provider);
      fInternalDocumentProvider = provider;
   }

   /**
    * Set this editor's source viewer configuration used to configure its
    * internal source viewer.  This method must be called before the editor's
    * control is created.  If not, this editor uses a default
    * <code>LpexSourceViewerConfiguration</code>.
    *
    * @param configuration the source viewer configuration object
    * @see LpexSourceViewerConfiguration
    */
   protected void setSourceViewerConfiguration(SourceViewerConfiguration configuration)
   {
      Assert.isNotNull(configuration);
      fConfiguration = configuration;
   }

   /**
    * Set the annotation which this editor uses to represent the highlight
    * range if the editor is configured to show the entire document. If the
    * range indicator is not set, this editor uses a
    * <code>DefaultRangeIndicator</code>.
    *
    * @param rangeIndicator the annotation
    */
   protected void setRangeIndicator(Annotation rangeIndicator)
   {
      Assert.isNotNull(rangeIndicator);
      fRangeIndicator = rangeIndicator;
   }

   /**
    * Set this editor's context menu id.
    *
    * @param contextMenuId the context menu id
    */
   protected void setEditorContextMenuId(String contextMenuId)
   {
      Assert.isNotNull(contextMenuId);
      fEditorContextMenuId = contextMenuId;
   }

   /**
    * Set the ruler's context menu id.
    *
    * @param contextMenuId the context menu id
    */
   protected void setRulerContextMenuId(String contextMenuId)
   {
      Assert.isNotNull(contextMenuId);
      fRulerContextMenuId = contextMenuId;
   }

   /**
    * Sets the context menu registration 1.0 compatibility mode. (See class
    * description for more details.)
    *
    * @param compatible <code>true</code> if compatibility mode is enabled
    */
   protected final void setCompatibilityMode(boolean compatible)
   {
      fCompatibilityMode = compatible;
   }

   /**
    * Return whether the text in this text editor can be changed by the user.
    * Preferred method:  use the LPEX <b>readonly</b> parameter.
    *
    * @see org.eclipse.ui.texteditor.ITextEditor#isEditable
    */
   public boolean isEditable()
   {
      // Eclipse R2.0 12/2001 has this:
      // IDocumentProvider provider = getDocumentProvider();
      // if (provider instanceof IDocumentProviderExtension) {
      //  IDocumentProviderExtension extension = (IDocumentProviderExtension)provider;
      //  return extension.isModifiable(getEditorInput());
      //  }
      // return false;

      LpexView lpexView = getLpexView();
      return lpexView != null && !lpexView.queryOn("readonly");
   }

   /**
    * Return the editor's selection provider.
    */
   public ISelectionProvider getSelectionProvider()
   {
      return (fSourceViewer != null)? fSourceViewer.getSelectionProvider() : null;
   }

   /**
    * Remembers the current selection of this editor.  This method is called when, e.g.,
    * the content of the editor is about to be reverted to the saved state.  This method
    * remembers the selection in a semantic format, i.e., in a format which allows to
    * restore the selection even if the originally selected text is no longer part of the
    * editor's content.
    *
    * <p>Subclasses should implement this method including all necessary state. This
    * default implementation remembers the textual range only and is thus purely
    * syntactic.</p>
    *
    * @see #restoreSelection
    */
   protected void rememberSelection() {
      ISelectionProvider sp = getSelectionProvider();
      fRememberedSelection = (sp == null ? null : (ITextSelection)sp.getSelection());
   }

   /**
    * Restores a selection previously remembered by <code>rememberSelection</code>.
    * Subclasses may reimplement this method and thereby semantically adapt the
    * remembered selection. This default implementation just selects the
    * remembered textual range.
    *
    * @see #rememberSelection
    */
   protected void restoreSelection() {
      if (getSourceViewer() != null && fRememberedSelection != null)
         selectAndReveal(fRememberedSelection.getOffset(), fRememberedSelection.getLength());
      fRememberedSelection= null;
   }

   /**
    * Create and return the listener on this editor's context menus.
    *
    * @return the menu listener
    */
   protected final IMenuListener getContextMenuListener()
   {
      if (fMenuListener == null) {
         fMenuListener = new IMenuListener() {
            public void menuAboutToShow(IMenuManager menu) {
               String id = menu.getId();
               if (getRulerContextMenuId().equals(id)) {
                  setFocus();
                  rulerContextMenuAboutToShow(menu);
                  }
               else if (getEditorContextMenuId().equals(id)) {
                  setFocus();
                  editorContextMenuAboutToShow(menu);
                  }
               }
            };
        }
      return fMenuListener;
   }

   /**
    * Create and return the listener on this editor's vertical ruler.
    *
    * @return the mouse listener
    */
   protected final MouseListener getRulerMouseListener()
   {
      if (fMouseListener == null) {
         fMouseListener = new MouseListener() {

            private boolean fDoubleClicked = false;

            private void triggerAction(String actionID)
            {
               IAction action = getAction(actionID);
               if (action != null) {
                  if (action instanceof IUpdate)
                     ((IUpdate)action).update();
                  if (action.isEnabled())
                     action.run();
                  }
            }

            public void mouseUp(MouseEvent e)
            {
               //*as* we have not yet defined the RULER_CLICK action in here...
               //if (1 == e.button && !fDoubleClicked)
               // triggerAction(ITextEditorActionConstants.RULER_CLICK);
               fDoubleClicked = false;
            }

            public void mouseDoubleClick(MouseEvent e)
            {
               if (1 == e.button) {
                  fDoubleClicked = true;
                  triggerAction(ITextEditorActionConstants.RULER_DOUBLE_CLICK);
                  }
            }

            public void mouseDown(MouseEvent e) {}
            };
         }
      return fMouseListener;
   }

   /**
    * Determines whether the given preference change affects the editor's
    * presentation.  This implementation always returns <code>false</code>.
    * May be reimplemented by subclasses.
    *
    * @param event the event which should be investigated
    * @return whether the event describes a preference change affecting the
    *         editor's presentation
    */
   protected boolean affectsTextPresentation(PropertyChangeEvent event)
   {
      return false;
   }

   /**
    * Handle a property-change event describing a change of the editor's
    * preference store.
    *
    * <p>LPEX's default settings are stored in its <b>defaultProfile</b>, not
    * in a preference store.  In TextViewer, this method updates any
    * preference-related editor properties (namely, its font and foreground and
    * background colours).</p>
    *
    * @param event the property change event
    */
   protected void handlePreferenceStoreChanged(PropertyChangeEvent event)
   {
      if (fSourceViewer == null)
         return;

      if (affectsTextPresentation(event))
         fSourceViewer.invalidateTextPresentation();
   }

   /**
    * Initialize this editor with the given editor site and input.
    * This method is automatically called shortly after the part construction;
    * it marks the start of the part's lifecycle.  The IWorkbenchPart.dispose()
    * method will be called automically at the end of the lifecycle.  Clients
    * must not call this method.
    *
    * @see org.eclipse.ui.IEditorPart#init
    */
   public void init(IEditorSite site, IEditorInput input) throws PartInitException
   {
      setSite(site);

      // implementors of this method must examine the editor input object type
      // to determine if it is understood;  if not, the implementor must throw
      // a PartInitException
      try {
         doSetInput(input);
         }
      catch (CoreException x) {
         throw new PartInitException(x.getMessage());
         }

      // listen to our editor part's events
      getSite().getWorkbenchWindow().getPartService().addPartListener(fPartListener);
   }

   /**
    * Create the vertical ruler (an LpexVerticalRuler) to be used by this editor.
    * Subclasses may reimplement this method.
    *
    * @return the vertical ruler
    */
   protected IVerticalRuler createVerticalRuler()
   {
      return new LpexVerticalRuler(VERTICAL_RULER_WIDTH);
   }

   /**
    * Create the source viewer (an LpexSourceViewer) to be used by this editor.
    * Subclasses may reimplement this method.
    *
    * <p>Called from createPartControl().</p>
    *
    * @param parent the parent control
    * @param ruler the vertical ruler
    * @param styles style bits
    * @return the source viewer
    */
   protected ISourceViewer createSourceViewer(Composite parent, IVerticalRuler ruler, int styles)
   {
      return new LpexSourceViewer(parent,
                                  this,             // LPEX: pass this ITextEditor too
                                  ruler, styles);
   }

   /**
    * The LpexAbstractTextEditor implementation of this
    * <code>IWorkbenchPart</code> method creates the vertical ruler and
    * source viewer.  Subclasses may extend.
    *
    * <p>This is a multistep process:
    * <ol>
    *   <li>create one or more controls within the parent
    *   <li>set the parent layout as needed
    *   <li>hook focus on each of the controls - when focus is gained, notify all
    *       focus listeners
    *   <li>register any global actions with the IActionService
    *   <li>register any popup menus with the IActionService.
    * </ol></p>
    *
    * @see org.eclipse.ui.IWorkbenchPart#createPartControl
    */
   public void createPartControl(Composite parent)
   {
      fVerticalRuler = createVerticalRuler();

      int styles = SWT.BORDER;
      fSourceViewer = (LpexSourceViewer)createSourceViewer(parent, fVerticalRuler, styles);

      // create a default SourceViewerConfiguration ...
      if (fConfiguration == null)
         fConfiguration = new LpexSourceViewerConfiguration();
      fSourceViewer.configure(fConfiguration);

      // set annotation used as range indicator for the viewer's vertical ruler
      if (fRangeIndicator != null)
         fSourceViewer.setRangeIndicator(fRangeIndicator);

      //AbstractTextEditor: StyledText styledText= fSourceViewer.getTextWidget();
      LpexView lpexView = fSourceViewer.getLpexView();
      LpexWindow lpexWindow = fSourceViewer.getLpexWindow();

      // LPEX's install/default font & colours are already set in lpexView...
      //initializeViewerFont(fSourceViewer);
      //initializeViewerColors(fSourceViewer);

      if (getHelpContextId() != null)
         WorkbenchHelp.setHelp(lpexWindow,           // Control
                               getHelpContextId());  // help context id

      /*------------------------------------------*/
      /*  create the editor context (popup) menu  */
      /*------------------------------------------*/
      String id = (fEditorContextMenuId != null)? fEditorContextMenuId :
                                                  DEFAULT_EDITOR_CONTEXT_MENU_ID;
      MenuManager manager = new MenuManager(id, id);
      manager.setRemoveAllWhenShown(true);
      manager.addMenuListener(getContextMenuListener());
      // -as- Eclipse R2.0 build F1 (20020521): set the menu on the TextWindow rather
      // than parent LpexWindow, else the popup in the debugger doesn't come up!?
      fTextContextMenu = manager.createContextMenu(lpexWindow.textWindow());
      lpexWindow.textWindow().setMenu(fTextContextMenu);

      // register the edit window's pop-up menu with its particular id for
      // extension;  this method is called because our part has more than one
      // context menu to register (see ruler's pop-up menu registered below);
      // see org.eclipse.ui.IWorkbenchPartSite#registerContextMenu()
      if (fEditorContextMenuId != null)
         getSite().registerContextMenu(fEditorContextMenuId, manager, getSelectionProvider());
      else if (fCompatibilityMode)
         getSite().registerContextMenu(DEFAULT_EDITOR_CONTEXT_MENU_ID, manager,
                                       getSelectionProvider());

      if ((fEditorContextMenuId != null && fCompatibilityMode) || fEditorContextMenuId == null) {
         String partId = getSite().getId();
         if (partId != null)
            getSite().registerContextMenu(partId + ".EditorContext", manager,
                                          getSelectionProvider());
         }

      if (fEditorContextMenuId == null)
         fEditorContextMenuId = DEFAULT_EDITOR_CONTEXT_MENU_ID;

      /*-----------------------------------------*/
      /*  create the ruler context (popup) menu  */
      /*-----------------------------------------*/
      Control ruler = fVerticalRuler.getControl();
      id = (fRulerContextMenuId != null)? fRulerContextMenuId : DEFAULT_RULER_CONTEXT_MENU_ID;
      manager = new MenuManager(id, id);
      manager.setRemoveAllWhenShown(true);
      manager.addMenuListener(getContextMenuListener());
      fRulerContextMenu = manager.createContextMenu(ruler);
      ruler.setMenu(fRulerContextMenu);
      ruler.addMouseListener(getRulerMouseListener());

      if (fRulerContextMenuId != null)
         getSite().registerContextMenu(fRulerContextMenuId, manager, getSelectionProvider());
      else if (fCompatibilityMode)
         getSite().registerContextMenu(DEFAULT_RULER_CONTEXT_MENU_ID, manager,
                                       getSelectionProvider());

      if ((fRulerContextMenuId != null && fCompatibilityMode) || fRulerContextMenuId == null) {
         String partId = getSite().getId();
         if (partId != null)
            getSite().registerContextMenu(partId + ".RulerContext", manager,
                                          getSelectionProvider());
         }

      if (fRulerContextMenuId == null)
         fRulerContextMenuId = DEFAULT_RULER_CONTEXT_MENU_ID;

      getSite().setSelectionProvider(getSelectionProvider());

      /*------------------*/
      /*  create actions  */
      /*------------------*/
      createActions();

      /*---------------------------*/
      /*  initialize SourceViewer  */
      /*---------------------------*/
      initializeSourceViewer(getEditorInput());
   }

   /**
    * Initialize the editor's source viewer based on the given editor input.
    * Called by createPartControl() and doSetInput().
    *
    * @param input the editor input to be used to initialize the source viewer
    */
   private void initializeSourceViewer(IEditorInput input)
   {
      IAnnotationModel model = getDocumentProvider().getAnnotationModel(input);

      // let LpexTextViewer know the (new) input: LPEX's name parameter and,
      // accordingly, the parser, must be set (may have to change)
      fSourceViewer.setEditorInput(input);

      IDocument document = getDocumentProvider().getDocument(input);
      if (document != null) {
         fSourceViewer.setDocument(document, model);

         //LPEX uses the <b>readonly</b> parameter (based on file's read/write
         // attribute for IFile inputs), unless explicit LpexTextViewer.setEditable()
         //fSourceViewer.setEditable(isEditable());
         if (input instanceof IStorageEditorInput) {
            IStorageEditorInput storageInput = (IStorageEditorInput)input;
            try {
               IStorage storage = storageInput.getStorage();
               if (storage != null)
                  fSourceViewer.setEditable(!storage.isReadOnly());
               }
            catch (CoreException x) {}
            }

         fSourceViewer.showAnnotations(model != null);
         }

      // add listeners for updating 'dirty' state & actions' enable state
      addDirtyListener();

      // ensure an up-to-date preference page for the LPEX view
      fSourceViewer.updatePreferencePage();
   }

   /**
    * Initialize the editor's title (text & image) based on the given editor
    * input.
    *
    * @param input the (new) editor input to be used
    */
   private void initializeTitle(IEditorInput input)
   {
      Image oldImage = fTitleImage;
      fTitleImage = null;
      String title = "";

      if (input != null) {
         IEditorRegistry editorRegistry = getEditorSite().getPage().getWorkbenchWindow()
                                                         .getWorkbench().getEditorRegistry();
         IEditorDescriptor editorDesc = editorRegistry.findEditor(getSite().getId());
         ImageDescriptor imageDesc = (editorDesc != null)? editorDesc.getImageDescriptor() : null;

         fTitleImage = (imageDesc != null)? imageDesc.createImage() : null;
         title = input.getName();
         }

      setTitleImage(fTitleImage);
      setTitle(title);

      firePropertyChange(PROP_DIRTY);

      if (oldImage != null && !oldImage.isDisposed())
         oldImage.dispose();
   }

   /**
    * If there is no implicit document provider set, the external one is
    * re-initialized based on the given editor input.
    *
    * @param input the (new) editor input
    */
   private void updateDocumentProvider(IEditorInput input) {
      if (getDocumentProvider() != null)
         getDocumentProvider().removeElementStateListener(fElementStateListener);

      if (fInternalDocumentProvider == null)
         fExternalDocumentProvider = DocumentProviderRegistry.getDefault()
                                                             .getDocumentProvider(input);

      if (getDocumentProvider() != null)
         getDocumentProvider().addElementStateListener(fElementStateListener);
   }

   /**
    * Internal processing of setting/changing the input to this editor.
    * Called from init() (shortly after the part construction), from
    * setInput(), and from handleEditorInputChanged().
    *
    * @param input the (new) input to be set;
    *        if <code>null</code>, this text editor is being closed
    *
    * @exception CoreException if input cannot be connected to the document
    *            provider (is not understood by this part)
    */
   protected void doSetInput(IEditorInput input) throws CoreException
   {
      if (input == null)
         close(isSaveOnCloseNeeded());
      else {
         IEditorInput oldInput = getEditorInput(); // get old input from EditorPart
         if (oldInput != null)
            getDocumentProvider().disconnect(oldInput);

         /*---------------------------------------------------------------*/
         /*  now call EditorPart#setInput() to update with the new input  */
         /*---------------------------------------------------------------*/
         super.setInput(input);

         updateDocumentProvider(input);

         IDocumentProvider provider = getDocumentProvider();
         if (provider == null) {
            IStatus s = new Status(IStatus.ERROR, PlatformUI.PLUGIN_ID, IStatus.OK,
                                   EditorMessages.getString("Editor.error.no_provider"), null);
            throw new CoreException(s);
            }

         provider.connect(input);

         initializeTitle(input);
         if (fSourceViewer != null)
            initializeSourceViewer(input);

         //updateStatusField(ITextEditorActionConstants.STATUS_CATEGORY_ELEMENT_STATE);

         // get an object which is an instance of the given class associated
         // with this input object (returns null if no such object can be found)
         // 1.- IFileEditorInput
         _inputResource = (IResource)input.getAdapter(IFile.class);

         // 2.- IStorageEditorInput (e.g., the debugger's
         //     getAdapter() method returns an IProject)
         if (_inputResource == null)
            _inputResource = (IResource)input.getAdapter(IResource.class);
         }
   }

   /**
    * Set the input to this editor.
    * Overrides EditorPart's, but doSetInput() - called in here - will eventually
    * call EditorPart's setInput() as well.
    *
    * @see org.eclipse.ui.part.EditorPart#setInput
    */
   // Eclipse R2.0 12/2001 - see new org.eclipse.ui.IReusableEditor:  interface
   // for reusable editors:  an editor may support changing its input so that
   // the workbench may change its contents instead of opening a new editor
   public final void setInput(IEditorInput input)
   {
      try {
         doSetInput(input);
         }
      catch (CoreException x) {
         String title = EditorMessages.getString("Editor.error.setinput.title");
         String msg = EditorMessages.getString("Editor.error.setinput.message");
         Shell shell = getSite().getShell();
         ErrorDialog.openError(shell, title, msg, x.getStatus());
         }
   }

   /**
    * Set this editor's preference store.  This method must be
    * called before the editor's control is created.
    * LPEX's default settings are stored in its <b>defaultProfile</b>,
    * not in the preference store.
    *
    * @param store the new preference store
    */
   protected void setPreferenceStore(IPreferenceStore store)
   {
      if (fPreferenceStore != null)
         fPreferenceStore.removePropertyChangeListener(fPropertyChangeListener);

      fPreferenceStore = store;

      if (fPreferenceStore != null)
         fPreferenceStore.addPropertyChangeListener(fPropertyChangeListener);
   }

   /**
    * Close this text editor, after optionally saving changes.
    *
    * @param save <code>true</code> if unsaved changed should be saved, or
    *             <code>false</code> if unsaved changed should be discarded
    * @see org.eclipse.ui.texteditor.ITextEditor#close
    */
   public void close(final boolean save)
   {
      Display display = getSite().getShell().getDisplay();

      display.asyncExec(new Runnable() {
         public void run() {
            if (fSourceViewer != null) { // ensure editor has not been disposed yet
               getSite().getPage().closeEditor(LpexAbstractTextEditor.this, save);
               }
            }
         });
   }

   /**
    * Dispose this part and discard all part state.  From this point on, the
    * part will not be referenced within the workbench.
    *
    * <p>The AbstractTextEditor implementation of this
    * <code>IWorkbenchPart</code> method may be extended by subclasses.
    * Subclasses must call <code>super.dispose()</code>.</p>
    *
    * <p>This method is called at the end of the part lifecycle: release any
    * resources, fonts, images, etc. held by the part.  The part control has
    * already been disposed, so there is no need to dispose it here.</p>
    *
    * @see org.eclipse.ui.IWorkbenchPart#dispose
    */
   public void dispose()
   {
      // 1.- our own disposing
      if (fPartListener != null) {
         getSite().getWorkbenchWindow().getPartService().removePartListener(fPartListener);
         fPartListener = null;
         }

      if (fTitleImage != null) {
         fTitleImage.dispose();
         fTitleImage = null;
         }

      if (fPropertyChangeListener != null) {
         if (fPreferenceStore != null) {
            fPreferenceStore.removePropertyChangeListener(fPropertyChangeListener);
            fPreferenceStore = null;
            }
         fPropertyChangeListener = null;
         }

      IDocumentProvider provider = getDocumentProvider();
      if (provider != null) {
         IEditorInput input = getEditorInput();
         if (input != null)
            provider.disconnect(input);

         if (fElementStateListener != null) {
            provider.removeElementStateListener(fElementStateListener);
            fElementStateListener = null;
            }

         fInternalDocumentProvider = null;
         fExternalDocumentProvider = null;
         }

      // remove our listeners....
      LpexView lpexView = getLpexView();
      if (lpexView != null) {
         lpexView.removeLpexViewListener(_lpexViewListener);
         lpexView.removeLpexDocumentSectionListener(_lpexDocumentSectionListener);
         lpexView.window().commandLine().removeFocusListener(_commandLineFocusListener);
         _lpexViewListener = null;
         _lpexDocumentSectionListener = null;
         _commandLineFocusListener = null;
         }

      // having no LpexSourceViewer no more
      fSourceViewer = null;

      if (fTextContextMenu != null) {
         fTextContextMenu.dispose();
         fTextContextMenu = null;
         }

      if (fRulerContextMenu != null) {
         fRulerContextMenu.dispose();
         fRulerContextMenu = null;
         }

      if (fActions != null) {
         fActions.clear();
         fActions = null;
         }

      super.setInput(null);

      // 2.- now go on with WorkbenchPart's herein-extended dispose()
      super.dispose();
   }

   /**
    * Save the contents of the target.  If the save is successful, the editor
    * fires a property-changed event, reflecting the new dirty state.
    *
    * <p>The implementation of this <code>IEditorPart</code> method may be
    * extended by subclasses.</p>
    *
    * @see org.eclipse.ui.IEditorPart#doSave
    */
   public void doSave(IProgressMonitor progressMonitor)
   {
      IDocumentProvider p = getDocumentProvider();
      if (p == null)
         return;

      // 1.- the editor input element has been meanwhile deleted
      if (p.isDeleted(getEditorInput())) {
         if (isSaveAsAllowed()) {
            /*
             * 1GEUSSR: ITPUI:ALL - User should never loose changes made in the editors.
             * Changed behavior to make sure that if called inside a regular save (because
             * of deletion of input element), there is a way to report back to the caller
             */
            performSaveAs(progressMonitor);
            }
         else {
            Shell shell = getSite().getShell();
            String title = EditorMessages.getString("Editor.error.save.deleted.title");
            String msg = EditorMessages.getString("Editor.error.save.deleted.message");
            MessageDialog.openError(shell, title, msg);
            }
         }

      // 2.- editor input element is still out there and fine
      else {
         performSaveOperation(createSaveOperation(false), progressMonitor);
         }
   }

   /**
    * Validates the state of the given editor input.  The predominant intent
    * of this method is to take any action probably necessary to ensure that
    * the input can persistently be changed.
    *
    * @param input the input to be validated
    */
   protected void validateState(IEditorInput input)
   {
      IDocumentProvider provider = getDocumentProvider();
      if (provider instanceof IDocumentProviderExtension) {
         IDocumentProviderExtension extension = (IDocumentProviderExtension)provider;
         try {
            extension.validateState(input, getSite().getShell());
            if (fSourceViewer != null)
               fSourceViewer.setEditable(isEditable());
            }
         catch (CoreException x) {
            ILog log = Platform.getPlugin(PlatformUI.PLUGIN_ID).getLog();
            log.log(x.getStatus());
            }
         }
   }

   /**
    * Updates the state of the given editor input, such as readonly flag, etc.
    *
    * @param input the input to be validated
    */
   protected void updateState(IEditorInput input)
   {
      IDocumentProvider provider = getDocumentProvider();
      if (provider instanceof IDocumentProviderExtension) {
         IDocumentProviderExtension extension = (IDocumentProviderExtension)provider;
         try {
            extension.updateStateCache(input);
            if (fSourceViewer != null)
               fSourceViewer.setEditable(isEditable());
            }
         catch (CoreException x) {
            ILog log = Platform.getPlugin(PlatformUI.PLUGIN_ID).getLog();
            log.log(x.getStatus());
            }
         }
   }

   /**
    * Create a workspace-modify operation which saves the content of the editor
    * to the editor's input element.
    * Clients may reimplement this method.
    *
    * @param overwrite indicates whether the editor input element may be
    *        overwritten if necessary
    * @return the save operation
    */
   protected WorkspaceModifyOperation createSaveOperation(final boolean overwrite)
   {
      return new WorkspaceModifyOperation() {
         public void execute(final IProgressMonitor monitor) throws CoreException
         {
            // We used to first try to save straight from LPEX to the local file,
            // emulating FileDocumentProvider.saveDocument(), but that's not
            // viable any more...  Now we update IDocument & do the real thing.
            // if (fSourceViewer != null &&
            //     fSourceViewer.doSaveAction(monitor) == true)
            //  return;

            IEditorInput input = getEditorInput();
            getDocumentProvider().
               saveDocument(monitor,          // monitor
                            input,            // the editor input element
                            getDocumentProvider().getDocument(input), // the IDoc
                            overwrite);       // overwrite?
         }};
   }

   /**
    * Perform the given save operation and handle errors appropriately.
    *
    * @param operation the operation to be performed
    * @param progressMonitor the monitor in which to run the operation
    */
   protected void performSaveOperation(WorkspaceModifyOperation operation,
                                       IProgressMonitor progressMonitor)
   {
      LpexView lpexView = getLpexView();
      int textLimit = lpexView.queryInt("current.save.textLimit");
      int firstTruncatedElement = 0;
      DocumentAdapter documentAdapter = fSourceViewer.getDocumentAdapter();
      IDocumentProvider provider = getDocumentProvider();

      try {
         /*-------------------------------------------------*/
         /* inform document provider we're changing element */
         /*-------------------------------------------------*/
         // inform this document provider about upcoming changes of the given
         // element.  The changes might cause change notifications specific for
         // the type of the given element.  If this provider manages a document
         // for the given element, the document provider must not change the
         // document because of the notifications received after aboutToChange()
         // has been called and before changed() is called.  In this case, it
         // is assumed that the document is already up to date, e.g., a save
         // operation is a typical case
         provider.aboutToChange(getEditorInput());

         /*----------------------------------------------------------------------*/
         /* LPEX-specific pre-save stuff - see also LpexTextEditor#performSaveAs */
         /*----------------------------------------------------------------------*/
         // commit any pending changes (clears 'dirty' flag), ensure all's parsed
         lpexView.doDefaultCommand("undo check");
         lpexView.doCommand("parse");

         // trim trailing blanks
         if (lpexView.queryOn("current.save.trim"))
            lpexView.trimDocument();

         // truncate (just in IDocument!) to save.textLimit
         firstTruncatedElement = lpexView.notifyTruncateDocument(documentAdapter, textLimit);

         /*------------------------------*/
         /* do the actual save operation */
         /*------------------------------*/
         operation.run(progressMonitor);
         }
      catch (InterruptedException x) {}
      catch (InvocationTargetException x) {
         Throwable t = x.getTargetException();
         if (t instanceof CoreException) {
            handleExceptionOnSave((CoreException)t, progressMonitor);
            }
         else {
            Shell shell = getSite().getShell();
            String title = EditorMessages.getString("Editor.error.save.title");
            String msg = EditorMessages.getString("Editor.error.save.message");
            MessageDialog.openError(shell, title, msg + t.getMessage());
            }
         }
      finally {
         /*-----------------------------------------------------------------------*/
         /* LPEX-specific post-save stuff - see also LpexTextEditor#performSaveAs */
         /*-----------------------------------------------------------------------*/
         if (firstTruncatedElement != 0) {
            // restore save.textlimit truncations in IDocument
            lpexView.notifyTruncateDocumentRestore(documentAdapter, textLimit,
                                                   firstTruncatedElement);
            // inform user of save truncations
            lpexView.doDefaultCommand("set messageText " +
                         LpexResources.message(LpexConstants.MSG_FILE_SAVE_TRUNCATION));
            lpexView.doDefaultCommand("locate element " + firstTruncatedElement);
            }

         // reset the changes count, ensure display is up-to-date
         lpexView.doDefaultCommand("undo resetChanges");
         lpexView.doGlobalCommand("screenShow");

         /*-------------------------------------*/
         /* inform document provider we're done */
         /*-------------------------------------*/
         // informs this document provider that the given element has been
         // changed.  All notifications have been sent out.  If this provider
         // manages a document for the given element, the document provider must
         // from now on change the document on the receipt of change notifications.
         // The concrete nature of the change notification depends on the concrete
         // type of the given element.  If the element is, e.g., an IResource, the
         // notification is a resource delta
         provider.changed(getEditorInput());
         }
   }

   /**
    * Handle the given save exception.  If the exception reports an out-of-sync
    * situation, this is reported to the user.  Otherwise, the exception
    * is generically reported.
    *
    * @param exception the exception to handle
    * @param progressMonitor the progress monitor
    */
   protected void handleExceptionOnSave(CoreException exception,
                                        IProgressMonitor progressMonitor)
   {
      try {
         ++fErrorCorrectionOnSave;

         Shell shell = getSite().getShell();

         IDocumentProvider p = getDocumentProvider();
         long modifiedStamp = p.getModificationStamp(getEditorInput());
         long synchStamp = p.getSynchronizationStamp(getEditorInput());

         if (fErrorCorrectionOnSave == 1 && modifiedStamp != synchStamp) {
            String title = EditorMessages.getString("Editor.error.save.outofsync.title");
            String msg = EditorMessages.getString("Editor.error.save.outofsync.message");

            if (MessageDialog.openQuestion(shell, title, msg))
               performSaveOperation(createSaveOperation(true), progressMonitor);
            else {
               /*
                * 1GEUPKR: ITPJUI:ALL - Loosing work with simultaneous edits
                * Set progress monitor to canceled in order to report back
                * to enclosing operations.
                */
               if (progressMonitor != null)
                  progressMonitor.setCanceled(true);
               }
            }
         else {
            String title = EditorMessages.getString("Editor.error.save.title");
            String msg = EditorMessages.getString("Editor.error.save.message");
            ErrorDialog.openError(shell, title, msg, exception.getStatus());

            /*
             * 1GEUPKR: ITPJUI:ALL - Loosing work with simultaneous edits
             * Set progress monitor to canceled in order to report back
             * to enclosing operations.
             */
            if (progressMonitor != null)
               progressMonitor.setCanceled(true);
            }
         }

      finally {
         --fErrorCorrectionOnSave;
         }
   }

   /**
    * Save the contents of the target to another object.
    * If the save is successful, the editor should fire a property-changed
    * event, reflecting the new dirty state and input object.
    *
    * <p>The LpexAbstractTextEditor implementation of this
    * <code>IEditorPart</code> calls performSaveAs(null).</p>
    *
    * @see org.eclipse.ui.IEditorPart#doSaveAs()
    */
   public void doSaveAs()
   {
      /*
       * 1GEUSSR: ITPUI:ALL - User should never lose changes made in the editors.
       * Changed behavior to make sure that if called inside a regular save (because
       * of deletion of input element), there is a way to report back to the caller
       */
      performSaveAs(new NullProgressMonitor());
   }

   /**
    * Perform a "Save as", and report the result state back to the
    * given progress monitor.
    * This default implementation does nothing.  Subclasses may reimplement.
    *
    * @param progressMonitor the progress monitor for communicating result state, or
    *                        <code>null</code>
    * @see #performSaveAs(IProgressMonitor,String)
    */
   protected void performSaveAs(IProgressMonitor progressMonitor) {}

   /**
    * Perform a "Save as", and report the result state back to the
    * given progress monitor.
    * This default implementation does nothing.  Subclasses may reimplement.
    *
    * @param fileName name of the file to save to (initial file for the SaveAs dialog)
    * @param progressMonitor the progress monitor for communicating result state, or
    *                        <code>null</code>
    * @see #performSaveAs(IProgressMonitor)
    */
   protected void performSaveAs(IProgressMonitor progressMonitor, String fileName) {}

   /**
    * Return <code>true</code> if the "Save as" operation is supported by
    * the target.
    * Overrides EditorPart's.
    * The implementation of this <code>IEditorPart</code> method returns
    * <code>false</code>.  Subclasses may override.
    *
    * @see org.eclipse.ui.IEditorPart#isSaveAsAllowed
    */
   public boolean isSaveAsAllowed()
   {
      return false;
   }

   /**
    * Return whether the contents of this editor should be saved when the editor
    * is closed.
    *
    * @return <code>true</code> if the contents of the editor should be saved
    *                           on close, or
    *         <code>false</code> if the contents are expendable
    * @see org.eclipse.ui.IEditorPart#isSaveOnCloseNeeded()
    */
   public boolean isSaveOnCloseNeeded()
   {
      //AbstractTextEditor:
      //IDocumentProvider p= getDocumentProvider();
      //return (p == null)? false : p.mustSaveDocument(getEditorInput());
      return isDirty();
   }

   /**
    * Return whether the contents of this editor have changed since the last
    * save operation.  If this value changes, the part must fire a property
    * listener event with PROP_DIRTY.
    *
    * <p>What's returned by this method determines both the display, in the
    * viewer label, of the dirty indication '*' which follows the file name, and
    * the enablement of the Save menu items (which are only enabled on changed
    * documents in Eclipse).</p>
    *
    * @see org.eclipse.ui.IEditorPart#isDirty
    */
   public boolean isDirty()
   {
      boolean dirty = false;

      // try to get the dirty info straight from the horse's mouth
      LpexView lpexView = getLpexView();
      if (lpexView != null)
         dirty = lpexView.queryOn("dirty") || lpexView.queryInt("changes") != 0;

      // DOESN'T SEEM TO BE THE CASE AS OF Eclipse R2.0 build F1!?...
//    // after e.g., replacing an open document with a version from the local
//    // history, the Eclipse Document is dirty (unlike in Eclipse R1.0) - if we
//    // don't save it, it won't be replaced in the local file system!  Therefore:
//    // Check what AbstractTextEditor does (NB we don't keep the IDocument
//    // up-to-date!...) - if it's dirty, override our indication:
//    if (!dirty) {
//       IDocumentProvider p = getDocumentProvider();
//       if (p != null)
//          dirty = p.canSaveDocument(getEditorInput());
//       }

      return dirty;
   }

   /**
    * Abandon all modifications applied to the editor's input element's textual
    * presentation since the last save operation.
    *
    * <p>The implementation of this <code>ITextEditor</code> method may be
    * extended by subclasses.</p>
    *
    * @see org.eclipse.ui.texteditor.ITextEditor#doRevertToSaved
    */
   public void doRevertToSaved()
   {
      //*as* to just do an "undo n" (where n == changes&dirty parameters)??...
      //     but what about the marks modified since? - reinitialize from markers??
      IDocumentProvider p = getDocumentProvider();
      if (p == null)
         return;

      try {
         p.resetDocument(getEditorInput());

         IAnnotationModel model = p.getAnnotationModel(getEditorInput());
         if (model instanceof AbstractMarkerAnnotationModel) {
            AbstractMarkerAnnotationModel markerModel = (AbstractMarkerAnnotationModel)model;
            // reset all the markers to their original state
            markerModel.resetMarkers();
            }

         firePropertyChange(PROP_DIRTY);
         }
      catch (CoreException x) {
         String title = EditorMessages.getString("Editor.error.revert.title");
         String msg = EditorMessages.getString("Editor.error.revert.message");
         Shell shell = getSite().getShell();
         ErrorDialog.openError(shell, title, msg, x.getStatus());
         }
   }

   /**
    * Install (i.e., cache in here) the given action under the specified
    * action name (id).
    *
    * @param actionName name of the action (e.g., "SelectAll")
    * @param action     the JFace IAction
    *
    * @see org.eclipse.ui.texteditor.ITextEditor#setAction
    */
   public void setAction(String actionName, IAction action)
   {
      Assert.isNotNull(actionName);
      if (action == null)
         fActions.remove(actionName);
      else
         fActions.put(actionName, action);
   }

   /**
    * Return the action which has been installed (i.e., cached in here) under
    * the specified action name (id).  If no action has been installed,
    * the method returns <code>null</code>.
    *
    * @see org.eclipse.ui.texteditor.ITextEditor#getAction
    */
   public IAction getAction(String actionName)
   {
      Assert.isNotNull(actionName);
      return (IAction)fActions.get(actionName);
   }

   /**
    * Create this editor's standard actions.
    *
    * <p>Actions handled in here are the standard Eclipse editor actions defined
    * in ITextEditorActionConstants (and IWorkbenchActionConstants), and some of
    * the context menu actions.
    * The standard editor actions will be connected to the workbench global
    * actions in LpexContextContributor -> BasicTextEditorActionContributor.</p>
    *
    * <p>For LPEX's contributions to the Eclipse context, see
    * LpexContextContributor.</p>
    *
    * <p>Subclasses may extend this method.</p>
    */
   protected void createActions()
   {
      //-as- NB For some [LpexEditor]Actions below, there is no key in LpexPlugin's
      // resource bundle (e.g., "Delete.") - but these actions are just linked to
      // the Eclipse global ones anyway, we don't have them on the popup...
      ResourceAction action;

      action = new LpexEditorAction("undo.", this, ITextOperationTarget.UNDO);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.UNDO_ACTION);
      setAction(ITextEditorActionConstants.UNDO, action);

      action = new LpexEditorAction("redo.", this, ITextOperationTarget.REDO);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.REDO_ACTION);
      setAction(ITextEditorActionConstants.REDO, action);

      action = new LpexEditorAction("cut.", this, ITextOperationTarget.CUT);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.CUT_ACTION);
      setAction(ITextEditorActionConstants.CUT, action);

      action = new LpexEditorAction("copy.", this, ITextOperationTarget.COPY);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.COPY_ACTION);
      setAction(ITextEditorActionConstants.COPY, action);

      action = new LpexEditorAction("paste.", this, ITextOperationTarget.PASTE);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.PASTE_ACTION);
      setAction(ITextEditorActionConstants.PASTE, action);

      action = new LpexEditorAction("Delete.", this, ITextOperationTarget.DELETE);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.DELETE_ACTION);
      setAction(ITextEditorActionConstants.DELETE, action);

      action = new LpexEditorAction("SelectAll.", this, ITextOperationTarget.SELECT_ALL);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.SELECT_ALL_ACTION);
      setAction(ITextEditorActionConstants.SELECT_ALL, action);

      action = new LpexEditorAction("Print.", this, ITextOperationTarget.PRINT);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.PRINT_ACTION);
      setAction(ITextEditorActionConstants.PRINT, action);

      action = new LpexFindAction("FindReplace.", this);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.FIND_ACTION);
      setAction(ITextEditorActionConstants.FIND, action);

      //action = new LpexEditorAction("ShiftRight.", this, ITextOperationTarget.SHIFT_RIGHT);
      //action.setHelpContextId(IAbstractTextEditorHelpContextIds.SHIFT_RIGHT_ACTION);
      //setAction(ITextEditorActionConstants.SHIFT_RIGHT, action);
      //action = new LpexEditorAction("ShiftLeft.", this, ITextOperationTarget.SHIFT_LEFT);
      //action.setHelpContextId(IAbstractTextEditorHelpContextIds.SHIFT_LEFT_ACTION);
      //setAction(ITextEditorActionConstants.SHIFT_LEFT, action);

      action = new LpexAddMarkerAction("addBookmark.", this, IMarker.BOOKMARK, true);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.BOOKMARK_ACTION);
      setAction(ITextEditorActionConstants.BOOKMARK, action);

      action = new LpexAddMarkerAction("addTask.", this, IMarker.TASK, true);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.ADD_TASK_ACTION);
      setAction(ITextEditorActionConstants.ADD_TASK, action);

      action = new LpexSaveAction(this);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.SAVE_ACTION);
      setAction(ITextEditorActionConstants.SAVE, action);

      action = new RevertToSavedAction(LpexPlugin.getResourceBundle(), "Revert.", this);
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.REVERT_TO_SAVED_ACTION);
      setAction(ITextEditorActionConstants.REVERT_TO_SAVED, action);

      // these ruler setActions are gone in Eclipse build M5 (20020416) - they're
      // added by default to the "#TextRulerContext" ruler menus;  it seems that
      // we can keep these names & redefine them for our "#LpexTextRulerContext"
      // (as it is now called in LpexTextEditor)...
      setAction(ITextEditorActionConstants.RULER_MANAGE_BOOKMARKS,
         new MarkerRulerAction(LpexPlugin.getResourceBundle(), "manageBookmarks.",
                               this, fVerticalRuler, IMarker.BOOKMARK, true));
      setAction(ITextEditorActionConstants.RULER_MANAGE_TASKS,
         new MarkerRulerAction(LpexPlugin.getResourceBundle(), "manageTasks.",
                               this, fVerticalRuler, IMarker.TASK, true));
      setAction(ITextEditorActionConstants.RULER_DOUBLE_CLICK,
         getAction(ITextEditorActionConstants.RULER_MANAGE_BOOKMARKS));
      //*as* new in Eclipse R2.0 12/2001, must adapt to LPEX & define in here:
      //setAction(ITextEditorActionConstants.RULER_CLICK,
      // new /*Lpex*/SelectMarkerRulerAction(EditorMessages.getResourceBundle(),
      //                                     "Editor.SelectMarker.",
      //                                     fVerticalRuler, this));
   }

   /**
    * Convenience method to add the action installed under the given action name
    * to the given menu.
    *
    * @param menu       menu to add the action
    * @param actionName name of the action (e.g., "SelectAll")
    */
   protected final void addAction(IMenuManager menu, String actionName)
   {
      IAction action = getAction(actionName);
      if (action != null) {
         // a TextEditorAction will update its enabled status based on the result
         // received from canDoOperation() called on the ITextOperationTarget
         if (action instanceof IUpdate)
            ((IUpdate)action).update();
         menu.add(action);
         }
   }

   /**
    * Convenience method to add the action installed under the given action id
    * to the specified group of the menu.
    */
   protected final void addAction(IMenuManager menu, String group, String actionId)
   {
      IAction action = getAction(actionId);
      if (action != null) {
         if (action instanceof IUpdate)
            ((IUpdate)action).update();

         IMenuManager subMenu = menu.findMenuUsingPath(group);
         if (subMenu != null)
            subMenu.add(action);
         else
            menu.appendToGroup(group, action);
         }
   }

   /**
    * Convenience method to add the LPEX action to the given popup menu.  If the
    * action is not installed, it is installed first.
    * Called from populateSubmenu().
    *
    * @param menu       menu to add the action
    * @param actionName the LPEX action name, e.g., "cut"
    * @param labelKey   LpexResources key for the action label, e.g., "popup.cut"
    *                   (as key for value "Cu&t")
    */
   private void addLpexAction(IMenuManager menu, String actionName, String labelKey)
   {
      IAction action = getAction(actionName);

      // the action was previously created;  for LpexPopupActions (which is what
      // we create for the popup - e.g., the filter-view parser actions), update
      // the id (LPEX's action id may have changed after an updateProfile command)
      if (action != null && action instanceof LpexPopupAction)
         ((LpexPopupAction)action).setId(getLpexView().actionId(actionName));

      if (action == null) {
         action = createLpexAction(actionName, labelKey);
         if (action != null)
            setAction(actionName, action);
         }

      addAction(menu, actionName);
   }

   /**
    * Convenience method to add a new group after the specified group.
    */
   protected final void addGroup(IMenuManager menu, String existingGroup, String newGroup)
   {
      IMenuManager subMenu = menu.findMenuUsingPath(existingGroup);
      if (subMenu != null)
         subMenu.add(new Separator(newGroup));
      else
         menu.appendToGroup(existingGroup, new Separator(newGroup));
   }

   /**
    * Set up the vertical ruler's context (popup) menu before it is made
    * visible.
    *
    * <p>Subclasses may extend to add other actions.</p>
    *
    * @param menu the menu
    */
   protected void rulerContextMenuAboutToShow(IMenuManager menu)
   {
      // only show ruler popup if mouse on position corresponding to a valid line
      if (getVerticalRuler().getLineOfLastMouseButtonActivity() >= 0) {
         addAction(menu, ITextEditorActionConstants.RULER_MANAGE_BOOKMARKS);
         addAction(menu, ITextEditorActionConstants.RULER_MANAGE_TASKS);
         }

      menu.add(new Separator(ITextEditorActionConstants.GROUP_REST));
      menu.add(new Separator(ITextEditorActionConstants.MB_ADDITIONS));
   }

   /**
    * Set up this editor's context (popup) menu before it is made visible.
    * Contribute LPEX's actions defined by the <b>current.popup</b> parameter,
    * and also add "Add bookmark/task" as per Eclipse norms.
    *
    * <p>Subclasses may extend to add other actions.</p>
    *
    * @param menu the menu
    */
   protected void editorContextMenuAboutToShow(IMenuManager menu)
   {
      /*------------------------------*/
      /*  1.- Eclipse-specific stuff  */
      /*------------------------------*/
      // if (isEditable()) {
      //  menu.add(new Separator(ITextEditorActionConstants.GROUP_UNDO));
      //  addAction(menu, ITextEditorActionConstants.UNDO);  // in LPEX's popup
      //  addAction(menu, ITextEditorActionConstants.REDO);  //  parameter as well
      //  addAction(menu, ITextEditorActionConstants.REVERT_TO_SAVED);
      //  }
      // menu.add(new Separator(ITextEditorActionConstants.GROUP_COPY));
      // if (isEditable()) {
      //  addAction(menu, ITextEditorActionConstants.CUT);   // in LPEX's
      //  addAction(menu, ITextEditorActionConstants.COPY);  //  popup parameter
      //  addAction(menu, ITextEditorActionConstants.PASTE); //  as well
      //  addAction(menu, ITextEditorActionConstants.SELECT_ALL);
      //  }
      // else {
      //  addAction(menu, ITextEditorActionConstants.COPY);
      //  addAction(menu, ITextEditorActionConstants.SELECT_ALL);
      //  }

      /*------------------------------*/
      /*  2.- LPEX's popup parameter  */
      /*------------------------------*/
      populateSubmenu(menu, new LpexStringTokenizer(getLpexView().query("current.popup")));

      /*-----------------------------------*/
      /*  3.- more Eclipse-specific stuff  */
      /*-----------------------------------*/
      menu.add(new Separator(ITextEditorActionConstants.GROUP_PRINT));
      menu.add(new Separator(ITextEditorActionConstants.GROUP_EDIT));
      //addAction(menu, ITextEditorActionConstants.SHIFT_RIGHT);
      //addAction(menu, ITextEditorActionConstants.SHIFT_LEFT);
      menu.add(new Separator(ITextEditorActionConstants.GROUP_FIND));
      //addAction(menu, ITextEditorActionConstants.FIND);
      //addAction(menu, ITextEditorActionConstants.GOTO_LINE);

      String label = LpexResources.message("popup.add");
      MenuManager submenu = new MenuManager(label, ITextEditorActionConstants.GROUP_ADD);
      addAction(submenu, ITextEditorActionConstants.BOOKMARK);
      addAction(submenu, ITextEditorActionConstants.ADD_TASK);
      menu.add(submenu);

      menu.add(new Separator(ITextEditorActionConstants.GROUP_SAVE));
      //if (isEditable())
         addAction(menu, ITextEditorActionConstants.SAVE);

      /*----------------------------------*/
      /*  4.- start the rest of the menu  */
      /*----------------------------------*/
      menu.add(new Separator(ITextEditorActionConstants.GROUP_REST));
      menu.add(new Separator(ITextEditorActionConstants.MB_ADDITIONS));
   }

   /**
    * Return the object which is an instance of the given class associated with
    * this object, or <code>null</code> if no such object can be found.
    *
    * <p>IAdaptable is an interface for an adaptable object.  Adaptable objects
    * can be dynamically extended to provide different interfaces (or "adapters").
    * Adapters are created by adapter factories, which are in turn managed by
    * type by adapter managers.</p>
    *
    * @see org.eclipse.core.runtime.IAdaptable#getAdapter(Class)
    */
   public Object getAdapter(Class required)
   {
      // LPEX: we do our own findAndReplace action, not workbench's FindReplaceAction(),
      // so we're only called here to getAdapter() for ITextOperationTargets
      // (also, LpexTextViewer doesn't implement IFindReplaceTarget)...
      //if (IFindReplaceTarget.class.equals(required))
      // return (fSourceViewer == null)? null : fSourceViewer.getFindReplaceTarget();

      if (ITextOperationTarget.class.equals(required))
         return (fSourceViewer == null)? null : fSourceViewer.getTextOperationTarget();
      return super.getAdapter(required);
   }

   /**
    * Ask the part to take focus within the workbench.
    * Gives focus to the LpexWindow.
    * @see org.eclipse.ui.IWorkbenchPart#setFocus
    */
   public void setFocus()
   {
      if (fSourceViewer != null) {
         LpexWindow lpexWindow = fSourceViewer.getLpexWindow();
         if (lpexWindow != null)
            lpexWindow.setFocus();
         }
   }

   /**
    * Set the editor's help context id.
    *
    * @param helpContextId the help context id
    */
   protected void setHelpContextId(String helpContextId)
   {
      Assert.isNotNull(helpContextId);
      fHelpContextId = helpContextId;
   }

   /**
    * Set the cursor in the editor to the specified marker, and emphasize
    * accordingly.
    *
    * <p>If the editor can be saved, all marker ranges have been changed according
    * to the text manipulations. However, those changes are not yet propagated to the
    * marker manager.  Thus, when opening a marker, the marker's position in the editor
    * must be determined as it might differ from the position stated in the marker.
    *
    * @see org.eclipse.ui.part.EditorPart#gotoMarker
    */
   public void gotoMarker(IMarker marker)
   {
      LpexView lpexView = getLpexView();
      if (lpexView == null || marker == null)
         return;

      int eolLength = getEOL().length();
      int charStart = MarkerUtilities.getCharStart(marker);
      int charEnd = MarkerUtilities.getCharEnd(marker);

      /*--------------------*/
      /*  character marker  */
      /*--------------------*/
      if (charStart >= 0 && charEnd >= 0) {
         // look up the *current* range of the marker, as the document may have
         // been edited and not yet saved (see method's comments above)
         IAnnotationModel model = getDocumentProvider().getAnnotationModel(getEditorInput());
         if (model instanceof AbstractMarkerAnnotationModel) {
            AbstractMarkerAnnotationModel markerModel = (AbstractMarkerAnnotationModel)model;
            Position pos = markerModel.getMarkerPosition(marker);
            if (pos == null || pos.isDeleted()) {
               // do nothing if position has been deleted
               return;
               }

            charStart = pos.getOffset();
            charEnd = pos.getOffset() + pos.getLength();
            }

         // NB offset conversion can only be done for
         // the currently-loaded LPEX document section
         LpexDocumentLocation start = lpexView.documentLocation(charStart, eolLength);
         if (lpexView.query("includedClasses").length() != 0) // ensure all lines reachable
            lpexView.doCommand("set includedClasses");
         lpexView.jump(start.element, start.position);
         int len = 1;
         if (charEnd != charStart) {
            LpexDocumentLocation end = lpexView.documentLocation(charEnd, eolLength);
            if (start.element == end.element) {
               len = end.position - start.position;
               if (len <= 0)
                  len = 1;
               }
            else
               len = lpexView.queryInt("length", start) - start.position + 1;
            }
         lpexView.doCommand("set emphasisLength " + len);
         }

      /*---------------*/
      /*  line marker  */
      /*---------------*/
      else {
         int element = lpexView.elementOfLine(MarkerUtilities.getLineNumber(marker));
         if (element <= 0)
            return;
         if (lpexView.query("includedClasses").length() != 0) // ensure all lines reachable
            lpexView.doCommand("set includedClasses");
         lpexView.jump(element, 1);
         int len = lpexView.queryInt("length");
         lpexView.doCommand("set emphasisLength " + len);
         }

      lpexView.doCommand("screenShow");
   }

   /**
    * Handle an external change of the editor's input element.
    */
   protected void handleEditorInputChanged()
   {
      String title;
      String msg;
      Shell shell = getSite().getShell();

      IDocumentProvider provider= getDocumentProvider();
      if (provider == null) {
         // fix for http://dev.eclipse.org/bugs/show_bug.cgi?id=15066
         close(false);
         return;
         }

      // 1.- our previous editor input has been meanwhile deleted
      if (provider.isDeleted(getEditorInput())) {
         if (isSaveAsAllowed()) {
            title = EditorMessages.getString("Editor.error.activated.deleted.save.title");
            msg = EditorMessages.getString("Editor.error.activated.deleted.save.message");

            String[] buttons = {
               EditorMessages.getString("Editor.error.activated.deleted.save.button.save"),
               EditorMessages.getString("Editor.error.activated.deleted.save.button.close")
               };

            MessageDialog dialog = new MessageDialog(shell, title, null, msg,
                                                     MessageDialog.QUESTION, buttons, 0);

            if (dialog.open() == 0) {
               NullProgressMonitor pm = new NullProgressMonitor();
               performSaveAs(pm);
               if (pm.isCanceled())
                  handleEditorInputChanged();
               }
            else {
               close(false);
               }

            }
         else {
            title = EditorMessages.getString("Editor.error.activated.deleted.close.title");
            msg = EditorMessages.getString("Editor.error.activated.deleted.close.message");
            MessageDialog.openConfirm(shell, title, msg);
            }
         }

      // 2.- editor input still there
      // SAMPLE SCENARIO: change the file outside Eclipse (e.g., with another editor),
      // then go and re-activate the file's view in Eclipse
      else {
         title = EditorMessages.getString("Editor.error.activated.outofsync.title");
         msg = EditorMessages.getString("Editor.error.activated.outofsync.message");
         // The file has been changed on the file system.  Do you want to load the changes?

         if (MessageDialog.openQuestion(shell, title, msg)) {
            try {
               doSetInput(getEditorInput());
               }
            catch (CoreException x) {
               title = EditorMessages.getString("Editor.error.refresh.outofsync.title");
               msg = EditorMessages.getString("Editor.error.refresh.outofsync.message");
               ErrorDialog.openError(shell, title, msg, x.getStatus());
               }
            }
         }
   }

   /**
    * Query whether the editor is configured to show the highlight range only,
    * or all of the input element's textual representation.
    *
    * @see org.eclipse.ui.texteditor.ITextEditor#showsHighlightRangeOnly
    */
   public boolean showsHighlightRangeOnly()
   {
      return fShowHighlightRangeOnly;
   }

   /**
    * Configure the editor to show / not show the highlight range only.
    *
    * @see org.eclipse.ui.texteditor.ITextEditor#showHighlightRangeOnly
    */
   public void showHighlightRangeOnly(boolean showHighlightRangeOnly)
   {
      fShowHighlightRangeOnly = showHighlightRangeOnly;
   }

   /**
    * Set the highlight range to the specified region.
    *
    * @see org.eclipse.ui.texteditor.ITextEditor#setHighlightRange
    */
   public void setHighlightRange(int start, int len, boolean moveCursor)
   {
      if (fSourceViewer == null)
         return;

      //if (fShowHighlightRangeOnly) {
      // if (moveCursor) {
      //  IRegion visibleRegion = fSourceViewer.getVisibleRegion();
      //  if (start != visibleRegion.getOffset() || len != visibleRegion.getLength())
      //   fSourceViewer.setVisibleRegion(start, len); // the LPEX method does nothing...
      //  }
      // }
      //else {
         IRegion rangeIndication = fSourceViewer.getRangeIndication();
         if (rangeIndication == null || start != rangeIndication.getOffset() ||
             len != rangeIndication.getLength())
            fSourceViewer.setRangeIndication(start, len, moveCursor);
      // }
   }

   /**
    * Return the highlighted range of this text editor.
    * @see org.eclipse.ui.texteditor.ITextEditor#getHighlightRange
    */
   public IRegion getHighlightRange()
   {
      if (fSourceViewer == null)
         return null;

      if (fShowHighlightRangeOnly)
         return fSourceViewer.getVisibleRegion();

      return fSourceViewer.getRangeIndication();
   }

   /**
    * This method is not currently implemented in LpexAbstractTextEditor.
    * Preferred method: use the <b>set keyAction</b> LPEX command.
    *
    * @param actionName LPEX action name
    * @see org.eclipse.ui.texteditor.ITextEditor#setActionActivationCode(String, char, int, int)
    */
   public void setActionActivationCode(String actionName, char activationCharacter,
                                       int activationKeyCode, int activationStateMask) {}

   /**
    * This method is not currently implemented in LpexAbstractTextEditor.
    * Preferred method: use the <b>set keyAction</b> LPEX command.
    *
    * @param actionName LPEX action name
    * @see org.eclipse.ui.texteditor.ITextEditor#removeActionActivationCode(String)
    */
   public void removeActionActivationCode(String actionName) {}

   /**
    * Reset the highlight range.
    *
    * @see org.eclipse.ui.texteditor.ITextEditor#resetHighlightRange
    */
   public void resetHighlightRange()
   {
      if (fSourceViewer == null)
         return;

      if (fShowHighlightRangeOnly)
         fSourceViewer.resetVisibleRegion();
      else
         fSourceViewer.removeRangeIndication();
   }

   /**
    * Adjust the highlight range so that at least the specified range
    * is highlighted.
    * Subclasses may re-implement this method.
    *
    * @param offset the offset of the range which at least should be highlighted
    * @param length the length of the range which at least should be highlighted
    */
   protected void adjustHighlightRange(int offset, int len)
   {
      if (fSourceViewer == null)
         return;

      if (!fSourceViewer.overlapsWithVisibleRegion(offset, len))
         fSourceViewer.resetVisibleRegion();
   }

   /**
    * Select and reveal the specified range in this text editor.
    *
    * @param offset the offset of the selection
    * @param len    the length of the selection
    * @see org.eclipse.ui.texteditor.ITextEditor#selectAndReveal
    */
   public void selectAndReveal(int start, int len)
   {
      if (fSourceViewer == null)
         return;

      //LpexWindow widget = fSourceViewer.getLpexWindow();
      //widget.setRedraw(false);
      //{
         adjustHighlightRange(start, len);

         fSourceViewer.revealRange(start, len);
         fSourceViewer.setSelectedRange(start, len);
      //}
      //widget.setRedraw(true);
   }

   /**
    * Fire a property-changed event.
    *
    * @param property the id of the property that changed
    * @see org.eclipse.ui.part.WorkbenchPart#firePropertyChange
    */
   protected void firePropertyChange(int property)
   {
      super.firePropertyChange(property);
   }

   /**
    * Convenience method to retrieve the underlying LPEX text-widget view on
    * the document.
    */
   public LpexView getLpexView()
   {
      return (fSourceViewer != null)? fSourceViewer.getLpexView() : null;
   }

   /**
    * Convenience method to retrieve the underlying LPEX text-widget window
    * (an SWT Composite).
    */
   public LpexWindow getLpexWindow()
   {
      return (fSourceViewer != null)? fSourceViewer.getLpexWindow() : null;
   }

   /**
    * LpexView listener to take care of document 'dirty' state changes, and
    * update the enable state of our actions.
    */
   private LpexViewListener getLpexViewListener()
   {
      if (_lpexViewListener == null)
         _lpexViewListener = new LpexViewAdapter() {
            public void shown(LpexView view) {
               boolean modified = view.queryInt("changes") != 0 || view.queryOn("dirty");
               if (_modified != modified) {
                  _modified = modified;
                  firePropertyChange(PROP_DIRTY);
                  }
               updateWorkbenchActions();
               }
            };
      return _lpexViewListener;
   }

   /**
    * FocusListener on the LPEX command line, in order to update the
    * cut/copy/paste global actions whenever the command line gets input
    * focus (e.g., via a user mouse click on it, where we don't get a
    * shown() notification above).
    */
   private FocusListener getCommandLineFocusListener()
   {
      if (_commandLineFocusListener == null)
         _commandLineFocusListener = new FocusListener() {
            public void focusGained(FocusEvent e) {
               commandLineFocusGained();
               }
            public void focusLost(FocusEvent e) {
               commandLineFocusLost();
               }
            };
      return _commandLineFocusListener;
   }

   private void commandLineFocusGained()
   {
      // -as- if there were one, add a text-selection listener if on
      // a text field, in order to enable correctly cut/copy actions
      // _commandLineTextControl = commandLineTextControl(getLpexView());
      // if (_commandLineTextControl != null)
      //    _commandLineTextControl.addSelectionListener(getCommandLineSelectionListener());
      updateClipboardActions();
   }

   private void commandLineFocusLost()
   {
      // -as- remove the selection listener
      // if (_commandLineTextControl != null)
      //  _commandLineTextControl.removeSelectionListener(_commandLineSelectionListener);
      updateClipboardActions();
   }

   // -as- SelectionListener on LPEX command line Text controls' text, to update
   // the cut and copy global actions whenever the command line has input focus.
   // private SelectionListener getCommandLineSelectionListener() {
   //  if (_commandLineSelectionListener == null)
   //   _commandLineSelectionListener = new SelectionListener() {
   //    public void widgetSelected(SelectionEvent e)
   //    { updateClipboardActions(); }
   //    public void widgetDefaultSelected(SelectionEvent e)
   //    {}
   //   };
   //  return _commandLineSelectionListener;
   // }

   /**
    * Hook to initialize a newly instantiated LpexView during the construction
    * of this text editor's SourceViewer.
    *
    * <p>Extend this method to set any file/view-specific parameters for this
    * LpexView.</p>
    *
    * <p>Here you may set any "File Open" preference-page settings for your
    * solution's plugin, such as <b>sequenceNumbers</b>, <b>sourceEncoding</b>,
    * <b>save.textLimit</b>, and <b>save.trim</b>.
    * The <b>updateProfile</b> command will be called later.</p>
    *
    * @see #updateProfile
    */
   public void initializeLpexView(LpexView lpexView) {}

   /**
    * Extend this method for post-<b>updateProfile</b> command processing.
    * For example, define your own LPEX actions and assign them to keys, define
    * your own LPEX commands, etc.
    * Ensure you also call <code>super.updateProfile()</code>.
    *
    * <p>Called when a new LpexSourceViewer is created (an LPEX document
    * is opened), and whenever the <b>updateProfile</b> command is issued
    * afterwards.</p>
    *
    * @see #initializeLpexView
    */
   public void updateProfile()
   {
      LpexView lpexView = getLpexView();
      if (lpexView == null)
         return;

      // Eclipse desktop takes over the accelerator keys for cut, copy, and
      // paste, and only sends the corresponding actions.  (The actions are also
      // sent from the "Edit" corresponding menu items, a situation currently
      // not handled by other versions of LPEX either...)
      // In LPEX, the focus may be on the command line, in which case carrying
      // out the cut, copy, or paste *action* is not appropriate - the command
      // line's field must be passed the cut/copy/paste request.
      // Override these actions to use the current context.
      LpexAction lpexAction = new LpexAction() {
         public void doAction(LpexView view) {
            if (view.window().textWindow().isFocusControl())
               view.doDefaultAction(LpexConstants.ACTION_CUT);
            else {
               Text text = commandLineTextControl(view);
               if (text != null)
                  text.cut();
               }
            }
         public boolean available(LpexView view) {
            if (view.window().textWindow().isFocusControl())
               return view.defaultActionAvailable(LpexConstants.ACTION_CUT);
            return commandLineTextControl(view) != null;
            // we can't listen to text-selection changes here, so enable by
            // default in order to have the accelerator (Ctrl+X) working...
            // && text.getSelectionCount() != 0;
            }
         };
      lpexView.defineAction("eclipseCut", lpexAction);

      lpexAction = new LpexAction() {
         public void doAction(LpexView view) {
            if (view.window().textWindow().isFocusControl())
               view.doDefaultAction(LpexConstants.ACTION_COPY);
            else {
               Text text = commandLineTextControl(view);
               if (text != null)
                  text.copy();
               }
            }
         public boolean available(LpexView view) {
            if (view.window().textWindow().isFocusControl())
               return view.defaultActionAvailable(LpexConstants.ACTION_COPY);
            return commandLineTextControl(view) != null;
            // we can't listen to text-selection changes here, so enable by
            // default in order to have the accelerator (Ctrl+C) working...
            // && text.getSelectionCount() != 0;
            }
         };
      lpexView.defineAction("eclipseCopy", lpexAction);

      lpexAction = new LpexAction() {
         public void doAction(LpexView view) {
            if (view.window().textWindow().isFocusControl())
               view.doDefaultAction(LpexConstants.ACTION_PASTE);
            else {
               Text text = commandLineTextControl(view);
               if (text != null)
                  text.paste();
               }
            }
         public boolean available(LpexView view) {
            if (view.window().textWindow().isFocusControl())
               return view.defaultActionAvailable(LpexConstants.ACTION_PASTE);
            return commandLineTextControl(view) != null;
            }
         };
      lpexView.defineAction("eclipsePaste", lpexAction);

      //*as* Linux Eclipse driver 0.105 bug: popup doesn't show on our LpexWindow
      //Composite-made-up-of-several-Composites...  Define mouse button 2 to do it
      //(we do get its MouseEvent, unlike button 3's, which is consumed by Eclipse),
      //which works fine for two-button mice
      lpexView.doCommand("set mouseAction.2-pressed.1 popupAtMouse");

      // redefine LPEX's "save" command, to do it in Eclipse's context
      lpexView.defineCommand("save", new LpexCommand() {
         public boolean doCommand(LpexView view, String parameters) {
            return performSaveCommand(view, parameters);
            }
         });

      // define a "quit" command (used e.g., by the vi baseProfile)
      lpexView.defineCommand("quit", new LpexCommand() {
         public boolean doCommand(LpexView view, String parameters) {
            close(false);
            return true;
            }
         });
   }

   /**
    * Carry out the LPEX <b>save</b> command in the Eclipse context.
    *
    * -as- must refine this - cf. com.ibm.lpex.core.SaveCommand...
    */
   private boolean performSaveCommand(LpexView lpexView, String parameters)
   {
      LpexStringTokenizer st = new LpexStringTokenizer(parameters);
      // 1.- "save"
      if (!st.hasMoreTokens() /*or arguments that we don't care about*/) {
         // do what org.eclipse.ui.texteditor.SaveAction does
         getSite().getPage().saveEditor(this, false);
         return true;
         }

      // 2.- "save <parameters>"
      String token = st.nextToken();
      // (a) "save <filename>"
      if (!st.hasMoreTokens() /*or arguments that we don't care about*/) {
         if (LpexStringTokenizer.isInvalidQuotedString(token)) {
            lpexView.doDefaultCommand("set messageText " +
                          LpexResources.message(LpexConstants.MSG_COMMAND_INVALID_QUOTED_PARAMETER,
                          token, "save"));
            return false;
            }
         String fileName = LpexStringTokenizer.trimQuotes(token);
         performSaveAs(new NullProgressMonitor(), fileName);
         return true;
         }

      // (b) "save <parameters>"
      return lpexView.doDefaultCommand("save " + parameters);
   }

   /**
    * Return the Text control with the focus, if any, in the LPEX command line
    * of the window associated with the specified LpexView.
    */
   private Text commandLineTextControl(LpexView lpexView)
   {
      Widget widget = lpexView.commandLineFocusWidget();
      return (widget != null && widget instanceof Text)? (Text)widget : null;
   }

   /**
    * Update global actions.  Workbench menus don't initialize before every
    * show (like the context menu does), so the enable state of their actions
    * must be kept up-to-date.
    * Called on every display refresh of the LPEX screen.
    */
   private void updateWorkbenchActions()
   {
      for (LpexEditorAction action = _firstAction; action != null; action = action.next())
         action.update();
   }

   /**
    * Update global clipboard actions.  Workbench menus don't initialize before
    * every show (like the context menu does), so the enable state of their
    * actions must be kept up-to-date.
    * Called whenever the LPEX command line gains or loses focus.
    */
   private void updateClipboardActions()
   {
      IAction action = getAction(ITextEditorActionConstants.CUT);
      if (action != null) ((IUpdate)action).update();
      action = getAction(ITextEditorActionConstants.COPY);
      if (action != null) ((IUpdate)action).update();
      action = getAction(ITextEditorActionConstants.PASTE);
      if (action != null) ((IUpdate)action).update();
   }

   /**
    * Create a TextEditorAction for an LPEX action for the popup menu.
    * Called from addLpexAction().
    *
    * @param actionName LPEX action name, e.g., "cut"
    * @param labelKey   LpexResources key for the action label, e.g., "popup.cut"
    *                   (as key for "Cu&t")
    * @return the newly created TextEditorAction, or
    *         <code>null</code> if actionName is not a valid LPEX action
    */
   private IAction createLpexAction(String actionName, String labelKey)
   {
      LpexPopupAction action = null;

      String label;
      String description = null;
      if (LpexStringTokenizer.isValidQuotedString(labelKey))
         label = LpexStringTokenizer.removeQuotes(labelKey);
      else {
         label = LpexResources.message(labelKey);
         if (label == null)
            label = labelKey;
         else {
            description = LpexResources.message(labelKey + ".description");
            //*as* if no description in LpexResources [or no labelKey in the first
            // place], see if this action is an instance of LpexResourceAction
            // (when we invent it...), and query [label,] description, etc.!?
            }
         }

      int id = getLpexView().actionId(actionName);
      if (id != LpexConstants.ACTION_INVALID) {
         //-as- IF we add NLS accelerator text to the label (but Eclipse R2.0
         // doesn't yet display it on the popup menus anyway):
         //  String accelerator = getLpexView().actionKeyText(actionId);
         //  if (accelerator != null)
         //   label += '\t' + accelerator;
         // THEN make sure LpexPopupAction.getAccelerator() returns 0, so
         // we don't get into Eclipse's key-action binding & its problems
         // (cf. we also avoid this in LpexContextContributor)...
         action = new LpexPopupAction(this, id, label, description);

         // register context help
         //-as- for popup actions contributed by LPEX users (e.g., additional
         // parser Filter view menu item), we can use LpexResourceAction &
         // query this action's context-help string, BUT can we point to the
         // context help of another plugin (probably, it is one using us, like
         // we set here Eclipse's own context help for other actions)?!...
         action.setHelpContextId("com.ibm.lpex."+labelKey.replace('.', '_')+"_context");
         }
      //else
      // getLpexView().setLpexMessageText(LpexConstants.MSG_ACTION_INVALID, actionName);

      return action;
   }

   /**
    * Populate the context (popup) menu with LPEX-defined actions, as per the
    * tokenized string passed in.
    */
   private boolean populateSubmenu(IMenuManager menu, LpexStringTokenizer st)
   {
      while (st.hasMoreTokens()) {
         String token = st.nextToken();
         if (token.equals("endSubmenu"))
            return true;
         if (token.equals("beginSubmenu")) {
            if (st.hasMoreTokens()) {
               token = st.nextToken();
               String label;
               if (LpexStringTokenizer.isValidQuotedString(token))
                  label = LpexStringTokenizer.removeQuotes(token);
               else {
                  label = LpexResources.message(token);
                  if (label == null)
                     label = token;
                  }
               MenuManager submenu = new MenuManager(label);
               menu.add(submenu);
               if (!populateSubmenu(submenu, st))
                 return false;
               }
            }
         else if (token.equals("separator")) {
            menu.add(new Separator()); // give them group names, like LpexAbstractTextEditor?! -as-
            }
         else if (st.hasMoreTokens()) {
            String actionName = st.nextToken();
            addLpexAction(menu, actionName, token);
            }
         }
      return true;
   }

   /**
    * Add an LpexViewListener to take care of 'dirty' state chages, and
    * a command-line focus listener to update the enable state of our actions.
    *
    * <p>Called from initializeSourceViewer().</p>
    */
   private void addDirtyListener()
   {
      _modified = false;
      LpexView lpexView = getLpexView();
      if (lpexView != null) {
         // handle document 'dirty' state changes, and update
         // the enable state of our actions
         lpexView.addLpexViewListener(getLpexViewListener());

         // update the cut/copy/paste global actions & accelerator keys
         // whenever the command line line gets focus
         lpexView.window().commandLine().addFocusListener(getCommandLineFocusListener());
         }
   }


   /*=========================================================================*/
   /* Document-section management.                                            */
   /*=========================================================================*/

   private boolean _documentSection;
   private LpexDocumentSectionListener _lpexDocumentSectionListener;

   /**
    * Establish the boundaries of the LPEX document section that was loaded or
    * is going to be loaded in the text widget, and initiate the management of
    * this document section.
    *
    * <p>Note that this feature is only available for certain specific text
    * editor applications.  Normally, the LPEX text widget loads and operates
    * on a complete document (underlying resource).</p>
    *
    * <p>This method requires the LPEX text widget to have been already created.
    * Initially, it must be called after calling super.createSourceViewer(),
    * if the method createSourceViewer() is extended, or otherwise at any time
    * after createPartControl().  Afterwards, this method may be called
    * following document-section updates triggered by addLines()
    * notifications.</p>
    *
    * @see #addLines
    */
   protected void setDocumentSection(int linesBeforeStart, int linesAfterEnd)
   {
      LpexView lpexView = getLpexView();
      if (lpexView == null)
         return;

      // entire document has been loaded, no more section management
      if (linesBeforeStart == 0 && linesAfterEnd == 0) {
         if (_lpexDocumentSectionListener != null) {
            lpexView.removeLpexDocumentSectionListener(_lpexDocumentSectionListener);
            _lpexDocumentSectionListener = null;
            }
         }
      // or else start the document-section listener, if not done yet
      else if (_lpexDocumentSectionListener == null) {
         _lpexDocumentSectionListener = new LpexDocumentSectionListener() {
            public boolean addLines(LpexView lpexView, int neededLine) {
               return manageDocumentSection(lpexView, neededLine);
               }
            };
         lpexView.addLpexDocumentSectionListener(_lpexDocumentSectionListener);
         }

      // update document section boundaries in the LPEX text widget
      lpexView.setLinesOutsideDocumentSection(linesBeforeStart, linesAfterEnd);
   }

   /**
    * Manage a document-listener notification to expand the document section.
    */
   private boolean manageDocumentSection(LpexView lpexView, int neededLine)
   {
      int linesBeforeStart = lpexView.linesBeforeStart();

      // save current cursor, row state
      int currentLine = lpexView.queryInt("line");
      int currentPosition = lpexView.currentPosition();
      int cursorRow = lpexView.queryInt("cursorRow");
      int emphasisLength = lpexView.queryInt("emphasisLength");

      // save block if any & if in this view
      String blockType=null;
      int blockTopLine=0, blockTopPosition=0, blockBottomLine=0, blockBottomPosition=0;
      boolean blockInView = lpexView.queryOn("block.inView");
      if (blockInView) {
         blockType = lpexView.query("block.type");
         blockTopLine = lpexView.lineOfElement(lpexView.queryInt("block.topElement") -
                                               linesBeforeStart) + linesBeforeStart;
         blockBottomLine = lpexView.lineOfElement(lpexView.queryInt("block.bottomElement") -
                                                  linesBeforeStart) + linesBeforeStart;
         blockTopPosition = lpexView.queryInt("block.topPosition");
         blockBottomPosition = lpexView.queryInt("block.bottomPosition");
         }

      // call user's hook to expand / re-set the LPEX document section;
      // the user loads in the needed lines, and updates the section either with:
      //  setDocumentSection(newLinesBeforeStart, newLinesAfterEnd);
      // or by calling directly:
      //  lpexView.setLinesOutsideDocumentSection(newLinesBeforeStart, newLinesAfterEnd);
      //*as* FOR NOW, SUSPEND LISTENING TO BOTH THE LPEX AND ECLIPSE DOCUMENTS
      //     DURING addLines(), AND LET THE USER SETTLE THEIR OWN DOCS MANAGEMENT !?
      DocumentAdapter documentAdapter = fSourceViewer.getDocumentAdapter();
      documentAdapter.listenToLpexDocument(false);
      documentAdapter.listenToEclipseDocument(false);
      boolean restore = addLines(lpexView, neededLine);
      documentAdapter.listenToEclipseDocument(true);
      documentAdapter.listenToLpexDocument(true);

      linesBeforeStart = lpexView.linesBeforeStart(); // get new value

      // restore state if the document section contents were completely re-set
      if (restore) {
         if (currentLine != lpexView.queryInt("line")) {
            int currentElement = lpexView.elementOfLine(currentLine - linesBeforeStart);
            // original cursor line still available in the adjusted document section
            if (currentElement != 0) {
               // 1.- restore saved block if still inside document section & none now
               if (blockInView && !lpexView.queryOn("block.inView")) {
                  int topElement = lpexView.elementOfLine(blockTopLine - linesBeforeStart);
                  int bottomElement = lpexView.elementOfLine(blockBottomLine - linesBeforeStart);
                  if (topElement != 0 && bottomElement != 0) {
                     // set in the right order, in case it's a stream block
                     if (topElement == currentElement && blockTopPosition == currentPosition) {
                        lpexView.jump(bottomElement, blockBottomPosition);
                        lpexView.doDefaultCommand("block set " + blockType);
                        lpexView.jump(topElement, blockTopPosition);
                        }
                     else {
                        lpexView.jump(topElement, blockTopPosition);
                        lpexView.doDefaultCommand("block set " + blockType);
                        lpexView.jump(bottomElement, blockBottomPosition);
                        }
                     lpexView.doDefaultCommand("block set");
                     }
                  }

               // 2.- restore cursor, its screen row, emphasis
               lpexView.jump(currentElement, currentPosition);
               lpexView.doDefaultCommand("set cursorRow " + cursorRow);
               lpexView.doDefaultCommand("set emphasisLength " + emphasisLength);
               }
            }
         }

      // if now the entire document is loaded in, don't listen no more
      if (linesBeforeStart == 0 && lpexView.linesAfterEnd() == 0) {
         if (_lpexDocumentSectionListener != null) {
            lpexView.removeLpexDocumentSectionListener(_lpexDocumentSectionListener);
            _lpexDocumentSectionListener = null;
            }
         }

      return true;
   }

   /**
    * Hook for managing an LPEX text-widget document section.
    *
    * <p>This method is invoked when it was determined that the currently-loaded
    * LPEX text-widget document section should be expanded.  A minimum of about
    * two screen rows of lines is expected to be loaded around the current
    * (cursor) line at any time.</p>
    *
    * <p>The current implementation of this method does nothing beyond returning
    * <code>false</code>.  The DocumentAdapter of this editor's text viewer is
    * currently suspended from listening to both the Eclipse document and the
    * LPEX document when calling this hook.</p>
    *
    * @param lpexView the LPEX text-widget view
    * @param lineNeeded the first line before the currently-loaded LPEX document
    *        section, or the last line after the currently-loaded LPEX document
    *        section, in the range of lines with which the current document
    *        section must be expanded;
    *        lineNeeded already includes the minimum threshold indicated
    *
    * @return true = try to restore the original position in the view (this
    *         is recommended when e.g., the document section was updated by
    *         replacing the entire contents of the text widget)
    *
    * @see #setDocumentSection
    */
   protected boolean addLines(LpexView lpexView, int neededLine)
   {
      return false;
   }


   /*=========================================================================*/
   /* others                                                                  */
   /*=========================================================================*/

   /**
    * Retrieve the IResource underlying our editor input (file / storage).
    * It is used to retrieve the IProject for save-as operations.
    */
   protected IResource getInputResource()
   {
      return _inputResource;
   }

   /**
    * Create an LPEX mark corresponding to the given Eclipse marker.
    * LPEX marks are maintained in sync with the text during editing.
    * LPEX marks are created automatically for an IFile / IResource
    * handled by this text editor.  When an LPEX mark is deleted as a result of
    * a text-editing operation, its corresponding Eclipse marker will also be
    * deleted.
    *
    * <p>The mark is defined inside the currently-loaded LPEX document section,
    * and assumes that the marker is defined in an IDocument corresponding to
    * this section.</p>
    *
    * @deprecated N/A as of Eclipse R2.0 build F1, IDocument is now keeping
    * sync-ed with LPEX changes, markers being consequently maintained
    */
   public void addMark(IMarker marker) {}

   /**
    * An LPEX mark was deleted, delete its corresponding Eclipse marker.
    * An application may prevent the removal of (some of) its markers by
    * extending this method, and simply returning when the specified marker
    * should not be deleted.
    *
    * @deprecated N/A as of Eclipse R2.0 build F1, IDocument is now keeping
    * sync-ed with LPEX changes, markers being consequently maintained
    */
   protected void deleteMarker(long markerId) {}

   /**
    * Bring the location of this editor's input resource markers back in sync
    * with the location of LpexView's corresponding marks.
    * This positional update of the markers takes place on every save operation.
    *
    * <p>As LPEX doesn't keep the IDocument and, consequently, its listeneres
    * up-to-date, during an edit session the up-to-date location of a marker can
    * only be established from the corresponding LPEX mark set in LpexView.</p>
    *
    * <p>Markers are defined, and have corresponding LPEX marks set, inside the
    * currently-loaded LPEX document section.</p>
    *
    * @deprecated N/A as of Eclipse R2.0 build F1, IDocument is now keeping
    * sync-ed with LPEX changes, markers being consequently maintained
    */
   public void updateMarkers() {}

   /**
    * Return the line delimiter used by the document currently handled by
    * this text editor.  This method assumes that a consistent line separator
    * is used throughout the document (i.e., throughout the original underlying
    * file resource).
    */
   public String getEOL()
   {
      return (fSourceViewer != null)? fSourceViewer.getEOL() :
                                      System.getProperty("line.separator");
   }

   /*=========================================================================*/
   /* LPEX-adapted editor actions.                                            */
   /*=========================================================================*/

   /**
    * Save action.  org.eclipse.ui.texteditor.SaveACtion is extended here solely
    * in order to use LpexResources for the label and description (which are
    * defined according to the LpexResources syntax rules).
    */
   private class LpexSaveAction extends SaveAction
   {
      public LpexSaveAction(ITextEditor editor)
      {
         super(LpexPlugin.getResourceBundle(), "save.", editor);

         setText(LpexResources.message("popup.save"));
         setDescription(LpexResources.message("popup.save.description"));
         setToolTipText(LpexResources.message("popup.save.description"));
      }
   }

   /**
    * An LPEX-oriented action that we can manipulate comfortably for our
    * implementation of the standard editor actions.
    *
    * All the actions are linked in a list (_firstAction);  the enable/disable
    * state is updated by a call to update() on each LPEX screen's display
    * refresh (see updateWorkbenchActions()).
    */
   private class LpexEditorAction extends TextEditorAction
   {
      private LpexEditorAction _next;
      private int fOperationCode = -1;

      /**
       * Create an LPEX editor action and link it in a list.
       *
       * @param key    action's key prefix in the LPEX plugin resource bundle
       * @param editor the text editor handling this action
       * @param id     LPEX action id (=> TextEditorAction.fOperationCode)
       */
      public LpexEditorAction(String key, LpexAbstractTextEditor editor, int id)
      {
         super(LpexPlugin.getResourceBundle(), key, editor);
         fOperationCode = id;

         _next = _firstAction;
         _firstAction = this;
      }

      LpexEditorAction next()
      {
         return _next;
      }

      /**
       * Update the enable/disable state of the action.
       */
      public void update()
      {
         // simplify what TextOperationAction does by shortcutting to LPEX;
         // Action.setEnabled(isEnabled) also fires a property change;
         // NB this prevents the user from changing the operation target
         // and/or overriding canDoOperation() for this action - user must
         // redefine the LPEX action instead!
         LpexView lpexView = ((LpexAbstractTextEditor)getTextEditor()).getLpexView();
         setEnabled(lpexView != null &&
                    lpexView.actionAvailable(fOperationCode));
      }

      /**
       * Action selected, run it.
       */
      public void run()
      {
         // simplify what TextOperationAction does by shortcutting to LPEX;
         // NB this prevents the user from changing the operation target
         // and/or overriding doOperation() for this action - user must
         // redefine the LPEX action instead!
         LpexView lpexView = ((LpexAbstractTextEditor)getTextEditor()).getLpexView();
         if (lpexView != null)
            lpexView.triggerAction(fOperationCode);
      }
   }

   /**
    * An LPEX-oriented action used for the popup menu items.
    *
    * As popup menu items are recreated every time the popup is about to display,
    * these actions are not updated on every LPEX screen's display refresh
    * (and, therefore, are not linked in a list).
    *
    * See LpexEditorAction.
    */
   private class LpexPopupAction extends TextEditorAction
   {
      private int fOperationCode = -1;

      /**
       * Create an LPEX operation action.
       *
       * @param editor the text editor handling this action
       * @param id     LPEX action id (=> TextEditorAction.fOperationCode)
       */
      public LpexPopupAction(LpexAbstractTextEditor editor, int id,
                             String label, String description)
      {
         super(LpexPlugin.getResourceBundle(), "", editor);
         fOperationCode = id;

         setText(label);
         //*as* description doesn't appear to work in Eclipse right now...
         setDescription(description);
      }

      /**
       * Update action id.  Methods update() and run() will use the new id
       * (NB like in LpexEditorAction, they shortcut to LPEX).
       */
      void setId(int id)
      {
         fOperationCode = id;
      }

      /**
       * Update the enable/disable state of the action.
       */
      public void update()
      {
         LpexView lpexView = ((LpexAbstractTextEditor)getTextEditor()).getLpexView();
         setEnabled(lpexView != null &&
                    lpexView.actionAvailable(fOperationCode));
      }

      /**
       * Action selected, run it.
       */
      public void run()
      {
         LpexView lpexView = ((LpexAbstractTextEditor)getTextEditor()).getLpexView();
         if (lpexView != null)
            lpexView.triggerAction(fOperationCode);
      }
   }

   /**
    * Find action which runs either the <b>find</b> or the <b>findAndReplace</b>
    * LPEX action, depending on the <b>readonly</b> parameter.
    */
   private class LpexFindAction extends LpexEditorAction
   {
      public LpexFindAction(String key, LpexAbstractTextEditor editor)
      {
         super(key, editor, -1);
      }

      public void update()
      {
         LpexView lpexView = ((LpexAbstractTextEditor)getTextEditor()).getLpexView();
         setEnabled(lpexView != null &&
                    lpexView.actionAvailable(lpexView.queryOn("readonly")?
                LpexConstants.ACTION_FIND : LpexConstants.ACTION_FIND_AND_REPLACE));
      }

      public void run()
      {
         LpexView lpexView = ((LpexAbstractTextEditor)getTextEditor()).getLpexView();
         if (lpexView != null)
            lpexView.triggerAction(lpexView.queryOn("readonly")?
                LpexConstants.ACTION_FIND : LpexConstants.ACTION_FIND_AND_REPLACE);
      }
   }

   /*=========================================================================*/
   /* LPEX-adapted marker actions.                                            */
   /*=========================================================================*/

   /**
    * Variation of AddMarkerAction for LPEX.
    * This action is always enabled.
    */
   private class LpexAddMarkerAction extends AddMarkerAction
   {
      /**
       * @param key action's key prefix in the LPEX plugin resource bundle
       */
      public LpexAddMarkerAction(String key,
                                 ITextEditor textEditor, String markerType, boolean askForLabel)
      {
         super(LpexPlugin.getResourceBundle(), key, textEditor, markerType, askForLabel);
      }

      /**
       * Return the attributes the new marker will be initialized with, based on
       * the current cursor position or text selection in the editor's
       * LpexSourceViewer.
       *
       * <p>If there is no text selection in this view, the cursor position will
       * be set in the marker, and the token or word at the cursor will be used
       * for the label proposal.
       * If a block has been selected, the selection will be used for the marker;
       * if the cursor is located at the start or end of this block, then it's
       * assumed the text has just been selected for the purpose of creating the
       * marker, and the selection text will be used as a preliminary proposal
       * for the marker label.</p>
       */
      protected Map getInitialAttributes()
      {
         Map attributes = new HashMap(11);

         LpexView lpexView = ((LpexAbstractTextEditor)getTextEditor()).getLpexView();
         if (lpexView == null)
            return attributes;
         // get cursor location inside the currently-loaded LPEX document section
         LpexDocumentLocation loc = lpexView.documentLocation();
         if (loc.element == 0)         // no visible elements...
            return attributes;

         /*--------------------------------------*/
         /*  set label proposal and line number  */
         /*--------------------------------------*/
         int line;
         String label = null;
         int linesBeforeStart = lpexView.linesBeforeStart();

         // 1.- see if a selection seems to have been set for setting this marker
         if (lpexView.queryOn("block.inView") &&
                  (loc.position == lpexView.queryInt("block.bottomPosition") ||
                   loc.position == lpexView.queryInt("block.topPosition"))) {
            line = lpexView.lineOfElement(lpexView.queryInt("block.topElement") -
                                          linesBeforeStart);
            //label=getLabelProposal(lpexView.query("block.text"),1); get it as is, blanks and all
            label = lpexView.query("block.text");
            }

         else {
            // 2.- give parser a chance to determine the token at the cursor
            LpexParser parser = lpexView.parser();
            if (parser instanceof LpexCommonParser) {
               line = lpexView.lineOfElement(loc.element);
               label = getLabelProposal(((LpexCommonParser)parser).getToken(loc), 1);
               }

            // 3.- just use line's text at the cursor position
            else
               line = lpexView.lineOfElement(loc.element);
            }

         // set a proposal for the label text (token / text selected / at cursor)
         // (used e.g., to initialize the dialog displayed to name BOOKMARKs)
         if (label == null)
            label = getLabelProposal(lpexView.query("text"), loc.position);
         MarkerUtilities.setMessage(attributes, label);
         MarkerUtilities.setLineNumber(attributes, line);

         /*-----------------------------*/
         /*  set charStart and charEnd  */
         /*-----------------------------*/
         // we adjust here positions which are outside the current IDocument
         // text (in LPEX the cursor, character/element/rectangle block positions,
         // etc. can be located outside the actual line text)
         DocumentAdapter documentAdapter = fSourceViewer.getDocumentAdapter();
         int start, end;
         if (lpexView.queryOn("block.inView")) {
            loc.element =  lpexView.queryInt("block.topElement") - linesBeforeStart;
            loc.position = lpexView.queryInt("block.topPosition");
            start = documentAdapter.getDocOffset(loc);
            loc.element =  lpexView.queryInt("block.bottomElement") - linesBeforeStart;
            loc.position = lpexView.queryInt("block.bottomPosition");
            end = documentAdapter.getDocOffset(loc);
            }
         else { // no block, use cursor position
            start = documentAdapter.getDocOffset(loc);
            end = start;
            }

         MarkerUtilities.setCharStart(attributes, start);
         MarkerUtilities.setCharEnd(attributes, end);

         return attributes;
      }

      /**
       * This LpexAddMarkerAction method proposes the initial label for a marker
       * being created.  Called by getInitialAttributes().  A String delimited
       * by white space is extracted from the specified text.
       *
       * @param text  current token at cursor / text of the current line / the
       *              current selection
       * @param start ONE-based starting index for extracting the label proposal
       */
      String getLabelProposal(String text, int start)
      {
         if (text == null || text.length() == 0)
            return null;                // no text.

         int s = start - 1;
         if (s >= text.length())
             s = text.length() - 1;     // stay inside the text

         int e = s;
         while (s >= 0 && Character.isWhitespace(text.charAt(s)))
            s--;

         if (s < 0) {                   // no word at left, search right
            s = e;
            while (s < text.length() && Character.isWhitespace(text.charAt(s)))
               s++;
            if (s >= text.length())
               return null;             // no word anywhere in text.
            e = s;
            }
         else {
            e = s + 1;
            while (s >= 0 && !Character.isWhitespace(text.charAt(s)))
               s--;
            s++;
            }

         while (e < text.length() && !Character.isWhitespace(text.charAt(e)))
            e++;

         return text.substring(s, e);
      }
   }


   /*===========================================*/
   /*  View-scoped preference-pages management  */
   /*===========================================*/

   /**
    * Factory method to create a view preference page to be used by this
    * editor's source viewer.
    *
    * <p>Extend this method to create customized preference page(s) for the
    * view-scoped preference node(s).  The default implementation returns
    * <code>null</code>, letting the source viewer create its own default view
    * preference pages.</p>
    *
    * @param nodeType preference node type
    *
    * @see LpexSourceViewer#VIEW_BASE_PREFERENCE_NODE
    * @see LpexSourceViewer#VIEW_PARSER_PREFERENCE_NODE
    * @see LpexSourceViewer#VIEW_SEQUENCE_NUMBERS_PREFERENCE_NODE
    * @see LpexSourceViewer#VIEW_SOURCE_ENCODING_PREFERENCE_NODE
    * @see LpexSourceViewer#createViewPreferencePage
    */
   protected IPreferencePage createViewPreferencePage(LpexView lpexView, int nodeType)
   {
      return null;
   }
}