//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexTextViewer - a line-oriented (LPEX-based) TextViewer
// (Eclipse R2.0).
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexDocumentLocation;
import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.core.LpexViewAdapter;
import com.ibm.lpex.core.LpexWindow;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;

import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.HelpEvent;
import org.eclipse.swt.events.HelpListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseMoveListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;

import org.eclipse.swt.custom.StyledText;

import org.eclipse.jface.text.AbstractHoverInformationControlManager;
import org.eclipse.jface.text.AbstractInformationControlManager;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.BadPositionCategoryException;
import org.eclipse.jface.text.DefaultPositionUpdater;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.DocumentCommand;
import org.eclipse.jface.text.DocumentEvent;
import org.eclipse.jface.text.IAutoIndentStrategy;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentAdapter;
import org.eclipse.jface.text.IDocumentListener;
import org.eclipse.jface.text.IEventConsumer;
import org.eclipse.jface.text.IFindReplaceTarget;
import org.eclipse.jface.text.IInformationControlCreator;
import org.eclipse.jface.text.IPositionUpdater;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextDoubleClickStrategy;
import org.eclipse.jface.text.ITextHover;
import org.eclipse.jface.text.ITextInputListener;
import org.eclipse.jface.text.ITextListener;
import org.eclipse.jface.text.ITextOperationTarget;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.IUndoManager;
import org.eclipse.jface.text.IViewportListener;
import org.eclipse.jface.text.IWidgetTokenOwner;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.TextEvent;
import org.eclipse.jface.text.TextPresentation;
import org.eclipse.jface.text.TextSelection;
import org.eclipse.jface.text.TypedRegion;

import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.Viewer;

import org.eclipse.core.resources.IStorage;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IStorageEditorInput;


//*as* jface.text.TextHoveringController is not public....................................
//*as* jface.text.DocumentAdapter is not public...........................................


/**
 * A line-oriented, LPEX-based <b>partial</b> implementation of
 * <code>org.eclipse.jface.text.ITextViewer</code>.
 *
 * Like TextViewer, once this viewer and its text widget have been created,
 * the viewer can only indirectly be disposed by disposing its primary SWT
 * control (the LpexWindow).  Clients should not subclass this class, as it
 * is likely that subclasses will be broken by future releases.
 *
 * <p>One major difference from TextViewer, this viewer's stream-oriented
 * IDocument is <b>not</b> kept up-to-date with the text changes in the
 * underlying LPEX text widget.  Always use LpexView to query / set the text
 * of the edited document.  For example:
 * <pre>
 *   IEditorPart editor = IWorkbenchPage.getActiveEditor();
 *   // (a) Using LPEX
 *   if (editor instanceof LpexTextEditor) {
 *      LpexTextEditor lpexEditor = (LpexTextEditor)editor;
 *      LpexView lpexView = lpexEditor.getLpexView();
 *      if (lpexView != null) {
 *         lpexView.doDefaultCommand("insertText " + text); // insert text at cursor
 *         LpexView.doGlobalCommand("screenShow");          // refresh display
 *         }
 *      }
 *   // (b) Using the Eclipse editor
 *   else {
 *      . . . // get DocumentProvider, get IDocument, do replace()
 *      } </pre>
 * The DocumentChanged() notification is interpreted as a total replacement of
 * the IDocument contents.
 *
 * <p>Several TextViewer classes, methods, and fields are not available in
 * LpexTextViewer.  Most programming of the underlying LPEX widget should be
 * done directly via its LpexView and LpexWindow.
 *
 * <p>TextViewer classes, methods, and fields which are not available, not
 * implemented, or whose function differs significantly in LpexTextViewer are
 * listed below, along with explanations and any LPEX alternatives.  While the
 * list is rather long, it should be noted that several (such as those geared
 * towards specific Eclipse solutions, like the shift-string operations, or
 * those specific to the underlying StyledText) are indicated for completness,
 * even if their visibility is package or private.
 * <ul>
 * <li>private StyledText fTextWidget,
 *     protected StyledText createTextWidget(),
 *     public StyledText getTextWidget() <br>
 *     -- an LPEX widget is used, rather than StyledText.  Method
 *     getTextWidget() returns <code>null</code>:  use getLpexWindow() and
 *     getLpexView() instead
 *
 * <li>protected IUndoManager fUndoManager,
 *     public void setUndoManager() <br>
 *     -- LPEX uses its own built-in undo manager (with unlimited undo/redo
 *     capabilitites), therefore it does not support <code>IUndoManager</code>
 *
 * <li>class FindReplaceTarget implements IFindReplaceTarget
 *      (including IFindReplaceTargetExtension),
 *     private class FindReplaceRange,
 *     public IFindReplaceTarget getFindReplaceTarget(),
 *     protected boolean canPerformFind(),
 *     protected int findAndSelect(),
 *     private int findAndSelectInRange(),
 *     private IFindReplaceTarget fFindReplaceTarget <br>
 *     -- LPEX does its own <b>findAndReplace</b> action, which is currently
 *     implemented as a live find and replace at the bottom of its window
 *
 * <li>protected Map fDoubleClickStrategies,
 *     private TextDoubleClickStrategyConnector fDoubleClickStrategyConnector,
 *     class TextDoubleClickStrategyConnector,
 *     public void setTextDoubleClickStrategy() <br>
 *     -- LPEX has its own double-click actions, therefore it doesn't support
 *     <code>ITextDoubleClickStrategy</code>.  Token/word selection and bracket
 *     matching can be customized via new LpexActions
 *
 * <li>protected boolean fIgnoreAutoIndent,
 *     protected Map fAutoIndentStrategies,
 *     public void setAutoIndentStrategy(),
 *     protected void customizeDocumentCommand()
 *     -- an LPEX language parser handles its own autoindent, therefore
 *     <code>IAutoIndentStrategy</code> is not supported
 *
 * <li>protected boolean isBlockSelected() <br>
 *     -- LPEX has various selection types and implements its own block
 *     operations.  See the <b>block</b> command and related references
 *
 * <li>protected void deleteText() <br>
 *     -- LPEX does its own deletions
 *
 * <li>class TextVerifyListener implements VerifyListener,
 *     private VerifyListener fVerifyListener,
 *     protected void handleVerifyEvent(),
 *     protected IEventConsumer fEventConsumer,
 *     public void setEventConsumer() <br>
 *     -- LPEX doesn't install a VerifyListener
 *
 * <li>public void setSelectedRange(...),
 *     public void setSelection(...),
 *     protected void internalRevealRange(),
 *     final protected int getWidthInPixels(),
 *     final protected int getAverageCharWidth() <br>
 *     -- not implemented, use LPEX commands and actions to set selections
 *
 * <li>public void setTextColor(Color),
 *     public void setTextColor(Color, int, int, boolean),
 *     public void changeTextPresentation(),
 *     private void addPresentation() <br>
 *     -- LPEX parsers set display attributes to text in the parsed document.
 *     Also, LPEX marks can be set with certain style, visibility, and protection
 *     attributes.  See the <b>mark</b> and related parameters
 *
 * <li>private ChildDocumentManager fChildDocumentManager,
 *     private ChildDocumentManager getChildDocumentManager() <br>
 *     -- an LPEX parser that manages mixed-content documents may use
 *     subparsers (including the available lexers) for the various document
 *     sections, under its direct control (instead of the management of
 *     IDocument children in the text viewer invoking the different parsers)
 *
 * <li>public void setDocument(document, visibleRegionOffset, visibleRegionLength),
 *     public IRegion getVisibleRegion(),
 *     public void setVisibleRegion(),
 *     public void resetVisibleRegion(),
 *     public boolean overlapsWithVisibleRegion(),
 *     protected IDocument getVisibleDocument(),
 *     protected int getVisibleRegionOffset(),
 *     protected IRegion internalGetVisibleRegion(),
 *     private IDocument fVisibleDocument <br>
 *     -- in LpexTextViewer, the visible document is always the viewer's (entire)
 *     input document.  To display only one or more certain region(s) of the
 *     document in the viewer, set marks for these regions, and set their
 *     included or excluded attribute.  See the <b>mark</b>, <b>markIncluded</b>,
 *     and <b>markExcluded</b> parameters
 *
 * <li>ITextOperationTarget.PREFIX,
 *     ITextOperationTarget.SHIFT_LEFT,
 *     ITextOperationTarget.SHIFT_RIGHT,
 *     ITextOperationTarget.STRIP_PREFIX,
 *     protected void shift(boolean useDefaultPrefixes, boolean right),
 *     protected void shift(boolean useDefaultPrefixes, boolean right, boolean ignoreWhitespace),
 *     private void shiftRight(...),
 *     private void shiftLeft(...),
 *     private IRegion getTextBlockFromSelection(...),
 *     protected Map fIndentChars,
 *     protected Map fDefaultPrefixChars,
 *     public void setDefaultPrefixes(...),
 *     public void setIndentPrefixes() <br>
 *     -- not currently supported
 *
 * <li>private WidgetCommand fWidgetCommand,
 *     protected class WidgetCommand,
 *     protected List fTextListeners,
 *     public void addTextListener(ITextListener listener),
 *     public void removeTextListener(ITextListener listener),
 *     protected void updateTextListeners(WidgetCommand cmd),
 *     public final void invalidateTextPresentation() <br>
 *     -- not currently supported
 *
 *     protected Map fTextHovers,
 *     protected IInformationControlCreator fHoverControlCreator,
 *     public void setTextHover(ITextHover hover, String contentType),
 *     protected ITextHover getTextHover(int offset) <br>
 *     -- not currently supported
 *
 * <li>static class ShiftPositionUpdater,
 *     protected static final String SHIFTING,
 *     private int getFirstCompleteLineOfRegion(),
 *     protected boolean isPrintable().
 * </ul>
 *
 * Other notable differences:
 * <ul>
 * <li>protected void setEditorInput() <br>
 *     -- use the setEditorInput() method prior to setDocument(), in order
 *     to specify the org.eclipse.core.resources.IFile input resource for
 *     this text viewer.
 * </ul>
 *
 * @see org.eclipse.jface.text.ITextViewer
 * @see #getLpexView
 * @see #getLpexWindow
 */
public class LpexTextViewer extends Viewer
                            implements ITextViewer, ITextOperationTarget, IWidgetTokenOwner
{
   /**
    * Use JFace's own resources for TextViewer-specific messages.
    * This is based on org.eclipse.jface.text.JFaceTextMessages.java.
    */
   private static final class JFaceTextMessages
   {
      private static ResourceBundle _bundle;
      public static String getString(String key)
      {
         try {
            if (_bundle == null)
               _bundle = ResourceBundle.getBundle("org.eclipse.jface.text.JFaceTextMessages");
            if (_bundle != null)
               return _bundle.getString(key);
            }
         catch (MissingResourceException e) {}
         return "!" + key + "!";
      }
   }


   public static boolean TRACE_ERRORS;


// /**
//  * We currently don't support TextListeners in LpexTextViewer...
//  *
//  * This class represents a replace command that brings the text viewer's text
//  * widget back in sync with text viewer's IDocument after the document has
//  * been changed.
//  */
// protected class WidgetCommand
// {
//    ...
// };


   /**
    * Monitors the area of the viewer's document that is visible in the viewer.
    * If the area might have been changed, it informs the text viewer about this
    * potential change and its origin.  The origin is internally used for
    * optimization purposes.
    */
   class ViewportGuard extends MouseAdapter
                       implements ControlListener,
                                  KeyListener,
                                  MouseMoveListener,
                                  SelectionListener
   {
      /*
       * @see org.eclipse.swt.events.ControlListener#controlResized(ControlEvent)
       */
      public void controlResized(ControlEvent e)
      {
         updateViewportListeners(RESIZE);
      }

      /*
       * @see org.eclipse.swt.events.ControlListener#controlMoved(ControlEvent)
       */
      public void controlMoved(ControlEvent e) {}

      /*
       * @see org.eclipse.swt.events.KeyListener#keyReleased
       */
      public void keyReleased(KeyEvent e)
      {
         updateViewportListeners(KEY);
      }

      /*
       * @see org.eclipse.swt.events.KeyListener#keyPressed
       */
      public void keyPressed(KeyEvent e)
      {
         updateViewportListeners(KEY);
      }

      /*
       * @see org.eclipse.swt.events.MouseListener#mouseUp
       */
      public void mouseUp(MouseEvent e)
      {
         if (_lpexWindow != null)
            _lpexWindow.textWindow().removeMouseMoveListener(this);
         updateViewportListeners(MOUSE_END);
      }

      /*
       * @see org.eclipse.swt.events.MouseListener#mouseDown
       */
      public void mouseDown(MouseEvent e)
      {
         if (_lpexWindow != null)
            _lpexWindow.textWindow().addMouseMoveListener(this);
      }

      /*
       * @see org.eclipse.swt.events.MouseMoveListener#mouseMove
       */
      public void mouseMove(MouseEvent e)
      {
         updateViewportListeners(MOUSE);
      }

      /*
       * @see org.eclipse.swt.events.SelectionListener#widgetSelected
       */
      public void widgetSelected(SelectionEvent e)
      {
         updateViewportListeners(SCROLLER);
      }

      /*
       * @see org.eclipse.swt.events.SelectionListener#widgetDefaultSelected
       */
      public void widgetDefaultSelected(SelectionEvent e) {}
   };


   /**
    * Internal document listener and hover reset timer.
    */
   class DocumentListener implements IDocumentListener, Runnable
   {
      private Object fSyncPoint = new Object();
      private Thread fThread;
      private boolean fIsReset;

      /*
       * @see IDocumentListener#documentAboutToBeChanged
       */
      public void documentAboutToBeChanged(DocumentEvent e) {
//       if (e.getDocument() == getVisibleDocument()) {
//          fWidgetCommand.setEvent(e);
//          if (fTextHoverManager != null && (fThread == null || !fThread.isAlive())) {
//             //fThread = new Thread(this, "hover reset timer");
//             fThread = new Thread(this, JFaceTextMessages.getString("TextViewer.timer.name"));
//             fThread.start();
//             }
//       }
      }

      /*
       * @see IDocumentListener#documentChanged
       */
      public void documentChanged(final DocumentEvent e) {
         // this is called when, for example, the text of a file opened in the editor
         // is replaced with a version from the local history [Navigator -> file right-
         // mouse click -> Replace with -> Local history ==> org\eclipse\compare\internal\
         // ReplaceWithEditionAction.java -> IFile file.setContents()]: TextViewer's
         // documentAboutToBeChanged() above creates a WidgetCommand with the change, and
         // here it sends it to all text listeners -> the listening Eclipse text widget
         // (StyledText) will consequently replace its contents with the new version of
         // the file from the local history...

         // System.out.println(" TextViewer#documentChanged() e.offset="+e.getOffset()+", e.length="+e.getLength());
         // LPEX: assume a total document-text change (as is the case for local-history
         // replacement detailed above)...
         updateWidgetContents();

//       if (fWidgetCommand.event == e) {
//          updateTextListeners(fWidgetCommand);
//
//          if (fTextHoverManager != null) {
//             synchronized (fSyncPoint) {
//                fIsReset= true;
//                }
//             fTextHoverManager.setEnabled(false);
//             }
//       }
      }

      /*
       * @see IRunnable#run
       */
      public void run() {
//       try {
//          while (true) {
//
//             synchronized (fSyncPoint) {
//                fSyncPoint.wait(1500);
//                if (fIsReset) {
//                   fIsReset= false;
//                   continue;
//                }
//             }
//
//             break;
//          }
//       } catch (InterruptedException e) {}
//
//       fThread= null;
//
//       if (fTextHoverManager != null) {
//          Control c= getControl();
//          if (c != null && !c.isDisposed()) {
//             Display d= c.getDisplay();
//             if (d != null) {
//                d.asyncExec(new Runnable() {
//                   public void run() {
//                      if (fTextHoverManager != null)
//                         fTextHoverManager.setEnabled(true);
//                   }
//                });
//             }
//          }
//       }
      }

      /**
       * Stops the running hover timer thread.
       */
      public void stop() {
//       if (fThread != null) {
//          if (fThread.isAlive())
//             fThread.interrupt();
//          fThread= null;
//       }
      }
   };

// /**
//  * Internal verify listener.
//  */
// class TextVerifyListener implements VerifyListener {
//
//    private boolean fForward= true;
//
//    /**
//     * Tells the listener to forward received events.
//     */
//    public void forward(boolean forward) {
//       fForward= forward;
//    }
//
//    /*
//     * A notification from the VerifyListener we installed on the text widget.
//     * If we have an event consumer set (see setEventConsumer()), send the
//     * event to it first, and process it only if we get its go-ahead.
//     *
//     * @see VerifyListener#verifyText(VerifyEvent)
//     */
//    public void verifyText(VerifyEvent e) {
//       if (fForward)
//          handleVerifyEvent(e);
//    }
// };


   /** Id for originator of view port changes. */
   protected static final int
    SCROLLER  = 1,
    MOUSE     = 2,
    MOUSE_END = 3,
    KEY       = 4,
    RESIZE    = 5,
    INTERNAL  = 6;

   /** The viewer's input stream-oriented IDocument.  It is not maintained by LpexTextViewer. */
   private IDocument fDocument;
   /** The viewer's visible IDocument;  in LPEX, it's always fDocument. */
   private IDocument fVisibleDocument;

   /** The viewer's document adapter. */
   private IDocumentAdapter fDocumentAdapter;
   /** The text viewer's hovering controller. */
   private AbstractHoverInformationControlManager fTextHoverManager;

   /** The LpexTextViewer's viewport guard. */
   private ViewportGuard fViewportGuard;
   /** Caches the graphical coordinate of the top of the text-widget screen. */
   private int fTopInset = 0;
   /** The most recent document modification as widget command. */
// private WidgetCommand fWidgetCommand = new WidgetCommand();
   /** The underlying widget's scroll bars. */
   private ScrollBar fScroller;

   /** Document listener. */
   private DocumentListener fDocumentListener = new DocumentListener();
   /** Verify listener. */
// private TextVerifyListener fVerifyListener = new TextVerifyListener();

   /** The most recent widget modification as a document command. */
//*as* jface.text.DocumentCommand doesn't have a public constructor like this.....................
   private DocumentCommand fDocumentCommand; // = new DocumentCommand();

   /** The viewer widget token keeper. */
   private Object fWidgetTokenKeeper;

   /** The strings a line is prefixed with on SHIFT_RIGHT, and removed from each line on SHIFT_LEFT. */
// protected Map fIndentChars;
   /** The string a line is prefixed with on PREFIX and removed from each line on STRIP_PREFIX. */
// protected Map fDefaultPrefixChars;

   /** The text viewer's text hovers. */
// protected Map fTextHovers;
   /** The creator of the text hover control */
// protected IInformationControlCreator fHoverControlCreator;

   /** All registered viewport listeners. */
   protected List fViewportListeners;

   /** The last visible vertical position of the top line. */
   protected int fLastTopPixel;
   /** All registered text listeners. */
// protected List fTextListeners;
   /** All registered text input listeners. */
   protected List fTextInputListeners;
   /** The text viewer's event consumer. */
// protected IEventConsumer fEventConsumer;
   /** Indicates whether the viewer's text presentation should be replaced are modified. */
   protected boolean fReplaceTextPresentation;

   // the viewer's text widget is LPEX
   //private StyledText fTextWidget;
   // LPEX text widget's document view
   private LpexView _lpexView;
   // LPEX text widget's window
   private LpexWindow _lpexWindow;
   // using plugin's class loader
   ClassLoader _classLoader;
   // best-guess eol for the document handled by this viewer
   private String _eol;

   // The input underlying this text viewer.
   //
   // Eclipse:   IEditorInput
   //                 ^
   //                 |
   //         IStorageEditorInput  // wraps an IStorage object
   //                 ^
   //                 |
   //          IFileEditorInput    // wraps a file-resource IFile object
   //
   //
   //             IResource
   //               ^
   //               |
   //               |IStorage
   //               |  ^
   //               |  |
   //              IFile
   //
   private IEditorInput _editorInput;
   // explicit read-only request via setEditable()
   private String _readonly;


   //---- Construction and disposal ------------------

   /**
    * Internal-use constructor.
    * This constructor is the one called by the extending class LpexSourceViewer;
    * afterwards, methods createControl(), setEditorInput(), and setDocument()
    * will be called.
    */
   protected LpexTextViewer() {}

   /**
    * Create an LpexTextViewer with the given SWT style bits.
    * The viewer's text widget (consisting of an LpexView and an LpexWindow)
    * is created.
    *
    * @param parent the parent of the viewer's control
    * @param styles the SWT style bits for the viewer's control
    * @see #createControl
    */
   public LpexTextViewer(Composite parent, int styles)
   {
      createControl(parent, styles);
   }

   /**
    * Factory method to create the document adapter to be used by this viewer.
    *
    * <p>IDocumentAdapter adapts an IDocument to the StyledTextContent interface.
    * The document adapter is used by TextViewer to translate IDocument changes
    * into its styled text content changes and vice versa.  Clients may
    * implement this interface and override this method if they want to
    * intercept the communication between the viewer's text widget and
    * the viewer's document.
    *
    * @return the document adapter to be used
    */
   protected IDocumentAdapter createDocumentAdapter() {
      return null; //*as* return new DocumentAdapter();
//*as* implement an LpexDocumentAdapter to solve various headaches?!?!? ..................
   }

   /**
    * Creates the viewer's SWT control.  The viewer's text widget is either
    * the control, or is a child of the control.  The contents of the text
    * widget will be set later, on setDocument().
    *
    * <p>Here are the steps carried out by this method:
    * <ul>
    *   <li>a new LpexView is constructed
    *   <li>a new LpexWindow is created and associated with the LpexView
    *   <li>listeners are added to the new text widget
    *   <li>initializeLpexView() is called to allow the user to set their own
    *       parameters for this view.
    * </ul>
    *
    * <p>The user must add their own LPEX actions and commands by extending
    * updateProfile(), which is called when we are notified of the completion
    * of the <b>updateProfile</b> command.
    *
    * @param parent the parent of the viewer's control
    * @param styles the SWT style bits for the viewer's control
    *
    * @see #initializeLpexView
    * @see #updateProfile
    */
   protected void createControl(Composite parent, int styles)
   {
      // create an LpexView
      _lpexView = new LpexView(false); // false = we'll do updateProfile later

      // create & set a window for our LpexView
      _lpexWindow = new LpexWindow(parent, styles);
      _lpexView.setWindow(_lpexWindow);

      _lpexWindow.addDisposeListener(
         new DisposeListener() {
            public void widgetDisposed(DisposeEvent e) {
               setDocument(null);
               handleDispose();
               }
            });

      // keep LPEX's install/default font...
      //_lpexView.setFont(parent.getFont());

      // top of the text-widget screen area
      fTopInset= -_lpexWindow.computeTrim(0, 0, 0, 0).y;

//    fVerifyListener.forward(true);
//    fTextWidget.addVerifyListener(fVerifyListener);

//    fTextWidget.addSelectionListener(new SelectionListener() {
//       public void widgetDefaultSelected(SelectionEvent event) {
//          selectionChanged(event.x, event.y - event.x);
//          }
//       public void widgetSelected(SelectionEvent event) {
//          selectionChanged(event.x, event.y - event.x);
//          }
//       });

      initializeViewportUpdate();

      // add an LpexViewListener, which handles all the listening needed here
      _lpexView.addLpexViewListener(
         new LpexViewAdapter() {
            //public void showing(LpexView lpexView) {}
            //public void shown(LpexView lpexView) {}
            //public boolean saving(LpexView lpexView) { return false; }
            //public void saved(LpexView lpexView) {}
            //public boolean renaming(LpexView lpexView) { return false; }
            //public void renamed(LpexView lpexView) {}
            //public void readonly(LpexView lpexView) {}

            // called after the updateProfile command was performed
            public void updateProfile(LpexView lpexView) {
               LpexTextViewer.this.updateProfile();
               }
            // called when the LpexView is disposed
            public void disposed(LpexView lpexView) {
               _lpexView = null;
               }
            });

      // initialize LpexView
      _lpexView.setClassLoader(_classLoader);
      initializeLpexView(_lpexView);

      // on setDocument(), we'll load the file into LPEX & do updateProfile
   }

   /**
    * Return the primary SWT Control (LpexWindow) associated with this viewer.
    * @see org.eclipse.jface.viewers.Viewer#getControl
    */
   public Control getControl()
   {
      return _lpexWindow;
   }

   /**
    * Activate the installed TextViewer 'plugins' (hover, etc.).  If the plugins
    * are already activated, this call is without effect.
    *
    * <p>Defined by ITextViewer, as part of its plugins support.
    * @see org.eclipse.jface.text.ITextViewer#activatePlugins
    */
   public void activatePlugins()
   {
//    if (fTextHovers != null && !fTextHovers.isEmpty() && fHoverControlCreator != null && fTextHoverManager == null) {
//       fTextHoverManager= new TextViewerHoverManager(this, fHoverControlCreator);
//       fTextHoverManager.install(this.getTextWidget());
//       }
   }

   /**
    * Resets the installed plug-ins.  If plug-ins change their state or behavior
    * over the course of time, this method causes them to be set back to their
    * initial state and behavior.
    * @see org.eclipse.jface.text.ITextViewer#resetPlugins
    */
   public void resetPlugins()
   {
      //if (fUndoManager != null)
      // fUndoManager.reset();
   }

   /**
    * Frees all resources allocated by this viewer.
    * Internally called when the viewer's control has been disposed.
    */
   protected void handleDispose()
   {
      removeViewPortUpdate();
      fViewportGuard = null;

      if (fViewportListeners != null) {
         fViewportListeners.clear();
         fViewportListeners = null;
         }

//    if (fTextListeners != null) {
//       fTextListeners.clear();
//       fTextListeners = null;
//       }

//    if (fTextHovers != null) {
//       fTextHovers.clear();
//       fTextHovers = null;
//       }

//    if (fTextHoverManager != null) {
//       fTextHoverManager.dispose();
//       fTextHoverManager = null;
//       }

      if (fDocumentListener != null) {
         fDocumentListener.stop();
         fDocumentListener = null;
         }

      if (fDocumentAdapter != null) {
         fDocumentAdapter.setDocument(null);
         fDocumentAdapter = null;
         }

      fDocument = null;
      fScroller = null;

      _lpexView.dispose();
      _lpexWindow = null;
   }

   //---- simple getters and setters

   /**
    * This method returns <code>null</code>.  In TextViewer, this method returns
    * the StyledText control, its underlying text widget.
    *
    * <p>Note:  Do not use this method in LpexTextViewer.  LpexTextViewer uses
    * an LPEX text widget, which consists of an LpexWindow (an SWT Composite)
    * and an LpexView, rather than a StyledText widget.
    *
    * @see org.eclipse.jface.text.ITextViewer#getTextWidget
    * @see #getLpexWindow
    * @see #getLpexView
    */
   public StyledText getTextWidget()
   {
      return /*fTextWidget*/ null;
   }

   /**
    * This method does nothing.
    *
    * <p>In TextViewer, this method registers an IAutoIndentStrategy for the
    * given content type.  LPEX language parsers handle their own autoindent.
    *
    * <p>Defined by ITextViewer, as part of its plugins support.
    * @see org.eclipse.jface.text.ITextViewer#setAutoIndentStrategy
    */
   public void setAutoIndentStrategy(IAutoIndentStrategy strategy, String contentType) {}

   /**
    * This method does nothing.
    *
    * <p>In TextViewer, implementers can register and receive VerifyEvents
    * before the text viewer touches them.  If the IEventConsumer marks
    * an event as processed, the text viewer will ignore it.
    * For example, keys consumed by a content-assist popup should not be
    * again processed by us (this is not quite AWT's e.consume(), but that's
    * the way Eclipse operates).
    *
    * @see org.eclipse.jface.text.ITextViewer#setEventConsumer
    */
   public void setEventConsumer(IEventConsumer consumer)
   {
//    fEventConsumer = consumer;
   }

   /**
    * This method does nothing.
    * LPEX does not currently support the Eclipse shift operations.
    *
    * <p>In TextViewer, this method sets the strings that are used as prefixes
    * when lines of the given content type are shifted using the shift operations.
    * Defined by ITextViewer, as part of its plugins support.
    * @see org.eclipse.jface.text.ITextViewer#setIndentPrefixes
    */
   public void setIndentPrefixes(String[] indentPrefixes, String contentType) {}

   /**
    * Return the top, in pixels, of the text-widget screen.
    *
    * @see org.eclipse.jface.text.ITextViewer#getTopInset
    */
   public int getTopInset()
   {
      return fTopInset;
   }

   /**
    * Query whether the shown text can be manipulated.
    * Preferred method:  use the LPEX <b>readonly</b> parameter.
    *
    * @see org.eclipse.jface.text.ITextViewer#isEditable
    */
   public boolean isEditable()
   {
      return _lpexView != null && !_lpexView.queryOn("readonly");
   }

   /**
    * Set the editable mode.
    * This method is called when an IFile input's desired editable mode is
    * different from the file's read/write attribute, or when the input is
    * IStorage.
    *
    * @see org.eclipse.jface.text.ITextViewer#setEditable
    * @see #isEditable
    */
   public void setEditable(boolean editable)
   {
      _readonly = (editable == true)? "off" : "on";
      if (_lpexView != null)
         _lpexView.doCommand("set readonly " + _readonly);
   }

   /**
    * This method does nothing in LpexTextViewer.
    * LPEX does not currently support the prefix and strip-prefix operations.
    *
    * <p>Defined by ITextViewer, as part of its plugins support.
    * @see org.eclipse.jface.text.ITextViewer#setDefaultPrefixes
    */
   public void setDefaultPrefixes(String[] defaultPrefixes, String contentType) {}

   /**
    * This method does nothing in LpexTextViewer.
    * LPEX uses its own built-in undo manager (with unlimited undo/redo
    * capabilitites), therefore it does not support <code>IUndoManager</code>.
    *
    * <p>Defined by ITextViewer, as part of its plugins support.
    * @see org.eclipse.jface.text.ITextViewer#setUndoManager
    */
   public void setUndoManager(IUndoManager undoManager) {}

   /**
    * This method does nothing.
    * Defined by ITextViewer, as part of its plugins support.
    * @see org.eclipse.jface.text.ITextViewer#setTextHover
    */
   public void setTextHover(ITextHover hover, String contentType)
   {
//    if (hover != null) {
//       if (fTextHovers == null)
//          fTextHovers = new HashMap();
//       fTextHovers.put(contentType, hover);
//       }
//    else if (fTextHovers != null)
//       fTextHovers.remove(contentType);
   }

   /**
    * This method returns null.
    * In TextViewer, this method returns the text hover for a given offset.
    *
    * @param offset the offset for which to return the text hover
    * @return the text hover for the given offset
    */
   protected ITextHover getTextHover(int offset) {
//    return (ITextHover)selectContentTypePlugin(offset, fTextHovers);
      return null;
   }

   /**
    * Returns the text hovering controller of this viewer.
    *
    * @return the text hovering controller of this viewer
    */
   protected AbstractInformationControlManager getTextHoveringController() {
      return fTextHoverManager;
   }

   /**
    * Sets the creator for the hover controls.
    *
    * @param creator the hover control creator
    */
   public void setHoverControlCreator(IInformationControlCreator creator) {
//   fHoverControlCreator = creator;
   }

   /*
    * @see IWidgetTokenOwner#requestWidgetToken(Object)
    */
   public synchronized boolean requestWidgetToken(Object tokenRequester) {
      return true;
//    if (fTextWidget != null) {// commented out in original (Eclipse build 20020214)
//       if (fWidgetTokenKeeper == null) {
//          fWidgetTokenKeeper= tokenRequester;
//          return true;
//       }
//       return (fWidgetTokenKeeper == tokenRequester);
//    }
//    return false;
   }

   /*
    * @see IWidgetTokenOwner#releaseWidgetToken(Object)
    */
   public synchronized void releaseWidgetToken(Object tokenKeeper) {
      if (fWidgetTokenKeeper == tokenKeeper)
         fWidgetTokenKeeper= null;
   }


   //---- Selection

   /**
    * Return the range of the current selection in coordinates of this viewer's
    * document.
    *
    * Returns the start and length of the selection:  x is the offset of the
    * first selected character relative to the first character of the widget
    * content, y is the length of the selection.
    *
    * <p>In LPEX, this stream-oriented method is inefficient, and should be
    * avoided.
    *
    * @see org.eclipse.jface.text.ITextViewer#getSelectedRange
    */
   public Point getSelectedRange()
   {
      //TextViewer:
      //if (fTextWidget != null) {
      // Point p = fTextWidget.getSelectionRange();
      // int offset = getVisibleRegionOffset();
      // return new Point(p.x + offset, p.y);
      // }

      if (_lpexView != null) {
         int start, end;
         int eolLength = getEOL().length();
         LpexDocumentLocation loc = _lpexView.documentLocation();
         if (_lpexView.queryOn("block.inView")) {
            int linesBeforeStart = _lpexView.linesBeforeStart();
            loc.element =  _lpexView.queryInt("block.topElement") - linesBeforeStart;
            loc.position = _lpexView.queryInt("block.topPosition");
            start = _lpexView.charOffset(loc, eolLength);
            loc.element =  _lpexView.queryInt("block.bottomElement") - linesBeforeStart;
            loc.position = _lpexView.queryInt("block.bottomPosition");
            end = _lpexView.charOffset(loc, eolLength);
            }
         else { // no block, use cursor position
            start = _lpexView.charOffset(loc, eolLength);
            end = start;
            }

         return new Point(start, end - start);
         }

      return new Point(-1, -1);
   }

   /**
    * This method is not currently implemented.
    * In TextViewer, this method sets the selection to the specified range.
    *
    * <p>To set selections in LPEX, use the <b>block</b> command or
    * <b>blockMark___</b> actions.  To reposition the cursor, use the
    * <b>locate</b> command and the <b>position</b> parameter.</p>
    *
    * @see org.eclipse.jface.text.ITextViewer#setSelectedRange
    */
   public void setSelectedRange(int offset, int len) {}

   /**
    * This method is not currently implemented.
    * In TextViewer, this method sets a new selection for this viewer, and
    * optionally makes it visible.
    *
    * <p>To set selections in LPEX, use the <b>block</b> command or
    * <b>blockMark___</b> actions.  To reposition the cursor, use the
    * <b>locate</b> command and the <b>position</b> parameter.</p>
    *
    * @see org.eclipse.jface.viewers.Viewer#setSelection(ISelection)
    */
   public void setSelection(ISelection selection, boolean reveal) {}

   /**
    * Return the current selection.
    *
    * <p>In LPEX, this stream-oriented method is inefficient, and should be
    * avoided.
    *
    * @see org.eclipse.jface.viewers.Viewer#getSelection
    */
   public ISelection getSelection()
   {
      Point p = getSelectedRange();
      if (p.x == -1 || p.y == -1)
         return LpexTextSelection.emptySelection();

      return new LpexTextSelection(_lpexView, getDocument(), p.x, p.y);
   }

   /**
    * @see org.eclipse.jface.text.ITextViewer#getSelectionProvider
    */
   public ISelectionProvider getSelectionProvider()
   {
      return this;
   }

   /**
    * Sends out a selection-changed event to all registered listeners.
    *
    * @param offset the offset of the newly selected range in the visible document
    * @param len the length of the newly selected range in the visible document
    */
   protected void selectionChanged(int offset, int len)
   {
      ISelection selection = new LpexTextSelection(_lpexView, getDocument(),
                                                   getVisibleRegionOffset() + offset, len);
      SelectionChangedEvent event = new SelectionChangedEvent(this, selection);
      fireSelectionChanged(event);
   }

   //---- Text listeners

   /**
    * The implementation of this method does nothing.
    *
    * <p>In TextViewer, this method adds a text listener to the text widget.
    * A listener is registered only once, subsequent calls are without effect.
    *
    * @see org.eclipse.jface.text.ITextViewer#addTextListener
    */
   public void addTextListener(ITextListener listener)
   {
//    if (fTextListeners == null)
//       fTextListeners = new ArrayList();
//
//    if (!fTextListeners.contains(listener))
//       fTextListeners.add(listener);
   }

   /**
    * The implementation of this method does nothing.
    *
    * <p>In TextViewer, this method removes the text listener from the text
    * widget.  If the listener is not registered with the widget, the call is
    * without effect.
    *
    * @see org.eclipse.jface.text.ITextViewer#removeTextListener
    */
   public void removeTextListener(ITextListener listener)
   {
//    if (fTextListeners != null) {
//       fTextListeners.remove(listener);
//       if (fTextListeners.size() == 0)
//          fTextListeners = null;
//       }
   }

// /**
//  * This method informs all registered text listeners about the change
//  * specified by the widget command.  Text listeners are notified via
//  * textChanged(TextEvent).
//  *
//  * @param cmd the widget command translated into a text event and sent to all
//  *        text listeners
//  */
// protected void updateTextListeners(WidgetCommand cmd)
// {
//    if (fTextListeners != null) {
//       DocumentEvent event = cmd.event;
//       TextEvent e = new TextEvent(cmd.start, cmd.length, cmd.text, cmd.preservedText, event);
//       for (int i = 0; i < fTextListeners.size(); i++) {
//          ITextListener l = (ITextListener)fTextListeners.get(i);
//          l.textChanged(e);
//          }
//       }
// }

   //---- Text input listeners

   /**
    * Add a text input listener to the <code>ITextViewer</code>.  A listener is
    * registered only once, subsequent calls are without effect.
    *
    * <p>Text input listeners registered with a text viewer are informed when the
    * document serving as the text viewer's model is replaced.
    *
    * @see org.eclipse.jface.text.ITextViewer#addTextInputListener
    */
   public void addTextInputListener(ITextInputListener listener)
   {
      if (fTextInputListeners == null)
         fTextInputListeners = new ArrayList();

      if (!fTextInputListeners.contains(listener))
         fTextInputListeners.add(listener);
   }

   /**
    * Remove the text input listener from the <code>ITextViewer</code>.  If the
    * listener is not registered with the viewer, the call is without effect.
    *
    * @see org.eclipse.jface.text.ITextViewer#removeTextInputListener
    */
   public void removeTextInputListener(ITextInputListener listener)
   {
      if (fTextInputListeners != null) {
         fTextInputListeners.remove(listener);
         if (fTextInputListeners.size() == 0)
            fTextInputListeners = null;
         }
   }

   /**
    * Informs all registered text input listeners about the forthcoming input change.
    *
    * @param oldInput the old input document
    * @param newInput the new input document
    */
   protected void fireInputDocumentAboutToBeChanged(IDocument oldInput, IDocument newInput)
   {
      if (fTextInputListeners != null) {
         for (int i = 0; i < fTextInputListeners.size(); i++) {
            ITextInputListener l = (ITextInputListener)fTextInputListeners.get(i);
            l.inputDocumentAboutToBeChanged(oldInput, newInput);
            }
         }
   }

   /**
    * Informs all registered text input listeners about the sucessful input change.
    *
    * @param oldInput the old input document
    * @param newInput the new input document
    */
   protected void fireInputDocumentChanged(IDocument oldInput, IDocument newInput)
   {
      if (fTextInputListeners != null) {
         for (int i = 0; i < fTextInputListeners.size(); i++) {
            ITextInputListener l = (ITextInputListener)fTextInputListeners.get(i);
            l.inputDocumentChanged(oldInput, newInput);
            }
         }
   }

   //---- Document

   /**
    * Return the input (IDocument) of this viewer.
    * Note that LPEX does not maintain this IDocument in sync with the contents
    * of its text widget during the edit session.
    * @see org.eclipse.jface.viewers.Viewer#getInput
    */
   public Object getInput()
   {
      return getDocument();
   }

   /**
    * Return this text viewer's stream-oriented IDocument.
    * Note that LPEX does not maintain this IDocument in sync with the contents
    * of its text widget during the edit session.
    *
    * <p>Defined by ITextViewer, as part of its model-manipulation support.
    * @see org.eclipse.jface.text.ITextViewer#getDocument
    */
   public IDocument getDocument()
   {
      return fDocument;
   }

   /**
    * Set or clear the input (IDocument) for this viewer.
    * @see org.eclipse.jface.viewers.Viewer#setInput
    */
   public void setInput(Object input)
   {
      IDocument document = null;
      if (input instanceof IDocument)
         document = (IDocument)input;

      setDocument(document);
   }

   /**
    * Set the given IDocument as the text viewer's model, and update the
    * presentation accordingly.  An approriate TextEvent is issued.
    * The text event does not carry a related document event, though.
    *
    * <p>Defined by ITextViewer, as part of its model-manipulation support.
    * @see org.eclipse.jface.text.ITextViewer#setDocument(IDocument)
    */
   public void setDocument(IDocument document)
   {
      fReplaceTextPresentation = true;
      fireInputDocumentAboutToBeChanged(fDocument, document);

      IDocument oldDocument = fDocument;
      fDocument = document;
      if (fDocument != null)
         _eol = null; // may need to recalculate!?

      setVisibleDocument(fDocument);

      inputChanged(fDocument, oldDocument);

      fireInputDocumentChanged(oldDocument, fDocument);
      fReplaceTextPresentation= false;
   }

   /**
    * The implementation of this method calls setDocument(document).
    * In LpexTextViewer, the visible document (or currently-loaded document
    * section) is always the viewer's (entire) input document.  To display only
    * certain region(s) of the document in the viewer, set marks for these
    * regions, and set their included or excluded attributes.  See the
    * <b>mark</b>, <b>markIncluded</b>, and <b>markExcluded</b> parameters.
    *
    * <p>In TextViewer, this is a convenience method for
    * <pre>
    *   setDocument(document);
    *   setVisibleRegion(offset, length) </pre>
    * It is defined by ITextViewer as part of its visible-region support.
    *
    * @see org.eclipse.jface.text.ITextViewer#setDocument(IDocument,int,int)
    * @see #setDocument(IDocument)
    */
   public void setDocument(IDocument document, int visibleRegionOffset, int visibleRegionLength)
   {
      setDocument(document);
   }

   //---- Viewports

   /**
    * Initializes all listeners and structures required to set up viewport
    * listeners.
    */
   private void initializeViewportUpdate()
   {
      if (fViewportGuard != null)
         return;

//    if (fTextWidget != null) {
//       fViewportGuard= new ViewportGuard();
//       fLastTopPixel= -1;
//
//       fTextWidget.addKeyListener(fViewportGuard);
//       fTextWidget.addMouseListener(fViewportGuard);
//
//       fScroller= fTextWidget.getVerticalBar();
//       if (fScroller != null)
//          fScroller.addSelectionListener(fViewportGuard);
//       }
   }

   /**
    * Removes all listeners and structures required to set up viewport listeners.
    */
   private void removeViewPortUpdate()
   {
//    if (fTextWidget != null) {
//       fTextWidget.removeKeyListener(fViewportGuard);
//       fTextWidget.removeMouseListener(fViewportGuard);
//
//       if (fScroller != null && !fScroller.isDisposed()) {
//          fScroller.removeSelectionListener(fViewportGuard);
//          fScroller= null;
//          }
//
//       fViewportGuard = null;
//       }
   }

   /**
    * @see org.eclipse.jface.text.ITextViewer#addViewportListener
    */
   public void addViewportListener(IViewportListener listener)
   {
      if (fViewportListeners == null) {
         fViewportListeners = new ArrayList();
         initializeViewportUpdate();
         }

      if (!fViewportListeners.contains(listener))
         fViewportListeners.add(listener);
   }

   /**
    * @see org.eclipse.jface.text.ITextViewer#removeViewportListener
    */
   public void removeViewportListener(IViewportListener listener)
   {
      if (fViewportListeners != null)
         fViewportListeners.remove(listener);
   }

   /**
    * Checks whether the viewport changed and if so informs all registered
    * listeners about the change.
    *
    * @param origin describes under which circumstances this method has been called.
    *
    * @see IViewportListener
    */
   protected void updateViewportListeners(int origin)
   {
//    int topPixel = fTextWidget.getTopPixel();
//    if (topPixel >= 0 && topPixel != fLastTopPixel) {
//       if (fViewportListeners != null) {
//          for (int i= 0; i < fViewportListeners.size(); i++) {
//             IViewportListener l= (IViewportListener)fViewportListeners.get(i);
//             l.viewportChanged(topPixel);
//             }
//          }
//       fLastTopPixel = topPixel;
//       }
   }

   //---- scrolling and revealing

   /**
    * Return the ZERO-based index of the visible document-section line with
    * the smallest line number.
    *
    * @see org.eclipse.jface.text.ITextViewer#getTopIndex
    */
   public int getTopIndex()
   {
      if (_lpexView != null) {
         int element = _lpexView.elementOfRow(1);
         if (element != 0)
            // this could still be just a show element for the document line
            // situated above the viewport (i.e., outside the visible edit area)
            return _lpexView.lineOfElement(element) - 1;
         }

      return -1;
   }

   /**
    * Return the character position which is at the upper-left corner of the
    * widget's viewport.
    *
    * @see org.eclipse.jface.text.ITextViewer#getTopIndexStartOffset
    */
   public int getTopIndexStartOffset()
   {
//    if (fTextWidget != null) {
//       int top = fTextWidget.getTopIndex();
//       try {
//          top= getVisibleDocument().getLineOffset(top);
//          return top + getVisibleRegionOffset();
//          }
//       catch (BadLocationException ex) {
//          if (TRACE_ERRORS) {
//             //System.out.println("LpexTextViewer.getTopIndexStartOffset: BadLocationException");
//             System.out.println(JFaceTextMessages.getString("TextViewer.error.bad_location.getTopIndexStartOffset"));
//             }
//          }
//       }

      return -1;
   }

   /**
    * Scrolls the edit window so that ZERO-based <code>index</code> is the
    * smallest document-section line number of all visible lines.
    *
    * <p>Preferred method:  in LPEX you may consider various options, depending
    * on the intended usage.
    * For example, to set the cursor in the edit window on a certain line in the
    * document:
    * <pre>
    *   LpexView lpexView = getLpexView();
    *   lpexView.doCommand("locate emphasis line " +
    *                      (index + 1 + lpexView.linesBeforeStart()));
    *   lpexView.triggerAction(lpexView.actionId("textWindow"));</pre>
    * To position the line that contains the cursor on a certain screen row:
    * <pre>
    *   LpexView lpexView = getLpexView();
    *   lpexView.doCommand("set cursorRow " + row);
    *   lpexView.doDefaultCommand("screenShow");</pre>
    *
    * <p>You must consider certain characteristics of the LPEX edit window,
    * such as:
    * <ul>
    *   <li>some or all elements (lines) in the document may be hidden
    *   <li>the current (cursor) element is always visible in the edit window
    *   <li>elements are laid out such that there is never any wasted space at
    *       the top of the edit area
    *   <li>there may be wasted space only at the bottom of the edit area, if
    *       there are not enough visible elements to fill it.
    * </ul>
    *
    * @see org.eclipse.jface.text.ITextViewer#setTopIndex
    */
   public void setTopIndex(int index)
   {
      if (_lpexView != null && index >= 0) {
         _lpexView.doCommand("locate line " + (index+1 +
                                               // bump up for document-section support
                                               _lpexView.linesBeforeStart()));
         _lpexView.triggerAction(LpexConstants.ACTION_SCROLL_TOP);
         updateViewportListeners(INTERNAL);
         }
   }

   /**
    * Return the number of rows displayable in the viewport.
    * The actual document lines displayed in the edit window may be fewer,
    * when the document is shorter or some lines are not visible.
    *
    * <p>Preferred method:  use getLpexView().queryInt("rows").
    *
    * @return the viewport height in lines
    */
   protected int getVisibleLinesInViewport()
   {
      return (_lpexView != null)? _lpexView.queryInt("rows") : -1;
   }

   /**
    * Return the ZERO-based index of the visible document-section line
    * with the highest line number.
    *
    * @see org.eclipse.jface.text.ITextViewer#getBottomIndex
    */
   public int getBottomIndex()
   {
      if (_lpexView != null) {
         int element = _lpexView.elementOfRow(_lpexView.queryInt("rows"));
         if (element != 0)
            return _lpexView.lineOfElement(element) - 1;

         // last screen row displays no element - if there are *any* visible elements
         // on the screen, then just return the last line in the document section
         if (_lpexView.elementOfRow(1) != 0)
            return _lpexView.queryInt("lines") -
                   (_lpexView.linesBeforeStart() + _lpexView.linesAfterEnd()) - 1;
         }

      return -1;
   }

   /**
    * Return the character position which is at the lower-right corner of the
    * widget's viewport, i.e., the visible character with the highest character
    * position.  If the content of the widget is shorter, the last character of
    * the content is returned.
    *
    * @see org.eclipse.jface.text.ITextViewer#getBottomIndexEndOffset
    */
   public int getBottomIndexEndOffset()
   {
      try {
         IRegion line= getDocument().getLineInformation(getBottomIndex());
         return line.getOffset() + line.getLength() - 1;
         }
      catch (BadLocationException ex) {
         if (TRACE_ERRORS) {
            //System.out.println("LpexTextViewer.getBottomIndexEndOffset: BadLocationException");
            System.out.println(JFaceTextMessages.getString("TextViewer.error.bad_location.getBottomIndexEndOffset"));
            }
         return getDocument().getLength() - 1;
         }
   }

   /**
    * This method is not currently implemented.
    * In TextViewer, this method ensures that the given character range is visible.
    * Note that in LPEX, the cursor is always visible.
    *
    * @see org.eclipse.jface.text.ITextViewer#revealRange
    */
   public void revealRange(int start, int end) {}

   /**
    * Refresh this viewer completely with information freshly obtained from
    * this viewer's model (its IDocument).
    * The implementation of this method does a setDocument(getDocument());
    *
    * @see org.eclipse.jface.viewers.Viewer#refresh
    * @see #setDocument(IDocument)
    */
   public void refresh()
   {
      setDocument(getDocument());
   }

   //---- visible range support

   /**
    * This method does nothing.
    * In TextViewer, this method invalidates the current presentation by
    * sending an initialization event to all the text listeners.
    */
   public final void invalidateTextPresentation() {
//    if (fVisibleDocument != null) {
//       fWidgetCommand.start= 0;
//       fWidgetCommand.length= 0;
//       // on large docs, this below is yet another killing overhead...
//       fWidgetCommand.text= fVisibleDocument.get();
//       fWidgetCommand.event= null;
//       updateTextListeners(fWidgetCommand);
//       }
   }

   /**
    * Initialize the text widget with the contents of the visual document.
    * In LpexTextViewer, the visible document (or currently-loaded document
    * section) is always the viewer's input document.
    *
    * <p>In TextViewer, this method initializes the StyledText widget with the
    * contents of the visual document, and invalidates the overall presentation
    * by sending an text-initialization event to all the text listeners.
    *
    * Called from setVisibleDocument().
    *
    * @see #updateWidgetContents
    */
   private void initializeWidgetContents()
   {
      // we have a text widget & setting doc (i.e., not null-ed upon viewer closing)
      if (_lpexView != null && fVisibleDocument != null) {
//       if (fDocumentAdapter == null)
//          fDocumentAdapter = createDocumentAdapter();
//       fDocumentAdapter.setDocument(fVisibleDocument);

         // TextViewer:
         //  fTextWidget.setContent(fDocumentAdapter);
         // LPEX:
         //  try to load directly from local file as the preferred method
         if (_editorInput != null)
            setFileName();

         // don't load directly any more: allow the (customized) document
         // provider to do its own load & save using e.g., specific character
         // encodings (such as read/save in UTF-8 for simple workstation-remote
         // host comms as desired by iSeries)
         //if (_editorInput instanceof IFileEditorInput)
         // _lpexView.doCommand("load");
         //else // IStorageEditorInput
         _lpexView.setText(fVisibleDocument.get());

         // call updateProfile command, display the document
         _lpexView.doDefaultCommand("updateProfile");
         // screenShow is not needed 1st time around, but *is* when e.g., file reloaded
         _lpexView.doDefaultCommand("screenShow");

         // TextViewer here sends out the appropriate widget change event -
         // a total invalidation (complete-text initialization):
         // invalidateTextPresentation();
         }
   }

   /**
    * Update the text widget with the contents of the visual document.
    */
   // See LpexSourceViewer#updateWidgetContents(), which prevents the removal of
   // Eclipse markers which correspond to the LPEX marks being removed in here
   // @see #initializeWidgetContents
   protected void updateWidgetContents()
   {
      if (_lpexView != null && fVisibleDocument != null) {
         _lpexView.setText(fVisibleDocument.get());
         _lpexView.doDefaultCommand("screenShow");
         }
   }

   /**
    * Sets this viewer's visible document.  The visible document represents
    * the visible region of the viewer's input document.
    * In LPEX, the visible document (or currently-loaded document section) is
    * always the viewer's entire input document.
    *
    * @param document the visible document
    */
   private void setVisibleDocument(IDocument document)
   {
      if (fVisibleDocument != null)
         fVisibleDocument.removeDocumentListener(fDocumentListener);

      fVisibleDocument = document;

      initializeWidgetContents();
      resetPlugins();

      if (fVisibleDocument != null)
         fVisibleDocument.addDocumentListener(fDocumentListener);
   }

   /**
    * Stop / restart listening to input-document changes.
    */
   protected void listenToDocumentChanges(boolean listen)
   {
      if (fVisibleDocument != null) {
         if (listen)
            fVisibleDocument.addDocumentListener(fDocumentListener);
         else
            fVisibleDocument.removeDocumentListener(fDocumentListener);
         }
   }

   /**
    * Returns the viewer's visible document.  The visible document represents
    * the visible region of the viewer's input document.
    * In LPEX, the visible document (or currently-loaded document section) is
    * always the viewer's entire input document.
    *
    * @return the viewer's visible document
    */
   public /*protected -as- but DEBUGGER wants access */ IDocument getVisibleDocument()
   {
      return fVisibleDocument;
   }

   /**
    * This method always returns 0.
    * In LpexTextViewer, the visible document (or document section) is always
    * the viewer's (entire) input document.  To display only certain region(s)
    * of the document in the viewer, set marks for these regions, and set their
    * included or excluded attributes.  See the <b>mark</b>, <b>markIncluded</b>,
    * and <b>markExcluded</b> parameters.
    *
    * <p>In TextViewer, this method returns the offset of the visible region.
    */
   protected int getVisibleRegionOffset()
   {
      return 0;
   }

   /**
    * This method always returns a 0,0 region.
    * In LpexTextViewer, the visible document (or document section) is always
    * the viewer's (entire) input document.  To display only certain region(s)
    * of the document in the viewer, set marks for these regions, and set their
    * included or excluded attributes.  See the <b>mark</b>, <b>markIncluded</b>,
    * and <b>markExcluded</b> parameters.
    *
    * <p>In TextViewer, this method returns the current visible region of this
    * viewer's document.  Defined by ITextViewer as part of its visible-region
    * support.
    *
    * @see org.eclipse.jface.text.ITextViewer#getVisibleRegion
    */
   public IRegion getVisibleRegion()
   {
      return new org.eclipse.jface.text.Region(0, 0);
   }

   /**
    * This method does nothing.
    * In LpexTextViewer, the visible document (or document section) is always
    * the viewer's (entire) input document.  To display only certain region(s)
    * of the document in the viewer, set marks for these regions, and set their
    * included or excluded attributes.  See the <b>mark</b>, <b>markIncluded</b>,
    * and <b>markExcluded</b> parameters.
    *
    * <p>In TextViewer, this method sets the region of this viewer's document
    * which will be visible in the presentation.  It does this by defining a
    * child document for this region, and setting it as the visible document for
    * the text widget (i.e., reloading the text widgets with the contents of
    * this child document). It is defined by ITextViewer as part of its
    * visible-region support.
    *
    * @see org.eclipse.jface.text.ITextViewer#setVisibleRegion
    */
   public void setVisibleRegion(int start, int len) {}

   /**
    * This method does nothing.
    * In LpexTextViewer, the visible document (or document section) is always
    * the viewer's (entire) input document.  To display only certain region(s)
    * of the document in the viewer, set marks for these regions, and set their
    * included or excluded attributes.  See the <b>mark</b>, <b>markIncluded</b>,
    * and <b>markExcluded</b> parameters.
    *
    * <p>In TextViewer, this method resets the region of this viewer's document
    * which is visible in the presentation, so that the whole document is
    * presented again.
    * It is defined by ITextViewer, as part of its visible-region support.
    *
    * @see org.eclipse.jface.text.ITextViewer#resetVisibleRegion
    */
   public void resetVisibleRegion() {}

   /**
    * This method always returns <code>true</code>.
    * In LpexTextViewer, the visible document is always the viewer's (entire)
    * input document.  To display only certain region(s) of the document in the
    * viewer, set marks for these regions, and set their included or excluded
    * attribute.  See the <b>mark</b>, <b>markIncluded</b>, and
    * <b>markExcluded</b> parameters.
    *
    * <p>In TextViewer, this method returns whether a given range overlaps with
    * the visible region of this viewer's document.
    * It is defined by ITextViewer, as part of its visible-region support.
    * @see org.eclipse.jface.text.ITextViewer#overlapsWithVisibleRegion
    */
   public boolean overlapsWithVisibleRegion(int start, int length)
   {
      return true;
   }

   //--------------------------------------

   /**
    * This method does nothing in LpexTextViewer.
    * LPEX has its own double-click actions, therefore it doesn't support
    * <code>ITextDoubleClickStrategy</code>.  Token/word selection and bracket
    * matching can be customized via new LpexActions.
    *
    * <p>Defined by ITextViewer, as part of its plugins support.
    * @see org.eclipse.jface.text.ITextViewer#setTextDoubleClickStrategy
    */
   public void setTextDoubleClickStrategy(ITextDoubleClickStrategy strategy, String contentType) {}

   /**
    * Selects from the given map the one which is registered under
    * the content type of the partition in which the given offset is located.
    *
    * @param offset  the offset for which to find the plugin
    * @param plugins the map from which to choose
    * @return the plugin registered under the offset's content type
    */
   protected Object selectContentTypePlugin(int offset, Map plugins)
   {
//*as* in LPEX, use LpexCommonParser's getLanguage(LpexDocumentLocation)?!.......
      try {
         return selectContentTypePlugin(getDocument().getContentType(offset), plugins);
         }
      catch (BadLocationException x) {
         if (TRACE_ERRORS) {
            //System.out.println("LpexTextViewer.selectContentTypePlugin: BadLocationException");
            System.out.println(JFaceTextMessages.getString("TextViewer.error.bad_location.selectContentTypePlugin"));
            }
         }
      return null;
   }

   /**
    * Selects from the given <code>plugins</code> this one which is registered for
    * the given content <code>type</code>.
    */
   private Object selectContentTypePlugin(String type, Map plugins)
   {
      if (plugins == null)
         return null;

      return plugins.get(type);
   }

// /**
//  * Hook called on receipt of a <code>VerifyEvent</code>.  The event has
//  * been translated into a <code>DocumentCommand</code>, which can now be
//  * manipulated by interested parties.
//  *
//  * <p>The implementation of this method does nothing.
//  * In TextViewer, as default behaviour, this hook forwards the command to
//  * the installed <code>IAutoIndentStrategy</code>.
//  *
//  * @param command the document command representing the verify event
//  */
// protected void customizeDocumentCommand(DocumentCommand command) {}


// /**
//  * LpexTextViewer doesn't install a TextVerifyListener.
//  * @see VerifyListener#verifyText
//  */
// protected void handleVerifyEvent(VerifyEvent e)
// {
//  ...
// }

   //---- text manipulation

   /**
    * Check whether the action specified by the operation id can be performed.
    *
    * <p>Note that most LPEX actions (as defined in e.g., LpexAbstractTextEditor)
    * call the editor directly for querying availability.
    *
    * @param operation LPEX-defined operation id (including the equivalents of
    *                  ITextOperationTarget.UNDO, .REDO, etc.)
    *
    * @see org.eclipse.jface.text.ITextOperationTarget#canDoOperation
    */
   public boolean canDoOperation(int operation)
   {
      return (_lpexView != null)? _lpexView.actionAvailable(operation) : false;
   }

   /**
    * Performs the action specified by the operation id.
    * This method may be called when <code>canDoOperation()</code>
    * returns <code>true</code>.
    *
    * <p>Note that most LPEX actions (as defined in e.g., LpexAbstractTextEditor)
    * call the editor directly.
    *
    * @param operation LPEX-defined operation id (including the equivalents of
    *                  ITextOperationTarget.UNDO, .REDO, etc.)
    *
    * @see org.eclipse.jface.text.ITextOperationTarget#doOperation
    */
   public void doOperation(int operation)
   {
      if (_lpexView != null)
         _lpexView.triggerAction(operation);
   }

// /**
//  * This method does nothing.
//  * In TextViewer, this method shifts a text block to the right or left using
//  * the specified set of prefix characters.
//  * The prefixes must start at the beginnig of the line.
//  *
//  * @param useDefaultPrefixes says whether the configured default or indent prefixes should be used
//  * @param right says whether to shift to the right or the left
//  *
//  * @deprecated use shift(boolean, boolean, boolean) instead
//  */
// protected void shift(boolean useDefaultPrefixes, boolean right) {}

// /**
//  * This method does nothing.
//  * In TextViewer, this method shifts a text block to the right or left using
//  * the specified set of prefix characters.
//  * If white space should be ignored the prefix characters must not be at the beginning of
//  * the line when shifting to the left. There may be whitespace in front of the prefixes.
//  *
//  * @param useDefaultPrefixes says whether the configured default or indent prefixes should be used
//  * @param right says whether to shift to the right or the left
//  * @param ignoreWhitespace says whether whitepsace in front of prefixes is allowed
//  */
// protected void shift(boolean useDefaultPrefixes, boolean right, boolean ignoreWhitespace) {}


   //---------- text presentation support

   /**
    * This method does nothing.
    * LPEX parsers set display attributes to text in the parsed document.
    * Also, LPEX marks can be set with certain style, visibility, and protection
    * attributes.
    * See the <b>mark</b> and related parameters.
    *
    * <p>Defined by ITextViewer, as part of its presentation-manipulation support.
    * @see org.eclipse.jface.text.ITextViewer#setTextColor(Color)
    */
   public void setTextColor(Color color) {}

   /**
    * This method does nothing.
    * LPEX parsers set display attributes to text in the parsed document.
    * Also, LPEX marks can be set with certain style, visibility, and protection
    * attributes.
    * See the <b>mark</b> and related parameters.
    *
    * <p>Defined by ITextViewer, as part of its presentation-manipulation support.
    * @see org.eclipse.jface.text.ITextViewer#setTextColor(Color,int,int,boolean)
    */
   public void setTextColor(Color color, int start, int length, boolean controlRedraw) {}

   /**
    * This method always return <code>null</code>.
    * In LpexTextViewer, the visible document is always the viewer's (entire)
    * input document.  To display only certain region(s) of the document in the
    * viewer, set marks for these regions, and set their included or excluded
    * attribute.  See the <b>mark</b>, <b>markIncluded</b>, and
    * <b>markExcluded</b> parameters.
    *
    * <p>In TextViewer, this method returns the visible region if it is not equal
    * to the whole document, or <code>null</code> if it is.
    */
   protected IRegion internalGetVisibleRegion()
   {
      return null;
   }

   /**
    * This method does nothing.
    * LPEX document parsers set display attributes to the text in the parsed
    * document.  Also, LPEX marks can be set with certain style, visibility,
    * and protection attributes.
    * See the <b>mark</b> and related parameters.
    *
    * <p>In TextViewer, this method applies in the text widget the color
    * information of the specified text presentation.
    *
    * <p>Defined by ITextViewer, as part of its presentation-manipulation support.
    * @see org.eclipse.jface.text.ITextViewer#changeTextPresentation
    */
   public void changeTextPresentation(TextPresentation presentation, boolean controlRedraw) {}

   /**
    * This method returns <code>null</code>.
    * LPEX implements its own <b>findAndReplace</b> action.
    *
    * <p>Defined by ITextViewer, as part of its target-handling support.
    * @see org.eclipse.jface.text.ITextViewer#getFindReplaceTarget
    */
   public IFindReplaceTarget getFindReplaceTarget()
   {
      return null;
   }

   /**
    * Return the text-operations target of this viewer.
    *
    * <p>Defined by ITextViewer, as part of its target-handling support.
    * @see org.eclipse.jface.text.ITextViewer#getTextOperationTarget()
    */
   public ITextOperationTarget getTextOperationTarget()
   {
      return this;
   }

   /**
    * Hook to initialize a newly instantiated LpexView.
    * Called from createControl().
    *
    * <p>Extend this method to set any file/view-specific parameters for this
    * LpexView.
    * Here you may set any "File Open" preferences page settings for your
    * solution's plugin, such as <b>sequenceNumbers</b>, <b>sourceEncoding</b>,
    * <b>save.textLimit</b>, and <b>save.trim</b>.  The <b>updateProfile</b>
    * command will be called later.
    *
    * @see #createControl
    */
   protected void initializeLpexView(LpexView lpexView) {}

   /**
    * Hook for post-<b>updateProfile</b> command processing.
    * Extend this method to define your own LPEX actions (and assign them to
    * keys), and your own LPEX commands.  Ensure you also call
    * super.updateProfile().
    *
    * <p>Called when a new LpexTextViewer is created (an LPEX document is
    * opened), and whenever the <b>updateProfile</b> command is issued
    * afterwards.
    */
   protected void updateProfile()
   {
      if (_readonly != null)        // if an explicit setEditable() call by user
         _lpexView.doCommand("set readonly " + _readonly);
   }

   /**
    * Indicate which is the editor-input resource for this text viewer.
    * LPEX uses this to set its document name.  The LPEX document name
    * is used to e.g., determine the document parser activated on this document.
    *
    * <p>This method should be called prior to the setDocument() for this text
    * viewer, and whenever the input changes for this text viewer.
    */
   protected void setEditorInput(IEditorInput editorInput)
   {
      _editorInput = editorInput;
      setFileName();
   }

   //---- simple getters and setters

   /**
    * Retrieve the underlying LPEX text widget window (an SWT Composite).
    * @return null if the text widget was not yet created, or was disposed
    */
   public LpexWindow getLpexWindow()
   {
      return _lpexWindow;
   }

   /**
    * Retrieve the underlying LPEX text widget view on the document.
    * @return null if the text widget was not yet created, or was disposed
    */
   public LpexView getLpexView()
   {
      return _lpexView;
   }

   /**
    * Set/update LPEX's document absolute file name.  The file name is used
    * to e.g., determine the document parser activated through association.
    * The name is obtained from the editor-input resource.
    */
   private void setFileName()
   {
      if (_lpexView != null) {
         String name = "";

         if (_editorInput != null) {
            if (_editorInput instanceof IFileEditorInput)
               name = ((IFileEditorInput)_editorInput).getFile().getLocation().toOSString();
            else if (_editorInput instanceof IStorageEditorInput) {
               try {
                  IStorage storage = ((IStorageEditorInput)_editorInput).getStorage();
                  IPath fullPath = storage.getFullPath();
                  if (fullPath != null)
                     name = fullPath.toOSString();
                  else // try just the name, maybe was set separately from fullPath
                     name = storage.getName();
                  }
               catch (CoreException x) {}
               }
            //else if (_editorInput instanceof java.io.File) // pre-Eclipse 0.043
            // name = ((java.io.File)_editorInput).getAbsolutePath();
            }

         _lpexView.doCommand("set name " + name);
         //*as* if file extension (or name??) changed / _editorInput was null
         //     before, do an updateProfile?!.........
         }
   }

   /**
    * Return the line delimiter used by the document currently handled by
    * this text viewer.  This method assumes that a consistent line separator
    * is used throughout the document (i.e., throughout the original underlying
    * file resource).
    */
   public String getEOL()
   {
      // eol is used for offsetInFile <-> line+positionInLine conversions, and
      // to maintain the file's original line delimiter standard (Windows/UNIX);
      // also see org.eclipse.jface.text.DocumentAdapter#getLineDelimiter()
      if (_eol == null) {
         try {
            _eol = fDocument.getLineDelimiter(0);
            }
         catch (BadLocationException x) {}

         if (_eol == null) {
            String sysLineDelimiter = System.getProperty("line.separator");

            // use system's line delimiter, if it's valid choice for IDocument
            String[] delimiters = fDocument.getLegalLineDelimiters();
            if (delimiters.length > 0) {
               for (int i = 0; i < delimiters.length; i++) {
                  if (delimiters[i].equals(sysLineDelimiter)) {
                     _eol = sysLineDelimiter;
                     break;
                     }
                  }
               }

            // system line delimiter is not a legal IDocument line delimiter
            if (_eol == null) {
               if (delimiters.length > 0)
                  _eol = delimiters[0];    // use first legal one...
               else
                  _eol = sysLineDelimiter; // no other choice..
               }
            }
         }

      return _eol;
   }

   // /**
   //  * These methods were used in previous Eclipse builds, when we could still
   //  * emulate what FileDocumentProvider.saveDocument() was doing, which is not
   //  * viable any longer...
   //  * Try to do a save or save as of the LPEX text widgets contents straight
   //  * to the local editor-input resource.
   //  * This method is used to do a save (or save as), because LpexTextViewer
   //  * doesn't keep its IDocument up-to-date;  also, this method takes into
   //  * account the <b>save.trim</b> and <b>save.textLimit</b> parameters of the
   //  * LPEX <b>save</b> command.
   //  *
   //  * @return <code>true</code> save performed, or
   //  *         <code>false</code> cannot save directly from LPEX
   //  */
   // public boolean doSaveAction(IProgressMonitor monitor, IEditorInput input) throws CoreException
   // {
   //  if (_lpexView != null) {
   //   if (input instanceof IFileEditorInput) {
   //    IFile ifile = ((IFileEditorInput)input).getFile();
   //    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
   //    OutputStreamWriter writer = new OutputStreamWriter(bytes);
   //    _lpexView.setSaveWriter(writer);
   //    _lpexView.setSaveLineSeparator(getEOL());
   //    _lpexView.triggerAction(LpexConstants.ACTION_SAVE_TO_WRITER);
   //    InputStream stream = new ByteArrayInputStream(bytes.toByteArray());
   //    if (ifile.exists()) // 1.- "Save"
   //     ifile.setContents(stream,   // input stream
   //                       false,    // force (when not in sync with local file system)
   //                       true,     // keep history
   //                       monitor); // progress monitor
   //    else                // 2.- "Save as"
   //     ifile.create(stream,   // input stream
   //                  false,    // overwrite (when not in sync with local file system)
   //                  monitor); // progress monitor
   //    _lpexView.setSaveWriter(null);
   //    return true;
   //    }
   //   }
   //  return false;
   // }
   // public boolean doSaveAction(IProgressMonitor monitor) throws CoreException
   // {
   //    return doSaveAction(monitor, _editorInput);
   // }


   /**
    * Variation of org.eclipse.jface.text.TextSelection for LPEX, which uses
    * LpexView rather than IDocument.
    */
   private final class LpexTextSelection extends TextSelection
   {
      private LpexView lpexView;

      LpexTextSelection(LpexView lpexView,
                        IDocument document, // needed, a few super methods use it...
                        int offset, int len)
      {
         super(document, offset, len);
         this.lpexView = lpexView;
      }

      //-as- always use the *current* LPEX selection for now...
      public String getText()
      {
         if (lpexView == null)
            return null;

         if (lpexView.queryOn("block.inView"))
            return lpexView.query("block.text");

         return ""; // no block - no selection
      }
   }
}