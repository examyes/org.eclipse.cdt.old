//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// DocumentAdapter - synchronizes IDocument and LPEX document
// (Eclipse R2.0).
// See also org.eclipse.jface.text.DocumentAdapter (used by TextViewer), and
// org.eclipse.jdt.internal.ui.javaeditor.DocumentAdapter (and its related
// org.eclipse.jdt.core.IBuffer).
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import com.ibm.lpex.core.LpexDocumentListener;
import com.ibm.lpex.core.LpexDocumentLocation;
import com.ibm.lpex.core.LpexView;

import org.eclipse.swt.SWT;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.DocumentEvent;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentExtension;
import org.eclipse.jface.text.IDocumentListener;


/**
 * Synchronizes an Eclipse <code>IDocument</code> with an LpexView's own
 * internal document.
 * The document adapter is used by LpexTextViewer to translate IDocument
 * changes into LPEX document text changes, and vice versa.
 *
 * <p>Two LpexViews on the same LPEX document cannot directly use this
 * DocumentAdapter, as IDocument notifications will be sent twice to the
 * LPEX document, it being common to the two views.  Some extra management
 * is required for such cases.
 *
 * *as* WORK IN PROGRESS . . . Only handles LPEX --> IDocument for now
 */
final class DocumentAdapter implements IDocumentListener,
                                       LpexDocumentListener
                                       // IDocumentAdapter - StyledTextContent specific...
{
 // LpexTextViewer
 private LpexTextViewer _lpexTextViewer;
 // the adapted Eclipse IDocument
 private IDocument _document;
 // the adapted LpexView
 private LpexView _lpexView;

 // remember IDocument event between aboutToBeChanged & changed notifications
 private DocumentEvent _event;
 // & whether it is a complete IDocument replace
 private boolean _eventTotalDoc;
 // & the end {line,position} for part to delete, if any
 private int _eventEndLine, _eventEndPosition;


 /**
  * Creates a new document adapter for an LpexTextViewer.
  * Initially, it is not connected to any document.
  */
 public       DocumentAdapter(LpexTextViewer lpexTextViewer)
 {
  _lpexTextViewer = lpexTextViewer;
 }

 /**
  * Sets the given Eclipse document as the IDocument to be adapted.
  *
  * @param document the IDocument to be adapted, or <code>null</code> if
  *                 there is no (longer a) document
  */
 void         setEclipseDocument(IDocument document)
 {
  listenToEclipseDocument(false);
  _document = document;
  listenToEclipseDocument(true);
 }

 /**
  * Sets the given LpexView as the LPEX view whose document is being adapted.
  */
 void         setLpexView(LpexView lpexView)
 {
  listenToLpexDocument(false);
  _lpexView = lpexView;
  listenToLpexDocument(true);
 }

 /**
  * Suspend/restore IDocument listening.
  */
 void         listenToEclipseDocument(boolean listen)
 {
  if (_document != null) {
     if (listen)
        _document.addPrenotifiedDocumentListener(this);
     else
        _document.removePrenotifiedDocumentListener(this);
     }
 }

 /**
  * Suspend/restore LPEX document listening.
  */
 void         listenToLpexDocument(boolean listen)
 {
  if (_lpexView != null) {
     if (listen)
        _lpexView.addLpexDocumentListener(this);
     else
        _lpexView.removeLpexDocumentListener(this);
     }
 }

 /**
  * IDocument change coming.
  * Prepare to update LpexView's document.
  *
  * @see org.eclipse.jface.text.IDocumentListener#documentAboutToBeChanged
  */
 public void  /*Eclipse*/documentAboutToBeChanged(DocumentEvent event)
 {
  _event = event;
  int offset = event.getOffset();
  int len = event.getLength();

  // remember if entire IDocument is replaced (e.g., change file from local history)
  _eventTotalDoc = offset == 0 && len == _document.getLength();

  // save end {line,position} info from IDocument for the part to delete, if any
  if (!_eventTotalDoc && len != 0) {
     offset += len;
     _eventEndLine = getDocLine(offset);
     _eventEndPosition = offset - getDocOffset(_eventEndLine);
     }
 }

 /**
  * IDocument has changed.
  * Update LpexView's document.
  *
  * @see org.eclipse.jface.text.IDocumentListener#documentChanged
  */
 public void  /*Eclipse*/documentChanged(DocumentEvent event)
 {
  if (_event == null || _event != event || _lpexView == null)
     return;

  // DEBUG DEBUG DEBUG
  // if (_eventTotalDoc)
  //    System.out.println("## IDocument TOTAL change!");
  // else {
  //    System.out.println("## IDocument line="+getDocLine(event.getOffset())+
  //       ", position="+(event.getOffset()-getDocOffset(getDocLine(event.getOffset())))+
  //       ", oldLen="+event.getLength()+
  //       ", newLen="+event.getText().length()+
  //       ", text="+event.getText());
  //    }
  // DEBUG DEBUG DEBUG

  if (_eventTotalDoc)
     lpexUpdate(event.getText());
  else
     lpexUpdate(event.getText(), event.getOffset(), event.getLength());
 }

 /**
  * LPEX document has changed.
  * Update IDocument.
  *
  * @param line     ONE-based line defined inside the document section currently
  *                 loaded in LPEX
  * @param position ONE-based position inside the full line (including any
  *                 sequence numbers)
  *
  * @see com.ibm.lpex.core.LpexDocumentListener#documentChanged
  */
 public void  /*LPEX*/documentChanged(LpexView lpexView, int type, int line, int position, int len)
 {
  if (_document == null)
     return;

  // DEBUG DEBUG DEBUG
  // String change;
  // switch (type) {
  //  case TEXT_REMOVED:     change = "** TEXT REMOVED  "; break;
  //  case TEXT_REPLACED:    change = "** TEXT REPLACED "; break;
  //  case TEXT_INSERTED:    change = "** TEXT INSERTED "; break;
  //  case ELEMENT_REMOVED:  change = "** ELEM REMOVED  "; break;
  //  case ELEMENT_REPLACED: change = "** ELEM REPLACED "; break;
  //  case ELEMENT_INSERTED: change = "** ELEM INSERTED "; break;
  //  default:               change = "** ????????????? ";
  //  }
  // System.out.println(change+" line="+line+", position="+position+", len="+len);
  // DEBUG DEBUG DEBUG

  int docOffset;
  int docLen;
  String docText;

  switch (type) {
     case TEXT_REMOVED:
          docOffset = getDocOffset(line, position);
          docLen    = len;
          docText   = "";
          break;
     case TEXT_REPLACED:
          docOffset = getDocOffset(line, position);
          docLen    = len;
          docText   = getLpexText(line, position, len);
          break;
     case TEXT_INSERTED:
          docOffset = getDocOffset(line, position);
          docLen    = 0;
          docText   = getLpexText(line, position, len);
          break;
     case ELEMENT_REMOVED:
          docOffset = getDocOffset(line);
          docLen    = getDocLineLength(line);
          docText   = "";
          break;
     case ELEMENT_REPLACED:
          docOffset = getDocOffset(line);
          docLen    = getDocLineLength(line); // includes EOL, if line has one
          docText   = getLpexText(line) + _lpexTextViewer.getEOL();
          break;
     case ELEMENT_INSERTED:
          docOffset = getDocOffset(line);
          docLen    = 0;
          docText   = getLpexText(line) + _lpexTextViewer.getEOL();
          break;
     default:
          return;
     }

  docUpdate(docText, docOffset, docLen);
 }

 /**
  * Return the number of the line at which the character of the
  * specified offset is located in the IDocument.
  *
  * A new line starts directly after a line delimiter.  An offset equal to the
  * IDocument length is a valid argument (although there is no corresponding
  * character), and returns the number of lines.  If the character at offset
  * is a delimiter character, it returns the line index of the line that is
  * delimited.
  *
  * @param offset ZERO-based offset in IDocument
  *
  * @return ONE-based line number for the given offset
  */
 private int  getDocLine(int offset)
 {
  try {
     return _document.getLineOfOffset(offset) + 1;
     }
  catch (BadLocationException x) {
     SWT.error(SWT.ERROR_INVALID_ARGUMENT);
     return -1;
     }
 }

 /**
  * Determine the offset in IDocument of the first character of the given line.
  *
  * NOTE: when inserting a new line in LPEX (e.g., 2nd) at the end of the
  * document, IDocument will only recognize this line number & return an offset
  * for it if its current last one (here, 1st and only) ends in a line delimiter
  * - another good reason for us to always call #docUpdateEndingEOL()!
  *
  * @param line ONE-based line number inside the document
  *
  * @return ZERO-based offset in IDocument of the given line
  */
 private int  getDocOffset(int line)
 {
  try {
     return _document.getLineOffset(line-1);
     }
  catch (BadLocationException x) {
     SWT.error(SWT.ERROR_INVALID_ARGUMENT);
     return -1;
     }
 }

 /**
  * Determine the offset in IDocument of the given line and position in it.
  *
  * @param line     ONE-based line number inside the document
  * @param position ONE-based position inside the line
  *
  * @return ZERO-based offset in IDocument
  */
 private int  getDocOffset(int line, int position)
 {
  try {
     return _document.getLineOffset(line-1) + position-1;
     }
  catch (BadLocationException x) {
     SWT.error(SWT.ERROR_INVALID_ARGUMENT);
     return -1;
     }
 }

 // reusable temp LPEX document location, so we don't change input argument
 private LpexDocumentLocation loc = new LpexDocumentLocation(1,1);
 /**
  * Determine the offset in IDocument of the given location defined inside the
  * document section currently loaded in LPEX.  This method adjusts LPEX
  * positions which are outside the current IDocument text (in LPEX the cursor,
  * character/element/rectangle block positions, etc. can be located outside
  * the actual line text).
  *
  * @param documentLocation a document location (element inside the
  *                         document section currently loaded in LPEX, position
  *                         inside the editable text part of the line)
  * @return ZERO-based offset in IDocument
  */
 int          getDocOffset(LpexDocumentLocation documentLocation)
 {
  //-as- once we provide access to ElementList#textToFullTextPosition() and
  // #fullTextPositionToPosition(), can deprecate LpexView#charOffset() and
  // #documentLocation(int,int) (which also assume a uniform EOL throughout
  // the IDocument...), and use something a la #getDocOffset(int,int)?!
  if (documentLocation == null || _lpexView == null)
     return -1;

  loc.element  = documentLocation.element;
  int maxPosition = _lpexView.elementText(loc.element).length() + 1;

  loc.position = documentLocation.position;
  if (loc.position > maxPosition)
     loc.position = maxPosition;

  return _lpexView.charOffset(loc, _lpexTextViewer.getEOL().length());
 }

 /**
  * Return the length of the given line in IDocument including the line's
  * delimiter.
  *
  * @param line ONE-based line number
  */
 private int  getDocLineLength(int line)
 {
  try {
     return _document.getLineLength(--line);
     }
  catch (BadLocationException x) {
     SWT.error(SWT.ERROR_INVALID_ARGUMENT);
     return -1;
     }
 }

 /**
  * Return the LPEX text in the given line.
  * No line delimiter is included.
  *
  * @param line ONE-based line number
  */
 private String getLpexText(int line)
 {
  return _lpexView.elementFullText(_lpexView.elementOfLine(line));
 }

 /**
  * Return the LPEX text in a line at the given position and of the given length.
  * No line delimiter is included.
  *
  * @param line     ONE-based line number
  * @param position ONE-based position in line
  * @param len      required length of text
  */
 private String getLpexText(int line, int position, int len)
 {
  return _lpexView.elementFullText(_lpexView.elementOfLine(line))
                  .substring(position-1, position-1 + len);
 }

// /**
//  * Update the entire Eclipse IDocument with the given text.
//  * It does not trigger changes in the LPEX document.
//  *
//  * @param text the new IDocument contents
//  */
// public void  docUpdate(String text)
// {
//  if (_document == null)
//     return;
//
//  listenToEclipseDocument(false);
//  _document.set(text);
//  listenToEclipseDocument(true);
// }

 /**
  * Update the Eclipse IDocument with the given text for the specified range.
  * As the updates are a consequence of LPEX document updates, it does not
  * trigger changes in the LPEX document.
  *
  * @param text   substitution text
  * @param offset ZERO-based offset in IDocument
  * @param len    length of the specified range
  */
 private void docUpdate(String text, int offset, int len)
 {
  listenToEclipseDocument(false);

  try {
     _document.replace(offset, len, text);
     }
  catch (BadLocationException x) {
     SWT.error(SWT.ERROR_INVALID_ARGUMENT);
     }

  listenToEclipseDocument(true);
 }

 /**
  * Ensure the IDocument contents end in a line delimiter, like LPEX saves its
  * documents (which is healthy for NFS transfers, etc).
  */
 // see also comments in prolog of #getDocOffset(int)...
 void         docUpdateEndingEOL()
 {
  if (_document == null)
     return;

  try {
     int len = _document.getLength();
     char eol = (len == 0)? 0 : _document.getChar(len-1);
     if (eol != '\r' && eol != '\n')
        docUpdate(_lpexTextViewer.getEOL(), _document.getLength(), 0);
     }
  catch (BadLocationException x) {}
 }

 /**
  * Update the entire LPEX document with the given text.
  * As the updates are a consequence of IDocument updates, this method does
  * not trigger changes here in the Eclipse IDocument.
  *
  * @param text the new LPEX document contents
  */
 private void lpexUpdate(String text)
 {
  listenToLpexDocument(false);
  _lpexView.setText(text);                     // re-set entire text
  listenToLpexDocument(true);
  _lpexView.doGlobalCommand("screenShow");     // refresh screen
 }

 /**
  * Update the LPEX document with the given text for the specified range.
  * As the updates are a consequence of IDocument updates, this method does
  * not trigger changes here in the Eclipse IDocument, except for any further
  * LPEX-specific adjustments done on the new text.
  *
  * @param text   substitution text
  * @param offset ZERO-based offset in IDocument
  * @param len    length of the specified range
  */
 private void lpexUpdate(String text, int offset, int len)
 {
//int line = getDocLine(offset);
//int element = _lpexView.elementOfLine(line);
//int position = offset - getDocOffset(_eventEndLine);
//
//listenToLpexDocument(false);
//
//// (1) text to delete: {line,position} .. {_eventEndLine,_eventEndPosition}
//if (len != 0) {
//   //*as* clear & restore "fields" & use force !!!
//   //     this must be fullText deletion !!!
//
//   // (a) deletion inside line
//   if (line == _eventEndLine) {
//      //*as* . . .
//      }
//
//   // (b) deletion across lines
//   else {
//      //*as* . . .
//      }
//
//   //*as* ANY LPEX-ADJUSTMENTS TO THE NEW TEXT (seq nums changes) - can send any
//   //     number of these:
//   //String adjText = "";
//   //int adjOffset = 1;
//   //int adjLen = 1;
//   //Adjust adjust = new Adjust(adjText, adjOffset, adjLen);
//   //((IDocumentExtension)_document).registerPostNotificationReplace(this, adjust);
//   //*as* . . .
//   }
//
//// (2) text to insert
//if (text.length() != 0) {
//   //*as* clear & restore "fields" & use force !!!
//   //     this must be fullText insertion !!!
//   _lpexView.doDefaultCommand(new LpexDocumentLocation(element, position),
//                              "insertText " + text);
//   //*as* ANY LPEX-ADJUSTMENTS TO THE NEW TEXT (seq nums [changes])- ?
//   //     can send any number of these...
//   }
//
//listenToLpexDocument(true);
 }


 /**
  * A post-notification IDocument adjustment.
  *
  * <p>When IDocument changes -> LPEX document is consequently changed ->
  * sequence numbers updates may cause adjustments to the new text.  We cannot
  * in turn update the IDocument from within its own original documentChanged()
  * notification call, but the IDocumentExtension.IReplace mechanism (though
  * not an official API yet), allows this:  after all its IDocument listeners
  * are notified, any registered post-notification Replace requests for this
  * IDocument are activated.
  * See also org.eclipse.jdt.internal.ui.text.link.LinkedPositionManager.
  *
  * @see org.eclipse.jface.text.IDocumentExtension#registerPostNotificationReplace
  */
 private static class Adjust implements IDocumentExtension.IReplace
 {
  private String _adjustText;
  private int _adjustOffset;
  private int _adjustLength;

  public      Adjust(String text, int offset, int len)
  {
   _adjustText = text;
   _adjustOffset = offset;
   _adjustLength = len;
  }

  public void perform(IDocument document, IDocumentListener owner)
  {
   // suspend listening - don't listen to our own IDocument adjustments...
   document.removePrenotifiedDocumentListener(owner);
   try {
      document.replace(_adjustOffset, _adjustLength, _adjustText);
      }
   catch (BadLocationException e) {
      // LpexLog.log(e);
      }
   // restore listening
   document.addPrenotifiedDocumentListener(owner);
  }
 }
}