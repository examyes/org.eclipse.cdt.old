//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexVerticalRuler - vertical ruler for the LPEX-based LpexSourceViewer.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import com.ibm.lpex.core.LpexDocumentLocation;
import com.ibm.lpex.core.LpexStringTokenizer;
import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.core.LpexViewAdapter;
import com.ibm.lpex.core.LpexViewListener;
import com.ibm.lpex.core.LpexWindow;

import java.util.Iterator;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;

import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.IAnnotationModelListener;
import org.eclipse.jface.text.source.IVerticalRuler;

import org.eclipse.core.resources.IMarker;
import org.eclipse.ui.texteditor.MarkerAnnotation;


/**
 * The class implements a vertical ruler which is connected to an LpexTextViewer.
 *
 * @see org.eclipse.jface.text.ITextViewer
 * @see org.eclipse.jface.text.source.IVerticalRuler
 */
public final class LpexVerticalRuler implements IVerticalRuler
{
   /**
    * Internal annotation-model listener listener.
    */
   class InternalListener implements IAnnotationModelListener
   {
      /**
       * Called if a model change occured on the given annotation model
       * (annotation added or removed).
       *
       * @see org.eclipse.jface.text.source.IAnnotationModelListener#modelChanged
       */
      public void modelChanged(IAnnotationModel model)
      {
         update();
      }
   };


   /** The vertical ruler's text viewer (LpexTextViewer). */
   private ITextViewer fTextViewer;
   /** The ruler's SWT control, a Canvas. */
   private Canvas fCanvas;
   /** The vertical ruler's annotation model. */
   private IAnnotationModel fModel;

   // Cache for the actual scroll position in pixels -
   // VerticalRuler:  uses StyledText.getTopPixel(), the top pixel being the
   //   pixel position of the line that's currently at the top of the widget.
   //   The text widget can be scrolled by pixels by dragging the scroll
   //   thumb, so that a partial line may be displayed at the top of the
   //   widget:  the top pixel changes when the widget is scrolled.  The top
   //   pixel does not include the widget trimming (the top inset).
   // LpexVerticalRuler:  LPEX always displays a full line of text at the top
   //   of the TextWindow edit area.
   // private int fScrollPos;

   /** The drawable for double buffering. */
   private Image fBuffer;
   /** The line of the last mouse button activity. */
   private int fLastMouseButtonActivityLine = -1;
   /** The internal listener */
   private InternalListener fInternalListener = new InternalListener();
   /** The width of this vertical ruler */
   private int fWidth;

   // all the listening for changes in the LPEX screen
   private LpexViewListener _lpexViewListener;


   /**
    * Constructs a vertical ruler with the given width.
    * The actual vertical-ruler SWT control is only created when createControl()
    * is invoked.
    *
    * @param width the width of the vertical ruler
    */
   public LpexVerticalRuler(int width)
   {
      fWidth = width;
   }

   /**
    * Return the vertical ruler's SWT control, if any was created yet.
    *
    * @see org.eclipse.jface.text.source.IVerticalRuler#getControl
    */
   public Control getControl()
   {
      return fCanvas;
   }

   /**
    * @see org.eclipse.jface.text.source.IVerticalRuler#getWidth
    */
   public int getWidth()
   {
      return fWidth;
   }

   /**
    * Create the vertical ruler's SWT control, a Canvas,
    * for the LpexTextViewer specified.
    *
    * @see org.eclipse.jface.text.source.IVerticalRuler#createControl
    */
   public Control createControl(Composite parent, ITextViewer textViewer)
   {
      fTextViewer = textViewer;
      fCanvas = new Canvas(parent, SWT.NO_BACKGROUND);

      // listen to paint requests
      fCanvas.addPaintListener(new PaintListener() {
         public void paintControl(PaintEvent event) {
            if (fTextViewer != null)
               doubleBufferPaint(event.gc);
            }
         });

      // listen to dispose ourselves when dismissed
      fCanvas.addDisposeListener(new DisposeListener() {
         public void widgetDisposed(DisposeEvent e) {
            handleDispose();
            }
         });

      // listen to record the corresponding document line number for any
      // mouse down / doubleclick inside the vertical ruler
      fCanvas.addMouseListener(new MouseListener() {
         public void mouseUp(MouseEvent event) {}

         public void mouseDown(MouseEvent event) {
            fLastMouseButtonActivityLine = toDocumentLineNumber(event.y);
            }

         public void mouseDoubleClick(MouseEvent event) {
            fLastMouseButtonActivityLine = toDocumentLineNumber(event.y);
            }
         });

      // listen to the LPEX screen updates to keep ruler in sync
      if (fTextViewer != null) {
         LpexView lpexView = ((LpexTextViewer)fTextViewer).getLpexView();
         if (lpexView != null) {
            if (_lpexViewListener == null)
               _lpexViewListener = new LpexViewAdapter() {
                  // do it only when the display actually changes!?... -as-
                  public void shown(LpexView view) {
                     redraw();
                     }
                  };
            lpexView.addLpexViewListener(_lpexViewListener);
            }
         }

      return fCanvas;
   }

   /**
    * Dispose of the ruler's resources.
    */
   private void handleDispose()
   {
      if (fTextViewer != null) {
         LpexView lpexView = ((LpexTextViewer)fTextViewer).getLpexView();
         if (lpexView != null) {
            lpexView.removeLpexViewListener(_lpexViewListener);
            _lpexViewListener = null;
            }
         fTextViewer = null;    // we're there no more for the LpexTextViewer...
         }

      if (fModel != null)
         fModel.removeAnnotationModelListener(fInternalListener);

      if (fBuffer != null) {
         fBuffer.dispose();
         fBuffer = null;
         }
   }

   /**
    * Double-buffer drawing.
    */
   private void doubleBufferPaint(GC dest)
   {
      Point size = fCanvas.getSize();
      if (size.x <= 0 || size.y <= 0)
         return;

      if (fBuffer != null) {
         Rectangle r = fBuffer.getBounds();
         if (r.width != size.x || r.height != size.y) {
            fBuffer.dispose();
            fBuffer = null;
            }
         }

      if (fBuffer == null)
         fBuffer = new Image(fCanvas.getDisplay(), size.x, size.y);

      GC gc = new GC(fBuffer);
      try {
         gc.setBackground(fCanvas.getBackground());
         gc.fillRectangle(0, 0, size.x, size.y);
         doPaint(gc);
         }
      finally {
         gc.dispose();
         }

      dest.drawImage(fBuffer, 0, 0);
   }

   /**
    * Draws the vertical ruler annotations (without drawing the Canvas
    * background).
    */
   private Rectangle _r = new Rectangle(0, 0, 0, 0); // reuse painting rectangle
   private void doPaint(GC gc)
   {
      if (fModel == null || fTextViewer == null)
         return;

      LpexView lpexView = ((LpexTextViewer)fTextViewer).getLpexView();
      LpexWindow lpexWindow = ((LpexTextViewer)fTextViewer).getLpexWindow();
      int rowHeight = lpexView.queryInt("rowHeight");
      int rows = lpexView.queryInt("rows"); // 1..rows visible in the edit area
      int linesBeforeStart = lpexView.linesBeforeStart(); // lines before doc section

      // skip over the widget inset, LPEX's status & format lines
      int shift = fTextViewer.getTopInset() +
                  lpexWindow.textWindow().getLocation().y;

      // establish lowest/highest lines inside the currently-loaded document section
      //(-as- to display correct ruler for lines ouside TextWindow but inside
      // Screen, so as to allow for smooth scrolling of stuff inside ruler?!?)
      int lowestShowing = lpexView.queryInt("lines") + 1 -
                          (linesBeforeStart + lpexView.linesAfterEnd());
      int highestShowing = 0;
      for (int i = 1;  i <= rows; i++) {
         int element = lpexView.elementOfRow(i);
         if (element != 0 && !lpexView.show(element)) {
            int line = lpexView.lineOfElement(element);
            if (line < lowestShowing)
               lowestShowing = line;
            if (line > highestShowing)
               highestShowing = line;
            }
         }
      if (highestShowing == 0)
         return;

      // draw Annotations
      Point d = fCanvas.getSize();
      //Rectangle r = new Rectangle(0, 0, d.x, 0);
      _r.x = 0; /* _r.y = 0; */ _r.width = d.x; /* _r.height = 0; */
      int maxLayer = 1;  // loop at least once thru layers

      for (int layer = 0; layer < maxLayer; layer++) {
         Iterator iter = fModel.getAnnotationIterator();
         while (iter.hasNext()) {
            Annotation annotation = (Annotation)iter.next();
            if (!(annotation instanceof MarkerAnnotation))
               continue;

            int lay = annotation.getLayer();
            maxLayer = Math.max(maxLayer, lay+1); // dynamically update layer maximum
            if (lay != layer)                     // wrong layer: skip annotation
               continue;

            // retrieve annotation's underlying marker -> LPEX mark for it
            //(-as- currently, we don't display annotations w/o LPEX marks...)
            IMarker marker = ((MarkerAnnotation)annotation).getMarker();
            String mark = lpexView.query("mark.@ALEF." + String.valueOf(marker.getId()));
            if (mark == null)
               continue;

            int startLine, endLine;
            LpexStringTokenizer st = new LpexStringTokenizer(mark);
            String token = st.nextToken();
            if (token.equals("sticky"))
               token = st.nextToken();
            if (token.equals("element")) {
               // line marker
               startLine = lpexView.lineOfElement(Integer.parseInt(st.nextToken()) -
                                                  linesBeforeStart);
               endLine   = lpexView.lineOfElement(Integer.parseInt(st.nextToken()) -
                                                  linesBeforeStart);
               }
            else {
               // character marker
               startLine = lpexView.lineOfElement(Integer.parseInt(token) -
                                                  linesBeforeStart);
               st.nextToken(); // skip position1
               endLine   = lpexView.lineOfElement(Integer.parseInt(st.nextToken()) -
                                                  linesBeforeStart);
               }

            if (startLine > highestShowing || endLine < lowestShowing)
               continue;

            int startRow = -1, endRow = -1;    // ZERO-based rows for paint calc
            for (int i = 1;  i <= rows; i++) {
               int element = lpexView.elementOfRow(i);
               if (element != 0 && !lpexView.show(element)) {
                  int line = lpexView.lineOfElement(element);

                  if (line == startLine)
                     startRow = i - 1;
                  else if (line > startLine &&
                           startRow == -1 &&   // start not yet set
                           line <= endLine) {
                     startRow = 0;
                     endRow   = startRow;
                     }

                  if (line > endLine)
                     break;
                  else if (line == endLine) {
                     endRow = i - 1;
                     break;
                     }
                  else if (line < endLine && startRow != -1)
                     endRow = i - 1;
                  }
               }//end "for rows"


            if (startRow >= 0) {    // let annotation paint itself if visible...
               _r.y = (startRow * rowHeight) + shift;
               if (_r.y < d.y) {    // ... and within the ruler's canvas
                  //_r.x = 0; _r.width = d.x;
                  _r.height = (endRow - startRow + 1) * rowHeight;
                  annotation.paint(gc, fCanvas, _r);
                  }
               }
            }//end "while annotations"
         }//end "for layers"
   }

   /**
    * Force the vertical ruler to update.
    * This method can be called from any thread.
    *
    * @see org.eclipse.jface.text.source.IVerticalRuler#update
    */
   public void update()
   {
      if (fCanvas != null && !fCanvas.isDisposed()) {
         Display d = fCanvas.getDisplay();
         if (d != null) {
            d.asyncExec(new Runnable() {
               public void run() {
                  redraw();
                  }
               });
            }
         }
   }

   /**
    * Redraw the vertical ruler.
    */
   private void redraw()
   {
      if (fCanvas != null && !fCanvas.isDisposed()) {
         GC gc = new GC(fCanvas);
         doubleBufferPaint(gc);
         gc.dispose();
         }
   }

   /**
    * Associate an annotation model with this vertical ruler.
    * If the ruler is visible, it must display those annotations of the
    * annotation model whose visual representation overlaps with the viewport
    * of the text viewer.  A <code>null</code> value clears the ruler.
    *
    * @see org.eclipse.jface.text.source.IVerticalRuler#setModel
    */
   public void setModel(IAnnotationModel model)
   {
      if (model != fModel) {
         if (fModel != null)
            fModel.removeAnnotationModelListener(fInternalListener);

         fModel = model;
         if (fModel != null)
            fModel.addAnnotationModelListener(fInternalListener);

         update();
         }
   }

   /**
    * Return the current annotation model of this ruler, or <code>null</code>
    * if the ruler has no model.
    *
    * @see org.eclipse.jface.text.source.IVerticalRuler#getModel
    */
   public IAnnotationModel getModel()
   {
      return fModel;
   }

   /**
    * Return the document line number in LpexTextViewer corresponding to the
    * last mouse-button activity inside the ruler.
    *
    * @see org.eclipse.jface.text.source.IVerticalRuler#getLineOfLastMouseButtonActivity
    */
   public int getLineOfLastMouseButtonActivity()
   {
      return fLastMouseButtonActivityLine;
   }

   /**
    * Translate a y-coordinate of the vertical ruler's SWT Control into
    * the corresponding ZERO-based line number of the input document section
    * of the connected LpexTextViewer.
    *
    * @return ZERO-based document-section line number, or
    *         -1 if no corresponding document-section line
    *
    * @see org.eclipse.jface.text.source.IVerticalRuler#toDocumentLineNumber
    */
   public int toDocumentLineNumber(int y_coordinate)
   {
      if (fTextViewer == null)
         return -1;

      int top = fTextViewer.getTopInset() +
                ((LpexTextViewer)fTextViewer).getLpexWindow().textWindow().getLocation().y;
      if (y_coordinate < top)
         return -1; // above text area (on LPEX widget inset / status/format line).

      LpexView lpexView = ((LpexTextViewer)fTextViewer).getLpexView();
      int row = (y_coordinate - top) / lpexView.queryInt("rowHeight") + 1;
      if (row > lpexView.queryInt("rows"))
         return -1; // beyond the edit-area full rows.

      int element = lpexView.elementOfRow(row);
      if (element == 0 || lpexView.show(element))
         return -1; // not a document line (expand/hide header / eof / show).

      return lpexView.lineOfElement(element) - 1;
   }
}