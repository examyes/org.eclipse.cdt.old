//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexMarkerRulerAction - variation of MarkerRulerAction for LPEX
// (Eclipse R2.0).
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.source.IVerticalRulerInfo;

import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.MarkerRulerAction;
import org.eclipse.ui.texteditor.MarkerUtilities;


/**
 * Variation of MarkerRulerAction for LPEX.
 * A ruler action which can add and remove markers which have a visual
 * representation in the vertical ruler.
 */
public class LpexMarkerRulerAction extends MarkerRulerAction
{
   /**
    * Create a new action for the given ruler and editor.
    * The action configures its visual representation from the given resource
    * bundle.
    *
    * @param bundle the resource bundle
    * @param key action's key prefix in the resource bundle, or
    *            <code>null</code> if none
    * @param ruler the vertical ruler
    * @param editor the text editor
    * @param markerType the type of marker
    * @param askForLabel <code>true</code> if the user should be asked for
    *            a label when a new marker is created
    *
    * @deprecated as of Eclipse R2.0 build F1, IDocument is now keeping
    * sync-ed with LPEX changes, markers being consequently maintained,
    * this class will soon go - use Eclipse's MarkerRulerAction!
    */
   public LpexMarkerRulerAction(ResourceBundle bundle, String key, IVerticalRulerInfo ruler,
                                ITextEditor editor, String markerType, boolean askForLabel)
   {
      super(bundle, key, editor, ruler, markerType, askForLabel);
   }

   /**
    * Return all markers which include the ruler's line of mouse activity.
    * Marks & markers are assumed to be defined inside the LPEX document section
    * currently loaded & inside a corresponding IDocument.
    *
    * @deprecated as of Eclipse R2.0 build F1, IDocument is now keeping
    * sync-ed with LPEX changes, markers being consequently maintained,
    * this class will soon go - use Eclipse's MarkerRulerAction!
    */
   protected List getMarkers()
   {
      return super.getMarkers();
   }

   /**
    * Returns the attributes with which a newly created marker will be
    * initialized.
    *
    * @return the initial marker attributes
    *
    * @deprecated as of Eclipse R2.0 build F1, IDocument is now keeping
    * sync-ed with LPEX changes, markers being consequently maintained,
    * this class will soon go - use Eclipse's MarkerRulerAction!
    */
   protected Map getInitialAttributes()
   {
      Map attributes = new HashMap(11);

      // 6/2001 - keep mark & marker line-only, it's a vertical ruler action!
      int line = getVerticalRulerInfo().getLineOfLastMouseButtonActivity();
      int start = -1;
      int end = -1;

      // marker line numbers are 1-based
      MarkerUtilities.setLineNumber(attributes, line + 1);
      MarkerUtilities.setCharStart(attributes, start);
      MarkerUtilities.setCharEnd(attributes, end);

      return attributes;
   }
}