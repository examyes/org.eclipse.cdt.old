//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexMarkerRulerAction - variation of MarkerRulerAction for LPEX.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import com.ibm.lpex.core.LpexStringTokenizer;
import com.ibm.lpex.core.LpexView;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

import org.eclipse.jface.text.source.IVerticalRuler;

import org.eclipse.ui.texteditor.AbstractMarkerAnnotationModel;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.MarkerRulerAction;
import org.eclipse.ui.texteditor.MarkerUtilities;


/**
 * Variation of MarkerRulerAction for LPEX.
 * A ruler action which can add and remove markers which have a visual
 * representation in the vertical ruler.
 *
 * <p>IDocument is not kept up-to-date, therefore the latest marker information
 * is only available from LPEX's corresponding marks.
 * Note that <code>includesRulerLine(Position position, IDocument document)</code>
 * is <b>not</b> supported in LpexMarkerRulerAction.
 */
public class LpexMarkerRulerAction extends MarkerRulerAction
{
   private String _markerType;  // can't access superclass's


   /**
    * Create a new action for the given ruler and editor.
    * The action configures its visual representation from the given resource
    * bundle.
    *
    * @param bundle the resource bundle
    * @param key action's key prefix in the resource bundle, or
    *            <code>null</code> if none
    * @param ruler the vertical ruler
    * @param editor the text editor
    * @param markerType the type of marker
    * @param askForLabel <code>true</code> if the user should be asked for
    *            a label when a new marker is created
    */
   public LpexMarkerRulerAction(ResourceBundle bundle, String key, IVerticalRuler ruler,
                            ITextEditor editor, String markerType, boolean askForLabel)
   {
      super(bundle, key, ruler, editor, markerType, askForLabel);
      _markerType = markerType;
   }

   /**
    * Return the attributes with which a newly created marker will be
    * initialized.
    *
    * @return the initial marker attributes
    */
   protected Map getInitialAttributes()
   {
      Map attributes = new HashMap(11);

      int line = getVerticalRuler().getLineOfLastMouseButtonActivity();
      int start = -1;
      int end = -1;

      // 6/2001 - keep mark & marker line-only, it's a vertical ruler action!
      // if (line >= 0) {
      //  int eolLength = ((LpexAbstractTextEditor)getTextEditor()).getEOL().length();
      //  LpexDocumentLocation loc = new LpexDocumentLocation(line+1, 1);
      //  LpexView lpexView = ((LpexAbstractTextEditor)getTextEditor()).getLpexView();
      //  start = lpexView.charOffset(loc, eolLength);
      //  int len = lpexView.queryInt("length", loc);
      //  if (len > 0)
      //   len--;
      //  end = start + len;
      //  }

      // marker line numbers are 1-based
      MarkerUtilities.setLineNumber(attributes, line + 1);
      MarkerUtilities.setCharStart(attributes, start);
      MarkerUtilities.setCharEnd(attributes, end);
      return attributes;
   }

   /**
    * Return all markers which include the ruler's line of mouse activity.
    * Marks & markers are assumed to be defined inside the LPEX document section
    * currently loaded & inside a corresponding IDocument.
    */
   protected List getMarkers()
   {
      List markers = new ArrayList();
      IResource resource = getResource();
      AbstractMarkerAnnotationModel model = getAnnotationModel();
      int rulerLine = getVerticalRuler().getLineOfLastMouseButtonActivity() + 1;

      if (resource == null || model == null || rulerLine < 1)
         return markers;

      LpexView lpexView = ((LpexAbstractTextEditor)getTextEditor()).getLpexView();
      try {
         IMarker[] allMarkers = resource.findMarkers(_markerType, true, IResource.DEPTH_ZERO);
         if (allMarkers != null) {
            for (int i= 0; i < allMarkers.length; i++) {
               String mark = lpexView.query("mark.@ALEF." + String.valueOf(allMarkers[i].getId()));
               if (mark == null)
                  continue;

               int startLine, endLine; // lines inside the currently-loaded document section
               LpexStringTokenizer st = new LpexStringTokenizer(mark);
               String token = st.nextToken();
               if (token.equals("sticky"))
                  token = st.nextToken();
               // look at marks inside the currently-loaded document section
               int linesBeforeStart = lpexView.linesBeforeStart();
               if (token.equals("element")) {
                  // line marker
                  startLine = lpexView.lineOfElement(Integer.parseInt(st.nextToken()) -
                                                     linesBeforeStart);
                  endLine   = lpexView.lineOfElement(Integer.parseInt(st.nextToken()) -
                                                     linesBeforeStart);
                  }
               else {
                  // character marker
                  startLine = lpexView.lineOfElement(Integer.parseInt(token) -
                                                     linesBeforeStart);
                  st.nextToken(); // skip position1
                  endLine = lpexView.lineOfElement(Integer.parseInt(st.nextToken()) -
                                                   linesBeforeStart);
                  }

               if (rulerLine >= startLine && rulerLine <= endLine)
                  markers.add(allMarkers[i]);
               }//end "for"
            }
         }
      catch (CoreException x) {
         handleCoreException(x, "MarkerRulerAction.getMarker");
         }

      return markers;
   }
}