//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexPlugin - LPEX plugin runtime class.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import java.net.URL;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.jar.JarFile;

import com.ibm.lpex.core.LpexLog;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.ILibrary;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.core.runtime.IPluginRegistry;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Plugin;


/**
 * Plugin runtime class for LPEX.
 *
 * <p>A plugin usually extends the startup() and shutdown() methods in order to
 * react to life cycle requests automatically issued by the Eclipse platform.
 */
public class LpexPlugin extends Plugin
{
   private static LpexPlugin _lpexPlugin;
   private static ResourceBundle _resourceBundle;


   /**
    * Constructs an LPEX plugin runtime object for the given plugin descriptor.
    *
    * <p>Instances of plugin runtime classes are automatically created by the
    * Eclipse platform in the course of plugin activation.
    *
    * @param descriptor the plugin descriptor (information about the plugin
    *                   obtained from its manifest file, plugin.xml)
    */
   public LpexPlugin(IPluginDescriptor descriptor)
   {
      super(descriptor);

      if (_lpexPlugin == null) {
         _lpexPlugin = this;
         try {
            _resourceBundle = ResourceBundle.getBundle("com.ibm.lpex.alef.PluginResources");
            }
         catch (MissingResourceException x) {
            _resourceBundle = null;
            }
         }
   }

   /**
    * Return an instance of this plugin.
    * Eclipse-style static convenience method to gain access to a plugin's
    * runtime object, so code in other parts of the plugin implementation
    * without direct access to the plugin runtime object can easily obtain
    * a reference to it, and hence to any plugin-wide resources recorded on it.
    *
    * @return an initialized instance of LpexPlugin
    */
   public static LpexPlugin getDefault()
   {
      return _lpexPlugin;
   }

   /**
    * Retrieve the resource bundle for this plugin.
    * The resource file of the LPEX plugin is
    * <code>com.ibm.lpex.alef.PluginResources.properties</code>.
    */
   public static ResourceBundle getResourceBundle()
   {
      return _resourceBundle;
   }

   /**
    * Retrieve a string from the LpexPlugin resource bundle.
    *
    * @return the <code>key</code> if not found
    *
    * @see #getResourceLpexString(String)
    * @see #getResourceLpexString(String,String)
    */
   public static String getResourceString(String key)
   {
      try {
         if (_resourceBundle != null)
            return _resourceBundle.getString(key);
         }
      catch (MissingResourceException x) {}
      return key;
   }

   /**
    * Retrieve from the LpexPlugin resource bundle the string with the specified
    * key.
    * This method uses class <code>LpexResources</code> to retrieve the value,
    * which assumes certain syntax rules for the text in the resource.
    *
    * @return the <code>key</code> if not found
    *
    * @see com.ibm.lpex.core.LpexResources
    * @see #getResourceString(String)
    * @see #getResourceLpexString(String,String)
    */
   public static String getResourceLpexString(String key)
   {
      String value = LpexResources.message(_resourceBundle, key);
      return (value == null)? key : value;
   }

   /**
    * Retrieve from the LpexPlugin resource bundle the string with the specified
    * key and a single substitution argument.
    * This method uses class <code>LpexResources</code> to retrieve the value,
    * which assumes certain syntax rules for the text in the resource.
    *
    * @return the <code>key</code> if not found
    *
    * @see com.ibm.lpex.core.LpexResources
    * @see #getResourceString(String)
    * @see #getResourceLpexString(String)
    */
   public static String getResourceLpexString(String key, String arg)
   {
      String value = LpexResources.message(_resourceBundle, key, arg);
      return (value == null)? key : value;
   }

   /**
    * Starts up the LPEX plugin.
    * This method is automatically invoked by the platform core the first
    * time any code in the plugin is executed.  It is intended to perform a
    * simple initialization of the plugin environment.  The platform may
    * terminate initializers that do not complete in a timely fashion.
    *
    * <p>If this method throws an exception, it is taken as an indication that
    * the plugin initialization has failed;  as a result, the plugin will not
    * be activated;  moreover, the plugin will be marked as disabled and
    * ineligible for activation for the duration.
    *
    * <p>Plugin startup code should be robust.  In the event of a startup
    * failure, the plugin's shutdown() method will be invoked automatically,
    * in an attempt to close open files, etc.
    *
    * @exception CoreException if this plugin did not start up properly
    */
   public void startup() throws CoreException
   {
      // get/create LPEX plugin's writable state area:
      // this is the location in the local file system of the plugin state area
      // for this plugin.  If the plugin state area did not exist prior to this
      // call, it is created.  The plugin state area is a file directory within
      // the platform's metadata area where a plugin is free to create files.
      // The content and structure of this area is defined by the plugin, and
      // the particular plugin is solely responsible for any files it puts
      // there.  It is recommended for plugin preference settings and other
      // configuration parameters.
      IPath homeDir = getStateLocation();

      // find/establish the error-log file, and the defaultProfile (the
      // working properties for the LPEX plugin, in Eclipse terminology)
      LpexLog.setName(homeDir.append("Editor.log").toFile().getPath());
      LpexView.doGlobalCommand("set defaultProfile " +
                               homeDir.append("Editor.properties").toFile().getPath());

      // get the class loaders of all plugins that provide LPEX extensions
      getDeclaredClassLoaders();
   }

   /**
    * Get the class loaders of all the plugins that provide extensions for the
    * LPEX Plugin:  user profiles, user-defines commands, actions, and parsers.
    *
    * Activating them here also gives them a chance to register "default." parser
    * classes and file-extension - parser associations, so they appear in the
    * LPEX Editor preference pages first time these display.
    */
   private void getDeclaredClassLoaders()
   {
      // Obtain the registry
      IPluginRegistry registry = Platform.getPluginRegistry();

      if (registry != null) {
         // locate the LPEX "preload" extension point - Plugin ID, Extension ID
         IExtensionPoint extensionPoint = registry.getExtensionPoint("com.ibm.lpex", "preload");

         // get all the plugins registering to this extension point
         if (extensionPoint != null) {
            IExtension extensions[] = extensionPoint.getExtensions();

            // for each extending plugin, get its class loader
            for (int i = 0; i < extensions.length; i++) {
               IPluginDescriptor descriptor = extensions[i].getDeclaringPluginDescriptor();
               ClassLoader classLoader = descriptor.getPluginClassLoader();
               LpexView.setClassLoader(classLoader);
               }
            }
         }
   }

   /**
    * Get access to the LPEX jar file.
    * This method is used to retrieve information from the jar manifest.
    */
   public static JarFile getLpexJar()
   {
      try {
         ILibrary[] libs = getDefault().getDescriptor().getRuntimeLibraries();
         for (int i = 0;  i < libs.length; i++) {
            if (libs[i].getType() == ILibrary.CODE) {
               // find(): platform:/plugin/com.ibm.lpex_1.2.0/lpex.jar
               URL jarUrl = getDefault().find(libs[i].getPath());
               // asLocalURL(): file:/C:/eclipse/plugins/com.ibm.lpex/lpex.jar
               URL localUrl = Platform.asLocalURL(jarUrl);
               // getFile(): /C:/eclipse/plugins/com.ibm.lpex/lpex.jar
               return new JarFile(localUrl.getFile());
               }
            }
         }
      catch(Exception x) {}
      return null;
   }
}