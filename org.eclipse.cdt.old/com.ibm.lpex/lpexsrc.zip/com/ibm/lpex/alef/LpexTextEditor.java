//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexTextEditor - a line-oriented (LPEX-based) TextEditor
// (Eclipse R2.0).  See org.eclipse.ui.editors.text.TextEditor.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import java.lang.reflect.InvocationTargetException;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.alef.LpexPlugin;

import org.eclipse.swt.widgets.Shell;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Plugin;

import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.dialogs.SaveAsDialog;
import org.eclipse.ui.editors.text.ITextEditorHelpContextIds;
import org.eclipse.ui.editors.text.DefaultEncodingSupport;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.plugin.AbstractUIPlugin;

import org.eclipse.ui.texteditor.AbstractTextEditor;
import org.eclipse.ui.texteditor.ConvertLineDelimitersAction;
import org.eclipse.ui.texteditor.DefaultRangeIndicator;
import org.eclipse.ui.texteditor.IAbstractTextEditorHelpContextIds;
import org.eclipse.ui.texteditor.ITextEditorActionConstants;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;
import org.eclipse.ui.texteditor.ResourceAction;


/**
 * A line-oriented, LPEX-based text editor for <code>IFile</code> resources and
 * <code>IStorage</code> objects.
 *
 * <p>The editor's context menu has the id defined in EDITOR_CONTEXT_MENU_ID;
 * its ruler context menu has the id defined in RULER_CONTEXT_MENU_ID.
 *
 * @see LpexAbstractTextEditor
 */
public class LpexTextEditor extends LpexStatusTextEditor
{
   /**
    * This editor's context menu (popup) id (<code>"#TextEditorContext"</code>).
    */
   public static final String EDITOR_CONTEXT_MENU_ID = "#TextEditorContext";
   /**
    * This editor's ruler context menu (popup) id (<code>"#LpexTextRulerContext"</code>).
    */
   public static final String RULER_CONTEXT_MENU_ID = "#LpexTextRulerContext";

   private DefaultEncodingSupport fEncodingSupport;


   /**
    * Use Eclipse's own resources for TextEditor-specific messages.
    * See org.eclipse.ui.editors.text.TextEditorMessages.
    */
   private static final class TextEditorMessages
   {
      private static ResourceBundle _bundle;
      public static String getString(String key)
      {
         try {
            if (getResourceBundle() != null)
               return _bundle.getString(key);
            }
         catch (MissingResourceException e) {}
         return "!" + key + "!";
      }

      public static ResourceBundle getResourceBundle()
      {
         if (_bundle == null)
            _bundle = ResourceBundle.getBundle("org.eclipse.ui.editors.text.TextEditorMessages");
         return _bundle;
      }
   }

   /**
    * Creates a new text editor.
    */
   public LpexTextEditor()
   {
      super();

      setRangeIndicator(new DefaultRangeIndicator());
      setEditorContextMenuId(EDITOR_CONTEXT_MENU_ID);

      // since Eclipse R2.0 build M5 (20020416):
      // don't use org.eclipse.ui.editors.text.TextEditor's "#TextRulerContext",
      // as then two default Eclipse items "Add bookmark..." and "Add task..."
      // (not good in LPEX) will be added on the ruler menu popup whenever
      // someone extends LpexAbstractTextEditor's rulerContextMenuAboutToShow()
      // in a solution plugin...
      setRulerContextMenuId(RULER_CONTEXT_MENU_ID);

      // added in Eclipse 0.122:
      // set help context to
      //   [PlatformUI.PLUGIN_ID + "."] + "text_editor_context"
      setHelpContextId(ITextEditorHelpContextIds.TEXT_EDITOR);  //*as* must change for LPEX!?

      // added in Eclipse 0.120:  set editor's preference store to be that of
      // the workbench plugin's - this may be OK for TextEditor, as default
      // Eclipse editor, but most probably not for LpexTextEditor?!
      // Plugin plugin = Platform.getPlugin(PlatformUI.PLUGIN_ID);
      // if (plugin instanceof AbstractUIPlugin) {
      //  AbstractUIPlugin uiPlugin = (AbstractUIPlugin)plugin;
      //  setPreferenceStore(uiPlugin.getPreferenceStore());
      //  }
   }

   /**
    * Disposes of this workbench part.  This is the last method called on the
    * IWorkbenchPart.  At this point, the part controls (if they were ever
    * created) have been disposed as part of an SWT composite.  There is no
    * guarantee that createPartControl() has been called, so the part controls
    * may never have been created.  Within this method, a part may release any
    * resources, fonts, images, etc. held by it.  It is also very important to
    * deregister all listeners from the workbench.  Clients should not call this
    * method - the workbench calls this method at appropriate times.
    * @see org.eclipse.ui.IWorkbenchPart#dispose()
    */
   public void dispose()
   {
      if (fEncodingSupport != null) {
         fEncodingSupport.dispose();
         fEncodingSupport = null;
         }
      super.dispose();
   }

   /**
    * The <code>TextEditor</code> implementation of this
    * <code>IEditorPart</code> method returns <code>true</code>.
    *
    * @see org.eclipse.ui.IEditorPart#isSaveAsAllowed
    */
   public boolean isSaveAsAllowed()
   {
      return true;
   }

   /**
    * The <code>LpexTextEditor</code> implementation of this
    * <code>AbstractTextEditor</code> method prompts the user for the workspace
    * path of a file resource, and saves the document there.
    *
    * @see #performSaveAs(IProgressMonitor,String)
    */
   protected void performSaveAs(IProgressMonitor progressMonitor)
   {
      String fileName = null;

      IEditorInput input = getEditorInput();
      if (input instanceof IFileEditorInput)
         fileName = ((IFileEditorInput)input).getFile().getName();

      performSaveAs(progressMonitor, fileName);
   }

   /**
    * The <code>LpexTextEditor</code> implementation of this
    * <code>AbstractTextEditor</code> method prompts the user for the workspace
    * path of a file resource, and saves the document there.
    *
    * @param fileName initial file name in the dialog
    * @see #performSaveAs(IProgressMonitor)
    */
   protected void performSaveAs(IProgressMonitor progressMonitor, String fileName)
   {
      Shell shell = getSite().getShell();
      SaveAsDialog dialog = new SaveAsDialog(shell);

      // try to get an acceptable initial IFile from the specified fileName...
      if (fileName != null) {
         IResource inputResource = getInputResource();
         // 1.- we have a project that we can use
         if (inputResource != null) {
            IProject project = inputResource.getProject();
            if (project != null)
               dialog.setOriginalFile(project.getFile(fileName));
            }
         // 2.- else, just forget it?!
         }

      dialog.open();
      IPath path = dialog.getResult();

      if (path == null) {
         if (progressMonitor != null)
            progressMonitor.setCanceled(true);
         return;
         }

      IWorkspace workspace = ResourcesPlugin.getWorkspace();
      IFile file = workspace.getRoot().getFile(path);
      final IEditorInput newInput = new FileEditorInput(file);

      WorkspaceModifyOperation op = new WorkspaceModifyOperation() {
         public void execute(final IProgressMonitor monitor) throws CoreException
         {
            getDocumentProvider().
            saveDocument(monitor,  // monitor
                         newInput, // the element
                         getDocumentProvider().getDocument(getEditorInput()), // the IDoc
                         true);    // overwrite?
         }
      };

      boolean success = false;
      try {
         getDocumentProvider().aboutToChange(newInput);

         //-as- must still consider any "visible" parameter of save command!?

         // cf. LpexAbstractTextEditor#performSaveOperation
         // commit any pending changes (clears 'dirty' flag), ensure all's parsed
         LpexView lpexView = getLpexView();
         lpexView.doDefaultCommand("undo check");
         lpexView.doCommand("parse");

         // even though it's a 'save as', clear changes count like Eclipse does...
         lpexView.doDefaultCommand("undo resetChanges");
         lpexView.doGlobalCommand("screenShow");

         new ProgressMonitorDialog(shell).run(false, true, op);
         success = true;
         }
      catch (InterruptedException x) {}
      catch (InvocationTargetException x) {
         Throwable targetException = x.getTargetException();
         String title = TextEditorMessages.getString("Editor.error.save.title");
         String msg = MessageFormat.format(TextEditorMessages.getString("Editor.error.save.message"),
                                           new Object[] { targetException.getMessage() });

         if (targetException instanceof CoreException) {
            CoreException coreException = (CoreException)targetException;
            IStatus status = coreException.getStatus();
            if (status != null) {
               switch (status.getSeverity()) {
                  case IStatus.INFO:
                     MessageDialog.openInformation(shell, title, msg);
                     break;
                  case IStatus.WARNING:
                     MessageDialog.openWarning(shell, title, msg);
                     break;
                  default:
                     MessageDialog.openError(shell, title, msg);
                  }
               }
            else {
               MessageDialog.openError(shell, title, msg);
               }
            }
         }
      finally {
         getDocumentProvider().changed(newInput);
         if (success)
            setInput(newInput);
         }

      if (progressMonitor != null)
         progressMonitor.setCanceled(!success);
   }

   /*
    * @see AbstractTextEditor#createActions()
    */
   protected void createActions() {
      super.createActions();

      //*as* to add these actions by default to our LpexContextContributor.java?!
      ResourceAction action = new ConvertLineDelimitersAction(TextEditorMessages.getResourceBundle(), "Editor.ConvertToWindows.", this, "\r\n");
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.CONVERT_LINE_DELIMITERS_TO_WINDOWS);
      action.setActionDefinitionId(ITextEditorActionDefinitionIds.CONVERT_LINE_DELIMITERS_TO_WINDOWS);
      setAction(ITextEditorActionConstants.CONVERT_LINE_DELIMITERS_TO_WINDOWS, action);

      action = new ConvertLineDelimitersAction(TextEditorMessages.getResourceBundle(), "Editor.ConvertToUNIX.", this, "\n");
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.CONVERT_LINE_DELIMITERS_TO_UNIX);
      action.setActionDefinitionId(ITextEditorActionDefinitionIds.CONVERT_LINE_DELIMITERS_TO_UNIX);
      setAction(ITextEditorActionConstants.CONVERT_LINE_DELIMITERS_TO_UNIX, action);

      action = new ConvertLineDelimitersAction(TextEditorMessages.getResourceBundle(), "Editor.ConvertToMac.", this, "\r");
      action.setHelpContextId(IAbstractTextEditorHelpContextIds.CONVERT_LINE_DELIMITERS_TO_MAC);
      action.setActionDefinitionId(ITextEditorActionDefinitionIds.CONVERT_LINE_DELIMITERS_TO_MAC);
      setAction(ITextEditorActionConstants.CONVERT_LINE_DELIMITERS_TO_MAC, action);

      //-as- commented out in original TextEditor
      //markAsContentDependentAction(ITextEditorActionConstants.CONVERT_LINE_DELIMITERS_TO_WINDOWS, true);
      //markAsContentDependentAction(ITextEditorActionConstants.CONVERT_LINE_DELIMITERS_TO_UNIX, true);
      //markAsContentDependentAction(ITextEditorActionConstants.CONVERT_LINE_DELIMITERS_TO_MAC, true);

//*as* MUST USE OWN LpexEncodingSupport, #initialize() takes a StatusTextEditor() right now!?...
//    fEncodingSupport = new DefaultEncodingSupport();
//    fEncodingSupport.initialize(this);
   }

   /*
    * @see StatusTextEditor#getStatusHeader(IStatus)
    */
   protected String getStatusHeader(IStatus status)
   {
      if (fEncodingSupport != null) {
         String message = fEncodingSupport.getStatusHeader(status);
         if (message != null)
            return message;
         }
      return super.getStatusHeader(status);
   }

   /*
    * @see StatusTextEditor#getStatusBanner(IStatus)
    */
   protected String getStatusBanner(IStatus status)
   {
      if (fEncodingSupport != null) {
         String message = fEncodingSupport.getStatusBanner(status);
         if (message != null)
            return message;
         }
      return super.getStatusBanner(status);
   }

   /*
    * @see StatusTextEditor#getStatusMessage(IStatus)
    */
   protected String getStatusMessage(IStatus status)
   {
      if (fEncodingSupport != null) {
         String message = fEncodingSupport.getStatusMessage(status);
         if (message != null)
            return message;
         }
      return super.getStatusMessage(status);
   }

   /*
    * @see LpexAbstractTextEditor#doSetInput(IEditorInput)
    */
   protected void doSetInput(IEditorInput input) throws CoreException
   {
      super.doSetInput(input);
      if (fEncodingSupport != null)
         fEncodingSupport.reset();
   }

//*as* TO RESTORE when we have a working encoding support...
// /*
//  * @see IAdaptable#getAdapter(Class)
//  */
// public Object getAdapter(Class adapter)
// {
//    if (IEncodingSupport.class.equals(adapter))
//       return fEncodingSupport;
//    return super.getAdapter(adapter);
// }

//-as- N/A in LPEX
// /*
//  * @see LpexAbstractTextEditor#editorContextMenuAboutToShow(IMenuManager)
//  */
// protected void editorContextMenuAboutToShow(IMenuManager menu) {
//    super.editorContextMenuAboutToShow(menu);
//    addAction(menu, ITextEditorActionConstants.GROUP_EDIT, ITextEditorActionConstants.SHIFT_RIGHT);
//    addAction(menu, ITextEditorActionConstants.GROUP_EDIT, ITextEditorActionConstants.SHIFT_LEFT);
// }
// /*
//  * @see LpexAbstractTextEditor#updatePropertyDependentActions()
//  */
// protected void updatePropertyDependentActions() {
//    super.updatePropertyDependentActions();
//    if (fEncodingSupport != null)
//       fEncodingSupport.reset();
// }
}