//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexTextEditor - a line-oriented (LPEX-based) TextEditor
// (Eclipse R2.0).
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.alef.LpexPlugin;

import java.lang.reflect.InvocationTargetException;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.swt.widgets.Shell;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Plugin;

import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.dialogs.SaveAsDialog;
import org.eclipse.ui.editors.text.ITextEditorHelpContextIds;
import org.eclipse.ui.part.FileEditorInput;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.eclipse.ui.texteditor.AbstractTextEditor;
import org.eclipse.ui.texteditor.DefaultRangeIndicator;


/**
 * A line-oriented, LPEX-based text editor for <code>IFile</code> resources and
 * <code>IStorage</code> objects.
 *
 * <p>The editor's context menu has the id defined in EDITOR_CONTEXT_MENU_ID;
 * its ruler context menu has the id defined in RULER_CONTEXT_MENU_ID.
 *
 * @see LpexAbstractTextEditor
 */
public class LpexTextEditor extends LpexAbstractTextEditor
{
   /**
    * This editor's context menu (popup) id (<code>"#TextEditorContext"</code>).
    */
   public static final String EDITOR_CONTEXT_MENU_ID = "#TextEditorContext";
   /**
    * This editor's ruler context menu (popup) id (<code>"#LpexTextRulerContext"</code>).
    */
   public static final String RULER_CONTEXT_MENU_ID = "#LpexTextRulerContext";


   /**
    * Creates a new text editor.
    */
   public LpexTextEditor()
   {
      super();

      setRangeIndicator(new DefaultRangeIndicator());
      setEditorContextMenuId(EDITOR_CONTEXT_MENU_ID);

      // since Eclipse R2.0 build M5 (20020416):
      // don't use org.eclipse.ui.editors.text.TextEditor's "#TextRulerContext",
      // as then two default Eclipse items "Add bookmark..." and "Add task..."
      // (not good in LPEX) will be added on the ruler menu popup whenever
      // someone extends LpexAbstractTextEditor's rulerContextMenuAboutToShow()
      // in a solution plugin...
      setRulerContextMenuId(RULER_CONTEXT_MENU_ID);

      // added in Eclipse 0.122:
      // set help context to
      //   [PlatformUI.PLUGIN_ID + "."] + "text_editor_context"
      setHelpContextId(ITextEditorHelpContextIds.TEXT_EDITOR);  //*as* must change for LPEX!?

      // added in Eclipse 0.120:  set editor's preference store to be that of
      // the workbench plugin's - this may be OK for TextEditor, as default
      // Eclipse editor, but most probably not for LpexTextEditor?!
      // Plugin plugin = Platform.getPlugin(PlatformUI.PLUGIN_ID);
      // if (plugin instanceof AbstractUIPlugin) {
      //  AbstractUIPlugin uiPlugin = (AbstractUIPlugin)plugin;
      //  setPreferenceStore(uiPlugin.getPreferenceStore());
      //  }
   }

   /**
    * The <code>TextEditor</code> implementation of this
    * <code>IEditorPart</code> method returns <code>true</code>.
    *
    * @see org.eclipse.ui.IEditorPart#isSaveAsAllowed
    */
   public boolean isSaveAsAllowed()
   {
      return true;
   }

   /**
    * The <code>LpexTextEditor</code> implementation of this
    * <code>AbstractTextEditor</code> method prompts the user for the workspace
    * path of a file resource, and saves the document there.
    *
    * @see #performSaveAs(IProgressMonitor,String)
    */
   protected void performSaveAs(IProgressMonitor progressMonitor)
   {
      String fileName = null;

      IEditorInput input = getEditorInput();
      if (input instanceof IFileEditorInput)
         fileName = ((IFileEditorInput)input).getFile().getName();

      performSaveAs(progressMonitor, fileName);
   }

   /**
    * The <code>LpexTextEditor</code> implementation of this
    * <code>AbstractTextEditor</code> method prompts the user for the workspace
    * path of a file resource, and saves the document there.
    *
    * @param fileName initial file name in the dialog
    * @see #performSaveAs(IProgressMonitor)
    */
   protected void performSaveAs(IProgressMonitor progressMonitor, String fileName)
   {
      Shell shell = getSite().getShell();
      SaveAsDialog dialog = new SaveAsDialog(shell);

      // try to get an acceptable initial IFile from the specified fileName...
      if (fileName != null) {
         IResource inputResource = getInputResource();
         // 1.- we have a project that we can use
         if (inputResource != null) {
            IProject project = inputResource.getProject();
            if (project != null)
               dialog.setOriginalFile(project.getFile(fileName));
            }
         // 2.- else, just forget it?!
         }

      dialog.open();
      IPath path = dialog.getResult();

      if (path == null) {
         if (progressMonitor != null)
            progressMonitor.setCanceled(true);
         return;
         }

      IWorkspace workspace = ResourcesPlugin.getWorkspace();
      IFile file = workspace.getRoot().getFile(path);
      final IEditorInput newInput = new FileEditorInput(file);

      WorkspaceModifyOperation op = new WorkspaceModifyOperation() {
         public void execute(final IProgressMonitor monitor) throws CoreException
         {
            getDocumentProvider().
            saveDocument(monitor,  // monitor
                         newInput, // the element
                         getDocumentProvider().getDocument(getEditorInput()), // the IDoc
                         true);    // overwrite?
         }
      };

      boolean success = false;
      try {
         getDocumentProvider().aboutToChange(newInput);

         //-as- must still consider any "visible" parameter of save command!?

         // cf. LpexAbstractTextEditor#performSaveOperation
         // commit any pending changes (clears 'dirty' flag), ensure all's parsed
         LpexView lpexView = getLpexView();
         lpexView.doDefaultCommand("undo check");
         lpexView.doCommand("parse");

         // even though it's a 'save as', clear changes count like Eclipse does...
         lpexView.doDefaultCommand("undo resetChanges");
         lpexView.doGlobalCommand("screenShow");

         new ProgressMonitorDialog(shell).run(false, true, op);
         success = true;
         }
      catch (InterruptedException x) {}
      catch (InvocationTargetException x) {
         String title = LpexPlugin.getResourceLpexString("Error.saveAs.title");
         String msg = LpexPlugin.getResourceLpexString("Error.save.message",
                                                       x.getTargetException().getMessage());
         MessageDialog.openError(shell, title, msg);
         }
      finally {
         getDocumentProvider().changed(newInput);
         if (success)
            setInput(newInput);
         }

      if (progressMonitor != null)
         progressMonitor.setCanceled(!success);
   }
}