//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexSourceViewerConfiguration - LPEX edition of SourceViewerConfiguration.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import com.ibm.lpex.alef.contentassist.IContentAssistant;

import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.SourceViewerConfiguration;


/**
 * This class extends the configuration space defined by
 * SourceViewerConfiguration, with LPEX's content assist
 * for use with an LpexSourceViewer.
 * Instances of this class are passed to the <code>configure</code>
 * method of an LpexSourceViewer <code>ISourceViewer</code>.
 *
 * @see org.eclipse.jface.text.source.SourceViewerConfiguration
 * @see org.eclipse.jface.text.source.ISourceViewer
 */
public class LpexSourceViewerConfiguration extends SourceViewerConfiguration
{
   /**
    * Return a <code>com.ibm.lpex.alef.contentassist.IContentAssistant</code>
    * ready to be used with the given LPEX source viewer.  This implementation
    * returns <code>null</code>.
    *
    * @param sourceViewer the LpexSourceViewer to be configured by this
    *                     configuration
    * @return a content assistant, or
    *         <code>null</code> if content assist should not be supported
    */
   public IContentAssistant getLpexContentAssistant(ISourceViewer sourceViewer)
   {
      return null;
   }
}