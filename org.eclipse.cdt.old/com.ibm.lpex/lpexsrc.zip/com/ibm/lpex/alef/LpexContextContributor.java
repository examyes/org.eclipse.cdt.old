//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexContextContributor - basic LPEX contributor to the Eclipse context.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import java.util.ResourceBundle;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.core.LpexViewAdapter;
import com.ibm.lpex.core.LpexViewListener;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.resource.ImageDescriptor;

import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.texteditor.BasicTextEditorActionContributor;
import org.eclipse.ui.texteditor.TextEditorAction;


/**
 * Basic LPEX contributions to the Eclipse context.
 *
 * <p>Solution plugins using the LPEX plugin must extend this class in order
 * to add their own Eclipse contributions.
 * An LPEX-based editor plugin that has no contributions of its own
 * must still use this class (or a class extending it) as the
 * <code>contributorClass</code> in its plugin.xml (the <code>editor</code>
 * definition of the "org.eclipse.ui.editors" extension point) in order to have
 * the LPEX contributions appear in the workbench.
 *
 * <p>Subclasses may extend the following methods:
 * <ul>
 *   <li><code>contributeToMenu</code> - extend to contribute to menu
 *   <li><code>contributeToToolBar</code> - extend to contribute to toolbar
 *   <li><code>contributeToStatusLine</code> - extend to contribute to status line
 *   <li><code>setActiveEditor</code> - extend to react to editor changes
 * </ul>
 * Any extended method should also call its <code>super.</code> equivalent.
 */
public class LpexContextContributor extends BasicTextEditorActionContributor
{
   private LpexView _activeLpexView;      // our active editor's LpexView
   private LpexEditorAction _firstAction; // list of all the actions
   private static ResourceBundle _bundle = LpexPlugin.getResourceBundle();

   // listener on LPEX display updates, for updating actions' enable state
   // and their accelerators when the profile changes
   private LpexViewListener _lpexViewListener = new LpexViewAdapter() {
      public void shown(LpexView lpexView)
         { updateActions(); }
      public void updateProfile(LpexView lpexView)
         { updateLabels(); }
      public void disposed(LpexView lpexView)
         { _activeLpexView = null; updateLpexView(); }
      };

   // In the current Eclipse drivers, if the user presses a disabled action's
   // accelerator key, neither is its action run(), nor is its key sent as a
   // KeyEvent - therefore even actions on submenus (which we used to enable/
   // disable through a menu listener), such as Alt+L, must be now kept always
   // up-to-date for their accelerators to be active correctly:  we update all
   // actions on every refresh.

   // common toolbar & menu actions
   private LpexEditorAction _compareAction, _startAction, _stopAction, _playAction;


   /**
    * Initialize our common actions, call all the contributeTo...() methods.
    */
   public void init(IActionBars bars)
   {
      // create our common toolbar & menu actions
      _compareAction = new LpexEditorAction(LpexConstants.ACTION_COMPARE, "compare.",
                                            "icons/full/ctool16/compare_co.gif");
      _startAction = new LpexEditorAction(LpexConstants.ACTION_KEY_RECORDER_START, "start.",
                                          "icons/full/ctool16/start_exec.gif");
      _stopAction = new LpexEditorAction(LpexConstants.ACTION_KEY_RECORDER_STOP, "stop.",
                                         "icons/full/ctool16/stop_exec.gif");
      _playAction = new LpexEditorAction(LpexConstants.ACTION_KEY_RECORDER_PLAY, "play.",
                                         "icons/full/ctool16/play_exec.gif");

      // ensure super does the calls
      super.init(bars);
   }

   /**
    * Add the menus portion of this contribution.
    *
    * @param menu the manager that controls the menu
    */
   public void contributeToMenu(IMenuManager menu)
   {
      MenuManager mm;

      // 1.- contribute to "File"
      IMenuManager m = menu.findMenuUsingPath(IWorkbenchActionConstants.M_FILE);
      if (m != null) {
         try {
            m.insertAfter(IWorkbenchActionConstants.IMPORT_EXT,
              new LpexEditorAction(LpexConstants.ACTION_GET, "get."));
            m.insertAfter(IWorkbenchActionConstants.IMPORT_EXT, new Separator());
            }
         catch (IllegalArgumentException e) {}
         }

      // 2.- contribute to "Edit"
      m = menu.findMenuUsingPath(IWorkbenchActionConstants.M_EDIT);
      if (m != null) {
         try {
            m.insertAfter(IWorkbenchActionConstants.FIND,
              new LpexEditorAction(LpexConstants.ACTION_SHOW_ALL, "showAll."));
            m.insertAfter(IWorkbenchActionConstants.FIND,
              new LpexEditorAction(LpexConstants.ACTION_FILTER_SELECTION, "filterSelection."));

            // "Find Other =>"
            mm = new MenuManager(LpexPlugin.getResourceString("findOtherMenu"), "lpex_findOther");
            mm.add(new LpexEditorAction(LpexConstants.ACTION_FIND_SELECTION, "findSelection."));
            mm.add(new LpexEditorAction(LpexConstants.ACTION_FIND_BLOCK_START, "findBlockStart."));
            mm.add(new LpexEditorAction(LpexConstants.ACTION_FIND_BLOCK_END, "findBlockEnd."));
            mm.add(new LpexEditorAction(LpexConstants.ACTION_FIND_LAST_CHANGE, "findLastChange."));
            mm.add(new LpexEditorAction(LpexConstants.ACTION_FIND_QUICK_MARK, "findQuickMark."));
            mm.add(new LpexEditorAction(LpexConstants.ACTION_FIND_MARK, "findMark."));
            m.insertAfter(IWorkbenchActionConstants.FIND, mm);

            m.insertAfter(IWorkbenchActionConstants.FIND,
              new LpexEditorAction(LpexConstants.ACTION_FIND_UP, "findUp."));
            m.insertAfter(IWorkbenchActionConstants.FIND,
              new LpexEditorAction(LpexConstants.ACTION_FIND_NEXT, "findNext."));
            }
         catch (IllegalArgumentException e) {}

         m.add(new Separator());

         // "Select =>"
         mm = new MenuManager(LpexPlugin.getResourceString("selectMenu"), "lpex_select");
         mm.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_MARK_ELEMENT, "blockMarkElement."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_MARK_CHARACTER, "blockMarkCharacter."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_MARK_RECTANGLE, "blockMarkRectangle."));
         m.add(mm);

         // "Selected =>"
         mm = new MenuManager(LpexPlugin.getResourceString("selectedMenu"), "lpex_selected");
         mm.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_COPY, "blockCopy."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_OVERLAY, "blockOverlay."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_MOVE, "blockMove."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_DELETE, "blockDelete."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_UPPER_CASE, "blockUpperCase."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_LOWER_CASE, "blockLowerCase."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_SHIFT_LEFT, "blockShiftLeft."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_SHIFT_RIGHT, "blockShiftRight."));
         m.add(mm); //menu.insertAfter(IWorkbenchActionConstants.M_EDIT,mm); == as top-level menu

         m.add(new LpexEditorAction(LpexConstants.ACTION_BLOCK_UNMARK, "blockUnmark."));

         m.add(new Separator());

         // "Mark =>"
         mm = new MenuManager(LpexPlugin.getResourceString("markMenu"), "lpex_mark");
         mm.add(new LpexEditorAction(LpexConstants.ACTION_SET_QUICK_MARK, "setQuickMark."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_NAME_MARK, "nameMark."));
         m.add(mm);

         //*as* Hex edit line...

         // "Compare =>"
         mm = new MenuManager(LpexPlugin.getResourceString("compareMenu"), "lpex_compare");
         mm.add(_compareAction);
         mm.add(new LpexEditorAction(LpexConstants.ACTION_COMPARE_NEXT, "compareNext."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_COMPARE_PREVIOUS, "comparePrevious."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_COMPARE_REFRESH, "compareRefresh."));
         mm.add(new LpexEditorAction(LpexConstants.ACTION_COMPARE_CLEAR, "compareClear."));
         m.add(mm);

         // "Keystroke Recorder =>"
         mm = new MenuManager(LpexPlugin.getResourceString("recorderMenu"), "lpex-recorder");
         mm.add(_startAction);
         mm.add(_stopAction);
         mm.add(_playAction);
         m.add(mm);
         }
   }

   /**
    * Add the tool bar portion of this contribution.
    *
    * @param tbm the manager that controls the workbench tool bar
    */
   public void contributeToToolBar(IToolBarManager tbm)
   {
      tbm.add(new Separator("lpex"));
      tbm.add(new LpexEditorAction(LpexConstants.ACTION_UNDO, "undo.",
                                   "icons/full/ctool16/undo_edit.gif"));
      tbm.add(new LpexEditorAction(LpexConstants.ACTION_REDO, "redo.",
                                   "icons/full/ctool16/redo_edit.gif"));
      tbm.add(new Separator());
      tbm.add(_startAction);
      tbm.add(_stopAction);
      tbm.add(_playAction);
      tbm.add(new Separator());
      tbm.add(_compareAction);
   }

   /**
    * Set the active editor for the contributor.  This method disconnects from
    * the old editor, connects to the new editor, and updates the actions to
    * reflect the new editor.
    *
    * @param targetEditor the new editor target
    *
    * @see org.eclipse.ui.IEditorActionBarContributor#setActiveEditor
    */
   public void setActiveEditor(IEditorPart targetEditor)
   {
      // install the global action handler for the active text editor
      super.setActiveEditor(targetEditor);

      // remove view listener from previous LPEX view, add it to the new one
      if (_activeLpexView != null)
         _activeLpexView.removeLpexViewListener(_lpexViewListener);

      _activeLpexView = null;
      if (targetEditor instanceof LpexAbstractTextEditor) {
         _activeLpexView = ((LpexAbstractTextEditor)targetEditor).getLpexView();
         _activeLpexView.addLpexViewListener(_lpexViewListener);
         }

      // our LpexEditorActions perform directly in LPEX, so there is no need to
      // retarget their editor [setEditor()], just update their active LpexView
      updateLpexView();
      // ensure accelerator keys up-to-date for the current edit view
      updateLabels();
      // update actions' enable/disable state
      updateActions();
   }

   /**
    * Update the target LpexView of the context actions.
    */
   private void updateLpexView()
   {
      for (LpexEditorAction action = _firstAction; action != null; action = action.next())
         action.setLpexView(_activeLpexView);
   }

   /**
    * Update the accelerators of the actions.
    */
   private void updateLabels()
   {
      for (LpexEditorAction action = _firstAction; action != null; action = action.next())
         action.updateLabel();
   }

   /**
    * Update the enable/disable state of the actions.
    */
   private void updateActions()
   {
      for (LpexEditorAction action = _firstAction; action != null; action = action.next())
         action.update();
   }


   /**
    * An LPEX-oriented text-editor action we can manipulate comfortably for
    * our contributions to the workbench context.  The enable/disable state
    * is updated by a call to update() on each LPEX screen's display refresh.
    */
   private final class LpexEditorAction extends TextEditorAction
   {
      private LpexEditorAction _next;
      private int fOperationCode = -1;
      private LpexView _lpexView;

      /**
       * Create an LPEX action and link it in our list.
       *
       * @param id LPEX action id (=> TextEditorAction.fOperationCode)
       * @param prefix prefix in LPEX plugin's resource bundle for this action's keys
       * @param icon icon file for the image (on the toolbar)
       */
      public LpexEditorAction(int id, String prefix, String icon)
      {
         // create action
         super(_bundle, prefix, null);
         fOperationCode = id;

         if (icon != null)
            setImageDescriptor(ImageDescriptor.createFromFile(LpexPlugin.class, icon));

         // link action into our list
         _next = _firstAction;
         _firstAction = this;
      }

      /**
       * Create an LPEX action and link it in our list.
       *
       * @param id LPEX action id (=> TextEditorAction.fOperationCode)
       * @param prefix prefix in LPEX plugin's resource bundle for this action's keys
       */
      public LpexEditorAction(int id, String prefix)
      {
         this(id, prefix, null);
      }

      LpexEditorAction next()
      {
         return _next;
      }

      void setLpexView(LpexView lpexView)
      {
         _lpexView = lpexView;
      }

      /**
       * Update action's accelerator key.
       * The Workbench does its own key-action bindings based on this, but it
       * shouldn't interfere with LPEX's key-action bindings!?
       */
      void updateLabel()
      {
         //*as* must call whenever an action's primary key changes!...

         if (_lpexView != null) {
            String text = this.removeAcceleratorText(getText());
            //*as* actionKeyText() returns *NLS-translated* accelerator string:
            //     bad if we want this key to become Eclipse-handled accelerator!
            String accelerator = _lpexView.actionKeyText(fOperationCode);
            if (accelerator != null)
               setText(text + '\t' + accelerator);
            else
               setText(text);
            }
      }

      /**
       * Update the enable/disable state of the action.
       */
      public void update()
      {
         // simplify what TextEditorAction does by shortcutting to LPEX;
         // Action.setEnabled(isEnabled) also fires a property change;
         // NB this prevents the user from changing the operation target
         // and/or overriding canDoOperation() for this action - user must
         // redefine the LPEX action instead!
         setEnabled(_lpexView != null &&
                    _lpexView.actionAvailable(fOperationCode));
      }

      /**
       * Action selected, run it.
       */
      public void run()
      {
         // simplify what TextEditorAction does by shortcutting to LPEX;
         // this way we don't have to re-setEditor() (operation's target
         // editor) in editorChanged() either;
         // NB this prevents the user from changing the operation target
         // and/or overriding doOperation() for this action - user must
         // redefine the LPEX action instead!
         if (_lpexView != null)
            _lpexView.triggerAction(fOperationCode);
      }
   }
}