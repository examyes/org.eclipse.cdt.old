//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexSourceViewer - line-oriented (LPEX-based) SourceViewer.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.core.LpexWindow;

import com.ibm.lpex.alef.preferences.ViewBasePreferencePage;
import com.ibm.lpex.alef.preferences.ViewParserPreferencePage;
import com.ibm.lpex.alef.preferences.SequenceNumbersPreferencePage;
import com.ibm.lpex.alef.preferences.SourceEncodingPreferencePage;

// cannot extend org.eclipse.jface.text.contentassist.IContentAssistant...
import com.ibm.lpex.alef.contentassist.IContentAssistant;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Layout;

import org.eclipse.jface.preference.IPreferenceNode;
import org.eclipse.jface.preference.IPreferencePage;
import org.eclipse.jface.preference.PreferenceManager;
import org.eclipse.jface.preference.PreferenceNode;

//import org.eclipse.jface.resource.ImageDescriptor;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.TextViewer;

import org.eclipse.jface.text.formatter.IContentFormatter;
import org.eclipse.jface.text.presentation.IPresentationReconciler;
import org.eclipse.jface.text.reconciler.IReconciler;

import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.IVerticalRuler;
import org.eclipse.jface.text.source.SourceViewerConfiguration;

//*as* currently using local copy....................
//import org.eclipse.jface.text.source.VisualAnnotationModel;

//*as* must be made public...........................
//import org.eclipse.jface.text.source.VerticalRulerHoveringController;

import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.texteditor.ITextEditor;

import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Plugin;


/**
 * A line-oriented, LPEX-based <b>partial</b> implementation of
 * <code>org.eclipse.jface.text.source.ISourceViewer</code>.
 *
 * A source viewer uses an <code>IVerticalRuler</code> as its annotation
 * presentation area.  The vertical ruler is a small strip shown left of the
 * viewer's text widget.
 *
 * <p>Clients should not subclass this class, as it is quite likely
 * that subclasses will be broken by future releases.
 *
 * <p>One major difference from SourceViewer, this viewer's stream-oriented
 * IDocument is <b>not</b> kept up-to-date with the text changes in the
 * underlying LPEX text widget.
 *
 * <p>Several SourceViewer classes, methods, and fields are not available in
 * LpexSourceViewer.  Most programming of the underlying LPEX widget should be
 * done directly via its LpexView and LpexWindow.
 * <ul>
 * <li>public void configure() <br>
 *     -- refer to this {@link #configure method's} documentation
 *
 * <li>public void setDocument(document, visibleRegionOffset, visibleRegionLength),
 *     public void setDocument(document, annotationModel,
 *                             visibleRegionOffset, visibleRegionLength) <br>
 *     -- in LpexSourceViewer, the visible document is always the viewer's (entire)
 *     input document.  To display only one or more certain region(s) of the
 *     document in the viewer, set marks for these regions, and set their
 *     included or excluded attribute.  See the <b>mark</b>, <b>markIncluded</b>,
 *     and <b>markExcluded</b> parameters.
 * </ul>
 *
 * @see LpexTextViewer
 */
public class LpexSourceViewer extends LpexTextViewer implements ISourceViewer
{
   /**
    * Layout of a source viewer.
    * The vertical ruler and the text widget are shown side by side.
    */
   class RulerLayout extends Layout
   {
      protected int fGap;

      protected RulerLayout(int gap)
      {
         fGap = gap;
      }

      protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache)
      {
         Control[] children = composite.getChildren();
         Point s = children[children.length - 1].computeSize(SWT.DEFAULT, SWT.DEFAULT, flushCache);
         if (fVerticalRuler != null && fIsVerticalRulerVisible)
            s.x += fVerticalRuler.getWidth() + fGap;
         return s;
      }

      protected void layout(Composite composite, boolean flushCache)
      {
         Rectangle clientArea = composite.getClientArea();
         if (fVerticalRuler != null && fIsVerticalRulerVisible) {
            Rectangle trim = getLpexWindow().computeTrim(0, 0, 0, 0);
            int scrollbarHeight = trim.height;

            int rulerWidth = fVerticalRuler.getWidth();
            fVerticalRuler.getControl().setBounds(0, 0,
                                      rulerWidth, clientArea.height - scrollbarHeight);
            getLpexWindow().setBounds(rulerWidth + fGap, 0,
                                      clientArea.width - rulerWidth - fGap, clientArea.height);
            }
         else
            getLpexWindow().setBounds(0, 0, clientArea.width, clientArea.height);
      }
   };


   /** The viewer's content assistant. */
   protected IContentAssistant fContentAssistant;
   /** The viewer's content formatter. */
   protected IContentFormatter fContentFormatter;
   /** The viewer's model reconciler. */
   protected IReconciler fReconciler;
   /** The viewer's presentation reconciler. */
   protected IPresentationReconciler fPresentationReconciler;
   /** The viewer's annotation hover. */
   protected IAnnotationHover fAnnotationHover;

   /** Visual vertical ruler. */
   private IVerticalRuler fVerticalRuler;
   /** Visibility of the vertical ruler. */
   private boolean fIsVerticalRulerVisible;
   /** The parent Composite used when supporting a vertical ruler. */
   private Composite fComposite;
   /** The vertical ruler's annotation model. */
   private VisualAnnotationModel fVisualAnnotationModel;
   /** The viewer's range indicator to be shown in the vertical ruler. */
   private Annotation fRangeIndicator;
// /** The viewer's vertical ruler hovering controller. */
// private VerticalRulerHoveringController fVerticalRulerHoveringController;
   /** The size of the gap between the vertical ruler and the text widget. */
   protected final static int GAP_SIZE = 0;

   // the ITextEditor (LpexAbstractTextEditor) instantiating us
   private ITextEditor _textEditor;

   // LPEX base preference page id
   private static final String LPEX_BASE_PREFERENCE_PAGE =
      "com.ibm.lpex.alef.preferences.LpexBasePreferencePage";
   // the preference manager node with the base page for our LPEX view
   private LpexPreferenceNode _viewBasePreferenceNode;
   // the preference manager node with the parser child page for our LPEX view
   private LpexPreferenceNode _viewParserPreferenceNode;
   //  & node with the seq.-nums. child page
   private LpexPreferenceNode _viewSequenceNumbersPreferenceNode;
   //  & node with the source-encoding child page
   private LpexPreferenceNode _viewSourceEncodingPreferenceNode;


   /**
    * Constructs a new LPEX source viewer.
    * The vertical ruler is initially visible.  The viewer has not yet been
    * initialized with a source viewer configuration.
    *
    * @param parent the parent of the viewer's control
    * @param textEditor the LpexAbstractTextEditor instantiating this source viewer
    * @param ruler the vertical ruler used by this source viewer
    * @patam styles the SWT style bits
    */
   public LpexSourceViewer(Composite parent,
                           ITextEditor textEditor, // LPEX - know thy text editor!
                           IVerticalRuler ruler,
                           int styles)
   {
      super();

      // keep _textEditor in order to call LpexAbstractTextEditor's
      // initializeLpexView() and updateProfile(), and determine _classLoader
      // for the LPEX plugin to be able to load classes (such as parser classes)
      // defined in the using LPEX-based solution plugin
      _textEditor = textEditor;
      if (_textEditor != null) {
         Plugin plugin = Platform.getPlugin(_textEditor.getEditorSite().getPluginId());
         if (plugin != null)
            _classLoader = plugin.getDescriptor().getPluginClassLoader();
         }

      fIsVerticalRulerVisible = true;
      fVerticalRuler = ruler;

      createControl(parent, styles);
   }

   /**
    * @see LpexTextViewer#createControl
    */
   protected void createControl(Composite parent, int styles)
   {
      if (fVerticalRuler != null) {
         styles= (styles & ~SWT.BORDER);
         fComposite= new Canvas(parent, SWT.NONE);
         fComposite.setLayout(new RulerLayout(GAP_SIZE));
         parent = fComposite;
         }

      super.createControl(parent, styles);

      if (fComposite != null)
         fVerticalRuler.createControl(fComposite, this);
   }

   /**
    * @see org.eclipse.jface.text.source.ISourceViewer#setAnnotationHover
    */
   public void setAnnotationHover(IAnnotationHover annotationHover)
   {
      fAnnotationHover = annotationHover;
   }

   /**
    * Configure the source viewer as described in the configuration.
    *
    * <p>You should use an LpexSourceViewerConfiguration-based class to
    * configure an LpexSourceViewer.
    *
    * <p>LpexSourceViewer does not use/implement certain
    * (Lpex)SourceViewerConfiguration features.
    * <ul>
    * <li>configuration.getAutoIndentStrategy() <br>
    *     -- an LPEX language parser handles its own autoindent strategy
    * <li>configuration.getContentAssist() <br>
    *     -- using configuration.getLpexContentAssist() instead (defined in
    *     LpexSourceViewerConfiguration)
    * <li>configuration.getDoubleClickStrategy() <br>
    *     -- LPEX has its own double-click actions.  Token/word selection and
    *     bracket matching can be customized via new LpexActions
    * <li>configuration.getTabWidth() <br>
    *     -- LPEX tab positions for the <b>nextTabStop</b> and <b>prevTabStop</b>
    *     actions are configured through the <b>tabs</b> parameter
    * <li>configuration.getUndoManager() <br>
    *     -- LPEX uses its own built-in undo manager (with unlimited undo/redo
    *     capabilitites).
    * </ul>
    *
    * @param configuration an LpexSourceViewerConfiguration
    *
    * @see com.ibm.lpex.alef.LpexSourceViewerConfiguration
    * @see org.eclipse.jface.text.source.ISourceViewer#configure
    * @see com.ibm.lpex.core.LpexCommonParser
    */
   public void configure(SourceViewerConfiguration configuration)
   {
      if (getLpexView() == null)
         return;

      // install content type independent plugins
      fPresentationReconciler = configuration.getPresentationReconciler(this);
      if (fPresentationReconciler != null)
         fPresentationReconciler.install(this);

      fReconciler = configuration.getReconciler(this);
      if (fReconciler != null)
         fReconciler.install(this);

      //fContentAssistant = configuration.getContentAssistant(this);
      if (configuration instanceof LpexSourceViewerConfiguration)
         fContentAssistant = ((LpexSourceViewerConfiguration)configuration).getLpexContentAssistant(this);
      if (fContentAssistant != null)
         fContentAssistant.install(this);

      fContentFormatter = configuration.getContentFormatter(this);

      // LPEX has its own undo/redo...
      //setUndoManager(configuration.getUndoManager(this));
      // leave default LPEX tabs stops as they are...
      //getLpexView().doDefaultCommand("set tabs every "+ configuration.getTabWidth(this));

      setAnnotationHover(configuration.getAnnotationHover(this));

      // install content-type specific plugins
      String[] types = configuration.getConfiguredContentTypes(this);
      for (int i = 0; i < types.length; i++) {
         String t = types[i];

         // LPEX handles its autoindent strategy in the particular parsers...
         //setAutoIndentStrategy(configuration.getAutoIndentStrategy(this, t), t);
         // LPEX has its own double-click & bracket-matching actions...
         //setTextDoubleClickStrategy(configuration.getDoubleClickStrategy(this, t), t);

         setTextHover(configuration.getTextHover(this, t), t);

         String[] prefixes = configuration.getIndentPrefixes(this, t);
         if (prefixes != null && prefixes.length > 0)
            setIndentPrefixes(prefixes, t);

         String prefix = configuration.getDefaultPrefix(this, t);
         if (prefix != null && prefix.length() > 0)
            setDefaultPrefix(prefix, t);
         }

      activatePlugins();
   }

   /**
    * @see LpexTextViewer#activatePlugins
    */
   public void activatePlugins()
   {
//    if (fVerticalRuler != null &&
//        fAnnotationHover != null &&
//        fVerticalRulerHoveringController == null) {
//       fVerticalRulerHoveringController =
//          new VerticalRulerHoveringController(this, fVerticalRuler, fAnnotationHover);
//       fVerticalRulerHoveringController.install();
//       }

      super.activatePlugins();
   }

   /**
    * Set the viewer's IDocument.
    */
   public void setDocument(IDocument document)
   {
      setDocument(document, null, -1, -1);
   }

   /**
    * This method just sets the viewer's IDocument.
    *
    * <p>In LpexSourceViewer, the visible document is always the viewer's (entire)
    * input document.  To display only certain region(s) of the document in the
    * viewer, set marks for these regions, and set their included or excluded
    * attribute.  See the <b>mark</b>, <b>markIncluded</b>, and
    * <b>markExcluded</b> parameters.
    *
    * <p>In SourceViewer, this method sets the viewer's document and the visible
    * region.
    */
   public void setDocument(IDocument document, int visibleRegionOffset, int visibleRegionLength)
   {
      setDocument(document, null,
                  visibleRegionOffset, visibleRegionLength); // both are ignored
   }

   /**
    * Sets the given document as this viewer's text model and the
    * given annotation model as the model for this viewer's visual
    * annotations.  The presentation is accordingly updated.  An appropriate
    * <code>TextEvent</code> is issued. This text event does not carry
    * a related document event.
    *
    * @param document the viewer's new input document
    * @param annotationModel the model for the viewer's visual annotations
    *
    * @see org.eclipse.jface.text.source.ISourceViewer#setDocument(IDocument, IAnnotationModel)
    */
   public void setDocument(IDocument document, IAnnotationModel annotationModel)
   {
      setDocument(document, annotationModel, -1, -1);
   }

   /**
    * Sets the given document as this viewer's text model and the
    * given annotation model as the model for this viewer's visual
    * annotations.
    * In LpexSourceViewer, the visible document is always the viewer's (entire)
    * input document.  To display only certain region(s) of the document in the
    * viewer, set marks for these regions, and set their included or excluded
    * attribute.  See the <b>mark</b>, <b>markIncluded</b>, and
    * <b>markExcluded</b> parameters.
    *
    * <p>In SourceViewer, the presentation is also updated, whereby
    * only the specified region is made visible.
    * In SourceViewer, this is a convenience method for <pre>
    *   setDocument(document, annotationModel);
    *   setVisibleRegion(offset, length) </pre>
    *
    * @param document the new input document
    * @param annotationModel the model of the viewer's visual annotations
    *
    * @see org.eclipse.jface.text.source.ISourceViewer#setDocument(IDocument,IAnnotationModel,int,int)
    */
   public void setDocument(IDocument document, IAnnotationModel annotationModel,
                           int visibleRegionOffset, int visibleRegionLength) // both ignored
   {
      if (fVerticalRuler == null) {
         if (visibleRegionOffset == -1 && visibleRegionLength == -1)
            super.setDocument(document);
         else
            super.setDocument(document, visibleRegionOffset, visibleRegionLength);
         }

      else {
         if (fVisualAnnotationModel != null && getDocument() != null)
            fVisualAnnotationModel.disconnect(getDocument());

         if (visibleRegionOffset == -1 && visibleRegionLength == -1)
            super.setDocument(document);
         else
            super.setDocument(document, visibleRegionOffset, visibleRegionLength);

         if (annotationModel != null && document != null) {
            fVisualAnnotationModel = new VisualAnnotationModel(annotationModel);
            fVisualAnnotationModel.connect(document);
            }
         else {
            fVisualAnnotationModel = null;
            }

         fVerticalRuler.setModel(fVisualAnnotationModel);
         }
   }

   /**
    * Return this viewer's annotation model.
    *
    * @see org.eclipse.jface.text.source.ISourceViewer#getAnnotationModel
    */
   public IAnnotationModel getAnnotationModel()
   {
      return (fVisualAnnotationModel != null)?
         fVisualAnnotationModel.getModelAnnotationModel() : null;
   }

   /**
    * Free all resources allocated by this viewer.
    * Extends LpexTextViewer's.
    *
    * @see LpexTextViewer#handleDispose
    */
   protected void handleDispose()
   {
      if (fPresentationReconciler != null) {
         fPresentationReconciler.uninstall();
         fPresentationReconciler = null;
         }

      if (fReconciler != null) {
         fReconciler.uninstall();
         fReconciler = null;
         }

      if (fContentAssistant != null) {
         fContentAssistant.uninstall();
         fContentAssistant = null;
         }

      fContentFormatter = null;

      if (fVisualAnnotationModel != null && getDocument() != null) {
         fVisualAnnotationModel.disconnect(getDocument());
         fVisualAnnotationModel = null;
         }

      fVerticalRuler = null;

//    if (fVerticalRulerHoveringController != null) {
//       fVerticalRulerHoveringController.dispose();
//       fVerticalRulerHoveringController= null;
//       }

      // dispose of our LPEX view preference pages
      disposePreferencePage();

      // LpexTextViewer's dispose
      super.handleDispose();
   }

   /**
    * @see org.eclipse.jface.text.ITextOperationTarget#canDoOperation
    */
   public boolean canDoOperation(int operation)
   {
      if (getLpexView() == null)
         return false;

      if (operation == CONTENTASSIST_PROPOSALS ||
          operation == CONTENTASSIST_CONTEXT_INFORMATION)
         return fContentAssistant != null;

      //if (operation == FORMAT) {
      // Point p = getSelectedRange();
      // int length = (p == null ? -1 : p.y);
      // return (fContentFormatter != null && (length == 0 || isBlockSelected()));
      // }

      return super.canDoOperation(operation);
   }

   /**
    * @see org.eclipse.jface.text.ITextOperationTarget#doOperation
    */
   public void doOperation(int operation)
   {
      LpexView lpexView = getLpexView();
      if (lpexView == null)
         return;

      switch (operation) {
         case CONTENTASSIST_PROPOSALS:
            showAll(lpexView);
            fContentAssistant.showPossibleCompletions();
            return;
         case CONTENTASSIST_CONTEXT_INFORMATION:
            //showAll(lpexView); ?? needed here ??
            fContentAssistant.showContextInformation();
            return;
         //case FORMAT: {
         // Point s = getSelectedRange();
         // IRegion r = (s.y == 0 ? getVisibleRegion() : new Region(s.x, s.y));
         // fContentFormatter.format(getDocument(), r);
         // return;
         // }

         default:
            super.doOperation(operation);
         }
   }

   // Called by doOperation() for the CONTENTASSIST actions:
   // if a parser-filtered view (e.g., Java method headers via Ctrl+G -
   // but not a find-all screen), show all before letting the user to
   // do any editing of the candidate word during the content assist
   // (which may create unwanted, or at least unexpected, behaviour)
   private static void showAll(LpexView lpexView)
   {
      if (lpexView.query("includedClasses").length() != 0) {
         lpexView.doCommand("set includedClasses");
         lpexView.doDefaultCommand("screenShow");
         }
   }

   /**
    * Set the annotation used as range indicator for the viewer's vertical
    * ruler.
    *
    * @see org.eclipse.jface.text.source.ISourceViewer#setRangeIndicator
    */
   public void setRangeIndicator(Annotation rangeIndicator)
   {
      fRangeIndicator = rangeIndicator;
   }

   /**
    * Set the viewers's range indication to the specified range.
    *
    * @see org.eclipse.jface.text.source.ISourceViewer#setRangeIndication
    */
   public void setRangeIndication(int start, int len, boolean moveCursor)
   {
      if (moveCursor) {
         setSelectedRange(start, 0);
         revealRange(start, len);
         }

      if (fRangeIndicator != null && fVisualAnnotationModel != null)
         fVisualAnnotationModel.modifyAnnotation(fRangeIndicator, new Position(start, len));
   }

   /**
    * @see LpexTextViewer#getControl
    */
   public Control getControl()
   {
      if (fComposite != null)
         return fComposite;
      return super.getControl();
   }

   /**
    * @see org.eclipse.jface.text.source.ISourceViewer#getRangeIndication
    */
   public IRegion getRangeIndication()
   {
      if (fRangeIndicator != null && fVisualAnnotationModel != null) {
         Position position= fVisualAnnotationModel.getPosition(fRangeIndicator);
         if (position != null)
            return new Region(position.getOffset(), position.getLength());
         }

      return null;
   }

   /**
    * Remove the viewer's range indication.
    *
    * @see org.eclipse.jface.text.source.ISourceViewer#removeRangeIndication
    */
   public void removeRangeIndication()
   {
      if (fRangeIndicator != null && fVisualAnnotationModel != null)
         fVisualAnnotationModel.modifyAnnotation(fRangeIndicator, null);
   }

   /**
    * Control the visibility of annotations and, in the case of separate
    * presentation areas of text and annotations, the visibility of the
    * annotation's presentation area.
    *
    * @see org.eclipse.jface.text.source.ISourceViewer#showAnnotations
    */
   public void showAnnotations(boolean show)
   {
      boolean old = fIsVerticalRulerVisible;
      fIsVerticalRulerVisible = show;
      if (old != fIsVerticalRulerVisible)
         fComposite.layout();
   }

   /**
    * Hook to initialize a newly instantiated LpexView during the construction
    * of this SourceViewer.
    *
    * <p>Extend this method to set any file/view-specific parameters for this
    * LpexView.  Ensure you also call super.initializeLpexView(lpexView).
    *
    * <p>Here you may set any "File Open" preferences page settings for your
    * solution's plugin, such as <b>sequenceNumbers</b>, <b>sourceEncoding</b>,
    * <b>save.textLimit</b>, and <b>save.trim</b>.  The <b>updateProfile</b>
    * command will be called later.
    */
   protected void initializeLpexView(LpexView lpexView)
   {
      if (_textEditor != null)
         ((LpexAbstractTextEditor)_textEditor).initializeLpexView(lpexView);
   }

   /**
    * Hook for post-<b>updateProfile</b> command processing.
    * Extend this method to define your own LPEX actions (and assign them
    * to keys), and your own LPEX commands.  Ensure you also call
    * super.updateProfile().
    *
    * <p>Called when a new LpexTextViewer is created (an LPEX document is
    * opened), and whenever the <b>updateProfile</b> command is issued
    * afterwards.
    */
   protected void updateProfile()
   {
      super.updateProfile();

      if (_textEditor != null)
         ((LpexAbstractTextEditor)_textEditor).updateProfile();
   }


   /*===========================================*/
   /*  View-scoped preference-pages management  */
   /*===========================================*/

   /**
    * Ensure up-to-date preference pages for our LPEX view.
    * Called by LpexAbstractTextEditor.initializeSourceViewer() - when
    * the part control is created, and when the editor input changes.
    */
   void updatePreferencePage()
   {
      // BTW NOTE - to identify the using plugin (if we want to add the view
      // preference page to one of the using plugin's preference pages, instead
      // of LPEX's own base preference page), can use something like this:
      //   AbstractTextEditor/EditorPart.getEditorSite().getPluginId();
      // equivalent to:
      //   <plugin>.getDescriptor().getUniqueIdentifier();
      // returning e.g., "com.ibm.lpex.examples.lpexeditor".

      PreferenceManager preferenceManager = PlatformUI.getWorkbench().getPreferenceManager();
      IPreferenceNode lpexBaseNode = preferenceManager.find(LPEX_BASE_PREFERENCE_PAGE);
      if (lpexBaseNode != null) {
         // 1.- remove old nodes
         if (_viewBasePreferenceNode != null) {
            if (_viewParserPreferenceNode != null) {                 // remove children nodes
               _viewBasePreferenceNode.remove(_viewParserPreferenceNode);
               _viewParserPreferenceNode.disposeResources();
               }
            if (_viewSequenceNumbersPreferenceNode != null) {
               _viewBasePreferenceNode.remove(_viewSequenceNumbersPreferenceNode);
               _viewSequenceNumbersPreferenceNode.disposeResources();
               }
            if (_viewSourceEncodingPreferenceNode != null) {
               _viewBasePreferenceNode.remove(_viewSourceEncodingPreferenceNode);
               _viewSourceEncodingPreferenceNode.disposeResources();
               }
            lpexBaseNode.remove(_viewBasePreferenceNode);            // remove base node
            _viewBasePreferenceNode.disposeResources();
            }

         // 2.- add updated nodes
         LpexView lpexView = getLpexView();
         _viewBasePreferenceNode = new LpexPreferenceNode(lpexView);
         _viewParserPreferenceNode =
            new LpexPreferenceNode(lpexView, LpexPreferenceNode.VIEW_PARSER_NODE);
         _viewSequenceNumbersPreferenceNode =
            new LpexPreferenceNode(lpexView, LpexPreferenceNode.VIEW_SEQUENCE_NUMBERS_NODE);
         _viewSourceEncodingPreferenceNode =
            new LpexPreferenceNode(lpexView, LpexPreferenceNode.VIEW_SOURCE_ENCODING_NODE);
         lpexBaseNode.add(_viewBasePreferenceNode);
         _viewBasePreferenceNode.add(_viewParserPreferenceNode);
         _viewBasePreferenceNode.add(_viewSequenceNumbersPreferenceNode);
         _viewBasePreferenceNode.add(_viewSourceEncodingPreferenceNode);
         }
   }


   /**
    * Called from handleDispose() to dispose of our view preference page(s).
    */
   private void disposePreferencePage()
   {
      if (_viewBasePreferenceNode != null) {
         // 1.- remove children nodes
         if (_viewParserPreferenceNode != null)
            _viewBasePreferenceNode.remove(_viewParserPreferenceNode);
         if (_viewSequenceNumbersPreferenceNode != null)
            _viewBasePreferenceNode.remove(_viewSequenceNumbersPreferenceNode);
         if (_viewSourceEncodingPreferenceNode != null)
            _viewBasePreferenceNode.remove(_viewSourceEncodingPreferenceNode);

         // 2.- remove base node
         IPreferenceNode lpexBaseNode = PlatformUI.getWorkbench().getPreferenceManager()
                                                  .find(LPEX_BASE_PREFERENCE_PAGE);
         if (lpexBaseNode != null)
            lpexBaseNode.remove(_viewBasePreferenceNode);

         // 3.- dispose nodes' resources
         _viewParserPreferenceNode.disposeResources();
         _viewSequenceNumbersPreferenceNode.disposeResources();
         _viewSourceEncodingPreferenceNode.disposeResources();
         _viewBasePreferenceNode.disposeResources();

         _viewParserPreferenceNode = null;
         _viewSequenceNumbersPreferenceNode = null;
         _viewSourceEncodingPreferenceNode = null;
         _viewBasePreferenceNode = null;
         }
   }

   /**
    * PreferenceNode for the LPEX view preference page(s).
    */
   static class LpexPreferenceNode extends PreferenceNode
   {
      private static int _nodeId;      // a running id for these nodes

      static final int                 // node type
         VIEW_BASE_NODE             = 0,
         VIEW_PARSER_NODE           = 1,
         VIEW_SEQUENCE_NUMBERS_NODE = 2,
         VIEW_SOURCE_ENCODING_NODE  = 3;
      private int _nodeType;

      private LpexView _lpexView;      // LpexView associated with the node


      /**
       * Constructor for the LPEX view base preference page node.
       * @see #LpexPreferenceNode(LpexView,int)
       */
      public LpexPreferenceNode(LpexView lpexView)
      {
         super("LPEX" + _nodeId++);

         // //*as* in order to display an image for the view preference item, must use
         // // the 'complete' constructor - because there is no way to setImageDescriptor()...
         // // Don't do it right now, *all* "Preferences" tree item texts will have gaps!!
         // super("LPEX" + _nodeId++,
         //  lpexView.query("name"),
         //  ImageDescriptor.createFromFile(LpexPlugin.class, "icons/full/obj16/editor_obj.gif"),
         //  null);
         _lpexView = lpexView;
      }

      /**
       * Constructor for an LPEX view child preference page node.
       * @see #LpexPreferenceNode(LpexView)
       */
      public LpexPreferenceNode(LpexView lpexView, int nodeType)
      {
         super("LPEX" + _nodeId++);
         _lpexView = lpexView;
         _nodeType = nodeType;
      }

      /**
       * The PreferenceNode constructor we use doesn't set a label - which will
       * prevent "Preferences" from displaying (as there will be no text for
       * this tree item's name):  therefore, we must override getTextLabel() to
       * return the desired node name.
       */
      public String getLabelText()
      {
         switch (_nodeType) {
            case VIEW_BASE_NODE:
                 return _lpexView.query("name");
            case VIEW_PARSER_NODE:
                 return LpexResources.message(LpexConstants.MSG_PREFERENCES_VIEW_PARSER_TITLE);
            case VIEW_SEQUENCE_NUMBERS_NODE:
                 return LpexResources.message(LpexConstants.MSG_PREFERENCES_SEQUENCE_NUMBERS_TITLE);
            default: // case VIEW_SOURCE_ENCODING_NODE
                 return LpexResources.message(LpexConstants.MSG_PREFERENCES_VIEW_SOURCE_ENCODING_TITLE);
            }
      }

      /**
       * Pages are created lazily when the user selects a node.
       * getPage() != null is used to track what pages have been visited.
       *
       * When "Preferences" is dismissed, the node resources are disposed
       * (disposeResources() is called);  this method will be called when in
       * a new "Preferences" the user selects this node...
       */
      public void createPage()
      {
         IPreferencePage newPage;
         switch (_nodeType) {
            case VIEW_BASE_NODE:
                 newPage = new ViewBasePreferencePage(_lpexView);
                 break;
            case VIEW_PARSER_NODE:
                 newPage = new ViewParserPreferencePage(_lpexView);
                 break;
            case VIEW_SEQUENCE_NUMBERS_NODE:
                 newPage = new SequenceNumbersPreferencePage(_lpexView);
                 break;
            default: // case VIEW_SOURCE_ENCODING_NODE
                 newPage = new SourceEncodingPreferencePage(_lpexView);
                 break;
            }

         setPage(newPage);
         //if (getLabelImage() != null)
         //   newPage.setImageDescriptor(imageDescriptor);
         //newPage.setTitle(getLabelText());
      }
   }
}