//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// PopupCloser - LPEX variation of org.eclipse.jface.text.contentassist.
// PopupCloser.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.contentassist;

import com.ibm.lpex.core.LpexUtilities;

import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.widgets.Table;


/**
 * A generic closer class used to monitor various
 * interface events in order to determine whether
 * a content assist should be terminated and all
 * associated windows be closed.
 */
class PopupCloser implements FocusListener, SelectionListener
{
   private ContentAssistant fContentAssistant;
   private Table fTable;
   private ScrollBar fScrollbar;
   private boolean fScrollbarClicked;


   public void install(ContentAssistant contentAssistant, Table table)
   {
      fContentAssistant = contentAssistant;
      fTable = table;
      if (LpexUtilities.okToUse(fTable)) {
         fTable.addFocusListener(this);
         fScrollbar = fTable.getVerticalBar();
         if (fScrollbar != null)
            fScrollbar.addSelectionListener(this);
      }
   }

   public void uninstall()
   {
      if (LpexUtilities.okToUse(fTable)) {
         fTable.removeFocusListener(this);
         if (fScrollbar != null)
            fScrollbar.removeSelectionListener(this);
      }
   }

   // SelectionListener
   public void widgetSelected(SelectionEvent e)
   {
      fScrollbarClicked = true;
   }

   public void widgetDefaultSelected(SelectionEvent e)
   {
      fScrollbarClicked = true;
   }

   // FocusListener
   public void focusGained(FocusEvent e) {}

   public void focusLost(final FocusEvent e)
   {
      fScrollbarClicked = false;
      Display d = fTable.getDisplay();
      d.asyncExec(new Runnable() {
         public void run() {
            if (LpexUtilities.okToUse(fTable) && !fTable.isFocusControl() && !fScrollbarClicked)
               fContentAssistant.popupFocusLost(e);
            }
         });
   }
}