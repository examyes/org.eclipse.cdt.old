//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// IContentAssistListener - LPEX variation of org.eclipse.jface.text.contentassist.
// IContentAssistListener.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.contentassist;

import org.eclipse.swt.widgets.Event;


/**
 * An interface whereby listeners can not only receive key events,
 * but can also consume them to prevent subsequent listeners (including
 * the text widget) from processing the event.
 */
interface IContentAssistListener
{
   /**
    * Process the key pressed event.
    *
    * @return true if processing should continue by additional listeners
    * @see KeyListener#keyPressed
    */
   public boolean keyPressed(Event e); // jface's: verifyKey(VerifyEvent event);
}