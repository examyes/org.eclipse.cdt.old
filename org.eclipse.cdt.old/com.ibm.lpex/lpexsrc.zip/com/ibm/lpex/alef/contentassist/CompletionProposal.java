//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CompletionProposal - LPEX variation of org.eclipse.jface.text.contentassist.
// CompletionProposal.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.contentassist;

import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.alef.LpexTextViewer;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.util.Assert;


/**
 * The standard LPEX implementation of the <code>ICompletionProposal</code>
 * interface.
 */
public final class CompletionProposal implements ICompletionProposal
{
   private String fDisplayString;
   private String fReplacementString;
   private int fReplacementOffset;
   private int fReplacementLength;
   private int fCursorPosition;
   private Image fImage;
   private IContextInformation fContextInformation;
   private String fAdditionalProposalInfo;


   /**
    * Creates a new completion proposal based on the provided information.
    * The replacement string is considered being the display string too.
    * All remaining fields are set to <code>null</code>.
    *
    * @param replacementString the actual string to be inserted into the document
    * @param replacementOffset the offset of the text to be replaced
    * @param replacementLength the length of the text to be replaced
    * @param cursorPosition the position of the cursor following the insert relative to replacementOffset
    */
   public CompletionProposal(String replacementString,
                             int replacementOffset, int replacementLength,
                             int cursorPosition)
   {
      this(replacementString,
           replacementOffset, replacementLength,
           cursorPosition, null, null, null, null);
   }

   /**
    * Creates a new completion proposal. All fields are initialized based on the
    * provided information.
    *
    * @param replacementString the actual string to be inserted into the document
    * @param replacementOffset the offset of the text to be replaced
    * @param replacementLength the length of the text to be replaced
    * @param cursorPosition the position of the cursor following the insert relative to replacementOffset
    * @param image the image to display for this proposal
    * @param displayString the string to be displayed for the proposal
    * @param contentInformation the context information associated with this proposal
    * @param additionalProposalInfo the additional information associated with this proposal
    */
   public CompletionProposal(String replacementString,
                             int replacementOffset, int replacementLength,
                             int cursorPosition, Image image, String displayString,
                             IContextInformation contextInformation,
                             String additionalProposalInfo)
   {
      Assert.isNotNull(replacementString);
      //Assert.isTrue(replacementOffset >= 0);
      //Assert.isTrue(replacementLength >= 0);
      //Assert.isTrue(cursorPosition >= 0);

      fReplacementString= replacementString;
      fReplacementOffset= replacementOffset;
      fReplacementLength= replacementLength;
      fCursorPosition= cursorPosition;
      fImage= image;
      fDisplayString= displayString;
      fContextInformation= contextInformation;
      fAdditionalProposalInfo= additionalProposalInfo;
   }

   /*
    * This method is not used in LPEX.
    * @see ICompletionProposal#apply
    * @see #apply(LpexTextViewer)
    */
   // Ensure the offset is set in such a manner that it covers what
   // was already typed in, so that the proposal string can be placed in
   // the document in its entirety.
   public void apply(IDocument document)
   {
      try {
         document.replace(fReplacementOffset,    // offset in document
                          fReplacementLength,    // length
                          fReplacementString);   // string
         }
      catch (BadLocationException x) {}
   }
   /*
    * In LPEX, we apply against the LpexTextViewer directly, not its document.
    * The proposal is applied *at the current cursor* (which is located somewhere
    * inside the final word that we want upon completion);  the offset,
    * therefore, is 0 or the negative number of positions prior to the cursor.
    */
   public void apply(LpexTextViewer viewer)
   {
      // Insert the completion part of fReplacementString at the cursor:
      //
      //   edit window:        /* ccccc */ con|
      //   fReplacementString:             continue      fReplacementOffset: -3
      //                                                 completionIndex:     3
      //   applying proposal:  /* ccccc */ continue|
      //                                      =====
      int completionIndex = -fReplacementOffset;
      if (completionIndex >= 0 && completionIndex <= fReplacementString.length()) {
         LpexView lpexView = viewer.getLpexView();
         lpexView.doCommand("insertText " +
            fReplacementString.substring(completionIndex));
         lpexView.doCommand("screenShow");
         }
   }

   /*
    * @see ICompletionProposal#getSelection
    */
   public Point getSelection(IDocument document)
   {
      return new Point(fReplacementOffset + fCursorPosition, 0);
   }

   /*
    * @see ICompletionProposal#getContextInformation()
    */
   public IContextInformation getContextInformation()
   {
      return fContextInformation;
   }

   /*
    * @see ICompletionProposal#getImage()
    */
   public Image getImage()
   {
      return fImage;
   }

   /*
    * @see ICompletionProposal#getDisplayString()
    */
   public String getDisplayString()
   {
      if (fDisplayString != null)
         return fDisplayString;
      return fReplacementString;
   }

   /*
    * @see ICompletionProposal#getAdditionalProposalInfo()
    */
   public String getAdditionalProposalInfo()
   {
      return fAdditionalProposalInfo;
   }
}