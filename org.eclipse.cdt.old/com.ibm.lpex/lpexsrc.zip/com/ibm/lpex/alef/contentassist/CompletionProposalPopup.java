//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CompletionProposalPopup - LPEX variation of org.eclipse.jface.text.contentassist.
// CompletionProposalPopup.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.contentassist;

import com.ibm.lpex.core.LpexUtilities;
import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.core.LpexWindow;

import com.ibm.lpex.alef.LpexTextViewer;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextViewer;


/**
 * This class is used to present proposals to the user. If additional
 * information exists for a proposal, then selecting that proposal
 * will result in the information being displayed in a secondary
 * window.
 *
 * @see IContentAssistProposal
 * @see IAdditionalInfoPopup
 */
class CompletionProposalPopup implements IContentAssistListener
{
   private LpexTextViewer fViewer;
   private ContentAssistant fContentAssistant;
   private AdditionalInfoPopup fAdditionalInfoPopup;
   private int fListenerCount;

   private PopupCloser fPopupCloser = new PopupCloser();
   private Shell fProposalShell;
   private Table fProposalTable;
   private ICompletionProposal[] fProposalInput;


   public CompletionProposalPopup(ContentAssistant contentAssistant, ITextViewer viewer, AdditionalInfoPopup presenter)
   {
      fContentAssistant= contentAssistant;
      fViewer= (LpexTextViewer)viewer;
      fAdditionalInfoPopup= presenter;
   }

   public String showProposals(final boolean beep)
   {
      final LpexWindow lpexWindow = fViewer.getLpexWindow();
      BusyIndicator.showWhile(lpexWindow.getDisplay(), new Runnable() {
         public void run() {
            ICompletionProposal[] proposals= computeProposals();
            int count= (proposals == null ? 0 : proposals.length);
            if (count > 0) {
               createProposalSelector();
               setProposals(proposals);
               displayProposals();
               fAdditionalInfoPopup.install(fProposalInput, fViewer, fProposalShell, fProposalTable);
               }
            else if (beep) {
               lpexWindow.getDisplay().beep();
               }
            }
         });

      return getErrorMessage();
   }

   private ICompletionProposal[] computeProposals()
   {
      int pos= fViewer.getSelectedRange().x;
      return fContentAssistant.computeCompletionProposals(fViewer, pos);
   }

   private String getErrorMessage()
   {
      return fContentAssistant.getErrorMessage();
   }

   private void createProposalSelector()
   {
      if (LpexUtilities.okToUse(fProposalShell))
         return;

      // take a checkpoint first for any uncompleted changes
      fViewer.getLpexView().doDefaultCommand("undo check");

      fProposalShell = new Shell(fViewer.getLpexWindow().getShell(), SWT.NO_TRIM | SWT.ON_TOP);
      fProposalTable = new Table(fProposalShell, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);

      fProposalShell.setSize(300, fProposalTable.getItemHeight() * 10);
      fProposalTable.setBounds(fProposalShell.getClientArea());

      fProposalTable.addSelectionListener(new SelectionListener() {
         public void widgetSelected(SelectionEvent e) {}

         // double-click on a proposal
         public void widgetDefaultSelected(SelectionEvent e) {
            insertSelectedProposal();
            hide();
            }
         });

      fPopupCloser.install(fContentAssistant, fProposalTable);

      fProposalTable.setHeaderVisible(false);
      fContentAssistant.addToLayout(this, fProposalShell,
                                    ContentAssistant.LAYOUT_PROPOSAL_SELECTOR);
   }

   private void insertSelectedProposal()
   {
      int i = fProposalTable.getSelectionIndex();
      if (i < 0 || i >= fProposalInput.length)
         return;

      // in LPEX, we apply against the LpexTextViewer directly, not its document...
      ((CompletionProposal)fProposalInput[i]).apply(fViewer);
      //IDocument document= fViewer.getDocument();
      //fProposalInput[i].apply(document);

      // LPEX handles its own cursor after the proposal applied
      //Point selection= fProposalInput[i].getSelection(document);
      //if (selection != null)
      // fViewer.setSelectedRange(selection.x, selection.y);

      IContextInformation info= fProposalInput[i].getContextInformation();
      if (info != null)
         fContentAssistant.showContextInformation(info);
   }

   public boolean hasFocus()
   {
      if (LpexUtilities.okToUse(fProposalShell))
         return (fProposalShell.isFocusControl() || fProposalTable.isFocusControl());
      return false;
   }

   public void hide()
   {
      if (LpexUtilities.okToUse(fProposalShell)) {
         fContentAssistant.removeContentAssistListener(this, ContentAssistant.PROPOSAL_SELECTOR);

         fPopupCloser.uninstall();
         fProposalShell.setVisible(false);
         fProposalShell.dispose();
         fProposalShell = null;
         }
   }

   public boolean isActive()
   {
      return fProposalShell != null && !fProposalShell.isDisposed();
   }

   private void setProposals(ICompletionProposal[] proposals)
   {
      if (LpexUtilities.okToUse(fProposalTable)) {
         fProposalInput= proposals;

         fProposalTable.setRedraw(false);
         fProposalTable.removeAll();

         Display display= fProposalTable.getDisplay();

         TableItem item;
         ICompletionProposal p;
         for (int i= 0; i<proposals.length; i++) {
            p= proposals[i];
            item= new TableItem(fProposalTable, SWT.NULL);
            if (p.getImage() != null)
               item.setImage(p.getImage());
            item.setText(p.getDisplayString());
            }

         Point currentLocation= fProposalShell.getLocation();
         Point newLocation= getLocation();
         if ((newLocation.x < currentLocation.x && newLocation.y == currentLocation.y) || newLocation.y < currentLocation.y)
            fProposalShell.setLocation(newLocation);

         fProposalTable.select(0);
         fProposalTable.setRedraw(true);
         }
   }

   private Point getLocation()
   {
      // same as in getAbove/BelowLocation() in ContentAssistant.java...
      LpexView lpexView = fViewer.getLpexView();
      Point p = new Point(lpexView.queryInt("pixelPosition"),
                          lpexView.queryInt("cursorRow") * lpexView.queryInt("rowHeight"));
      return fViewer.getLpexWindow().textWindow().toDisplay(p);
   }

   private void displayProposals()
   {
      // content-assist notifications will be calls to our keyPressed()
      fContentAssistant.addContentAssistListener(this, ContentAssistant.PROPOSAL_SELECTOR);
      fProposalShell.setVisible(true);
   }

   /**
    * Called by ContentAssistController's LpexKeyListener's verifyKeyPressed().
    * The controller registered a KeyListener on the text editor widget:  we
    * follow the keys it receives, and react accordingly in our proposal popup.
    *
    * @return <code>true</code> if this key should be sent further to the other
    *         content-assist listeners
    */
   public boolean keyPressed(Event e)  // jface's: verifyKey(VerifyEvent e)
   {
      if (LpexUtilities.okToUse(fProposalShell))
         return proposalKeyPressed(e);
      return true;
   }

// private boolean proposalKeyPressed(VerifyEvent e)
   private boolean proposalKeyPressed(Event e)
   {
      char key = e.character;

      if (key == 0) {
         int newSelection = fProposalTable.getSelectionIndex();
         int visibleRows = (fProposalTable.getSize().y / fProposalTable.getItemHeight()) - 1;
         switch (e.keyCode) {
            case SWT.ARROW_LEFT:
            case SWT.ARROW_RIGHT:
               filterProposal();
               return true;    // proceed to other listeners...

            case SWT.ARROW_UP:
               newSelection -= (newSelection > 0 ? 1 : 0);
               break;

            case SWT.ARROW_DOWN:
               newSelection += (newSelection < fProposalTable.getItemCount() - 1 ? 1 : 0);
               break;

            case SWT.PAGE_DOWN:
               newSelection += visibleRows;
               if (newSelection >= fProposalTable.getItemCount())
                  newSelection = fProposalTable.getItemCount() - 1;
               break;

            case SWT.PAGE_UP:
               newSelection -= visibleRows;
               if (newSelection < 0)
                  newSelection = 0;
               break;

            case SWT.HOME:
               newSelection = 0;
               break;

            case SWT.END:
               newSelection = fProposalTable.getItemCount() - 1;
               break;

            case SWT.CTRL:
            case SWT.SHIFT:
               return true;    // proceed to other listeners...

            default:
               hide();
               return true;    // proceed to other listeners...
            }

         fProposalTable.setSelection(newSelection);
         fProposalTable.showSelection();
         e.doit = false; // LPEX shouldn't also process this key
         return false;   // don't send key further, we handled it enough
         }

      else if (key == SWT.ESC) { // terminate on "Esc"
         hide();
         e.doit = false; // LPEX shouldn't also process this key
         }

      else if (key == SWT.CR) {  // apply proposal on "Enter"
         insertSelectedProposal();
         hide();
         e.doit = false; // LPEX shouldn't also process this key
         return false;   // don't send key further, we handled it enough
         }

      else
         filterProposal();

      return true; // proceed to other listeners...
   }

   // we don't do IEventConsuming in LPEX...
   public void processEvent(VerifyEvent event) {}
   //private void proposalProcessEvent(VerifyEvent e) {}

   private void filterProposal()
   {
      fViewer.getLpexWindow().getDisplay().asyncExec(new Runnable() {
         public void run() {
            ICompletionProposal[] proposals= computeProposals();
            if (proposals != null && proposals.length > 0)
               setProposals(proposals);
            else
               hide(); // nothing left to propose, disappear...
            }
         });
   }
}