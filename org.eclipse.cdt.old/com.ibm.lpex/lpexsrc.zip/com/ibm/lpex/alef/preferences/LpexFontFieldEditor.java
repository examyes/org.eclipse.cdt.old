//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexFontFieldEditor - FontFieldEditor that works with LPEX's
// preference pages.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexResources;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FontDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

import org.eclipse.jface.resource.StringConverter;
import org.eclipse.jface.util.Assert;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.preference.FieldEditor;


/**
 * Field editor for a font type preference.
 */
final class LpexFontFieldEditor extends FieldEditor
{
   private Button changeFontButton;    // the change font button
   private FontData chosenFont;        // font data for the chosen font button
   private Label valueControl;         // the label that displays the selected font
   private DefaultPreviewer previewer; // the previewer
   private String _helpId;             // context-help id


   /**
    * Internal font previewer implementation.
    */
   private static class DefaultPreviewer
   {
      private Text text;
      private String string;
      private Font font;

      public DefaultPreviewer(Composite parent, String s, String helpId)
      {
         string = s;
         text = new Text(parent, SWT.READ_ONLY | SWT.BORDER);
         text.addDisposeListener(new DisposeListener() {
            public void widgetDisposed(DisposeEvent e) {
               if (font != null)
                  font.dispose();
               }
            });
         if (string != null)
            text.setText(string);
         Utilities.setHelp(text, helpId);
      }

      public Control getControl()
      {
         return text;
      }

      public void setFont(FontData fontData)
      {
         if (font != null)
            font.dispose();
         font = new Font(text.getDisplay(), fontData);
         text.setFont(font);
         text.setSize(text.getSize().x, getPreferredHeight());
      }

      public int getPreferredHeight()
      {
         Point preferredSize = text.computeSize(SWT.DEFAULT, SWT.DEFAULT, true);
         return Math.max(18, preferredSize.y);
      }
   }


   /**
    * Creates a font field editor with a preview window.
    *
    * @param parent the parent of the field editor's control
    * @param labelKey key for the label text of the field editor
    * @param previewKey key for the text used in the preview window
    * @param helpId context-help id
    */
   public LpexFontFieldEditor(Composite parent, String labelKey, String previewKey, String helpId)
   {
      init("" /*preferenceName*/, LpexResources.message(labelKey));
      _helpId = helpId;
      createControl(parent);

      // create the sample-text field outside our controls count
      if (previewKey != null) {
         previewer = new DefaultPreviewer(parent, LpexResources.message(previewKey), _helpId);
         // we create sample text *after* the regular controls - parent's layout
         // appears to be very sensitive at this point:  we must set the number of
         // columns for the horizontal span, or it traps.
         GridData gd = new GridData();
         gd.horizontalAlignment = gd.FILL;
         gd.horizontalSpan = getNumberOfControls();
         // don't widen entire preference page if very large font makes large sample
         gd.widthHint = parent.getClientArea().width;
         previewer.getControl().setLayoutData(gd);
         }
   }

   // /**
   //  * Creates a font field editor without a preview.
   //  *
   //  * @param parent the parent of the field editor's control
   //  * @param labelKey key for the label text of the field editor
   //  */
   // public LpexFontFieldEditor(Composite parent, String labelKey, String helpId)
   // {
   //    this(parent, labelKey, null, helpId);
   // }

   /**
    * Adjust the horizontal span of this field editor's basic controls.
    * We must adjust the horizontal span of controls so they appear correctly
    * in the given number of columns.  The number of columns is always equal to
    * or greater than the value returned by this editor's getNumberOfControls().
    */
   protected void adjustForNumColumns(int numColumns)
   {
      // keep the label to show above the value label & Change button
      Control control = getLabelControl();
      ((GridData)control.getLayoutData()).horizontalSpan = numColumns;

      // current font value
      ((GridData)valueControl.getLayoutData()).horizontalSpan = numColumns - 1;

      // sample text
      control = getPreviewControl();
      if (control != null) {
         ((GridData)control.getLayoutData()).horizontalSpan = numColumns;
         }
   }

   /**
    * Fills this field editor's basic controls into the given parent.
    * We must implement this method to create the controls for this field editor.
    * @param parent the composite used as a parent for the basic controls;
    *               the parent's layout must be a GridLayout
    * @param numColumns the number of columns
    */
   protected void doFillIntoGrid(Composite parent, int numColumns)
   {
      Control control = getLabelControl(parent);
      GridData gd = new GridData();
      gd.horizontalSpan = numColumns;
      control.setLayoutData(gd);

      valueControl = getValueControl(parent);
      gd = new GridData(GridData.FILL_HORIZONTAL);
      gd.horizontalSpan = numColumns - 1;
      //of no help: gd.grabExcessHorizontalSpace = true;
      valueControl.setLayoutData(gd);

      changeFontButton = getChangeControl(parent);
      gd = new GridData();
      gd.horizontalAlignment = gd.END;
      gd.heightHint = convertVerticalDLUsToPixels(changeFontButton, IDialogConstants.BUTTON_HEIGHT);
      int widthHint = convertHorizontalDLUsToPixels(changeFontButton, IDialogConstants.BUTTON_WIDTH);
      gd.widthHint = Math.max(widthHint, changeFontButton.computeSize(SWT.DEFAULT, SWT.DEFAULT, true).x);
      changeFontButton.setLayoutData(gd);
      Utilities.setHelp(changeFontButton, _helpId);

      // sample text
      control = getPreviewControl();
      if (control != null) {
         gd = new GridData();
         gd.horizontalAlignment = gd.FILL;
         gd.horizontalSpan = numColumns;
         gd.heightHint = previewer.getPreferredHeight();
         control.setLayoutData(gd);
         }
   }

   protected void doLoad() {}
   protected void doLoadDefault() {}
   protected void doStore() {}

   /**
    * Returns the change button for this field editor.
    */
   protected Button getChangeControl(Composite parent) {
      if (changeFontButton == null) {
         changeFontButton = new Button(parent, SWT.PUSH);
         changeFontButton.setText(LpexResources.message(LpexConstants.MSG_PREFERENCES_CHANGE));
         changeFontButton.addSelectionListener(new SelectionAdapter() {
            public void widgetSelected(SelectionEvent event) {
               FontDialog fontDialog = new FontDialog(changeFontButton.getShell());
               fontDialog.setFontData(chosenFont);
               FontData font = fontDialog.open();
               if (font != null) {
                  FontData oldFont = chosenFont;
                  setPresentsDefaultValue(false);
                  updateFont(font);
                  fireValueChanged(VALUE, oldFont, font);
                  }
               }
            });
         changeFontButton.addDisposeListener(new DisposeListener() {
            public void widgetDisposed(DisposeEvent event) {
               changeFontButton= null;
               }
            });
         }
      else
         checkParent(changeFontButton, parent);
      return changeFontButton;
   }

   public int getNumberOfControls()
   {
      return 3;
   }

   /**
    * Returns the preferred preview height.
    * @return the height, or <code>-1</code> if no previewer is installed
    */
   public int getPreferredPreviewHeight()
   {
      return (previewer == null)? -1 : previewer.getPreferredHeight();
   }

   /**
    * Returns the preview control for this field editor.
    */
   public Control getPreviewControl()
   {
      return (previewer == null)? null : previewer.getControl();
   }

   /**
    * Returns the value control for this field editor.  The value control
    * displays the currently selected font name.
    * @return the value control
    */
   protected Label getValueControl(Composite parent)
   {
      if (valueControl == null) {
         valueControl = new Label(parent, SWT.LEFT | SWT.BORDER);
         valueControl.addDisposeListener(new DisposeListener() {
            public void widgetDisposed(DisposeEvent event) {
               valueControl = null;
               }
            });
         }
      else
         checkParent(valueControl, parent);
      return valueControl;
   }

   /**
    * Updates the change font button and the previewer to reflect the
    * newly selected font.
    */
   private void updateFont(FontData font)
   {
      chosenFont = font;
      if (valueControl != null)
         valueControl.setText(StringConverter.asString(chosenFont));
      if (previewer != null)
         previewer.setFont(chosenFont);
   }

   // /**
   //  * @input fontValue e.g., "Courier New-regular-9"
   //  */
   // void setFontValue(String fontValue)
   // {
   //  // FontDialog.setFontData(FontData) won't show the selected size when
   //  // the FontData it's passed is not one created from a real Device font:
   //  // updateFont(StringConverter.asFontData(fontValue));
   //  FontData fd = StringConverter.asFontData(fontValue);
   //  Font f = new Font(Display.getCurrent(), fd); // assume editor is for Display fonts
   //  updateFont(f.getFontData()[0]);
   //  f.dispose();
   // }

   /**
    * @input fontDataValue font data string e.g.,
    *        "1|Fixedsys|9|0|WINDOWS|1|-12|0|0|0|0|0|0|0|1|0|0|0|0|Fixedsys"
    */
   void setFontDataValue(String fontDataValue)
   {
      updateFont(new FontData(fontDataValue));
   }

   /**
    * @return the selected font e.g., "Courier New-regular-9"
    */
   public String getFontValue()
   {
       return StringConverter.asString(chosenFont);
   }

   /**
    * @return the selected font data string e.g.,
    *         "1|lucida console|9|0|WINDOWS|1|-12|0|0|0|0|0|0|0|1|0|0|0|0|lucida console"
    */
   public String getFontDataValue()
   {
       return chosenFont.toString();
   }
}