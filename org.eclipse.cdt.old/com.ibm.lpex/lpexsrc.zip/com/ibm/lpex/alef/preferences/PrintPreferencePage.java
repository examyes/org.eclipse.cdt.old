//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// PrintPreferencePage - print settings preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import org.eclipse.swt.widgets.Composite;


/**
 * Preference page for LPEX's default print settings.
 */
public final class PrintPreferencePage extends LpexFieldEditorPreferencePage
{
   private String _initialBottomMargin;
   private String _initialLeftMargin;
   private String _initialLineNumbers;
   private String _initialRightMargin;
   private String _initialTokenized;
   private String _initialTopMargin;
   private LpexIntegerFieldEditor _bottomMarginTextField;
   private LpexIntegerFieldEditor _leftMarginTextField;
   private LpexBooleanFieldEditor _lineNumbersCheckBox;
   private LpexIntegerFieldEditor _rightMarginTextField;
   private LpexBooleanFieldEditor _tokenizedCheckBox;
   private LpexIntegerFieldEditor _topMarginTextField;


   public PrintPreferencePage()
   {
      super(LpexResources.message(LpexConstants.MSG_PREFERENCES_PRINT_TITLE), GRID);
   }

   protected void createFieldEditors()
   {
      Composite parent = getFieldEditorParent();

      _lineNumbersCheckBox = new LpexBooleanFieldEditor(
         LpexConstants.MSG_PREFERENCES_PRINT_LINE_NUMBERS, parent);
      _tokenizedCheckBox = new LpexBooleanFieldEditor(
         LpexConstants.MSG_PREFERENCES_PRINT_TOKENIZED, parent);
      _topMarginTextField = new LpexIntegerFieldEditor(
         LpexConstants.MSG_PREFERENCES_PRINT_TOP_MARGIN, parent);
      _bottomMarginTextField = new LpexIntegerFieldEditor(
         LpexConstants.MSG_PREFERENCES_PRINT_BOTTOM_MARGIN, parent);
      _leftMarginTextField = new LpexIntegerFieldEditor(
         LpexConstants.MSG_PREFERENCES_PRINT_LEFT_MARGIN, parent);
      _rightMarginTextField = new LpexIntegerFieldEditor(
         LpexConstants.MSG_PREFERENCES_PRINT_RIGHT_MARGIN, parent);
      addField(_lineNumbersCheckBox);
      addField(_tokenizedCheckBox);
      addField(_topMarginTextField);
      addField(_bottomMarginTextField);
      addField(_leftMarginTextField);
      addField(_rightMarginTextField);

      _initialBottomMargin = getDefaultValue("print.bottomMargin");
      _initialLeftMargin = getDefaultValue("print.leftMargin");
      _initialLineNumbers = getDefaultValue("print.lineNumbers");
      _initialRightMargin = getDefaultValue("print.rightMargin");
      _initialTokenized = getDefaultValue("print.tokenized");
      _initialTopMargin = getDefaultValue("print.topMargin");
      performReset();
   }

   // "OK" / "Apply" button pressed:  commit any new updated values.
   public boolean performOk()
   {
      setDefaultValue("print.bottomMargin", _bottomMarginTextField.getStringValue());
      setDefaultValue("print.leftMargin", _leftMarginTextField.getStringValue());
      setDefaultValue("print.lineNumbers", _lineNumbersCheckBox.getOnOffValue());
      setDefaultValue("print.rightMargin", _rightMarginTextField.getStringValue());
      setDefaultValue("print.tokenized", _tokenizedCheckBox.getOnOffValue());
      setDefaultValue("print.topMargin", _topMarginTextField.getStringValue());
      return true;
   }

   // "Defaults" button pressed:  set fields to the install settings, and do a
   // checkState() to recalculate this preference page's error state.
   protected void performDefaults()
   {
      updateSettings(LpexView.globalQuery("install.print.bottomMargin"),
                     LpexView.globalQuery("install.print.leftMargin"),
                     LpexView.globalQuery("install.print.lineNumbers"),
                     LpexView.globalQuery("install.print.rightMargin"),
                     LpexView.globalQuery("install.print.tokenized"),
                     LpexView.globalQuery("install.print.topMargin"));
      super.performDefaults();
   }

   // "Reset" button pressed:  set/restore fields to their initial settings.
   protected void performReset()
   {
      updateSettings(_initialBottomMargin,
                     _initialLeftMargin,
                     _initialLineNumbers,
                     _initialRightMargin,
                     _initialTokenized,
                     _initialTopMargin);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   private void updateSettings(String bottomMargin,
                               String leftMargin,
                               String lineNumbers,
                               String rightMargin,
                               String tokenized,
                               String topMargin)
   {
      _bottomMarginTextField.setStringValue(bottomMargin);
      _leftMarginTextField.setStringValue(leftMargin);
      _lineNumbersCheckBox.setSelected("on".equals(lineNumbers));
      _rightMarginTextField.setStringValue(rightMargin);
      _tokenizedCheckBox.setSelected("on".equals(tokenized));
      _topMarginTextField.setStringValue(topMargin);
   }

   private void setDefaultValue(String setting, String value)
   {
     if (!value.equals(getDefaultValue(setting)))
        LpexView.doGlobalCommand("set default." + setting + " " + value);
   }
}