//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// UserActionsPreferencePage - user-defined actions preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import java.util.StringTokenizer;
import java.util.Vector;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;


/**
 * Preference page for user actions.
 * It lets the user add and remove user-defined editor actions.
 */
public final class UserActionsPreferencePage extends TablePreferencePage
{
   private static final String[] _valueTableNames =
    { LpexResources.message(LpexConstants.MSG_PREFERENCES_USER_ACTIONS_TABLE_NAME),
      LpexResources.message(LpexConstants.MSG_PREFERENCES_USER_ACTIONS_TABLE_CLASS_NAME) };
   private static final String[] _valueNames =
    { LpexResources.message(LpexConstants.MSG_PREFERENCES_USER_ACTIONS_NAME),
      LpexResources.message(LpexConstants.MSG_PREFERENCES_USER_ACTIONS_CLASS_NAME) };
   private static final int[] _valueWeights = { 50, 50 };


   /**
    * Return the names for the table columns.
    */
   protected String[] getValueTableNames()
   {
      return _valueTableNames;
   }

   /**
    * Return the names for the text-field labels.
    */
   protected String[] getValueNames()
   {
      return _valueNames;
   }

   /**
    * Return the column weights for the two columns in the table.
    */
   protected int[] getValueWeights()
   {
      return _valueWeights;
   }

   /**
    * Return a new vector of LpexTableItems with the initial (current) settings
    * (the preference page is being initialized).
    */
   protected Vector initialize()
   {
      return updateSettings(LpexView.globalQuery("current.updateProfile.userActions"));
   }

   /**
    * Return a new vector of LpexTableItems with the install settings
    * ("Default" button was pressed).
    */
   protected Vector initializeDefaults()
   {
      return updateSettings(LpexView.globalQuery("install.updateProfile.userActions"));
   }

   /**
    * Return a new vector of LpexTableItems with the settings in the provided
    * userActions.
    */
   private Vector updateSettings(String userActions)
   {
      Vector items = new Vector();
      if (userActions != null) {
         StringTokenizer st = new StringTokenizer(userActions);
         while (st.hasMoreTokens()) {
            String actionName = st.nextToken();
            if (st.hasMoreTokens())
               items.addElement(new LpexTableItem(actionName, st.nextToken()));
            }
         }
      return items;
   }

   /**
    * "OK" / "Apply" button pressed.  Commit any new updated values.
    */
   public boolean performOk()
   {
      Vector items = getItems();

      String newUserActions = "";
      boolean first = true;
      for (int i = 0; i < items.size(); i++) {
         if (!first)
            newUserActions += " ";
         first = false;
         LpexTableItem pi = (LpexTableItem)items.elementAt(i);
         newUserActions += pi.value1() + " " + pi.value2(); // action name + class
         }

      if (!newUserActions.equals(LpexView.globalQuery("current.updateProfile.userActions"))) {
         LpexView.doGlobalCommand("set default.updateProfile.userActions " + newUserActions);
         //-as- if newUserActions empty, clean it up from Editor.properties
         LpexView.doGlobalCommand("updateProfile all");
         }
      return true;
   }
}