//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SequenceNumbersPreferencePage - sequence numbers preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexStringTokenizer;
import com.ibm.lpex.core.LpexView;

import org.eclipse.swt.widgets.Composite;


/**
 * Preference page with sequence-numbers settings for one LPEX view, or
 * default settings for the editor.
 *
 * <p>When the constructor is passed a non-null LpexView, an LPEX <b>view</b>
 * preference page (rather than a global-settings preference page) is created,
 * which handles the sequence-numbers settings for the particular view.</p>
 */
public class SequenceNumbersPreferencePage extends LpexFieldEditorPreferencePage
{
   private LpexView _lpexView;
   private String _initialSequenceNumbers;
   private LpexIntegerFieldEditor _numColumnTextField;
   private LpexIntegerFieldEditor _numWidthTextField;
   private LpexIntegerFieldEditor _textColumnTextField;
   private LpexIntegerFieldEditor _textWidthTextField;


   public SequenceNumbersPreferencePage(LpexView lpexView)
   {
      super(LpexResources.message(LpexPreferencesConstants.MSG_PREFERENCES_SEQUENCE_NUMBERS_TITLE),
            GRID);
      _lpexView = lpexView;
   }

   protected void createFieldEditors()
   {
      Composite parent = getFieldEditorParent();

      _numColumnTextField = new LpexIntegerFieldEditor(parent,
         LpexPreferencesConstants.MSG_PREFERENCES_SEQUENCE_NUMBERS_COLUMN, "pref_058");
      _numWidthTextField = new LpexIntegerFieldEditor(parent,
         LpexPreferencesConstants.MSG_PREFERENCES_SEQUENCE_NUMBERS_WIDTH, "pref_058");
      _textColumnTextField = new LpexIntegerFieldEditor(parent,
         LpexPreferencesConstants.MSG_PREFERENCES_SEQUENCE_TEXT_COLUMN, "pref_058");
      _textWidthTextField = new LpexIntegerFieldEditor(parent,
         LpexPreferencesConstants.MSG_PREFERENCES_SEQUENCE_TEXT_WIDTH, "pref_058");

      addField(_numColumnTextField);
      addField(_numWidthTextField);
      addField(_textColumnTextField);
      addField(_textWidthTextField);

      if (_lpexView != null) // view settings
         _initialSequenceNumbers = _lpexView.query("current.sequenceNumbers");
      else                   // global settings
         _initialSequenceNumbers = LpexView.globalQuery("current.sequenceNumbers");
      updateSettings(_initialSequenceNumbers);
   }

   /**
    * The "OK" or "Apply" button was pressed:  commit any new updated value
    * and ensure that the changes are reflected correctly on the LPEX screens.
    */
   public boolean performOk()
   {
      if (_lpexView != null) { // view settings
         // if new value set, the actual text that the parser sees may have been
         // affected: parse changes *now* (may add/remove error messages), refresh view
         if (setValue(sequenceNumbers())) {
            _lpexView.doDefaultCommand("parse");
            _lpexView.doDefaultCommand("screenShow");
            }
         }
      else {                 // global settings
         // if new default value set, refresh all views of all documents
         if (setDefaultValue(sequenceNumbers()))
            LpexView.doGlobalCommand("screenShow");
         }

      return true;
   }

   /**
    * The "Defaults" button was pressed:  set fields to the install/default
    * settings, and do a checkState() to recalculate page's error state.
    */
   protected void performDefaults()
   {
      if (_lpexView != null) // view settings - use the default values
         updateSettings(LpexView.globalQuery("current.sequenceNumbers"));
      else                   // global settings - use the install values
         updateSettings(LpexView.globalQuery("install.sequenceNumbers"));
      super.performDefaults();
   }

   /**
    * The "Reset" button was pressed:  restore the initial preference page
    * settings.
    */
   protected void performReset()
   {
      updateSettings(_initialSequenceNumbers);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   private void updateSettings(String sequenceNumbers)
   {
      LpexStringTokenizer st = new LpexStringTokenizer(sequenceNumbers);
      _numColumnTextField.setStringValue(st.hasMoreTokens()? st.nextToken() : "");
      _numWidthTextField.setStringValue(st.hasMoreTokens()? st.nextToken() : "");
      _textColumnTextField.setStringValue(st.hasMoreTokens()? st.nextToken() : "");
      _textWidthTextField.setStringValue(st.hasMoreTokens()? st.nextToken() : "");
   }

   private String sequenceNumbers()
   {
      return _numColumnTextField.getStringValue() + " " +
             _numWidthTextField.getStringValue() + " " +
             _textColumnTextField.getStringValue() + " " +
             _textWidthTextField.getStringValue();
   }

   private boolean setValue(String value)
   {
      if (!value.equals(_lpexView.query("current.sequenceNumbers"))) {
         _lpexView.doCommand("set sequenceNumbers " + value);
         return true;
         }
      return false;
   }

   private boolean setDefaultValue(String value)
   {
      if (!value.equals(LpexView.globalQuery("current.sequenceNumbers"))) {
         LpexView.doGlobalCommand("set default.sequenceNumbers " + value);
         return true;
         }
      return false;
   }
}