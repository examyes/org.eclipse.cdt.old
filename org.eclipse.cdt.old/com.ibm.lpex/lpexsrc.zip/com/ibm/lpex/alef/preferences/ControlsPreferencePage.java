//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ControlsPreferencePage - controls preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import org.eclipse.swt.widgets.Composite;


/**
 * Preference page for LPEX's default controls settings.
 */
public final class ControlsPreferencePage extends LpexFieldEditorPreferencePage
{
   private boolean _initialStatusLine;
   private boolean _initialFormatLine;
   private boolean _initialMessageLine;
   private boolean _initialCommandLine;
   private boolean _initialPrefixArea;
   private boolean _initialHideSequenceNumbers;
   private boolean _initialExpandHide;
   private LpexBooleanFieldEditor _statusLineCheckBox;
   private LpexBooleanFieldEditor _formatLineCheckBox;
   private LpexBooleanFieldEditor _messageLineCheckBox;
   private LpexBooleanFieldEditor _commandLineCheckBox;
   private LpexBooleanFieldEditor _prefixAreaCheckBox;
   private LpexBooleanFieldEditor _hideSequenceNumbersCheckBox;
   private LpexBooleanFieldEditor _expandHideCheckBox;

   public ControlsPreferencePage()
   {
      super(LpexResources.message(LpexConstants.MSG_PREFERENCES_CONTROLS_TITLE), GRID);
   }

   protected void createFieldEditors()
   {
      _initialStatusLine  = defaultSetting("statusLine");
      _initialFormatLine  = defaultSetting("formatLine");
      _initialMessageLine = defaultSetting("messageLine");
      _initialCommandLine = defaultSetting("commandLine");
      _initialPrefixArea  = defaultSetting("prefixArea");
      _initialHideSequenceNumbers = defaultSetting("hideSequenceNumbers");
      _initialExpandHide  = defaultSetting("expandHide");

      Composite parent = getFieldEditorParent();
      _statusLineCheckBox = new LpexBooleanFieldEditor(parent, // parent
         LpexConstants.MSG_PREFERENCES_CONTROLS_STATUSLINE,    // key of field's text label
         _initialStatusLine,                                   // initial value
         "pref_007");                                          // context-help id
      _formatLineCheckBox = new LpexBooleanFieldEditor(parent,
         LpexConstants.MSG_PREFERENCES_CONTROLS_FORMATLINE,
         _initialFormatLine, "pref_008");
      _messageLineCheckBox = new LpexBooleanFieldEditor(parent,
         LpexConstants.MSG_PREFERENCES_CONTROLS_MESSAGELINE,
         _initialMessageLine, "pref_009");
      _commandLineCheckBox = new LpexBooleanFieldEditor(parent,
         LpexConstants.MSG_PREFERENCES_CONTROLS_COMMANDLINE,
         _initialCommandLine, "pref_010");
      _prefixAreaCheckBox = new LpexBooleanFieldEditor(parent,
         LpexConstants.MSG_PREFERENCES_CONTROLS_PREFIXAREA,
         _initialPrefixArea, "pref_011");
      _hideSequenceNumbersCheckBox = new LpexBooleanFieldEditor(parent,
         LpexConstants.MSG_PREFERENCES_CONTROLS_HIDESEQUENCENUMBERS,
         _initialHideSequenceNumbers, "pref_012");
      _expandHideCheckBox = new LpexBooleanFieldEditor(parent,
         LpexConstants.MSG_PREFERENCES_CONTROLS_EXPANDHIDE,
         _initialExpandHide, "pref_013");
      addField(_statusLineCheckBox);
      addField(_formatLineCheckBox);
      addField(_messageLineCheckBox);
      addField(_commandLineCheckBox);
      addField(_prefixAreaCheckBox);
      addField(_hideSequenceNumbersCheckBox);
      addField(_expandHideCheckBox);
   }

   // "OK" / "Apply" button pressed:  commit any new updated values, ensure any
   // changes are reflected correctly on the LPEX screens.
   public boolean performOk()
   {
      boolean performScreenShow =
         updateLpex(_statusLineCheckBox,  "statusLine")  |
         updateLpex(_formatLineCheckBox,  "formatLine")  |
         updateLpex(_messageLineCheckBox, "messageLine") |
         updateLpex(_commandLineCheckBox, "commandLine") |
         updateLpex(_prefixAreaCheckBox,  "prefixArea")  |
         updateLpex(_hideSequenceNumbersCheckBox, "hideSequenceNumbers") |
         updateLpex(_expandHideCheckBox,  "expandHide");

      if (performScreenShow)
         LpexView.doGlobalCommand("screenShow");
      return true;
   }

   // "Defaults" button pressed:  set fields to the install settings, and do a
   // checkState() to recalculate page's error state.
   protected void performDefaults()
   {
      _statusLineCheckBox.setSelected(installSetting("statusLine"));
      _formatLineCheckBox.setSelected(installSetting("formatLine"));
      _messageLineCheckBox.setSelected(installSetting("messageLine"));
      _commandLineCheckBox.setSelected(installSetting("commandLine"));
      _prefixAreaCheckBox.setSelected(installSetting("prefixArea"));
      _hideSequenceNumbersCheckBox.setSelected(installSetting("hideSequenceNumbers"));
      _expandHideCheckBox.setSelected(installSetting("expandHide"));
      super.performDefaults();
   }

   // "Reset" button pressed:  restore fields to their initial settings.
   protected void performReset()
   {
      _statusLineCheckBox.setSelected(_initialStatusLine);
      _formatLineCheckBox.setSelected(_initialFormatLine);
      _messageLineCheckBox.setSelected(_initialMessageLine);
      _commandLineCheckBox.setSelected(_initialCommandLine);
      _prefixAreaCheckBox.setSelected(_initialPrefixArea);
      _hideSequenceNumbersCheckBox.setSelected(_initialHideSequenceNumbers);
      _expandHideCheckBox.setSelected(_initialExpandHide);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   private boolean defaultSetting(String parameter)
   {
      return "on".equals(getDefaultValue(parameter));
   }

   private boolean installSetting(String parameter)
   {
      String installParameter = LpexView.globalQuery("install." + parameter);
      return "on".equals(installParameter);
   }

   private boolean updateLpex(LpexBooleanFieldEditor checkBox, String parameter)
   {
      if (checkBox != null) {
         String defaultSetting = LpexView.globalQuery("default." + parameter);
         boolean setting = checkBox.getBooleanValue();
         boolean installSetting = "on".equals(LpexView.globalQuery("install." + parameter));
         if (installSetting == setting) {
            if (!(defaultSetting.equals("install"))) {
               LpexView.doGlobalCommand("set default." + parameter);
               return true;
               }
            }
         else if (defaultSetting.equals("install") || ((defaultSetting.equals("on")) != setting)) {
            LpexView.doGlobalCommand("set default." + parameter + " " + (setting? "on" : "off"));
            return true;
            }
         }
      return false;
   }
}