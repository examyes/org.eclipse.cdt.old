//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ViewParserPreferencePage - parser preference page for an LPEX view.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexStringTokenizer;
import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.alef.LpexPlugin;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;

import org.eclipse.jface.dialogs.IDialogConstants;


/**
 * Parser reference page for an LPEX view.
 * It handles the parser setting for the view.
 */
public final class ViewParserPreferencePage extends LpexFieldEditorPreferencePage
{
   private LpexView _lpexView;
   private String _parsers[];
   private String _initialParser;
   private LpexListEditor _parserList;
   private String _parserSetting;
   private Button applyButton;


   public ViewParserPreferencePage(LpexView lpexView)
   {
      super(LpexResources.message(LpexConstants.MSG_PREFERENCES_VIEW_PARSER_TITLE), GRID);
      noDefaultAndApplyButton(); // no need for the "Defaults" button in here
      _lpexView = lpexView;
   }

   protected void createFieldEditors()
   {
      LpexStringTokenizer st = new LpexStringTokenizer(LpexView.globalQuery("current.updateProfile.parsers"));
      _parsers = new String[st.countTokens()];
      for (int i = 0; st.hasMoreTokens(); i++)
         _parsers[i] = st.nextToken();

      Composite parent = getFieldEditorParent();

      _parserList = new LpexListEditor(LpexConstants.MSG_PREFERENCES_VIEW_PARSER_PARSER,
                                       parent, _parsers);
      addField(_parserList);

      _initialParser = _lpexView.query("parser");
      updateSettings(_initialParser);
   }

   /**
    * Contribute the "Reset" and "Apply" buttons (we had to get rid of the
    * "Defaults" button, so original "Apply" also had to be Ecliptically flushed...).
    *
    * @param buttonBar the preference-page button bar
    */
   protected void contributeButtons(Composite buttonBar)
   {
      super.contributeButtons(buttonBar); // contribute the "Reset" button

      // for each button contributed we must increment
      // the parent's grid layout number of columns
      ((GridLayout)buttonBar.getLayout()).numColumns++;

      applyButton = new Button(buttonBar, SWT.PUSH);
      applyButton.setFont(buttonBar.getFont());
      applyButton.setText(LpexPlugin.getResourceString("preferences.apply"));
      GridData data = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
      data.heightHint = convertVerticalDLUsToPixels(IDialogConstants.BUTTON_HEIGHT);
      data.widthHint = Math.max(convertHorizontalDLUsToPixels(IDialogConstants.BUTTON_WIDTH),
                                applyButton.computeSize(SWT.DEFAULT, SWT.DEFAULT, true).x);
      applyButton.setLayoutData(data);
      applyButton.addSelectionListener(
         new SelectionAdapter() {
            public void widgetSelected(SelectionEvent e) {
               performApply();
            }
         });
      applyButton.setEnabled(isValid());
   }

   // we must reimplement this, because we had to define our own "Apply" button...
   protected void updateApplyButton()
   {
      if (applyButton != null)
         applyButton.setEnabled(isValid());
   }

   // "OK" / "Apply" button pressed:  commit any new updated value by running
   // the updateProfile command, ensure changes are reflected correctly on the
   // LPEX screens.
   public boolean performOk()
   {
      String currentParser = _lpexView.query("parser");
      if (currentParser == null)
         currentParser = "";
      String newParser = parser();
      if (!currentParser.equals(newParser)) {
         _lpexView.doCommand("set updateProfile.parser " + newParser);
         _lpexView.doCommand("updateProfile");
         _lpexView.doCommand("screenShow");
         }
      return true;
   }

   // "Reset" button pressed:  restore initial preference page settings.
   protected void performReset()
   {
      updateSettings(_initialParser);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   // select the given parser (if any) in the list
   private void updateSettings(String parser)
   {
      _parserSetting = parser; // keep it in case it's not in the list
      _parserList.clearSelection();
      for (int i = 0; i < _parsers.length; i++) {
         if (_parsers[i].equals(parser)) {
            _parserList.setSelectedIndex(i);
            return;
            }
         }
   }

   // return the parser selected in the list, or an empty String if none
   private String parser()
   {
      int index = _parserList.getSelectedIndex();
      if (index >= 0 && index < _parsers.length)
         return _parsers[index];

      // not in the list, return whatever we set last time
      return (_parserSetting != null)? _parserSetting : "";
   }
}