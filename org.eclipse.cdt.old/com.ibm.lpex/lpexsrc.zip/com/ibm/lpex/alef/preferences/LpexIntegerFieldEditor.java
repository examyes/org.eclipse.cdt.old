//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexIntegerFieldEditor - IntegerFieldEditor that works with LPEX's
// preference pages.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexResources;

import org.eclipse.swt.widgets.Composite;


/**
 * A field editor for an integer type preference.
 * The LPEX version mainly uses the layout and widget-control functions of
 * StringFieldEditor.
 * By default, the validation strategy is to revalidate on each keystroke.
 */
class LpexIntegerFieldEditor extends LpexStringFieldEditor
{
   /**
    * Creates an integer field editor with a display width suitable
    * for approximately 3 characters.
    * An empty field is allowed;  otherwise, if not a valid positive
    * integer, an error message is displayed.
    * Use <code>setTextLimit()</code> to limit the width.
    *
    * @param parent the parent of the field editor's control
    * @param labelKey key for the label text of the field editor
    * @param helpId context-help id
    */
   public LpexIntegerFieldEditor(Composite parent, String labelKey, String helpId)
   {
      super(parent, labelKey, 3, null, helpId);
   }

   protected boolean checkState()
   {
      boolean result = true;
      String text = getStringValue().trim();
      if (text.length() > 0) {
         try {
            result = Integer.parseInt(text) >= 0;
            }
         catch (NumberFormatException e) {
            result = false;
            }
         }

      // call hook for subclasses
      result = result && doCheckState();

      if (result)
         clearErrorMessage();
      else
         showErrorMessage(LpexResources.message(
            LpexConstants.MSG_PREFERENCES_INCORRECT_VALUE, text));

      return result;
   }
}