//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexBasePreferencePage - top LPEX preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import org.eclipse.swt.widgets.Composite;


/**
 * The main page of LPEX preferences.  It handles default updateProfile
 * settings - baseProfile and noParser.
 */
public final class LpexBasePreferencePage extends LpexFieldEditorPreferencePage
                                          implements LpexPreferencesConstants
{
   private static final String[] _baseProfiles =
      { "brief", "emacs", "epm", "ispf", "lpex", "seu", "vi", "xedit" };

   private String _initialBaseProfile;
   private String _initialNoParser;
   private LpexListEditor _baseProfileList;
   private LpexBooleanFieldEditor _noParserCheckBox;


   public LpexBasePreferencePage()
   {
      super(LpexResources.message(MSG_PREFERENCES_ROOT_TITLE), GRID);
   }

   protected void createFieldEditors()
   {
      Composite parent = getFieldEditorParent();
      _baseProfileList = new LpexListEditor(parent,
         MSG_PREFERENCES_ROOT_EDITOR_PROFILE, _baseProfiles, "pref_055");
      _noParserCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_ROOT_NO_PARSER, "pref_056");
      addField(_baseProfileList);
      addField(_noParserCheckBox);

      _initialBaseProfile = LpexView.globalQuery("current.updateProfile.baseProfile");
      _initialNoParser = LpexView.globalQuery("current.updateProfile.noParser");
      updateSettings(_initialBaseProfile, _initialNoParser);
   }

   // "OK" / "Apply" button pressed:  commit any new updated values and run
   // the updateProfile command, ensure changes are reflected correctly on the
   // LPEX screens.
   public boolean performOk()
   {
      boolean baseProfileUpdated = setDefaultValue("updateProfile.baseProfile", baseProfile());
      boolean noParserUpdated = setDefaultValue("updateProfile.noParser",
                                                _noParserCheckBox.getOnOffValue());
      if (baseProfileUpdated || noParserUpdated) {
         LpexView.doGlobalCommand("updateProfile all");
         LpexView.doGlobalCommand("screenShow");
         }
      return true;
   }

   // "Defaults" button pressed:  set fields to the install settings, and do a
   // checkState() to recalculate page's error state.
   protected void performDefaults()
   {
      updateSettings(LpexView.globalQuery("install.updateProfile.baseProfile"),
                     LpexView.globalQuery("install.updateProfile.noParser"));
      super.performDefaults();
   }

   // "Reset" button pressed:  restore initial preference page settings.
   protected void performReset()
   {
      updateSettings(_initialBaseProfile, _initialNoParser);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   // select given baseProfile in the list & update the noParser check box
   private void updateSettings(String baseProfile, String noParser)
   {
      for (int i = 0; i < _baseProfiles.length; i++) {
         if (_baseProfiles[i].equals(baseProfile)) {
            _baseProfileList.setSelectedIndex(i);
            break;
            }
         }
      _noParserCheckBox.setSelected("on".equals(noParser));
   }

   private boolean setDefaultValue(String setting, String value)
   {
      if (!value.equals(LpexView.globalQuery("current." + setting))) {
         LpexView.doGlobalCommand("set default." + setting + " " + value);
         return true;
         }
      return false;
   }

   private String baseProfile()
   {
      int index = _baseProfileList.getSelectedIndex();
      if (index >= 0 && index < _baseProfiles.length)
         return _baseProfiles[index];
       return "";
   }
}