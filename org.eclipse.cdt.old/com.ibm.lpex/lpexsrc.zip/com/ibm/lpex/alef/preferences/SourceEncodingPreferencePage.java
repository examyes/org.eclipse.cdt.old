//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SourceEncodingPreferencePage - source-encoding preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexNls;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;


/**
 * Parser reference page for an LPEX view.
 * It handles the parser setting for the view.
 */
public final class SourceEncodingPreferencePage extends LpexFieldEditorPreferencePage
{
   private LpexView _lpexView;
   private static final String _sourceEncodings[] = {
     /*   Japan           */  "Cp930", "Cp939",
     /*   Korea           */  "Cp933",
     /*   S-Chinese       */  "Cp935",
     /*   T-Chinese       */  "Cp937"
     };
   private String _initialSourceEncoding;
   private LpexComboEditor _sourceEncodingList;


   public SourceEncodingPreferencePage(LpexView lpexView)
   {
      super(LpexResources.message(LpexConstants.MSG_PREFERENCES_VIEW_SOURCE_ENCODING_TITLE), GRID);
      _lpexView = lpexView;
   }

   protected void createFieldEditors()
   {
      _sourceEncodingList =
         new LpexComboEditor(LpexConstants.MSG_PREFERENCES_VIEW_SOURCE_ENCODING_SOURCE_ENCODING,
                             getFieldEditorParent(), _sourceEncodings);
      addField(_sourceEncodingList);

      _initialSourceEncoding = _lpexView.query("current.sourceEncoding");
      updateSettings(_initialSourceEncoding);
   }

   // "OK" / "Apply" button pressed:  commit any new updated value by running
   // the updateProfile command, ensure changes are reflected correctly on the
   // LPEX screens.
   public boolean performOk()
   {
      if (!isEncodingValid())
         return false;

      String currentSourceEncoding = _lpexView.query("current.sourceEncoding");
      if (currentSourceEncoding == null)
         currentSourceEncoding = "";
      String newSourceEncoding = sourceEncoding();
      if (!currentSourceEncoding.equals(newSourceEncoding)) {
         _lpexView.doCommand("set sourceEncoding " + newSourceEncoding);
         _lpexView.doCommand("screenShow");
         }
      return true;
   }

   // "Defaults" button pressed:  set fields to the default/install settings,
   // and do a checkState() to recalculate page's error state.
   protected void performDefaults()
   {
      updateSettings(LpexView.globalQuery("current.sourceEncoding"));
      super.performDefaults();
   }

   // "Reset" button pressed:  restore initial preference page settings.
   protected void performReset()
   {
      updateSettings(_initialSourceEncoding);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   private void updateSettings(String sourceEncoding)
   {
      _sourceEncodingList.setStringValue(sourceEncoding);
   }

   private String sourceEncoding()
   {
      return _sourceEncodingList.getStringValue().trim();
   }

   // validate encoding only when "Apply" / "OK" pressed, keep clear of errors
   // errors otherwise (LpexComboEditor does that in valueChanged())
   private boolean isEncodingValid()
   {
      boolean valid;
      String sourceEncoding = sourceEncoding();
      if (sourceEncoding.length() == 0)
         valid = true;
      else
         valid = LpexNls.isValidEncoding(sourceEncoding);
      if (!valid)
         setErrorMessage(LpexResources.message(LpexConstants.MSG_ENCODING_INVALID, sourceEncoding));
      return valid;
   }
}