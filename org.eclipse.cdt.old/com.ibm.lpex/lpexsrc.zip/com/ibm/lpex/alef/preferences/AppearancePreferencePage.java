//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// AppearancePreferencePage - color palette & font settings preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexStringTokenizer;
import com.ibm.lpex.core.LpexView;

import org.eclipse.swt.widgets.Composite;


/**
 * Preference page for LPEX's default palette and font settings.
 */
public final class AppearancePreferencePage extends LpexFieldEditorPreferencePage
{
   private String[] _palettes;
   private String[] _paletteNames;
   private String _initialPalette;
   private String _initialFontDataString;
   private LpexListEditor _paletteList;
   private LpexFontFieldEditor _fontFieldEditor;


   public AppearancePreferencePage()
   {
      super(LpexResources.message(LpexConstants.MSG_PREFERENCES_APPEARANCE_TITLE), GRID);
   }

   protected void createFieldEditors()
   {
      LpexStringTokenizer st =
         new LpexStringTokenizer(LpexView.globalQuery("current.updateProfile.palettes"));
      int paletteCount = st.countTokens();
      _palettes = new String[paletteCount];
      _paletteNames = new String[paletteCount];
      int i = 0;
      while (st.hasMoreTokens()) {
         _palettes[i] = st.nextToken();
         _paletteNames[i] = LpexResources.message("paletteName." + _palettes[i]);
         if (_paletteNames[i] == null)
            _paletteNames[i] = _palettes[i];
         i++;
         }

      Composite parent = getFieldEditorParent();
      _paletteList = new LpexListEditor(LpexConstants.MSG_PREFERENCES_PALETTE_PALETTE,
                                        parent, _paletteNames);

      createSpace(parent, 3); // gap of one line, three columns

      _fontFieldEditor =
         new LpexFontFieldEditor(LpexConstants.MSG_PREFERENCES_FONT_TITLE,
                                 LpexConstants.MSG_PREFERENCES_FONT_SAMPLE, parent);

      addField(_paletteList);
      addField(_fontFieldEditor);

      _initialPalette = LpexView.globalQuery("current.updateProfile.palette");
      _initialFontDataString = LpexStringTokenizer.removeQuotes(LpexView.globalQuery("default.font.fontData"));
      updateSettings(_initialPalette, _initialFontDataString);
   }

   // "OK" / "Apply" button pressed:  commit any new updated values and ensure
   // any changes are reflected correctly on the LPEX screens.
   public boolean performOk()
   {
      boolean performScreenShow = false;

      // 1.- commit any new palette value and run the updateProfile command
      boolean paletteUpdated = setDefaultValue("updateProfile.palette", palette());
      if (paletteUpdated) {
         LpexView.doGlobalCommand("updateProfile all");
         performScreenShow = true;
         }

      // 2.- apply the selected font as the default.font in the editor;  if the
      // chosen font is already the install.font, then default.font is cleared
      // so as to point to install
      // NOTE:  If the current visible edit View had a "set font .." command applied,
      // too bad - the Font preferences panel is global in nature, is not aware of
      // the currently active edit View (if any), therefore it cannot change this
      // view's current.font to be "default"...
      String setting = _fontFieldEditor.getFontValue();
      String settingFontData = _fontFieldEditor.getFontDataValue();
      String defaultSetting = LpexStringTokenizer.removeQuotes(LpexView.globalQuery("default.font"));
      String installSetting = LpexStringTokenizer.removeQuotes(LpexView.globalQuery("install.font"));

      // (a) selected font == "install" font
      if (installSetting.equals(setting)) {
         if (!defaultSetting.equals("install")) {
            LpexView.doGlobalCommand("set default.font"); // make default be install
            performScreenShow = true;
            }
         }
      // (b) "default" == "install" OR "default" != selected font
      else if (defaultSetting.equals("install") || !(defaultSetting.equals(setting))) {
         LpexView.doGlobalCommand("set default.font.fontData " +
                                  LpexStringTokenizer.addQuotes(settingFontData));
         performScreenShow = true;
         }

      if (performScreenShow)
         LpexView.doGlobalCommand("screenShow");

      return true;
   }

   // "Defaults" button pressed:  set fields to the install settings, and do a
   // checkState() to recalculate page's error state.
   protected void performDefaults()
   {
      updateSettings(LpexView.globalQuery("install.updateProfile.palette"),
                     LpexStringTokenizer.removeQuotes(LpexView.globalQuery("install.font.fontData")));
      super.performDefaults();
   }

   // "Reset" button pressed:  restore the initial preference page settings.
   protected void performReset()
   {
      updateSettings(_initialPalette, _initialFontDataString);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   // select the given palette in the list, set the given font
   private void updateSettings(String palette, String fontDataString)
   {
     for (int i = 0; i < _palettes.length; i++) {
        if (_palettes[i].equals(palette)) {
           _paletteList.setSelectedIndex(i);
           break;
           }
        }

     _fontFieldEditor.setFontDataValue(fontDataString);
   }

   private String palette()
   {
      int index = _paletteList.getSelectedIndex();
      if (index >= 0 && index < _palettes.length)
         return _palettes[index];
      return "";
   }

   private boolean setDefaultValue(String setting, String value)
   {
      if (!value.equals(LpexView.globalQuery("current." + setting))) {
         LpexView.doGlobalCommand("set default." + setting + " " + value);
         return true;
         }
      return false;
   }
}