//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexListEditor - ListEditor that works with LPEX's preference pages.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexResources;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.List;

import org.eclipse.jface.preference.FieldEditor;


/**
 * A field editor that manages a single-selection list of input values.
 * The editor displays a list containing the values.
 */
final class LpexListEditor extends FieldEditor
{
   private List _list;
   private int _itemCount;

   /**
    * Creates a list field editor.
    *
    * @param labelKey key of the label text of the field editor
    * @param parent the parent of the field editor's control
    * @param values list of strings for the list
    */
   protected LpexListEditor(String labelKey, Composite parent, String[] values)
   {
      init("" /*preferenceName*/, LpexResources.message(labelKey));
      _itemCount = values.length;
      createControl(parent);
      for (int i = 0; i < values.length; i++)
         _list.add(values[i]);
   }

   void setSelectedIndex(int index)
   {
      _list.setSelection(index);
      _list.showSelection();
   }

   int getSelectedIndex()
   {
      return _list.getSelectionIndex();
   }

   void clearSelection()
   {
      _list.deselectAll();
   }

   /**
    * Adjust the horizontal span of this field editor's basic controls.
    * We must adjust the horizontal span of controls so they appear correct in
    * the given number of columns.  The number of columns is always equal to
    * or greater than the value returned by this editor's getNumberOfControls().
    */
   protected void adjustForNumColumns(int numColumns)
   {
      Control control = getLabelControl();
      // keep the label to show above the list
      ((GridData)control.getLayoutData()).horizontalSpan = numColumns;
      ((GridData)_list.getLayoutData()).horizontalSpan = numColumns;
   }

   /**
    * Fills this field editor's basic controls into the given parent.
    * We must implement this method to create the controls for this field editor.
    * @param parent the composite used as a parent for the basic controls;
    *               the parent's layout must be a GridLayout
    * @param numColumns the number of columns
    */
   protected void doFillIntoGrid(Composite parent, int numColumns)
   {
      Control control = getLabelControl(parent);
      GridData gd = new GridData();
      gd.horizontalSpan = numColumns;
      control.setLayoutData(gd);

      _list = getListControl(parent);
      gd = new GridData(GridData.FILL_HORIZONTAL);
      gd.verticalAlignment = gd.FILL;
      // don't heighten the preference page (unfortunately,
      // parent.getClientArea().height returns 0 here...)
      gd.heightHint = _list.getItemHeight() * Math.min(_itemCount, 15);
      gd.horizontalSpan = numColumns;
      _list.setLayoutData(gd);
   }

   protected void doLoad() {}
   protected void doLoadDefault() {}
   protected void doStore() {}

   /**
    * Returns this field editor's list control.
    *
    * @param parent the parent control
    * @return the list control
    */
   public List getListControl(Composite parent)
   {
      if (_list == null) {
         // NB adding a SWT.H_SCROLL always keeps ~ 1-item room for it...
         _list = new List(parent, SWT.BORDER | SWT.SINGLE | SWT.V_SCROLL);
         _list.addDisposeListener(new DisposeListener() {
            public void widgetDisposed(DisposeEvent event) {
               _list = null;
               }
            });
         }
      else
         checkParent(_list, parent);

      return _list;
   }

   /**
    * Return the number of basic controls this field editor consists of.
    */
   public int getNumberOfControls()
   {
      return 2; // label + list
   }

   public void setFocus()
   {
      if (_list != null)
         _list.setFocus();
   }
}