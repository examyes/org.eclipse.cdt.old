//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// TabsPreferencePage - default tabs setting preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import org.eclipse.swt.widgets.Composite;


/**
 * Preference page for LPEX's default tabs setting.
 */
public final class TabsPreferencePage extends LpexFieldEditorPreferencePage
                                      implements LpexPreferencesConstants
{
   private String _initialTabs;
   private String _initialExpandTabs;
   private LpexStringFieldEditor _tabStopsTextField;
   private LpexStringFieldEditor _tabIncrementTextField;
   private LpexBooleanFieldEditor _expandTabsCheckBox;


   public TabsPreferencePage()
   {
      super(LpexResources.message(MSG_PREFERENCES_TABS_TITLE), GRID);
   }

   protected void createFieldEditors()
   {
      Composite parent = getFieldEditorParent();
      _tabStopsTextField = new TabsStringFieldEditor(parent,
         MSG_PREFERENCES_TABS_TAB_STOPS, "pref_039");
      _tabIncrementTextField = new LpexIntegerFieldEditor(parent,
         MSG_PREFERENCES_TABS_TAB_INCREMENT, "pref_040");
      _expandTabsCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_TABS_EXPAND_TABS, "pref_041");
      addField(_tabStopsTextField);
      addField(_tabIncrementTextField);
      addField(_expandTabsCheckBox);

      _initialTabs = getDefaultValue("tabs");
      _initialExpandTabs = getDefaultValue("expandTabs");
      updateSettings(_initialTabs, _initialExpandTabs);
   }

   // "OK" / "Apply" button pressed:  commit any new updated values and
   // ensure changes are reflected correctly on the affected LPEX screens.
   public boolean performOk()
   {
      boolean performScreenShow = false;
      String tabs = tabs();
      if (!tabs.equals(getDefaultValue("tabs"))) {
         LpexView.doGlobalCommand("set default.tabs " + tabs);
         performScreenShow = true;
         }
      String expandTabs = _expandTabsCheckBox.getOnOffValue();
      if (!expandTabs.equals(getDefaultValue("expandTabs"))) {
         LpexView.doGlobalCommand("set default.expandTabs " + expandTabs);
         performScreenShow = true;
         }

      if (performScreenShow)
         LpexView.doGlobalCommand("screenShow");
      return true;
   }

   // "Defaults" button pressed:  set fields to the install setting, and do a
   // checkState() to recalculate page's error state.
   protected void performDefaults()
   {
      String tabs = LpexView.globalQuery("install.tabs");
      String expandTabs = LpexView.globalQuery("install.expandTabs");
      updateSettings(tabs, expandTabs);
      super.performDefaults();
   }

   // "Reset" button pressed:  restore fields to their initial settings.
   protected void performReset()
   {
      updateSettings(_initialTabs, _initialExpandTabs);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   private void updateSettings(String tabs, String expandTabs)
   {
      String tabStops = "";
      String tabIncrement = "";
      if (tabs != null) {
         int indexOfEvery = tabs.indexOf("every");
         if (indexOfEvery != -1) {
            tabIncrement = tabs.substring(indexOfEvery + 5).trim();
            tabStops = tabs.substring(0, indexOfEvery).trim();
            }
         else
            tabStops = tabs.trim();
         }

     _tabStopsTextField.setStringValue(tabStops);
     _tabIncrementTextField.setStringValue(tabIncrement);
     _expandTabsCheckBox.setSelected("on".equals(expandTabs));
   }

   private String tabs()
   {
      String tabStops = _tabStopsTextField.getStringValue().trim();
      String tabIncrement = _tabIncrementTextField.getStringValue().trim();
      if (tabIncrement.length() > 0)
         return tabStops + " every " + tabIncrement;
      return tabStops;
   }

   static class TabsStringFieldEditor extends LpexStringFieldEditor
   {
      public TabsStringFieldEditor(Composite parent, String labelKey, String helpId)
      {
         super(parent, labelKey, helpId);
      }

      // very basic tabs stops validation
      protected boolean doCheckState()
      {
         String value = getStringValue().trim();
         boolean valid = true;
         for (int i = 0; i < value.length(); i++)
            if (value.charAt(i) != ' ' && !Character.isDigit(value.charAt(i))) {
               valid = false;
               break;
               }

         if (!valid)
            setErrorMessage(LpexResources.message(MSG_PREFERENCES_INCORRECT_VALUE,
                                                  value));
         return valid;
      }
   }
}