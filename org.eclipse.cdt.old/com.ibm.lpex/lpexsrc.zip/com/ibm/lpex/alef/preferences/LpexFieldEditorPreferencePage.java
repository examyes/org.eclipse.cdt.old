//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexFieldEditorPreferencePage - LPEX variation of FieldEditorPreferencePage.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.alef.LpexPlugin;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.preference.FieldEditorPreferencePage;

import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;


/**
 * LPEX variation of FieldEditorPreferencePage.
 * It implements a series of common methods used by LPEX preference pages.
 * Method contributeButtons() adds a "Reset" button, which restores the initial
 * settings in effect when the preference page came up.
 */
public abstract class LpexFieldEditorPreferencePage extends FieldEditorPreferencePage
                                                    implements IWorkbenchPreferencePage
{
   /**
    * Constructor for a preference page with the given title and style,
    * and no image.
    * @param style either <code>GRID</code> or <code>FLAT</code>
    */
   protected LpexFieldEditorPreferencePage(String title, int style)
   {
      super(title, style);
   }

   /**
    * The LpexFieldEditorPreferencePage implementation of this method
    * contributes a "Reset" button.  Method performReset() is called when this
    * button is selected.
    *
    * @param buttonBar the preference-page button bar
    * @see org.eclipse.jface.preference.PreferencePage#contributeButtons
    * @see #performReset
    */
   protected void contributeButtons(Composite buttonBar)
   {
      // for each button contributed we must increment
      // the parent's grid layout number of columns
      ((GridLayout)buttonBar.getLayout()).numColumns++;

      Button resetButton = new Button(buttonBar, SWT.PUSH);
      resetButton.setFont(buttonBar.getFont());
      resetButton.setText(LpexPlugin.getResourceString("preferences.reset"));
      GridData data = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
      data.heightHint = convertVerticalDLUsToPixels(IDialogConstants.BUTTON_HEIGHT);
      data.widthHint = Math.max(convertHorizontalDLUsToPixels(IDialogConstants.BUTTON_WIDTH),
                                resetButton.computeSize(SWT.DEFAULT, SWT.DEFAULT, true).x);
      resetButton.setLayoutData(data);
      resetButton.addSelectionListener(
         new SelectionAdapter() {
            public void widgetSelected(SelectionEvent e) {
               performReset();
            }
         });
   }

   /**
    * The "Reset" button was pressed.
    * The LpexFieldEditorPreferencePage implementation of this method does
    * nothing.  Override to restore the initial settings of the preference page.
    *
    * @see #contributeButtons
    */
   protected void performReset() {}

   /**
    * Creates a space of one horizontal line.
    *
    * @param parent the parent in which the gap should be created
    * @param columns number of columns in the page layout grid
    */
   static void createSpace(Composite parent, int columns)
   {
      Label vfiller = new Label(parent, SWT.LEFT);
      GridData gridData = new GridData();
      gridData = new GridData();
      gridData.horizontalAlignment = GridData.BEGINNING;
      gridData.grabExcessHorizontalSpace = false;
      gridData.horizontalSpan = columns;
      gridData.verticalAlignment = GridData.CENTER;
      gridData.grabExcessVerticalSpace = false;
      vfiller.setLayoutData(gridData);
   }

   /**
    * Initializes this preference page for the given workbench.
    * This method, defined by IWorkbenchPreferencePage, is called automatically
    * when the preference page defined in plugin.xml is being created and
    * initialized.
    *
    * <p>The LpexFieldEditorPreferencePage implementation of this method does
    * nothing.
    */
   public void init(IWorkbench workbench) {}

   /**
    * Retrieve the effective default value of an LPEX parameter.
    */
   static String getDefaultValue(String setting)
   {
      String value = LpexView.globalQuery("default." + setting);
      if ("install".equals(value))
         value = LpexView.globalQuery("install." + setting);
      return value;
   }
}