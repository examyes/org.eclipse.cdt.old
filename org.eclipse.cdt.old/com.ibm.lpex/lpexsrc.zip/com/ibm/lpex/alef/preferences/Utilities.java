//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Utilities - utilities for the LPEX preference pages.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import org.eclipse.swt.widgets.Control;
//import org.eclipse.jface.dialogs.IDialogPage;
//import org.eclipse.ui.help.DialogPageContextComputer;
import org.eclipse.ui.help.WorkbenchHelp;

/**
 * Utilities for the LPEX preference pages.
 */
final class Utilities
{
   /**
    * Set the context-help id for a Control inside an LPEX preference page.
    */
   static void setHelp(Control c, String helpId)
   {
      if (helpId != null)
         WorkbenchHelp.setHelp(c, "com.ibm.lpex." + helpId);
   }

// /**
//  * Set the context-help id for the Control of an LPEX preference page.
//  *
//  * <p>Usage examples:
//  * <pre>
//  *   // PreferencePage#createControl(Composite)
//  *   public void createControl(Composite parent)
//  *   {
//  *     super.createControl(parent);
//  *     Utilities.setHelp(getControl(), // retrieve top level control for this dialog page
//  *                       this, "pref_001");
//  *   } </pre>
//  *
//  * or:
//  * <pre>
//  *   // PreferencePage#createContents(Composite)
//  *   protected Control createContents(Composite parent)
//  *   {
//  *      Utilities.setHelp(parent, this, "pref_001");
//  *      return super.createContents(parent);
//  *   } </pre></p>
//  */
// static void setHelp(Control c, IDialogPage page, String helpId)
// {
//    if (helpId != null)
//       WorkbenchHelp.setHelp(c, new DialogPageContextComputer(page, "com.ibm.lpex." + helpId));
// }
}