//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParsersPreferencePage - parser - class preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import java.util.StringTokenizer;
import java.util.Vector;

import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;


/**
 * Preference page for LPEX's parser settings.
 * It lets the user add and remove registered parsers.
 */
public final class ParsersPreferencePage extends TablePreferencePage
{
   private static final String[] _valueTableNames =
    { LpexResources.message(LpexPreferencesConstants.MSG_PREFERENCES_PARSERS_TABLENAME),
      LpexResources.message(LpexPreferencesConstants.MSG_PREFERENCES_PARSERS_TABLECLASSNAME) };
   private static final String[] _valueNames =
    { LpexResources.message(LpexPreferencesConstants.MSG_PREFERENCES_PARSERS_NAME),
      LpexResources.message(LpexPreferencesConstants.MSG_PREFERENCES_PARSERS_CLASSNAME) };
   private static final String[] _helpIds = { "pref_028", "pref_029", "pref_030" };
   private static final int[] _valueWeights = { 30, 70 };


   /**
    * Return the names for the table columns.
    */
   protected String[] getValueTableNames()
   {
      return _valueTableNames;
   }

   /**
    * Return the names for the text-field labels.
    */
   protected String[] getValueNames()
   {
      return _valueNames;
   }

   /**
    * Return the context-help ids for the table and two text fields.
    */
   protected String[] getHelpIds()
   {
      return _helpIds;
   }

   /**
    * Return the column weights for the two columns in the table.
    */
   protected int[] getValueWeights()
   {
      return _valueWeights;
   }

   /**
    * Return a new vector of LpexTableItems with the initial settings
    * (the preference page is being initialized).
    */
   protected Vector initialize()
   {
      Vector items = new Vector();
      StringTokenizer st =
         new StringTokenizer(LpexView.globalQuery("current.updateProfile.parsers"));
      while (st.hasMoreTokens()) {
         String name = st.nextToken();
         String className = LpexView.globalQuery("current.updateProfile.parserClass." + name);
         if (className != null && className.length() > 0)
            items.addElement(new LpexTableItem(name, className));
         }
      return items;
   }

   /**
    * Return a new vector of LpexTableItems with the install settings
    * ("Default" button was pressed).
    */
   protected Vector initializeDefaults()
   {
      Vector items = new Vector();
      StringTokenizer st =
         new StringTokenizer(LpexView.globalQuery("install.updateProfile.parsers"));
      while (st.hasMoreTokens()) {
         String name = st.nextToken();
         String className = LpexView.globalQuery("install.updateProfile.parserClass." + name);
         if (className != null && className.length() > 0)
            items.addElement(new LpexTableItem(name, className));
         }
      return items;
   }

   /**
    * "OK" / "Apply" button pressed.  Commit any new updated values.
    */
   public boolean performOk()
   {
      boolean parserChanged = false;
      Vector items = getItems();

      // record parser definitions in effect
      Vector names = new Vector();
      StringTokenizer st =
         new StringTokenizer(LpexView.globalQuery("current.updateProfile.parsers"));
      while (st.hasMoreTokens())
         names.addElement(st.nextToken());

      // remove all parser definitions in effect which have been deleted
      for (int i = 0; i < names.size(); i++) {
         String name = (String)names.elementAt(i);
         boolean found = false;
         for (int j = 0; j < items.size(); j++) {
            String currentName = ((LpexTableItem)items.elementAt(j)).value1();
            if (name.equals(currentName)) {
               found = true;
               break;
               }
            }//end "for"
         if (!found) {
            // e.g., sets "default.updateProfile.parserClass.ILEcobol=null":
            // the ILEcobol parser will not be available, for all the views
            // that have updateProfile.parserClass.parser set to default, to
            // the updateProfile command
            LpexView.doGlobalCommand("set default.updateProfile.parserClass." + name);
            parserChanged = true;
            }
         }

      // add & update all other parser definitions from the table
      for (int i = 0; i < items.size(); i++) {
         LpexTableItem pi = (LpexTableItem)items.elementAt(i);
         String name = pi.value1();
         String className = pi.value2();
         String lpexClassName = getDefaultValue("updateProfile.parserClass." + name);
         if (!className.equals(lpexClassName)) {
            LpexView.doGlobalCommand("set default.updateProfile.parserClass." + name + " " +
                                     className);
            parserChanged = true;
            //-as- if default.xxx equals install.xxx, remove from Editor.properties
            }
         //-as- else { if a default.xxx setting in Editor.properties, clean it up }
         }

      if (parserChanged) {
         LpexView.doGlobalCommand("updateProfile all");
         LpexView.doGlobalCommand("screenShow");
         }
      return true;
   }
}