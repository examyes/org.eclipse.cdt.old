//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ViewBasePreferencePage - top LPEX preference page for a view.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;


/**
 * The main page of preferences for an LPEX view.
 * It handles save-related settings for the view.
 */
public final class ViewBasePreferencePage extends SavePreferencePage
                                          implements LpexPreferencesConstants
{
   public ViewBasePreferencePage(LpexView lpexView)
   {
      super(lpexView);
      setDescription(LpexResources.message(MSG_PREFERENCES_SAVE_TITLE));
   }
}