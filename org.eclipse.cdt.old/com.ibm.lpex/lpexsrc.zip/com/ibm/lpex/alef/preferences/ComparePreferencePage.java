//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ComparePreferencePage - compare preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import org.eclipse.swt.widgets.Composite;


/**
 * Preference page for LPEX's default compare settings.
 */
public final class ComparePreferencePage extends LpexFieldEditorPreferencePage
                                         implements LpexPreferencesConstants
{
   private boolean _initialIgnoreCase;
   private boolean _initialIgnoreLeadingBlanks;
   private boolean _initialIgnoreTrailingBlanks;
   private boolean _initialIgnoreAllBlanks;
   private LpexBooleanFieldEditor _ignoreCaseCheckBox;
   private LpexBooleanFieldEditor _ignoreLeadingBlanksCheckBox;
   private LpexBooleanFieldEditor _ignoreTrailingBlanksCheckBox;
   private LpexBooleanFieldEditor _ignoreAllBlanksCheckBox;

   public ComparePreferencePage()
   {
      super(LpexResources.message(MSG_PREFERENCES_COMPARE_TITLE), GRID);
   }

   protected void createFieldEditors()
   {
      _initialIgnoreCase           = defaultSetting("compare.ignoreCase");
      _initialIgnoreLeadingBlanks  = defaultSetting("compare.ignoreLeadingBlanks");
      _initialIgnoreTrailingBlanks = defaultSetting("compare.ignoreTrailingBlanks");
      _initialIgnoreAllBlanks      = defaultSetting("compare.ignoreAllBlanks");

      Composite parent = getFieldEditorParent();
      _ignoreCaseCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_COMPARE_IGNORECASE,
         _initialIgnoreCase, "pref_003");
      _ignoreLeadingBlanksCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_COMPARE_IGNORELEADINGBLANKS,
         _initialIgnoreLeadingBlanks, "pref_004");
      _ignoreTrailingBlanksCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_COMPARE_IGNORETRAILINGBLANKS,
         _initialIgnoreTrailingBlanks, "pref_005");
      _ignoreAllBlanksCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_COMPARE_IGNOREALLBLANKS,
         _initialIgnoreAllBlanks, "pref_006");
      addField(_ignoreCaseCheckBox);
      addField(_ignoreLeadingBlanksCheckBox);
      addField(_ignoreTrailingBlanksCheckBox);
      addField(_ignoreAllBlanksCheckBox);
   }

   // "OK" / "Apply" button pressed:  commit any new updated values, ensure any
   // changes are reflected correctly on the LPEX screens.
   public boolean performOk()
   {
      boolean performScreenShow =
         updateLpex(_ignoreCaseCheckBox, "compare.ignoreCase") |
         updateLpex(_ignoreLeadingBlanksCheckBox, "compare.ignoreLeadingBlanks") |
         updateLpex(_ignoreTrailingBlanksCheckBox, "compare.ignoreTrailingBlanks") |
         updateLpex(_ignoreAllBlanksCheckBox, "compare.ignoreAllBlanks");
      if (performScreenShow)
         LpexView.doGlobalCommand("screenShow");
      return true;
   }

   // "Defaults" button pressed:  set fields to the install settings, and do a
   // checkState() to recalculate page's error state.
   protected void performDefaults()
   {
      _ignoreCaseCheckBox.setSelected(installSetting("compare.ignoreCase"));
      _ignoreLeadingBlanksCheckBox.setSelected(installSetting("compare.ignoreLeadingBlanks"));
      _ignoreTrailingBlanksCheckBox.setSelected(installSetting("compare.ignoreTrailingBlanks"));
      _ignoreAllBlanksCheckBox.setSelected(installSetting("compare.ignoreAllBlanks"));
      super.performDefaults();
   }

   // "Reset" button pressed:  restore the initial preference page settings.
   protected void performReset()
   {
      _ignoreCaseCheckBox.setSelected(_initialIgnoreCase);
      _ignoreLeadingBlanksCheckBox.setSelected(_initialIgnoreLeadingBlanks);
      _ignoreTrailingBlanksCheckBox.setSelected(_initialIgnoreTrailingBlanks);
      _ignoreAllBlanksCheckBox.setSelected(_initialIgnoreAllBlanks);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   private boolean defaultSetting(String parameter)
   {
      return "on".equals(getDefaultValue(parameter));
   }

   private boolean installSetting(String parameter)
   {
      return "on".equals(LpexView.globalQuery("install." + parameter));
   }

   private boolean updateLpex(LpexBooleanFieldEditor checkBox, String parameter)
   {
      if (checkBox != null) {
         String defaultSetting = LpexView.globalQuery("default." + parameter);
         boolean setting = checkBox.getBooleanValue();
         boolean installSetting = "on".equals(LpexView.globalQuery("install." + parameter));
         if (installSetting == setting) {
            if (!(defaultSetting.equals("install"))) {
               LpexView.doGlobalCommand("set default." + parameter);
               return true;
               }
            }
         else if (defaultSetting.equals("install") || ((defaultSetting.equals("on")) != setting)) {
            LpexView.doGlobalCommand("set default." + parameter + " " + (setting? "on" : "off"));
            return true;
            }
         }
      return false;
   }
}