//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexStringFieldEditor - StringFieldEditor that works with LPEX's
// preference pages.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexResources;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.jface.preference.StringFieldEditor;


/**
 * A field editor for a string type preference.
 * The LPEX version mainly uses the layout and widget-control functions of
 * StringFieldEditor.
 * By default, the validation strategy is to revalidate on each keystroke,
 * and empty strings are considered valid.
 */
class LpexStringFieldEditor extends StringFieldEditor
{
   /**
    * Creates a string field editor of the given width and with an initial value.
    *
    * @param parent the parent of the field editor's control
    * @param labelKey key for the label text of the field editor
    * @param width the width of the text input field in characters,
    * @param initialValue initial string for the field
    * @param helpId context-help id
    */
   public LpexStringFieldEditor(Composite parent, String labelKey, int width,
                                String initialValue, String helpId)
   {
      super("" /*preferenceName*/, LpexResources.message(labelKey), width, parent);
      Utilities.setHelp(getTextControl(), helpId);

      // methods doLoad()/doLoadDefault() do nothing, so use setStringValue()
      // in order to record the field's oldValue for the purpose of firing
      // value-changed notifications, and ensure to refresh the validity state
      setStringValue(initialValue);
      refreshValidState();
   }

   /**
    * Creates a string field editor of unlimited width and with an initial value.
    * Use <code>setTextLimit()</code> to limit the text.
    *
    * @param parent the parent of the field editor's control
    * @param labelKey key for the label text of the field editor
    * @param initialValue initial string for the field
    * @param helpId context-help id
    */
   public LpexStringFieldEditor(Composite parent, String labelKey,
                                String initialValue, String helpId)
   {
      this(parent, labelKey, UNLIMITED, initialValue, helpId);
   }

   /**
    * Creates a string field editor of unlimited width.
    * Use <code>setTextLimit()</code> to limit the text.
    *
    * @param parent the parent of the field editor's control
    * @param labelKey key for the label text of the field editor
    * @param helpId context-help id
    */
   public LpexStringFieldEditor(Composite parent, String labelKey, String helpId)
   {
      this(parent, labelKey, UNLIMITED, null, helpId);
   }

   protected void doLoad() {}
   protected void doLoadDefault() {}
   protected void doStore() {}

   /**
    * Returns the field editor's value.
    * @return the current value (at least an empty String,
    *         never a <code>null</code>)
    */
   public String getStringValue()
   {
      Text textField = getTextControl();
      return (textField != null)? textField.getText() : "";
   }
}