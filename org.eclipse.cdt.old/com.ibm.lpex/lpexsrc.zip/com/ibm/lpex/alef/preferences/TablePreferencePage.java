//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// TablePreferencePage - base table preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.alef.LpexPlugin;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Text;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.jface.viewers.TableLayout;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;

import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;


/**
 * Abstract base preference page for LPEX settings presented in a table.
 * It manages a single-selection table of paired value1, value2 String items
 * (LpexTableItems), and two corresponding text fields for editing one table
 * item.
 */
abstract class TablePreferencePage extends PreferencePage implements IWorkbenchPreferencePage
{
   private int[] _valueWeights;

   private TableViewer _itemsList;
   private Button _setButton;
   private Button _deleteButton;
   private Text _value1TextField;
   private Text _value2TextField;

   private boolean _updatingTextFields;
   private boolean _updatingTableSelection;

   private Vector _items;         // table's items (a vector of LpexTableItems)
   private Vector _initialItems;  // keep the initial preference page settings


   // public TablePreferencePage() { super(); }

   /**
    * @see org.eclipse.jface.preference.PreferencePage#createContents(Composite)
    */
   protected Control createContents(Composite ancestor)
   {
      String[] valueTableNames = getValueTableNames();
      String[] valueNames = getValueNames();
      String[] helpIds = getHelpIds();
      _valueWeights = getValueWeights();

      _items = initialize();
      _initialItems = (Vector)_items.clone();

      /*-------------------------*/
      /*  table value1 + value2  */
      /*-------------------------*/
      Composite parent = new Composite(ancestor, SWT.NULL);
      GridLayout layout = new GridLayout();
      layout.numColumns = 2;
      parent.setLayout(layout);

      // single selection
      _itemsList = new TableViewer(parent, SWT.BORDER | SWT.FULL_SELECTION);
      Table table = _itemsList.getTable();
      GridData gd = new GridData(GridData.FILL_BOTH);
      // don't let preference page grow over its current dimensions
      // (OTHERS DO: gd.widthHint = convertWidthInCharsToPixels(70);)
      // but there is no client area laid out yet either...
      // (TRIED: gd.widthHint = parent.getClientArea().width;)
      gd.heightHint = (table.getItemHeight() /* +table.getGridLineWidth()*/) * 15;
                      // +table.computeSize(0,0,true).y; // header height!?
      table.setLayoutData(gd);

      _itemsList.setSorter(new ViewerSorter() {
         public int compare(Viewer viewer, Object e1, Object e2) {
            if ((e1 instanceof LpexTableItem) && (e2 instanceof LpexTableItem)) {
               String left  = ((LpexTableItem)e1).value1();
               String right = ((LpexTableItem)e2).value1();
               return left.compareTo(right);
               }
            return super.compare(viewer, e1, e2);
            }

         public boolean isSorterProperty(Object element, String property) {
            return true;
            }
         });

      table.setHeaderVisible(true);
      table.setLinesVisible(true);
      Utilities.setHelp(table, helpIds[0]);

      TableColumn column1 = new TableColumn(table, SWT.NULL);
      column1.setText(valueTableNames[0]);
      TableColumn column2 = new TableColumn(table, SWT.NULL);
      column2.setText(valueTableNames[1]);
      setTableLayout(); // do initial table layout (needed on at least Windows NT)

      // when another preference page increases & back here, the table is not
      // resized according to its column weights (disabled in TableLayout...)
      table.addControlListener(new ControlListener() {
         public void controlMoved(ControlEvent e) {}
         public void controlResized(ControlEvent e) {
            setTableLayout();
            }
         });

      _itemsList.setLabelProvider(new LabelProvider());
      _itemsList.setContentProvider(new ContentProvider(_itemsList, _items));

      _itemsList.addSelectionChangedListener(new ISelectionChangedListener() {
         public void selectionChanged(SelectionChangedEvent evt) {
            tableSelectionChanged();
            }
         });

      /*----------------------------*/
      /*  "Set" & "Delete" buttons  */
      /*----------------------------*/
      Composite buttons = new Composite(parent, SWT.NULL);
      buttons.setLayoutData(new GridData(GridData.VERTICAL_ALIGN_BEGINNING));
      buttons.setLayout(new GridLayout());

      _setButton = new Button(buttons, SWT.PUSH);
      _setButton.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
      _setButton.setText(LpexPlugin.getResourceString("preferences.set"));
      _setButton.addListener(SWT.Selection, new Listener() {
         public void handleEvent(Event evt) {
            setPressed();
            }
         });

      _deleteButton = new Button(buttons, SWT.PUSH);
      _deleteButton.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
      _deleteButton.setText(LpexPlugin.getResourceString("preferences.delete"));
      _deleteButton.addListener(SWT.Selection, new Listener() {
         public void handleEvent(Event e) {
            deletePressed();
            }
         });

      /*-------------------------------*/
      /*  value1 & value2 text fields  */
      /*-------------------------------*/
      Composite fieldsContainer = new Composite(parent, SWT.NULL);
      fieldsContainer.setLayoutData(new GridData(GridData.FILL_BOTH));
      GridLayout jreLayout = new GridLayout();
      jreLayout.numColumns = 2;
      fieldsContainer.setLayout(jreLayout);

      Label l = new Label(fieldsContainer, SWT.NULL);
      l.setText(valueNames[0]);
      l.setLayoutData(new GridData());
      _value1TextField = new Text(fieldsContainer, SWT.BORDER);
      _value1TextField.setLayoutData(new GridData(gd.FILL_HORIZONTAL));
      Utilities.setHelp(_value1TextField, helpIds[1]);
      _value1TextField.addModifyListener(new ModifyListener() {
         public void modifyText(ModifyEvent e) {
            updateTableSelection();
            }
         });

      l = new Label(fieldsContainer, SWT.NULL);
      l.setText(valueNames[1]);
      l.setLayoutData(new GridData());
      _value2TextField = new Text(fieldsContainer, SWT.BORDER);
      _value2TextField.setLayoutData(new GridData(gd.FILL_HORIZONTAL));
      Utilities.setHelp(_value2TextField, helpIds[2]);

      _itemsList.setInput(_items);
      enableButtons();
      //WorkbenchHelp.setHelp(parent, new DialogPageContextComputer(this, IJavaHelpContextIds.JRE_PREFERENCE_PAGE));
      return parent;
   }

   /**
    * Set the Table layout / re-set it after a resize.
    */
   private void setTableLayout()
   {
      TableLayout tableLayout = new TableLayout();
      _itemsList.getTable().setLayout(tableLayout);
      tableLayout.addColumnData(new ColumnWeightData(_valueWeights[0]));
      tableLayout.addColumnData(new ColumnWeightData(_valueWeights[1]));
   }

   /**
    * Initializes this preference page for the given workbench.
    * This method, defined by IWorkbenchPreferencePage, is called automatically
    * when the preference page defined in plugin.xml is being created and
    * initialized.
    *
    * <p>The TablePreferencePage implementation of this method does
    * nothing.
    */
   public void init(IWorkbench workbench) {}

   /**
    * Return the names for the table columns.
    */
   abstract protected String[] getValueTableNames();

   /**
    * Return the names for the text-field labels.
    */
   abstract protected String[] getValueNames();

   /**
    * Return the context-help ids for the table and the two text fields.
    */
   abstract protected String[] getHelpIds();

   /**
    * Return the column weights for the two columns in the table.
    */
   abstract protected int[] getValueWeights();

   /**
    * Enable/disable the "Set" and "Delete" buttons.
    */
   private void enableButtons()
   {
      _setButton.setEnabled(_value1TextField.getText().trim().length() != 0);
      _deleteButton.setEnabled(!_itemsList.getSelection().isEmpty());
   }

   /**
    * "Set" button pressed.
    * The value1 being edited is added / changed / removed.
    */
   private void setPressed()
   {
      String value1 = _value1TextField.getText().trim();
      if (value1.length() == 0)
         return;

      String value2 = _value2TextField.getText().trim();
      int index = indexOf(value1);

      // 1.- value1 is in the table, being changed / deleted
      if (index >= 0) {
         if (value2.length() == 0) {
            _items.removeElementAt(index);
            //fireTableRowsDeleted(index, index);
            _itemsList.refresh();
            }
         else {
            _items.setElementAt(new LpexTableItem(value1, value2), index);
            //fireTableCellUpdated(index, 1);
            _itemsList.refresh();
            selectItem(value1);
            }
         }
      // 2.- a new value1 is being set
      else {
         if (value2.length() > 0) {
            _items.addElement(new LpexTableItem(value1, value2));
            //fireTableRowsInserted(_items.size()-1, _items.size()-1);
            _itemsList.refresh();
            selectItem(value1);
            }
         }
   }

   /**
    * "Delete" button pressed.
    * The selected item is removed.
    */
   private void deletePressed()
   {
      IStructuredSelection selection = (IStructuredSelection)_itemsList.getSelection();
      Iterator elements = selection.iterator();
      while (elements.hasNext()) {
         Object o = elements.next();
         _items.remove(o);     // remove item from our vector
         _itemsList.remove(o); //  & viewer (_itemsList.refresh(); flashes more!?)
         }
   }

   /**
    * Contribute a "Reset" button.  Method performReset() is called when this
    * button is selected.
    *
    * @param buttonBar the preference-page button bar
    * @see org.eclipse.jface.preference.PreferencePage#contributeButtons
    * @see #performReset
    */
   protected void contributeButtons(Composite buttonBar)
   {
      // for each button contributed we must increment
      // the parent's grid layout number of columns
      ((GridLayout)buttonBar.getLayout()).numColumns++;

      Button resetButton = new Button(buttonBar, SWT.PUSH);
      resetButton.setFont(buttonBar.getFont());
      resetButton.setText(LpexPlugin.getResourceString("preferences.reset"));
      GridData data = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
      data.heightHint = convertVerticalDLUsToPixels(IDialogConstants.BUTTON_HEIGHT);
      data.widthHint = Math.max(convertHorizontalDLUsToPixels(IDialogConstants.BUTTON_WIDTH),
                                resetButton.computeSize(SWT.DEFAULT, SWT.DEFAULT, true).x);
      resetButton.setLayoutData(data);
      resetButton.addSelectionListener(
         new SelectionAdapter() {
            public void widgetSelected(SelectionEvent e) {
               performReset();
               }
            });
   }

   /**
    * "Defaults" button pressed.  Set the table to the install settings.
    */
   protected void performDefaults()
   {
      _value1TextField.setText("");
      _value2TextField.setText("");
      _items = initializeDefaults();
      _itemsList.setInput(_items); // not just refresh(), a new _items!

      //super.performDefaults();   // reenable "Apply" if page now valid
   }

   /**
    * "Reset" button pressed.  Restore the initial preference page settings.
    */
   protected void performReset()
   {
      _value1TextField.setText("");
      _value2TextField.setText("");
      _items = (Vector)_initialItems.clone();
      _itemsList.setInput(_items); // not just refresh(), a new _items!

      //checkState();              // to recalculate page's error state
      //updateApplyButton();       //  & to enable/disable the "Apply" button
   }

   /**
    * Return a new vector of LpexTableItems with the initial (current) settings
    * (the preference page is being initialized).
    */
   abstract protected Vector initialize();

   /**
    * Return a new vector of LpexTableItems with the install settings
    * ("Default" button was pressed).
    */
   abstract protected Vector initializeDefaults();

   /**
    * Retrieve the current vector of LpexTableItems in the table.
    */
   protected Vector getItems()
   {
      return _items;
   }

   /**
    * Table selection changed (by user mouse click / by us while tracking
    * the value1 text field being edited) - update the text fields.
    */
   private void tableSelectionChanged()
   {
      if (!_updatingTableSelection) {
         _updatingTextFields = true;
         IStructuredSelection selection = (IStructuredSelection)_itemsList.getSelection();
         Iterator elements = selection.iterator();
         while (elements.hasNext()) {
            Object o = elements.next();
            _value1TextField.setText(((LpexTableItem)o).value1());
            _value2TextField.setText(((LpexTableItem)o).value2());
            }
         _updatingTextFields = false;

         enableButtons();
         }
   }

   /**
    * Value1 is being edited in the text field - look for and try to select
    * the current value1 in the table.
    */
   private void updateTableSelection()
   {
      if (!_updatingTextFields)
         selectItem(_value1TextField.getText().trim());
   }

   /**
    * Select an item in the table, and ensure it shows.  If not in the table,
    * clear any existing selection.
    */
   private void selectItem(String value1)
   {
      _updatingTableSelection = true;
      int index = indexOf(value1);
      if (index == -1)
         _itemsList.getTable().deselectAll();
      else {
         // when editing value1 text field, any space typed is trimmed, unless
         // setting selection only when it's a really a new selection!?
         // (notifications are sent outside our _updatingXxx flags!?)
         //*as* instead of these flags, just remove the appropriate listener(s)
         // & reinstall them when we're done with the updates!?
         Object newSelection = elementOf(value1);
         Object oldSelection = ((IStructuredSelection)_itemsList.getSelection())
                                                                .getFirstElement();
         if (newSelection != oldSelection) {
            _itemsList.setSelection(new StructuredSelection(newSelection));
            _itemsList.reveal(newSelection);
            }
         }
      enableButtons();
      _updatingTableSelection = false;
   }

   /**
    * Return the index of value1 in _items.
    * @param value1 trimmed value1
    */
   private int indexOf(String value1)
   {
      int index = -1;
      for (int i = 0; i < _items.size(); i++) {
         String currentValue1 = ((LpexTableItem)_items.elementAt(i)).value1();
         if (currentValue1.equals(value1)) {
            index = i;
            break;
            }
         }
      return index;
   }

   /**
    * Return the element of value1 in _items.
    * @param value1 trimmed value1
    */
   private Object elementOf(String value1)
   {
      Object object = null;
      for (int i = 0; i < _items.size(); i++) {
         String currentValue1 = ((LpexTableItem)_items.elementAt(i)).value1();
         if (currentValue1.equals(value1)) {
            object = _items.elementAt(i);
            break;
            }
         }
      return object;
   }

   /**
    * Retrieve the effective default value of an LPEX parameter.
    */
   static String getDefaultValue(String setting)
   {
      String value = LpexView.globalQuery("default." + setting);
      if ("install".equals(value))
         value = LpexView.globalQuery("install." + setting);
      return value;
   }
}

class LpexTableItem
{
   private String _value1;
   private String _value2;

   LpexTableItem(String value1, String value2)
   {
      _value1 = value1;
      _value2 = value2;
   }

   String value1()
   {
      return _value1;
   }

   String value2()
   {
      return _value2;
   }
}

/**
 * Content provider for our table viewer.
 */
class ContentProvider implements IStructuredContentProvider
{
   public ContentProvider(StructuredViewer viewer, List input) {}
   public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {}
   public void dispose() {}

   /**
    * Return the elements to display in the viewer when its input is set to the
    * given element.  These elements can be presented as rows in a table, items
    * in a list, etc.  The result is not modified by the viewer.
    */
   public Object[] getElements(Object input)
   {
      // return an array containing all of the elements in the input list in
      // proper sequence;  the runtime type of the returned array is that of
      // the specified array
      return ((List)input).toArray();
   }
}

/**
 * Label provider for our table viewer.
 */
class LabelProvider implements ITableLabelProvider
{
   public void addListener(ILabelProviderListener listener) {}
   public void removeListener(ILabelProviderListener listener) {}
   public void dispose() {}
   public Image getColumnImage(Object element, int columnIndex) { return null; }
   public boolean isLabelProperty(Object element, String property) { return false; }

   public String getColumnText(Object element, int columnIndex)
   {
      if (element instanceof LpexTableItem) {
         switch(columnIndex) {
            case 0:
               return ((LpexTableItem)element).value1();
            case 1:
               return ((LpexTableItem)element).value2();
            }
         }
      return element.toString();
   }
}