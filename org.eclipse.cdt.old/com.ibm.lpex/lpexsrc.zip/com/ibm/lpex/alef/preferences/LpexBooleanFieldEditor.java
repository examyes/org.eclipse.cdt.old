//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexBooleanFieldEditor - BooleanFieldEditor that works with LPEX's
// preference pages.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexResources;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.jface.preference.BooleanFieldEditor;


/**
 * A field editor for a boolean type preference.
 * The LPEX version only uses the layout and widget-control functions of
 * BooleanFieldEditor.
 */
final class LpexBooleanFieldEditor extends BooleanFieldEditor
{
   private Button _checkBox; // can't access super's private checkBox

   /**
    * Creates a boolean field editor in the default style.
    *
    * @param parent the parent of the field editor's control
    * @param labelKey key for the label text of the field editor
    * @param helpId context-help id
    */
   public LpexBooleanFieldEditor(Composite parent, String labelKey, String helpId)
   {
      super("" /*preferenceName*/, LpexResources.message(labelKey), DEFAULT, parent);
      Utilities.setHelp(_checkBox, helpId);
   }

   /**
    * Creates a boolean field editor in the default style and
    * with an initial value.
    *
    * @param parent the parent of the field editor's control
    * @param labelKey key for the label text of the field editor
    * @param initialValue field's initial value
    * @param helpId context-help id
    */
   public LpexBooleanFieldEditor(Composite parent, String labelKey,
                                 boolean initialValue, String helpId)
   {
      this(parent, labelKey, helpId);

      // methods doLoad()/doLoadDefault() do nothing: set an initial value here
      setSelected(initialValue);
   }

   protected Button getChangeControl(Composite parent)
   {
      // steal super's private checkBox...
      _checkBox = super.getChangeControl(parent);
      return _checkBox;
   }

   void setSelected(boolean value)
   {
      if (_checkBox != null && !_checkBox.isDisposed())
         _checkBox.setSelection(value);
      // should keep track of wasSelected & fire value-changed notifications!?...
   }

   String getOnOffValue()
   {
      return getBooleanValue()? "on" : "off";
   }

   protected void doLoad() {}
   protected void doLoadDefault() {}
   protected void doStore() {}
}