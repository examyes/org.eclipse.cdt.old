//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FindTextPreferencePage - default findText setting preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexStringTokenizer;
import com.ibm.lpex.core.LpexView;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;


/**
 * Preference page for LPEX's default findText settings.
 */
public final class FindTextPreferencePage extends LpexFieldEditorPreferencePage
                                          implements LpexPreferencesConstants
{
   private String _initialAsis;
   private String _initialBlock;
   private String _initialColumns;
   private String _initialEmphasis;
   private String _initialEndColumn;
   private String _initialFindText;
   private String _initialMark;
   private String _initialRegularExpression;
   private String _initialReplaceText;
   private String _initialStartColumn;
   private String _initialWrap;
   private LpexBooleanFieldEditor _asisCheckBox;
   private LpexBooleanFieldEditor _blockCheckBox;
   private LpexBooleanFieldEditor _columnsCheckBox;
   private LpexBooleanFieldEditor _emphasisCheckBox;
   private LpexIntegerFieldEditor _endColumnField;
   private LpexStringFieldEditor  _findTextField;
   private LpexBooleanFieldEditor _markCheckBox;
   private LpexBooleanFieldEditor _regularExpressionCheckBox;
   private LpexStringFieldEditor  _replaceTextField;
   private LpexIntegerFieldEditor _startColumnField;
   private LpexBooleanFieldEditor _wrapCheckBox;


   public FindTextPreferencePage()
   {
      super(LpexResources.message(MSG_PREFERENCES_FIND_TEXT_TITLE), GRID);
   }

   protected void createFieldEditors()
   {
      Composite parent = getFieldEditorParent();

      _asisCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_FIND_TEXT_ASIS, "pref_014");
      _blockCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_FIND_TEXT_BLOCK, "pref_015");
      _emphasisCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_FIND_TEXT_EMPHASIS, "pref_016");
      _markCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_FIND_TEXT_MARK, "pref_017");
      _regularExpressionCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_FIND_TEXT_REGULAR_EXPRESSION, "pref_018");
      _wrapCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_FIND_TEXT_WRAP, "pref_019");
      _columnsCheckBox = new LpexBooleanFieldEditor(parent,
         MSG_PREFERENCES_FIND_TEXT_COLUMNS, "pref_020");
      _startColumnField = new LpexIntegerFieldEditor(parent,
         MSG_PREFERENCES_FIND_TEXT_START_COLUMN, "pref_021");
      _endColumnField = new LpexIntegerFieldEditor(parent,
         MSG_PREFERENCES_FIND_TEXT_END_COLUMN, "pref_022");

      // gap (two-column wide)
      new Label(parent, 0);
      new Label(parent, 0);

      _findTextField = new LpexStringFieldEditor(parent,
         MSG_PREFERENCES_FIND_TEXT_FIND_TEXT, "pref_023");
      _replaceTextField = new LpexStringFieldEditor(parent,
         MSG_PREFERENCES_FIND_TEXT_REPLACE_TEXT, "pref_024");
      addField(_asisCheckBox);
      addField(_blockCheckBox);
      addField(_emphasisCheckBox);
      addField(_markCheckBox);
      addField(_regularExpressionCheckBox);
      addField(_wrapCheckBox);
      addField(_columnsCheckBox);
      addField(_startColumnField);
      addField(_endColumnField);
      addField(_findTextField);
      addField(_replaceTextField);

      _initialAsis = getDefaultValue("findText.asis");
      _initialBlock = getDefaultValue("findText.block");
      _initialColumns = getDefaultValue("findText.columns");
      _initialEmphasis = getDefaultValue("findText.emphasis");
      _initialEndColumn = getDefaultValue("findText.endColumn");
      _initialFindText = getDefaultValue("findText.findText");
      _initialMark = getDefaultValue("findText.mark");
      _initialRegularExpression = getDefaultValue("findText.regularExpression");
      _initialReplaceText = getDefaultValue("findText.replaceText");
      _initialStartColumn = getDefaultValue("findText.startColumn");
      _initialWrap = getDefaultValue("findText.wrap");
      performReset();
   }

   // "OK" / "Apply" button pressed:  commit any new updated values.
   public boolean performOk()
   {
      setDefaultValue("findText.asis", _asisCheckBox.getOnOffValue());
      setDefaultValue("findText.block", _blockCheckBox.getOnOffValue());
      setDefaultValue("findText.columns", _columnsCheckBox.getOnOffValue());
      setDefaultValue("findText.emphasis", _emphasisCheckBox.getOnOffValue());
      setDefaultValue("findText.endColumn", _endColumnField.getStringValue());
      setDefaultValue("findText.findText",
                      LpexStringTokenizer.addQuotes(_findTextField.getStringValue()));
      setDefaultValue("findText.mark", _markCheckBox.getOnOffValue());
      setDefaultValue("findText.regularExpression", _regularExpressionCheckBox.getOnOffValue());
      setDefaultValue("findText.replaceText",
                      LpexStringTokenizer.addQuotes(_replaceTextField.getStringValue()));
      setDefaultValue("findText.startColumn", _startColumnField.getStringValue());
      setDefaultValue("findText.wrap", _wrapCheckBox.getOnOffValue());
      return true;
   }

   // "Defaults" button pressed:  set fields to the install setting, and do a
   // checkState() to recalculate page's error state.
   protected void performDefaults()
   {
      updateSettings(LpexView.globalQuery("install.findText.asis"),
                     LpexView.globalQuery("install.findText.block"),
                     LpexView.globalQuery("install.findText.columns"),
                     LpexView.globalQuery("install.findText.emphasis"),
                     LpexView.globalQuery("install.findText.endColumn"),
                     LpexView.globalQuery("install.findText.findText"),
                     LpexView.globalQuery("install.findText.mark"),
                     LpexView.globalQuery("install.findText.regularExpression"),
                     LpexView.globalQuery("install.findText.replaceText"),
                     LpexView.globalQuery("install.findText.startColumn"),
                     LpexView.globalQuery("install.findText.wrap"));
      super.performDefaults();
   }

   // "Reset" button pressed:  set/restore fields to their initial settings.
   protected void performReset()
   {
      updateSettings(_initialAsis,
                     _initialBlock,
                     _initialColumns,
                     _initialEmphasis,
                     _initialEndColumn,
                     _initialFindText,
                     _initialMark,
                     _initialRegularExpression,
                     _initialReplaceText,
                     _initialStartColumn,
                     _initialWrap);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   private void updateSettings(String asis,
                               String block,
                               String columns,
                               String emphasis,
                               String endColumn,
                               String findText,
                               String mark,
                               String regularExpression,
                               String replaceText,
                               String startColumn,
                               String wrap)
   {
      _asisCheckBox.setSelected("on".equals(asis));
      _blockCheckBox.setSelected("on".equals(block));
      _columnsCheckBox.setSelected("on".equals(columns));
      _emphasisCheckBox.setSelected("on".equals(emphasis));
      _endColumnField.setStringValue(endColumn);
      _findTextField.setStringValue((findText != null)?
         LpexStringTokenizer.removeQuotes(findText) : "");
      _markCheckBox.setSelected("on".equals(mark));
      _regularExpressionCheckBox.setSelected("on".equals(regularExpression));
      _replaceTextField.setStringValue((replaceText != null)?
         LpexStringTokenizer.removeQuotes(replaceText) : "");
      _startColumnField.setStringValue(startColumn);
      _wrapCheckBox.setSelected("on".equals(wrap));
   }

   private void setDefaultValue(String setting, String value)
   {
      if (!value.equals(getDefaultValue(setting)))
         LpexView.doGlobalCommand("set default." + setting + " " + value);
   }
}