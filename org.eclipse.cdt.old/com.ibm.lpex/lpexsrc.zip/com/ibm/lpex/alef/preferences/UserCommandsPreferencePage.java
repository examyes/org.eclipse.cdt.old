//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// UserCommandsPreferencePage - user-defined commands preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import java.util.StringTokenizer;
import java.util.Vector;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;


/**
 * Preference page for user commands.
 * It lets the user add and remove user-defined editor commands.
 */
public final class UserCommandsPreferencePage extends TablePreferencePage
{
   private static final String[] _valueTableNames =
    { LpexResources.message(LpexConstants.MSG_PREFERENCES_USER_COMMANDS_TABLE_NAME),
      LpexResources.message(LpexConstants.MSG_PREFERENCES_USER_COMMANDS_TABLE_CLASS_NAME) };
   private static final String[] _valueNames =
    { LpexResources.message(LpexConstants.MSG_PREFERENCES_USER_COMMANDS_NAME),
      LpexResources.message(LpexConstants.MSG_PREFERENCES_USER_COMMANDS_CLASS_NAME) };
   private static final String[] _helpIds = { "pref_052", "pref_053", "pref_054" };
   private static final int[] _valueWeights = { 50, 50 };


   /**
    * Return the names for the table columns.
    */
   protected String[] getValueTableNames()
   {
      return _valueTableNames;
   }

   /**
    * Return the names for the text-field labels.
    */
   protected String[] getValueNames()
   {
      return _valueNames;
   }

   /**
    * Return the context-help ids for the table and two text fields.
    */
   protected String[] getHelpIds()
   {
      return _helpIds;
   }

   /**
    * Return the column weights for the two columns in the table.
    */
   protected int[] getValueWeights()
   {
      return _valueWeights;
   }

   /**
    * Return a new vector of LpexTableItems with the initial (current) settings
    * (the preference page is being initialized).
    */
   protected Vector initialize()
   {
      return updateSettings(LpexView.globalQuery("current.updateProfile.userCommands"));
   }

   /**
    * Return a new vector of LpexTableItems with the install settings
    * ("Default" button was pressed).
    */
   protected Vector initializeDefaults()
   {
      return updateSettings(LpexView.globalQuery("install.updateProfile.userCommands"));
   }

   /**
    * Return a new vector of LpexTableItems with the settings in the provided
    * userCommands.
    */
   private Vector updateSettings(String userCommands)
   {
      Vector items = new Vector();
      if (userCommands != null) {
         StringTokenizer st = new StringTokenizer(userCommands);
         while (st.hasMoreTokens()) {
            String commandName = st.nextToken();
            if (st.hasMoreTokens())
               items.addElement(new LpexTableItem(commandName, st.nextToken()));
            }
         }
      return items;
   }

   /**
    * "OK" / "Apply" button pressed.  Commit any new updated values.
    */
   public boolean performOk()
   {
      Vector items = getItems();

      String newUserCommands = "";
      boolean first = true;
      for (int i = 0; i < items.size(); i++) {
         if (!first)
            newUserCommands += " ";
         first = false;
         LpexTableItem pi = (LpexTableItem)items.elementAt(i);
         newUserCommands += pi.value1() + " " + pi.value2(); // command name + class
         }

      if (!newUserCommands.equals(LpexView.globalQuery("current.updateProfile.userCommands"))) {
         LpexView.doGlobalCommand("set default.updateProfile.userCommands " + newUserCommands);
         //-as- if newUserCommands empty, clean it up from Editor.properties
         LpexView.doGlobalCommand("updateProfile all");
         }
      return true;
   }
}