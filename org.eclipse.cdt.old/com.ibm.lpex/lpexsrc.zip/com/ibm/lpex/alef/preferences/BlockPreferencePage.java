//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// BlockPreferencePage - block settings preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;


/**
 * Preference page for LPEX's default block settings.
 */
public final class BlockPreferencePage extends LpexFieldEditorPreferencePage
{
   private static final String[] _blockTypes =
      { "character", "element", "rectangle", "stream" };
   private static String[] _blockTypeNames = new String[4]; // NLS block-type names

   private int _initialBlockType;
   private LpexListEditor _blockTypeList;


   public BlockPreferencePage()
   {
      super(LpexResources.message(LpexPreferencesConstants.MSG_PREFERENCES_BLOCK_TITLE),
            GRID);
   }

   protected void createFieldEditors()
   {
      for (int i = 0; i < _blockTypeNames.length; i++) {
         _blockTypeNames[i] = LpexResources.message("blockType." + _blockTypes[i]);
         if (_blockTypeNames[i] == null)
            _blockTypeNames[i] = _blockTypes[i];
         }

      _blockTypeList = new LpexListEditor(getFieldEditorParent(),
                                   LpexPreferencesConstants.MSG_PREFERENCES_BLOCK_DEFAULT_TYPE,
                                   _blockTypeNames, "pref_002");
      addField(_blockTypeList);

      _initialBlockType = defaultBlockType();
      updateSettings(_initialBlockType);
   }

   // "OK" / "Apply" button pressed:  commit any new updated values.
   public boolean performOk()
   {
      int index = _blockTypeList.getSelectedIndex();
      if (index != defaultBlockType() && index >= 0 && index < _blockTypes.length) {
         String blockType = _blockTypes[index];
         LpexView.doGlobalCommand("set default.block.defaultType " + blockType);
         }
      return true;
   }

   // "Defaults" button pressed:  set fields to the install settings, and do a
   // checkState() to recalculate page's error state.
   protected void performDefaults()
   {
      updateSettings(installBlockType());
      super.performDefaults();
   }

   // "Reset" button pressed:  restore the initial preference page settings.
   protected void performReset()
   {
      updateSettings(_initialBlockType);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   // select the given index's block type in the list
   private void updateSettings(int index)
   {
      if (index != -1)
         _blockTypeList.setSelectedIndex(index);
      else
         _blockTypeList.clearSelection();
   }

   private int defaultBlockType()
   {
      return blockTypeIndex(getDefaultValue("block.defaultType"));
   }

   private int installBlockType()
   {
      return blockTypeIndex(LpexView.globalQuery("install.block.defaultType"));
   }

   private int blockTypeIndex(String blockType)
   {
      for (int i = 0; i < _blockTypes.length; i++) {
         if (_blockTypes[i].equals(blockType))
            return i;
         }
      return -1;
   }
}