//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexComboEditor - LpexListEditor using a Combo box instead.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexResources;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Combo;

import org.eclipse.jface.preference.FieldEditor;


/**
 * A field editor that manages a combo (a list + an editable text field) with
 * input values.
 * @see LpexListEditor
 */
final class LpexComboEditor extends FieldEditor
{
   private Combo _combo;


   /**
    * Creates a combo field editor.
    *
    * @param labelKey key of the label text of the field editor
    * @param parent the parent of the field editor's control
    * @param values list of strings for the list
    */
   protected LpexComboEditor(String labelKey, Composite parent, String[] values)
   {
      init("" /*preferenceName*/, LpexResources.message(labelKey));
      createControl(parent);
      for (int i = 0; i < values.length; i++)
         _combo.add(values[i]);
   }

   String getStringValue()
   {
      return _combo.getText();
   }

   // the index in the list will be selected automatically if value is in list
   void setStringValue(String value)
   {
      _combo.setText((value != null)? value : "");
   }

   /**
    * Adjust the horizontal span of this field editor's basic controls.
    * We must adjust the horizontal span of controls so they appear correct in
    * the given number of columns.  The number of columns is always equal to
    * or greater than the value returned by this editor's getNumberOfControls().
    */
   protected void adjustForNumColumns(int numColumns)
   {
      Control control = getLabelControl();
      // keep the label to show above the combo
      ((GridData)control.getLayoutData()).horizontalSpan = numColumns;
      ((GridData)_combo.getLayoutData()).horizontalSpan = numColumns;
   }

   /**
    * Fills this field editor's basic controls into the given parent.
    * We must implement this method to create the controls for this field editor.
    * @param parent the composite used as a parent for the basic controls;
    *               the parent's layout must be a GridLayout
    * @param numColumns the number of columns
    */
   protected void doFillIntoGrid(Composite parent, int numColumns)
   {
      Control control = getLabelControl(parent);
      GridData gd = new GridData();
      gd.horizontalSpan = numColumns;
      control.setLayoutData(gd);

      _combo = getComboControl(parent);
      gd = new GridData(GridData.FILL_HORIZONTAL);
      gd.verticalAlignment = gd.FILL;
      gd.horizontalSpan = numColumns;
      _combo.setLayoutData(gd);
   }

   protected void doLoad() {}
   protected void doLoadDefault() {}
   protected void doStore() {}

   /**
    * Returns this field editor's combo control.
    *
    * @param parent the parent control
    * @return the combo control
    */
   public Combo getComboControl(Composite parent)
   {
      if (_combo == null) {
         _combo = new Combo(parent, SWT.BORDER | SWT.SINGLE);
         _combo.addDisposeListener(new DisposeListener() {
            public void widgetDisposed(DisposeEvent event) {
               _combo = null;
               }
            });
         _combo.addModifyListener(new ModifyListener() {
               public void modifyText(ModifyEvent e) {
                  valueChanged();
               }
            });
         }
      else
         checkParent(_combo, parent);

      return _combo;
   }

   /**
    * Return the number of basic controls this field editor consists of.
    */
   public int getNumberOfControls()
   {
      return 2; // label + combo
   }

   public void setFocus()
   {
      if (_combo != null)
         _combo.setFocus();
   }

   /**
    * Text field's value changed.  The LpexComboEditor implementation of this
    * method just clears the preference page's error message.
    */
   private void valueChanged()
   {
      clearErrorMessage();
   }
}