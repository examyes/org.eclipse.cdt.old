//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SaveBasePreferencePage - LPEX preference page for save-related settings.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexStringTokenizer;
import com.ibm.lpex.core.LpexView;

import org.eclipse.swt.widgets.Composite;


/**
 * Preference page with save-related settings for one LPEX view,
 * or default settings for the entire editor.
 */
public class SavePreferencePage extends LpexFieldEditorPreferencePage
{
   private LpexView _lpexView;
   private String _initialTrim;
   private String _initialTextLimit;
   private LpexBooleanFieldEditor _trimCheckBox;
   private LpexIntegerFieldEditor _textLimitTextField;


   /**
    * Preference-page constructor for one LPEX view's save settings.
    * This is currently the base preference page of an LPEX view.
    */
   public SavePreferencePage(LpexView lpexView)
   {
      super(lpexView.query("name"), GRID);
      _lpexView = lpexView;
   }

   /**
    * Preference-page constructor for default save-related settings.
    */
   public SavePreferencePage()
   {
      super(LpexResources.message(LpexConstants.MSG_PREFERENCES_SAVE_TITLE), GRID);
   }

   protected void createFieldEditors()
   {
      Composite parent = getFieldEditorParent();

      _trimCheckBox = new LpexBooleanFieldEditor(
         LpexConstants.MSG_PREFERENCES_SAVE_TRIM, parent);
      _textLimitTextField = new LpexIntegerFieldEditor(
         LpexConstants.MSG_PREFERENCES_SAVE_TEXT_LIMIT, parent);

      addField(_trimCheckBox);
      addField(_textLimitTextField);

      if (_lpexView != null) { // view settings - use the view values
         _initialTrim = _lpexView.query("current.save.trim");
         _initialTextLimit = _lpexView.query("current.save.textLimit");
         }
      else {                   // global settings - use the default values
         _initialTrim = LpexView.globalQuery("current.save.trim");
         _initialTextLimit = LpexView.globalQuery("current.save.textLimit");
         }
      updateSettings(_initialTrim, _initialTextLimit);
   }

   // "OK" / "Apply" button pressed:  commit new values.
   public boolean performOk()
   {
      boolean refresh; // a truncation message may be displayed by LPEX...
      if (_lpexView != null) { // view settings
         setValue("save.trim", _trimCheckBox.getOnOffValue());
         refresh = setValue("save.textLimit", _textLimitTextField.getStringValue());
         }
      else {                   // global settings
         setDefaultValue("save.trim", _trimCheckBox.getOnOffValue());
         refresh = setDefaultValue("save.textLimit", _textLimitTextField.getStringValue());
         }

      if (refresh)
         LpexView.doGlobalCommand("screenShow");
      return true;
   }

   // "Defaults" button pressed:  set fields to the install/default settings,
   // do a checkState() to recalculate page's error state.
   protected void performDefaults()
   {
      if (_lpexView != null)   // view settings - use the default values
         updateSettings(LpexView.globalQuery("current.save.trim"),
                        LpexView.globalQuery("current.save.textLimit"));
      else                    // global settings - use the install values
         updateSettings(LpexView.globalQuery("install.save.trim"),
                        LpexView.globalQuery("install.save.textLimit"));
      super.performDefaults();
   }

   // "Reset" button pressed:  restore initial preference page settings.
   protected void performReset()
   {
      updateSettings(_initialTrim, _initialTextLimit);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   private void updateSettings(String trim, String textLimit)
   {
      _trimCheckBox.setSelected("on".equals(trim));
      _textLimitTextField.setStringValue(textLimit);
   }


   private boolean setValue(String setting, String value)
   {
      if (!value.equals(_lpexView.query("current." + setting))) {
         _lpexView.doCommand("set " + setting + " " + value);
         return true;
         }
      return false;
   }

   private boolean setDefaultValue(String setting, String value)
   {
      if (!value.equals(LpexView.globalQuery("current." + setting))) {
         LpexView.doGlobalCommand("set default." + setting + " " + value);
         return true;
         }
      return false;
   }
}