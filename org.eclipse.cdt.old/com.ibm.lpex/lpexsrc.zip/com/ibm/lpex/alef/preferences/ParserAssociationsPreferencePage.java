//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ParserAssociationsPreferencePage - file extension - parser preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import java.util.StringTokenizer;
import java.util.Vector;

import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;


/**
 * Preference page for LPEX's parser associations.
 * It lets the user add and remove parser associations with file extensions.
 */
public final class ParserAssociationsPreferencePage extends TablePreferencePage
{
   private static final String[] _valueTableNames =
    { LpexResources.message(LpexPreferencesConstants.MSG_PREFERENCES_PARSER_ASSOCIATIONS_TABLEEXTENSION),
      LpexResources.message(LpexPreferencesConstants.MSG_PREFERENCES_PARSER_ASSOCIATIONS_TABLEPARSER) };
   private static final String[] _valueNames =
    { LpexResources.message(LpexPreferencesConstants.MSG_PREFERENCES_PARSER_ASSOCIATIONS_EXTENSION),
      LpexResources.message(LpexPreferencesConstants.MSG_PREFERENCES_PARSER_ASSOCIATIONS_PARSER) };
   private static final String[] _helpIds = { "pref_025", "pref_026", "pref_027" };
   private static final int[] _valueWeights = { 50, 50 };


   /**
    * Return the names for the table columns.
    */
   protected String[] getValueTableNames()
   {
      return _valueTableNames;
   }

   /**
    * Return the names for the text-field labels.
    */
   protected String[] getValueNames()
   {
      return _valueNames;
   }

   /**
    * Return the context-help ids for the table and two text fields.
    */
   protected String[] getHelpIds()
   {
      return _helpIds;
   }

   /**
    * Return the column weights for the two columns in the table.
    */
   protected int[] getValueWeights()
   {
      return _valueWeights;
   }

   /**
    * Return a new vector of LpexTableItems with the initial settings
    * (the preference page is being initialized).
    */
   protected Vector initialize()
   {
      Vector items = new Vector();
      StringTokenizer st =
         new StringTokenizer(LpexView.globalQuery("current.updateProfile.extensions"));
      while (st.hasMoreTokens()) {
         String extension = st.nextToken();
         String parser = LpexView.globalQuery("current.updateProfile.parserAssociation." + extension);
         if (parser != null && parser.length() > 0)
            items.addElement(new LpexTableItem(extension, parser));
         }
      return items;
   }

   /**
    * Return a new vector of LpexTableItems with the install settings
    * ("Default" button was pressed).
    */
   protected Vector initializeDefaults()
   {
      Vector items = new Vector();
      StringTokenizer st =
         new StringTokenizer(LpexView.globalQuery("install.updateProfile.extensions"));
      while (st.hasMoreTokens()) {
         String extension = st.nextToken();
         String parser = LpexView.globalQuery("install.updateProfile.parserAssociation." + extension);
         if (parser != null && parser.length() > 0)
            items.addElement(new LpexTableItem(extension, parser));
         }
      return items;
   }

   /**
    * "OK" / "Apply" button pressed.  Commit any new updated values.
    */
   public boolean performOk()
   {
      boolean parserAssociationChanged = false;
      Vector items = getItems();

      // record parser definitions in effect
      Vector extensions = new Vector();
      StringTokenizer st =
         new StringTokenizer(LpexView.globalQuery("current.updateProfile.extensions"));
      while (st.hasMoreTokens())
         extensions.addElement(st.nextToken());

      // remove all parser definitions in effect which have been deleted
      for (int i = 0; i < extensions.size(); i++) {
         String extension = (String)extensions.elementAt(i);
         boolean found = false;
         for (int j = 0; j < items.size(); j++) {
            String currentExtension = ((LpexTableItem)items.elementAt(j)).value1();
            if (extension.equals(currentExtension)) {
               found = true;
               break;
               }
            }//end "for"
         if (!found) {
            // e.g., sets "default.updateProfile.parserAssociation.ASM=null":
            // no default parser will be associated with the ASM file extension
            LpexView.doGlobalCommand("set default.updateProfile.parserAssociation." + extension);
            parserAssociationChanged = true;
            }
         }

      // add & update all other parser definitions from the table
      for (int i = 0; i < items.size(); i++) {
         LpexTableItem pi = (LpexTableItem)items.elementAt(i);
         String extension = pi.value1();
         String parser = pi.value2();
         String lpexParser = getDefaultValue("updateProfile.parserAssociation." + extension);
         if (!parser.equals(lpexParser)) {
            LpexView.doGlobalCommand("set default.updateProfile.parserAssociation." + extension + " " +
                                     parser);
            parserAssociationChanged = true;
            //-as- if default.xxx equals install.xxx, remove from Editor.properties
            }
         //-as- else { if a default.xxx setting in Editor.properties, clean it up }
         }

      if (parserAssociationChanged) {
         LpexView.doGlobalCommand("updateProfile all");
         LpexView.doGlobalCommand("screenShow");
         }
      return true;
   }
}