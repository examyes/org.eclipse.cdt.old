//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// UserProfilePreferencePage - user-profile preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import org.eclipse.swt.widgets.Composite;


/**
 * Preference page for LPEX's user profile.
 */
public final class UserProfilePreferencePage extends LpexFieldEditorPreferencePage
{
   private String _initialUserProfile;
   private LpexStringFieldEditor _userProfileTextField;


   public UserProfilePreferencePage()
   {
      super(LpexResources.message(LpexPreferencesConstants.MSG_PREFERENCES_USER_PROFILE_TITLE),
            GRID);
   }

   protected void createFieldEditors()
   {
      _initialUserProfile = LpexView.globalQuery("current.updateProfile.userProfile");

      _userProfileTextField = new ClassNameStringFieldEditor(getFieldEditorParent(),
                                   LpexPreferencesConstants.MSG_PREFERENCES_USER_PROFILE_CLASS_NAME,
                                   _initialUserProfile, "pref_051");
      addField(_userProfileTextField);
   }

   // "OK" / "Apply" button pressed:  commit any new updated values and run the
   // updateProfile command (which will also run the newly-set user profile),
   // ensure changes are reflected correctly on the LPEX screens.
   public boolean performOk()
   {
      if (setDefaultValue("updateProfile.userProfile",
                          _userProfileTextField.getStringValue().trim())) {
         LpexView.doGlobalCommand("updateProfile all");
         LpexView.doGlobalCommand("screenShow");
         }
      return true;
   }

   // "Defaults" button pressed:  set field to the install setting, and do a
   // checkState() to recalculate page's error state.
   protected void performDefaults()
   {
      updateSettings(LpexView.globalQuery("install.updateProfile.userProfile"));
      super.performDefaults();
   }

   // "Reset" button pressed:  restore fields to their initial settings.
   protected void performReset()
   {
      updateSettings(_initialUserProfile);
      //checkState();        // to recalculate page's error state
      //updateApplyButton(); //  & to enable/disable the "Apply" button
   }

   private void updateSettings(String userProfile)
   {
      _userProfileTextField.setStringValue(userProfile);
   }

   private boolean setDefaultValue(String setting, String value)
   {
     if (!value.equals(LpexView.globalQuery("current." + setting))) {
        LpexView.doGlobalCommand("set default." + setting + " " + value);
        return true;
        }
     return false;
   }

   static class ClassNameStringFieldEditor extends LpexStringFieldEditor
   {
      public ClassNameStringFieldEditor(Composite parent, String labelKey,
                                        String initialValue, String helpId)
      {
         super(parent, labelKey, initialValue, helpId);
      }

      // basic class name validation
      protected boolean doCheckState()
      {
         String value = getStringValue().trim();
         boolean valid = value.indexOf(' ') == -1;
         if (!valid)
            setErrorMessage(LpexResources.message(LpexConstants.MSG_CLASSNAME_INVALID, value));
         return valid;
      }
   }
}