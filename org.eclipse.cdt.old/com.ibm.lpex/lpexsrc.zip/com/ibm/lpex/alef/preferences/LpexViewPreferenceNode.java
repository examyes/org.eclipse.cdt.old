//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// LpexViewPreferenceNode - PreferenceNode for the LPEX view preference page(s).
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;
import org.eclipse.jface.preference.IPreferencePage;
import org.eclipse.jface.preference.PreferenceNode;


/**
 * PreferenceNode for the LPEX view preference pages.
 */
public class LpexViewPreferenceNode extends PreferenceNode
                                    implements LpexPreferencesConstants
{
   private static int _nodeId;      // a running id for these nodes

   public static final int          // node type
      VIEW_BASE_NODE             = 0,
      VIEW_PARSER_NODE           = 1,
      VIEW_SEQUENCE_NUMBERS_NODE = 2,
      VIEW_SOURCE_ENCODING_NODE  = 3;
   private int _nodeType;

   private LpexView _lpexView;      // LpexView associated with the node


   /**
    * Constructor for the LPEX view base preference page node.
    * @see #LpexViewPreferenceNode(LpexView,int)
    */
   public LpexViewPreferenceNode(LpexView lpexView)
   {
      super("LPEX" + _nodeId++);

      // //*as* in order to display an image for the view preference item, must use
      // // the 'complete' constructor - because there is no way to setImageDescriptor()...
      // // Don't do it right now, *all* "Preferences" tree item texts will have gaps!!
      // // import org.eclipse.jface.resource.ImageDescriptor;
      // super("LPEX" + _nodeId++,
      //  lpexView.query("name"),
      //  ImageDescriptor.createFromFile(LpexPlugin.class, "icons/full/obj16/editor_obj.gif"),
      //  null);
      _lpexView = lpexView;
   }

   /**
    * Constructor for an LPEX view child preference page node.
    * @see #LpexViewPreferenceNode(LpexView)
    */
   public LpexViewPreferenceNode(LpexView lpexView, int nodeType)
   {
      super("LPEX" + _nodeId++);
      _lpexView = lpexView;
      _nodeType = nodeType;
   }

   /**
    * The PreferenceNode constructor we use doesn't set a label - which will
    * prevent "Preferences" from displaying (as there will be no text for
    * this tree item's name):  therefore, we must override getTextLabel() to
    * return the desired node name.
    */
   public String getLabelText()
   {
      switch (_nodeType) {
       case VIEW_BASE_NODE:
            return _lpexView.query("name");
       case VIEW_PARSER_NODE:
            return LpexResources.message(MSG_PREFERENCES_VIEW_PARSER_TITLE);
       case VIEW_SEQUENCE_NUMBERS_NODE:
            return LpexResources.message(MSG_PREFERENCES_SEQUENCE_NUMBERS_TITLE);
       default: // case VIEW_SOURCE_ENCODING_NODE
            return LpexResources.message(MSG_PREFERENCES_VIEW_SOURCE_ENCODING_TITLE);
         }
   }

   /**
    * Pages are created lazily when the user selects a node.
    * getPage() != null is used to track what pages have been visited.
    *
    * When "Preferences" is dismissed, the node resources are disposed
    * (disposeResources() is called);  this method will be called when in
    * a new "Preferences" the user selects this node...
    */
   public void createPage()
   {
      IPreferencePage newPage;
      switch (_nodeType) {
         case VIEW_BASE_NODE:
              newPage = new ViewBasePreferencePage(_lpexView);
              break;
         case VIEW_PARSER_NODE:
              newPage = new ViewParserPreferencePage(_lpexView);
              break;
         case VIEW_SEQUENCE_NUMBERS_NODE:
              newPage = new SequenceNumbersPreferencePage(_lpexView);
              break;
         default: // case VIEW_SOURCE_ENCODING_NODE
              newPage = new SourceEncodingPreferencePage(_lpexView);
              break;
         }

      setPage(newPage);
      //if (getLabelImage() != null)
      // newPage.setImageDescriptor(imageDescriptor);
      //newPage.setTitle(getLabelText());
   }
}