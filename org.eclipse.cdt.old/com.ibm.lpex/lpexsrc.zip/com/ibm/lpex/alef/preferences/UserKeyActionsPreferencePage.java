//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// UserKeyActionsPreferencePage - user-defined key actions preference page.
//----------------------------------------------------------------------------

package com.ibm.lpex.alef.preferences;

import java.util.StringTokenizer;
import java.util.Vector;

import com.ibm.lpex.core.LpexPreferencesConstants;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;


/**
 * Preference page for user key definitions.
 * It lets the user add and remove user-defined key actions.
 */
public final class UserKeyActionsPreferencePage extends TablePreferencePage
                                                implements LpexPreferencesConstants
{
   private static final String[] _valueTableNames =
    { LpexResources.message(MSG_PREFERENCES_USER_KEY_ACTIONS_TABLE_KEY),
      LpexResources.message(MSG_PREFERENCES_USER_KEY_ACTIONS_TABLE_ACTION) };
   private static final String[] _valueNames =
    { LpexResources.message(MSG_PREFERENCES_USER_KEY_ACTIONS_KEY),
      LpexResources.message(MSG_PREFERENCES_USER_KEY_ACTIONS_ACTION) };
   private static final String[] _helpIds = { "pref_045", "pref_046", "pref_047" };
   private static final int[] _valueWeights = { 50, 50 };


   /**
    * Return the names for the table columns.
    */
   protected String[] getValueTableNames()
   {
      return _valueTableNames;
   }

   /**
    * Return the names for the text-field labels.
    */
   protected String[] getValueNames()
   {
      return _valueNames;
   }

   /**
    * Return the context-help ids for the table and two text fields.
    */
   protected String[] getHelpIds()
   {
      return _helpIds;
   }

   /**
    * Return the column weights for the two columns in the table.
    */
   protected int[] getValueWeights()
   {
      return _valueWeights;
   }

   /**
    * Return a new vector of LpexTableItems with the initial (current) settings
    * (the preference page is being initialized).
    */
   protected Vector initialize()
   {
      return updateSettings(LpexView.globalQuery("current.updateProfile.userKeyActions"));
   }

   /**
    * Return a new vector of LpexTableItems with the install settings
    * ("Default" button was pressed).
    */
   protected Vector initializeDefaults()
   {
      return updateSettings(LpexView.globalQuery("install.updateProfile.userKeyActions"));
   }

   /**
    * Return a new vector of LpexTableItems with the settings in the provided
    * userKeyActions.
    */
   private Vector updateSettings(String userKeyActions)
   {
      Vector items = new Vector();
      if (userKeyActions != null) {
         StringTokenizer st = new StringTokenizer(userKeyActions);
         while (st.hasMoreTokens()) {
            String key = st.nextToken();
            if (st.hasMoreTokens())
               items.addElement(new LpexTableItem(key, st.nextToken()));
            }
         }
      return items;
   }

   /**
    * "OK" / "Apply" button pressed.  Commit any new updated values.
    */
   public boolean performOk()
   {
      Vector items = getItems();

      String newUserKeyActions = "";
      boolean first = true;
      for (int i = 0; i < items.size(); i++) {
         if (!first)
            newUserKeyActions += " ";
         first = false;
         LpexTableItem pi = (LpexTableItem)items.elementAt(i);
         newUserKeyActions += pi.value1() + " " + pi.value2(); // key + action
         }

      if (!newUserKeyActions.equals(LpexView.globalQuery("current.updateProfile.userKeyActions"))) {
         LpexView.doGlobalCommand("set default.updateProfile.userKeyActions " + newUserKeyActions);
         //-as- if newUserKeyActions empty, clean it up from Editor.properties
         LpexView.doGlobalCommand("updateProfile all");
         }
      return true;
   }
}