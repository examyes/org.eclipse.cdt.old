//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// PropertiesParser - document parser for Java properties files.
//----------------------------------------------------------------------------

package com.ibm.lpex.prop;

import java.util.ResourceBundle;

import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexView;


//-as- to highlight substitutions & literals - "{0}" "%s" "\r" "\u34ab"!?


/**
 * Document parser for Java properties files.
 *
 * <p>Action added by this parser:
 * <b>keys</b> (Ctrl+G) for a selective view of the keys defined.
 */
public class PropertiesParser extends LpexCommonParser
{
   private static ResourceBundle resource =
      ResourceBundle.getBundle("com.ibm.lpex.prop.Profile");

   // LPEX classes we use
   private static final String
      CLASS_KEY     = "key",          // key
      CLASS_VALUE   = "value",        // value
      CLASS_FWDLINK = "forwardLink",  // double-link "key=value"
      CLASS_BWDLINK = "backwardLink", //   units
      CLASS_COMMENT = "comment";      // comment

   // their allocated bit-masks
   private long
      classKey,
      classValue,
      classForwardLink,
      classBackwardLink,
      classComment,
      classAll;

   // end of a key
   private static final String KEYEND = "=: \t";

   // states:
   //  key = value\
   // |            |
   // NONE         INVALUE
   private static final int
      STATE_NONE      = 0x00000000,
      STATE_INVALUE   = 0x00000001;     // inside value

   private int state;                   // current method-detection state


   /**
    * Constructor for the parser.
    * Add all of the parser specifics to the LPEX view.
    * Initializes the LPEX view for the parser:  it sets up all the style
    * attributes, classes, etc. for the language-sensitive edit features
    * supported.
    *
    * @param lpexView the LPEX document view associated with this parser
    */
   public PropertiesParser(LpexView lpexView)
   {
      super(lpexView);        // LpexCommonParser constructor (view := lpexView)

      // set common attributes for the styles we use
      String tokenHighlight = getProperty("tokenHighlight");
      setStyleAttributes(tokenHighlight == null || !tokenHighlight.equals("off"));

      // register the classes we use & get their allocated bit-masks
      classKey          = view.registerClass(CLASS_KEY);
      classValue        = view.registerClass(CLASS_VALUE);
      classForwardLink  = view.registerClass(CLASS_FWDLINK);
      classBackwardLink = view.registerClass(CLASS_BWDLINK);
      classComment      = view.registerClass(CLASS_COMMENT);

      // set a bit-mask for all our own classes
      classAll = classKey | classValue |
                 classForwardLink | classBackwardLink | classComment;

      // define view filter action "keys"
      LpexAction lpexAction = new LpexAction() {                // "keys"
         public void     doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_KEY);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean  available(LpexView lpexView)
         { return true; }
         };
      view.defineAction("keys", lpexAction);
      view.doCommand("set keyAction.c-g.t.p.c keys");
   }

   /**
    * Define parser's style attributes.
    *
    * @param colours <code>true</code> = token highlighting,
    *                <code>false</code> = no token highlighting
    */
   public void           setStyleAttributes(boolean colours)
   {
      String toBackground = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                    BACKGROUND_COLOR, toBackground);
      if (colours) {
         setStyle("_e", attributes);   // Layout blanks, Equal

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("k", attributes);    // Key

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_STRING,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("v", attributes);    // Value

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("c", attributes);    // Comment
         }
      else                             // drop the nice colours
         setStyle("_ekvc", attributes);
   }

   /**
    * Returns <code>"properties"</code>, the file type supported by this parser.
    */
   public String         getLanguage()
   {
      return "properties";
   }

   /**
    * Returns the parser's properties profile resource bundle.
    */
   public ResourceBundle getProfile()
   {
      return resource;
   }

   /**
    * Total parse of the entire document.
    */
   public void           parseAll()
   {
      state = STATE_NONE;
      int elements = view.elements();

      for (int element = 1; element <= elements; element++)
         parseOneElement(element);
   }

   /**
    * Incremental parse.
    *
    * @param element the element whose committed change triggered the parse,
    *                or the element that precedes or follows a deleted block.
    *                The parser may identify other neighbouring elements that
    *                will have to be reparsed as a unit
    */
   public void           parseElement(int element)
   {
      state = STATE_NONE;
      int elements = view.elements();

      // evaluate optimal range to parse
      int beginElement = evaluateBeginElement(element);
      int endElement   = evaluateEndElement(element);

      // and get going until range exhausted AND no "key=value" still pending
      element = beginElement;
      while (true) {
         parseOneElement(element++);
         if (element > elements  ||
             (element > endElement && state == STATE_NONE))
            break;
         }
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * up to the top of the file.
    *
    * Extra lines may be included as follows:
    * - the previous non-show line is included if it has been modified or if it
    *   has a classForwardLink, or if the current line has a classBackwardLink,
    *   or if a line between the current and the previous was deleted;
    * - once an extra line is included, the one previous to it is also checked.
    *
    * @param elem main line that triggered the parse
    */
   private int           evaluateBeginElement(int elem)
   {
      int  tryElem;          // an element preceding elem
      long classes,          // classes of current elem
           tryClasses;       //  & classes of element preceding it

      // get current line's class
      for (;  elem > 1 && view.show(elem);  elem--) {}
      classes = view.elementClasses(elem);

      // LOOP BACKWARDS (up to top of the file)...
      while (elem > 1) {
         for (tryElem=elem-1;  tryElem > 1 && view.show(tryElem);  tryElem--) {}
         tryClasses = view.elementClasses(tryElem);               // prev line's

         // Include prev line in parse range and go on searching if *any* of:
         //   (a) current line has a BWDLINK;
         //   (b) previous non-show line has a FWDLINK;
         //   (c) line(s) between previous and current line was/were deleted;
         //   (d) previous non-show line has been modified.
         if ((classes & classBackwardLink)   == 0 &&
             (tryClasses & classForwardLink) == 0
             /*&&(view.parsePending(elem) & LX_PENDING_DELETE)==0*/
             /*&&(view.parsePending(tryElem) & LpexConstants.PARSE_PENDING_CHANGE_MASK)==0*/)
            break;

         classes = tryClasses;
         elem    = tryElem;
         }

      return elem;
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * to the bottom of the file.
    *
    * Extra lines may be included as follows:
    * - the next line is included if it's been modified, or if it has a class
    *   classBackwardLink, or is just a SHOW line;
    *   or if the current line has a classForwardLink;
    * - once an extra line is included, the one after it is also checked.
    *
    * @param element main line that triggered the parse
    */
   private int           evaluateEndElement(int element)
   {
      int elements = view.elements();

      // LOOP FORWARDS (down to bottom of the file)...
      int endElem = element;
      for (; endElem < elements; endElem++) {
         long classes = view.elementClasses(endElem);

         // Include next line in parse range and go on searching if *any* of:
         //   (a) current line has a FWDLINK;
         //   (b) next line is just a SHOW line;
         //   (c) next line was modified;
         //   (d) next line has a classBackwardLink.
         // Also: current line has LpexConstants.PARSE_PENDING_NEXT_DELETED_MASK ?!? *as*
         if (((classes & classForwardLink) == 0) &&
             (!view.show(endElem+1))             &&
             ((view.parsePending(endElem+1) & LpexConstants.PARSE_PENDING_CHANGE_MASK) == 0) &&
             ((view.elementClasses(endElem+1) & classBackwardLink) == 0)) {
            break;                               // break out of loop
            }
         }

      return endElem;
   }

   /**
    * Parse one element in the document.
    *
    * @param element one document element to parse
    */
   private void          parseOneElement(int element)
   {
      if (view.show(element))
         return;

      // query element's current classes (as possibly set by others), and text
      long   classes    = view.elementClasses(element) & ~classAll;
      String text       = view.elementText(element);
      int    textLength = text.length();
      String styles     = "";

      int i = 0, j;

      // skip & style any leading blanks
      while (i < textLength && (text.charAt(i)==' ' || text.charAt(i)=='\t'))
         i++;
      styles = styleString('_', i);

      /*========================*/
      /*  (a) continue a value  */
      /*========================*/
      if (state == STATE_INVALUE) {
         if (i < textLength) {             // style for any value
            styles += styleString('v', textLength - i);
            classes = classValue | classBackwardLink;
            }

         if (!text.endsWith("\\"))         // value may continue even further...
            state = STATE_NONE;
         }

      /*=============================*/
      /*  (b) or establish new type  */
      /*=============================*/
      else if (i < textLength) {                      // if any beef in the line
         /*----------------------------------------------------*/
         /*  comment line (comments don't continue with '\\')  */
         /*----------------------------------------------------*/
         if (text.charAt(i) == '#' || text.charAt(i) == '!') {
            styles  += styleString('c', textLength - i);
            classes |= classComment;
            }

         /*--------------------------*/
         /*  a key [and maybe more]  */
         /*--------------------------*/
         else {
            // scan to end of key (eol / separator)
            j = i;
            while (j < textLength) {
               char c = text.charAt(j);
               if (KEYEND.indexOf(c) >= 0) {
                  // '\' with space, '=', or ':' is part of key, not separator
                  // (see JDK1.2 java.util.Properties.store() API docs)
                  if (j > 0 && text.charAt(j-1) == '\\' &&
                     (c==' ' || c=='=' || c==':'))
                     {}
                  else
                     break;
                  }
               j++;
               }
            styles += styleString('k', j-i);
            classes |= classKey;

            if (j < textLength) {
               // skip leading blanks
               i = j;
               while (j < textLength && (text.charAt(j)==' ' || text.charAt(j)=='\t'))
                  j++;
               styles += styleString('_', j-i);

               /*------------------------------*/
               /*  an '=' / ':' before value?  */
               /*------------------------------*/
               if (j < textLength && (text.charAt(j)=='=' || text.charAt(j)==':')) {
                  styles += "e";

                  i = ++j;                       // skip any more leading blanks
                  while (j < textLength && (text.charAt(j)==' ' || text.charAt(j)=='\t'))
                     j++;
                  styles += styleString('_', j-i);
                  }

               /*--------------*/
               /*  any value?  */
               /*--------------*/
               state = STATE_NONE;                     // assume null (no) value
               if (j < textLength) {
                  styles += styleString('v', textLength - j);
                  classes |= classValue;
                  if (text.endsWith("\\"))             // value may be continued
                     state = STATE_INVALUE;
                  }
               }
            }
         }

      /*================================================*/
      /*  set the element's display styles and classes  */
      /*================================================*/
      if (state != STATE_NONE)
         classes |= classForwardLink;     // must parse entire "key=value" units
      view.setElementStyle(element, styles);
      view.setElementClasses(element, classes);
   }
}