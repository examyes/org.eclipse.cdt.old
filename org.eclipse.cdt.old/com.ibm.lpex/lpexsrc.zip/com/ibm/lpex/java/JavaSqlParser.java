//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// JavaSqlParser - document parser for Java + embedded SQL.
//----------------------------------------------------------------------------

package com.ibm.lpex.java;

import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCharStream;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexView;

import com.ibm.lpex.sql.SqlLexer;
import com.ibm.lpex.sql.SqlLexerClasses;
import com.ibm.lpex.sql.SqlLexerStyles;


/**
 * Document parser for Java with embedded SQL.
 *
 * <p>Action added by this parser:
 * <b>sql</b> for a selective view of the embedded SQL statements.
 */
public class JavaSqlParser extends JavaParser
{
   /**
    * Constructor for JavaSqlParser.
    * It calls JavaParser's constructor, and defines the action <b>sql</b>.
    */
   public JavaSqlParser(LpexView lpexView)
   {
      super(lpexView);

      // view filter action "sql"
      LpexAction lpexAction = new LpexAction()             // "sql"
      {
         public void    doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_SQL);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
      };
      view.defineAction("sql", lpexAction);
   }

   /**
    * Return parser's items for the popup View submenu:
    * methods, outline, sql, errors.
    */
   public String   getPopupViewItems()
   {
      return getLanguage() + ".popup.methods methods " +
             getLanguage() + ".popup.outline outline " +
             getLanguage() + ".popup.sql sql " +
             MSG_POPUP_ERRORS + " errors";
   }

   /**
    * Define SQL-specific additional style attributes.
    * @param  colours  true = token highlighting,
    *                  false = no token highlighting
    */
   public void     setStyleAttributes(boolean colours)
   {
      super.setStyleAttributes(colours);

      String toBackground = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                        BACKGROUND_COLOR,
                                                        toBackground);
      if (colours) {
         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_LIBRARY,
                                                    BACKGROUND_COLOR,
                                                    toBackground);
         setStyle("f",  attributes);      // SQL built-in function
         }
      else                                // drop the nice colours...
         setStyle("f", attributes);
   }

   /**
    * Retrieve the SqlLexer.
    * This method constructs and returns an SqlLexer object for parsing Java
    * embedded SQL statements.
    */
   public SqlLexer getSqlLexer(LpexCharStream stream)
   {
      return new SqlLexer(stream, getLanguage(),
                 new SqlLexerStyles("cekfnqip"),
                 new SqlLexerClasses(view, classCode,
                                     classForwardLink, classBackwardLink,
                                     classComment, classError,
                                     0)); // we don't care about an sqlStatement
   }
}