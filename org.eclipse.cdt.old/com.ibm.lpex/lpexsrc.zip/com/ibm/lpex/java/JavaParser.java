//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// JavaParser - document parser for Java.
//----------------------------------------------------------------------------

package com.ibm.lpex.java;

import java.text.MessageFormat;        // for format(), to substitute arguments
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import com.ibm.lpex.core.HelpCommand;
import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCharStream;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexDocumentLocation;
import com.ibm.lpex.core.LpexMatch;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import com.ibm.lpex.cc.LpexJavaParserTokenManager;
import com.ibm.lpex.cc.Token;
import com.ibm.lpex.cc.TokenMgrError;

import com.ibm.lpex.sql.SqlLexer;


/**
 * Document parser for Java.
 *
 * <p>Actions and assigned keys added by this document parser:
 * <ul>
 *   <li><b>methods</b> (Ctrl+G) for a selective view of the methods
 *       in the document
 *   <li><b>outline</b> for a logical-outline view of the document
 *   <li><b>errors</b> for a selective view of the errors in the document
 *   <li><b>doc</b> to generate a class/method javadoc comment-block template
 *   <li><b>trace</b> to insert tracing statements for a method
 *   <li><b>javaAmp</b> (Ctrl+&amp;) to insert an ampersand
 *       character entity reference (&amp;amp;) in javadoc comments
 *       (note: on most keyboards, you must also press the Shift key)
 *   <li><b>javaGt</b> (Ctrl+&gt;) to insert a greater-than sign
 *       character entity reference (&amp;gt;) in javadoc comments
 *       (note: on most keyboards, you must also press the Shift key)
 *   <li><b>javaLt</b> (Ctrl+&lt;) to insert a less-than sign
 *       character entity reference (&amp;lt;) in javadoc comments
 *       (note: on most keyboards, you must also press the Shift key).
 * </ul></p>
 *
 * Keys already defined (e.g., by the active base profile) to an action
 * different from <b>nullAction</b> are not redefined in here.
 *
 * <p>Actions modified by this document parser:
 * <b>split, join, delete</b> for handling javadoc comment-blocks editing.</p>
 *
 * <p>Actions redefined by LpexCommonParser and further modified by this
 * parser:
 * <b>openLine, splitLine</b> for handling javadoc comment-block editing.</p>
 *
 * <p>Template expansion (Ctrl+R) for the following keywords is available
 * in this parser's Profile.properties:
 * case, do, doc, err, for, if, iter, main, out, switch, try, while.</p>
 */

 // this one only works in AWT/Swing - SWT gives no key event for Ctrl+@...
 // <li><b>javaAt</b> (Ctrl+&#064;) to insert an at-condition
 //     character (&#064;) in javadoc comments
 //     (note: on most keyboards, you must also press the Shift key)

public class JavaParser extends LpexCommonParser
{
   // whether the help index has been loaded, and the index .properties file
   private static boolean properties_loaded;
   private static Properties helpPages;

   // the input stream the view feeds
   private LpexCharStream stream;

   // this parser's default settings
   private static ResourceBundle resource =
      ResourceBundle.getBundle("com.ibm.lpex.java.Profile");

   // the element classes we use...
   static final String
      CLASS_CODE            = "code",            // non-comment text
      CLASS_SPACE           = "space",           // empty line, not in a parse unit
      CLASS_FWDLINK         = "forwardLink",
      CLASS_BWDLINK         = "backwardLink",
      CLASS_SEMICOLON       = "semicolon",
      CLASS_METHOD          = "method",          // regular method signature
      CLASS_ABSTRACTMETHOD  = "abstractMethod",  // no body, declared "abstract"
      CLASS_INTERFACEMETHOD = "interfaceMethod", // no body, inside "interface"
      CLASS_BRACE           = "brace",
      CLASS_ERROR           = "error",
      CLASS_COMMENT         = "comment",         // "/* .. */" or "//" comment
      CLASS_JAVACOMMENT     = "javaComment",     // "/** .. */" javadoc comment
      CLASS_CONTROL         = "control",
      CLASS_CLASS           = "class",           // class XXX {
      CLASS_ANONYMOUSCLASS  = "anonymousClass",  // new XXX() {
      CLASS_INTERFACE       = "interface",       // interface XXX {
      CLASS_SQL             = "sql";             // embedded SQL

   // ...and their registered bitmasks
   long
      classCode,
      classSpace,
      classForwardLink,
      classBackwardLink,
      classSemicolon,
      classMethod,
      classAbstractMethod,
      classInterfaceMethod,
      classBrace,
      classError,
      classComment,
      classJavaComment,
      classControl,
      classClass,
      classAnonymousClass,
      classInterface,
      classSql,
      classAll;

   // comments state for FWDLINK & BWDLINK
   private long comments;

   // method declaration:
   //  public static char[] method ( char bla, int[] blah ) [throws a, b] {
   // |      |                      |                      |       |      |
   // NONE   ID     ...    ...      PARMS                  TOBRACE THROWS done
   // may want to 1st set a TYPE before ID (as ID cannot have DOT - xx.yy)! *as*
   private static final int
      METHOD_NONE      = 0x00000000,

      METHOD_ABSTRACT  = 0x00000001,     // "abstract" keyword
      METHOD_NEW       = 0x00000002,     // "new" keyword (--> anonymous class?)
      METHOD_ID        = 0x00000004,     // found a method type/name
      METHOD_PARMS     = 0x00000008,     // getting formal parameters
      METHOD_TOBRACE   = 0x00000010,     // after ')', expect the '{'
      METHOD_THROWS    = 0x00000020,     // after "throws", expect '{'

      METHOD_SQL       = 0x00000100,     // in sql somewhere:
      METHOD_SQLCLAUSE = 0x00000101,     //   outside "{ ..executable clause.. }"
      METHOD_SQLEXEC   = 0x00000102;     //   inside "{ ..executable clause.. }"

   private int method,                   // current method-detection state
               abstractElement,          // element of any "abstract" keyword,
               beginMethod,              // first element of (potential) method,
               endMethod;                //  & the last one

   // first "interface" in the file
   private int interfaceElement;

   // for processToken() - no brace for what looked so far like
   // a method declaration:  can it be an interface method?
   private LpexDocumentLocation interfaceScope;

   // lexers we (may) use
   private static final int
      LEXER_JAVA = 0,
      LEXER_SQL  = 1;

   private JavaLexer javaLexer;
   private SqlLexer  sqlLexer;
   private int       activeLexer = LEXER_JAVA;

   // token delimiters for LpexCommonParser's isTokenDelimiter()
   private static final String TOKEN_DELIMITERS = "()[]{};,/";


   /**
    * Constructor for the parser.
    * Adds all of the parser specifics to the LPEX document view.
    * Initializes the view for the parser:  sets up all the style
    * attributes, classes, etc. for the language-sensitive edit features
    * supported.
    *
    * @param lpexView the document view associated with this parser
    */
   public JavaParser(LpexView lpexView)
   {
      super(lpexView);        // LpexCommonParser constructor (view := lpexView)
      initializeParser();     // initialize LpexView with our stuff

      // instantiate an input stream for this view, and the lexers
      stream    = new LpexCharStream(view);
      javaLexer = new JavaLexer(stream);
   }

   /**
    * Total parse of the entire document.
    * Done initially, after a document has been loaded in the editor,
    * or after an <b>updateProfile</b> command.
    */
   public void           parseAll()
   {
      interfaceElement = 0;
      interfaceScope = null;

      int elements = view.elements();         // a bit of preventive care...
      if (elements == 0)
         return;

      doParse(1, elements, false, false);     // first parse on entire doc
      if (interfaceElement != 0)
         setInterfaceMethods(0);              // set interface method signatures
   }

   /**
    * Incremental parse.
    * @param element the (first) element whose committed change triggered the
    *                parse, or the element that precedes/follows a deleted block.
    *                The parser may identify other neighbouring elements that
    *                will have to be reparsed as a unit
    */
   public void           parseElement(int element)
   {
      if (view.elements() == 0)               // a bit of preventive care...
         return;

      int beginElement = evaluateBeginElement(element);
      doParse(beginElement,                   // parse optimal range
              evaluateEndElement(element),
              true,                           // remove error messages
              true);                          // clear their parsePending flags

      if (interfaceElement != 0) {            // "interface"s in the doc:
         if (element <= interfaceElement)
            interfaceElement = 0;
         setInterfaceMethods(beginElement);   //  re-set i/f method signatures
         }
   }

   /**
    * Returns the parser's properties profile resource bundle.
    */
   public ResourceBundle getProfile()
   {
      return resource;
   }

   /**
    * Returns <code>"Java"</code>, the language supported by this parser.
    *
    * @see com.ibm.lpex.core.LpexCommonParser#LANGUAGE_JAVA
    */
   public String         getLanguage()
   {
      return LANGUAGE_JAVA;
   }

   /**
    * Retrieve a string identifying the language segment at the specified
    * location.  In mixed-content documents, this may differ from the main
    * language of the document.
    *
    * The method assumes that no parse is pending for the location element.
    *
    * @return one of: LpexCommonParser.LANGUAGE_JAVA,
    *                 LpexCommonParser.LANGUAGE_SQL
    */
   public String         getLanguage(LpexDocumentLocation loc)
   {
      long classes = view.elementClasses(loc.element);
      if ((classes & classSql) != 0)
         return LANGUAGE_SQL;
      return getLanguage();
   }

   /**
    * Initialize the parser for an LPEX document view: set up style attributes
    * for the styles we need, classes, etc., and initialize the view
    * for the language-sensitive edit features supported.
    */
   private void          initializeParser()
   {
      // set attributes for the styles we use
      String tokenHighlight = getProperty("tokenHighlight");
      setStyleAttributes(tokenHighlight == null || !tokenHighlight.equals("off"));

      // register the classes we use & get their allocated bit-masks
      classCode            = view.registerClass(CLASS_CODE);
      classSpace           = view.registerClass(CLASS_SPACE);
      classForwardLink     = view.registerClass(CLASS_FWDLINK);
      classBackwardLink    = view.registerClass(CLASS_BWDLINK);
      classSemicolon       = view.registerClass(CLASS_SEMICOLON);
      classMethod          = view.registerClass(CLASS_METHOD);
      classAbstractMethod  = view.registerClass(CLASS_ABSTRACTMETHOD);
      classInterfaceMethod = view.registerClass(CLASS_INTERFACEMETHOD);
      classBrace           = view.registerClass(CLASS_BRACE);
      classError           = view.registerClass(CLASS_ERROR);
      classComment         = view.registerClass(CLASS_COMMENT);
      classJavaComment     = view.registerClass(CLASS_JAVACOMMENT);
      classControl         = view.registerClass(CLASS_CONTROL);
      classClass           = view.registerClass(CLASS_CLASS);
      classAnonymousClass  = view.registerClass(CLASS_ANONYMOUSCLASS);
      classInterface       = view.registerClass(CLASS_INTERFACE);
      classSql             = view.registerClass(CLASS_SQL);
      classAll = classCode | classSpace | classForwardLink | classBackwardLink |
                 classSemicolon |
                 classMethod | classAbstractMethod | classInterfaceMethod |
                 classBrace | classError | classComment | classJavaComment |
                 classControl | classClass | classAnonymousClass |
                 classInterface | classSql;

      /*----------------------------------*/
      /*  define & redefine LPEX actions  */
      /*----------------------------------*/
      // view filter action "methods"
      LpexAction lpexAction = new LpexAction()        // "methods"
      {
         public void doAction(LpexView view)
         { methods(); }

         public boolean available(LpexView view)
         { return true; }
      };
      view.defineAction("methods", lpexAction);
      view.doDefaultCommand("set keyAction.c-g.t.p.c methods");

      // view filter action "outline"
      lpexAction = new LpexAction()                   // "outline"
      {
         public void doAction(LpexView view)
         { outline(); }

         public boolean available(LpexView view)
         { return true; }
      };
      view.defineAction("outline", lpexAction);

      // view filter action "errors"
      lpexAction = new LpexAction()                   // "errors"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_ERROR);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { // could check if any errors in doc...
           return true; }
      };
      view.defineAction("errors", lpexAction);

      // action "doc" - document class/interface/method (add "docAll" for entire doc? -as-)
      lpexAction = new LpexAction()                   // "doc"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("parse"); // ensure all's parsed okay
           document(view.documentLocation()); }

         public boolean available(LpexView view)
         { return true; }
      };
      view.defineAction("doc", lpexAction);

      // action "trace" - insert trace statement(s) in method
      lpexAction = new LpexAction()                   // "trace"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("parse"); // ensure all's parsed okay
           trace(view.documentLocation()); }

         public boolean available(LpexView view)
         { return true; }
      };
      view.defineAction("trace", lpexAction);

      // redefine action "split"
      lpexAction = new LpexAction()                   // "split"
      {
         public void doAction(LpexView view)
         { split(); }

         public boolean available(LpexView view)
         { return view.defaultActionAvailable(LpexConstants.ACTION_SPLIT); }
      };
      view.defineAction("split", lpexAction);

      // redefine action "join"
      lpexAction = new LpexAction()                   // "join"
      {
         public void doAction(LpexView view)
         { join(); }

         public boolean available(LpexView view)
         { return view.defaultActionAvailable(LpexConstants.ACTION_JOIN); }
      };
      view.defineAction("join", lpexAction);

      // redefine action "delete"
      lpexAction = new LpexAction()                   // "delete"
      {
         public void doAction(LpexView view)
         { delete(); }

         public boolean available(LpexView view)
         { return view.defaultActionAvailable(LpexConstants.ACTION_DELETE); }
      };
      view.defineAction("delete", lpexAction);

      // convenient & in javadoc
      lpexAction = new LpexAction()                   // "javaAmp"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("insertText &amp;"); }
         public boolean available(LpexView view)
         { return true; }
      };
      view.defineAction("javaAmp", lpexAction);
      if (!view.keyAssigned("c-ampersand.t"))
         view.doCommand("set keyAction.c-ampersand.t javaAmp");

      // convenient > in javadoc
      lpexAction = new LpexAction()                   // "javaGt"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("insertText &gt;"); }
         public boolean available(LpexView view)
         { return true; }
      };
      view.defineAction("javaGt", lpexAction);
      if (!view.keyAssigned("c-greaterThanSign.t"))
         view.doCommand("set keyAction.c-greaterThanSign.t javaGt");

      // convenient < in javadoc
      lpexAction = new LpexAction()                   // "javaLt"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("insertText &lt;"); }
         public boolean available(LpexView view)
         { return true; }
      };
      view.defineAction("javaLt", lpexAction);
      if (!view.keyAssigned("c-lessThanSign.t"))
         view.doCommand("set keyAction.c-lessThanSign.t javaLt");

      // convenient @ in javadoc
      lpexAction = new LpexAction()                   // "javaAt"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("insertText &#064;"); }
         public boolean available(LpexView view)
         { return true; }
      };
      view.defineAction("javaAt", lpexAction);
      if (!view.keyAssigned("c-atSign.t"))
         view.doCommand("set keyAction.c-atSign.t javaAt");
   }

   /**
    * Return parser's items for the popup View submenu:
    * methods, outline, errors.
    */
   public String    getPopupViewItems()
   {
      return getLanguage() + ".popup.methods methods " +
             getLanguage() + ".popup.outline outline " +
             LpexConstants.MSG_POPUP_ERRORS + " errors";
   }

   /**
    * Return parser's items for the popup:
    * doc, trace.
    */
   public String    getPopupParserItems()
   {
      return "popup.document doc popup.trace trace";
   }

   /**
    * Define parser's style attributes.
    * @param colours true = token highlighting,
    *                false = no token highlighting
    */
   public void      setStyleAttributes(boolean colours)
   {
      String toBackground = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                        BACKGROUND_COLOR, toBackground);
      if (colours) {
         setStyle("_iopbu", attributes);  // Layout blanks, Identifier, Operator,
                                          //   Punctuator, Brace, Unicode sequence

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("c", attributes);       // Comment

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_ERROR,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("e", attributes);       // Lexical error

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("k", attributes);       // Keyword

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_NUMERAL,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("n", attributes);       // Constant

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_STRING,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("q", attributes);       // String literal
         }
      else                                // drop the nice colours...
         setStyle("_iopbuceknq", attributes);
   }

   /**
    * Continue comment for a line opened inside a comment block.
    */
   protected void   openLine()
   {
      super.openLine();
      continueComment();
   }

   /**
    * Continue comment for a line split inside a comment block.
    */
   protected void   splitLine()
   {
      super.splitLine();
      continueComment(); // (here, there is no need to do "parse" again... -as-)
   }

   /**
    * Continue comment for a line split inside a comment block.
    */
   protected void   split()
   {
      LpexDocumentLocation loc = view.documentLocation(); // current location
      splitLine();                                        // do splitLine, set
      view.jump(loc);                                     //  original cursor
   }

   /**
    * Continue a Java-style comment for a newly opened or inserted element.
    * Called from openLine() and splitLine() after the action was processed.
    */
   private void     continueComment()
   {
      LpexDocumentLocation loc = view.documentLocation(); // current cursor
      view.doDefaultCommand("parse");                     // ensure file is parsed

      // after actions openLine & splitLine, cursor is on the new element
      if (loc.element <= 1)
         return;

      // nothing to do if not inside a Java comment
      if (((view.elementClasses(loc.element) & classJavaComment) == 0) ||
          ((view.elementClasses(loc.element-1) & classJavaComment) == 0))
         return;

      String curr = view.elementText(loc.element);     // current element
      String prev = view.elementText(loc.element - 1); // previous element
      String text = null;                              // adjusting text

      // /**      /**      /**       /**
      // #*/  =>           #*   =>
      //          #*/       *       #*
      if (prev.trim().length() == 0) {
         if (loc.element > 2) {
            String prevprev = view.elementText(loc.element - 2);
            if (prevprev.trim().startsWith("*")) {
               text = prevprev.substring(0, prevprev.indexOf('*')) + "* ";
               view.setElementText(loc.element-1, text);
               return;
               }
            else if (prevprev.trim().startsWith("/**")) {
               text = prevprev.substring(0, prevprev.indexOf('/')) + " ";
               view.setElementText(loc.element-1, text + "* ");
               // may have to adjust the text of the new element too
               }
            }
         }

      else if (curr.trim().startsWith("*/")) {
         // /** a #*/  =>   /** a
         //                #*/
         if (prev.trim().startsWith("/**"))
            text = prev.substring(0, prev.indexOf('/')) + " ";
         }

      else {
         if (prev.trim().startsWith("*"))
            text = prev.substring(0, prev.indexOf('*')) + "* ";
         else if (prev.trim().startsWith("/**"))
            text = prev.substring(0, prev.indexOf('/')) + " * ";
         }

      /*--------------------------------------*/
      /*  adjust the text of the new element  */
      /*--------------------------------------*/
      if (text == null)
         return;

      // trim current element, so all OK regardless of autoIndent on or off
      view.setElementText(loc.element, view.elementText(loc.element).trim());

      loc.position = 1;
      view.jump(loc);
      view.doDefaultCommand(loc, "insertText " + text);
   }

   /**
    * Flow text inside a comment block during a join.
    */
   protected void   join()
   {
      LpexDocumentLocation loc = view.documentLocation(); // current cursor
      view.doDefaultCommand("parse");                  // ensure file is parsed

      if ((loc.element < view.elements()) &&           // if inside Java comment
          ((view.elementClasses(loc.element) & classJavaComment) != 0) &&
          (view.elementClasses(loc.element+1) & classJavaComment) != 0) {
         String text = view.elementText(loc.element + 1);
         if (text.trim().startsWith("*") && !text.trim().startsWith("*/")) {
            loc.element++;                             //  cut " * " for join
            loc.position = 1;
            view.doDefaultCommand(loc, "deleteText " + (text.indexOf('*')+2));
            }
         }
      view.doDefaultAction(LpexConstants.ACTION_JOIN);
   }

   /**
    * Flow text inside a comment block during a delete which joins lines.
    */
   protected void   delete()
   {
      LpexDocumentLocation loc = view.documentLocation(); // current cursor
      boolean joining = false;

      if ((loc.position >= view.elementText(loc.element).length()) &&
          loc.element < view.elements()) {
         view.doDefaultCommand("parse");                // ensure file is parsed
         if (((view.elementClasses(loc.element) & classJavaComment) != 0) &&
             (view.elementClasses(loc.element+1) & classJavaComment) != 0)
            joining = true; // seems we'll join elements, inside comment block
         }

      view.doDefaultAction(LpexConstants.ACTION_DELETE);

      if (joining && (view.currentElement() == loc.element) &&
          (view.currentPosition() == loc.position)) {
         String text = view.elementText(loc.element);
         if (text.length() > loc.position) {
            text = text.substring(loc.position-1);
            if (text.trim().startsWith("*") && !text.trim().startsWith("*/"))
               view.doDefaultCommand(loc, "deleteText " + (text.indexOf('*')+2));
            }
         }
   }

   /**
    * Returns <code>true</code> if the specified character is a token delimiter.
    */
   public boolean   isTokenDelimiter(char ch)
   {
      return TOKEN_DELIMITERS.indexOf(ch) >= 0;
   }

   /**
    * Retrieve the name of the html help page that the parser identifies
    * as appropriate for the currently selected token
    */
   public String    getHelpPage()
   {
      String helpPage = null;
      loadProperties();
      if (helpPages != null) {
         String token = getToken(view.documentLocation());
         if (token != null)
            helpPage = helpPages.getProperty(token);
         }
      return helpPage;
   }

   private static void loadProperties()
   {
      if (!properties_loaded) {
         helpPages = HelpCommand.loadHelpMap(HELP_JAVA);
         // whether the load succeeded or not, there's no point in
         // trying again until LPEX is restarted
         properties_loaded = true;
         }
   }

// /**
//  * Refine LpexCommonParser's cursor indentation.
//  * @param element the element for cursor indentation
//  * @return optimal display cursor column
//  */
// public int cursorIndent(int element) // *as*
// {
//    // (a) blank element - get indent of any non-blank element above it
//    String p = view.elementText(element);       // get element's text
//    if ((p.trim()).length() == 0) {
//       for (;;) {
//          if (--element < 1)
//             return 1;                          // no non-blank element found.
//
//          if (!view.show(element)) {            // ignore show lines
//             p = view.elementText(element);
//             if ((p.trim()).length() > 0)
//                break; // found nonblank line - fall through below...
//             }
//          }
//       }
//
//    // (b) element has text - skip the the first non-blank
//    int i;
//    for (i = 0;  Character.isWhitespace(p.charAt(i));  i++) {}
//
//    // text cursor column -> display cursor column
//    return view.queryInt("displayPosition",
//                         new LpexDocumentLocation(element, i+1));
// }

   /**
    * Expand LpexCommonParser's getProperty() to substitute arguments for
    * key PROTOKEY_EMPTY.  Argument {0} is the package name, {1} is the class
    * name.  The substitutions are based on the name parameter of the document.
    */
   public String    getProperty(String key)
   {
      if (!key.equals(PROTOKEY_EMPTY))
         return super.getProperty(key);

      Object arguments[] = { "myPackage", "MyClass" };

      String name = view.query("name");
      if (name != null) {
         // remove file extension and any drive letter from path part
         int i = name.lastIndexOf('.');
         if (i >= 0)
            name = name.substring(0, i);
         if ((i = name.indexOf(':')) >= 0)
            name = name.substring(i+1);

         // consider both '\\' & '/' as file separators (MS Windows does)
         name = name.replace('\\', '/');

         // extract file name from path
         i = name.lastIndexOf('/');
         if (i >= 0) {
            if (i < name.length()-1)
               arguments[1] = name.substring(i+1);
            name = name.substring(0, i);

            // make path into a package name
            if (name.length() > 0) {
               if (name.charAt(0) == '/')
                  name = name.substring(1);
               if (name.length() > 0)
                  arguments[0] = name.replace('/', '.');
               }
            }
         else if (name.length() > 0)
            arguments[1] = name;
         }

      try {
         return MessageFormat.format(super.getProperty(key), arguments);
         }
      catch (Exception e) {}

      return super.getProperty(key);
   }

   /**
    * Parse a range of elements.
    * Called by both parseAll() and parseElement().
    *
    * @param beginElement   first element in range
    * @param endElement     last element in the range
    * @param removeMessages true = remove any lexical errors in the parse range
    * @param clearPending   true = clear parsePending once done with an element
    */
   private void     doParse(int beginElement, int endElement,
                            boolean removeMessages, boolean clearPending)
   {
      // clear existing lexical errors (if any) in the parse range
      if (removeMessages)
         removeErrorMessages(beginElement, endElement);

      // initialize parse operation & get parsing
      stream.Init(beginElement, endElement,
                  classAll, classSpace, '_', clearPending);
      setLexer(LEXER_JAVA);                 // the TokenManager defaults to Java
      method = METHOD_NONE;

      // *can* cache: removeMessages() will really delete elements *after* parse
      int elements = view.elements();
      while (true) {
         try {
            int rc = processToken();
            // on EOF, we may have to extend the parse range
            if ((rc & LEXER_RC_EOF) != 0) {
               if ((comments & classForwardLink) != 0 || method != METHOD_NONE) {
                  int oldEndElement = endElement;
                  do {               // could re-evaluateEndElement() instead??!
                     endElement++;
                     } while ((endElement <= elements) && view.show(endElement));
                  if (endElement > elements)
                     break;
                  stream.Expand(endElement);
                  // clear old messages in the newly expanded parse range
                  if (removeMessages)
                     removeErrorMessages(oldEndElement+1, endElement);
                  }
               else
                  break;
               }
            }
         catch (TokenMgrError e) {            // EOF in middle of token/bad char
            stream.setStyles(stream.getBeginColumn(), stream.getEndColumn(), 'e');
            stream.setClasses(classError | classCode);
            // try to extract more accurate error info by parsing info in e
            // (see cc\TokenMgrError.java)!? (in other parsers too) -as-
            addErrorMessage(stream.getEndLine(),    // matchedToken.endLine bad!
                            "syntaxError");

            if (stream.EOFSeen()) {                 // EOF (styles already set)?
               stream.setCurrentStyles();           //  do it again, complete
               break;                               //  & that's it, folks...
               }

            stream.skipChar();       // skip the error character (presumably...)
            reinitializeLexer();                          //  & continue past it
            // to abort #sqlj in progress, must switch to LEXER_JAVA first! *as*
            if ((method & METHOD_SQL) == 0)      // abort methods in progress...
               method = METHOD_NONE;
            }
         //catch (Exception e) {
         // //System.err.println(e.getLocalizedMessage());
         // e.printStackTrace();
         // break;}
         }
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * up to the top of the file.
    * Extra lines may be included as follows:
    * - the previous non-show line is included if it has been modified or if it
    *   has a classForwardLink, or if the current line has a classBackwardLink
    *   or doesn't have classSemicolon (note:  this is needed for METHOD, i.e.,
    *   method processing), or if a line between the current and the previous
    *   was deleted;
    * - once an extra line is included, the one previous to it is also checked.
    *
    * @param elem main line that triggered the parse
    * @return suggested start line for parsing (may be a show line)
    */
   private int      evaluateBeginElement(int elem)
   {
      int  tryElem;          // an element preceding elem
      long classes,          // classes of current elem
           tryClasses;       //  & classes of element preceding it

      // get current line's class;  do not let a SEMICOLON (which can
      // be just *anywhere*) in the starting line fool you: go deeper!
      for (;  elem > 1 && view.show(elem);  elem--) {}
      classes = view.elementClasses(elem) & ~classSemicolon;

      // LOOP BACKWARDS (up to top of the file)...
      while (elem > 1) {
         for (tryElem=elem-1;  tryElem > 1 && view.show(tryElem);  tryElem--) {}
         tryClasses = view.elementClasses(tryElem);               // prev line's

         // Include prev line in parse range and go on searching if *any* of:
         //   (a) current line has a BWDLINK;
         //   (b) current line doesn't have a semicolon;
         //   (c) previous non-show line has a FWDLINK;
         //   (d) line(s) between previous and current line was/were deleted;
         //   (e) previous non-show line has been modified.
         if ((classes & classBackwardLink)   == 0 &&
             (classes & classSemicolon)      != 0 &&
             (tryClasses & classForwardLink) == 0
             /*&&(view.parsePending(elem) & LX_PENDING_DELETE)==0*/
             /*&&(view.parsePending(tryElem) & PARSE_PENDING_CHANGE_MASK)==0*/)
            //freeElement(tryElem); // free (unlock) the try line,
            break;                  //  break out of the loop

         classes = tryClasses;
         elem    = tryElem;
         }

      return elem;
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * to the bottom of the file.
    * Extra lines may be included as follows:
    * - the next line is included if it's been modified, or if it has a class
    *   classBackwardLink, or is just a SHOW line;
    *   or if the current line has a class of classForwardLink or has no SEMICOLON;
    * - once an extra line is included, the one after it is also checked.
    *
    * @param element main line that triggered the parse
    */
   private int      evaluateEndElement(int element)
   {
      int elements = view.elements();

      // LOOP FORWARDS (down to bottom of the file)...
      int endElem = element;
      for (; endElem < elements; endElem++) {
         long classes = view.elementClasses(endElem);

         // Include next line in parse range and go on searching if *any* of:
         //   (a) current line has a FWDLINK;
         //   (b) current line has no SEMICOLON;  (not 100% safe, as a linestart
         //       <;><statements...> will fool us into not reparsing... -as-)
         //   (c) next line is just a SHOW line;
         //   (d) next line was modified;
         //   (e) next line has a classBackwardLink.
         // Also: current line has PARSE_PENDING_NEXT_DELETED_MASK?!? -as-
         if (((classes & classForwardLink) == 0) &&
             ((classes & classSemicolon) != 0)   &&
             (!view.show(endElem+1))             &&
             ((view.parsePending(endElem+1) & PARSE_PENDING_CHANGE_MASK) == 0) &&
             ((view.elementClasses(endElem+1) & classBackwardLink) == 0)) {
            //freeElement(); // free (unlock) this try line,
            break;           // break out of loop
            }
         }

      return endElem;
   }

   /**
    * Set any interface method signatures.
    * Checks all interface declarations from interfaceElement to the end of the
    * document, and the no-body methods inside their scope.
    * Incremental parse:  if an interface was / is / is now defined in this doc,
    * reparse some more;  expensive but interfaces are, as a rule, small files!?
    * NB On e.g., a BLOCK MOVE operation, the two ranges of elements affected
    * are *not* called to be parseElement()d in ascending-element order...
    *
    * NOTES:
    *  - there are some assumptions here not several things in same element *as*
    *  - on the indexOf("interface") should check elementStyles too!        *as*
    *  - optimize - no styles needed to be set during this reparsing!       *as*
    *             - do a parseScope() from { to }, counting braces as they
    *               are encountered!  Will save on scope()'s match()!!      *as*
    *
    * @param changedElement 0 in parseAll(),
    *                       first element changed in parseElement()
    */
   private void     setInterfaceMethods(int changedElement)
   {
      int beginScope = interfaceElement;
      if (beginScope == 0)
         beginScope = 1;

      int  elements = view.elements();
      for (; beginScope <= elements; beginScope++) {
         long classes = view.elementClasses(beginScope);
         // search for "interface"s & reparse within their scope
         if ((classes & classInterface) != 0) {
            interfaceScope = scope(new LpexDocumentLocation(beginScope,
                          view.elementText(beginScope).indexOf("interface")+1));
            if (interfaceScope != null) { // never null if i/f parsed correctly!
               if (interfaceScope.element >= changedElement)
                  doParse(evaluateBeginElement(beginScope),
                          evaluateEndElement(interfaceScope.element),
                          false, false);
               beginScope = interfaceScope.element;
               }
            }

         // in parseElement(), clear previously-set interface methods in between scopes
         else if ((changedElement > 0) && (beginScope >= changedElement) &&
                  ((classes & classInterfaceMethod) != 0))
            view.setElementClasses(beginScope, classes & ~classInterfaceMethod);
         }
      interfaceScope = null;
   }

   /**
    * Establish the scope "{ .. }" of a class, interface, function, etc.
    * Assume the first '{' encountered belongs to the scope sought (this will be
    * true if class, etc. only set when indeed specified correctly)...      *as*
    *
    * class a {          // a
    *   class b {        // a.b
    *     method_c() {}  // a.b.c
    *   }
    *   method_d() {}    // a.d
    * }
    *
    * @param begin approximate (ONE-based element+column) start of scope,
    *              e.g., indexOf("class")
    * @return document location (ONE-based element+column) end of scope, or
    *         end of doc if scope-closing '}' or ';' not found, or
    *         <code>null</code> if scope-beginning '{' not found
    */
   private LpexDocumentLocation scope(LpexDocumentLocation begin)
   {
      String text, style;
      int position = begin.position-1;
      if (position < 0)
         position = 0;
      int element  = begin.element;
      int elements = view.elements();

      // 1.- abstract & interface methods - scope defined by the ending ';'
      if ((view.elementClasses(element) &
           (classAbstractMethod | classInterfaceMethod)) != 0) {
         for (; element <= elements; element++) {
            text = view.elementText(element);
            while ((position=text.indexOf(';', position)) >= 0) {
               style = view.elementStyle(element);
               if (style.length() > position && style.charAt(position) == 'p')
                  return new LpexDocumentLocation(element, position+1);
               }
            position = 0;
            }

         return new LpexDocumentLocation(elements,         // ';' was not found.
                         view.elementText(elements).length());
         }

      // 2.- classes & interfaces & methods - scope defined by the ending '}'
      for (; element <= elements; element++) {
         text = view.elementText(element);
         while ((position=text.indexOf('{', position)) >= 0) {
            style = view.elementStyle(element);
            if (style.length() > position && style.charAt(position) == 'b') {
               LpexDocumentLocation endLoc =    // == LpexMatch.match(view, ..);
                  match(new LpexDocumentLocation(element, position+1));
               if (endLoc == null)         // no matching '}', return end of doc
                  endLoc = new LpexDocumentLocation(elements,
                                    view.elementText(elements).length());
               return endLoc;
               }
            position++;
            }//end "while" searching for '{'
         position = 0;
         }

      return null;                         // '{' was not found.
   }

   /**
    * Own version of LpexMatch.match(), optimized for our scope search:
    * find the matching '}' for our brace-style '{'.
    */
   private LpexDocumentLocation match(LpexDocumentLocation loc)
   {
      int elements = view.elements();
      int i = loc.position-1;                          // char index in the text
      int element = loc.element;

      String text, style;
      for (int nesting = 0;  element <= elements;  element++, i=0) {
         if ((view.elementClasses(element) & classBrace) == 0)
            continue;
         text  = view.elementText(element);
         style = view.elementStyle(element);
         int len = text.length();
         for (; i < len;  i++) {
            char ch = text.charAt(i);                 // char & style must match
            if (ch == '{') {
               if ((style.length() > i) && (style.charAt(i) == 'b'))
                  nesting++;                              // go one level deeper
               }
            else if (ch == '}') {
               if ((style.length() > i) && (style.charAt(i) == 'b'))
                  if (--nesting == 0)
                     return new LpexDocumentLocation(element, i+1);    // match.
               }
            }
         }

      return null;
   }

   /**
    * Check whether a potential interface method is indeed part of an
    * "interface" declaration.  We've just parsed a ';' while waiting
    * for the '{' of a method signature.
    * Interface methods are reparsed separately from regular parsing,
    * during which reparsing a certain interfaceScope is set.
    */
   private boolean  isInterfaceMethod(Token t)
   {
      if (interfaceScope == null)
         return false;

      return ((interfaceScope.element > t.endLine) ||
              ((interfaceScope.element == t.endLine) &&
               (interfaceScope.position >= t.endColumn)));
   }

   /**
    * Set a class for all the elements that belong to a parse unit, and
    * double-link them if necessary.  Note that strictly for purposes of
    * incremental parsing, double-linking is not really always necessary,
    * as evaluateXxxxxElement()s usually go back & forth up to lines with
    * a SEMICOLON;  others, though, may use it, e.g., doc() & trace().
    *
    * <p>Sets a method class in all the elements of a method signature;
    * for abstract methods, forward/backward links for incremental parse are set
    * starting from the element where the "abstract" keyword is specified;
    * it also sets an anonymous class, and marks imbedded SQL.</p>
    *
    * @param methodClass the class bit-mask to set:  classMethod /
    *                    classAbstractMethod / class InterfaceMethod /
    *                    classAnonymousClass / classSql
    */
   private void     setMethod(long methodClass)
   {
      // abstractElement is only used for tagging abstract methods
      if ((methodClass & classAbstractMethod) == 0)
         abstractElement = beginMethod;

      // for a multi-line method declaration, double-link classes
      long classes = (abstractElement < endMethod)? classForwardLink : 0;
      int  currentElement = stream.getEndLine();
      for (int i = abstractElement; i <= endMethod; i++) {
         if (view.show(i))
            continue;
         if (i == beginMethod)
            classes |=  methodClass;
         if (i == endMethod)
            classes &= ~classForwardLink;
         if (i == currentElement)
            stream.setClasses(classes);
         else
            view.setElementClasses(i, view.elementClasses(i) &
                                       ~classSpace | classes);
         classes |= classBackwardLink;
         }
   }

   /**
    * Display an error message for an element.
    * We don't fiddle with messages when re-parsing scope for interface methods.
    */
   private void     addErrorMessage(int element, String message)
   {
      if (interfaceScope == null)
         addMessage(element,
                    LpexResources.message(getLanguage() + "." + message));
   }

   /**
    * Remove error messages for a given range of elements.
    * We don't fiddle with messages when re-parsing scope for interface methods.
    */
   private void     removeErrorMessages(int beginElement, int endElement)
   {
      if (interfaceScope == null)
         removeMessages(beginElement, endElement);
   }

   /**
    * Filter view to the methods in the source code.
    */
   void             methods()
   {
      view.doDefaultCommand("set includedClasses " +
         CLASS_CLASS  +" "+ CLASS_ANONYMOUSCLASS +" "+
         CLASS_INTERFACE +" "+
         CLASS_METHOD +" "+ CLASS_ABSTRACTMETHOD +" "+ CLASS_INTERFACEMETHOD);
      view.doDefaultCommand("set excludedClasses");
   }

   /**
    * Filter view to a logical outline of the source code.
    */
   void             outline()
   {
      view.doDefaultCommand("set includedClasses " +
         CLASS_BRACE  +" "+ CLASS_CONTROL +" "+
         CLASS_CLASS  +" "+ CLASS_ANONYMOUSCLASS +" "+
         CLASS_INTERFACE +" "+
         CLASS_METHOD +" "+ CLASS_ABSTRACTMETHOD +" "+ CLASS_INTERFACEMETHOD);
      view.doDefaultCommand("set excludedClasses");
   }

   /**
    * Document a class / interface / method - add a detailed javadoc comment
    * block.  Assumes that the class / interface / method we try to document
    * starts on a new line, and any type / qualifier and its id are on the same
    * line.
    *
    * @param cursor document location in the scope of the class / interface /
    *               method to document
    */
   void             document(LpexDocumentLocation cursor)
   {
      /*------------------------------------------------------------*/
      /*  look for top of the class / interface / method we are in  */
      /*------------------------------------------------------------*/
      int topElement = topOfScope(cursor,
                          classClass | classAnonymousClass | classInterface |
                          classMethod | classAbstractMethod | classInterfaceMethod,
                          0);
      if (topElement == 0)
         return;              // no class / interface / method found for cursor.

      int docElement = topElement;

      /*----------------------------------------------------------------------*/
      /*  check whether not documented already (prev element==comments only)  */
      /*----------------------------------------------------------------------*/
      if (topElement > 1) {
         int prevElement = topElement - 1;

         // go up through any show lines
         while (prevElement > 0 && view.show(prevElement))
            prevElement--;

         // go up through any regular "/* .. */" or "//" comments
         while (prevElement > 0 &&
                (view.elementClasses(prevElement) &
                     (classAll & ~(classBackwardLink | classForwardLink))) == classComment) {
            docElement = prevElement; // our javadoc block before other immediate comments
            prevElement--;
            }

         // if it is already javadoc-ed, just go there...
         if (prevElement > 0) {
            long classes = view.elementClasses(prevElement);
            // go up through any empty lines
            while (prevElement > 1 && (classes & classAll) == classSpace) {
               prevElement--;
               classes = view.elementClasses(prevElement);
               }
            if ((classes & (classAll & ~classBackwardLink)) == classJavaComment) {
               // go to as nice as possible a place inside the javadoc comment block
               while (prevElement > 1 &&
                      (classes & (classAll & ~classForwardLink)) ==
                        (classJavaComment | classBackwardLink)) {
                  prevElement--;
                  classes = view.elementClasses(prevElement);
                  }
               view.jump(prevElement, view.elementText(prevElement).length()+1);
               view.doDefaultAction(LpexConstants.ACTION_TEXT_WINDOW);
               return;
               }
            }
         }

      /*---------------*/
      /*  document it  */
      /*---------------*/
      long classes = view.elementClasses(topElement); // classes of what we doc'ing
      String t = view.elementText(topElement);                  // get indent value
      int i = 0;
      for (; i < t.length() && (t.charAt(i)==' ' || t.charAt(i)=='\t'); i++) {}
      String indent = t.substring(0, i);

      // insert the top of a javadoc comment block
      LpexDocumentLocation loc = new LpexDocumentLocation(docElement, 1);
      view.doDefaultCommand(loc, "insertText " + indent + "/**\n" + indent + " * ");
      // save this location for setting the cursor at the end
      LpexDocumentLocation cursorLoc = new LpexDocumentLocation(loc);
      view.doDefaultCommand(loc, "insertText \n");
      loc.element--; // just do inserts (i.e., insert new lines) from now on...

      // add an @author tag for class & interface, if one defined
      if ((classes & (classClass | classInterface)) != 0) {
         String author = getProperty("author");
         if (author != null && author.length() != 0)
            view.doDefaultCommand(loc, "insert " + indent + " * @author " + author.trim());
         }

      // add any method tags
      if ((classes &
          (classMethod | classAbstractMethod | classInterfaceMethod)) != 0) {
         String[] st = getMethodDocTags(topElement+2); //NB we upped method line +2
         for (i = 0; i < st.length && st[i] != null; i++)
            view.doDefaultCommand(loc, "insert " + indent + st[i] + " ");
         }

      // finally add the end of the javadoc comment block
      view.doDefaultCommand(loc, "insert " + indent + " */");
      view.jump(cursorLoc);
      view.doDefaultAction(LpexConstants.ACTION_TEXT_WINDOW);
   }

   /**
    * Insert trace call(s) for a method.
    *
    * @param cursor document location in the scope of the method to document
    */
   void             trace(LpexDocumentLocation cursor)
   {
      /*------------------------------------------------------------------*/
      /*  look for top element (id) of signature of the method we are in  */
      /*------------------------------------------------------------------*/
      int element = topOfScope(cursor, classMethod,
             // if inside an anonymous class but outside the scope of any of its
             // methods, don't try to trace the class's encompassing method!...
                               classAnonymousClass);
      if (element == 0)
         return;                     // nothing that we can in good faith trace.

      /*------------------------*/
      /*  get method's details  */
      /*------------------------*/
      LpexDocumentLocation loc = new LpexDocumentLocation(element,1);
      LpexDocumentLocation s = scope(loc);   // loc of method body's closing '}'

      // get class name
      String className  = getMethodClass(loc);
      // get method name;  loc := location of '(' start of method's parameters
      String methodName = getMethodId(loc);
      // check if constructor, make up full method name
      boolean constructor = className.equals(methodName);
      if (className.length() > 0)
         className += '.';
      methodName = className + methodName + "()";

      // get method's parameters, if any, and expand them for the trace statement
      String[] st = getMethodParams(loc);
      String parms = "";
      for (int i = 0; i < st.length && st[i] != null; i++) {
         if (i > 0)
            parms += " + ";
         parms += "\" "+st[i]+"=\"+"+st[i];
         }
      if (parms.length() == 0)
         parms = "\"\"";

      loc = LpexMatch.match(view, s);   // remember loc of method body-start '{'
      String traceBegin = getProperty("traceBegin");
      String traceEnd   = getProperty("traceEnd");

      /*-------------------------------------*/
      /*  insert method-end trace statement  */
      /*-------------------------------------*/
      if (traceEnd != null && traceEnd.trim().length() != 0) {
         int indent = s.position;                      // until AI is in... *as*
         // if last statement is a "return .. ;", must insert trace beforehand
         // insert trace-end statement before *every* return in method?! -as-
         boolean preReturn = adjustToLastReturn(s);
         // now s == location of either final '}' or "return .. ;"
         view.doDefaultCommand(s, "action split");
         String command;
         if (view.elementText(s.element).trim().length() == 0)
            command = "replaceText ";
         else {
            command = "insert ";
            indent = -1;
            }
         Object[] arguments = { methodName };
         try {
            traceEnd = MessageFormat.format(traceEnd, arguments);
            }
         catch (Exception e) {}
         view.doDefaultCommand(s, command + traceEnd);
         if (indent >= 0) {                            // until AI is in... *as*
            indentText(s.element, indent);
            if (!preReturn)
               indentText(s.element+1, indent);
            }
         else
            indentText(s.element);
         }

      /*---------------------------------------*/
      /*  insert method-begin trace statement  */
      /*---------------------------------------*/
      if (traceBegin != null && traceBegin.trim().length() != 0) {
         view.doDefaultCommand("parse"); // avoid halfbaked stuff from end trace
         int indent = loc.position;                    // until AI is in... *as*
         // if 1st is a constructor's "super(..);", must insert trace after it
         if (constructor)
            adjustToAfterSuper(loc);
         // now loc == location of either opening '{' / after "super(..);"
         String text = view.elementText(loc.element);
         if (text.length() > loc.position &&
             text.substring(loc.position).trim().length() != 0) {
            loc.position++;
            view.doDefaultCommand(loc, "action split");
            indent = -1;
            }
         Object[] arguments = { methodName, parms };
         try {
            traceBegin = MessageFormat.format(traceBegin, arguments);
            }
         catch (Exception e) {}
         view.doDefaultCommand(loc, "insert " + traceBegin);
         if (indent >= 0)                              // until AI is in... *as*
            indentText(loc.element, indent);
         else
            indentText(loc.element);
         }
   }

   /**
    * Get a method class name for the "trace" command.
    *
    * @param cursor the beginning of a method signature
    * @return name of the method's class
    * @see #trace
    */
   private String   getMethodClass(LpexDocumentLocation cursor)
   {
      String s = "";

      /*-----------------------------------------------*/
      /*  look for the class of the method at element  */
      /*-----------------------------------------------*/
      int element = topOfScope(cursor, classClass | classAnonymousClass, 0);
      if (element == 0)
         return s;                      // class for this method just not there.

      /*----------------------*/
      /*  get the class name  */
      /*----------------------*/
      // is the encompassing class an anonymous class?
      boolean anonymous = (view.elementClasses(element) & classAnonymousClass) != 0;
      boolean className = false; // true after "class" found: class name follows
      char endChar = anonymous? '(' : '{';  // end of class name search

      int i = 0;
      String text = elementCode(element);
      // fast, dumb way to avoid using x (also coming before a '('!) when
      // the class is y in "x(new y() { method() {/*tracing this*/} });"
      if (anonymous) {
         i = text.indexOf("new");
         if (i == -1)
            i = 0;
         }

      for (;;) {
         int j = text.indexOf(endChar, i);  // '{'/'(', StringTokenize end point
         StringTokenizer st = new
            StringTokenizer(text.substring(i, (j==-1)? text.length() : j)," \t");
         while (st.hasMoreTokens()) {
            String t = st.nextToken();
            if (anonymous)           // name of anonymous class just before '(',
               s = t;
            else {                   //  of regular class - just after "class"
               if (t.equals("class"))
                  className = true;
               else if (className == true)
                  return t;
               }
            }

         if (j >= 0)
            break;     // got to the '{'/'(', should have got class name by now.
         // "class" .. '{' elements are not currently linked... *as*
         // if ((view.elementClasses(element) & classForwardLink) == 0)
         //  break;                                      // no more class lines.

         do {                   // go to the next class line, skip show elements
            element++;
            } while ((element <= view.elements()) && view.show(element));
         if (element > view.elements())
            break;
         // as not linking class lines now, abort if eg, classMethod here?! *as*
         text = elementCode(element);
         i = 0;
         }

      return s;                  // but may be nested classes e.g., a.b.c?! *as*
   }

   /**
    * Get a method's id for the "trace" command.
    * @param loc location of the first element of the method signature;
    *            upon exit = location of the '(' where the method's parameters
    *            start
    * @see #trace
    */
   private String   getMethodId(LpexDocumentLocation loc)
   {
      int element = loc.element;
      String types =                            // ignore "new" and method types
      " public protected private static abstract final native synchronized void new ";
      String s = null;

      String text = elementCode(element);
      for (;;) {
         int j = text.indexOf('(');   // '(', i.e., end point of StringTokenize
         StringTokenizer st = new
            StringTokenizer(text.substring(0, (j==-1)? text.length() : j), " \t");
         while (st.hasMoreTokens()) {
            String t = st.nextToken();
            if (types.indexOf(" "+t+" ") < 0)
               s = t;                 // method id / primitive type
            }

         if (j >= 0) {                // on the '(', must have method id by now:
            loc.element  = element;   //  update loc,
            loc.position = j+1;
            break;                    //  break & return.
            }
         if ((view.elementClasses(element) & classForwardLink) == 0)
            break;                    // no more method lines.
         do {                         // go to next method line, skip show lines
            element++;
            } while ((element <= view.elements()) && view.show(element));
         if (element > view.elements())
            break;
         text = elementCode(element);
         }

      return s;
   }

   /**
    * Get a method's parameters for the "trace" command.
    * Current assumption:
    *   - param type id's have no spaces around '.'s (eg, abc.def not abc. def)
    *
    * @param loc location of the '(' where the method's parameters start;
    *            upon exit = location of method parameters' ending ')'
    * @see #trace
    */
   private String[] getMethodParams(LpexDocumentLocation loc)
   {
      int element = loc.element;
      String[] s = new String[16];
      int n = 0;                                                 // index into s

      String text = elementCode(element);
      boolean type = true;                        // expect a param *type* first
      int i, j;                           // start, end points to StringTokenize
      for (i = loc.position; n < s.length;) {
         j = text.indexOf(')');        // ')', i.e., end point of StringTokenize
         StringTokenizer st = new
            StringTokenizer(text.substring(i, (j==-1)? text.length():j), " \t,");
         while (st.hasMoreTokens() && n < s.length) {
            String t = st.nextToken();
            if (!type)
               s[n++] = t;
            type = !type;                   //   toggle parm type - parm id
            }

         if (j >= 0) {                      // on the ')', got all parms by now:
            loc.element  = element;         //  update loc,
            loc.position = j+1;
            break;                          //  break & return.
            }
         if ((view.elementClasses(element) & classForwardLink) == 0)
            break;                                      // no more method lines.
         do {                     // go to the next method line, skip show lines
            element++;
            } while ((element <= view.elements()) && view.show(element));
         if (element > view.elements())
            break;
         text = elementCode(element);
         i = 0;
         }

      return s;
   }

   /**
    * Get the javadoc tags (@param, @return, @exception) of a method for the
    * "doc" command.
    * Current assumptions:
    *   - return type & method id should be on the same line
    *   - type id's should have no spaces around '.'s (eg, abc.def not abc. def)
    *
    * @param element the first element of a method signature
    * @see #document
    */
   private String[] getMethodDocTags(int element)
   {
      String types =
         " public protected private static abstract final native synchronized void ";
      String[] s = new String[32];
      int n = 0;                                                 // index into s

      String text = elementCode(element);
      int target = 0;         // looking for return(0) /params(1) /exceptions(2)
      int returntag = 0;              // count primitive types / ids for @return
      boolean type = true;                 // in (1) expect a param *type* first
      char endChar = '(';
      int  i, j;                          // start, end points to StringTokenize
      for (i = 0, j = -1; n < s.length;) {
         if (i != -1) {
            j = text.indexOf(endChar, i);
            StringTokenizer st = new
               StringTokenizer(text.substring(i, (j==-1)? text.length() : j),
                               " \t,(){;");
            while (st.hasMoreTokens() && n < s.length) {
               String t = st.nextToken();
               if (target == 0) {                // 0.- looking for return type
                  //if (t.equals("new"))
                  // returntag=-9999; //anonymous class...
                  if (types.indexOf(" "+t+" ") < 0)
                     returntag++;                //   primitive type / id
                  }
               else if (target == 1) {           // 1.- looking for params
                  if (!type)
                     s[n++] = " * @param "+t;
                  type = !type;                  //   toggle parm type - parm id
                  }
               else if (!t.equals("throws"))     // 2.- looking for exceptions
                  s[n++] = " * @exception "+t;
               }
            }

         if (j == -1) {                          // didn't find endChar yet
            if ((view.elementClasses(element) & classForwardLink) == 0)
               break;                            // no more method lines.

            do {                                 // skip show lines
               element++;
               } while ((element <= view.elements()) && view.show(element));
            if (element > view.elements())
               break;                            // no more lines at all.

            text = elementCode(element);         // the next method line
            }
         else {
            if (++target > 2)                    // go to the next target
               break;            // we've got all params & exceptions we wanted.
            if (target == 2 && returntag > 1 && n < s.length)
               s[n++] = " * @return";
            endChar = (target == 1)? ')' : '{';
            i = j = -1;
            }

         if (i != -1)                            // found beginChar already
            i = 0;
         else
            i = text.indexOf((target == 1)? '(' : ')');
         }//end "for"

      return s;
   }

   /**
    * Adjust a document location pointing to end of a method body, to the last
    * statement in this method if this is a "return .. ;".
    *
    * @param cursor document location of a method body's closing '}';
    *               on exit it is adjusted to the location of "return ..;",
    *               if any
    * @return true if cursor adjusted
    * @see #trace
    */
   private boolean  adjustToLastReturn(LpexDocumentLocation cursor)
   {
      // *as* for now just simple-minded short "return();" on prev line, etc.
      if (cursor.element > 1) {
         String text = elementCode(cursor.element-1).trim();
         int i = text.indexOf("return");
         if (i >= 0 && text.indexOf(";", i) >= 0) {
            cursor.element--;
            cursor.position = i+1;
            return true;
            }
         }
      return false;
   }

   /**
    * Adjust a document location pointing to start of a constructor method body,
    * to the first statement in this method which follows any "super(..);".
    *
    * @param cursor document location of a constructor body's opening '{';
    *               on exit it is adjusted to the location after "super(..);",
    *               if any
    * @see #trace
    */
   private void     adjustToAfterSuper(LpexDocumentLocation cursor)
   {
      // for now assume "super" and its ";" are on same line... -as-
      String text = "";
      int element = cursor.element;
      int i = cursor.position;
      while (element <= view.elements()) {
         if (!view.show(element)) {
            text = elementCode(element);
            if (text.length() > i) {
               text = text.substring(i).trim();
               if (text.length() != 0)
                  break;
               }
            }
         element++;
         i = 0;
         }
      if (element > view.elements())
         return;

      if (text.startsWith("super") && text.indexOf(';') >= 0 &&
          text.substring(5).trim().startsWith("(")) {
         cursor.element  = element;
         cursor.position = view.elementText(element).indexOf(';', i)+1;
         }
   }

   /**
    * Get the first element of the top type of structure sought (class /
    * interface / method), which encompasses cursor in its scope:
    *   get the method in which cursor is, if indeed in a method (for trace()),
    *   get the class of a method starting at cursor (for trace()),
    *   get the class / interface / method we're in (for document()).
    * If an undesirable structure found first (i.e., it is the more immediate
    * scope), 'not found' is returned.
    *
    * @param cursor     document location in the scope of the structure sought
    *                   (e.g., the beginning of a method signature whose class
    *                   we're looking for)
    * @param topClass   the element class(es) we're looking for
    * @param breakClass class(es) (if any) which should abort the search if
    *                   cursor is in their scope
    *
    * @return first element of the top structure, or 0 if not found
    */
   private int      topOfScope(LpexDocumentLocation cursor, long topClass,
                               long breakClass)
   {
      int  element = cursor.element;
      long multiElement = topClass &    // seeking a class which may span lines?
                     (classMethod | classAbstractMethod | classInterfaceMethod);
      LpexDocumentLocation s;

      // find the top class at or above us
      for (;;) {
         for (; element >= 1; element--) {
            // candidate make element
            if ((view.elementClasses(element) & topClass) != 0)
               break;

            // if a break class encountered whose scope includes cursor, return
            if ((view.elementClasses(element) & breakClass) != 0) {
               s = scope(new LpexDocumentLocation(element, 1));
               if (s != null) { // never null if class parsed fully & correctly!
                  if ((s.element > cursor.element) ||
                      ((s.element == cursor.element) &&
                       (s.position >= cursor.position)))
                     return 0;             // a valid enclosing top not found...
                  }
               }
            }//end "for"

         if (element < 1)
            return 0;                              // no elements to talk about.

         // go up to first linked line if dealing with multi-element class(es)
         if (multiElement != 0) {
            long c;
            int  prevElement = element-1;
            while (((c=view.elementClasses(element)) & classBackwardLink) != 0) {
               while ((prevElement > 0) && view.show(prevElement))
                  prevElement--;                              // skip show lines
               if (prevElement < 1)
                  break;
               if ((view.elementClasses(prevElement) & multiElement) == 0)
                  break;
               element = prevElement--;
               }//end "while" linked
            if ((c & topClass) == 0)
               return 0;    // not a top structure (method / class / interface).
            }

         // if scope of what we found doesn't include cursor, go on (nesteds)...
         // (here we should first find "class" or "interface" or etc., depending
         // on what we're looking for, as the scope-search starting point)  -as-
         s = scope(new LpexDocumentLocation(element, 1));
         if (s == null)
            return 0;     // never null if class, etc. parsed fully & correctly!
         if ((s.element > cursor.element) ||
             ((s.element == cursor.element) && (s.position >= cursor.position)))
            break;       // element has the "class" for method's scope
         element--;      // go on searching backwards for a better "class"...
         }//end "for"

      return element;
   }

   /**
    * Get the bare code (comments stripped) of an element.
    * The comment characters are blanked out in the returned String.
    */
   private String   elementCode(int element)
   {
      String cmt   = "c";                                    // comment style(s)
      String style = view.elementStyle(element);
      StringBuffer code = new StringBuffer(view.elementText(element));
      int i = style.length();
      if (code.length() < i)
         i = code.length();

      while (--i >= 0)
         if (cmt.indexOf(style.charAt(i)) >= 0)
            code.setCharAt(i, ' ');

      return code.toString();
   }

   /**
    * Set/switch lexer.
    *
    * @return true = new lexer set as the active lexer;
    *                it is set in its DEFAULT lexical state.
    */
   private boolean  setLexer(int newLexer)
   {
      if (newLexer == LEXER_JAVA)
         javaLexer.initialize();
      else { // newLexer == LEXER_SQL
         if (sqlLexer == null) {
            sqlLexer = getSqlLexer(stream);
            if (sqlLexer == null)
               return false;
            }
         sqlLexer.initialize();
         }
      activeLexer = newLexer;
      return true;
   }

   /**
    * Retrieve the SqlLexer.
    * The document parser extending JavaParser to support embedded SQL
    * statements must override this method to construct and return an SqlLexer
    * object.
    * The implementation of this method provided by the JavaParser class does
    * nothing, except return null.
    *
    * @param stream input character stream for the SQL lexer
    */
   public SqlLexer  getSqlLexer(LpexCharStream stream)
   {
      return null;
   }

   /**
    * Reinitialize active lexer for the same input char stream.
    * For example, after an exception (such as EOF at end of the
    * initially-estimated parse range):  we skip the token in
    * error and continue parsing.
    */
   private void     reinitializeLexer()
   {
      if (activeLexer == LEXER_JAVA)
         javaLexer.reinitialize();
      else // activeLexer == LEXER_SQL
         sqlLexer.reinitialize();
   }

   /**
    * Process a token with the active lexer.
    *
    * @return LEXER_RC_OK, LEXER_RC_EOF
    * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_OK
    * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_EOF
    */
   private int      processToken()
   {
      int rc;
      if (activeLexer == LEXER_JAVA)
         rc = javaLexer.processToken();
      else { // activeLexer == LEXER_SQL
         rc = sqlLexer.processToken();
         // embedded-SQL statement's executable clause ended
         if ((rc & LEXER_RC_END) != 0) {
            setLexer(LEXER_JAVA);
            method = METHOD_SQLCLAUSE;
            rc = LEXER_RC_OK;
            }
         // if LEXER_RC_EOF returned, we can ignore the LEXER_RC_MORE part, as
         // doParse() will try to extend the parse range anyway:  method is
         // SQL, not METHOD_NONE - see doParse().
         }
      return rc;
   }


   /**
    * Subclass LpexJavaParserTokenManager for LPEX-specific operations.
    * LpexJavaParserTokenManager.java, our token manager for the grammar,
    * is generated by:
    *   x:\JavaCC\bin\javacc cc\LpexJavaParser.jj
    * We only use JavaCC's token manager, attempting our own parsing -
    * otherwise it's quite difficult to handle LPEX's incremental parsing...
    */
   final class JavaLexer extends LpexJavaParserTokenManager
   {
      private int lastToken; // last token (t.kind) processed

      JavaLexer(LpexCharStream charStream)
      {
         super(charStream /*,DEFAULT*/);
      }

      /**
       * Initialize the token manager for the same character input stream,
       * and in the default lexical state (DEFAULT).
       * This method is normally called when the parser sets / switches the
       * active lexer [back] to the Java lexer.
       */
      void           initialize()
      {
         ReInit(stream);
         lastToken = EOF;                      // ignore previous [SQL] tokens
         comments = 0;                         // not inside multi-line comments
      }

      /**
       * Reinitialize the token manager for the same character input stream,
       * and in the default lexical state (DEFAULT).
       * This method is normally called after a TokenMgrError exception (e.g.,
       * encountered EOF in the middle of a token / a bad character), after the
       * token in error is skipped and we continue parsing.
       */
      void           reinitialize()
      {
         ReInit(stream);
      }

      /**
       * Like JavaCC's CommonTokenAction(), which is called just before
       * getNextToken() returns a matched token.
       * Comments are SPECIAL_TOKENs, and are being processed by setComment().
       * White space is SKIPped altogether.
       *
       * NOTES:
       *  - may want to parse correct declarations of "interface {":
       *    STATIC/ABSTRACT/FINAL/PUBLIC/PROTECTED/PRIVATE
       *      INTERFACE id [EXTENDS id.id [, id.id ..]] {
       *
       * @return LEXER_RC_OK, LEXER_RC_EOF
       *
       * @see #setComment
       * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_OK
       * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_EOF
       */
      private int    processToken()
      {
         /*======================================*/
         /*  A.- embedded SQL:  #sql .. { .. };  */
         /*======================================*/
         if ((method & METHOD_SQL) != 0)
            return processSQLToken();

         Token t = getNextToken();

         char style;
         long classes = classCode;
         int  currentToken = t.kind;

         /*====================*/
         /*  B.- regular Java  */
         /*====================*/
         switch (currentToken) {
            /*-------------------*/
            /*  keyword (token)  */
            /*-------------------*/
            case VOID:     // method result types: void | primitive type | id
            case BOOLEAN:  // primitive types
            case CHAR:
            case BYTE:
            case SHORT:
            case INT:
            case LONG:
            case FLOAT:
            case DOUBLE:
                 style = 'k';
                 if ((method & (METHOD_TOBRACE | METHOD_THROWS)) != 0)
                    method = METHOD_NONE;
                 break;

            case ABSTRACT: // method/variable attributes
                 style = 'k';
                 method = METHOD_ABSTRACT;
                 abstractElement = t.endLine;
                 break;
            case NEW:
                 style = 'k';
                 method = METHOD_NEW;
                 break;
            case PUBLIC:
            case PROTECTED:
            case PRIVATE:
            case STATIC:
            case FINAL:
            case NATIVE:
            case SYNCHRONIZED:
            case STRICTFP:

            case ASSERT:   // various
            case BREAK:
            case CONST:
            case CONTINUE:
            case EXTENDS:
            case FALSE:
            case GOTO:
            case IMPLEMENTS:
            case IMPORT:
            case INSTANCEOF:
            case NULL:
            case PACKAGE:
            case RETURN:
            case SUPER:
            case THIS:
            case THROW:
            case TRANSIENT:
            case TRUE:
            case VOLATILE:
                 style = 'k';
                 method = METHOD_NONE;
                 break;
            case THROWS: // the only acceptable keyword when expecting '{' in methods
                 if ((method & (METHOD_TOBRACE | METHOD_THROWS)) != 0)
                    // be easy on "throws"-typing repetitions...
                    method = method & ~METHOD_TOBRACE | METHOD_THROWS;
                 else
                    method = METHOD_NONE;
                 style = 'k';
                 break;

            case CASE:                         // keyword + "View" filter CONTROL
            case CATCH:
            case _DEFAULT:
            case DO:
            case ELSE:
            case FINALLY:
            case FOR:
            case IF:
            case SWITCH:
            case TRY:
            case WHILE:
                 style = 'k'; classes |= classControl;
                 method = METHOD_NONE;
                 break;

            case CLASS:                        // keyword + "View" filter CLASS
                 // (a) e.g., if (ClassNameXxx.class.isAssignable())
                 if (lastToken == DOT) {
                    style = 'i';
                    method = METHOD_NONE;
                    }
                 // (b) e.g., public class ANewClass {}
                 else {
                    style = 'k'; classes |= classClass;
                    method = METHOD_NONE;
                    }
                 break;
            case INTERFACE:
                 style = 'k'; classes |= classInterface;
                 method = METHOD_NONE;
                 if ((interfaceElement == 0) || (t.endLine < interfaceElement))
                    interfaceElement = t.endLine;
                 break;

            // there is an implicit "import java.lang.*;" assumed at the
            // beginning of a Java compilation unit, just after any "package"
            // statement in the unit - could highlight java.lang types?! -as-

            /*------------*/
            /*  constant  */
            /*------------*/
            case INTEGER_LITERAL:
            case FLOATING_POINT_LITERAL:
            case CHARACTER_LITERAL:
                 style = 'n';
                 method = METHOD_NONE;
                 break;
            case BADOCTAL_LITERAL:
                 style = 'e';
                 classes |= classError;
                 addErrorMessage(t.endLine, "badOctal");
                 break;

            /*------------------*/
            /*  string literal  */
            /*------------------*/
            case STRING_LITERAL:
                 style = 'q';
                 method = METHOD_NONE;
                 break;

            /*--------------*/
            /*  identifier  */
            /*--------------*/
            case IDENTIFIER:
                 style = 'i';
                 if (method == METHOD_NONE) {
                    if (lastToken != ASSIGN && lastToken != DOT &&
                        lastToken != RETURN &&
                        lastToken != ASSERT && lastToken != COLON) {
                        // & others, not critical - better to check for what's OK!!
                        // these checks are done here mainly in order to keep
                        // "interface method" alarms to a minimum
                       method = METHOD_ID;
                       beginMethod = t.endLine;
                       }
                    }
                 else if (method == METHOD_ABSTRACT || method == METHOD_NEW) {
                    method |= METHOD_ID;
                    beginMethod = t.endLine;
                    }
                 else if ((method & METHOD_ID) != 0) {
                    if (lastToken == DOT)
                       method = method & ~METHOD_ID | METHOD_NONE;
                    else
                       beginMethod = t.endLine;        // adjust start to method id
                    }
                 else if ((method & METHOD_TOBRACE) != 0)
                    method = METHOD_NONE;      // was expecting "throws" / '{' only
                 else if ((method & METHOD_THROWS) != 0)
                    endMethod = t.endLine; // adjust end to "throws"'s exception id
                 break;

            /*--------------------------*/
            /*  punctuator (separator)  */
            /*--------------------------*/
            case DOT:    // '.'
            case LBRACKET:
            case RBRACKET:
                 style = 'p';
                 break;
            case COMMA:  // ','
                 style = 'p';
                 if ((method & (METHOD_PARMS | METHOD_THROWS)) == 0)
                    method = METHOD_NONE;
                 break;
            case RPAREN: // ')'
                 style = 'p';
                 if ((method & METHOD_PARMS) != 0) {
                    method = method & ~METHOD_PARMS | METHOD_TOBRACE;
                    endMethod = t.endLine;
                    }
                 else
                    method = METHOD_NONE;
                 break;
            case LPAREN: // '('
                 style = 'p';
                 if ((method & METHOD_ID) != 0)
                    method = method & ~METHOD_ID | METHOD_PARMS;
                 else
                    method = METHOD_NONE;
                 break;
            case SEMICOLON: // ';'
                 style = 'p'; classes |= classSemicolon;
                 if ((method & (METHOD_TOBRACE | METHOD_THROWS)) != 0) {
                    if ((method & METHOD_ABSTRACT) != 0)
                       setMethod(classAbstractMethod);
                    else if (isInterfaceMethod(t))
                       setMethod(classInterfaceMethod);
                    }
                 method = METHOD_NONE;
                 break;
            case LBRACE: // '{'
                 style = 'b'; classes |= classBrace;
                 if ((method & (METHOD_TOBRACE | METHOD_THROWS)) != 0) {
                    if ((method & METHOD_NEW) != 0) {
                       endMethod = beginMethod;  // sets ANONYMOUSCLASS for id only
                       setMethod(classAnonymousClass);
                       }
                    else
                       setMethod(classMethod);
                    }
                 method = METHOD_NONE;
                 break;
            case RBRACE: // '}'
                 style = 'b'; classes |= classBrace;
                 method = METHOD_NONE;
                 break;

            /*------------*/
            /*  operator  */
            /*------------*/
            case ASSIGN: // '='
            case GT:
            case LT:
            case NOT:    // '!'
            case TILDE:
            case QUESTION:
            case EQ:     // "=="
            case LE:
            case GE:
            case NE:
            case SC_OR:
            case SC_AND:
            case INCR:
            case DECR:
            case PLUS:
            case MINUS:
            case STAR:
            case SLASH:
            case BIT_AND:
            case BIT_OR:
            case XOR:
            case REM:
            case LSHIFT:
            case RSIGNEDSHIFT:
            case RUNSIGNEDSHIFT:
            case PLUSASSIGN:
            case MINUSASSIGN:
            case STARASSIGN:
            case SLASHASSIGN:
            case ANDASSIGN:
            case ORASSIGN:
            case XORASSIGN:
            case REMASSIGN:
            case LSHIFTASSIGN:
            case RSIGNEDSHIFTASSIGN:
            case RUNSIGNEDSHIFTASSIGN:
            case COLON:
                 style = 'o';
                 method = METHOD_NONE;
                 break;

            /*------------------------------------------*/
            /*  Unicode sequence in middle of anything  */
            /*------------------------------------------*/
            case UNICODE:              // see .jj - should do it in LpexCharStream!
                 style = 'u';
                 break;

            /*-----------------------------------*/
            /*  end-of-comment from thin air...  */
            /*-----------------------------------*/
            case EOC:                  // unexpected end-of-comment "*/"
                 style = 'e';
                 classes = classError;
                 currentToken = lastToken;  // don't let EOC interfere with parsing
                 t.endColumn--;   // for extra char after "*/" that we check != "/"
                 addErrorMessage(t.endLine, "endOfComment");
                 break;

            /*----------------*/
            /*  imbedded SQL  */
            /*----------------*/
            case SQL:                  // imbedded SQL:  #sql { .. .. };
                 // if another METHOD in progress, stop it with ERROR!? -as-
                 style = 'k';
                 classes |= classControl;   // show it in "Logical outline" view
                 method = METHOD_SQLCLAUSE;
                 beginMethod = t.endLine;
                 break;

            /*-------------------------------------------------*/
            /*  end of current parse range / real end of file  */
            /*-------------------------------------------------*/
            case EOF:
                 return LEXER_RC_EOF;

            /*----------------------*/
            /*  everything else...  */
            /*----------------------*/
            //case ANY_CHAR:
            //   //*as* if it's a one-character-long token, try here
            //   // isJavaIdentifierStart() / Part() & eat-up and
            //   // process the ID here (if we want to handle, correctly, all
            //   // ranges = too much for the .jj) - check if not just continues
            //   // prev ID token indicated by TokenManager;  else error...
            //   style = 'e';
            //   classes |= classError;
            //   addErrorMessage(t.endLine, "syntaxError");
            //   break;

            default:
                 lastToken = currentToken;
                 return LEXER_RC_OK;
            }//end "switch"

         lastToken = currentToken;
         stream.setStyles(t.beginColumn, t.endColumn, style);
         stream.setClasses(classes);
         return LEXER_RC_OK;
      }

      /**
       * Handles the #sql construct's
       *     SQL clause "#sql .."
       * and the " .. ;" after the executable clause.
       * The executable clause is handled by the SqlLexer's processToken(),
       * if this is defined in this parser or in a subclassing parser;
       * the code here is sufficient to 'tolerate' the entire #sql construct.
       */
      private int    processSQLToken()
      {
         Token t = getNextToken();

         int currentToken = t.kind;
         if (currentToken == EOF)
            return LEXER_RC_EOF | LEXER_RC_MORE; // we're here, still in SQL...

         char style;
         long classes = classCode;

         /*------------------------*/
         /*  SQL CLAUSE "#sql .."  */
         /*------------------------*/
         if (method == METHOD_SQLCLAUSE) {
            if (currentToken == LBRACE) {         // '{'
               //mark with 'p' (=SqlLexer's style for the closing '}'), not 'b'
               //style = 'b'; classes |= classBrace;
               style = 'p';
               method = METHOD_SQLEXEC;
               setLexer(LEXER_SQL);
               }
            else if (currentToken == SEMICOLON) { // ';'
               style = 'p'; classes |= classSemicolon;
               endMethod = t.endLine;
               setMethod(classSql);
               method = METHOD_NONE;
               SwitchTo(DEFAULT); // switch scanner to default lexical state
               }
            else if (currentToken == RBRACE) {    // '}'
               style = 'e'; classes |= classError;
               addErrorMessage(t.endLine, "syntaxError");
               endMethod = t.endLine;
               setMethod(classSql);
               method = METHOD_NONE;
               SwitchTo(DEFAULT);
               }
            else {                                // SQL clause stuff...
               // if first thing after "#sql", check for white space in-between
               if (lastToken == SQL && t.beginColumn > 1 &&
                   stream.bufferStyles.charAt(t.beginColumn-2) == 'k') {
                  style = 'e'; classes |= classError;
                  addErrorMessage(t.endLine, "syntaxError");
                  endMethod = t.endLine;
                  setMethod(classSql);
                  method = METHOD_NONE;
                  SwitchTo(DEFAULT);
                  }
               // sqlj clause "iterator"
               else if (currentToken == ITERATOR)
                  style = 'k';
               // other sqlj clauses (or, in all fairness, any junk...)
               else // e.g., ANY_CHAR
                  style = '!';
               }
            }

         /*------------------------------------*/
         /*  SQL EXECUTABLE CLAUSE "{ .. }"    */
         /*  Actually handled by SqlLexer's    */
         /*  processToken(), where available.  */
         /*------------------------------------*/
         else {
            switch (currentToken) {
               case RBRACE:  // '}'
                    style = 'p';
                    //mark with 'p' (=SqlLexer's style for the closing '}'), not 'b'
                    //style = 'b'; classes |= classBrace;
                    method = METHOD_SQLCLAUSE;
                    break;

               //case LBRACE:  // '{' // Just ignore it...
               //     style = 'e'; classes |= classError;
               //     addMessage(t.endLine, "syntaxError");
               //     endMethod = t.endLine;
               //     setMethod(classSql);
               //     method = METHOD_NONE;
               //     SwitchTo(DEFAULT);
               //     break;

               default: // e.g., ANY_CHAR
                    style = '!'; // good enough default style...
                    break;
               }
            }

         lastToken = currentToken;
         stream.setStyles(t.beginColumn, t.endColumn, style);
         stream.setClasses(classes);
         return LEXER_RC_OK;
      }

      /**
       * Set style & class for comments.  Activated by \n, \r, or * /
       * encountered while in a comment SPECIAL_TOKEN.  SPECIAL_TOKEN, rather
       * than TOKEN, is used for these, as we don't need to see the same
       * tokens in processToken() too, nor have them recorded in the parse.
       *
       * Does the real work for the extended dummy in LpexJavaParser.jj.
       * @param t special token
       */
      protected void setComment(Token t)
      {
         int lexState = getCurLexState();
         long classes = (lexState == IN_FORMAL_COMMENT)? classJavaComment : classComment;

         switch (lexState) {
            case IN_FORMAL_COMMENT:
            case IN_MULTILINE_COMMENT:
            case IN_MULTILINE_SQLCOMMENT:
                 if (t.kind != COMMENT_END && t.kind != SQLCOMMENT_END)
                    classes |= classForwardLink;         // comment to be continued
                 if ((comments & classForwardLink) != 0) // continuing comment:
                    classes |= classBackwardLink;        //  double-link it
                 break;
            }
         comments = classes;

         if (t.endColumn >= t.beginColumn)
            stream.setStyles(t.beginColumn, t.endColumn, 'c');
         stream.setClasses(classes);
      }
   }
}