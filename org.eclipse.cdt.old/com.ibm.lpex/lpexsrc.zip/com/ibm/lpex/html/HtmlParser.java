//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// HtmlParser - document parser for HTML4.
//----------------------------------------------------------------------------

package com.ibm.lpex.html;

import java.util.Properties;
import java.util.ResourceBundle;

import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCharStream;
import com.ibm.lpex.core.LpexCommand;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexDocumentLocation;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import com.ibm.lpex.cc.LpexHtmlParserTokenManager;
import com.ibm.lpex.cc.Token;
import com.ibm.lpex.cc.TokenMgrError;


/**
 * Document parser for HTML.
 *
 * <p>Actions and assigned keys added by this document parser:
 * <ul>
 *   <li><b>htmlAmp</b> (Ctrl+&amp;) to insert an ampersand
 *       character entity reference (&amp;amp;)
 *   <li><b>htmlB</b> (Ctrl+B) to set the bold text style to the
 *       currently selected text
 *   <li><b>htmlGt</b> (Ctrl+&gt;) to insert a greater-than sign
 *       character entity reference (&amp;gt;)
 *   <li><b>htmlHrefs</b> for a selective view of the hyperlink references
 *       defined in the document
 *   <li><b>htmlI</b> (Ctrl+I) to set the italic text style to the
 *       currently selected text
 *   <li><b>htmlLt</b> (Ctrl+&lt;) to insert a less-than sign
 *       character entity reference (&amp;lt;)
 *   <li><b>htmlNbsp</b> (Ctrl+Space) to insert a non-breaking space
 *       character entity reference (&amp;nbsp;)
 *   <li><b>htmlQuot</b> (Ctrl+&quot;) to insert a double-quote
 *       character entity reference (&amp;quot;)
 *   <li><b>htmlTag</b> (Ctrl+T) to prompt for an element name, and insert a
 *       start-end pair of tags for this element around the currently selected
 *       text.
 * </ul></p>
 *
 * Keys already defined (e.g., by the active base profile) to an action
 * different from <b>nullAction</b> are not redefined in here.
 *
 * <p>Command added by this document parser:&nbsp;
 * <b>htmlTag</b> to insert a start-end pair of tags for the specified element
 * around the currently selected text.</p>
 *
 * <p>Template expansions (Ctrl+R) for an empty document, and for the following
 * keywords, are available in this parser's Profile.properties:&nbsp;
 * href, image, img, table.</p>
 */
public class HtmlParser extends LpexCommonParser
{
   // the input stream the view feeds
   private LpexCharStream stream;

   // this parser's default settings
   private static ResourceBundle resource =
      ResourceBundle.getBundle("com.ibm.lpex.html.Profile");

   // the element classes we use...
   private static final String
      CLASS_CODE       = "code",          // any markup / text on the line
      CLASS_SPACE      = "space",         // empty line
      CLASS_TAG        = "tag",           // <tag>
      CLASS_HREF       = "href",          // <tag href=
      CLASS_SCRIPT     = "script",        // <script>
      CLASS_FWDLINK    = "forwardLink",   // links multi-line
      CLASS_BWDLINK    = "backwardLink",  //   structures
      CLASS_COMMENT    = "comment",       // comment
      CLASS_TAGCOMMENT = "tagComment",    // tag comment
      CLASS_ERROR      = "error";         // syntax error

   // ...and their registered bitmasks
   private long
      classCode,
      classSpace,
      classTag,
      classHref,
      classScript,
      classForwardLink,
      classBackwardLink,
      classComment,
      classTagComment,
      classError,
      classAll;

   // lexers we (may) use
   private static final int
      LEXER_HTML       = 0,
      LEXER_JAVASCRIPT = 1;

   private HtmlLexer       htmlLexer;
   //ivate JavaScriptLexer javaScriptLexer;
   private int             activeLexer = LEXER_HTML;

   // token delimiters for LpexCommonParser's isTokenDelimiter()
   private static final String TOKEN_DELIMITERS = "<>/";


   /**
    * Constructor for the parser.
    * Adds all of the parser specifics to the LPEX document view.
    * Initializes the view for the parser:  sets up all the style attributes,
    * classes, etc. for the language-sensitive edit features supported.
    *
    * @param lpexView the document view associated with this parser
    */
   public HtmlParser(LpexView lpexView)
   {
      super(lpexView);        // LpexCommonParser constructor (view := lpexView)
      initializeParser();     // initialize LpexView with our stuff

      // instantiate an input stream for this view, and the main (HTML) lexer
      stream    = new LpexCharStream(view);
      htmlLexer = new HtmlLexer(stream);
   }

   /**
    * Total parse of the entire document.
    * Done initially, after a document has been loaded in LPEX, or after an
    * <b>updateProfile</b> command.
    */
   public void           parseAll()
   {
      if (view.elements() != 0)                  // a bit of preventive care...
         doParse(1, view.elements(), false);     // do the parse on entire doc
   }

   /**
    * Incremental parse.
    *
    * @param element the (first) element whose committed change triggered the
    *                parse, or the element that precedes/follows a deleted
    *                block.  The parser may identify other neighbouring
    *                elements that will have to be reparsed as a unit
    */
   public void           parseElement(int element)
   {
      if (view.elements() != 0)                  // play it safe...
         doParse(evaluateBeginElement(element),  // parse optimal range
                 evaluateEndElement(element),
                 true);                          // clear their parsePending flags
   }

   /**
    * Returns the parser's properties profile resource bundle.
    */
   public ResourceBundle getProfile()
   {
      return resource;
   }

   /**
    * Returns "HTML", the language supported by this parser.
    *
    * @see com.ibm.lpex.core.LpexCommonParser#LANGUAGE_HTML
    */
   public String         getLanguage()
   {
      return LANGUAGE_HTML;
   }

   /**
    * Initialize the parser for an LPEX document view: set up style attributes
    * for the styles we need, classes, etc., and initialize the view
    * for the language-sensitive edit features supported.
    */
   private void          initializeParser()
   {
      // set common attributes for the styles we use
      String tokenHighlight = getProperty("tokenHighlight");
      setStyleAttributes(tokenHighlight == null || !tokenHighlight.equals("off"));

      // register the classes we use & get their allocated bit-masks
      classCode            = view.registerClass(CLASS_CODE);
      classSpace           = view.registerClass(CLASS_SPACE);
      classTag             = view.registerClass(CLASS_TAG);
      classHref            = view.registerClass(CLASS_HREF);
      classScript          = view.registerClass(CLASS_SCRIPT);
      classForwardLink     = view.registerClass(CLASS_FWDLINK);
      classBackwardLink    = view.registerClass(CLASS_BWDLINK);
      classComment         = view.registerClass(CLASS_COMMENT);
      classTagComment      = view.registerClass(CLASS_TAGCOMMENT);
      classError           = view.registerClass(CLASS_ERROR);
      classAll = classCode | classSpace | classTag | classHref | classScript |
                 classForwardLink | classBackwardLink |
                 classComment | classTagComment | classError;

      // view filter action for hypertext references
      defineAction("htmlHrefs", null, new LpexAction()               // "htmlHrefs"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_HREF);
           view.doDefaultCommand("set excludedClasses"); }
         public boolean available(LpexView view)
         { return true; }
      });

      // convenient &
      defineAction("htmlAmp", "c-ampersand.t", new LpexAction()      // "htmlAmp"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("insertText &amp;"); }
         public boolean available(LpexView view)
         { return true; }
      });

      // convenient >
      defineAction("htmlGt", "c-greaterThanSign.t", new LpexAction() // "htmlGt"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("insertText &gt;"); }
         public boolean available(LpexView view)
         { return true; }
      });

      // convenient <
      defineAction("htmlLt", "c-lessThanSign.t", new LpexAction()    // "htmlLt"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("insertText &lt;"); }
         public boolean available(LpexView view)
         { return true; }
      });

      // convenient non-breaking space
      defineAction("htmlNbsp", "c-space.t", new LpexAction()         // "htmlNbsp"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("insertText &nbsp;"); }
         public boolean available(LpexView view)
         { return true; }
      });

      // convenient "
      defineAction("htmlQuot", "c-doubleQuote.t", new LpexAction()   // "htmlQuot"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("insertText &quot;"); }
         public boolean available(LpexView view)
         { return true; }
      });

      // add bold text style to selection
      defineAction("htmlB", "c-b.t", new LpexAction()                // "htmlB"
      {
         public void doAction(LpexView view)
         { tagSelection("b"); }
         public boolean available(LpexView view)
         { return true; }
      });

      // add italic text style to selection
      defineAction("htmlI", "c-i.t", new LpexAction()                // "htmlI"
      {
         public void doAction(LpexView view)
         { tagSelection("i"); }
         public boolean available(LpexView view)
         { return true; }
      });

      // add start & end tags to selection
      defineAction("htmlTag", "c-t.t", new LpexAction()              // "htmlTag"
      {
         public void doAction(LpexView view)
         {
            view.doDefaultCommand("input \"" +
                                  LpexResources.message("commandLine.tag") +
                                  "\" \"htmlTag \"");
         }
         public boolean available(LpexView view)
         { return true; }
      });

      // command to add start & end tags to selection
      view.defineCommand("htmlTag", new LpexCommand()                // "htmlTag" command
      {
         public boolean doCommand(LpexView view, String parameters)
         {
            tagSelection(parameters);
            // if called here from a command-line prompt (e.g.,
            // the htmlTag action), clear this prompt
            view.doDefaultAction(ACTION_TEXT_WINDOW);
            return true;
         }
      });
   }

   /**
    * Define an action for this view, and optionally
    * assign it to an available key.
    *
    * @param actionName e.g., "htmlTag"
    * @param key        e.g., "c-b.t" for Ctrl+B in the text area
    */
   private void defineAction(String actionName, String key, LpexAction lpexAction)
   {
      view.defineAction(actionName, lpexAction);
      if (key != null && !view.keyAssigned(key))
         view.doCommand("set keyAction." + key + ' ' + actionName);
   }

   /**
    * Define parser's style attributes.
    *
    * @param colours true = token highlighting,
    *                false = no token highlighting
    */
   public void        setStyleAttributes(boolean colours)
   {
      String toBackground = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                        BACKGROUND_COLOR, toBackground);
      if (colours) {
         setStyle("_t=", attributes);         // Layout blanks, Text, =

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("kud", attributes);         // Tag name, Unrecognized tag name, Tag delimiter

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_LIBRARY,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("a",   attributes);         // Tag attribute name

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_STRING,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("v",   attributes);         // Tag attribute value

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("c",   attributes);         // Comment

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_ERROR,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("e",   attributes);         // Lexical error
         }
      else                                    // drop the nice colours
         setStyle("_t=kudavce", attributes);
   }

   /**
    * Set a class (tagClass) in all the elements of a document structure
    * (tagBegin .. tagEnd), and double-link them for future incremental parses.
    * Currently used for (multi-line) tags and <script> .. </script> structures.
    *
    * @param tagBegin start element belonging to the document structure
    * @param tagEnd   last element belonging to the structure
    * @param tagClass the class bit-mask to set:  classTag / classScript
    */
   private void       setTag(int tagBegin, int tagEnd, long tagClass)
   {
      // for a multi-line tag, double-link classes
      long classes = (tagBegin < tagEnd)? tagClass | classForwardLink : tagClass;
      int currentElement = stream.getEndLine();

      for (int i = tagBegin; i <= tagEnd; i++) {
         if (view.show(i))
            continue;
         if (i == tagEnd)
            classes &= ~classForwardLink;
         if (i == currentElement)
            stream.setClasses(classes);
         else
            view.setElementClasses(i, view.elementClasses(i) & ~classSpace | classes);
         classes |= classBackwardLink;
         }
   }

// /**
//  * Display an error message for an element.
//  */
// private void addErrorMessage(int element, String message)
// {
//    StringBuffer buffer = new StringBuffer(getLanguage());
//    buffer.append('.').append(message);
//    addMessage(element, LpexResources.message(buffer.toString()));
// }

   /**
    * Parse a range of elements.
    * Called by both totalParse() and parse().
    *
    * @param beginElement first element in range
    * @param endElement   last element in the range
    * @param clearPending true = clear parsePending once done with an element
    */
   private void       doParse(int beginElement, int endElement, boolean clearPending)
   {
      // clear existing lexical errors (if any) in the parse range
      // removeMessages(beginElement, endElement); // N/A right now...

      // initialize parse operation & get parsing
      stream.Init(beginElement, endElement,
                  classAll, classSpace, '_', clearPending);
      setLexer(LEXER_HTML);                 // the TokenManager defaults to HTML
      int elements = view.elements();

      while (true) {
         try {
            int rc = processToken();
            // on EOF, we may have to extend the parse range
            if ((rc & LEXER_RC_EOF) != 0) {
               if ((rc & LEXER_RC_MORE) != 0 ||
                   // comment continues
                   (view.elementClasses(endElement) & classForwardLink) != 0) {
                  int oldEndElement = endElement;
                  do {               // could re-evaluateEndElement() instead??!
                     endElement++;
                     } while ((endElement <= elements) && view.show(endElement));
                  if (endElement > elements)
                     break;
                  stream.Expand(endElement);
                  // clear old messages in the newly expanded parse range
                  //removeMessages(oldEndElement+1, endElement); // N/A right now
                  }
               else
                  break;
               }
            }
         catch (TokenMgrError e) {            // EOF in middle of token/bad char
            stream.setStyles(stream.getBeginColumn(),
                             stream.getEndColumn(), 'e');
            stream.setClasses(classError | classCode);
            // do we really want to say "syntax error" when browsers accept
            // virtually anything, and we're not really validating anything -
            // the 'e' style is more than enough for now... -as-
            //addErrorMessage(stream.getEndLine(), "syntaxError");
            if (stream.EOFSeen()) {                 // EOF (styles already set)?
               stream.setCurrentStyles();           //  do it again, complete
               break;                               //  & that's it, folks...
               }

            stream.skipChar();       // skip the error character (presumably...)
            reinitializeLexer();                          //  & continue past it
            }
         }

      // ensure all matters closed up nicely on EOF
      htmlLexer.handleEndOfFile();
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * up to the top of the file.
    * Extra lines may be included as follows:
    * - the previous non-show line is included if it has been modified or if it
    *   has a classForwardLink, or if the current line has a classBackwardLink,
    *   or if a line between the current and the previous was deleted;
    * - once an extra line is included, the one previous to it is also checked.
    *
    * @param elem main line that triggered the parse
    * @return suggested start line for parsing (may be a show line)
    */
   private int        evaluateBeginElement(int elem)
   {
      int  tryElem;          // an element preceding elem
      long classes,          // classes of current elem
           tryClasses;       //  & classes of element preceding it

      /* always include previous line: e.g., Enter at the end of a line in error
         will open a new element pushing that line's message one down, we clear
         this error (now in our parse range), so it's lost! */
      if (elem > 1)
         elem--;

      // get current line's class
      for (;  elem > 1 && view.show(elem);  elem--) {}
      classes = view.elementClasses(elem);

      // LOOP BACKWARDS (up to top of the file)...
      while (elem > 1) {
         for (tryElem=elem-1;  tryElem > 1 && view.show(tryElem);  tryElem--) {}
         tryClasses = view.elementClasses(tryElem);               // prev line's

         // Include prev line in parse range and go on searching if *any* of:
         //   (a) current line has a BWDLINK;
         //   (b) previous non-show line has a FWDLINK;
         //   (c) line(s) between previous and current line was/were deleted;
         //   (d) previous non-show line has been modified.
         if ((classes & classBackwardLink)   == 0  &&
             (tryClasses & classForwardLink) == 0
             /*&&(view.parsePending(elem) & LX_PENDING_DELETE)==0*/
             /*&&(view.parsePending(tryElem) & PARSE_PENDING_CHANGE_MASK)==0*/)
            break;

         classes = tryClasses;
         elem    = tryElem;
         }

      return elem;
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * to the bottom of the file.
    * Extra lines may be included as follows:
    * - the next line is included if it's been modified, or if it has a class
    *   classBackwardLink, or is just a SHOW line;
    *   or if the current line has a class of classForwardLink or has no SEMICOLON;
    * - once an extra line is included, the one after it is also checked.
    *
    * @param element main line that triggered the parse
    */
   private int        evaluateEndElement(int element)
   {
      int elements = view.elements();

      // LOOP FORWARDS (down to bottom of the file)...
      int endElem = element;
      for (; endElem < elements; endElem++) {
         long classes = view.elementClasses(endElem);

         // Include next line in parse range and go on searching if *any* of:
         //   (a) current line has a FWDLINK;
         //   (b) next line is just a SHOW line;
         //   (c) next line was modified;
         //   (d) next line has a classBackwardLink.
         // Also: current line has PARSE_PENDING_NEXT_DELETED_MASK ?!? *as*
         if (((classes & classForwardLink)   == 0)  &&
             (!view.show(endElem+1))             &&
             ((view.parsePending(endElem+1) & PARSE_PENDING_CHANGE_MASK) == 0)  &&
             ((view.elementClasses(endElem+1) & classBackwardLink) == 0)) {
            break;                               // break out of loop
            }
         }

      return endElem;
   }

   /**
    * Set/switch lexer.
    *
    * @return true = new lexer set as the active lexer;
    *                it is set in its DEFAULT lexical state.
    */
   private boolean    setLexer(int newLexer)
   {
      if (newLexer == LEXER_HTML)
         htmlLexer.initialize();
      else if (newLexer == LEXER_JAVASCRIPT) {
//       if (javaScriptLexer == null) {
//          javaScriptLexer = getJavaScriptLexer(stream);
//          if (javaScriptLexer == null)
               return false;
//          }
//       javaScriptLexer.initialize();
         }
      activeLexer = newLexer;
      return true;
   }

// /**
//  * Retrieve the JavaScriptLexer.
//  * @param stream input character stream for the SQL lexer
//  */
// public JavaScriptLexer getJavaScriptLexer (LpexCharStream stream)
// {
//    return new JavaScriptLexer(stream, getLanguage(), . . . );
// }

   /**
    * Reinitialize active lexer for the same input char stream.
    * For example, after an exception (such as EOF at end of the
    * initially-estimated parse range):  we skip the token in
    * error and continue parsing.
    */
   private void       reinitializeLexer()
   {
      if (activeLexer == LEXER_HTML)
         htmlLexer.reinitialize();
//    else // activeLexer == LEXER_JAVASCRIPT
//       javaScriptLexer.reinitialize();
   }

   /**
    * Process a token with the active lexer.
    *
    * @return LEXER_RC_OK, LEXER_RC_EOF [+LEXER_RC_MORE]
    * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_OK
    * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_EOF
    * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_MORE
    */
   private int        processToken()
   {
      int rc;
      if (activeLexer == LEXER_HTML)
         rc = htmlLexer.processToken();
      else { // activeLexer == LEXER_JAVASCRIPT
//       rc = javaScriptLexer.processToken();
//       if ((rc & LEXER_RC_END) != 0) {   // embedded Java Script section ended
//          endFunction = stream.getEndLine();
//          setFunction(classJavaScript);
//          setLexer(LEXER_HTML);
            rc = LEXER_RC_OK;
//          }
         }
      return rc;
   }

   /**
    * Return <code>true</code> if the specified character is a token delimiter.
    */
   public boolean     isTokenDelimiter(char ch)
   {
      return TOKEN_DELIMITERS.indexOf(ch) >= 0;
   }

   /**
    * Add <tag> and </tag> for the selected text / at the cursor.
    */
   private void       tagSelection(String tag)
   {
      LpexDocumentLocation s, e; // start, end tag-insert locations
      boolean block = view.queryOn("block.inView");
      view.doDefaultCommand("undo check"); // close off undo unit for any pending changes

      // keep any parameters for the start tag only
      int spaceIndex = tag.indexOf(' ');
      String endTag = (spaceIndex < 0)? tag : tag.substring(0, spaceIndex);

      /*-----------------------------------------------------------------*/
      /* (1) no block in the current view, insert the tags at the cursor */
      /*-----------------------------------------------------------------*/
      if (!block) {
         view.doDefaultCommand("insertText <" + tag + ">");

         e = view.documentLocation();
         int finalCursor = e.position;

         if (!view.queryOn("insertMode"))
            e.position++;
         view.doDefaultCommand(e, "insertText </" + endTag + ">");
         view.doDefaultCommand("set position " + finalCursor);
         return;
         }

      /*------------------------------------------*/
      /* (2) there is a block in the current view */
      /*------------------------------------------*/
      String blockType = view.query("block.type");
      s = new LpexDocumentLocation(view.queryInt("block.topElement"),
                                   view.queryInt("block.topPosition"));
      if (blockType.equals("element")) {
         String text = view.query("text", s);
         int i = 0;
         while (i < text.length() && // tag start of text on this line
                (text.charAt(i) == ' ' || text.charAt(i) == '\t'))
            i++;
         if (i == text.length())     // if whole line empty, tag its beginning
            i = 0;
         s.position = i + 1;
         }

      e = new LpexDocumentLocation(view.queryInt("block.bottomElement"),
                                   view.queryInt("block.bottomPosition"));
      if (blockType.equals("element"))
         e.position = view.queryInt("length", e) + 1;
      else if (!blockType.equals("stream"))
         e.position++;

      boolean tagsOnTheSameLine = s.element == e.element;

      // insert the tags
      view.doDefaultCommand(e, "insertText </" + endTag + ">");
      view.doDefaultCommand(s, "insertText <"  + tag    + ">");

      // set cursor on end tag [the block may have been out of the screen]
      view.doDefaultCommand("block clear"); // (-as- try to restore block?)
      if (tagsOnTheSameLine)
         e.position -= 1 + endTag.length() - tag.length(); // adjust e by the extra '/'
      else
         e.position -= 3 + endTag.length();                //  or by the entire end tag
      view.jump(e);
   }

   /**
    * Subclass LpexHtmlParserTokenManager (our token manager) for LPEX-specific
    * operations.
    */
   final class HtmlLexer extends LpexHtmlParserTokenManager
   {
      private long comments;     // comments state for FWDLINK & BWDLINK
      private int  beginTag,     // start element of a markup tag
                   beginScript;  // 1st element of a <script>..</script> section
      private int  lastToken;    // last token (t.kind) processed


      /**
       * Constructor.  Use LpexHtmlParserTokenManager's constructor, then
       * initialize any other specific information of ours.
       */
      HtmlLexer(LpexCharStream charstream)
      {
         super(charstream /*,DEFAULT*/);    // start up in DEFAULT lexical state
      }

      /**
       * Initialize the token manager for the same character input stream,
       * and in the default lexical state (DEFAULT).
       * This method is normally called when the parser sets / switches the
       * active lexer [back] to the HTML lexer.
       */
      void            initialize()
      {
         ReInit(stream);
         comments = 0;                   // not inside multi-line comments
         beginTag = 0;
         beginScript = 0;
         lastToken = EOF;                // ignore previous [Java Script] tokens
      }

      /**
       * Reinitialize the token manager for the same character input stream,
       * and in the default lexical state (DEFAULT).
       * This method is normally called after a TokenMgrError exception (e.g.,
       * encountered EOF in the middle of a token / a bad character), after the
       * token in error is skipped and we continue parsing.
       */
      void            reinitialize()
      {
         ReInit(stream);
      }

      /**
       * Like JavaCC's CommonTokenAction(), which is called just before
       * getNextToken() returns a matched token.
       * Comments are SPECIAL_TOKENs, and are being processed by setComment().
       * White space is SKIPped altogether.
       *
       * @param t matched token returned by HtmlLexer/LpexHtmlTokenManager
       * @return LEXER_RC_OK, LEXER_RC_EOF [+LEXER_RC_MORE]
       * @see #setComment
       */
      private int     processToken()
      {
         Token t = getNextToken();

         char style;
         long classes = classCode;
         int  currentToken = t.kind;

         switch (currentToken) {
            /*---------*/
            /*  token  */
            /*---------*/
            case STAGO:       // '<'
            case ETAGO:       // "</"
            case SDECL:       // "<!"
                 style = 'd';
                 beginTag = t.endLine;
                 break;

            case ETAGOO:      // attribute '<'
            case STAGOO:      // attribute "</"
                 style = 'd';
                 break;

            case TAGE:        // '>'
            case TAGC:
                 style = 'd';
                 setTag(beginTag, t.endLine, classTag);
                 beginTag = 0;
                 break;

            /*-------------*/
            /*  tag names  */
            /*-------------*/
            case A:           // tags
            case ABBR:
            case ACRONYM:
            case ADDRESS:
            case APPLET:
            case AREA:
            case B:
            case BASE:
            case BASEFONT:
            case BDO:
            case BIG:
            case BLOCKQUOTE:
            case BODY:
            case BR:
            case BUTTON:
            case CAPTION:
            case CENTER:
            case CITE:
            case CODE:
            case COL:
            case COLGROUP:
            case DD:
            case DEL:
            case DFN:
            case DIR:
            case DIV:
            case DL:
            case DT:
            case EM:
            case FIELDSET:
            case FONT:
            case FORM:
            case FRAME:
            case FRAMESET:
            case H1:
            case H2:
            case H3:
            case H4:
            case H5:
            case H6:
            case HEAD:
            case HR:
            case HTML:
            case I:
            case IFRAME:
            case IMG:
            case INPUT:
            case INS:
            case ISINDEX:
            case KBD:
            case LABEL:
            case LEGEND:
            case LI:
            case LINK:
            case MAP:
            case MENU:
            case META:
            case NOFRAMES:
            case NOSCRIPT:
            case OBJECT:
            case OL:
            case OPTGROUP:
            case OPTION:
            case P:
            case PARAM:
            case PRE:
            case Q:
            case S:
            case SAMP:
            case SELECT:
            case SMALL:
            case SPAN:
            case STRIKE:
            case STRONG:
            case STYLE:
            case SUB:
            case SUP:
            case TABLE:
            case TBODY:
            case TD:
            case TEXTAREA:
            case TFOOT:
            case TH:
            case THEAD:
            case TITLE:
            case TR:
            case TT:
            case U:
            case UL:
            case VAR:
                 style = 'k';
                 break;

            case SCRIPT:
                 style = 'k';
                 if (lastToken == ETAGO) { // "</SCRIPT>"
                    if (beginScript != 0) {
                       setTag(beginScript, t.endLine, classScript);
                       beginScript = 0;
                       }
                    else
                       classes |= classScript; // to rather set error?! -as-
                    }
                 else {                    // "<SCRIPT>"
                    if (beginScript == 0) {
                       beginScript = t.endLine;
                       }
                    // nested <script> tags!? -as-
                    }
                 break;

            case ATTLIST:     // declarations
            case DOCTYPE:
            case ELEMENT:
            case ENTITY:
                 style = 'k';
                 break;

            case UNKNOWN:     // unrecognized tag
                 style = 'u';
                 break;

            case A_NAME:      // attribute name
            case DECLSTUFF:   // any declaration (tag too...) junk...
                 style = 'a';
                 break;
            case HREF:        // - href
                 classes |= classHref;
                 style = 'a';
                 break;

            case A_EQ:        // '='
                 style = '=';
                 break;

            case CDATA:       // attribute value
            case CONT_QUOTE:  // accumulated quoted stuff inside <!declarations...
            case SQUOTEE:
            case DQUOTEE:
                 style = 'v';
                 break;

            case TEXT:
                 style = 't'; // text
                 break;

            /*-------------------------------------------------*/
            /*  end of current parse range / real end of file  */
            /*-------------------------------------------------*/
            case EOF:
                 if (beginTag != 0 || beginScript != 0)
                    // other cases: doParse() goes on when classForwardLink
                    return LEXER_RC_EOF | LEXER_RC_MORE; // try to go on parsing
                 return LEXER_RC_EOF;

            /*----------------------*/
            /*  everything else...  */
            /*----------------------*/
            default:
                 lastToken = currentToken;
                 return LEXER_RC_OK;
            }

         lastToken = currentToken;
         stream.setStyles(t.beginColumn, t.endColumn, style);
         stream.setClasses(classes);
         return LEXER_RC_OK;
      }

      /**
       * Set the style and class for comments.  Activated by \n, \r, or -->
       * encountered while in a comment SPECIAL_TOKEN, or similar in a
       * tag-attribute comment.  SPECIAL_TOKEN, rather than TOKEN, is used
       * for these, as we don't need to see the same tokens in processToken()
       * too, nor have them recorded in the parse.
       *
       * Does the real work for the extended dummy in LpexHtmlParser.jj.
       *
       * @param t special token
       */
      protected void  setComment(Token t)
      {
         long classes = (getCurLexState() == ATTCOMM)?
                                             classTagComment : classComment;

         if (t.kind == CONT_COMMENT || t.kind == CONT_ATTCOMM)
            classes |= classForwardLink;         // comment to be continued
         if ((comments & classForwardLink) != 0) // continuing comment:
            classes |= classBackwardLink;        //  double-link it
         comments = classes;

         if (t.endColumn >= t.beginColumn)
            stream.setStyles(t.beginColumn, t.endColumn, 'c');
         stream.setClasses(classes);
      }

      /**
       * The parse terminated on an actual EOF.  If EOFed in middle of an
       * unended <tag>, set links for the benefit of the next incremental parse.
       */
      void            handleEndOfFile()
      {
         if (beginTag != 0) {
            setTag(beginTag, stream.getEndLine(), classTag);
            stream.setCurrentStyles(); // EOFed, ensure here it's set in element
            }
         if (beginScript != 0) {
            setTag(beginScript, stream.getEndLine(), classScript);
            stream.setCurrentStyles(); // EOFed, ensure here it's set in element
            }
      }
   }
}