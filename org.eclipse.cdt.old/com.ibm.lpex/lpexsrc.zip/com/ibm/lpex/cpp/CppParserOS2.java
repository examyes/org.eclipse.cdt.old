//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CppParserOS2 - document parser for OS/2-flavoured C/C++.
//----------------------------------------------------------------------------

package com.ibm.lpex.cpp;

import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.cc.Token;


/**
 * Document parser for OS/2-flavoured C/C++.
 */
public class CppParserOS2 extends CppParser
{
   public CppParserOS2(LpexView lpexView)
   {
      super(lpexView);
   }

   /**
    * Query whether the token passed is an extension keyword.
    */
   public boolean isExtensionKeyword(Token token)
   {
      // CppTokens has two extension-keyword tables for OS/2:  one for language
      // and system extension keywords, and one for typedefs and #defines in the
      // development toolkit.
      return CppTokens.isToken(view, token, CppTokens.OS2.extKeyword1,
                                            CppTokens.OS2.extKeyword2);
   }

   /**
    * Query whether the token passed is a C library function.
    */
   public boolean isCLibraryFunction(Token token)
   {
      // CppTokens has two C-library-function tables for OS/2:  one for
      // ANSI/SAA C library functions, and one for non-ANSI/SAA lib functions.
      return CppTokens.isToken(view, token, CppTokens.OS2.libFunction1,
                                            CppTokens.OS2.libFunction2);
   }
}