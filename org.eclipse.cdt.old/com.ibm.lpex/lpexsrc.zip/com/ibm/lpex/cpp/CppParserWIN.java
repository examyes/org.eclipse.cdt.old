//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CppParserWIN - document parser for MS Windows-flavoured C/C++.
//----------------------------------------------------------------------------

package com.ibm.lpex.cpp;

import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.cc.Token;


/**
 * Document parser for MS Windows-flavoured C/C++.
 */
public class CppParserWIN extends CppParser
{
   public CppParserWIN(LpexView lpexView)
   {
      super(lpexView);
   }

   /**
    * Query whether the token passed is an extension keyword.
    */
   public boolean isExtensionKeyword(Token token)
   {
      // CppTokens has two extension-keyword tables for Windows:  one for
      // language and system extension keywords, and one for typedefs and
      // #defines in the SDK.
      return CppTokens.isToken(view, token, CppTokens.WINDOWS.extKeyword1,
                                            CppTokens.WINDOWS.extKeyword2);
   }

   /**
    * Query whether the token passed is a C library function.
    */
   public boolean isCLibraryFunction(Token token)
   {
      // CppTokens has two C-library-function tables applicable to Windows:  one
      // the ANSI/SAA C lib functions, and one for non-ANSI/SAA lib functions.
      // In IBM VisualAge for C++, they are identical to OS/2's.
      return CppTokens.isToken(view, token, CppTokens.OS2.libFunction1,
                                            CppTokens.OS2.libFunction2);
   }
}