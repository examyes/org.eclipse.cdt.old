//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CppParser & CppLexer - base C/C++ document parser.
//----------------------------------------------------------------------------

package com.ibm.lpex.cpp;

import java.util.Properties;
import java.util.ResourceBundle;

import com.ibm.lpex.core.HelpCommand;
import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCharStream;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexDocumentLocation;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import com.ibm.lpex.cc.LpexCppParserTokenManager;
import com.ibm.lpex.cc.Token;
import com.ibm.lpex.cc.TokenMgrError;

import com.ibm.lpex.sql.SqlLexer;
import com.ibm.lpex.cics.CicsLexer;


/**
 * Document parser for C/C++.
 * This class is extended by various C/C++ document parsers for specific
 * systems/platforms and embedded SQL/CICS support.
 *
 * <p>Actions and assigned keys added by this document parser:
 * <ul>
 *   <li><b>functions</b> (Ctrl+G) for a selective view of the functions
 *       in the document
 *   <li><b>outline</b> for a logical-outline view of the document
 *   <li><b>errors</b> for a selective view of the errors in the document.
 * </ul>
 * Keys already defined (e.g., by the active base profile) to an action
 * different from <b>nullAction</b> are not redefined in here.
 *
 * <p>Template expansion (Ctrl+R) for the following keywords is available
 * in this parser's Profile.properties:
 * case, do, doc, for, if, main, switch, try, while.
 *
 * @see com.ibm.lpex.cpp.CppParserOS2
 * @see com.ibm.lpex.cpp.CppParserWIN
 * @see com.ibm.lpex.cpp.CppParserAIX
 * @see com.ibm.lpex.cpp.CppSqlParser
 * @see com.ibm.lpex.cpp.CppSqlParserOS2
 * @see com.ibm.lpex.cpp.CppSqlParserWIN
 * @see com.ibm.lpex.cpp.CppSqlParserAIX
 */
public class CppParser extends LpexCommonParser
{
   // whether the help index was loaded, and the help index .properties file
   private static boolean properties_loaded;
   private static Properties helpPages;

   // the input stream the view feeds
   private LpexCharStream stream;

   private static ResourceBundle resource =
      ResourceBundle.getBundle("com.ibm.lpex.cpp.Profile");

   // the element classes we use...
   static final String
      CLASS_CODE      = "code",
      CLASS_SPACE     = "space",
      CLASS_FWDLINK   = "forwardLink",
      CLASS_BWDLINK   = "backwardLink",
      CLASS_SEMICOLON = "semicolon",
      CLASS_FUNCTION  = "function",
      CLASS_BRACE     = "brace",
      CLASS_ERROR     = "error",
      CLASS_COMMENT   = "comment",
      CLASS_INCLUDE   = "include",
      CLASS_CONTROL   = "control",
      CLASS_CLASS     = "class",
      CLASS_SQL       = "sql",
      CLASS_CICS      = "cics";

   // ...and their assigned bitmasks
   long
      classCode,
      classSpace,
      classForwardLink,
      classBackwardLink,
      classSemicolon,
      classFunction,
      classBrace,
      classError,
      classComment,
      classInclude,
      classControl,
      classClass,
      classSql,
      classCics,
      classAll;

   /*
    * Notes on our (rather imperfect) searching for FUNCTIONs
    * -------------------------------------------------------
    * We're looking for non-prototype function declarators;
    * variable function keeps track of the search status:
    *
    *  X      X::operator =          ( X& x                 )         {
    *  public static char[] function ( char bla, int[] blah ) const   {
    * |      |                        |                      |        |
    * NONE   ID     ...    ...        PARMS                  TOBRACE  done
    *
    * Examples
    * --------
    * void a() {
    * char **fun1(const int a, char *b[], t_size s, ...) {
    *
    * int atexit(void(*)(void)) {               // parentheses in function=PARMS
    * void asort(void*, int (* _Optlink __compare)(const void*, const void*)) {
    *
    * // parenthesised function id:
    * char (*(*x())[])() { // K&R x=function that returns ptr to array[] of ptr
    *                      //     to function returning character
    * void (*set_unexpected(void(*)()))() {
    * unsigned int (_Optlink _control87)(int, unsigned int) {
    *
    * Examples we don't / cannot handle (for the *real* functions below!)   *as*
    * -------------------------------------------------------------------
    * // the old LPEX parser accepts this non-ANSI stuff:
    * int oldstyle(a, c_c) int a; char **c_c; {
    *   - for old-style declares, any 'keyword' (word starting with letter or _)
    *     in function=TOBRACE will set function, without ensuring the keyword is
    *     not a non-type specifier like, e.g., "do", and without any further
    *     search for the eventual '{'  (seek { / should NOT do if any 'keyword'
    *     found in function=PARMS !?!? *as*)
    * // no identifier and/or parentheses in function=FUNCTION_ID:
    * myOwnType (*(*x())[])() {
    * unsigned int (_Optlink _control87)(a) int a; {
    */

   private static final int
      FUNCTION_NONE     = 0x00000000,
      FUNCTION_ID       = 0x00000001,   // found a function type/"name"
      FUNCTION_PARENSID = 0x00000002,   // doing a "(*(*name())[])"
      FUNCTION_PARMS    = 0x00000004,   // getting formal parameters
      FUNCTION_TOBRACE  = 0x00000008,   // after ')', expecting the '{'

      FUNCTION_EXEC     = 0x00000010,   // after "EXEC"
      FUNCTION_SQL      = 0x00000011,   // after "EXEC SQL"
      FUNCTION_CICS     = 0x00000012;   // after "EXEC CICS"

   private int
      function,                         // current function-detection state
      beginFunction,                    // first element of (potential) function
      endFunction;                      //  & the last one

   // lexers we (may) use
   private static final int
      LEXER_CPP  = 0,
      LEXER_SQL  = 1,
      LEXER_CICS = 2;

   private CppLexer  cppLexer;
   private SqlLexer  sqlLexer;
   private CicsLexer cicsLexer;
   private int       activeLexer = LEXER_CPP;

   // token delimiters for isTokenDelimiter()
   private static final String TOKEN_DELIMITERS = "()[]{};,";


   /**
    * Constructor for the parser.
    * Add all of the parser specifics to the LPEX document view.
    * Initializes the view for the parser:  it sets up the style
    * attributes, classes, etc. for the language-sensitive edit features
    * supported.
    *
    * @param lpexView the LPEX document view associated with this parser
    */
   public CppParser(LpexView lpexView)
   {
      super(lpexView);        // LpexCommonParser constructor (view := lpexView)
      initializeParser();     // initialize LpexView with our stuff

      // instantiate an input stream for this view, and the main (C/C++) lexer
      stream   = new LpexCharStream(view);
      cppLexer = new CppLexer(stream);
   }

   /**
    * Total parse of the entire document.
    * Done initially, after a document has been loaded in the editor, and
    * after an <b>updateProfile</b> command.
    */
   public void           parseAll()
   {
      if (view.elements() == 0)                   // a bit of preventive care...
         return;

      // initialize parse operation & get parsing
      stream.Init(1, view.elements(), classAll, classSpace, '_', false);
      setLexer(LEXER_CPP);                 // the TokenManager defaults to C/C++

      while (true) {
         try {
            int rc = processToken();
            if ((rc & LEXER_RC_EOF) != 0)
               break;
            }
         catch (TokenMgrError e) {            // EOF in middle of token/bad char
            stream.setStyles(stream.getBeginColumn(),
                             stream.getEndColumn(), 'e');
            stream.setClasses(classError | classCode);
            addErrorMessage(stream.getEndLine(), "syntaxError");
            if (stream.EOFSeen()) {                 // EOF (styles already set)?
               stream.setCurrentStyles();           //  do it again, complete
               break;                               //  & that's it, folks...
               }

            stream.skipChar();       // skip the error character (presumably...)
            reinitializeLexer();     //  & continue past it
            }
         }
   }

   /**
    * Incremental parse.
    *
    * @param element the (first) element whose committed change triggered the
    *                parse, or the element that precedes/follows a deleted
    *                block.  The parser may identify other neighbouring
    *                elements that will have to be reparsed as a unit
    */
   public void           parseElement(int element)
   {
      // *can* cache: removeMessages() will really delete elements *after* parse
      int elements = view.elements();

      // a bit of preventive care...
      if (elements == 0)
         return;

      // evaluate optimal range to parse
      int beginElement = evaluateBeginElement(element);
      int endElement   = evaluateEndElement(element);

      // clear any previously-marked lexical errors in the parse range
      removeMessages(beginElement, endElement);

      // initialize parse operation & get parsing
      stream.Init(beginElement, endElement, classAll, classSpace, '_',
                  true);         // clear parsePending once done with an element
      setLexer(LEXER_CPP);                 // the TokenManager defaults to C/C++

      while (true) {
         try {
            int rc = processToken();
            // on EOF, we may have to extend the parse range
            if ((rc & LEXER_RC_EOF) != 0) {
               if ((rc & LEXER_RC_MORE) != 0 ||
                   // "/*" or "//..<ESCAPE>" comment / string<ESCAPE> continues:
                   (view.elementClasses(endElement) & classForwardLink) != 0) {
                  int oldEndElement = endElement;
                  do {
                     endElement++;
                     } while ((endElement <= elements) && view.show(endElement));
                  if (endElement > elements)
                     break;
                  stream.Expand(endElement);
                  // clear old messages in the newly expanded parse range
                  removeMessages(oldEndElement+1, endElement);
                  }
               else
                  break;
               }
            }
         catch (TokenMgrError e) {            // EOF in middle of token/bad char
            stream.setStyles(stream.getBeginColumn(),
                             stream.getEndColumn(), 'e');
            stream.setClasses(classError | classCode);
            addErrorMessage(stream.getEndLine(), "syntaxError");
            if (stream.EOFSeen()) {                 // EOF (styles already set)?
               stream.setCurrentStyles();           //  do it again, complete
               break;                               //  & that's it, folks...
               }

            stream.skipChar();       // skip the error character (presumably...)
            reinitializeLexer();     //  & continue past it
            }
         }//end "while true"
   }

   /**
    * Return the parser's properties profile resource bundle.
    */
   public ResourceBundle getProfile()
   {
      return resource;
   }

   /**
    * Returns <code>"CPP"</code>, the language supported by this parser (C/C++).
    *
    * @see com.ibm.lpex.core.LpexCommonParser#LANGUAGE_CCPP
    */
   public String         getLanguage()
   {
      return LANGUAGE_CCPP;
   }

   /**
    * Retrieve a string identifying the language segment at the specified
    * location.  In mixed-content documents, this may differ from the main
    * language of the document.
    *
    * The method assumes that no parse is pending for this location's element.
    *
    * @return one of: LpexCommonParser.LANGUAGE_CCPP,
    *                 LpexCommonParser.LANGUAGE_CICS,
    *                 LpexCommonParser.LANGUAGE_SQL
    */
   public String         getLanguage(LpexDocumentLocation loc)
   {
      long classes = view.elementClasses(loc.element);
      if ((classes & classSql) != 0)
         return LANGUAGE_SQL;
      if ((classes & classCics) != 0)
         return LANGUAGE_CICS;
      return getLanguage();
   }

   /**
    * Initialize the parser for an LPEX document view:  set up style attributes
    * for the styles we need, classes, etc., and initialize the view for the
    * language-sensitive edit features supported.
    */
   private void          initializeParser()
   {
      // set attributes for the styles we use
      String tokenHighlight = getProperty("tokenHighlight");
      setStyleAttributes(tokenHighlight == null || !tokenHighlight.equals("off"));

      // register classes & get their allocated bit-masks
      classCode         = view.registerClass(CLASS_CODE);
      classSpace        = view.registerClass(CLASS_SPACE);
      classForwardLink  = view.registerClass(CLASS_FWDLINK);
      classBackwardLink = view.registerClass(CLASS_BWDLINK);
      classSemicolon    = view.registerClass(CLASS_SEMICOLON);
      classFunction     = view.registerClass(CLASS_FUNCTION);
      classBrace        = view.registerClass(CLASS_BRACE);
      classError        = view.registerClass(CLASS_ERROR);
      classComment      = view.registerClass(CLASS_COMMENT);
      classInclude      = view.registerClass(CLASS_INCLUDE);
      classControl      = view.registerClass(CLASS_CONTROL);
      classClass        = view.registerClass(CLASS_CLASS);
      classSql          = view.registerClass(CLASS_SQL);
      classCics         = view.registerClass(CLASS_CICS);
      classAll = classCode | classSpace | classForwardLink |
                 classBackwardLink | classSemicolon | classFunction |
                 classBrace | classError | classComment | classInclude |
                 classControl | classClass | classSql | classCics;

      /*-----------------------*/
      /*  define LPEX actions  */
      /*-----------------------*/
      // view filter action "functions"
      LpexAction lpexAction = new LpexAction() {                // "functions"
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_FUNCTION);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView lpexView)
         { return true; }
         };
      view.defineAction("functions", lpexAction);
      view.doDefaultCommand("set keyAction.c-g.t.p.c functions");

      // view filter action "outline"
      lpexAction = new LpexAction() {                           // "outline"
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " +
                                  CLASS_FUNCTION + " " +
                                  CLASS_BRACE + " " +
                                  CLASS_CONTROL);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView lpexView)
         { return true; }
         };
      view.defineAction("outline", lpexAction);

      // view filter action "errors"
      lpexAction = new LpexAction() {                           // "errors"
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_ERROR);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView lpexView)
         { // could check if any errors in doc...
           return true; }
         };
      view.defineAction("errors", lpexAction);
   }

   /**
    * Return this parser's items for the popup Filter view submenu:
    * functions, outline, errors.
    */
   public String    getPopupViewItems()
   {
      StringBuffer buffer = new StringBuffer();
      buffer.append(getLanguage());
      buffer.append(".popup.functions functions ");
      buffer.append(getLanguage());
      buffer.append(".popup.outline outline ");
      buffer.append(MSG_POPUP_ERRORS);
      buffer.append(" errors");
      return buffer.toString();
   }

   /**
    * Define parser's style attributes.
    *
    * @param colours <code>true</code> = token highlighting, or
    *                <code>false</code> = no token highlighting
    */
   public void      setStyleAttributes(boolean colours)
   {
      String toBackground = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                        BACKGROUND_COLOR, toBackground);
      if (colours) {
         setStyle("_ioptb", attributes);         // Layout blanks, Identifier,
                                                 //   Operator, Punctuator,
                                                 //   Continuation char, Brace

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("c",  attributes);             // Comment

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_ERROR,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("e",  attributes);             // Lexical error

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("k", attributes);              // Keyword

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD1,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("x", attributes);              // Extension keyword

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_LIBRARY,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("f",  attributes);             // C library function

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_NUMERAL,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("n",  attributes);             // Constant

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_STRING,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("q",  attributes);             // String literal

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DIRECTIVE,
                                                    BACKGROUND_COLOR, toBackground);
         setStyle("h",  attributes);             // CPP directive
         }
      else                                       // drop the nice colours
         setStyle("_ioptbcekxfnqh", attributes);
   }

   /**
    * Returns true if the specified character is a token delimiter.
    */
   public boolean   isTokenDelimiter(char ch)
   {
      return TOKEN_DELIMITERS.indexOf(ch) >= 0;
   }

   /**
    * Set an element class for all the elements that belong to a parse unit,
    * and double-link them if necessary (note that strictly for purposes of
    * incremental parsing, double-linking is not really always necessary,
    * as evaluateXxxxxElement()s usually go back & forth up to lines with
    * a SEMICOLON...).
    * Sets a function class in all the elements of a function declaration
    * (beginFunction .. endFunction);  marks imbedded SQL and CICS.
    *
    * @param functionClass the class bit-mask to set:  classFunction /
    *                      classSql / classCics
    */
   private void     setFunction(long functionClass)
   {
      // for a multi-line function declaration, double-link classes
      long classes = (beginFunction < endFunction)?
                         functionClass | classForwardLink :
                         functionClass;
      int currentElement = stream.getEndLine();
      for (int i = beginFunction; i <= endFunction; i++) {
         if (view.show(i))
            continue;
         if (i == endFunction)
            classes &= ~classForwardLink;
         if (i == currentElement)
            stream.setClasses(classes);
         else
            view.setElementClasses(i, view.elementClasses(i) & ~classSpace | classes);
         classes |= classBackwardLink;
         }
   }

   /**
    * Display an error message for an element.
    */
   private void     addErrorMessage(int element, String message)
   {
      StringBuffer buffer = new StringBuffer(getLanguage());
      buffer.append('.');
      buffer.append(message);
      addMessage(element, LpexResources.message(buffer.toString()));
   }

   /**
    * Returns true if the token passed is an extension keyword.
    * CppParser has no particular system/platform flavour, so it will
    * always return false.
    *
    * <p>A document parser extending class CppParser must override this method
    * to check for extension keywords for the system / platform it applies to.
    * Other extensions (such as for a particular project / compiler) may also be
    * supported in this manner.
    */
   public boolean   isExtensionKeyword(Token token)
   {
      // CppTokens has two extension-keyword tables for each of OS/2, Windows,
      // AIX, and 390 (where applicable):  one for language & system extension
      // keywords, and one for typedefs and #defines in the development toolkit.
      return false;
   }

   /**
    * Returns true if the token passed is a C library function.
    * A document parser extending CppParser must override this method to check
    * for C library & extension C library functions available on the system /
    * platform it applies to.
    */
   public boolean   isCLibraryFunction(Token token)
   {
      // CppTokens has two C-library-function tables for each of OS/2, Windows,
      // AIX, and 390 (where applicable):  one for ANSI/SAA C library functions,
      // and one for non-ANSI/SAA library functions.  Use the former for this
      // default (unflavoured) parser.
      return CppTokens.isToken(view, token, CppTokens.OS2.libFunction1);
   }

   private static void loadProperties()
   {
      if (!properties_loaded) {
         helpPages = HelpCommand.loadHelpMap(HELP_CCPP);
         // whether the load succeeded or not, there's no point
         // in trying again until LPEX is restarted
         properties_loaded = true;
         }
   }

   /**
    * Retrieve the name of the html help page that the parser identifies
    * as appropriate for the currently selected token.
    */
   public String    getHelpPage()
   {
      String helpPage = null;
      loadProperties();
      if (helpPages != null) {
         String token = getToken(view.documentLocation());
         if (token != null) {
            // modify token to match syntax used in .properties file -
            // e.g., "operator +" becomes "help.operator$+"
            token = token.trim();
            token = token.replace(' ','$');
            token = token.replace('=','@');
            token = token.replace(':','?');
            token = "help." + token;

            // other things we should/could add:  if token style shows
            // numeric, do help for constant, and same for string/char
            // literals / comment / etc.;  if class is sql/cics, do
            // help for sql/cics; etc. etc.                       *as*

            helpPage = helpPages.getProperty(token);
            }
         }
      return helpPage;
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * up to the top of the file.
    * Extra lines may be included as follows:
    * - the previous non-show line is included if it has been modified or if it
    *   has a classForwardLink, or if the current line has a classBackwardLink
    *   or doesn't have classSemicolon (note:  this is needed for FUNCTION, i.e.,
    *   function processing), or if a line between the current and the previous
    *   was deleted;
    * - once an extra line is included, the one previous to it is also checked.
    *
    * @param elem main line that triggered the parse
    * @return suggested start line for parsing (may be a show line)
    */
   private int      evaluateBeginElement(int elem)
   {
      int  tryElem;          // an element preceding elem
      long classes,          // classes of current elem
           tryClasses;       //  & classes of element preceding it

      // get current line's class;  do not let a SEMICOLON (which can
      // be just *anywhere*) in the starting line fool you: go deeper!
      for (;  elem > 1 && view.show(elem);  elem--) {}
      classes = view.elementClasses(elem) & ~classSemicolon;

      // LOOP BACKWARDS (up to top of the file)...
      while (elem > 1) {
         for (tryElem=elem-1;  tryElem > 1 && view.show(tryElem);  tryElem--) {}
         tryClasses = view.elementClasses(tryElem); // previous line's

         // Include prev line in parse range and go on searching if *any* of:
         //   (a) current line has a BWDLINK;
         //   (b) current line doesn't have a SEMICOLON;
         //   (c) previous non-show line has a FWDLINK;
         //   (d) line(s) between previous and current line was/were deleted;
         //   (e) previous non-show line has been modified.
         if ((classes & classBackwardLink)   == 0 &&
             (classes & classSemicolon)      != 0 &&
             (tryClasses & classForwardLink) == 0
             /*&&(view.parsePending(elem) & LX_PENDING_DELETE)==0*/
             /*&&(view.parsePending(tryElem) & PARSE_PENDING_CHANGE_MASK)==0*/)
            break;

         classes = tryClasses;
         elem    = tryElem;
         }

      return elem;
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * to the bottom of the file.
    * Extra lines may be included as follows:
    * - the next line is included if it's been modified, or if it has a class
    *   classBackwardLink, or is just a SHOW line;
    *   or if the current line has a class of classForwardLink or has no SEMICOLON;
    * - once an extra line is included, the one after it is also checked.
    *
    * @param element main line that triggered the parse
    */
   private int      evaluateEndElement(int element)
   {
      int elements = view.elements();

      // LOOP FORWARDS (down to bottom of the file)...
      int endElem = element;
      for (; endElem < elements; endElem++) {
         long classes = view.elementClasses(endElem);

         // Include next line in parse range and go on searching if *any* of:
         //   (a) current line has a FWDLINK;
         //   (b) current line has no SEMICOLON;  (not 100% safe, as a linestart
         //       <;><statements...> will fool us into not reparsing... *as*)
         //   (c) next line is just a SHOW line;
         //   (d) next line was modified;
         //   (e) next line has a classBackwardLink.
         // Also: current line has PARSE_PENDING_NEXT_DELETED_MASK?!? *as*
         if (((classes & classForwardLink) == 0)  &&
             ((classes & classSemicolon)   != 0)  &&
             (!view.show(endElem+1))              &&
             ((view.parsePending(endElem+1) & PARSE_PENDING_CHANGE_MASK) == 0) &&
             ((view.elementClasses(endElem+1) & classBackwardLink) == 0)) {
            break; // break out of the loop
            }
         }

      return endElem;
   }

   /**
    * Set/switch lexer.
    *
    * @return true = new lexer set as the active lexer;
    *                it is set in its DEFAULT lexical state
    */
   private boolean  setLexer(int newLexer)
   {
      if (newLexer == LEXER_CPP)
         cppLexer.initialize();
      else if (newLexer == LEXER_SQL) {
         if (sqlLexer == null) {
            sqlLexer = getSqlLexer(stream);
            if (sqlLexer == null)
               return false;
            }
         sqlLexer.initialize();
         }
      else {// newLexer == LEXER_CICS
         if (cicsLexer == null) {
            cicsLexer = getCicsLexer(stream);
            if (cicsLexer == null)
               return false;
            }
         cicsLexer.initialize();
         }

      activeLexer = newLexer;
      return true;
   }

   /**
    * Retrieve the SqlLexer.
    * The document parser extending CppParser to support embedded SQL statements
    * must override this method to construct and return an SqlLexer object.
    * The implementation of this method provided by the CppParser class does
    * nothing, except return null.
    *
    * @param stream input character stream for the SQL lexer
    */
   public SqlLexer  getSqlLexer(LpexCharStream stream)
   {
      return null;
   }

   /**
    * Retrieve the CicsLexer.
    * The document parser extending CppParser to support embedded CICS statements
    * must override this method to construct and return a CicsLexer object.
    * The implementation of this method provided by the CppParser class does
    * nothing, except return null.
    *
    * @param stream input character stream for the CICS lexer
    */
   public CicsLexer getCicsLexer(LpexCharStream stream)
   {
      return null;
   }

   /**
    * Reinitialize the active lexer for the same input char stream.
    * For example, after an exception (such as EOF at end of the
    * initially-estimated parse range):  we skip the token in
    * error and continue parsing.
    */
   private void     reinitializeLexer()
   {
      if (activeLexer == LEXER_CPP)
         cppLexer.reinitialize();
      else if (activeLexer == LEXER_SQL)
         sqlLexer.reinitialize();
      else // activeLexer == LEXER_CICS
         cicsLexer.reinitialize();
   }

   /**
    * Process a token with the active lexer.
    * @return LEXER_RC_OK, LEXER_RC_EOF [+LEXER_RC_MORE]
    *
    * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_OK
    * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_EOF
    * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_MORE
    */
   private int      processToken()
   {
      int rc;
      if (activeLexer == LEXER_CPP)
         rc = cppLexer.processToken();
      else if (activeLexer == LEXER_SQL) {
         rc = sqlLexer.processToken();
         if ((rc & LEXER_RC_END) != 0) {        // embedded-SQL statement ended
            endFunction = stream.getEndLine();
            setFunction(classSql);
            setLexer(LEXER_CPP);
            rc = LEXER_RC_OK;
            }
         }
      else { // activeLexer == LEXER_CICS
         rc = cicsLexer.processToken();
         if ((rc & LEXER_RC_END) != 0) {        // embedded-CICS statement ended
            endFunction = stream.getEndLine();
            setFunction(classCics);
            setLexer(LEXER_CPP);
            rc = LEXER_RC_OK;
            }
         }
      return rc;
   }


   /**
    * Subclass LpexCppParserTokenManager for LPEX-specific operations.
    * LpexCppParserTokenManager.java, our token manager for the grammar, is
    * generated by:
    *   x:\JavaCC\bin\javacc cc\LpexCppParser.jj
    * We only use JavaCC's token manager, attempting our own parsing -
    * otherwise it's quite difficult to handle LPEX's incremental parsing...
    */
   final class CppLexer extends LpexCppParserTokenManager
                        implements LpexConstants
   {
      // various parsing states kept
      private int     lastToken;        // last token (t.kind) processed
      private long    comments;         // comments state for FWDLINK & BWDLINK
      private int     parensCount;      // nested ()s in function searches
      private boolean conditional;      // part of "a ? x : y"?
      private int     directive;        // #xxxx directive line?

      private final int
         DIRECTIVE_NONE    = 0,         // not a directive line
         DIRECTIVE_LINE    = 1,         // #if, #define, etc.
         DIRECTIVE_INCLUDE = 2;         // #include


      /**
       * Constructor.  Use LpexCppParserTokenManager's constructor, then
       * initialize any other specific information of ours.
       */
      CppLexer(LpexCharStream charstream)
      {
         super(charstream /*,DEFAULT*/);    // start up in DEFAULT lexical state
      }

      /**
       * Initialize the token manager for the same character input stream,
       * and in the default lexical state (DEFAULT).
       * This method is normally called when the parser sets / switches the
       * active lexer [back] to the Cpp lexer.
       */
      void           initialize()
      {
         ReInit(stream);
         lastToken = EOF;               // ignore previous [SQL/CICS] tokens
         function = FUNCTION_NONE;      // no function determination in progress
         comments = 0;                  // not inside multi-line comments
         parensCount = 0;
         conditional = false;
         directive = DIRECTIVE_NONE;
      }

      /**
       * Reinitialize the token manager for the same character input stream,
       * and in the default lexical state (DEFAULT).
       * This method is normally called after a TokenMgrError exception (e.g.,
       * encountered EOF in the middle of a token / a bad character), after the
       * token in error is skipped and we continue parsing.
       */
      void           reinitialize()
      {
         ReInit(stream);
      }

      /**
       * Like JavaCC's CommonTokenAction() which is called just before
       * getNextToken() returns a matched token.
       * Comments are SPECIAL_TOKENs, and are being processed by setComment().
       * White space is SKIPped altogether.
       *
       * NOTES:
       *  - if we'd parse better #include "<" .. ">" | "\"" .. "\"", we could get
       *    rid of a few ugly "if (directive == ..)"s in here...               *as*
       *
       * @param t matched token returned by CppLexer/LpexCppTokenManager
       * @return LEXER_RC_OK, LEXER_RC_EOF [+LEXER_RC_MORE]
       *
       * @see #setComment
       * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_OK
       * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_EOF
       * @see com.ibm.lpex.core.LpexCommonParser.LEXER_RC_MORE
       */
      private int    processToken()
      {
         /*=====================*/
         /*  A.- EXEC SQL/CICS  */
         /*=====================*/
         if ((function & FUNCTION_EXEC) != 0)
            return processEXECToken();

         // if (directive != DIRECTIVE_NONE)
         //    handle separately too!!!?...   // *as*

         Token t = getNextToken();

         char style;
         long classes = classCode;
         int  currentToken = t.kind; // don't fiddle with t.kind directly herein
         String text;

         /*=====================*/
         /*  B.- regular C/C++  */
         /*=====================*/
         switch (currentToken) {
            /*-------------------*/
            /*  keyword (token)  */
            /*-------------------*/
            case BOOL:     // type specifiers
            case CHAR:
            case DOUBLE:
            case ENUM:
            case FLOAT:
            case INT:
            case LONG:
            case SHORT:
            case SIGNED:
            case STRUCT:
            case UNION:
            case UNSIGNED:
            case VOID:
            case SIZE_T: // - stddef.h's #defines
            case WCHAR_T:
                 if (directive == DIRECTIVE_INCLUDE)
                    style = 'i';
                 else if (directive == DIRECTIVE_LINE) {
                    style = 'k';
                    currentToken = lastToken;        // keep pre-#directive info
                    }
                 else {
                    style = 'k';
                    if (function == FUNCTION_TOBRACE)
                       function = FUNCTION_NONE;
                    }
                 break;

            case PUBLIC:   // access control
            case PROTECTED:
            case PRIVATE:
            case FRIEND:

            case TYPENAME:
            case NAMESPACE:
            case USING:

            case INLINE:   // function specifier
            case VIRTUAL:
            case EXPLICIT:

            case AUTO:     // storage classes
            case EXTERN:
            case MUTABLE:
            case ASM:
            case __CPLUSPLUS:
            case REGISTER:
            case STATIC:

            case BREAK:    // various
            case CONTINUE:
            case FALSETOK:
            case GOTO:
            case RETURN:
            case THIS:
            case TRUETOK:
            case SIZEOF:
            case TEMPLATE:
            case TYPEDEF:

            case CONST_CAST: // casts
            case DYNAMIC_CAST:
            case REINTERPRET_CAST:
            case STATIC_CAST:
            case TYPEID:
                 style = 'k';
                 if (directive == DIRECTIVE_NONE)
                    function = FUNCTION_NONE;
                 else
                    currentToken = lastToken;        // keep pre-#directive info
                 break;

            case THROW:
                 style = 'k';
                 if (directive == DIRECTIVE_NONE) {
                    // allow fun header "int a (int b) throw (exc1, exc2) {}"
                    if (function == FUNCTION_TOBRACE)
                       function = FUNCTION_ID;
                    else
                       function = FUNCTION_NONE;
                    }
                 else
                    currentToken = lastToken;        // keep pre-#directive info
                 break;

            case OPERATOR:   // overriding "operator"
                 style = 'k';
                 if (directive != DIRECTIVE_NONE)
                    currentToken = lastToken;        // keep pre-#directive info
                 else if (function == FUNCTION_NONE) {
                    function = FUNCTION_ID;
                    beginFunction = t.endLine;
                    // @bb 12/99: if not followed by an operator,
                    // it is not, after all, a function...   *as*
                    }
                 else if (function == FUNCTION_ID)
                    beginFunction = t.endLine;         // keep only name in view
                 else // FUNCTION_PARENSID, _PARMS, _TOBRACE
                    function = FUNCTION_NONE;
                 break;

            // the only okay keywords when expecting '{' in functions:
            // keywords const/volatile after function header apply to lvalue:
            // bool operator== (Message const& msg) const {};  ~ volatile {}
            case CONST:    // type qualifiers
            case VOLATILE:
                 style = 'k';
                 if (directive == DIRECTIVE_NONE) {
                    if (function == FUNCTION_TOBRACE)
                       endFunction = t.endLine;  // incl. kwd in function header
                    }
                 else
                    currentToken = lastToken;        // keep pre-#directive info
                 break;

            case CASE:                       // keyword + "View" filter CONTROL
            case CATCH:
            case _DEFAULT:
            case DO:
            case ELSE:
            case FOR:
            case IF:
            case SWITCH:
            case TRY:
            case WHILE:
                 style = 'k';
                 if (directive == DIRECTIVE_NONE) {
                    classes |= classControl;
                    function = FUNCTION_NONE;
                    }
                 else
                    currentToken = lastToken;        // keep pre-#directive info
                 break;

            case CLASS:                      // keyword + "View" filter CLASS
                 style = 'k';
                 if (directive == DIRECTIVE_NONE) {
                    classes |= classClass;
                    function = FUNCTION_NONE;
                    }
                 else
                    currentToken = lastToken;        // keep pre-#directive info
                 break;

            /*---------------------------------------*/
            /*  language / system extension keyword  */
            /*---------------------------------------*/
            case NULL:
                 style = 'x';
                 // to fiddle with function searching?! -as-
                 if (directive != DIRECTIVE_NONE)
                    currentToken = lastToken;        // keep pre-#directive info
                 break;

            case EXEC:                       // imbedded SQL/CICS
                 style = 'x';
                 if (directive != DIRECTIVE_NONE)
                    currentToken = lastToken;        // keep pre-#directive info
                 // min. insurance this is not a case of just a #define'd EXEC
                 // @bb 12/99:  this doesn't always work, e.g., change a '}'
                 // before EXEC, won't necessarily continue to the EXEC, etc.;
                 // to change, e.g., perhaps only highlight EXEC as keyword if
                 // followed by SQL/CICS + ensure going back & forth for it
                 // (between ';'s, as we do anyway, is probably enough) *as*
                 else if (lastToken == EOF ||
                     lastToken == SEMICOLON ||
                     lastToken == LCURLYBRACE || lastToken == RCURLYBRACE) {
                    classes |= classControl; // show it in the "Outline" view
                    function = FUNCTION_EXEC;
                    beginFunction = t.endLine;
                    // lexer is now in state IN_EXEC;  the next token will be
                    // processed by processEXECToken().
                    }
                 // else, assume a sort of 'regular' identifier...
                 else {
                    style = 'i';
                    SwitchTo(DEFAULT); // & stay in default (C/C++) lex state!
                    }
                 break;

            case SQL:                        // SQL/CICS not preceded by EXEC...
            case CICS:
                 style = 'x';
                 if (directive != DIRECTIVE_NONE)
                    currentToken = lastToken;        // keep pre-#directive info
                 else {
                    //style = 'e'; ?! -as-
                    function = FUNCTION_NONE;
                    }
                 break;

            /*------------*/
            /*  constant  */
            /*------------*/
            case OCTINT:
            case DECINT:
            case HEXINT:
            case FLOATONE:
            case FLOATTWO:
            case CHARACTER:
                 style = 'n';
                 if (directive != DIRECTIVE_NONE)
                    currentToken = lastToken;        // keep pre-#directive info
                 else if (function != FUNCTION_PARMS)
                    function = FUNCTION_NONE;
                 break;
            case BADOCT:
                 style = 'e';
                 classes |= classError;
                 addErrorMessage(t.endLine, "badOctal");
                 if (directive != DIRECTIVE_NONE)
                    currentToken = lastToken;        // keep pre-#directive info
                 else if (function != FUNCTION_PARMS)
                    function = FUNCTION_NONE;
                 break;

            /*------------------*/
            /*  string literal  */
            /*------------------*/
            case CONT_STRING:        // string continues from last line
                 classes |= classBackwardLink;
                 // vvv fall through...
            case STRING:             // entire string in line
                 style = 'q';
                 if (directive != DIRECTIVE_NONE)
                    currentToken = lastToken;        // keep pre-#directive info
                 else
                    function = FUNCTION_NONE;
                 break;

            case CONT_STRING_CONT:   // string goes on from last onto next line
                 classes |= classBackwardLink;
                 // vvv fall through...
            case STRING_CONT:        // string continues onto next line via '\\'
                 style = 'q';
                 if (directive == DIRECTIVE_NONE)
                    function = FUNCTION_NONE;
                 t.endColumn--;      // set no style for EOL 'char'
                 classes |= classForwardLink;  // ensure we go on parsing on EOF
                 break;

            /*--------------*/
            /*  identifier  */
            /*--------------*/
            case ID:
                 // (a) in #include lines, identifier at best
                 if (directive == DIRECTIVE_INCLUDE)
                    style = 'i';

                 // (b) extension keyword?
                 else if (isExtensionKeyword(t)) {
                    style = 'x';
                    // hmmm, don't touch function searching!?...
                    break;
                    }

                 // (c) C library function?
                 else if (isCLibraryFunction(t)) {
                    // x not C lib fun if just a class fun member (.x ->x ->*x)
                    if (lastToken == DOT   || lastToken == POINTERTO ||
                        lastToken == SCOPE || lastToken == DOTSTAR   ||
                        lastToken == ARROWSTAR)
                       style = 'i';
                    else
                       // should maybe set as function only when indeed we have
                       // a fun call, not just e.g. a 'memcpy' in the air!? *as*
                       style = 'f';
                    }

                 // (d) an identifier (most probably)
                 else
                    style = 'i';

                 if (directive != DIRECTIVE_NONE) {
                    currentToken = lastToken;        // keep pre-#directive info
                    }
                 else if (function == FUNCTION_NONE) {
                        // ignore derived class(es) x, y in a method:
                        // "X::X() : x() {}" or "X::X() : x(), y() {}"
                    if (lastToken != COLON2 && lastToken != COMMA &&
                        // x is not a fun in "case x(a,b) :"
                        lastToken != CASE &&
                        // x is not a method in "a = b ? [obj.]x(n) : 0;"
                        conditional == false) {
                       function = FUNCTION_ID;
                       beginFunction = t.endLine;
                       }
                    }
                 else if (function == FUNCTION_ID)
                    beginFunction = t.endLine;    // adjust start to function id
                 else if (function == FUNCTION_PARENSID) {
                    if (parensCount == 0)
                       function = FUNCTION_NONE;  // name after paren'ed name
                    }
                 else if (function == FUNCTION_TOBRACE)
                    function = FUNCTION_NONE;
                 break;

            /*--------------------------*/
            /*  punctuator (separator)  */
            /*--------------------------*/
            case DOT:            // '.'
                 if (directive == DIRECTIVE_INCLUDE)   // '.' in "include <a.b>"
                    style = 'i';
                 else {
                    style = 'p';
                    if (function != FUNCTION_PARMS)    // not default /
                       function = FUNCTION_NONE;       //   class.class parm
                    }
                 break;
            case LSQUAREBRACKET: // '['
            case RSQUAREBRACKET: // ']'
            case ELLIPSIS:       // "..."
                 style = 'p';
                 // '[', ']' - also function:=FUNCTION_NONE, like old parser,
                 // when in FUNCTION_ID (before '(') or in FUNCTION_TOBRACE;
                 // while for "..." - also kill function if != FUNCTION_PARMS?!
                 break;

            case COMMA:          // ','
                 if (lastToken == OPERATOR && function == FUNCTION_ID)
                    style = 'i';          // a function identifier: "operator ,"
                 else {
                    style = 'p';          // just punctuation...
                    if (function != FUNCTION_PARMS) {
                       conditional = false;
                       function = FUNCTION_NONE;
                       }
                    }
                 break;

            case RPARENTHESIS:   // ')'
                 style = 'p';
                 if (function == FUNCTION_PARENSID) {
                    if (parensCount > 0)
                       parensCount--;
                    }
                 else if (function == FUNCTION_PARMS) {
                    if (parensCount > 0)
                       parensCount--;
                    else {
                       function = FUNCTION_TOBRACE;
                       endFunction = t.endLine;
                       }
                    }
                 else
                    function = FUNCTION_NONE;
                 break;
            case LPARENTHESIS:   // '('
                 style = 'p';
                 if (function == FUNCTION_NONE) {
                    if (directive == DIRECTIVE_NONE) {
                       function = FUNCTION_PARENSID;
                       parensCount = 1;
                       beginFunction = t.endLine;
                       }
                    }
                 else if (function == FUNCTION_ID) {
                    function = FUNCTION_PARMS;
                    parensCount = 0;
                    }
                 else if (function == FUNCTION_PARENSID) {
                    if (parensCount == 0)
                       function = FUNCTION_PARMS;
                    else
                       parensCount++;
                    }
                 else if (function == FUNCTION_PARMS)
                    parensCount++;
                 else
                    function = FUNCTION_NONE;
                 break;
            case SEMICOLON:      // ';'
                 style = 'p';
                 classes |= classSemicolon;
                 conditional = false;
                 function = FUNCTION_NONE;
                 break;

            case LCURLYBRACE:    // '{'
                 style = 'b';
                 classes |= classBrace;
                 if (function == FUNCTION_TOBRACE)
                    setFunction(classFunction);
                 function = FUNCTION_NONE;
                 break;
            case RCURLYBRACE:    // '}'
                 style = 'b';
                 classes |= classBrace;
                 function = FUNCTION_NONE;
                 break;

            case COLON:          // ':'
                 style = 'p';
                 if (function == FUNCTION_TOBRACE) {
                    setFunction(classFunction);         // derived C++ method...
                    currentToken = COLON2;    // special indicator - see case ID
                    }
                 function = FUNCTION_NONE;
                 break;

            /*------------*/
            /*  operator  */
            /*------------*/
            // overloadable operators
            case PLUS:                 // '+'
            case MINUS:                // '-'
            case DIVIDE:               // '/'
            case MOD:                  // '%'
            case BITWISEXOR:           // '^'
            case ISO_XOR:              // "xor"
            case BITWISEOR:            // '|'
            case ISO_BITOR:            // "bitor"
            case TILDE:                // '~'
            case ISO_COMPL:            // "compl"
            case NOT:                  // '!'
            case ISO_NOT:              // "not"
            case LESSTHAN:             // '<'
            case GREATERTHAN:          // '>'
            case PLUSEQUAL:            // "+="
            case MINUSEQUAL:           // "-="
            case TIMESEQUAL:           // "*="
            case DIVIDEEQUAL:          // "/="
            case MODEQUAL:             // "%="
            case BITWISEXOREQUAL:      // "^="
            case ISO_XOR_EQ:           // "xor_eq"
            case BITWISEANDEQUAL:      // "&="
            case ISO_AND_EQ:           // "and_eq"
            case BITWISEOREQUAL:       // "|="
            case ISO_OR_EQ:            // "or_eq"
            case SHIFTLEFT:            // "<<"
            case SHIFTRIGHT:           // ">>"
            case SHIFTLEFTEQUAL:       // "<<="
            case SHIFTRIGHTEQUAL:      // ">>="
            case EQUAL:                // "=="
            case NOTEQUAL:             // "!="
            case ISO_NOT_EQ:           // "not_eq"
            case LESSTHANOREQUALTO:    // "<="
            case GREATERTHANOREQUALTO: // ">="
            case AND:                  // "&&"
            case ISO_AND:              // "and"
            case OR:                   // "||"
            case ISO_OR:               // "or"
            case PLUSPLUS:             // "++"
            case MINUSMINUS:           // "--"
            //se COMMA: done elsewhere // ','
            case ARROWSTAR:            // "->*" pointer to member
            case POINTERTO:            // "->"
                 if (lastToken == OPERATOR && function == FUNCTION_ID)
                    style = 'i';               // now it's a function identifier
                 else {
                    // actually, some of these operators can't really be used to
                    // set a constructor's argument default value, so for them
                    // we should just set FUNCTION_NONE!?
                    // Acceptable ones in _PARMS are '=' (cf ASSIGNEQUAL below),
                    // '%', '/', '+', '-', '~', '!' (any more??);
                    // also, '<' and '>' used for template arguments in _PARMS.
                    if (function != FUNCTION_PARMS)
                       function = FUNCTION_NONE;
                    style = 'o';                 // regular C++ operator
                    }
                 break;

            case NEW:    // "new" operator
            case DELETE: // "delete" (have a "delete[]" too!? *as*)
                 if (lastToken == OPERATOR && function == FUNCTION_ID)
                    style = 'i';               // now it's a function identifier
                 else {
                    function = FUNCTION_NONE;
                    style = 'k';               // regular C++ operator:  use
                    }                          //  'keyword' for the colour...
                 break;

            case ASSIGNEQUAL: // '='
                 if (lastToken == OPERATOR && function == FUNCTION_ID)
                    style = 'i';               // now it's a function identifier
                 else
                    style = 'o';               // regular C++ operator
                 break;

            case PARENS:      // "()"
                 if (lastToken == OPERATOR) {  // 1.- "operator ()"
                    if (function == FUNCTION_ID)
                       style = 'i';            //  now is a function identifier
                    else {
                       function = FUNCTION_NONE;
                       style = 'p';            //  just punctuation...
                       }
                    }
                 else {                        // 2.- just your regular "()"
                    if (function == FUNCTION_ID) {
                       function = FUNCTION_TOBRACE;
                       endFunction = t.endLine;
                       }
                    else if (function == FUNCTION_PARENSID) {
                       if (parensCount == 0) {
                          function = FUNCTION_TOBRACE;
                          endFunction = t.endLine;
                          }
                       }
                    else
                       function = FUNCTION_NONE;
                    style = 'p';               //  just punctuation...
                    }
                 break;

            case BRACKETS:   // "[]"
                 if (lastToken == OPERATOR) {  // 1.- "operator []"
                    if (function == FUNCTION_ID)
                       style = 'i';            //  now is a function identifier
                    else {
                       function = FUNCTION_NONE;
                       style = 'p';            //  just punctuation...
                       }
                    }
                 else {                        // 2.- just your regular "[]"
                    if (function == FUNCTION_ID || function == FUNCTION_TOBRACE)
                       function = FUNCTION_NONE;
                    style = 'p';
                    }
                 break;

            case AMPERSAND:  // '&' bitwise and / address of / reference
            case ISO_BITAND: // "bitand"
            case STAR:       // '*' multiply / dereference operator
                 if (lastToken == OPERATOR && function == FUNCTION_ID)
                    style = 'i';                // now is a function identifier
                 else {
                    // if FUNCTION_ID (before '(') / FUNCTION_TOBRACE, then
                    // function = FUNCTION_NONE!?                      *as*
                    style = 'o';    // (set 'o' only on #directive lines?! *as*)
                    }
                 break;

            // other operators
            case QUESTIONMARK: // '?'
                 conditional = true;
                 style = 'o';
                 function = FUNCTION_NONE;
                 break;

            case SCOPE:        // "::"
                 style = 'o';
                 if (function != FUNCTION_PARMS)
                    function = FUNCTION_NONE;
                 break;
            case DOTSTAR:      // ".*"
                 style = 'o';
                 function = FUNCTION_NONE;
                 break;
            case POUND:        // '#' e.g., ##etc in #define macro ops
                 style = 'o';       // (set 'o' only on #directive lines?! *as*)
                 // shouldn't also: function=FUNCTION_NONE, like old parser??
                 break;

            /*--------------------------*/
            /*  preprocessor directive  */
            /*--------------------------*/
            case INCLUDEDIRECTIVE:     // "#include"
                 // if (directive != DIRECTIVE_NONE ||
                 //     function != FUNCTION_NONE) just style as ID?!
                 directive = DIRECTIVE_INCLUDE;
                 style = 'h';
                 classes |= classInclude;
                 break;
            case DIRECTIVE:            // "#if", "#define", etc.
                 // if (directive != DIRECTIVE_NONE ||
                 //     function != FUNCTION_NONE) just style as ID?!
                 directive = DIRECTIVE_LINE;
                 style = 'h';
                 currentToken = lastToken;           // keep pre-#directive info
                 break;

            /*-------------*/
            /*  others...  */
            /*-------------*/
            case EOC:                  // unexpected end-of-comment "*/"
                 style = 'e';
                 classes = classError;
                 addErrorMessage(t.endLine, "endOfComment");
                 currentToken = lastToken;  // don't let EOC interfere parsing
                 t.endColumn--; // cf extra char after "*/" that we check != "/"
                 break;

            case EOL:               // line boundary - terminate directive state
                 if (directive != DIRECTIVE_NONE)
                    directive = DIRECTIVE_NONE;
                 // don't record EOL as lastToken or we lose good information...
                 return LEXER_RC_OK;

            case CONTCHAR:         // '\\'+[spaces]+EOL - continuation character
                 text = stream.getLpexView().elementText(t.beginLine);
                 if (text != null && text.length() >= t.beginColumn + 2 &&
                     text.charAt(t.beginColumn) == '?') {  // \'s trigraph "??/"
                   stream.setStyles(t.beginColumn, t.beginColumn+2, 't'); // "??/" style
                   stream.setStyles(t.beginColumn+3, t.endColumn-1, '_'); // & any spaces
                   }
                 else {
                   stream.setStyles(t.beginColumn, t.beginColumn, 't');   // '\\' style
                   stream.setStyles(t.beginColumn+1, t.endColumn-1, '_'); // & any spaces
                   }
                 // any directive/macro now still in effect for the next line
                 // don't record lastToken as '\\', we may lose good info...
                 return LEXER_RC_OK;

            case BACKSLASH:         // '\\' in a not-recognized escape sequence
                 style = '!';       // / error?!? (inside a string, it is!) *as*
                 break;

            /*-------------------------------------------------*/
            /*  end of current parse range / real end of file  */
            /*-------------------------------------------------*/
            case EOF:
                 if (function  != FUNCTION_NONE  || // may still be a function
                     directive != DIRECTIVE_NONE || // directive/macro continues
                     conditional == true)           // inside "a ? x : z;"
                    // other cases: parseElement() goes on when classForwardLink
                    return LEXER_RC_EOF | LEXER_RC_MORE; // try to go on parsing
                 return LEXER_RC_EOF;

            /*----------------------*/
            /*  everything else...  */
            /*----------------------*/
            default:
                 lastToken = currentToken;
                 return LEXER_RC_OK;
            }//end "switch"

         lastToken = currentToken;
         stream.setStyles(t.beginColumn, t.endColumn, style);
         stream.setClasses(classes);
         return LEXER_RC_OK;
      }

      /**
       * Handles the EXEC constructs for embedded SQL / CICS statements.
       * These are handled by the SqlLexer's and CicsLexer's processToken(),
       * if these are defined in this parser or in subclassing parser(s);
       * the code in here is sufficient to 'tolerate' the EXEC {SQL|CICS} .. ;
       * construct.
       */
      private int    processEXECToken()
      {
         Token t = getNextToken();

         int currentToken = t.kind;
         if (currentToken == EOF)
            return LEXER_RC_EOF | LEXER_RC_MORE; // we're here, still in EXEC...

         char style;
         long classes = classCode;

         /*====================================*/
         /*  A.- after EXEC SQL                */
         /*  Actually handled by SqlLexer's    */
         /*  processToken(), where available.  */
         /*====================================*/
         if (function == FUNCTION_SQL) {
            if (currentToken == SEMICOLON) {
               style = 'p';
               //classes |= classSemicolon;
               endFunction = t.endLine;
               setFunction(classSql);
               function = FUNCTION_NONE;
               SwitchTo(DEFAULT); // switch scanner to default lexical state
               }
            else // e.g., EXEC_CHAR
               style = '!'; // good enough default style...
            }

         /*====================================*/
         /*  B.- after EXEC CICS               */
         /*  Actually handled by CicsLexer's   */
         /*  processToken(), where available.  */
         /*====================================*/
         else if (function == FUNCTION_CICS) {
            if (currentToken == SEMICOLON) {
               style = 'p';
               //classes |= classSemicolon;
               endFunction = t.endLine;
               setFunction(classCics);
               function = FUNCTION_NONE;
               SwitchTo(DEFAULT); // switch scanner to default lexical state
               }
            else // e.g., EXEC_CHAR
               style = '!'; // good enough default style...
            }

         /*==================*/
         /*  C.- after EXEC  */
         /*==================*/
         else {
            if (currentToken == SQL) {
               style = 'x';
               function = FUNCTION_SQL;
               setLexer(LEXER_SQL);
               }
            else if (currentToken == CICS) {
               style = 'x';
               function = FUNCTION_CICS;
               setLexer(LEXER_CICS);
               }
            else { // e.g., EXEC_CHAR
               style = 'e';
               classes |= classError;
               addErrorMessage(t.endLine, "syntaxError");
               function = FUNCTION_NONE;
               SwitchTo(DEFAULT); // switch scanner to default (C/C++) lex state
               }
            }

         lastToken = currentToken;
         stream.setStyles(t.beginColumn, t.endColumn, style);
         stream.setClasses(classes);
         return LEXER_RC_OK;
      }

      /**
       * Set style & class for comments.  Activated by \n, \r, or * /
       * encountered while in a comment SPECIAL_TOKEN.  SPECIAL_TOKEN, rather
       * than TOKEN, is used for these, as we don't need to see the same
       * tokens in processToken() too, nor have them recorded in the parse.
       *
       * Does the real work for the extended dummy in LpexCppParser.jj.
       * @param t special token
       */
      protected void setComment(Token t)
      {
         long classes = classComment;

         switch (getCurLexState()) {
            case IN_COMMENT:                             // "/*" comment:
            case IN_EXECCOMMENT:
                 if (t.kind != COMMENT_END &&
                     t.kind != EXECCOMMENT_END)
                    classes |= classForwardLink;         //  comment to continue
                 if ((comments & classForwardLink) != 0) //  continuing comment:
                    classes |= classBackwardLink;        //   double-link it
                 break;
            }
         comments = classes;

         if (t.endColumn >= t.beginColumn)
            stream.setStyles(t.beginColumn, t.endColumn, 'c');
         stream.setClasses(classes);
      }
   }
}