//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1998, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CppCicsParser - document parser for C/C++ + embedded CICS.
//----------------------------------------------------------------------------

package com.ibm.lpex.cpp;

import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCharStream;
import com.ibm.lpex.core.LpexView;

import com.ibm.lpex.cics.CicsLexer;
import com.ibm.lpex.cics.CicsLexerClasses;
import com.ibm.lpex.cics.CicsLexerStyles;


/**
 * Document parser for C/C++ with embedded CICS statements.
 *
 * <p>Action added by this parser:
 * <b>cics</b> for a selective view of the embedded CICS statements.
 */
public class CppCicsParser extends CppParser
{
   /**
    * Constructor for CppCicsParser.
    * It defines the <b>cics</b> action.
    */
   public CppCicsParser(LpexView lpexView)
   {
      super(lpexView);

      // view filter action "cics"
      LpexAction lpexAction = new LpexAction()
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_CICS);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
      };
      view.defineAction("cics", lpexAction);
   }

   /**
    * Return this parser's items for the popup View submenu:
    * functions, outline, cics, errors.
    */
   public String getPopupViewItems()
   {
      StringBuffer buffer = new StringBuffer();
      buffer.append(getLanguage());
      buffer.append(".popup.functions functions ");
      buffer.append(getLanguage());
      buffer.append(".popup.outline outline ");
      buffer.append(getLanguage());
      buffer.append(".popup.cics cics ");
      buffer.append(MSG_POPUP_ERRORS);
      buffer.append(" errors");
      return buffer.toString();
   }

   /**
    * Retrieve the CicsLexer.
    * This method constructs and returns a CicsLexer object for parsing
    * C/C++ embedded CICS statements.
    */
   public CicsLexer getCicsLexer(LpexCharStream stream)
   {
      return new CicsLexer(stream, getLanguage(),
                 new CicsLexerStyles("ceknqip"),
                 new CicsLexerClasses(view, classCode,
                                     classForwardLink, classBackwardLink,
                                     classComment, classError,
                                     0)); // we don't care about a cicsStatement
   }
}