//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1999, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CobolWords - keywords for the COBOL document parsers.
//----------------------------------------------------------------------------

package com.ibm.lpex.cobol;


/**
 * Keywords and keyword-related functions for the COBOL document parsers.
 */
public final class CobolWords
{
 public static final int
  AUTHOR        =  1,
  DATE          =  2,
  DATE_COMPILED =  3,
  DATE_WRITTEN  =  4,
  DIVISION      =  5,
  FORMAT        =  6,
  FUNCTION      =  7,
  INSTALLATION  =  8,
  IS            =  9,
  PICTURE       = 10,
  PROGRAM_ID    = 11,
  SECTION       = 12,
  SECURITY      = 13,
  CBL           = 14,
  CONTROL       = 15,
  EJECT         = 16,
  SKIP          = 17,
  TITLE         = 18,

  LAST_ID       = 18;

 private static Word[] _reservedWords =
  {
   new Word("*"),
   new Word("**"),
   new Word("+"),
   new Word("-"),
   new Word("/"),
   new Word("<"),
   new Word("<="),
   new Word("="),
   new Word(">"),
   new Word(">="),
   new Word(">>CALLINT"),
   new Word(">>CALLINTERFACE"),
   new Word("ACCEPT"),
   new Word("ACCESS"),
   new Word("ADD"),
   new Word("ADDRESS"),
   new Word("ADVANCING"),
   new Word("AFTER"),
   new Word("ALL"),
   new Word("ALLOWING"),
   new Word("ALPHABET"),
   new Word("ALPHABETIC"),
   new Word("ALPHABETIC-LOWER"),
   new Word("ALPHABETIC-UPPER"),
   new Word("ALPHANUMERIC"),
   new Word("ALPHANUMERIC-EDITED"),
   new Word("ALSO"),
   new Word("ALTER"),
   new Word("ALTERNATE"),
   new Word("AND"),
   new Word("ANY"),
   new Word("APPLY"),
   new Word("ARE"),
   new Word("AREA"),
   new Word("AREAS"),
   new Word("ARITHMETIC"),
   new Word("ASCENDING"),
   new Word("ASSIGN"),
   new Word("AT"),
   new Word("AUTHOR", AUTHOR),
   new Word("AUTOMATIC"),
   new Word("B-AND"),
   new Word("B-EXOR"),
   new Word("B-LESS"),
   new Word("B-NOT"),
   new Word("B-OR"),
   new Word("BASIS"),
   new Word("BEFORE"),
   new Word("BEGINNING"),
   new Word("BINARY"),
   new Word("BIT"),
   new Word("BITS"),
   new Word("BLANK"),
   new Word("BLOCK"),
   new Word("BOOLEAN"),
   new Word("BOTTOM"),
   new Word("BY"),
   new Word("CALL"),
   new Word("CANCEL"),
   new Word("CBL"),
   new Word("CD"),
   new Word("CF"),
   new Word("CH"),
   new Word("CHARACTER"),
   new Word("CHARACTERS"),
   new Word("CLASS"),
   new Word("CLASS-ID"),
   new Word("CLOCK-UNITS"),
   new Word("CLOSE"),
   new Word("COBOL"),
   new Word("CODE"),
   new Word("CODE-SET"),
   new Word("COLLATING"),
   new Word("COLUMN"),
   new Word("COM-REG"),
   new Word("COMMA"),
   new Word("COMMIT"),
   new Word("COMMON"),
   new Word("COMMUNICATION"),
   new Word("COMP"),
   new Word("COMP-1"),
   new Word("COMP-2"),
   new Word("COMP-3"),
   new Word("COMP-4"),
   new Word("COMP-5"),
   new Word("COMP-6"),
   new Word("COMP-7"),
   new Word("COMP-8"),
   new Word("COMP-9"),
   new Word("COMPUTATIONAL"),
   new Word("COMPUTATIONAL-1"),
   new Word("COMPUTATIONAL-2"),
   new Word("COMPUTATIONAL-3"),
   new Word("COMPUTATIONAL-4"),
   new Word("COMPUTATIONAL-5"),
   new Word("COMPUTATIONAL-6"),
   new Word("COMPUTATIONAL-7"),
   new Word("COMPUTATIONAL-8"),
   new Word("COMPUTATIONAL-9"),
   new Word("COMPUTE"),
   new Word("CONFIGURATION"),
   new Word("CONNECT"),
   new Word("CONTAINED"),
   new Word("CONTAINS"),
   new Word("CONTENT"),
   new Word("CONTINUE"),
   new Word("CONTROL"),
   new Word("CONTROLS"),
   new Word("CONVERTING"),
   new Word("COPY"),
   new Word("CORR"),
   new Word("CORRESPONDING"),
   new Word("COUNT"),
   new Word("CURRENCY"),
   new Word("CURRENT"),
   new Word("CYCLE"),
   new Word("DATA"),
   new Word("DATE", DATE),
   new Word("DATE-COMPILED", DATE_COMPILED),
   new Word("DATE-WRITTEN", DATE_WRITTEN),
   new Word("DAY"),
   new Word("DAY-OF-WEEK"),
   new Word("DB"),
   new Word("DB-ACCESS-CONTROL-KEY"),
   new Word("DB-DATA-NAME"),
   new Word("DB-EXCEPTION"),
   new Word("DB-RECORD-NAME"),
   new Word("DB-SET-NAME"),
   new Word("DB-STATUS"),
   new Word("DBCS"),
   new Word("DE"),
   new Word("DEBUG-CONTENTS"),
   new Word("DEBUG-ITEM"),
   new Word("DEBUG-LINE"),
   new Word("DEBUG-NAME"),
   new Word("DEBUG-SUB-1"),
   new Word("DEBUG-SUB-2"),
   new Word("DEBUG-SUB-3"),
   new Word("DEBUGGING"),
   new Word("DECIMAL-POINT"),
   new Word("DECLARATIVES"),
   new Word("DEFAULT"),
   new Word("DELETE"),
   new Word("DELIMITED"),
   new Word("DELIMITER"),
   new Word("DEPENDING"),
   new Word("DESCENDING"),
   new Word("DESTINATION"),
   new Word("DETAIL"),
   new Word("DISABLE"),
   new Word("DISCONNECT"),
   new Word("DISPLAY"),
   new Word("DISPLAY-1"),
   new Word("DISPLAY-2"),
   new Word("DISPLAY-3"),
   new Word("DISPLAY-4"),
   new Word("DISPLAY-5"),
   new Word("DISPLAY-6"),
   new Word("DISPLAY-7"),
   new Word("DISPLAY-8"),
   new Word("DISPLAY-9"),
   new Word("DIVIDE"),
   new Word("DIVISION", DIVISION),
   new Word("DOWN"),
   new Word("DUPLICATE"),
   new Word("DUPLICATES"),
   new Word("DYNAMIC"),
   new Word("EGCS"),
   new Word("EGI"),
   new Word("EJECT"),
   new Word("ELSE"),
   new Word("EMI"),
   new Word("EMPTY"),
   new Word("ENABLE"),
   new Word("END"),
   new Word("END-ADD"),
   new Word("END-CALL"),
   new Word("END-COMPUTE"),
   new Word("END-DELETE"),
   new Word("END-DISABLE"),
   new Word("END-DIVIDE"),
   new Word("END-ENABLE"),
   new Word("END-EVALUATE"),
   new Word("END-IF"),
   new Word("END-INVOKE"),
   new Word("END-MULTIPLY"),
   new Word("END-OF-PAGE"),
   new Word("END-PERFORM"),
   new Word("END-READ"),
   new Word("END-RECEIVE"),
   new Word("END-RETURN"),
   new Word("END-REWRITE"),
   new Word("END-SEARCH"),
   new Word("END-START"),
   new Word("END-STRING"),
   new Word("END-SUBTRACT"),
   new Word("END-TRANSCEIVE"),
   new Word("END-UNSTRING"),
   new Word("END-WRITE"),
   new Word("ENDING"),
   new Word("ENTER"),
   new Word("ENTRY"),
   new Word("ENVIRONMENT"),
   new Word("EOP"),
   new Word("EQUAL"),
   new Word("EQUALS"),
   new Word("ERASE"),
   new Word("ERROR"),
   new Word("ESI"),
   new Word("EVALUATE"),
   new Word("EVERY"),
   new Word("EXACT"),
   new Word("EXCEEDS"),
   new Word("EXCEPTION"),
   new Word("EXCLUSIVE"),
   new Word("EXIT"),
   new Word("EXTEND"),
   new Word("EXTERNAL"),
   new Word("FALSE"),
   new Word("FD"),
   new Word("FETCH"),
   new Word("FILE"),
   new Word("FILE-CONTROL"),
   new Word("FILLER"),
   new Word("FINAL"),
   new Word("FIND"),
   new Word("FINISH"),
   new Word("FIRST"),
   new Word("FOOTING"),
   new Word("FOR"),
   new Word("FORM"),
   new Word("FORMAT", FORMAT),
   new Word("FREE"),
   new Word("FROM"),
   new Word("FUNCTION", FUNCTION),
   new Word("GENERATE"),
   new Word("GET"),
   new Word("GIVING"),
   new Word("GLOBAL"),
   new Word("GO"),
   new Word("GOBACK"),
   new Word("GREATER"),
   new Word("GROUP"),
   new Word("HEADING"),
   new Word("HIGH-VALUE"),
   new Word("HIGH-VALUES"),
   new Word("I-O"),
   new Word("I-O-CONTROL"),
   new Word("ID"),
   new Word("IDENTIFICATION"),
   new Word("IF"),
   new Word("IN"),
   new Word("INDEX"),
   new Word("INDEX-1"),
   new Word("INDEX-2"),
   new Word("INDEX-3"),
   new Word("INDEX-4"),
   new Word("INDEX-5"),
   new Word("INDEX-6"),
   new Word("INDEX-7"),
   new Word("INDEX-8"),
   new Word("INDEX-9"),
   new Word("INDEXED"),
   new Word("INDICATE"),
   new Word("INHERITS"),
   new Word("INITIAL"),
   new Word("INITIALIZE"),
   new Word("INITIATE"),
   new Word("INPUT"),
   new Word("INPUT-OUTPUT"),
   new Word("INSERT"),
   new Word("INSPECT"),
   new Word("INSTALLATION", INSTALLATION),
   new Word("INTO"),
   new Word("INVALID"),
   new Word("INVOKE"),
   new Word("IS", IS),
   new Word("JUST"),
   new Word("JUSTIFIED"),
   new Word("KANJI"),
   new Word("KEEP"),
   new Word("KEY"),
   new Word("LABEL"),
   new Word("LAST"),
   new Word("LD"),
   new Word("LEADING"),
   new Word("LEFT"),
   new Word("LENGTH"),
   new Word("LESS"),
   new Word("LIMIT"),
   new Word("LIMITS"),
   new Word("LINAGE"),
   new Word("LINAGE-COUNTER"),
   new Word("LINE"),
   new Word("LINE-COUNTER"),
   new Word("LINES"),
   new Word("LINKAGE"),
   new Word("LOCAL-STORAGE"),
   new Word("LOCALLY"),
   new Word("LOCK"),
   new Word("LOW-VALUE"),
   new Word("LOW-VALUES"),
   new Word("MEMBER"),
   new Word("MEMORY"),
   new Word("MERGE"),
   new Word("MESSAGE"),
   new Word("METACLASS"),
   new Word("METHOD"),
   new Word("METHOD-ID"),
   new Word("MODE"),
   new Word("MODIFY"),
   new Word("MODULES"),
   new Word("MORE-LABELS"),
   new Word("MOVE"),
   new Word("MULTIPLE"),
   new Word("MULTIPLY"),
   new Word("NATIVE"),
   new Word("NEGATIVE"),
   new Word("NEXT"),
   new Word("NO"),
   new Word("NORMAL"),
   new Word("NOT"),
   new Word("NULL"),
   new Word("NULLS"),
   new Word("NUMBER"),
   new Word("NUMERIC"),
   new Word("NUMERIC-EDITED"),
   new Word("OBJECT"),
   new Word("OBJECT-COMPUTER"),
   new Word("OCCURS"),
   new Word("OF"),
   new Word("OFF"),
   new Word("OMITTED"),
   new Word("ON"),
   new Word("ONLY"),
   new Word("OPEN"),
   new Word("OPTIONAL"),
   new Word("OR"),
   new Word("ORDER"),
   new Word("ORGANIZATION"),
   new Word("OTHER"),
   new Word("OUTPUT"),
   new Word("OVERFLOW"),
   new Word("OVERRIDE"),
   new Word("OWNER"),
   new Word("PACKED-DECIMAL"),
   new Word("PADDING"),
   new Word("PAGE"),
   new Word("PAGE-COUNTER"),
   new Word("PARAGRAPH"),
   new Word("PASSWORD"),
   new Word("PERFORM"),
   new Word("PF"),
   new Word("PH"),
   new Word("PIC", PICTURE),
   new Word("PICTURE", PICTURE),
   new Word("PLUS"),
   new Word("POINTER"),
   new Word("POSITION"),
   new Word("POSITIVE"),
   new Word("PRESENT"),
   new Word("PREVIOUS"),
   new Word("PRINTING"),
   new Word("PRIOR"),
   new Word("PROCEDURE"),
   new Word("PROCEDURE-POINTER"),
   new Word("PROCEDURES"),
   new Word("PROCEED"),
   new Word("PROCESSING"),
   new Word("PROGRAM"),
   new Word("PROGRAM-ID", PROGRAM_ID),
   new Word("PROTECTED"),
   new Word("PURGE"),
   new Word("QUEUE"),
   new Word("QUOTE"),
   new Word("QUOTES"),
   new Word("RANDOM"),
   new Word("RD"),
   new Word("READ"),
   new Word("READY"),
   new Word("REALM"),
   new Word("RECEIVE"),
   new Word("RECORD"),
   new Word("RECORD-NAME"),
   new Word("RECORDING"),
   new Word("RECORDS"),
   new Word("RECURSIVE"),
   new Word("REDEFINES"),
   new Word("REEL"),
   new Word("REFERENCE"),
   new Word("REFERENCES"),
   new Word("RELATION"),
   new Word("RELATIVE"),
   new Word("RELEASE"),
   new Word("RELOAD"),
   new Word("REMAINDER"),
   new Word("REMOVAL"),
   new Word("RENAMES"),
   new Word("REPEATED"),
   new Word("REPLACE"),
   new Word("REPLACING"),
   new Word("REPORT"),
   new Word("REPORTING"),
   new Word("REPORTS"),
   new Word("REPOSITORY"),
   new Word("RERUN"),
   new Word("RESERVE"),
   new Word("RESET"),
   new Word("RETAINING"),
   new Word("RETRIEVAL"),
   new Word("RETURN"),
   new Word("RETURN-CODE"),
   new Word("RETURNING"),
   new Word("REVERSED"),
   new Word("REWIND"),
   new Word("REWRITE"),
   new Word("RF"),
   new Word("RH"),
   new Word("RIGHT"),
   new Word("ROLLBACK"),
   new Word("ROUNDED"),
   new Word("RUN"),
   new Word("SAME"),
   new Word("SD"),
   new Word("SEARCH"),
   new Word("SECTION", SECTION),
   new Word("SECURITY", SECURITY),
   new Word("SEGMENT"),
   new Word("SEGMENT-LIMIT"),
   new Word("SELECT"),
   new Word("SELF"),
   new Word("SEND"),
   new Word("SENTENCE"),
   new Word("SEPARATE"),
   new Word("SEQUENCE"),
   new Word("SEQUENTIAL"),
   new Word("SERVICE"),
   new Word("SESSION-ID"),
   new Word("SET"),
   new Word("SHARED"),
   new Word("SHIFT-IN"),
   new Word("SHIFT-OUT"),
   new Word("SIGN"),
   new Word("SIZE"),
   new Word("SKIP1"),
   new Word("SKIP2"),
   new Word("SKIP3"),
   new Word("SORT"),
   new Word("SORT-CONTROL"),
   new Word("SORT-CORE-SIZE"),
   new Word("SORT-FILE-SIZE"),
   new Word("SORT-MERGE"),
   new Word("SORT-MESSAGE"),
   new Word("SORT-MODE-SIZE"),
   new Word("SORT-RETURN"),
   new Word("SOURCE"),
   new Word("SOURCE-COMPUTER"),
   new Word("SPACE"),
   new Word("SPACES"),
   new Word("SPECIAL-NAMES"),
   new Word("STANDARD"),
   new Word("STANDARD-1"),
   new Word("STANDARD-2"),
   new Word("STANDARD-3"),
   new Word("STANDARD-4"),
   new Word("START"),
   new Word("STATUS"),
   new Word("STOP"),
   new Word("STORE"),
   new Word("STRING"),
   new Word("SUB-QUEUE-1"),
   new Word("SUB-QUEUE-2"),
   new Word("SUB-QUEUE-3"),
   new Word("SUB-SCHEMA"),
   new Word("SUBTRACT"),
   new Word("SUM"),
   new Word("SUPER"),
   new Word("SUPPRESS"),
   new Word("SYMBOLIC"),
   new Word("SYNC"),
   new Word("SYNCHRONIZED"),
   new Word("TABLE"),
   new Word("TALLY"),
   new Word("TALLYING"),
   new Word("TAPE"),
   new Word("TENANT"),
   new Word("TERMINAL"),
   new Word("TERMINATE"),
   new Word("TEST"),
   new Word("TEXT"),
   new Word("THAN"),
   new Word("THEN"),
   new Word("THROUGH"),
   new Word("THRU"),
   new Word("TIME"),
   new Word("TIMEOUT"),
   new Word("TIMES"),
   new Word("TITLE"),
   new Word("TO"),
   new Word("TOP"),
   new Word("TRACE"),
   new Word("TRAILING"),
   new Word("TRANSCEIVE"),
   new Word("TRUE"),
   new Word("TYPE"),
   new Word("UNEQUAL"),
   new Word("UNIT"),
   new Word("UNSTRING"),
   new Word("UNTIL"),
   new Word("UP"),
   new Word("UPDATE"),
   new Word("UPON"),
   new Word("USAGE"),
   new Word("USAGE-MODE"),
   new Word("USE"),
   new Word("USING"),
   new Word("VALID"),
   new Word("VALIDATE"),
   new Word("VALUE"),
   new Word("VALUES"),
   new Word("VARYING"),
   new Word("WAIT"),
   new Word("WHEN"),
   new Word("WHEN-COMPILED"),
   new Word("WITH"),
   new Word("WITHIN"),
   new Word("WORDS"),
   new Word("WORKING-STORAGE"),
   new Word("WRITE"),
   new Word("WRITE-ONLY"),
   new Word("ZERO"),
   new Word("ZEROES"),
   new Word("ZEROS"),
  };

 /**
  * Determine if the specified string is a reserved word.
  */
 public static Word findReservedWord(StringBuffer stringBuffer)
  {
   return (Word)findWord(_reservedWords, stringBuffer);
  }

 /**
  * This class is used to combine a word with an id.
  */
 public static class Word
  {
   private String _string;
   private int _id;

   /**
    * Construct an instance of Word with the given
    * string and id.
    */
   public Word(String string, int id)
    {
     _string = string;
     _id = id;
    }

   /**
    * Construct an instance of Word with only a string.
    * This can be used if no id is necessary.
    */
   public Word(String string)
    {
     _string = string;
     _id = -1;
    }

   /**
    * Return the Word as a string.
    */
   public String toString()
    {
     return _string;
    }

   /**
    * Return the Word's id.
    */
   public int id()
    {
     return _id;
    }
  }

 private static String[] _functionNames =
  {
   "ACOS",
   "ANNUITY",
   "ASIN",
   "ATAN",
   "CHAR",
   "COS",
   "CURRENT-DATE",
   "DATE-OF-INTEGER",
   "DATE-TO-YYYYMMDD",
   "DATEVAL",
   "DAY-OF-INTEGER",
   "DAY-TO-YYYYDDD",
   "FACTORIAL",
   "INTEGER",
   "INTEGER-OF-DATE",
   "INTEGER-OF-DAY",
   "INTEGER-PART",
   "LENGTH",
   "LOG",
   "LOG10",
   "LOWER-CASE",
   "MAX",
   "MEAN",
   "MEDIAN",
   "MIDRANGE",
   "MIN",
   "MOD",
   "NUMVAL",
   "NUMVAL-C",
   "ORD",
   "ORD-MAX",
   "ORD-MIN",
   "PRESENT-VALUE",
   "RANDOM",
   "RANGE",
   "REM",
   "REVERSE",
   "SIN",
   "SQRT",
   "STANDARD-DEVIATION",
   "SUM",
   "TAN",
   "UNDATE",
   "UPPER-CASE",
   "VARIANCE",
   "WHEN-COMPILED",
   "YEAR-TO-YYYY",
   "YEARWINDOW",
  };

 /**
  * Determine if the specified string is a function name.
  */
 public static boolean isFunctionName(StringBuffer stringBuffer)
  {
   return findWord(_functionNames, stringBuffer) != null;
  }

 private static String[] _dateFormats =
  {
   "XXXXYY",
   "XXXXYYYY",
   "XXXYY",
   "XXXYYYY",
   "XXYY",
   "XXYYYY",
   "XYY",
   "XYYYY",
   "YY",
   "YYX",
   "YYXX",
   "YYXXX",
   "YYXXXX",
   "YYYY",
   "YYYYX",
   "YYYYXX",
   "YYYYXXX",
   "YYYYXXXX",
  };

 /**
  * Determine if the specified string is a date format.
  */
 public static boolean isDateFormat(StringBuffer stringBuffer)
  {
   return findWord(_dateFormats, stringBuffer) != null;
  }

 private static Word[] _directives =
  {
   new Word("*CBL", CONTROL),
   new Word("*CONTROL", CONTROL),
   new Word("CBL", CBL),
   new Word("EJECT", EJECT),
   new Word("PROCESS", CBL),
   new Word("SKIP1", SKIP),
   new Word("SKIP2", SKIP),
   new Word("SKIP3", SKIP),
   new Word("TITLE", TITLE),
  };

 /**
  * Determine if the specified string is a directive.
  */
 public static Word findDirective(StringBuffer stringBuffer)
  {
   return (Word) findWord(_directives, stringBuffer);
  }

 private static String[] _controlOptions =
  {
   "LIST",
   "MAP",
   "NOLIST",
   "NOMAP",
   "NOSOURCE",
   "SOURCE",
  };

 /**
  * Determine if the specified string is a valid option for
  * the *CONTROL (*CBL) directive.
  */
 public static boolean isControlOption(StringBuffer stringBuffer)
  {
   return findWord(_controlOptions, stringBuffer) != null;
  }

 /**
  * Perform a binary search for the specified word in an array of words.
  * Returns the word if found, otherwise returns <code>null</code>.
  * The array of words is assumed to be sorted and uppercase.
  * The search word may be any case, but will match case insensitively.
  */
 public static Object findWord(Object _words[], StringBuffer word)
  {
   int i, k;
   int hi, lo;

   hi = _words.length - 1;
   lo = 0;
   while (hi >= lo)
    {
     i = (hi + lo) / 2;
     k = compare(_words[i], word);
     if (k > 0)             // key is lower
      {
       hi = i - 1;
      }
     else if (k < 0)        // key is higher
      {
       lo = i + 1;
      }
     else
      {
       return _words[i];    // we found it.
      }
    }
   return null;             // we didn't find it.
  }

 /**
  * Compare <code>object</code> to <code>stringBuffer</code>.
  * The string value of <code>object</code> is assumed to be uppercase;
  * <code>stringBuffer</code> may be in any case, as it is uppercased before
  * the comparison is made.
  *
  * @return 0 if the values are equal, or
  *         an integer > 0 if object is greater than stringBuffer, or
  *         an integer < 0 if object is less than stringBuffer
  */
 public static int compare(Object object, StringBuffer stringBuffer)
  {
   String string = object.toString();
   int len1 = string.length();
   int len2 = stringBuffer.length();
   int n = Math.min(len1, len2);
   int i = 0;
   int j = 0;
   while (n-- != 0)
    {
     char c1 = string.charAt(i++);
     char c2 = stringBuffer.charAt(j++);
     c2 = Character.toUpperCase(c2);
     if (c1 != c2)
      {
       return c1 - c2;
      }
    }
   return len1 - len2;
  }

 /**
  * Compare <code>word</code> to <code>stringBuffer</code>.
  * The string value of <code>word</code> is assumed to be uppercase;
  * <code>stringBuffer</code> may be in any case, as it is uppercased before
  * the comparison is made.
  *
  * @return <code>true</code> if the values are equal, or
  *         <code>false</code> if the values are not equal
  */
 public static boolean equals(String word, StringBuffer stringBuffer)
  {
   return word.length() == stringBuffer.length() && compare(word, stringBuffer) == 0;
  }
}