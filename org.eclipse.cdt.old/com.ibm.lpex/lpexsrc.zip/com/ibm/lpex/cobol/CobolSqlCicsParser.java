//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1999, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CobolSqlCicsParser - document parser for COBOL + embedded SQL/CICS.
//----------------------------------------------------------------------------

package com.ibm.lpex.cobol;

import com.ibm.lpex.core.LpexCharStream;
import com.ibm.lpex.core.LpexView;

import com.ibm.lpex.cics.CicsLexer;
import com.ibm.lpex.cics.CicsLexerClasses;
import com.ibm.lpex.cics.CicsLexerStyles;
import com.ibm.lpex.sql.SqlLexer;
import com.ibm.lpex.sql.SqlLexerClasses;
import com.ibm.lpex.sql.SqlLexerStyles;


/**
 * Document parser for COBOL with embedded SQL/CICS statements.
 */
public class CobolSqlCicsParser extends CobolParser
{
 /**
  * Constructor for CobolSqlCicsParser.
  */
 public CobolSqlCicsParser(LpexView lpexView)
 {
  super(lpexView);
 }

 /**
  * Retrieve the SqlLexer.
  * This method constructs and returns an SqlLexer object for parsing
  * COBOL embedded SQL statements.
  */
 public SqlLexer getSqlLexer(LpexCharStream stream)
 {
  return new SqlLexer(stream, getLanguage(),
               new SqlLexerStyles("cehrnlfb"),
               new SqlLexerClasses(view,
                                   _classPreprocessor | _classSql,
                                   _classForwardLink, _classBackwardLink,
                                   _classComment, _classError,
                                   0)); // SQL statement is flagged by COBOL parser
 }

 /**
  * Retrieve the CicsLexer.
  * This method constructs and returns a CicsLexer object for parsing
  * COBOL embedded CICS statements.
  */
 public CicsLexer getCicsLexer(LpexCharStream stream)
 {
  return new CicsLexer(stream, getLanguage(),
               new CicsLexerStyles("cehnlfb"),
               new CicsLexerClasses(view,
                                    _classPreprocessor | _classCics,
                                    _classForwardLink, _classBackwardLink,
                                    _classComment, _classError,
                                    0)); // CICS statement is class-ed by COBOL parser
 }
}