//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1999, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// Cobol400Parser - document parser for COBOL/400.
//----------------------------------------------------------------------------

package com.ibm.lpex.cobol;

import com.ibm.lpex.core.LpexView;


/**
 * Document parser for COBOL/400.
 */
public class Cobol400Parser extends CobolParser
{
 // maximum token sizes
 private final static int MAX_NONNUMERIC_LIT         = 160;
 private final static int MAX_NONNUMERIC_HEX_LIT     = 320;
 private final static int MAX_NONNUMERIC_BOOLEAN_LIT = 1;

 private final static String NONNUMERIC_LITERAL_TYPES = "BX";

 /**
  * "PROCESS" has been detected.
  * The parser will now look for a reserved word that is not
  * a PROCESS statement option or a period separator.
  */
 protected final static int PARSE_MODE_PROCESS = PARSE_MODE_LAST + 1;


 /**
  * Constructor for the parser.
  * @param lpexView the LPEX document view associated with this parser
  */
 public Cobol400Parser(LpexView lpexView)
  {
   super(lpexView);
  }

 /**
  * Return the directive word indicated by the current directive token
  * (_directiveTokenText).
  */
 protected CobolWords.Word findDirective()
  {
   return Cobol400Words.findDirective(_directiveTokenText);
  }

 /**
  * Return true if the current line is a directive line.
  */
 protected boolean isDirectiveLine()
  {
   return super.isDirectiveLine() && _directiveStartBytePosition > 6;
  }

 /**
  * Parse the current token.
  */
 protected void parseToken()
  {
   switch (_parseMode)
    {
     case PARSE_MODE_PROCESS:
      {
       parseProcessToken();
       break;
      }
     default:
      {
       super.parseToken();
       break;
      }
    }
  }

 /**
  * Return true if the current token is a reserved word.
  */
 protected boolean isReservedWord()
  {
   _reservedWord = Cobol400Words.findReservedWord(_tokenText);
   return _reservedWord != null;
  }

 /**
  * Parse the current reserved word.
  */
 protected void parseReservedWord()
  {
   if (_reservedWord.id() == Cobol400Words.PROCESS)
    {
     _multiTokenStartElement = _firstTokenFragment._element;
     _parseMode = PARSE_MODE_PROCESS;
     setToken('d', _classDirective);
    }
   else
    {
     super.parseReservedWord();
    }
  }

 /**
  * Return true if the current token is a user defined word.
  */
 protected boolean isUserDefinedWord()
  {
   return super.isUserDefinedWord() && !_dbcsUserDefinedWord;
  }

 /**
  * Return a string indicating valid nonnumeric literal types.
  */
 protected String nonnumericLiteralTypes()
  {
   return NONNUMERIC_LITERAL_TYPES;
  }

 /**
  * Parse the current nonnumeric literal.
  */
 protected void parseNonnumericLiteral()
  {
   String error = null;
   if (!_nonnumericLiteralHasClosingDelimiter)
    {
     error = "delimiterNotFound";
    }
   else if (_nonnumericLiteralLength == 0)
    {
     error = "emptyLiteral";
    }
   else if (((_nonnumericLiteralType == '\'' || _nonnumericLiteralType == '"') &&
             _nonnumericLiteralLength > MAX_NONNUMERIC_LIT) ||
            (_nonnumericLiteralType == 'X' &&
             _nonnumericLiteralLength > MAX_NONNUMERIC_HEX_LIT) ||
            (_nonnumericLiteralType == 'B' &&
             _nonnumericLiteralLength > MAX_NONNUMERIC_BOOLEAN_LIT))
    {
     error = "tokenTooBig";
    }
   else if (_nonnumericLiteralType == 'B' && _nonnumericLiteralHasNonbinary)
    {
     error = "invalidBooleanLiteral";
    }
   else if (_nonnumericLiteralType == 'X' && _nonnumericLiteralHasNonhexadecimal)
    {
     error = "invalidHexadecimalLiteral";
    }
   else if (_nonnumericLiteralType == 'X' && _nonnumericLiteralLength % 2 != 0)
    {
     error = "oddHexadecimalLiteral";
    }
   else if (_nonnumericLiteralHasDBCS && _firstTokenFragment != _lastTokenFragment)
    {
     error = "badContinuation";
    }
   if (error != null)
    {
     setToken('e', _classError, error);
    }
   else
    {
     setToken('l');
    }
  }

 /**
  * Return true if the current token is a numeric literal.
  */
 protected boolean isNumericLiteral()
  {
   return super.isNumericLiteral() && _exponentLength == 0;
  }

 /**
  * Return true if the current token is a process statement option.
  */
 protected boolean isProcessOption()
  {
   return Cobol400Words.isProcessOption(_tokenText);
  }

 /**
  * Parse the current process statement option.
  */
 protected void parseProcessOption()
  {
   setToken('d', _classDirective);
  }

 /**
  * Parse a PROCESS statement token.
  */
 protected void parseProcessToken()
  {
   if (isSeparator())
    {
     parseSeparator();
     if (isPeriod())
      {
       linkElements(_multiTokenStartElement, _lastTokenFragment._element);
       _multiTokenStartElement = -1;
       _parseMode = PARSE_MODE_CODE;
      }
    }
   else if (isProcessOption())
    {
     parseProcessOption();
    }
   else if (isReservedWord())
    {
     linkElements(_multiTokenStartElement, _lastTokenFragment._element);
     _multiTokenStartElement = -1;
     _parseMode = PARSE_MODE_CODE;
     parseReservedWord();
    }
   else if (isNumericLiteral())
    {
     parseNumericLiteral();
    }
   else if (isUserDefinedWord())
    {
     parseUserDefinedWord();
    }
   else if (isNonnumericLiteral())
    {
     parseNonnumericLiteral();
    }
   else
    {
     parseErrorToken();
    }
  }
}