//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1999, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// ILECobolParser - document parser for ILE Cobol for AS/400.
//----------------------------------------------------------------------------

package com.ibm.lpex.cobol;

import com.ibm.lpex.core.LpexView;


/**
 * Document parser for ILE COBOL/400.
 */
public class ILECobolParser extends CobolParser
{
 // maximum token sizes
 private final static int MAX_DIGITS                 = 31;
 private final static int MAX_EXPONENT               = 3;
 private final static int MAX_PICTURE                = 50;
 private final static int MAX_NONNUMERIC_LIT         = 256;
 private final static int MAX_NONNUMERIC_HEX_LIT     = 512;
 private final static int MAX_NONNUMERIC_BOOLEAN_LIT = 1;
 private final static int MAX_NONNUMERIC_DBCS_LIT    = 58;

 private final static String NONNUMERIC_LITERAL_TYPES = "BGNX";

 /**
  * "PROCESS" has been detected.  The parser will now look for
  * a reserved word that is not a PROCESS statement option or a
  * period separator.
  */
 protected final static int PARSE_MODE_PROCESS = PARSE_MODE_LAST + 1;

 /**
  * Constructor for the parser.
  * @param lpexView the LPEX document view associated with this parser
  */
 public ILECobolParser(LpexView lpexView)
  {
   super(lpexView);
  }

 /**
  * Return the directive word indicated by the current directive token
  * (_directiveTokenText).
  */
 protected CobolWords.Word findDirective()
  {
   return ILECobolWords.findDirective(_directiveTokenText);
  }

 /**
  * Return true if the current line is a directive line.
  */
 protected boolean isDirectiveLine()
  {
   return super.isDirectiveLine() && _directiveStartBytePosition > 6;
  }

 /**
  * Parse the current token.
  */
 protected void parseToken()
  {
   switch (_parseMode)
    {
     case PARSE_MODE_PROCESS:
      {
       parseProcessToken();
       break;
      }
     default:
      {
       super.parseToken();
       break;
      }
    }
  }

 /**
  * Return true if the current token is a reserved word.
  */
 protected boolean isReservedWord()
  {
   _reservedWord = ILECobolWords.findReservedWord(_tokenText);
   return _reservedWord != null;
  }

 /**
  * Parse the current reserved word.
  */
 protected void parseReservedWord()
  {
   if (_reservedWord.id() == ILECobolWords.PROCESS)
    {
     _multiTokenStartElement = _firstTokenFragment._element;
     _parseMode = PARSE_MODE_PROCESS;
     setToken('d', _classDirective);
    }
   else
    {
     super.parseReservedWord();
    }
  }

 /**
  * Return true if the current token is a user-defined word.
  */
 protected boolean isUserDefinedWord()
  {
   _dbcsUserDefinedWord = false;
   for (int i = 0; i < _tokenText.length(); i++)
    {
     char c = _tokenText.charAt(i);
     if (!((c >= 'a' && c <= 'z') ||
           (c >= 'A' && c <= 'Z') ||
           (c >= '0' && c <= '9') ||
           ((c == '-' || c == '_') && i != 0 && i != _tokenText.length() - 1)))
      {
       return false;
      }
    }
   return true;
  }

 /**
  * Return a string indicating valid nonnumeric literal types.
  */
 protected String nonnumericLiteralTypes()
  {
   return NONNUMERIC_LITERAL_TYPES;
  }

 /**
  * Parse the current nonnumeric literal.
  */
 protected void parseNonnumericLiteral()
  {
   String error = null;
   if (!_nonnumericLiteralHasClosingDelimiter)
    {
     error = "delimiterNotFound";
    }
   else if (_nonnumericLiteralLength == 0)
    {
     error = "emptyLiteral";
    }
   else if (((_nonnumericLiteralType == '\'' || _nonnumericLiteralType == '"') &&
             _nonnumericLiteralLength > MAX_NONNUMERIC_LIT) ||
            (_nonnumericLiteralType == 'X' &&
             _nonnumericLiteralLength > MAX_NONNUMERIC_HEX_LIT) ||
            (_nonnumericLiteralType == 'B' &&
             _nonnumericLiteralLength > MAX_NONNUMERIC_BOOLEAN_LIT) ||
            ((_nonnumericLiteralType == 'G' || _nonnumericLiteralType == 'N') &&
             _nonnumericLiteralLength > MAX_NONNUMERIC_DBCS_LIT))
    {
     error = "tokenTooBig";
    }
   else if (_nonnumericLiteralType == 'B' && _nonnumericLiteralHasNonbinary)
    {
     error = "invalidBooleanLiteral";
    }
   else if (_nonnumericLiteralType == 'X' && _nonnumericLiteralHasNonhexadecimal)
    {
     error = "invalidHexadecimalLiteral";
    }
   else if (_nonnumericLiteralType == 'X' && _nonnumericLiteralLength % 2 != 0)
    {
     error = "oddHexadecimalLiteral";
    }
   else if ((_nonnumericLiteralType == 'G' || _nonnumericLiteralType == 'N') &&
            _nonnumericLiteralHasSBCS)
    {
     error = "invalidDBCSLiteral";
    }
   else if ((_nonnumericLiteralType == 'G' || _nonnumericLiteralType == 'N') &&
            _firstTokenFragment != _lastTokenFragment)
    {
     error = "badContinuation";
    }
   if (error != null)
    {
     setToken('e', _classError, error);
    }
   else
    {
     setToken('l');
    }
  }

 /**
  * Return the maximum number of digits allowed in a nonnumeric literal.
  */
 protected int maxDigits()
  {
   return MAX_DIGITS;
  }

 /**
  * Return the maximum number of digits allowed in the exponent of a floating-point literal.
  */
 protected int maxExponent()
  {
   return MAX_EXPONENT;
  }

 /**
  * Return the maximum number of characters allowed in the picture string.
  */
 protected int maxPicture()
  {
   return MAX_PICTURE;
  }

 /**
  * Return true if the current token is a function name.
  */
 protected boolean isFunctionName()
  {
   return ILECobolWords.isFunctionName(_tokenText);
  }

 /**
  * Return true if the current token is a process statement option.
  */
 protected boolean isProcessOption()
  {
   return ILECobolWords.isProcessOption(_tokenText);
  }

 /**
  * Parse the current process statement option.
  */
 protected void parseProcessOption()
  {
   setToken('d', _classDirective);
  }

 /**
  * Parse a PROCESS statement token.
  */
 protected void parseProcessToken()
  {
   if (isSeparator())
    {
     parseSeparator();
     if (isPeriod())
      {
       linkElements(_multiTokenStartElement, _lastTokenFragment._element);
       _multiTokenStartElement = -1;
       _parseMode = PARSE_MODE_CODE;
      }
    }
   else if (isProcessOption())
    {
     parseProcessOption();
    }
   else if (isReservedWord())
    {
     linkElements(_multiTokenStartElement, _lastTokenFragment._element);
     _multiTokenStartElement = -1;
     _parseMode = PARSE_MODE_CODE;
     parseReservedWord();
    }
   else if (isNumericLiteral())
    {
     parseNumericLiteral();
    }
   else if (isUserDefinedWord())
    {
     parseUserDefinedWord();
    }
   else if (isNonnumericLiteral())
    {
     parseNonnumericLiteral();
    }
   else
    {
     parseErrorToken();
    }
  }
}