//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 1999, 2001
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// CobolParser - COBOL document parser.
//----------------------------------------------------------------------------

package com.ibm.lpex.cobol;

import java.util.Properties;
import java.util.ResourceBundle;

import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCharStream;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexDocumentLocation;
import com.ibm.lpex.core.LpexNls;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexResources;
import com.ibm.lpex.core.LpexView;

import com.ibm.lpex.cc.TokenMgrError;
import com.ibm.lpex.cics.CicsLexer;
import com.ibm.lpex.sql.SqlLexer;


/**
 * Document parser for COBOL.
 *
 * <p>Actions added by this tokenizer:
 * <b>comments, divisions, areaA, preprocessor</b> for selective views of the
 * document: comments, divisions, a logical outline, embedded SQL/CICS.
 */
public class CobolParser extends LpexCommonParser
 {
  // whether the help index has been loaded, and the index .properties file
  private static boolean _propertiesLoaded;
  private static Properties _helpPages;

  private static ResourceBundle _resource =
   ResourceBundle.getBundle("com.ibm.lpex.cobol.Profile");

  // maximum token sizes
  private final static int
   MAX_USER_WORD           = 30,
   MAX_DBCS_USER_WORD      = 15,
   MAX_SOSI_DBCS_USER_WORD = 14,
   MAX_PICTURE             = 44,  // was 30  @as 8/2000
   MAX_DIGITS              = 31,  // was 18  @as 8/2000
   MAX_MANTISSA            = 16,
   MAX_EXPONENT            = 2,
   MAX_NONNUMERIC_LIT      = 160,
   MAX_NONNUMERIC_Z_LIT    = 159,
   MAX_NONNUMERIC_HEX_LIT  = 320;

  private final static String NONNUMERIC_LITERAL_TYPES = "GNXZ";

  /**
   * Normal parse mode.
   */
  protected final static int PARSE_MODE_CODE                  = 0;

  /**
   * An opening pseudo-text delimiter has been detected.
   * Now the parser is searching for the closing delimiter.
   */
  protected final static int PARSE_MODE_PSEUDO_TEXT           = 1;

  /**
   * Either "PIC" or PICTURE has been detected.
   * Now the parser is looking for either the reserved
   * word "IS" or the picture string.
   */
  protected final static int PARSE_MODE_PICTURE               = 2;

  /**
   * Either "PIC IS" or "PICTURE IS" has been detected.
   * Now the parser is looking for the picture string.
   */
  protected final static int PARSE_MODE_PICTURE_IS            = 3;

  /**
   * One of the identification division optional paragraph
   * reserved words has been detected.
   * Now the parser is looking for the period that should
   * follow that reserved word.
   */
  protected final static int PARSE_MODE_OPTIONAL_ID_PARAGRAPH = 4;

  /**
   * The parser is in the middle of a comment entry in one
   * of the identification divisions optional paragraphs.
   */
  protected final static int PARSE_MODE_COMMENT_ENTRY         = 5;

  /**
   * The reserved word "FUNCTION" has been detected.
   * Now the parser is looking for the token that follows
   * FUNCTION to see if it is a valid function name.
   */
  protected final static int PARSE_MODE_FUNCTION              = 6;

  /**
   * The reserved word "DATE" has been detected.
   * Now the parser is checking to see if the token that
   * follows DATE is the reserved word "FORMAT".
   */
  protected final static int PARSE_MODE_DATE                  = 7;

  /**
   * "DATE FORMAT" has been detected.
   * Now the parser is looking for either the reserved
   * word "IS" or the date format.
   */
  protected final static int PARSE_MODE_DATE_FORMAT           = 8;

  /**
   * "DATE FORMAT IS" has been detected.
   * Now the parser is looking to see if the next token
   * is a valid date format.
   */
  protected final static int PARSE_MODE_DATE_FORMAT_IS        = 9;

  /**
   * The parser has found the word "EXEC".
   * Now it is looking for the word "END-EXEC".
   * If "SQL" or "CICS" is encountered, the appropriate
   * SQL/CICS subparser may be activated.
   */
  protected final static int PARSE_MODE_PREPROCESSOR          = 10;

  /**
   * The last parse mode value used.
   */
  protected final static int PARSE_MODE_LAST                  = 10;

  /**
   * Element class used by this parser.
   */
  public static final String
    CLASS_FWDLINK      = "forwardLink",   // double-links multiline
    CLASS_BWDLINK      = "backwardLink",  //   structures
    CLASS_BLANK        = "blank",         // empty line
    CLASS_ERROR        = "error",         // lexical error
    CLASS_COMMENT      = "comment",       // comment line
    CLASS_DIRECTIVE    = "directive",     // compiler directive
    CLASS_DIVISION     = "division",      // COBOL division
    CLASS_SECTION      = "section",       // COBOL section
    CLASS_AREAA        = "areaA",         // code line starting in area A
    CLASS_AREAB        = "areaB",         // code line starting in area B
    CLASS_PREPROCESSOR = "preprocessor",  // CICS/SQL preprocessor line
    CLASS_CICS         = "cics",          //  - CICS
    CLASS_SQL          = "sql";           //  - SQL

  /**
   * Bitmask for element class used by this parser.
   */
  protected long
    _classForwardLink,
    _classBackwardLink,
    _classBlank,
    _classError,
    _classComment,
    _classDirective,
    _classDivision,
    _classSection,
    _classAreaA,
    _classAreaB,
    _classPreprocessor,
    _classCics,
    _classSql,
    _classAll;

  // a local copy of the view's LpexNls object
  private LpexNls _nls;

  /**
   * The first element in the current parse range.
   */
  protected int _startElement;

  /**
   * The last element in the current parse range.
   */
  protected int _endElement;

  /**
   * The current element being parsed.
   */
  protected int _currentElement;

  /**
   * The current byte position of the current character (ZERO-based).
   */
  protected int _currentBytePosition;

  /**
   * The current character position of the current character (ZERO-based).
   */
  protected int _currentCharacterPosition;

  /**
   * The width of the previous character.
   */
  protected int _previousCharacterWidth;

  /**
   * Indicates that the current line has bee parsed to the end.
   */
  protected boolean _currentElementCompleted;

  /**
   * A reference to the first ParseElement in a list
   * of active ParseElements.
   */
  protected ParseElement _parseElements;

  /**
   * A reference to the first ParseElement in a list of unused
   * ParseElements.
   */
  protected ParseElement _freeParseElements;

  /**
   * The element number of the saved character.
   */
  protected int _saveTokenCharacterElement;

  /**
   * The byte position of the saved character.
   */
  protected int _saveTokenCharacterBytePosition;

  /**
   * The character position of the saved character.
   */
  protected int _saveTokenCharacterPosition;

  /**
   * The saved character.
   */
  protected char _saveTokenCharacter;

  /**
   * Indicates that the saved character is valid.
   */
  protected boolean _saveTokenCharacterValid;

  /**
   * The current directive token.
   */
  protected StringBuffer _directiveTokenText = new StringBuffer(32);

  /**
   * The byte position of the start of the directive token.
   */
  protected int _directiveTokenStartBytePosition;

  /**
   * The character position of the start of the directive token.
   */
  protected int _directiveStartBytePosition;

  /**
   * Indicates that the current directive is in error.
   */
  protected boolean _directiveError;

  /**
   * The current parse mode.
   */
  protected int _parseMode;

  /**
   * A reference to the first token fragment of a multiline token.
   */
  protected TokenFragment _firstTokenFragment;

  /**
   * A reference to the last token fragment of a multiline token.
   */
  protected TokenFragment _lastTokenFragment;

  /**
   * The current token.
   */
  protected StringBuffer _tokenText = new StringBuffer(32);

  /**
   * Indicates that the current token character is within a
   * nonnumeric literal.
   */
  protected boolean _inNonnumericLiteral;

  /**
   * Indicates that the current token has at least quote or
   * apostrophe.
   */
  protected boolean _tokenHasDelimiter;

  /**
   * If the current token is a reserved word then this
   * contains a reference to that word.
   */
  protected CobolWords.Word _reservedWord;

  /**
   * If the current token is a numeric literal then
   * this indicates the number of digits before the decimal.
   */
  protected int _integerLength;

  /**
   * If the current token is a numeric literal then
   * this indicates the number of digits after the decimal.
   */
  protected int _decimalLength;

  /**
   * If the current token is a numeric literal then
   * this indicates the number of digits in the exponent.
   */
  protected int _exponentLength;


  /**
   * If the current token is a user defined word then
   * this indicates if it is a DBCS user defined word.
   */
  protected boolean _dbcsUserDefinedWord;

  /**
   * If the current token is a nonnumeric literal then
   * this indicates the type.
   */
  protected char _nonnumericLiteralType;

  /**
   * If the current token is a nonnumeric literal then
   * this indicates the delimiter.
   */
  protected char _nonnumericLiteralDelimiter;

  /**
   * If the current token is a nonnumeric literal then
   * this indicates the length.
   */
  protected int _nonnumericLiteralLength;

  /**
   * If the current token is a nonnumeric literal then
   * this indicates if the closing delimiter was found.
   */
  protected boolean _nonnumericLiteralHasClosingDelimiter;

  /**
   * If the current token is a nonnumeric literal then
   * this indicates if a non hexadecimal character was found.
   */
  protected boolean _nonnumericLiteralHasNonhexadecimal;

  /**
   * If the current token is a nonnumeric literal then
   * this indicates if a non binary (0 or 1) character was found.
   */
  protected boolean _nonnumericLiteralHasNonbinary;

  /**
   * If the current token is a nonnumeric literal then
   * this indicates if a DBCS character was found.
   */
  protected boolean _nonnumericLiteralHasDBCS;

  /**
   * If the current token is a nonnumeric literal then
   * this indicates if a SBCS character was found.
   */
  protected boolean _nonnumericLiteralHasSBCS;

  /**
   * This contains the starting element of a group of tokens
   * that must be parsed together.
   */
  protected int _multiTokenStartElement;

  // lexers we (may) use
  private static final int
   LEXER_COBOL = 0,
   LEXER_SQL   = 1,
   LEXER_CICS  = 2;

  private SqlLexer sqlLexer;
  private CicsLexer cicsLexer;
  private int _activeLexer = LEXER_COBOL;   // always starting in COBOL parsing
  private LpexCharStream _stream;           // the lexers work on a char stream


  /**
   * Constructor for the parser.
   * Add all of the parser specifics to the associated LPEX document view.
   * Initializes the LpexView for the parser:  it sets up all the style
   * attributes, element classes, etc. for the language-sensitive edit features
   * supported.
   *
   * @param lpexView the LPEX document view associated with this parser
   */
  public CobolParser(LpexView lpexView)
   {
    super(lpexView);        // LpexCommonParser constructor (view := lpexView)
    initializeParser();     // initialize LpexView with our stuff
   }

  /**
   * Total parse of the entire document.
   */
  public void parseAll()
   {
    _startElement = 1;
    _endElement = view.elements();
    if (_endElement == 0)
     {
      return;
     }

    parse();
   }

  /**
   * Incremental parse.
   * @param element the element whose committed change triggered the parse,
   *                or the element that precedes / follows a deleted block.
   *                The parser may identify other neighbouring elements that
   *                will have to be reparsed as a unit
   */
  public void parseElement(int element)
   {
    if (view.elements() == 0)
     {
      return;
     }

    _startElement = evaluateBeginElement(element);
    _endElement = evaluateEndElement(element);
    removeMessages(_startElement, _endElement);
    parse();

    // clear all elements that we've actually parsed from the pending list
    for (int i = _startElement; i <= _endElement; i++)
     {
      view.elementParsed(i);
     }
   }

  /**
   * Perform the parse.
   * This routine assumes that _startElement and _endElement have been set.
   */
  protected void parse()
   {
    int elements = view.elements();
    _parseMode = PARSE_MODE_CODE;
    _multiTokenStartElement = -1;
    _saveTokenCharacterValid = false;
    _tokenText.setLength(0);
    _currentElement = _startElement - 1;

    if (nextTokenElement())  // advance _currentElement inside the parse range
     {
      while (getToken())     // while tokens available...
       {
        parseToken();

        // if a CICS/SQL lexer was just activated, process
        // the entire preprocessor construct with it
        if (_activeLexer != LEXER_COBOL)
         {
          parsePreprocessor();
         }

        // if done with the element at the end of the currently-established
        // parse range, but must continue parsing (middle of construct) and
        // there are more elements in the document:
        if (_currentElement == _endElement &&
            _currentElementCompleted &&
            continueParse() &&
            _endElement < view.elements())
         {
          // extend the parse range and continue parsing...
          _endElement = evaluateEndElement(_endElement + 1);
          removeMessages(_currentElement, _endElement);
          nextTokenElement();
         }
       }//end "while getToken()"
     }

    // parsing ended - any multiline construct handled lately?
    if (_multiTokenStartElement != -1)
     {
      linkElements(_multiTokenStartElement, _endElement);
     }

    // flush all cached ParseElements
    while (_parseElements != null)
     {
      _parseElements.flush();
     }
   }

  /**
   * Reinitialize the current element for parsing.
   * When a preprocessor lexer completes an "EXEC" .. "END-EXEC" construct,
   * this method is called to get regular COBOL parsing going again.
   */
  protected void reInitCurrentElement(int currentCharacterPosition)
   {
    _saveTokenCharacterValid = false;
    flushElements(); // garbage-collect to make room in _freeParseElements
    ParseElement parseElement;
    if (_freeParseElements == null)
     {
      parseElement = new ParseElement();
     }
    else
     {
      parseElement = _freeParseElements;
     }
    parseElement.init(_currentElement);

    _previousCharacterWidth = 1;
    _currentElementCompleted = false;

    String originalStyle = view.elementStyle(_currentElement);
    _currentCharacterPosition = currentCharacterPosition;
    // if EOF in a token before "END-EXEC", we may have skipped one char ahead
    if (_currentCharacterPosition > originalStyle.length())
     {
      _currentCharacterPosition = originalStyle.length();
     }
    _currentBytePosition = _nls.encodingCharIndex(view.elementText(_currentElement),
                                                  _currentCharacterPosition,
                                                  _nls.getSourceEncoding());

    // set up styles & classes set by the SQL/CICS lexer so far
    for (int i = 0;
         i < _currentCharacterPosition && i < parseElement._style.length();
         i++)
     {
      parseElement._style.setCharAt(i, originalStyle.charAt(i));
     }
    parseElement._classes = view.elementClasses(_currentElement);

    if (_currentBytePosition >= 72 ||
        _currentCharacterPosition >= parseElement._text.length())
     {
      completeCurrentElement();
      nextTokenElement();
     }
   }

  /**
   * Initialize the current element for parsing.
   * It is cached into a ParseElement, and everything up to the first token
   * character is parsed.
   */
  protected void initCurrentElement()
   {
    flushElements(); // garbage-collect to make room in _freeParseElements
    ParseElement parseElement;
    if (_freeParseElements == null)
     {
      parseElement = new ParseElement();
     }
    else
     {
      parseElement = _freeParseElements;
     }
    parseElement.init(_currentElement);

    _currentCharacterPosition = 0;
    _currentBytePosition = 0;
    _previousCharacterWidth = 1;
    _currentElementCompleted = false;
    String text = parseElement._text;
    StringBuffer style = parseElement._style;

    if (isDirectiveLine())
     {
      parseDirectiveLine();
      return;
     }

    boolean blankSequenceNumber = true;
    while (_currentBytePosition < 6 && _currentCharacterPosition < text.length())
     {
      if (text.charAt(_currentCharacterPosition) != ' ')
       {
        blankSequenceNumber = false;
       }
      style.setCharAt(_currentCharacterPosition, 's');
      nextCharacter();
     }

    int indicatorCharacterPosition = _currentCharacterPosition;
    if (_currentBytePosition == 7)
     {
      addErrorMessage(_currentElement, "invalidIndicator",
                      String.valueOf(text.charAt(_currentCharacterPosition - 1)));
      parseElement._classes |= _classError;
      style.setCharAt(_currentCharacterPosition - 1, 'e');
     }
    else if (_currentCharacterPosition < text.length())
     {
      if (!blankSequenceNumber && isDirectiveLine())
       {
        parseDirectiveLine();
        return;
       }
      char c = text.charAt(_currentCharacterPosition);
      switch (c)
       {
        case '*':
        case '/':
         {
          style.setCharAt(_currentCharacterPosition, 'i');
          parseElement._classes |= _classComment;
          nextCharacter();
          while (_currentBytePosition < 72 && _currentCharacterPosition < text.length())
           {
            style.setCharAt(_currentCharacterPosition, 'c');
            nextCharacter();
           }
          return;
         }
        case '-':
         {
          style.setCharAt(_currentCharacterPosition, 'i');
          parseElement._continuationLine = true;
          parseElement._classes |= _classBackwardLink;
          break;
         }
        case 'D':
        case 'd':
        case ' ':
         {
          style.setCharAt(_currentCharacterPosition, 'i');
          break;
         }
        default:
         {
          style.setCharAt(_currentCharacterPosition, 'e');
          addErrorMessage(_currentElement, "invalidIndicator", String.valueOf(c));
          parseElement._classes |= _classError;
          break;
         }
       }//end "switch"
      nextCharacter();
     }

    boolean blankLine = true;
    while (_currentBytePosition < 72 && _currentCharacterPosition < text.length())
     {
      char c = text.charAt(_currentCharacterPosition);
      if (c != ' ')
       {
        blankLine = false;
        break;
       }
      style.setCharAt(_currentCharacterPosition, '_');
      nextCharacter();
     }
    if (blankLine)
     {
      parseElement._classes |= _classBlank;
      if (parseElement._continuationLine && _tokenText.length() != 0)
       {
        addErrorMessage(_currentElement, "blankContinuation");
        parseElement._classes |= _classError;
        parseElement._style.setCharAt(indicatorCharacterPosition, 'e');
       }
     }
    else
     {
      if (_currentBytePosition < 11)
       {
        parseElement._classes |= _classAreaA;
        if (parseElement._continuationLine)
         {
          addErrorMessage(_currentElement, "areaAContinuation");
          parseElement._classes |= _classError;
          for (int i = indicatorCharacterPosition; i < _currentCharacterPosition; i++)
           {
            parseElement._style.setCharAt(i, 'e');
           }
         }
       }
      else
       {
        parseElement._classes |= _classAreaB;
       }
     }
   }

  /**
   * Return directive word indicated by the current directive token.
   */
  protected CobolWords.Word findDirective()
   {
    return CobolWords.findDirective(_directiveTokenText);
   }

  /**
   * Return true if the current line is a directive line.
   */
  protected boolean isDirectiveLine()
   {
    int saveCurrentBytePosition = _currentBytePosition;
    int saveCurrentCharacterPosition = _currentCharacterPosition;
    boolean isDirectiveLine = false;
    _directiveError = false;

    if (getDirectiveToken())
     {
      CobolWords.Word directive = findDirective();
      if (directive != null &&
          (directive.id() == CobolWords.CBL ||
          (_directiveTokenStartBytePosition >= 6 && directive.id() == CobolWords.CONTROL) ||
          (_directiveTokenStartBytePosition > 6)))
       {
        isDirectiveLine = true;
        _directiveStartBytePosition = _directiveTokenStartBytePosition;
        switch (directive.id())
         {
          case CobolWords.CONTROL:
           {
            while (getDirectiveToken())
             {
              if (_directiveTokenText.length() == 1 && _directiveTokenText.charAt(0) == '.')
               {
                break;
               }
              if (!CobolWords.isControlOption(_directiveTokenText))
               {
                _directiveError = true;
                break;
               }
             }
            if (!_directiveError && getDirectiveToken())
             {
              _directiveError = true;
             }
            break;
           }
          case CobolWords.EJECT:
          case CobolWords.SKIP:
           {
            if (getDirectiveToken())
             {
              if (_directiveTokenText.length() != 1 ||
                  _directiveTokenText.charAt(0) != '.' ||
                  getDirectiveToken())
               {
                _directiveError = true;
               }
             }
            break;
           }
          case CobolWords.TITLE:
           {
            if (getDirectiveToken())
             {
              char delimiter = _directiveTokenText.charAt(0);
              if (delimiter != '"' && delimiter != '\'')
               {
                _directiveError = true;
               }
              else
               {
                boolean closingDelimiter = false;
                for (int i = 1; i < _directiveTokenText.length(); i++)
                 {
                  if (_directiveTokenText.charAt(i) == delimiter)
                   {
                    if (i + 1 == _directiveTokenText.length())
                     {
                      closingDelimiter = true;
                      break;
                     }
                    i++;
                    if (_directiveTokenText.charAt(i) != delimiter)
                     {
                      _directiveError = true;
                      break;
                     }
                   }
                 }
                if (!closingDelimiter)
                 {
                  _directiveError = true;
                 }
                if (!_directiveError && getDirectiveToken())
                 {
                  if (_directiveTokenText.length() != 1    ||
                      _directiveTokenText.charAt(0) != '.' ||
                      getDirectiveToken())
                   {
                    _directiveError = true;
                   }
                 }
               }
             }
            break;
           }
         }
       }
     }

    _currentBytePosition = saveCurrentBytePosition;
    _currentCharacterPosition = saveCurrentCharacterPosition;
    return isDirectiveLine;
   }

  /**
   * Parse a directive line.
   */
  protected void parseDirectiveLine()
   {
    StringBuffer style = _parseElements._style;
    if (_currentBytePosition == 0 && _directiveStartBytePosition >= 6)
     {
      while (_currentBytePosition < 6)
       {
        style.setCharAt(_currentCharacterPosition, 's');
        nextCharacter();
       }
     }
    if (_currentBytePosition == 6 && _directiveStartBytePosition > 6)
     {
      style.setCharAt(_currentCharacterPosition, 'i');
      nextCharacter();
     }
    int startCharacterPosition = _currentCharacterPosition;
    while (_currentBytePosition < 72 &&
           _currentCharacterPosition < _parseElements._text.length())
     {
      nextCharacter();
     }
    char styleCharacter = 'd';
    if (_directiveError)
     {
      styleCharacter = 'e';
      addErrorMessage(_currentElement, "invalidDirective");
      _parseElements._classes |= _classError;
     }
    for (int i = startCharacterPosition; i < _currentCharacterPosition; i++)
     {
      style.setCharAt(i, styleCharacter);
     }
    _parseElements._classes |= _classDirective;
   }

  /**
   * Get the next directive token.
   * @return <code>true</code> if a directive token (_directiveTokenText)
   *         was found
   */
  protected boolean getDirectiveToken()
   {
    _directiveTokenText.setLength(0);
    while (_currentBytePosition < 72 &&
           _currentCharacterPosition < _parseElements._text.length())
     {
      char c = _parseElements._text.charAt(_currentCharacterPosition);
      if (c != ' ' && c != ',' && c != ';')
       {
        break;
       }
      nextCharacter();
     }

    _directiveTokenStartBytePosition = _currentBytePosition;
    char delimiter = '"';
    boolean inNonnumericLiteral = false;
    while (_currentBytePosition < 72 &&
           _currentCharacterPosition < _parseElements._text.length())
     {
      char c = _parseElements._text.charAt(_currentCharacterPosition);
      if (inNonnumericLiteral)
       {
        _directiveTokenText.append(c);
        if (c == delimiter)
         {
          inNonnumericLiteral = false;
         }
       }
      else
       {
        switch (c)
         {
          case ' ':
          case ',':
          case ';':
           {
            if (_directiveTokenText.length() > 0)
             {
              return true;
             }
            break;
           }
          case '.':
           {
            if (_directiveTokenText.length() == 0)
             {
              _directiveTokenText.append(c);
              nextCharacter();
             }
            return true;
           }
          case '\'':
          case '\"':
           {
            _directiveTokenText.append(c);
            inNonnumericLiteral = true;
            delimiter = c;
            break;
           }
          default:
           {
            _directiveTokenText.append(c);
            break;
           }
         }
       }
      nextCharacter();
     }//end "while"

    return _directiveTokenText.length() > 0;
   }

  /**
   * Complete the parsing of the current line.
   */
  protected void completeCurrentElement()
   {
    if (!_currentElementCompleted)
     {
      ParseElement parseElement = _parseElements;
      String text = parseElement._text;
      StringBuffer style = parseElement._style;

      if (_currentBytePosition == 73)
       {
        addErrorMessage(_currentElement, "invalidItem");
        parseElement._classes |= _classError;
        style.setCharAt(_currentCharacterPosition - 1, 'e');
        nextCharacter();
       }

      while (_currentBytePosition < 80 && _currentCharacterPosition < text.length())
       {
        style.setCharAt(_currentCharacterPosition, 's');
        nextCharacter();
       }

      _currentElementCompleted = true;
     }
   }

  /**
   * Flush any of the cached elements with which we are finished.
   */
  protected void flushElements()
   {
    ParseElement parseElement = _parseElements;
    while (parseElement != null)
     {
      ParseElement next = parseElement._next;
      if (!parseElement.active())
       {
        parseElement.flush();
       }
      parseElement = next;
     }
   }

  /**
   * Find the active ParseElement for the specified element.
   *
   * @return <code>null</code> if there is no ParseElement for the given element
   */
  protected ParseElement findParseElement(int element)
   {
    for (ParseElement parseElement = _parseElements;
         parseElement != null;
         parseElement = parseElement._next)
     {
      if (parseElement._element == element)
       {
        return parseElement;
       }
     }
    return null;
   }

  /**
   * Return <code>true</code> if parsing should be continued (we are currently
   * inside a COBOL construct).
   */
  protected boolean continueParse()
   {
    return _parseMode != PARSE_MODE_CODE;
   }

  /**
   * Get the next token.
   * On exit, the new token is in _tokenText.
   *
   * @return <code>true</code> a token was found
   */
  protected boolean getToken()
   {
    _firstTokenFragment._next = null;
    _lastTokenFragment = _firstTokenFragment;
    _tokenHasDelimiter = false;
    _inNonnumericLiteral = false;

    if (_saveTokenCharacterValid)
     {
      _tokenText.setLength(1);
      _tokenText.setCharAt(0, _saveTokenCharacter);
      _firstTokenFragment._element = _saveTokenCharacterElement;
      _firstTokenFragment._startCharacterPosition = _saveTokenCharacterPosition;
      _firstTokenFragment._startBytePosition = _saveTokenCharacterBytePosition;
      setTokenEnd();
      return true;
     }

    if (_currentElementCompleted)
     {
      return false;
     }

    _firstTokenFragment._element = _currentElement;
    _firstTokenFragment._startCharacterPosition = _currentCharacterPosition;
    _firstTokenFragment._startBytePosition = _currentBytePosition;
    _tokenText.setLength(0);
    char delimiter = '\"';
    boolean lookAhead = false;
    do
     {
      lookAhead = false;
      char c = _parseElements._text.charAt(_currentCharacterPosition);
      if (_inNonnumericLiteral)
       {
        if (c != delimiter || _lastTokenFragment._element == _currentElement)
         {
          _tokenText.append(c);
          if (c == delimiter)
           {
            _inNonnumericLiteral = false;
           }
         }
        setTokenEnd();
       }
      else
       {
        switch (c)
         {
          case '.':
          case ',':
          case ';':
           {
            if (_tokenText.length() == 0)
             {
              _tokenText.append(c);
              setTokenEnd();
             }
            else
             {
              saveTokenCharacter();
              if (nextTokenCharacter())
               {
                lookAhead = true;
                _tokenText.append(c);
                setTokenEnd();
               }
              else
               {
                return true;
               }
             }
            break;
           }
          case ':':
          case '(':
          case ')':
           {
            if (_parseMode == PARSE_MODE_PICTURE || _parseMode == PARSE_MODE_PICTURE_IS)
             {
              _tokenText.append(c);
              setTokenEnd();
             }
            else
             {
              if (_tokenText.length() == 0)
               {
                _tokenText.append(c);
                setTokenEnd();
                nextTokenCharacter();
               }
              return true;
             }
            break;
           }
          case '"':
          case '\'':
           {
            if (_parseMode == PARSE_MODE_PICTURE || _parseMode == PARSE_MODE_PICTURE_IS)
             {
              _tokenText.append(c);
              setTokenEnd();
             }
            else
             {
              if (_tokenText.length() > 0 && _tokenHasDelimiter &&
                  _lastTokenFragment._element != _currentElement)
               {
                if (_lastTokenFragment._endBytePosition != 71)
                 {
                  return true;
                 }
                _tokenHasDelimiter = true;
                _inNonnumericLiteral = true;
                delimiter = c;
                setTokenEnd();
                if (nextTokenCharacter())
                 {
                  if (_lastTokenFragment._element != _currentElement)
                   {
                    lookAhead = true;
                   }
                  else
                   {
                    _tokenText.append(_parseElements._text.charAt(_currentCharacterPosition));
                    setTokenEnd();
                   }
                 }
                else
                 {
                  return true;
                 }
               }
              else
               {
                _tokenText.append(c);
                _tokenHasDelimiter = true;
                _inNonnumericLiteral = true;
                delimiter = c;
                setTokenEnd();
               }
             }
            break;
           }
          case '=':
           {
            if (_parseMode == PARSE_MODE_PICTURE || _parseMode == PARSE_MODE_PICTURE_IS)
             {
              _tokenText.append(c);
              setTokenEnd();
             }
            else if (_parseMode == PARSE_MODE_PSEUDO_TEXT)
             {
              if (_tokenText.length() > 0 &&
                  (_tokenText.length() != 1 || _tokenText.charAt(0) != '='))
               {
                return true;
               }
              _tokenText.append(c);
              setTokenEnd();
             }
            else
             {
              _tokenText.append(c);
              setTokenEnd();
              if (_tokenText.length() == 2 && _tokenText.charAt(0) == '=')
               {
                nextTokenCharacter();
                return true;
               }
             }
            break;
           }
          default:
           {
            _tokenText.append(c);
            setTokenEnd();
            break;
           }
         }
       }
     } while (lookAhead || nextTokenCharacter());

    return _tokenText.length() > 0;
   }

  /**
   * Set the (saved) current character as the end of the current token.
   */
  protected void setTokenEnd()
   {
    if (_saveTokenCharacterValid)
     {
      if (_lastTokenFragment._element != _saveTokenCharacterElement)
       {
        new TokenFragment();
        _lastTokenFragment._element = _saveTokenCharacterElement;
        _lastTokenFragment._startCharacterPosition = _saveTokenCharacterPosition;
        _lastTokenFragment._startBytePosition = _saveTokenCharacterBytePosition;
       }
      _lastTokenFragment._endCharacterPosition = _saveTokenCharacterPosition;
      _lastTokenFragment._endBytePosition = _saveTokenCharacterBytePosition;
      _saveTokenCharacterValid = false;
     }
    else
     {
      if (_lastTokenFragment._element != _currentElement)
       {
        new TokenFragment();
        _lastTokenFragment._element = _currentElement;
        _lastTokenFragment._startCharacterPosition = _currentCharacterPosition;
        _lastTokenFragment._startBytePosition = _currentBytePosition;
       }
      _lastTokenFragment._endCharacterPosition = _currentCharacterPosition;
      _lastTokenFragment._endBytePosition = _currentBytePosition;
     }
   }

  /**
   * Advance to the next token character.
   *
   * @return <code>true</code> if the next token character is contiguous to the
   *                           current token character
   */
  protected boolean nextTokenCharacter()
   {
    boolean spaceFound = false;
    for (;;)
     {
      nextCharacter(); // advance to next char in current element

      if (_currentBytePosition >= 72 ||
          _currentCharacterPosition >= _parseElements._text.length())
       {
        if (_inNonnumericLiteral)
         {
          for (int i = _currentBytePosition; i < 72; i++)
           {
            _tokenText.append(' ');
           }
         }
        completeCurrentElement();
        if (!nextTokenElement())
         {
          return false;
         }
        return _parseElements._continuationLine;
       }

      else
       {
        if (_inNonnumericLiteral)
         {
          return true;
         }
        char c = _parseElements._text.charAt(_currentCharacterPosition);
        if (c == ' ')
         {
          _parseElements._style.setCharAt(_currentCharacterPosition, '_');
          spaceFound = true;
         }
        else
         {
          return !spaceFound;
         }
       }
     }
   }

  /**
   * Advance to the next token (non-show) element in the parse range.
   * _currentElement is updated.
   *
   * @return <code>true</code> if another token element was found, or
   *         <code>false</code> if no more token elements are found within the
   *                            current parse range
   */
  protected boolean nextTokenElement()
   {
    while (_currentElement < _endElement)
     {
      _currentElement++;
      if (!view.show(_currentElement))
       {
        initCurrentElement();
        if (_currentBytePosition < 72 &&
            _currentCharacterPosition < _parseElements._text.length())
         {
          return true;
         }
        completeCurrentElement();
       }
     }

    return false;
   }

  /**
   * Advance to the next character in the current element.
   */
  protected void nextCharacter()
   {
    int characterWidth = 1;
    if (_currentCharacterPosition < _parseElements._text.length())
     {
      characterWidth = _nls.sourceLength(_parseElements._text.charAt(_currentCharacterPosition));
     }

    _currentBytePosition += characterWidth;
    _currentCharacterPosition++;
    if (characterWidth == 2 && _nls.isSourceSosi())
     {
      if (_previousCharacterWidth == 1)
       {
        _currentBytePosition++;
       }
      int nextCharacterWidth = 1;
      if (_currentCharacterPosition < _parseElements._text.length())
       {
        nextCharacterWidth =
           _nls.sourceLength(_parseElements._text.charAt(_currentCharacterPosition));
       }
      if (nextCharacterWidth == 1)
       {
        _currentBytePosition++;
       }
     }

    _previousCharacterWidth = characterWidth;
   }

  /**
   * Save the current token character.
   */
  protected void saveTokenCharacter()
   {
    _saveTokenCharacterElement = _currentElement;
    _saveTokenCharacterPosition = _currentCharacterPosition;
    _saveTokenCharacterBytePosition = _currentBytePosition;
    _saveTokenCharacter = _parseElements._text.charAt(_currentCharacterPosition);
    _saveTokenCharacterValid = true;
   }

  /**
   * Parse the current token.  Calls the appropriate parseXxxToken() method
   * based on the current parse mode.
   */
  protected void parseToken()
   {
    switch (_parseMode)
     {
      case PARSE_MODE_CODE:
       {
        parseCodeToken();
        break;
       }
      case PARSE_MODE_PSEUDO_TEXT:
       {
        parsePseudoTextToken();
        break;
       }
      case PARSE_MODE_PICTURE:
       {
        parsePictureToken();
        break;
       }
      case PARSE_MODE_PICTURE_IS:
       {
        parsePictureIsToken();
        break;
       }
      case PARSE_MODE_OPTIONAL_ID_PARAGRAPH:
       {
        parseOptionalIdParagraphToken();
        break;
       }
      case PARSE_MODE_COMMENT_ENTRY:
       {
        parseCommentEntryToken();
        break;
       }
      case PARSE_MODE_FUNCTION:
       {
        parseFunctionToken();
        break;
       }
      case PARSE_MODE_DATE:
       {
        parseDateToken();
        break;
       }
      case PARSE_MODE_DATE_FORMAT:
       {
        parseDateFormatToken();
        break;
       }
      case PARSE_MODE_DATE_FORMAT_IS:
       {
        parseDateFormatIsToken();
        break;
       }
      case PARSE_MODE_PREPROCESSOR: // inside an "EXEC" .. "END-EXEC" construct
       {
        parsePreprocessorToken();
        break;
       }
     }
   }

  /**
   * Parse the current code token.
   */
  protected void parseCodeToken()
   {
    if (isSeparator())
     {
      parseSeparator();
     }
    else if (isReservedWord())
     {
      parseReservedWord();
     }
    else if (isNumericLiteral())
     {
      parseNumericLiteral();
     }
    else if (isPreprocessorStart()) // is current token "EXEC"?
     {
      parsePreprocessorStart();     //  sets parse mode to PREPROCESSOR
     }
    else if (isUserDefinedWord())
     {
      parseUserDefinedWord();
     }
    else if (isNonnumericLiteral())
     {
      parseNonnumericLiteral();
     }
    else if (isPseudoTextStart())
     {
      parsePseudoTextStart();
     }
    else
     {
      parseErrorToken();
     }
   }

  /**
   * Return <code>true</code> if the current token is a separator.
   */
  protected boolean isSeparator()
   {
    if (_tokenText.length() == 1)
     {
      char c = _tokenText.charAt(0);
      return c == '.' || c == ';' || c == ',' || c == ':' || c == '(' || c == ')';
     }
    return false;
   }

  /**
   * Return <code>true</code> if the current token is a comma or semicolon.
   */
  protected boolean isCommaOrSemicolon()
   {
    if (_tokenText.length() == 1)
     {
      char c = _tokenText.charAt(0);
      return c == ';' || c == ',';
     }
    return false;
   }

  /**
   * Return <code>true</code> if the current token is a period.
   */
  protected boolean isPeriod()
   {
    if (_tokenText.length() == 1)
     {
      char c = _tokenText.charAt(0);
      return c == '.';
     }
    return false;
   }

  /**
   * Parse the current separator token.
   */
  protected void parseSeparator()
   {
    setToken('b');
   }

  /**
   * Return <code>true</code> if the current token is a reserved word.
   */
  protected boolean isReservedWord()
   {
    _reservedWord = CobolWords.findReservedWord(_tokenText);
    return _reservedWord != null;
   }

  /**
   * Parse the current reserved word.
   */
  protected void parseReservedWord()
   {
    long classes = 0;
    int id = _reservedWord.id();
    switch (id)
     {
      case CobolWords.AUTHOR:
      case CobolWords.DATE_COMPILED:
      case CobolWords.DATE_WRITTEN:
      case CobolWords.INSTALLATION:
      case CobolWords.SECURITY:
       {
        _multiTokenStartElement = _firstTokenFragment._element;
        _parseMode = PARSE_MODE_OPTIONAL_ID_PARAGRAPH;
        break;
       }
      case CobolWords.DATE:
       {
        _multiTokenStartElement = _firstTokenFragment._element;
        _parseMode = PARSE_MODE_DATE;
        break;
       }
      case CobolWords.DIVISION:
      case CobolWords.PROGRAM_ID:
       {
        classes = _classDivision;
        break;
       }
      case CobolWords.FUNCTION:
       {
        _multiTokenStartElement = _firstTokenFragment._element;
        _parseMode = PARSE_MODE_FUNCTION;
        break;
       }
      case CobolWords.PICTURE:
       {
        _multiTokenStartElement = _firstTokenFragment._element;
        _parseMode = PARSE_MODE_PICTURE;
        break;
       }
      case CobolWords.SECTION:
       {
        classes = _classSection;
        break;
       }
     }

    setToken('r', classes);
   }

  /**
   * Return <code>true</code> if the current token is a numeric literal.
   */
  protected boolean isNumericLiteral()
   {
    _integerLength = 0;
    _decimalLength = 0;
    _exponentLength = 0;
    if (_tokenText.length() > 0)
     {
      int i = 0;
      char c = _tokenText.charAt(i);
      if (c == '+' || c == '-')
       {
        i++;
        if (i >= _tokenText.length())
         {
          return false;
         }
        c = _tokenText.charAt(i);
       }
      while (c >= '0' && c <= '9')
       {
        _integerLength++;
        i++;
        if (i >= _tokenText.length())
         {
          break;
         }
        c = _tokenText.charAt(i);
       }
      if (i < _tokenText.length() && (c == '.' || c == ','))
       {
        i++;
        if (i >= _tokenText.length())
         {
          return false;
         }
        c = _tokenText.charAt(i);
        while (c >= '0' && c <= '9')
         {
          _decimalLength++;
          i++;
          if (i >= _tokenText.length())
           {
            break;
           }
          c = _tokenText.charAt(i);
         }
        if (i < _tokenText.length() && (c == 'e' || c == 'E'))
         {
          i++;
          if (i >= _tokenText.length())
           {
            return false;
           }
          c = _tokenText.charAt(i);
          if (c == '+' || c == '-')
           {
            i++;
            if (i >= _tokenText.length())
             {
              return false;
             }
            c = _tokenText.charAt(i);
           }
          while (c >= '0' && c <= '9')
           {
            _exponentLength++;
            i++;
            if (i >= _tokenText.length())
             {
              break;
             }
            c = _tokenText.charAt(i);
           }
          return _exponentLength > 0 && i == _tokenText.length();
         }
        return _decimalLength > 0 && i == _tokenText.length();
       }
      return _integerLength > 0 && i == _tokenText.length();
     }
    return false;
   }

  /**
   * Return the maximum number of digits allowed in a nonnumeric literal.
   */
  protected int maxDigits()
   {
    return MAX_DIGITS;
   }

  /**
   * Return the maximum number of digits allowed in the mantissa of a
   * floating-point literal.
   */
  protected int maxMantissa()
   {
    return MAX_MANTISSA;
   }

  /**
   * Return the maximum number of digits allowed in the exponent of a
   * floating-point literal.
   */
  protected int maxExponent()
   {
    return MAX_EXPONENT;
   }

  /**
   * Parse the current numeric literal.
   */
  protected void parseNumericLiteral()
   {
    if (_integerLength + _decimalLength > maxDigits() ||
        (_exponentLength > 0 && _integerLength + _decimalLength > maxMantissa()) ||
        _exponentLength > maxExponent())
     {
      setToken('e', _classError, "tokenTooBig");
     }
    else
     {
      setToken('n');
     }
   }

  /**
   * Return <code>true</code> if the current token is "EXEC".
   */
  protected boolean isPreprocessorStart()
   {
    return CobolWords.equals("EXEC", _tokenText);
   }

  /**
   * Parse the current "EXEC" token.
   * Sets parse mode to PREPROCESSOR.
   */
  protected void parsePreprocessorStart()
   {
    setToken('h', _classPreprocessor);
    _multiTokenStartElement = _firstTokenFragment._element;
    _parseMode = PARSE_MODE_PREPROCESSOR;
   }

  /**
   * Return true if the current token is a user-defined word.
   */
  protected boolean isUserDefinedWord()
   {
    _dbcsUserDefinedWord = false;
    char c = _tokenText.charAt(0);
    if (_nls.sourceLength(c) == 1)
     {
      for (int i = 0; i < _tokenText.length(); i++)
       {
        c = _tokenText.charAt(i);
        if (!((c >= 'a' && c <= 'z') ||
              (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') ||
              (c == '-' && i != 0 && i != _tokenText.length() - 1)))
         {
          return false;
         }
       }
     }
    else
     {
      boolean allFullwidthLatin = true;
      for (int i = 0; i < _tokenText.length(); i++)
       {
        c = _tokenText.charAt(i);
        if (c >= 0xff01 && c <= 0xff6e) // fullwidth Latin character
         {
          if (!((c >= 0xff41 && c <= 0xff5a) || // fullwidth 'a' to 'z'
                (c >= 0xff21 && c <= 0xff3a) || // fullwidth 'A' to 'Z'
                (c >= 0xff10 && c <= 0xff19) || // fullwidth '0' to '9'
                (c == 0xff0d && i != 0 && i != _tokenText.length() - 1))) // fullwidth hyphen
           {
            return false;
           }
         }
        else
         {
          allFullwidthLatin = false;
         }
       }
      if (allFullwidthLatin)
       {
        return false;
       }
      _dbcsUserDefinedWord = true;
     }

    return true;
   }

  /**
   * Parse the current user-defined word.
   */
  protected void parseUserDefinedWord()
   {
    int maxLength = MAX_USER_WORD;
    if (_dbcsUserDefinedWord)
     {
      if (_nls.isSourceSosi())
       {
        maxLength = MAX_SOSI_DBCS_USER_WORD;
       }
      else
       {
        maxLength = MAX_DBCS_USER_WORD;
       }
     }
    if (_tokenText.length() > maxLength)
     {
      setToken('e', _classError, "tokenTooBig");
     }
    else if (_dbcsUserDefinedWord && _firstTokenFragment != _lastTokenFragment)
     {
      setToken('e', _classError, "badContinuation");
     }
    else
     {
      setToken('u');
     }
   }

  /**
   * Return a string indicating valid nonnumeric literal types.
   */
  protected String nonnumericLiteralTypes()
   {
    return NONNUMERIC_LITERAL_TYPES;
   }

  /**
   * Return <code>true</code> if the current token is a nonnumeric literal.
   */
  protected boolean isNonnumericLiteral()
   {
    if (_tokenHasDelimiter && _tokenText.length() > 1)
     {
      int i = 0;
      char c = _tokenText.charAt(i);
      _nonnumericLiteralType = Character.toUpperCase(c);
      if (nonnumericLiteralTypes().indexOf(_nonnumericLiteralType) != -1)
       {
        i++;
        c = _tokenText.charAt(i);
       }
      _nonnumericLiteralDelimiter = c;
      if (c == '\'' || c == '"')
       {
        int previousCharacterWidth = 1;
        _nonnumericLiteralHasNonhexadecimal = false;
        _nonnumericLiteralHasNonbinary = false;
        _nonnumericLiteralHasDBCS = false;
        _nonnumericLiteralHasSBCS = false;
        _nonnumericLiteralHasClosingDelimiter = false;
        _nonnumericLiteralLength = 0;
        i++;
        while (i < _tokenText.length())
         {
          c = _tokenText.charAt(i);
          if (c == _nonnumericLiteralDelimiter)
           {
            i++;
            if (i == _tokenText.length())
             {
              _nonnumericLiteralHasClosingDelimiter = true;
              break;
             }
            c = _tokenText.charAt(i);
            if (c != _nonnumericLiteralDelimiter)
             {
              return false;
             }
           _nonnumericLiteralHasSBCS = false;
           }
          if (!((c >= '0' && c <= '9') ||
                (c >= 'a' && c <= 'f') ||
                (c >= 'A' && c <= 'F')))
           {
            _nonnumericLiteralHasNonhexadecimal = true;
           }
          if (c != '0' && c != '1')
           {
            _nonnumericLiteralHasNonbinary = true;
           }
          int characterWidth = _nls.sourceLength(c);
          _nonnumericLiteralLength += characterWidth;
          i++;
          if (_nls.sourceLength(c) == 1)
           {
            _nonnumericLiteralHasSBCS = true;
           }
          else
           {
            _nonnumericLiteralLength++;
            _nonnumericLiteralHasDBCS = true;
            if (characterWidth == 2 && _nls.isSourceSosi())
             {
              if (previousCharacterWidth == 1)
               {
                _nonnumericLiteralLength++;
               }
              int nextCharacterWidth = 1;
              if (i < _tokenText.length())
               {
                nextCharacterWidth = _nls.sourceLength(_tokenText.charAt(i));
               }
              if (nextCharacterWidth == 1)
               {
                _nonnumericLiteralLength++;
               }
             }
           }
          previousCharacterWidth = characterWidth;
         }
        return true;
       }
     }
    return false;
   }

  /**
   * Parse the current nonnumeric literal.
   */
  protected void parseNonnumericLiteral()
   {
    String error = null;
    if (!_nonnumericLiteralHasClosingDelimiter)
     {
      error = "delimiterNotFound";
     }
    else if (_nonnumericLiteralLength == 0)
     {
      error = "emptyLiteral";
     }
    else if (((_nonnumericLiteralType == '\'' || _nonnumericLiteralType == '"') &&
              _nonnumericLiteralLength > MAX_NONNUMERIC_LIT) ||
             (_nonnumericLiteralType == 'X' &&
              _nonnumericLiteralLength > MAX_NONNUMERIC_HEX_LIT) ||
             (_nonnumericLiteralType == 'Z' &&
              _nonnumericLiteralLength > MAX_NONNUMERIC_Z_LIT))
     {
      error = "tokenTooBig";
     }
    else if (_nonnumericLiteralType == 'X' && _nonnumericLiteralHasNonhexadecimal)
     {
      error = "invalidHexadecimalLiteral";
     }
    else if (_nonnumericLiteralType == 'X' && _nonnumericLiteralLength % 2 != 0)
     {
      error = "oddHexadecimalLiteral";
     }
    else if ((_nonnumericLiteralType == 'G' || _nonnumericLiteralType == 'N') &&
             _nonnumericLiteralHasSBCS)
     {
      error = "invalidDBCSLiteral";
     }
    else if (_nonnumericLiteralHasDBCS && _firstTokenFragment != _lastTokenFragment)
     {
      error = "badContinuation";
     }
    else if (_nonnumericLiteralType != '"' && _nonnumericLiteralType != '\'' &&
             _firstTokenFragment != _lastTokenFragment &&
             _firstTokenFragment._startCharacterPosition ==
                _firstTokenFragment._endCharacterPosition)
     {
      error = "badContinuation";
     }

    if (error != null)
     {
      setToken('e', _classError, error);
     }
    else
     {
      setToken('l');
     }
   }

  /**
   * Return <code>true</code> if the current token is an opening
   * pseudo-text delimiter.
   */
  protected boolean isPseudoTextStart()
   {
    return _tokenText.length() == 2 &&
           _tokenText.charAt(0) == '=' &&
           _tokenText.charAt(1) == '=';
   }

  /**
   * Parse the current opening pseudo-text delimiter.
   */
  protected void parsePseudoTextStart()
   {
    if (_firstTokenFragment != _lastTokenFragment)
     {
      setToken('e', _classError, "badContinuation");
     }
    else
     {
      setToken('t');
     }
    _multiTokenStartElement = _firstTokenFragment._element;
    _parseMode = PARSE_MODE_PSEUDO_TEXT;
   }

  /**
   * Parse the current error token.
   */
  protected void parseErrorToken()
   {
    setToken('e', _classError, "invalidItem");
   }

  /**
   * Parse the current pseudo-text token.
   */
  protected void parsePseudoTextToken()
   {
    if (_tokenText.length() == 2 &&
        _tokenText.charAt(0) == '=' &&
        _tokenText.charAt(1) == '=')
     {
      linkElements(_multiTokenStartElement, _lastTokenFragment._element);
      _multiTokenStartElement = -1;
      _parseMode = PARSE_MODE_CODE;
     }
    setToken('t');
   }

  /**
   * Parse the current token in the PICTURE clause.
   */
  protected void parsePictureToken()
   {
    if (isCommaOrSemicolon())
     {
      parseSeparator();
     }
    else if (isReservedWord() && _reservedWord.id() == CobolWords.IS)
     {
      setToken('r');
      _parseMode = PARSE_MODE_PICTURE_IS;
     }
    else
     {
      parsePictureString();
     }
   }

  /**
   * Parse the current token in the PICTURE IS clause.
   */
  protected void parsePictureIsToken()
   {
    if (isCommaOrSemicolon())
     {
      parseSeparator();
     }
    else
     {
      parsePictureString();
     }
   }

  /**
   * Return the maximum number of characters allowed in the picture string.
   */
  protected int maxPicture()
   {
    return MAX_PICTURE;
   }

  /**
   * Parse the current picture string.
   */
  protected void parsePictureString()
   {
    if (_tokenText.length() > maxPicture())
     {
      setToken('e', _classError, "tokenTooBig");
     }
    else
     {
      setToken('p');
     }
    linkElements(_multiTokenStartElement, _lastTokenFragment._element);
    _multiTokenStartElement = -1;
    _parseMode = PARSE_MODE_CODE;
   }

  /**
   * Parse the current identification division optional paragraph token.
   */
  protected void parseOptionalIdParagraphToken()
   {
    if (isCommaOrSemicolon())
     {
      parseSeparator();
     }
    else
     {
      if (_tokenText.length() == 1 && _tokenText.charAt(0) == '.')
       {
        _parseMode = PARSE_MODE_COMMENT_ENTRY;
       }
      else
       {
        linkElements(_multiTokenStartElement, _lastTokenFragment._element);
        _multiTokenStartElement = -1;
        _parseMode = PARSE_MODE_CODE;
       }
      parseCodeToken();
     }
   }

  /**
   * Parse the current comment entry token.
   */
  protected void parseCommentEntryToken()
   {
    if (_firstTokenFragment._startBytePosition >= 11)
     {
      if (_firstTokenFragment != _lastTokenFragment)
       {
        setToken('e', _classError, "badContinuation");
       }
      else
       {
        setToken('c');
       }
     }
    else
     {
      linkElements(_multiTokenStartElement, _lastTokenFragment._element);
      _multiTokenStartElement = -1;
      _parseMode = PARSE_MODE_CODE;
      parseCodeToken();
     }
   }


  /**
   * Return <code>true</code> if the current token is a function name.
   */
  protected boolean isFunctionName()
   {
    return CobolWords.isFunctionName(_tokenText);
   }

  /**
   * Parse the current function clause token.
   */
  protected void parseFunctionToken()
   {
    if (isCommaOrSemicolon())
     {
      parseSeparator();
     }
    else
     {
      if (isFunctionName())
       {
        setToken('f');
       }
      else
       {
        setToken('e', _classError, "invalidFunctionName", _tokenText.toString());
       }
      linkElements(_multiTokenStartElement, _lastTokenFragment._element);
      _multiTokenStartElement = -1;
      _parseMode = PARSE_MODE_CODE;
     }
   }

  /**
   * Parse the current date clause token.
   */
  protected void parseDateToken()
   {
    if (isCommaOrSemicolon())
     {
      parseSeparator();
     }
    else if (isReservedWord() && _reservedWord.id() == CobolWords.FORMAT)
     {
      setToken('r');
      _parseMode = PARSE_MODE_DATE_FORMAT;
     }
    else
     {
      linkElements(_multiTokenStartElement, _lastTokenFragment._element);
      _multiTokenStartElement = -1;
      _parseMode = PARSE_MODE_CODE;
      parseCodeToken();
     }
   }

  /**
   * Parse the current date format clause token.
   */
  protected void parseDateFormatToken()
   {
    if (isCommaOrSemicolon())
     {
      parseSeparator();
     }
    else if (isReservedWord() && _reservedWord.id() == CobolWords.IS)
     {
      setToken('r');
      _parseMode = PARSE_MODE_DATE_FORMAT_IS;
     }
    else
     {
      parseDateFormatString();
     }
   }

  /**
   * Parse the current date format is clause token.
   */
  protected void parseDateFormatIsToken()
   {
    if (isCommaOrSemicolon())
     {
      parseSeparator();
     }
    else
     {
      parseDateFormatString();
     }
   }

  /**
   * Parse the current date format.
   */
  protected void parseDateFormatString()
   {
    if (CobolWords.isDateFormat(_tokenText))
     {
      setToken('a');
     }
    else
     {
      setToken('e', _classError, "invalidDateFormat", _tokenText.toString());
     }
    linkElements(_multiTokenStartElement, _lastTokenFragment._element);
    _multiTokenStartElement = -1;
    _parseMode = PARSE_MODE_CODE;
   }

  /**
   * Parse the current preprocessor string token.
   * If it is "END-EXEC", return parse mode to CODE.
   * If it is "SQL" or "CICS", try to activate the appropriate lexer.
   */
  protected void parsePreprocessorToken()
   {
    long preprocessorClass = _classPreprocessor;

    if (CobolWords.equals("END-EXEC", _tokenText))
     {
      linkElements(_multiTokenStartElement, _lastTokenFragment._element);
      _multiTokenStartElement = -1;
      _parseMode = PARSE_MODE_CODE;
     }

    else if (CobolWords.equals("SQL", _tokenText))
     {
      if (setLexer(LEXER_SQL))
       {
        preprocessorClass |= _classSql;
       }
     }

    else if (CobolWords.equals("CICS", _tokenText))
     {
      if (setLexer(LEXER_CICS))
       {
        preprocessorClass |= _classCics;
       }
     }

    setToken('h', preprocessorClass);
   }

  /**
   * Set the style character for the current token.
   */
  protected void setToken(char styleCharacter)
   {
    setToken(styleCharacter, 0, null, null);
   }

  /**
   * Set the style character and classes for the current token.
   */
  protected void setToken(char styleCharacter, long classes)
   {
    setToken(styleCharacter, classes, null, null);
   }

  /**
   * Set the style character, classes and error message for the current token.
   */
  protected void setToken(char styleCharacter, long classes, String message)
   {
    setToken(styleCharacter, classes, message, null);
   }

  /**
   * Set the style character, classes, error message and error message argument
   * for the current token.
   */
  protected void setToken(char styleCharacter, long classes, String message, String argument)
   {
    // set style & classes in the parse elements of all this token's fragments
    for (TokenFragment tokenFragment = _firstTokenFragment;
         tokenFragment != null;
         tokenFragment = tokenFragment._next)
     {
      ParseElement parseElement = findParseElement(tokenFragment._element);
      if (parseElement != null)
       {
        StringBuffer style = parseElement._style;
        for (int i = tokenFragment._startCharacterPosition;
             i <= tokenFragment._endCharacterPosition;
             i++)
         {
          style.setCharAt(i, styleCharacter);
         }
        parseElement._classes |= classes;
       }
     }

    // if multiline token, link its elements
    linkElements(_firstTokenFragment._element, _lastTokenFragment._element);

    // display the error message
    if (message != null)
     {
      addErrorMessage(_lastTokenFragment._element, message, argument);
     }
   }

  /**
   * Link the specified elements together if necessary.  No action is taken if
   * <code>startElement</code> and <code>endElement</code> are the same element.
   *
   * Multiple elements belonging to one construct are doubly-linked with the
   * _classForwardLink and _classBackwardLink.
   */
  protected void linkElements(int startElement, int endElement)
   {
    if (startElement != endElement)
     {
      for (int i = startElement; i <= endElement; i++)
       {
        long classes = 0;
        if (i != startElement)
         {
          classes |= _classBackwardLink;
         }
        if (i != endElement)
         {
          classes |= _classForwardLink;
         }

        ParseElement parseElement = findParseElement(i);
        if (parseElement != null) // 1.- ParseElement available for this element
         {
          parseElement._classes |= classes;
         }
        else                      // 2.- no parse element, set directly in editor
         {
          view.setElementClasses(i, view.elementClasses(i) | classes);
         }
       }
     }
   }

  /**
   * Return the parser's properties profile resource bundle.
   */
  public ResourceBundle getProfile()
   {
    return _resource;
   }

  /**
   * Returns "COBOL", the language supported by this parser.
   *
   * @see com.ibm.lpex.core.LpexCommonParser#LANGUAGE_COBOL
   */
  public String getLanguage()
   {
    return LANGUAGE_COBOL;
   }

  /**
   * Retrieve a string identifying the language segment at the specified
   * location.  In mixed-content documents, this may differ from the main
   * language of the document.
   *
   * The method assumes that no parse is pending.
   *
   * @return one of: LpexCommonParser.LANGUAGE_COBOL,
   *                 LpexCommonParser.LANGUAGE_CICS,
   *                 LpexCommonParser.LANGUAGE_SQL
   */
  public String getLanguage(LpexDocumentLocation loc)
   {
    long classes = view.elementClasses(loc.element);
    if ((classes & _classSql) != 0)
       return LANGUAGE_SQL;
    if ((classes & _classCics) != 0)
       return LANGUAGE_CICS;
    return getLanguage();
   }

  /**
   * Initialize the parser for an LPEX document view: set up style attributes
   * for the styles we need, classes, etc., and initialize the view
   * for the language-sensitive edit features supported.
   */
  protected void initializeParser()
   {
    _nls = view.nls();

    // set the COBOL format line
    String formatLine = getProperty("formatLine");
    if (formatLine != null && formatLine.length() > 0)
       view.doCommand("set formatLineText "+formatLine);

    // set common attributes for the styles we use
    String tokenHighlight = getProperty("tokenHighlight");
    setStyleAttributes(tokenHighlight == null || !tokenHighlight.equals("off"));

    // register the classes we use & get their allocated bit-masks
    _classForwardLink  = view.registerClass(CLASS_FWDLINK);
    _classBackwardLink = view.registerClass(CLASS_BWDLINK);
    _classBlank        = view.registerClass(CLASS_BLANK);
    _classError        = view.registerClass(CLASS_ERROR);
    _classComment      = view.registerClass(CLASS_COMMENT);
    _classDirective    = view.registerClass(CLASS_DIRECTIVE);
    _classDivision     = view.registerClass(CLASS_DIVISION);
    _classSection      = view.registerClass(CLASS_SECTION);
    _classAreaA        = view.registerClass(CLASS_AREAA);
    _classAreaB        = view.registerClass(CLASS_AREAB);
    _classPreprocessor = view.registerClass(CLASS_PREPROCESSOR);
    _classCics         = view.registerClass(CLASS_CICS);
    _classSql          = view.registerClass(CLASS_SQL);
    _classAll = _classForwardLink | _classBackwardLink |
                _classBlank | _classError | _classComment |
                _classDirective | _classDivision | _classSection |
                _classAreaA | _classAreaB |
                _classPreprocessor | _classCics | _classSql;

    /*-----------------------*/
    /*  define LPEX actions  */
    /*-----------------------*/
    // view filter action "comments" for COBOL comments
    LpexAction lpexAction = new LpexAction()               // "comments"
     {
      public void doAction(LpexView view)
       {
        view.doDefaultCommand("set includedClasses " + CLASS_COMMENT);
        view.doDefaultCommand("set excludedClasses");
       }
      public boolean available(LpexView view)
       {
        return true;
       }
     };
    view.defineAction("comments", lpexAction);

    // view filter action "divisions" for COBOL divisions
    lpexAction = new LpexAction()                          // "divisions"
     {
      public void doAction(LpexView view)
       {
        view.doDefaultCommand("set includedClasses " + CLASS_DIVISION);
        view.doDefaultCommand("set excludedClasses");
       }
      public boolean available(LpexView view)
       {
        return true;
       }
     };
    view.defineAction("divisions", lpexAction);

    // view filter action "areaA" for COBOL areaA lines
    lpexAction = new LpexAction()                          // "areaA"
     {
      public void doAction(LpexView view)
       {
        view.doDefaultCommand("set includedClasses " + CLASS_AREAA);
        view.doDefaultCommand("set excludedClasses");
       }
      public boolean available(LpexView view)
       {
        return true;
       }
     };
    view.defineAction("areaA", lpexAction);

    // view filter action "preprocessor" for COBOL preprocessor lines
    lpexAction = new LpexAction()                          // "preprocessor"
     {
      public void doAction(LpexView view)
       {
        view.doDefaultCommand("set includedClasses " + CLASS_PREPROCESSOR);
        view.doDefaultCommand("set excludedClasses");
       }
      public boolean available(LpexView view)
       {
        return true;
       }
     };
    view.defineAction("preprocessor", lpexAction);

    // set tab stops
    view.doDefaultCommand("set tabs 1 7 8 12 every 4");

    // create initial token fragment
    new TokenFragment();
   }

  /**
   * Return parser's items for the popup View submenu:
   * comments, divisions, areaA, preprocessor statements.
   */
  public String getPopupViewItems()
   {
      return getLanguage() + ".popup.comments comments " +
             getLanguage() + ".popup.divisions divisions " +
             getLanguage() + ".popup.areaA areaA " +
             getLanguage() + ".popup.preprocessor preprocessor ";
             //+ LpexConstants.MSG_POPUP_ERRORS + " errors";
   }

  /**
   * Define parser's style attributes.
   * @param colours <code>true</code> = token highlighting,
   *                <code>false</code> = no token highlighting
   */
  public void setStyleAttributes (boolean colours)
   {
    String toBackground = LpexPaletteAttributes.background(view);
    String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                      BACKGROUND_COLOR,
                                                      toBackground);
    if (colours)
     {
      setStyle("_bu", attributes);         // Layout blanks, separator, user defined word

      attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD,
                                                 BACKGROUND_COLOR,
                                                 toBackground);
      setStyle("rfa", attributes);         // reserved word, function name, date format

      attributes = LpexPaletteAttributes.convert(ATTRIBUTES_NUMERAL,
                                                 BACKGROUND_COLOR,
                                                 toBackground);
      setStyle("np", attributes);          // numeric literal, picture string

      attributes = LpexPaletteAttributes.convert(ATTRIBUTES_STRING,
                                                 BACKGROUND_COLOR,
                                                 toBackground);
      setStyle("lt", attributes);          // nonnumeric literal, pseudo-text

      attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
                                                 BACKGROUND_COLOR,
                                                 toBackground);
      setStyle("csi", attributes);         // Comment, sequence number, indicator area

      attributes = LpexPaletteAttributes.convert(ATTRIBUTES_ERROR,
                                                 BACKGROUND_COLOR,
                                                 toBackground);
      setStyle("e", attributes);           // Lexical error

      attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DIRECTIVE,
                                                 BACKGROUND_COLOR,
                                                 toBackground);
      setStyle("d",  attributes);          // compiler directive

      attributes = LpexPaletteAttributes.convert(ATTRIBUTES_LIBRARY,
                                                 BACKGROUND_COLOR,
                                                 toBackground);
      setStyle("h",  attributes);          // preprocessor string
     }
    else // drop the nice colours
     {
      setStyle("_burfanpltcsiedh", attributes);
     }
   }

  /**
   * Retrieve the name of the COBOL help page that the parser identifies
   * as appropriate for the currently selected token
   */
  public String getHelpPage()
   {
    String helpPage = null;
    loadProperties();
    if (_helpPages != null)
     {
      String token = getToken(view.documentLocation());
      if (token != null)
       {
        helpPage = _helpPages.getProperty(token);
       }
     }
    return helpPage;
   }

  static private void loadProperties()
   {
    if (!_propertiesLoaded)
     {
      _helpPages = new Properties();
//    _helpPages = HelpCommand.loadHelpMap(HELP_COBOL);
//    // whether the load succeeded or not, there's no point
//    // in trying again until LPEX is restarted
      _propertiesLoaded = true;
     }
   }

  /**
   * Evaluate a parse range for incremental parse from the specified element
   * up to the top of the file.
   * @return new start element to parse from
   */
  protected int evaluateBeginElement (int element)
   {
    int elements = view.elements();
    while (element < elements && view.show(element))
     {
      element++;
     }
    long classes = 0;
    int parsePending = 0;
    if (!view.show(element))
     {
      classes = view.elementClasses(element);
      parsePending = view.parsePending(element);
     }

    for (; element > 1; element--)
     {
      if (!view.show(element - 1))
       {
        long prevClasses = view.elementClasses(element - 1);
        int prevParsePending = view.parsePending(element - 1);
        if ((classes & _classBackwardLink) == 0 &&
            (parsePending & PARSE_PENDING_CHANGE_MASK) == 0 &&
            (classes & (_classAreaA | _classAreaB)) != 0 &&
            (prevClasses & _classForwardLink) == 0 &&
            (prevParsePending &
               (PARSE_PENDING_CHANGE_MASK | PARSE_PENDING_NEXT_SHOW_DELETED_MASK)) == 0)
         {
          break;
         }
        classes = prevClasses;
        parsePending = prevParsePending;
       }
     }
    while (element < elements && view.show(element))
     {
      element++;
     }
    return element;
   }

  /**
   * Evaluate a parse range for incremental parse from the specified element
   * to the bottom of the file.
   * @return new end element to parse to
   */
  protected int evaluateEndElement(int element)
   {
    int elements = view.elements();
    while (element > 1 && view.show(element))
     {
      element--;
     }
    long classes = 0;
    if (!view.show(element))
     {
      classes = view.elementClasses(element);
     }

    for (; element < elements; element++)
     {
      if (!view.show(element + 1))
       {
        long nextClasses = view.elementClasses(element + 1);
        int nextParsePending = view.parsePending(element + 1);
        if ((classes & _classForwardLink) == 0 &&
            (nextClasses & _classBackwardLink) == 0 &&
            (nextParsePending &
               (PARSE_PENDING_CHANGE_MASK | PARSE_PENDING_NEXT_SHOW_DELETED_MASK)) == 0)
         {
          break;
         }
        classes = nextClasses;
       }
     }
    return element;
   }

  /**
   * Display an error message with an argument for an element.
   */
  protected void addErrorMessage(int element, String message, String argument)
   {
    StringBuffer buffer = new StringBuffer(getLanguage());
    buffer.append('.');
    buffer.append(message);
    addMessage(element, LpexResources.message(buffer.toString(), argument));
   }

  /**
   * Display an error message for an element.
   */
  protected void addErrorMessage(int element, String message)
   {
    addErrorMessage(element, message, null);
   }


  /*-------------------------------*/
  /*  Embedded SQL / CICS support  */
  /*-------------------------------*/

  /**
   * Set the active preprocessor lexer (SQL/CICS) or return to COBOL code
   * parsing. On exit, _activeLexer holds the currently active lexer.
   *
   * When a preprocessor lexer is successfully activated, it is set in
   * its DEFAULT lexical state.
   *
   * @return true = new lexer successfully set
   */
  private boolean setLexer(int newLexer)
   {
    if (newLexer != LEXER_COBOL)
     {
      if (_stream == null)
       {
        _stream = new LpexCharStream(view);
       }

      if (newLexer == LEXER_SQL)
       {
        if (sqlLexer == null)
         {
          sqlLexer = getSqlLexer(_stream);
          if (sqlLexer == null)
           {
            return false;
           }
         }
       }
      else // LEXER_CICS
       {
        if (cicsLexer == null)
         {
          cicsLexer = getCicsLexer(_stream);
          if (cicsLexer == null)
           {
            return false;
           }
         }
       }
     }

    _activeLexer = newLexer;
    return true;
   }

  /**
   * Retrieve the SqlLexer.
   * The parser extending CobolParser to support embedded SQL statements must
   * override this method to construct and return an SqlLexer object.
   * The implementation of this method provided by CobolParser does
   * nothing, except return null.
   *
   * @param stream input character stream for the SQL lexer
   */
  protected SqlLexer getSqlLexer(LpexCharStream stream)
   {
    return null;
   }

  /**
   * Retrieve the CicsLexer.
   * The parser extending CobolParser to support embedded CICS statements must
   * override this method to construct and return a CicsLexer object.
   * The implementation of this method provided by CobolParser does
   * nothing, except return null.
   *
   * @param stream input character stream for the CICS lexer
   */
  protected CicsLexer getCicsLexer(LpexCharStream stream)
   {
    return null;
   }

  /**
   * Reinitialize the active preprocessor lexer (SQL/CICS) for
   * the same input char stream.
   * For example, after an exception (such as EOF at end of the
   * initially-estimated parse range):  we skip the token in
   * error and continue parsing.
   */
  private void reinitializeLexer()
   {
    if (_activeLexer == LEXER_SQL)
     {
      sqlLexer.reinitialize();
     }
    else // LEXER_CICS
     {
      cicsLexer.reinitialize();
     }
   }

  /**
   * Process a token with the active preprocessor lexer (SQL/CICS).
   * We must continue parsing the embedded SQL/CICS construct until LEXER_RC_END
   * is returned indicating "END-EXEC".
   */
  private int processLexerToken()
   {
    return (_activeLexer == LEXER_SQL)? sqlLexer.processToken() :
                                        cicsLexer.processToken();
   }

  /**
   * Called from parse() after an EXEC "SQL" or "CICS" token (in _tokenText) was
   * parsed, to handle an entire preprocessor construct using a Cics/SqlLexer.
   * _currentElement & _currentCharacterPosition already point to the first
   * token to be processed by the lexer.
   *
   * <p>When done, this method returns the environment as expected by the COBOL
   * parser.
   */
  private void parsePreprocessor()
   {
    /*-----------------------*/
    /*  prepare for parsing  */
    /*-----------------------*/
    // set in the editor what's been parsed so far by the COBOL parser
    while (_parseElements != null)
     {
      _parseElements.flush();
     }

     // _classAreaA/_classAreaB may have been set for the 1st and/or possibly
     // 2nd/nth line, of the construct - our lexers, on the other hand, do *not*
     // set _classAreaA/_classAreaB for the lines they parse in the construct,
     // so drop them all except for the "EXEC" first line
     // [-as- alternatively, we could set _classAreaA/B in the parser only when
     // parse mode is not already PREPROCESSOR, regardless of whether lexers are
     // available or not...]
    for (int i = _multiTokenStartElement+1; i <= _currentElement; i++)
     {
      view.setElementClasses(i, view.elementClasses(i) & ~(_classAreaA | _classAreaB));
     }

    // initialize the char stream & lexer
    _stream.Init(_currentElement, _currentCharacterPosition+1, _endElement,
                 _classAll, _classBlank, '_', false);
    if (_activeLexer == LEXER_SQL)
     {
      sqlLexer.initialize();
     }
    else // LEXER_CICS
     {
      cicsLexer.initialize();
     }

    /*---------------------------------------*/
    /*  parse entire preprocessor construct  */
    /*---------------------------------------*/
    int elements = view.elements();
    while (true)
     {
      try
       {
        int rc = processLexerToken();

        // done with an entire "EXEC" .. "END-EXEC" construct
        if ((rc & LEXER_RC_END) != 0)
         {
          break;
         }

        // on EOF, try to extend the parse range
        else if ((rc & LEXER_RC_EOF) != 0)
         {
          if (_endElement >= elements)
           {
            break; // nothing more to do...
           }
          int oldEndElement = _endElement;
          _endElement = evaluateEndElement(_endElement + 1);
          _stream.Expand(_endElement);
          // clear old messages in the newly expanded parse range
          removeMessages(oldEndElement+1, _endElement);
         }
       }
      catch (TokenMgrError e)     // EOF in middle of token/bad char
       {
        _stream.setStyles(_stream.getBeginColumn(),
                          _stream.getEndColumn(), 'e');
        _stream.setClasses(_classError);
        addErrorMessage(_stream.getEndLine(), "syntaxError");
        if (_stream.EOFSeen())         // EOF (styles already set)?
         {
          _stream.setCurrentStyles();  //  do it again complete, with the error
          break;                       //  & that's it, folks...
         }

        _stream.skipChar();       // skip the error character (presumably...)
        reinitializeLexer();      //  & continue past it
       }
     }//end "while true"

    /*--------------------------------------------------------------*/
    /*  restore parse environment to what the COBOL parser expects  */
    /*--------------------------------------------------------------*/
    _stream.setCurrentStyles();   // set in editor the work of the lexer

    _currentElement = _stream.getEndLine();
    linkElements(_multiTokenStartElement, _currentElement);
    _multiTokenStartElement = -1;

    setLexer(LEXER_COBOL);        // return to regular COBOL parsing
    _parseMode = PARSE_MODE_CODE;
    reInitCurrentElement(_stream.getEndColumn());
   }


  /*--------------------------------*/
  /*  COBOL parser utility classes  */
  /*--------------------------------*/

  /**
   * A TokenFragment contains information about part of a token.
   * If a token extends over multiple lines, then several TokenFragment
   * objects will be needed to describe the entire token.
   */
  public class TokenFragment
   {
    /**
     * The element for this token fragment.
     */
    public int _element;

    /**
     * The start character position of this token fragment.
     */
    public int _startCharacterPosition;

    /**
     * The start byte position of this token fragment.
     */
    public int _startBytePosition;

    /**
     * The end character position of this token fragment.
     */
    public int _endCharacterPosition;

    /**
     * The end byte position of this token fragment.
     */
    public int _endBytePosition;

    /**
     * The next token fragment.
     */
    public TokenFragment _next;

    /**
     * Construct a new token fragment.  If not the first, link it in.
     */
    public TokenFragment()
     {
      if (_firstTokenFragment == null)
       {
        _firstTokenFragment = this;
        _lastTokenFragment = this;
       }
      else
       {
        _lastTokenFragment._next = this;
        _lastTokenFragment = this;
       }
     }
   }

  /**
   * The ParseElement class contains cached information about a document
   * element.
   */
  public class ParseElement
   {
    /**
     * The cached element number.
     */
    public int _element;

    /**
     * The cached element text.
     */
    public String _text;

    /**
     * The cached element classes.
     */
    public long _classes;

    /**
     * Indicates that the cached element is a continuation line.
     */
    public boolean _continuationLine;

    /**
     * The cached element style.
     */
    public StringBuffer _style = new StringBuffer(80);

    /**
     * The next cached element.
     */
    public ParseElement _next;

    /**
     * Construct an instance of ParseElement.  The instance is added
     * to the list of free ParseElements (_freeParseElements).
     */
    public ParseElement()
     {
      _next = _freeParseElements;
      _freeParseElements = this;
     }

    /**
     * Cache the specified element in this ParseElement.
     * This ParseElement is taken off the available list (_freeParseElements),
     * and added to the in-use list (_parseElements).
     */
    public void init(int element)
     {
      _element = element;
      _text = lpexView().elementText(element);
      _classes = 0;
      _continuationLine = false;
      _style.setLength((_text.length() < 80)? _text.length() : 80);

      _freeParseElements = _next;
      _next = _parseElements;
      _parseElements = this;
     }

    /**
     * Decache the cached element.
     * The style and classes are set in the editor.
     */
    public void flush()
     {
      lpexView().setElementStyle(_element, _style.toString());
      lpexView().setElementClasses(_element, _classes);

      ParseElement parseElement = _parseElements;
      ParseElement prev = null;
      while (parseElement != this)
       {
        prev = parseElement;
        parseElement = parseElement._next;
       }

      if (prev != null)
       {
        prev._next = _next;
       }
      else
       {
        _parseElements = _next;
       }

      _next = _freeParseElements;
      _freeParseElements = this;
     }

    /**
     * Determine if the cached parse element is still being used in parsing.
     */
    public boolean active()
     {
      if (_element == _currentElement ||
          (_saveTokenCharacterValid && _element == _saveTokenCharacterElement))
       {
        return true;
       }

      for (TokenFragment tokenFragment = _firstTokenFragment;
           tokenFragment != null;
           tokenFragment = tokenFragment._next)
       {
        if (_element == tokenFragment._element)
         {
          return true;
         }
       }

      return false;
     }
   }
 }