//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FortranParser - base document parser for Fortran (free source form).
//----------------------------------------------------------------------------

package com.ibm.lpex.fortran;

import java.util.ResourceBundle;

import com.ibm.lpex.core.LpexAction;
import com.ibm.lpex.core.LpexCharStream;
import com.ibm.lpex.core.LpexCommonParser;
import com.ibm.lpex.core.LpexConstants;
import com.ibm.lpex.core.LpexPaletteAttributes;
import com.ibm.lpex.core.LpexView;

import com.ibm.lpex.cc.TokenMgrError;


//*as* TO DO: port external\lxfmatch.c from C++LPEX.

/**
 * Base document parser for Fortran.  It uses the free source form Fortran lexer.
 *
 * <p>Actions and assigned keys added by this document parser:
 * <ul>
 *   <li><b>functions</b> (Ctrl+G) for a selective view of the functions and subroutines
 *       in the document
 *   <li><b>outline</b> for an outline view of the document
 *   <li><b>errors</b> for a selective view of the errors in the document.
 * </ul></p>
 *
 * Keys already defined (e.g., by the active base profile) to an action
 * different from <b>nullAction</b> are not redefined in here.
 */
public class FortranParser extends LpexCommonParser
{
   // the input stream the view feeds
   private LpexCharStream stream;

   private static ResourceBundle resource =
      ResourceBundle.getBundle("com.ibm.lpex.fortran.Profile");

   // the element classes we use...
   private static final String
      CLASS_CODE         = "code",
      CLASS_FWDLINK      = "forwardLink",
      CLASS_BWDLINK      = "backwardLink",
      CLASS_COMMENT      = "comment",
      CLASS_ERROR        = "error",
      CLASS_LABEL        = "label",
      CLASS_SUB          = "sub";

   // ...and their registered bitmasks
   private long
      classCode,
      classForwardLink,
      classBackwardLink,
      classComment,
      classError,
      classLabel,
      classSub,
      classAll;

   private IFortranLexer lexer;

   // token delimiters for LpexCommonParser's isTokenDelimiter()
   static final String TOKEN_DELIMITERS = "();,";


   /**
    * Constructor for the parser.
    * Adds all of the parser specifics to the LPEX document view.
    * Initializes the Lpex view for the parser:  it sets up all the style
    * attributes, classes, etc. for the language-sensitive edit features
    * supported.
    *
    * @param lpexView the LPEX document view associated with this parser
    */
   public FortranParser(LpexView lpexView)
   {
      super(lpexView);        // LpexCommonParser constructor (view := lpexView)
      initializeParser();     // initialize LpexView with our stuff

      // instantiate an input stream for this view, and the lexer
      stream = new LpexCharStream(view);
      lexer  = getFortranLexer(stream,
                               new FortranLexerStyles("crekosvnqalpdfi"),
                               new FortranLexerClasses(view, classCode,
                                          classForwardLink, classBackwardLink,
                                          classComment, classError,
                                          classSub, classLabel));
   }

   /**
    * Return the Fortran lexer to be used by this parser.
    * The default implementation returns a new FortranFFLexer (free source form
    * Fortran lexer).  To use a different lexer, override this method.
    */
   protected IFortranLexer getFortranLexer(LpexCharStream charStream,
                                           FortranLexerStyles lexerStyles,
                                           FortranLexerClasses lexerClasses)
   {
      return new FortranFFLexer(stream, lexerStyles, lexerClasses);
   }

   /**
    * Total parse of the entire document.
    * Done initially, after a document has been loaded in LPEX, or after an
    * <b>updateProfile</b> command.
    */
   public void    parseAll()
   {
      int elements = view.elements();         // a bit of preventive care...
      if (elements == 0)
         return;

      doParse(1, elements, false, false);     // first parse on entire doc
   }

   /**
    * Incremental parse.
    *
    * @param element the (first) element whose committed change triggered the
    *                parse, or the element that precedes/follows a deleted block.
    *                The parser may identify other neighbouring elements that
    *                will have to be reparsed as a unit
    */
   public void    parseElement(int element)
   {
      if (view.elements() == 0)               // a bit of preventive care...
         return;

      doParse(evaluateBeginElement(element),  // parse optimal range
              evaluateEndElement(element),
              true,                           // remove error messages
              true);                          // clear their parsePending flags
   }

   /**
    * Returns the parser's properties profile resource bundle.
    */
   public ResourceBundle getProfile()
   {
      return resource;
   }

   /**
    * Returns <code>"Fortran"</code>, the language supported by this parser.
    *
    * @see com.ibm.lpex.core.LpexCommonParser#LANGUAGE_FORTRAN
    */
   public String  getLanguage()
   {
      return LANGUAGE_FORTRAN;
   }

   /**
    * Initialize the parser for an LPEX document view: set up style attributes
    * for the styles we need, classes, etc., and initialize the view
    * for the language-sensitive edit features supported.
    */
   private void   initializeParser()
   {
      // set attributes for the styles we use
      String tokenHighlight = getProperty("tokenHighlight");
      setStyleAttributes(tokenHighlight == null || !tokenHighlight.equals("off"));

      // register the classes we use & get their allocated bit-masks
      classCode         = view.registerClass(CLASS_CODE);
      classForwardLink  = view.registerClass(CLASS_FWDLINK);
      classBackwardLink = view.registerClass(CLASS_BWDLINK);
      classComment      = view.registerClass(CLASS_COMMENT);
      classError        = view.registerClass(CLASS_ERROR);
      classLabel        = view.registerClass(CLASS_LABEL);
      classSub          = view.registerClass(CLASS_SUB);
      classAll = classCode | classForwardLink | classBackwardLink |
                 classComment | classError | classLabel | classSub;

      /*-----------------------*/
      /*  define LPEX actions  */
      /*-----------------------*/
      // view filter action "functions"
      LpexAction lpexAction = new LpexAction()             // "functions"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_SUB);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
      };
      view.defineAction("functions", lpexAction);
      view.doDefaultCommand("set keyAction.c-g.t.p.c functions");

      // view filter action "outline"
      view.defineAction("outline", new LpexAction()        // "outline"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_SUB + " " + CLASS_LABEL);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; }
      });

      // view filter action "errors"
      view.defineAction("errors", new LpexAction()         // "errors"
      {
         public void doAction(LpexView view)
         { view.doDefaultCommand("set includedClasses " + CLASS_ERROR);
           view.doDefaultCommand("set excludedClasses"); }

         public boolean available(LpexView view)
         { return true; /* could check if any errors in doc... */ }
      });
   }

   /**
    * Return parser's items for the popup View submenu:
    * functions, outline, errors.
    */
   public String    getPopupViewItems()
   {
      return getLanguage() + ".popup.functions functions " +
             getLanguage() + ".popup.outline outline " +
             LpexConstants.MSG_POPUP_ERRORS + " errors";
   }

   /**
    * Define parser's style attributes.
    *
    * @param colours true = token highlighting,
    *                false = no token highlighting
    */
   public void    setStyleAttributes(boolean colours)
   {
      String toBackground = LpexPaletteAttributes.background(view);
      String attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DEFAULT,
                                                        BACKGROUND_COLOR,
                                                        toBackground);
      if (colours) {
         setStyle("_p", attributes);      // Layout blanks; Punctuation/Operator

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_COMMENT,
                                                           BACKGROUND_COLOR,
                                                           toBackground);
         setStyle("cr", attributes);      // Comment; Remark (not in FF)

         attributes = LpexPaletteAttributes.convert("0 128 0 255 255 255",
                                                           BACKGROUND_COLOR,
                                                           toBackground);
         setStyle("a", attributes);       // Name

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_ERROR,
                                                           BACKGROUND_COLOR,
                                                           toBackground);
         setStyle("e", attributes);       // Error

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD,
                                                           BACKGROUND_COLOR,
                                                           toBackground);
         setStyle("ko", attributes);      // Executable; Nonexecutable statement keyword

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_KEYWORD1,
                                                           BACKGROUND_COLOR,
                                                           toBackground);
         setStyle("sv", attributes);      // Special program keyword; Special program end keyword

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_NUMERAL,
                                                           BACKGROUND_COLOR,
                                                           toBackground);
         setStyle("n", attributes);       // Numeric

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_STRING,
                                                           BACKGROUND_COLOR,
                                                           toBackground);
         setStyle("q", attributes);       // Character literal

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_DIRECTIVE,
                                                           BACKGROUND_COLOR,
                                                           toBackground);
         setStyle("d", attributes);       // Compiler directive

         attributes = LpexPaletteAttributes.convert("255 0 0 255 255 255",
                                                           BACKGROUND_COLOR,
                                                           toBackground);
         setStyle("f", attributes);       // Continuation indicator

         attributes = LpexPaletteAttributes.convert("0 0 128 255 255 255",
                                                           BACKGROUND_COLOR,
                                                           toBackground);
         setStyle("l", attributes);       // Label

         attributes = LpexPaletteAttributes.convert(ATTRIBUTES_NONSOURCE,
                                                           BACKGROUND_COLOR,
                                                           toBackground);
         setStyle("i", attributes);       // Ignored (not in FF)
         }
      else                                // drop the nice colours...
         setStyle("_pcraekosvnqdfli", attributes);
   }

   /**
    * Returns <code>true</code> if the specified character is a token delimiter.
    */
   public boolean isTokenDelimiter(char ch)
   {
      return TOKEN_DELIMITERS.indexOf(ch) >= 0;
   }

   /**
    * Parse a range of elements.
    * Called by both parseAll() and parseElement().
    *
    * @param beginElement   first element in range
    * @param endElement     last element in the range
    * @param removeMessages true = remove any lexical errors in the parse range
    * @param clearPending   true = clear parsePending once done with an element
    */
   private void   doParse(int beginElement, int endElement,
                          boolean removeMessages, boolean clearPending)
   {
      // clear existing lexical errors (if any) in the parse range
      // if (removeMessages)
      //    removeMessages(beginElement, endElement);

      // initialize parse operation & get parsing
      stream.Init(beginElement, endElement,
                  classAll,
                  0,                                // classSpace,
                  '_', clearPending);
      lexer.initialize();

      int elements = view.elements();
      while (true) {
         try {
            int rc = lexer.processToken();
            // on EOF, we may have to extend the parse range
            if ((rc & LEXER_RC_EOF) != 0) {
               if ((rc & LEXER_RC_MORE) != 0) {
                  int oldEndElement = endElement;
                  do {
                     endElement++;
                     } while ((endElement <= elements) && view.show(endElement));
                  if (endElement > elements)
                     break;
                  stream.Expand(endElement);
                  // clear old messages in the newly expanded parse range
                  // if (removeMessages)
                  //    removeMessages(oldEndElement+1, endElement);
                  }
               else
                  break;
               }
            }
         catch (TokenMgrError e) {            // EOF in middle of token/bad char
            //System.out.println(e);
            stream.setStyles(stream.getBeginColumn(),
                             stream.getEndColumn(), 'e');
            stream.setClasses(classError | classCode);
            //addErrorMessage(stream.getEndLine(),  // matchedToken.endLine bad!
            //                "syntaxError");

            if (stream.EOFSeen()) {                 // EOF (styles already set)?
               stream.setCurrentStyles();           //  do it again, complete
               break;                               //  & that's it, folks...
               }

            stream.skipChar();       // skip the error character (presumably...)
            lexer.reinitialize();                         //  & continue past it
            }
         }
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * up to the top of the file.
    * Extra lines may be included as follows:
    * - the previous non-show line is included if it has been modified or if it
    *   has a classForwardLink, or if the current line has a classBackwardLink,
    *   or if a line between the current and the previous was deleted;
    * - once an extra line is included, the one previous to it is also checked.
    *
    * @param element main line that triggered the parse
    * @return suggested start line for parsing (may be a show line)
    */
   private int    evaluateBeginElement(int element)
   {
      int  tryElem;          // an element preceding given element
      long classes,          // classes of current element
           tryClasses;       //  & classes of the element preceding it

      // get current line's class
      for (;  element > 1 && view.show(element);  element--) {}
      classes = view.elementClasses(element);

      // LOOP BACKWARDS (up to top of the file)...
      while (element > 1) {
         for (tryElem=element-1;  tryElem > 1 && view.show(tryElem);  tryElem--) {}
         tryClasses = view.elementClasses(tryElem);   // prev non-show line's classes

         // Include prev line in parse range and go on searching if *any* of:
         //   (a) current line has a BWDLINK;
         //   (b) previous non-show line has a FWDLINK;
         //   (c) line(s) between previous and current line was/were deleted;
         //   (d) previous non-show line has been modified.
         if ((classes & classBackwardLink) == 0  &&
             (tryClasses & classForwardLink) == 0
             /*&&(view.parsePending(element) & LX_PENDING_DELETE)==0*/
             /*&&(view.parsePending(tryElem) & LpexConstants.PARSE_PENDING_CHANGE_MASK)==0*/)
            break;

         classes = tryClasses;
         element = tryElem;
         }

      return element;
   }

   /**
    * Evaluate a parse range for incremental parse from the specified element
    * to the bottom of the file.
    * Extra lines may be included as follows:
    * - the next line is included if it's been modified, or if it has a class
    *   classBackwardLink, or is just a SHOW line, or if the current line has
    *   a class of classForwardLink;
    * - once an extra line is included, the one after it is also checked.
    *
    * @param element main line that triggered the parse
    * @return suggested end line for parsing (may be a show line)
    */
   private int    evaluateEndElement(int element)
   {
      int elements = view.elements();

      // LOOP FORWARDS (down to bottom of the file)...
      int endElem = element;
      for (; endElem < elements; endElem++) {
         long classes = view.elementClasses(endElem);

         // Include next line in parse range and go on searching if *any* of:
         //   (a) current line has a FWDLINK;
         //   (b) next line is just a SHOW line;
         //   (c) next line was modified;
         //   (d) next line has a classBackwardLink.
         // Also: current line has LpexConstants.PARSE_PENDING_NEXT_DELETED_MASK ?!? -as-
         if ((classes & classForwardLink)  == 0  &&
             (!view.show(endElem+1))             &&
             ((view.parsePending(endElem+1) & LpexConstants.PARSE_PENDING_CHANGE_MASK) == 0) &&
             ((view.elementClasses(endElem+1) & classBackwardLink) == 0))
            break;
         }

      return endElem;
   }
}