//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FortranLexerClasses - element classes for the Fortran lexers.
//----------------------------------------------------------------------------

package com.ibm.lpex.fortran;

import com.ibm.lpex.core.LpexView;

/**
 * Element classes for the Fortran lexers.  The classes used by the Fortran
 * lexers must be first defined and registered by the host document parser.
 */
public final class FortranLexerClasses
{
   long Code,             // any Fortran code in the line
        ForwardLink,      // double-link elements belonging
        BackwardLink,     //   to one parse unit
        Comment,          // comment
        Error,            // Fortran syntax error
        Sub,              // subroutine / functions
        Label;            // label

   /**
    * Default set of Fortran lexer classes.
    *
    * @param lpexView the LPEX document view associated with the lexer
    */
   public FortranLexerClasses(LpexView lpexView)
   {
      validateClasses(lpexView);
   }

   /**
    * Construct a set of Fortran lexer classes.
    *
    * @param lpexView the LPEX document view associated with the lexer
    */
   public FortranLexerClasses(LpexView lpexView, long code,
                              long forwardLink, long backwardLink,
                              long comment, long error, long sub, long label)
   {
      Code         = code;
      ForwardLink  = forwardLink;
      BackwardLink = backwardLink;
      Comment      = comment;
      Error        = error;
      Sub          = sub;
      Label        = label;
      validateClasses(lpexView);
   }

   /**
    * Ensure the classes set are OK.  Element links are used in incremental
    * parsing, must set them.
    */
   private void validateClasses(LpexView lpexView)
   {
      if (ForwardLink == 0)
         ForwardLink  = lpexView.registerClass("fortranForwardLink");
      if (BackwardLink == 0)
         BackwardLink = lpexView.registerClass("fortranBackwardLink");
   }
}