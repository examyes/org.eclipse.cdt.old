//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FortranLexer - Fortran lexer interface.
//----------------------------------------------------------------------------

package com.ibm.lpex.fortran;

/**
 * Interface FortranLexer can be implemented to define a Fortran lexer to be
 * used by a FortranParser.
 */
public interface IFortranLexer
{
   /**
    * Initialize the Fortran lexer.  The token manager is initialized for the
    * same character input stream, and in the default lexical state (DEFAULT).
    * This method is normally called when the host parser sets/switches the
    * active lexer to this lexer.
    */
   public void initialize();

   /**
    * Reinitialize the Fortran lexer.  The token manager is reinitialized for
    * the same character input stream, and in the default lexical state (DEFAULT).
    * This method is normally called after a TokenMgrError exception (e.g.,
    * encountered EOF in the middle of a token / a bad character), after the
    * token in error is skipped and parsing is continued.
    */
   public void reinitialize();

   /**
    * Retrieve and process the next Fortran token.
    *
    * @return LEXER_RC_OK, LEXER_RC_EOF [+LEXER_RC_MORE]
    *
    * @see com.ibm.lpex.core.LpexCommonParser#LEXER_RC_OK
    * @see com.ibm.lpex.core.LpexCommonParser#LEXER_RC_EOF
    * @see com.ibm.lpex.core.LpexCommonParser#LEXER_RC_MORE
    */
   public int processToken();
}