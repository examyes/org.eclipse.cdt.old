//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// FortranLexerStyles - styles for the Fortran lexers.
//----------------------------------------------------------------------------

package com.ibm.lpex.fortran;


/**
 * Styles for the Fortran lexers.  The style characters used by the Fortran
 * lexers must be defined by the host document parser.
 *
 * <p>The default style character set in the LpexCharStream by the host parser
 * (usually '_' for layout blanks) will also appear in elements tokenized by the
 * Fortran lexer.
 */
public final class FortranLexerStyles
{
   char Comment,       // comment
        Remark,        // remark
        Error,         // error
        ExeKeyword,    // executable statement keyword
        NonExeKeyword, // non-executable statement keyword
        ProKeyword,    // special program keyword
        ProEndKeyword, // special program end keyword
        Numeric,       // numeric constant
        String,        // character literal
        Name,          // name
        Label,         // label
        Punctuation,   // punctuation/operator
        Compiler,      // compiler directive
        Continuation,  // continuation indicator
        Ignored;       // ignored

   /**
    * Construct a set of Fortran lexer styles.
    * If the <code>styles</code> string is <code>null</code> or too short,
    * all the Fortran lexer styles are set to '!'.
    *
    * @param styles string of 15 style characters, in the following order:
    *               comment,
    *               remark,
    *               error,
    *               executable statement keyword,
    *               non-executable statement keyword,
    *               special program keyword,
    *               special program end keyword,
    *               numeric constant,
    *               character literal
    *               name,
    *               label,
    *               punctuation/operator,
    *               compiler directive,
    *               continuation indicator,
    *               ignored
    */
   public FortranLexerStyles(String styles)
   {
      if (styles == null || styles.length() < 15)
         styles = "!!!!!!!!!!!!!!!";

      Comment       = styles.charAt(0);
      Remark        = styles.charAt(1);
      Error         = styles.charAt(2);
      ExeKeyword    = styles.charAt(3);
      NonExeKeyword = styles.charAt(4);
      ProKeyword    = styles.charAt(5);
      ProEndKeyword = styles.charAt(6);
      Numeric       = styles.charAt(7);
      String        = styles.charAt(8);
      Name          = styles.charAt(9);
      Label         = styles.charAt(10);
      Punctuation   = styles.charAt(11);
      Compiler      = styles.charAt(12);
      Continuation  = styles.charAt(13);
      Ignored       = styles.charAt(14);
   }
}