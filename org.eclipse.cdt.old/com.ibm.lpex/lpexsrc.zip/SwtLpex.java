//----------------------------------------------------------------------------
// COMPONENT NAME: LPEX Editor
//
// (C) Copyright IBM Corporation 2000, 2002
// All Rights Reserved.
// This program and the accompanying materials are made available under
// the terms of the Common Public License which accompanies this distribution.
//
// DESCRIPTION:
// SwtLpex - sample/test class for the SWT-based LPEX text-edit widget.
//----------------------------------------------------------------------------

import com.ibm.lpex.core.LpexView;
import com.ibm.lpex.core.LpexViewAdapter;
import com.ibm.lpex.core.LpexWindow;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;


/**
 * This class is used to test the SWT-based LPEX edit widget by providing
 * a sample standalone editor.
 */
public final class SwtLpex
{
   Shell      _shell;
   String     _filename;
   LpexView   _lpexView;
   LpexWindow _lpexWindow;


   public static void main(String[] args)
   {
      String filename = null;
      if (args.length > 0)
         filename = args[0];
      new SwtLpex(filename).open().run().close();
   }

   SwtLpex(String filename)
   {
      _filename = filename;
   }

   public SwtLpex open()
   {
      // create a new Shell
      _shell = new Shell();

      // create an LpexView for the file name passed in,
      // do an explicit updateProfile later
      _lpexView = new LpexView(_filename, false);

      // set Shell title
      String name = _lpexView.query("name");
      if (name == null)
         name = "Untitled Document " + _lpexView.query("documentId");
      _shell.setText("SWT LPEX - " + name);

      // create & set a window for our LpexView
      _lpexWindow = new LpexWindow(_shell);
      _lpexView.setWindow(_lpexWindow);

      // add an LpexViewListener to handle all the listening needed here
      _lpexView.addLpexViewListener(
         new LpexViewAdapter() {
            //public void showing(LpexView lpexView) {}
            //public void shown(LpexView lpexView) {}
            //public boolean saving(LpexView lpexView) { return false; }
            //public void saved(LpexView lpexView) {}
            //public boolean renaming(LpexView lpexView) { return false; }
            //public void renamed(LpexView lpexView) {}
            //public void readonly(LpexView lpexView) {}

            // called after the updateProfile command was performed
            public void updateProfile(LpexView lpexView) {
               SwtLpex.this.updateProfile(lpexView);
               }

            // called when the LpexView is disposed
            public void disposed(LpexView lpexView) {
               _lpexView = null;
               }
            });

      // do an updateProfile command
      _lpexView.doCommand("updateProfile");

      // listen to a few Shell events
      _shell.addListener(SWT.Close, new Listener() {
         public void handleEvent(Event event) { closeShell(event); }}
         );
      _shell.addListener(SWT.Resize, new Listener() {
         public void handleEvent(Event event) { resizeShell(event); }}
         );
      _shell.addListener(SWT.Iconify, new Listener() {
         public void handleEvent(Event event) { iconifyShell(event); }}
         );
      _shell.addListener(SWT.Deiconify, new Listener() {
         public void handleEvent(Event event) { deiconifyShell(event); }}
         );
      _shell.addListener(SWT.Activate, new Listener() {
         public void handleEvent(Event event) { activateShell(event); }}
         );
      _shell.addListener(SWT.Deactivate, new Listener() {
         public void handleEvent(Event event) { deactivateShell(event); }}
         );

      // set Shell's position & size, open it
      _shell.setBounds(10, 10, 648, 711);
      _shell.open();

      // display the document
      LpexView.doGlobalCommand("screenShow");

      // set input focus in the edit area
      _lpexWindow.textWindow().setFocus();

      return this;
   }

   /**
    * Define any desired new LPEX commands, actions, and keys.
    * Called whenever the <b>updateProfile</b> command has been processed.
    */
   void updateProfile(LpexView lpexView)
   {
   }

   public SwtLpex close()
   {
      if ((_shell != null) && !_shell.isDisposed())
         _shell.dispose();
      _shell = null;
      return this;
   }

   void closeShell(Event event)
   {
      Rectangle rect = _shell.getClientArea();
      MessageBox box = new MessageBox(_shell, SWT.ICON_QUESTION | SWT.YES | SWT.NO);
      box.setText(_shell.getText());
      box.setMessage ("Close the SWT LPEX Example shell?");
      event.doit = box.open() == SWT.YES;
   }

   void activateShell(Event event)
   {
   }

   void deactivateShell(Event event)
   {
   }

   void deiconifyShell(Event event)
   {
      // remove the leading '*' added when iconified
      _shell.setText(_shell.getText().substring(1));
   }

   void iconifyShell(Event event)
   {
      // add a leading '*' for the taskbar icon name
      _shell.setText("*" + _shell.getText());
   }

   /**
    * Shell size was set / Shell was resized.
    */
   void resizeShell(Event event)
   {
      Rectangle rect = _shell.getClientArea();
      _lpexWindow.setBounds(0, 0, rect.width, rect.height);
   }

   public SwtLpex run()
   {
      Display display = _shell.getDisplay();
      while (!_shell.isDisposed()) {
         if (!display.readAndDispatch())
            display.sleep();
         }
      return this;
   }
}